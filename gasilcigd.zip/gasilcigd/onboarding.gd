extends ProofDebug















var _heard: Array[String] = []


func _listen() -> void :
	get_tree().node_added.connect( func(node: Node) -> void :
		if node is AudioStreamPlayer and node.get_parent() != null and node.get_parent().name == "UiSounds":
			var sound: = node as AudioStreamPlayer
			if sound.stream:
				_heard.append(sound.stream.resource_path.get_file().get_basename())
	)



func _press_event(action: String) -> void :
	await get_tree().process_frame
	var down: = InputEventAction.new()
	down.action = action
	down.pressed = true
	Input.parse_input_event(down)
	await get_tree().process_frame
	var up: = InputEventAction.new()
	up.action = action
	up.pressed = false
	Input.parse_input_event(up)
	await get_tree().process_frame



func _next_key() -> String:
	var next: Variant = Game.incident.get("next")
	return String(next.get("k", "")) if next is Dictionary else ""


func _until(condition: Callable, seconds: float) -> bool:
	var waited: = 0.0
	while not condition.call() and waited < seconds:
		await _wait(0.25)
		waited += 0.25
	return condition.call()





func _scenario_firstshift() -> void :
	await _wait(1.0)
	_listen()
	var shift: = FirstShift.current
	var list: = HudChecklist.current
	var calls: = CallService.current
	var fire: = FireService.current
	var pumper: = Vehicle.named("Fire Truck")
	_check(shift != null and list != null and HudStepBanner.current != null, "the first shift, its list and the step banner are there")
	player.teleport(Game.spawn_point())
	await _wait(0.5)
	calls.hold = false
	shift.begin()
	await _wait(0.6)
	_check(list.showing() and list._rows.size() == Config.Onboarding.FirstShift["Calls"][0].size(), "the list is up with the first call's %d steps" % list._rows.size())


	await _wait(float(Config.Onboarding.FirstShift["Every"]) + 0.5)
	_check(list.is_done("gear"), "the list ticks the gear: the suit is on from the start")
	_check(_heard.has(String(Config.Onboarding.FirstShift["TickSound"])), "a tick is heard (%s)" % [_heard])
	await _snap("list")


	var came: = await _until( func() -> bool: return not fire.incident.is_empty(), float(Config.Onboarding.FirstShift["CallAfter"]) + 20.0)
	_check(came, "the first call comes once the gear is on")
	if not came:
		await _done()
		return
	var building: Building = fire.incident["group"]["building"]
	var distance: = building.position.distance_to(Game.station.door_position)
	print("firstshift: call 1 at %s, %.0f studs out, level %d, card '%s'" % [building.name, distance, Alarm.level, Text.say(Game.incident.get("next"), "en")])
	_check(Alarm.level == 1, "the first call is at level I")
	_check( not building.counts_as_save and distance >= float(Config.Onboarding.FirstShift["SmallFrom"]) - 1.0, "a small fire a drive from the station")
	await _wait(0.5)
	_check(_next_key() == "onboarding.next.board", "the card says: get in a truck ('%s')" % Text.say(Game.incident.get("next"), "en"))
	await _wait(0.3)
	_check(HudStepBanner.current.showing() and HudStepBanner.current.last_shown == Text.say(Game.incident.get("next")), "the step shows in the middle of the screen ('%s')" % HudStepBanner.current.last_shown)
	await _snap("call1_banner")


	pumper.set_door("DoorCabLeft", true)
	await _wait(0.7)
	pumper._board(player, "DoorCabLeft")
	await _wait(0.8)
	_check(list.is_done("board"), "the list ticks boarding the pumper")
	_check(_next_key() == "onboarding.next.drive" or _next_key() == "onboarding.next.driveCall", "the card says where to drive ('%s')" % Text.say(Game.incident.get("next"), "en"))
	await _tap("veh_blue")
	await _tap("veh_siren")
	await _wait(0.6)
	print("firstshift: blue %s, siren %s" % [pumper.blue_on, pumper.siren])
	_check(list.is_done("lights"), "the list ticks blue lights and siren")
	await _snap("call1_drive")


	var way: = (Game.station.door_position - building.position)
	way.y = 0.0
	way = way.normalized()
	var spot: = _open_spot(building.position, way, pumper)
	_park(pumper, spot, atan2(way.x, way.z))
	await _wait(1.0)
	_check(list.is_done("route"), "the list ticks getting there")
	_check(_next_key() == "onboarding.next.parkHydrant", "the card says: park near a hydrant ('%s')" % Text.say(Game.incident.get("next"), "en"))
	await _tap("veh_exit")
	await _wait(0.8)
	if player.seat != null:
		print("firstshift: the exit key did not get out; leaving")
		pumper.leave(player)
		await _wait(0.6)
	_check(player.seat == null, "out of the truck")
	_check(_next_key() == "onboarding.next.hose", "the card says: pull a hose ('%s')" % Text.say(Game.incident.get("next"), "en"))


	await _reel(pumper)
	_check(list.is_done("hose"), "the list ticks the hose (holding '%s')" % player.holding)
	_check(_next_key().begins_with("calls.fire.next"), "the card goes on to the fire's own step ('%s')" % Text.say(Game.incident.get("next"), "en"))
	await _spray_at(fire)
	_check(list.is_done("spray"), "the list ticks the water")
	await _snap("call1_spray")
	await _put_out(fire)
	_check(fire.incident.is_empty(), "the first fire is out")


	await _home(pumper)
	var turned: = await _until( func() -> bool: return shift.call_index == 1, 5.0)
	_check(turned and list.is_done("gear") == true, "back at the station: the second call's list is up, the gear already ticked")
	_check(calls.wait_left <= float(Config.Onboarding.FirstShift["NextCallAfter"]) + 0.5, "the next call comes soon (%.0f s)" % calls.wait_left)
	await _snap("call2_list")
	calls.wait_left = minf(calls.wait_left, 1.0)


	came = await _until( func() -> bool: return not fire.incident.is_empty(), 15.0)
	_check(came, "the second call comes")
	if not came:
		await _done()
		return
	var house: Building = fire.incident["group"]["building"]
	var people: = VictimService.current
	print("firstshift: call 2 at %s, level %d, %d inside" % [house.name, Alarm.level, people.victims.size()])
	_check(house is House and Alarm.level == 1 and people.victims.size() == int(Config.Onboarding.FirstShift["Victims"]), "the second is a house fire at level I with one person inside")
	pumper.set_door("DoorCabLeft", true)
	await _wait(0.7)
	pumper._board(player, "DoorCabLeft")
	await _wait(0.5)
	await _tap("veh_blue")
	await _tap("veh_siren")
	way = Game.station.door_position - house.position
	way.y = 0.0
	way = way.normalized()
	var front_door: Dictionary = (house as House).outside_door()
	var out: = _stand_outside(house, front_door["lock"].global_position, 16.0)
	var outside: = player.global_position
	_park(pumper, outside + out * 22.0, atan2(out.x, out.z) + PI / 2)
	await _wait(0.4)
	pumper._board(player, "DoorCabLeft")
	await _wait(1.0)
	_check(list.is_done("board") and list.is_done("lights") and list.is_done("route"), "the second call's pumper, lights and arrival are ticked")
	pumper.leave(player)
	await _wait(0.6)
	await _reel(pumper)
	await _spray_at(fire)
	_check(list.is_done("hose") and list.is_done("spray"), "the second call's hose and water are ticked")
	await _put_out(fire)


	var person: Victim = people.victims[0] if not people.victims.is_empty() else null
	var ambulance: = AmbulanceService.current
	await _until( func() -> bool: return ambulance != null and ambulance.zone_position() != null, 40.0)
	var zone: Variant = ambulance.zone_position() if ambulance else null
	if person != null and person.state == "lying" and zone != null:
		player.teleport(person.position() + Vector3(1.5, 0.2, 0))
		_look_at(person.position())
		await _wait(0.4)
		await _hold("interact", float(Config.Victims.LiftTime) + 0.3)
		await _wait(0.3)
		if person.carrier != player:
			print("firstshift: E did not lift (%s); lifting" % person.state)
			people.lift(person, player)
			await _wait(0.3)
		player.teleport(zone + Vector3(0, 0.5, 0))
		await _wait(1.5)
	print("firstshift: the person is %s; card out %s" % [person.state if person else "-", Game.incident.get("victims_out", "-")])
	_check(list.is_done("carry"), "the list ticks the person handed over at the ambulance")
	await _snap("call2_carry")
	await _until( func() -> bool: return fire.incident.is_empty(), 20.0)
	await _home(pumper)
	await _until( func() -> bool: return not shift.active, 5.0)
	print("firstshift: ticked %s" % [shift.ticked])
	_check( not shift.active and PlayerData.first_shift_done, "the first shift is done, and kept as done")
	_check(list.showing(), "the finished list stays up a moment")
	await _snap("done")
	await _wait(float(Config.Onboarding.FirstShift["DoneTime"]) + 0.5)
	_check( not list.showing(), "and is put away")
	await _done()



func _reel(pumper: Vehicle) -> void :
	var hoses: = HoseService.current
	if hoses.line_of(player) != null:
		return
	player.teleport(_ground(pumper.global_transform * Vector3(9, 0, 12)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	var nearest: Variant = null
	for line: Dictionary in hoses.lines:
		if line["kind"] == "outlet" and line["rig"] != null and line["rig"]["vehicle"] == pumper and (nearest == null or line["source"].global_position.distance_to(player.global_position) < nearest["source"].global_position.distance_to(player.global_position)):
			nearest = line
	if nearest != null:
		hoses._on_outlet(nearest, player)
	await _wait(1.1)



func _spray_at(fire: FireService) -> void :
	if fire.incident.is_empty():
		return
	var target: = Vector3.INF
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"]:
			target = node["position"]
			break
	if target == Vector3.INF:
		return
	var away: = player.global_position - target
	away.y = 0.0
	var stand: = _ground(target + away.normalized() * 12.0) + Vector3(0, 0.3, 0)

	var from: = player.global_position
	var steps: = ceili(from.distance_to(stand) / 2.0)
	for step in steps:
		player.teleport(from.lerp(stand, float(step + 1) / steps))
		await get_tree().physics_frame
		await get_tree().physics_frame
	player.teleport(stand)
	await _wait(0.4)
	await _aim_view(target)
	await _hold("fire", 2.5)



func _put_out(fire: FireService) -> void :
	var waited: = 0.0
	while not fire.incident.is_empty() and int(fire.incident["count"]) > 0 and waited < 30.0:
		for node: Dictionary in fire.incident["group"]["nodes"]:
			node["heat"] = 0.0
			if node["burning"]:
				fire._extinguish(node, player)
		await _wait(0.5)
		waited += 0.5
	await _wait(1.0)



func _home(pumper: Vehicle) -> void :
	var hoses: = HoseService.current
	var line: Variant = hoses.line_of(player)
	if line != null:
		hoses.disconnect_line(line)
	if player.seat != null:
		pumper.leave(player)
		await _wait(0.5)
	var bay: Transform3D = pumper.spec["spawn"]
	pumper.global_transform = bay
	pumper.linear_velocity = Vector3.ZERO
	pumper.angular_velocity = Vector3.ZERO
	pumper.reset_physics_interpolation()
	player.teleport(_ground(Game.station.door_position + Vector3(0, 0, -6)) + Vector3(0, 0.3, 0))
	await _wait(1.5)






func _sample() -> Dictionary:
	var fire: = FireService.current
	var heat: = 0.0
	var burning: = 0
	if not fire.incident.is_empty():
		for node: Dictionary in fire.incident["group"]["nodes"]:
			heat += float(node["heat"])
			burning += 1 if node["burning"] else 0
	var people: = VictimService.current
	return {
		"now": Game.now(), 
		"heat": heat, 
		"burning": burning, 
		"condition": people.victims[0].condition if not people.victims.is_empty() else -1.0, 
		"air": AirService.current.pressure(player), 
		"call_time": CallService.current.call_time, 
		"hour": Sky3D.current.hour if Sky3D.current else 0.0, 
	}


func _scenario_pause() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	await _wait(1.0)
	var fire: = FireService.current
	var people: = VictimService.current
	var house: = _house("Family house")
	people.forced = 1
	people.forced_sick = 0.4
	Config.Fire["Traits"]["Force"] = "none"
	Config.Fire["Embers"]["Chance"] = 0.0
	CallService.current.run_call("fire", func() -> Variant:
		await fire.run_incident(house)
		return true
	)
	await _wait(1.0)
	var front_door: Dictionary = (house as House).outside_door()
	_stand_outside(house, front_door["lock"].global_position, 14.0)
	GearService.current._gear_up(player, null, true)
	AirService.current.take_set(player, "truck")
	await _wait(0.3)
	AirService.current._set_mask(player, true)
	await _wait(5.0)
	var before: = _sample()
	print("pause: before %s" % before)
	_check(float(before["burning"]) > 0 and float(before["condition"]) > 0.0 and float(before["air"]) > 0.0, "a fire burns, somebody is inside, the air is on")

	await _press_event("pause")
	await get_tree().process_frame
	_check(get_tree().paused and HudPause.current.open and Game.is_paused(), "the pause key opens the menu and pauses the game, alone")
	await get_tree().create_timer(20.0, true).timeout
	var during: = _sample()
	print("pause: after 20 s paused %s" % during)
	await _snap("paused")
	_check(absf(float(during["now"]) - float(before["now"])) < 1.0 and float(during["now"]) - float(before["now"]) < 20.0 - 18.0, "the game's clock stood still (%.2f s on)" % (float(during["now"]) - float(before["now"])))
	_check(during["burning"] == before["burning"] and absf(float(during["heat"]) - float(before["heat"])) < 0.01, "the fire stood still (%d flames, heat %.2f -> %.2f)" % [during["burning"], before["heat"], during["heat"]])
	_check(absf(float(during["condition"]) - float(before["condition"])) < 0.01, "the person inside did not get worse (%.1f -> %.1f)" % [before["condition"], during["condition"]])
	_check(absf(float(during["air"]) - float(before["air"])) < 0.01, "the air did not run down (%.1f -> %.1f bar)" % [before["air"], during["air"]])
	_check(absf(float(during["call_time"]) - float(before["call_time"])) < 0.6, "the close timer stood still (%.1f -> %.1f s)" % [before["call_time"], during["call_time"]])
	_check(absf(float(during["hour"]) - float(before["hour"])) < 0.01, "the day stood still")

	await _press_event("pause")
	await get_tree().process_frame
	_check( not get_tree().paused and not HudPause.current.open, "the pause key again shuts the menu and the game goes on")
	await _wait(4.0)
	var after: = _sample()
	print("pause: 4 s after %s" % after)
	var moved: = float(after["now"]) - float(during["now"])
	_check(moved > 3.5 and moved < 6.0, "the game's clock goes on (%.2f s in 4)" % moved)
	_check(float(after["condition"]) < float(during["condition"]), "the person inside gets worse again")
	_check(float(after["air"]) < float(during["air"]), "the air runs down again")
	_check(float(after["call_time"]) > float(during["call_time"]), "the close timer runs again")
	_check(after["burning"] != during["burning"] or absf(float(after["heat"]) - float(during["heat"])) > 0.001, "the fire goes on")
	await _done()





func _scenario_rankup() -> void :
	await _wait(1.0)
	_listen()
	var vitals: HudVitals = Hud.current.vitals
	var ranks: Array = Config.Gear.Ranks
	var first: = int(ranks[1]["saved"])
	var second: = int(ranks[2]["saved"])
	player.set_attr("Saved", first - 2)

	await _wait(float(Config.Onboarding.RankUp["Settle"]) + 0.5)
	var progress: = HudVitals.rank_progress(player)
	print("rankup: %d calls: %s; bar %.0f px" % [first - 2, progress, vitals._bar_fill.size.x])
	_check(int(progress["rank"]) == 0 and int(progress["next"]) == 1 and absf(float(progress["share"]) - float(first - 2) / first) < 0.01, "the progress to the next rank is read")
	_check(absf(vitals._bar_fill.size.x - HudVitals.BAR_WIDTH * float(progress["share"])) < 1.0 and vitals._bar_fill.color.is_equal_approx(Ui.RANK_COLORS[ranks[1]["sheet"]]), "the bar fills toward the next helmet, in its colour")
	_check( not HudRankUp.current.showing(), "no moment before a rank is earned")
	await _snap("bar")
	player.set_attr("Saved", first)
	await _wait(0.4)
	print("rankup: %d calls: showing %s (%s); heard %s" % [first, HudRankUp.current.showing(), HudRankUp.current.last_shown, _heard])
	_check(HudRankUp.current.showing() and HudRankUp.current.last_shown == ranks[1]["sheet"], "the rank-up moment comes for %s" % ranks[1]["sheet"])
	_check(_heard.has("ui_fanfare"), "with the fanfare")
	await _snap("moment")
	await _wait(float(Config.Onboarding.RankUp["Time"]) + 0.3)
	_check( not HudRankUp.current.showing(), "and is gone after %.0f s" % float(Config.Onboarding.RankUp["Time"]))
	player.set_attr("Saved", first + (second - first) / 2)
	await _wait(0.3)
	_check(absf(float(HudVitals.rank_progress(player)["share"]) - 0.5) < 0.11 and not HudRankUp.current.showing(), "half way to the next rank: the bar at half, no new moment")
	await _snap("bar_next")
	await _done()
