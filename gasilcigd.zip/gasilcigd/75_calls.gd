extends RefCounted






static func start(main: Node) -> void :
	var calls: = CallService.current
	var fires: = FireService.current
	if calls == null or fires == null:
		return
	var graph: = NavGraph.current
	var layout: Dictionary = graph.layout if graph != null and not graph.layout.is_empty() else Rbx.module("TownLayout")
	var station: Vector3 = Game.station.door_position if Game.station else Game.spawn_point()

	var cordon: = Cordon.new()
	cordon.name = "Cordon"
	main.add_child(cordon)
	cordon.start()

	if graph != null:
		var bystanders: = Bystanders.new()
		bystanders.name = "Bystanders"
		main.add_child(bystanders)
		bystanders.start(graph, layout)

	var crash: = CarCrash.new()
	crash.name = "CarCrash"
	main.add_child(crash)
	crash.start(layout, station)
	var tree: = FallenTree.new()
	tree.name = "FallenTree"
	main.add_child(tree)
	tree.start(layout, station)
	var flood: = FloodedCellar.new()
	flood.name = "FloodedCellar"
	main.add_child(flood)
	flood.start(layout, fires.buildings)
	var medical: = LockedIn.new()
	medical.name = "LockedIn"
	main.add_child(medical)
	medical.start(fires.buildings)
	var rescue: = HeightRescue.new()
	rescue.name = "HeightRescue"
	main.add_child(rescue)
	rescue.start(layout, fires.buildings)
	for call_kind: Node in [tree, crash, flood, medical, rescue]:
		calls.kinds.append(call_kind)



	Game.incident_changed.connect( func() -> void :
		var incident: = Game.incident
		if incident.has("total") and incident.get("kind", "fire") != "fire":
			var done: = int(incident.get("done", 0))
			var total: = int(incident["total"])
			incident["progress_text"] = "%d%%" % int(done * 100.0 / maxi(total, 1)) if total > 99 else "%d/%d" % [done, total]
	)

	var debug: = CallsDebug.new()
	debug.name = "CallsDebug"
	main.add_child(debug)
