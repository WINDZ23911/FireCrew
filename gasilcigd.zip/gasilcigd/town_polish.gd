class_name TownPolish
extends RefCounted













static func apply(store: PartStore) -> void :
	var started: = Time.get_ticks_msec()
	var kit: = PolishKit.new(store)
	var before: = store.count
	var said: Array[String] = []
	var names: = Array(ResourceLoader.list_directory("res://scripts/world/polish/passes"))
	names.sort()
	for file: String in names:
		if not file.ends_with(".gd") or Edition.skips(file):
			continue
		var script: GDScript = load("res://scripts/world/polish/passes/" + file)
		if script == null or not script.can_instantiate():
			push_error("could not run polish pass " + file)
			continue
		var began: = Time.get_ticks_usec()
		var what: String = script.apply(kit)
		if OS.get_cmdline_user_args().has("--polish-times"):
			print("  polish %s: %d ms" % [file, (Time.get_ticks_usec() - began) / 1000])
		if not what.is_empty():
			said.append(what)
	print("town polished in %d ms: %d parts added; %s" % [Time.get_ticks_msec() - started, store.count - before, ", ".join(said)])
