extends ProofDebug












var _reports: Array = []


func _ready() -> void :
	super._ready()
	if CallService.current != null:
		CallService.current.debriefed.connect( func(report: Dictionary) -> void : _reports.append(report))


static func _named(report: Dictionary) -> Dictionary:
	var found: = {}
	for entry: Array in report.get("checks", []):
		found[entry[0]] = entry[1]
	return found



func _use(id: String, by: Player = null) -> bool:
	var who: = by if by != null else player
	var prompt: Prompt = Prompt.by_id.get(id)
	if prompt == null or not is_instance_valid(prompt):
		print("othercalls: no prompt %s" % id)
		return false
	who.teleport(prompt.global_position + Vector3(1.2, -1.0, 1.2))
	await _wait(0.3)
	if not prompt.enabled or not prompt.shown_to(who):
		print("othercalls: prompt %s is not on offer (enabled %s)" % [id, prompt.enabled])
		return false
	prompt.triggered.emit(who)
	await _wait(0.3)
	return true


func _until(test: Callable, limit: float) -> bool:
	var waited: = 0.0
	while not test.call() and waited < limit:
		await _wait(0.25)
		waited += 0.25
	return test.call()


func _next_text() -> String:
	return Text.say(Game.incident.get("scene_next", Game.incident.get("next", "")), "en")


func _report_after(had: int, limit: float) -> Dictionary:
	await _until( func() -> bool: return _reports.size() > had, limit)
	return _reports[-1] if _reports.size() > had else {}





func _start_flood() -> Dictionary:
	var flood: = FloodedCellar.current
	CallService.current.run_call("flood", flood.run)
	await _until( func() -> bool: return not flood.source.is_empty(), 10.0)
	return flood._hatch


func _scenario_ocflood() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]
	var flood: = FloodedCellar.current
	var hatch: = await _start_flood()
	if not _check( not hatch.is_empty(), "a flooded cellar call starts"):
		await _done()
		return
	var inlet: Node3D = hatch["inlet"]
	var serial: int = hatch["serial"]
	var out: = - inlet.global_basis.z
	player.teleport(_ground(inlet.global_position + out * 8.0) + Vector3(0, 0.5, 0))
	await _wait(1.5)
	var drain: Vector3 = hatch["drain_at"]
	print("ocflood: hatch at %s, drain at %s (%.0f studs), %s L; card: %s" % [inlet.global_position, drain, drain.distance_to(inlet.global_position), Game.incident.get("total"), _next_text()])
	_check(hatch["power"] and _next_text() == Text.say(Text.m("calls.flood.next.power"), "en"), "the card asks for the power off first")
	_check(drain.distance_to(inlet.global_position) > 8.0, "a storm drain at the kerb, away from the hatch")

	CallGear.current._on_line(player, "Portable pump")
	_check(CallGear.carried(player) == "Portable pump", "a portable pump is taken from the pumper's lockers")

	var health: = player.health
	await _use("flood.%d.pump" % serial)
	print("ocflood: the pump into live water: health %.0f -> %.0f, pumps %d, carried %s" % [health, player.health, hatch["pumps"].size(), CallGear.carried(player)])
	_check(player.health < health and hatch["pumps"].is_empty() and CallGear.carried(player) == "Portable pump", "into live water is a shock, and the pump is not lowered")
	await _use("flood.%d.power" % serial)
	_check( not hatch["power"], "the isolator switches the cellar's power off")
	await _use("flood.%d.pump" % serial)
	_check(hatch["pumps"].size() == 1 and player.get_attr("Discharge") == serial, "the pump is lowered, and its hose's end is in hand")
	var left_before: = float(hatch["litres"])
	await _wait(2.0)
	_check(is_equal_approx(float(hatch["litres"]), left_before), "it does not pump until its hose is laid")
	_check(_next_text() == Text.say(Text.m("calls.flood.next.drain"), "en"), "the card says to lay the hose to the drain")
	_view(inlet.global_position + out * 16.0 + Vector3(6, 10, 0), (inlet.global_position + drain) / 2.0)
	await _snap("carrying")
	await _use("flood.%d.drain" % serial)
	_check(hatch["pumps"][0]["drain"] and player.get_attr("Discharge") == null, "the hose is laid in the drain")
	var at_start: = float(hatch["litres"])
	await _wait(4.0)
	var one_pump: = (at_start - float(hatch["litres"])) / 4.0

	CallGear.current._on_line(player, "Portable pump")
	await _use("flood.%d.pump" % serial)
	await _use("flood.%d.drain" % serial)
	at_start = float(hatch["litres"])
	await _wait(4.0)
	var two_pumps: = (at_start - float(hatch["litres"])) / 4.0
	print("ocflood: one pump %.0f L/s, two %.0f L/s (PumpFlow %s)" % [one_pump, two_pumps, Config.Incidents.Flood.PumpFlow])
	_check(one_pump > 25.0 and two_pumps > one_pump * 1.7, "a second pump about doubles the rate")
	CallGear.current._on_line(player, "Portable pump")
	_check(CallGear.carried(player).is_empty(), "the pumper carries two pumps")
	_view(inlet.global_position + out * 14.0 + Vector3(-8, 9, 4), (inlet.global_position + drain) / 2.0)
	await _snap("pumping")

	var had: = _reports.size()
	Config.Incidents.Flood["PumpFlow"] = 800.0
	var report: = await _report_after(had, 40.0)
	Config.Incidents.Flood["PumpFlow"] = 40.0
	var checks: = _named(report)
	print("ocflood: report %s, checks %s" % [report.get("grade"), checks])
	_check(checks.get("power") == false, "the report marks the shock: power not off first")
	_check(checks.get("drain") == true and checks.get("hose") == true and checks.get("valve") == true, "pumped into the drain, soon after arriving")
	_check(CallGear.current.kits["Portable pump"]["pool"] == 2, "the pumps are back on the truck after the call")


	Alarm.forced_complications = ["inflow", "oil"]
	hatch = await _start_flood()
	serial = hatch["serial"]
	inlet = hatch["inlet"]
	player.teleport(_ground(inlet.global_position - inlet.global_basis.z * 8.0) + Vector3(0, 0.5, 0))
	await _wait(1.5)
	await _use("flood.%d.power" % serial)
	await _wait(0.5)
	print("ocflood: oil %s, card: %s" % [hatch["oil"], _next_text()])
	_check(hatch["oil"] and _next_text() == Text.say(Text.m("calls.flood.next.oil"), "en"), "oil on the water: the card asks for a boom first")
	var total: = float(Game.incident.get("total", 0))
	await _wait(3.0)
	print("ocflood: with nothing pumping, %s L left of %d" % [hatch["litres"], int(total)])
	_check(float(hatch["litres"]) > total, "water still coming in raises the level")
	await _use("flood.%d.boom" % serial)
	_check(hatch["boomed"], "the boom goes on the oil")
	_view(inlet.global_position - inlet.global_basis.z * 7.0 + Vector3(0, 6, 0), inlet.global_position)
	await _snap("boom")
	await _end_call()
	Alarm.forced_complications = []
	Alarm.forced = 0
	await _done()





func _scenario_ocmedical() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Alarm.forced_complications = ["upstairs", "heavy"]
	var medical: = LockedIn.current
	CallService.current.run_call("medical", medical.run)
	await _until( func() -> bool: return not medical.scene.is_empty(), 10.0)
	var scene: Dictionary = medical.scene
	if not _check( not scene.is_empty(), "a medical call starts"):
		await _done()
		return
	var house: = medical.house
	var people: = VictimService.current
	var patient: Victim = people.victims[0]
	var serial: int = scene["serial"]
	print("ocmedical: %s, urgency %s, the patient in %s (upstairs %s), neighbour has a key: %s" % [house.name, scene["urgency"], patient.room, LockedIn._upstairs(house, patient.room), scene["has_key"]])
	var level_word: = Text.say(Text.m("calls.medical.urgency." + scene["urgency"]), "en")
	player.teleport(_ground((scene["neighbour"] as Transform3D).origin + Vector3(4, 0, 4)) + Vector3(0, 0.5, 0))
	await _wait(1.0)
	print("ocmedical: card: %s" % _next_text())
	_check(_next_text().begins_with(level_word), "the card says how urgent it is (%s)" % level_word)
	_check(Text.say(Text.m("calls.medical.next.ask"), "en") in _next_text(), "the card asks for the neighbour's key first")
	_check( not patient.prompt.enabled, "nobody can lift the patient before first aid")

	scene["has_key"] = true
	var front: Dictionary = house.outside_door()
	await _use("medical.%d.neighbour" % serial)
	print("ocmedical: asked the neighbour: front door locked %s" % front["locked"])
	_check(scene["asked"] and not front["locked"], "the neighbour's key unlocks the front door")
	_view((scene["neighbour"] as Transform3D).origin + Vector3(8, 6, 8), (scene["neighbour"] as Transform3D).origin + Vector3(0, 3, 0))
	await _snap("neighbour")

	var condition: = patient.condition
	await _use("medical.%d.aid" % serial)
	_check( not scene["aided"], "first aid wants the kit")
	_locker_line(Vehicle.named("Fire Truck"), "First aid kit").chosen.emit(player)
	await _use("medical.%d.aid" % serial)
	print("ocmedical: first aid: aided %s, condition %.0f -> %.0f, lift on offer %s" % [scene["aided"], condition, patient.condition, patient.prompt.enabled])
	_check(scene["aided"] and patient.condition > condition and patient.prompt.enabled, "first aid steadies them, and they can be lifted")

	player.teleport(patient.position() + Vector3(1.5, 0.5, 0))
	await _wait(0.3)
	people.lift(patient, player)
	await _wait(0.8)
	var upstairs: = LockedIn._upstairs(house, patient.room)
	var inside: = house.room_at(player.root_position()) != null
	print("ocmedical: carrying %s, inside %s, upstairs %s, pace %.0f (Dragging %s)" % [patient.state, inside, upstairs, player.walk_speed, player.get_attr("Dragging")])
	if (upstairs or Alarm.complicated("medical", "heavy")) and inside:
		_check(player.walk_speed <= float(Config.Incidents.Medical.StairPace) + 0.01, "alone with a heavy patient, or upstairs, the carry is slow")

		var service: = CrewService.current
		if service != null:
			var entry: = service.roster._member("", "rescue", 0, 0)
			var mind: = service._make(entry, service.members.size(), player)
			mind.body.frozen = true
			for step in 5:
				mind.body.teleport(player.global_position + Vector3(1.5, 0, 0))
				await _wait(0.25)
			print("ocmedical: a second firefighter beside (%.1f studs, one of the players %s): pace %.0f" % [mind.body.root_position().distance_to(player.root_position()), mind.body in Game.players, player.walk_speed])
			_check(player.walk_speed > float(Config.Incidents.Medical.StairPace) + 0.01, "with a second firefighter beside it is quick")
	else:
		_fail("the patient was not upstairs (%s) or the carrier not inside" % patient.room)
	var zone: Variant = AmbulanceService.current.zone_position()
	await _until( func() -> bool: return AmbulanceService.current.zone_position() != null, 30.0)
	zone = AmbulanceService.current.zone_position()
	var had: = _reports.size()
	if zone != null:
		player.teleport(zone + Vector3(0, 0.5, 0))
	var report: = await _report_after(had, 20.0)
	var checks: = _named(report)
	print("ocmedical: report %s, checks %s, Dragging after %s" % [report.get("grade"), checks, player.get_attr("Dragging")])
	_check(checks.get("entry") == true and checks.get("aid") == true, "asked for a key and gave first aid at once: both on the report")
	_check(player.get_attr("Dragging") == null, "the carrier's pace is their own again after the call")
	Alarm.forced_complications = []
	Alarm.forced = 0
	await _done()





func _scenario_ocrescue() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]
	Config.Incidents.Rescue["Who"] = "roof"
	var rescue: = HeightRescue.current
	var found: = false
	for attempt in 6:
		CallService.current.run_call("rescue", rescue.run)
		await _until( func() -> bool: return not rescue.stranded.is_empty(), 10.0)
		if rescue.stranded["params"]["board"] != null:
			found = true
			break

		rescue.pretend_near = true
		await _until( func() -> bool: return rescue.stranded.get("aboard", false), 5.0)
		rescue.pretend_stowed = true
		await _until( func() -> bool: return Game.incident.is_empty(), 10.0)
		rescue.pretend_near = false
		rescue.pretend_stowed = false
		await _wait(1.0)
	var held: Dictionary = rescue.stranded
	if not _check( not held.is_empty(), "a rescue call starts"):
		await _done()
		return
	var root: Node3D = held["root"]
	_check( not found or held["model"].get_node_or_null("RoofLadder") != null, "on a sloping roof they stand on a roof ladder, not a crate")
	var ladder_view: = root.global_position + ( - root.global_basis.z) * 14.0 + Vector3(0, 6, 0)
	_view(ladder_view, root.global_position - Vector3(0, 1.5, 0))
	await _snap("roofladder")

	await _wait(2.0)
	_check(is_equal_approx(float(held["grip"]), 100.0), "their grip holds until the crew arrives")
	var below: = CallKit.ground_at(root.global_position + Vector3(0, -2, 0) + ( - root.global_basis.z) * 25.0)
	player.teleport(below + Vector3(0, 0.5, 0))
	await _wait(4.0)
	var after_far: = float(held["grip"])
	print("ocrescue: grip after 4 s of the crew below: %.1f; card: %s" % [after_far, _next_text()])
	_check(after_far < 100.0, "with the crew there the grip runs down")
	_check(Text.say(Text.f("calls.rescue.grip", [ceili(after_far)]), "en") in _next_text(), "the card shows the grip")

	player.teleport(root.global_position + Vector3(1.5, -1.0, 0))
	var near_from: = float(held["grip"])
	await _wait(4.0)
	var near_drop: = near_from - float(held["grip"])
	print("ocrescue: 4 s with a firefighter by them: %.2f lost (%.2f far)" % [near_drop, 100.0 - after_far])
	_check(near_drop < (100.0 - after_far) * 0.8, "a firefighter close by slows it")

	rescue.pretend_near = true
	await _until( func() -> bool: return held.get("aboard", false), 5.0)
	rescue.pretend_near = false
	await _wait(0.6)
	var harness: Prompt = held["harness_prompt"]
	_check(harness.enabled and _next_text() == Text.say(Text.m("calls.rescue.next.harness"), "en"), "in the basket the card asks for the harness")
	harness.triggered.emit(player)
	await _wait(0.5)
	_check(held.get("harness", false), "the harness is clipped on")
	var had: = _reports.size()
	rescue.pretend_stowed = true
	var report: = await _report_after(had, 20.0)
	rescue.pretend_stowed = false
	print("ocrescue: report %s, checks %s" % [report.get("grade"), _named(report)])
	_check(_named(report).get("harness") == true, "the report has the harness on before the descent")

	Config.Incidents.Rescue["GripTimes"] = [6, 6]
	had = _reports.size()
	CallService.current.run_call("rescue", rescue.run)
	await _until( func() -> bool: return not rescue.stranded.is_empty(), 10.0)
	held = rescue.stranded
	player.teleport(CallKit.ground_at(held["root"].global_position + Vector3(0, -2, 0) + ( - held["root"].global_basis.z) * 25.0) + Vector3(0, 0.5, 0))
	report = await _report_after(had, 30.0)
	Config.Incidents.Rescue["GripTimes"] = [200, 320]
	print("ocrescue: left alone: report failed %s, grade %s" % [report.get("failed"), report.get("grade")])
	_check(report.get("failed", false) == true, "at nothing they fall, and the call has failed")
	Alarm.forced_complications = []
	Alarm.forced = 0
	await _done()





func _scenario_ocescalate() -> void :
	await _wait(1.0)
	Config.Alarm.Escalations["After"] = [1, 1]
	Alarm.forced = 1

	var table: Dictionary = Config.Alarm.Complications
	for kind_name: String in ["flood", "medical", "rescue", "hazmat", "accident"]:
		_check((table[kind_name] as Array).size() == 3 and (table[kind_name][0] as Array).is_empty() and not (table[kind_name][2] as Array).is_empty(), "%s: nothing at I, a named complication at III" % kind_name)
	Alarm.level = 3
	_check(Alarm.complicated("flood", "oil") and Alarm.complicated("medical", "heavy") and Alarm.complicated("rescue", "panic"), "at III: oil on the flood, a heavy patient, someone who panics")
	Alarm.level = 1
	_check(Alarm.complications("flood").is_empty(), "at I a flood is just water")
	Alarm.forced_complications = ["none"]


	Alarm.forced_escalation = "rising"
	var flood: = FloodedCellar.current
	CallService.current.run_call("flood", flood.run)
	await _until( func() -> bool: return not flood.source.is_empty(), 10.0)
	var total: = int(Game.incident.get("total", 0))
	var inlet: Node3D = flood._hatch["inlet"]
	player.teleport(_ground(inlet.global_position - inlet.global_basis.z * 20.0) + Vector3(0, 0.5, 0))
	var risen: = await _until( func() -> bool: return int(Game.incident.get("total", 0)) > total, 8.0)
	print("ocescalate: flood: %d L -> %s" % [total, Game.incident.get("total")])
	_check(Alarm.escalation == "rising" and risen, "flood: the water rises to the fuse board (more of it)")
	await _end_call()


	Alarm.forced_escalation = "worse"
	var medical: = LockedIn.current
	CallService.current.run_call("medical", medical.run)
	await _until( func() -> bool: return not medical.scene.is_empty(), 10.0)
	var patient: Victim = VictimService.current.victims[0]
	var sick: = patient.sick
	player.teleport(_ground((medical.scene["neighbour"] as Transform3D).origin + Vector3(3, 0, 3)) + Vector3(0, 0.5, 0))
	var worse: = await _until( func() -> bool: return patient.sick > sick * 1.5, 8.0)
	_check(worse, "medical: the patient gets worse, faster")
	await _end_call()


	Alarm.forced_escalation = "gutter"
	var rescue: = HeightRescue.current
	CallService.current.run_call("rescue", rescue.run)
	await _until( func() -> bool: return not rescue.stranded.is_empty(), 10.0)
	var held: Dictionary = rescue.stranded
	player.teleport(CallKit.ground_at(held["root"].global_position + Vector3(0, -2, 0) + ( - held["root"].global_basis.z) * 25.0) + Vector3(0, 0.5, 0))
	var gave: = await _until( func() -> bool: return float(held["grip"]) < 75.0, 8.0)
	print("ocescalate: rescue: grip %.0f" % float(held["grip"]))
	_check(gave, "rescue: the gutter gives, and the grip drops")
	await _end_call()


	var leak: = HazmatLeak.current
	if leak != null:
		Alarm.forced_escalation = "wind"
		leak.forced_source = "tanker"
		CallService.current.run_call("hazmat", leak.run)
		await _until( func() -> bool: return not leak._leak.is_empty(), 10.0)
		var wind: Vector3 = leak._leak["wind"]
		player.teleport(_ground((leak._leak["leak"] as Vector3) - wind * 30.0) + Vector3(0, 0.5, 0))
		var turned: = await _until( func() -> bool: return (leak._leak.get("wind", wind) as Vector3).distance_to(wind) > 0.5, 8.0)
		print("ocescalate: hazmat: wind %s -> %s" % [wind, leak._leak.get("wind")])
		_check(turned, "hazmat: the wind turns")
		await _end_call()


	var accident: = WorkAccident.current
	if accident != null:
		Alarm.forced_escalation = "second"
		CallService.current.run_call("accident", accident.run)
		await _until( func() -> bool: return not accident._call.is_empty(), 10.0)
		var count: = VictimService.current.victims.size()
		player.teleport(_ground((accident._call["foreman"] as Transform3D).origin) + Vector3(0, 0.5, 0))
		var more: = await _until( func() -> bool: return VictimService.current.victims.size() > count, 8.0)
		print("ocescalate: accident: %d -> %d people" % [count, VictimService.current.victims.size()])
		_check(more, "accident: a second worker collapses")
		await _end_call()
	Alarm.forced_escalation = ""
	Alarm.forced_complications = []
	Alarm.forced = 0
	await _done()



func _end_call() -> void :
	var before: Variant = Config.Incidents.get("CloseAfter")
	Config.Incidents["CloseAfter"] = 0.5
	await _until( func() -> bool: return Game.incident.is_empty() and not CallService.current.running, 20.0)
	Config.Incidents["CloseAfter"] = before
	await _wait(1.0)





func _scenario_oclook() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]

	var hatch: = await _start_flood()
	if not hatch.is_empty():
		var serial: int = hatch["serial"]
		var inlet: Node3D = hatch["inlet"]
		var out: = - inlet.global_basis.z
		player.teleport(_ground(inlet.global_position + out * 8.0) + Vector3(0, 0.5, 0))
		await _wait(1.0)
		_view(inlet.global_position + out * 12.0 + out.cross(Vector3.UP) * 6.0 + Vector3(0, 7, 0), inlet.global_position)
		await _wait(0.5)
		await _snap("flood_live")
		await _use("flood.%d.power" % serial)
		CallGear.current._on_line(player, "Portable pump")
		await _use("flood.%d.pump" % serial)
		await _use("flood.%d.drain" % serial)
		player.teleport(_ground(inlet.global_position + out * 6.0 - out.cross(Vector3.UP) * 6.0) + Vector3(0, 0.5, 0))
		var drain: Vector3 = hatch["drain_at"]
		_view(inlet.global_position + out * 6.0 + out.cross(Vector3.UP) * 14.0 + Vector3(0, 10, 0), (inlet.global_position + drain) / 2.0)
		await _wait(0.6)
		await _snap("flood_pump")
		_check(true, "pictures of the cellar")
		await _end_call()

	var leak: = HazmatLeak.current
	if leak != null:
		leak.forced_source = "tanker"
		CallService.current.run_call("hazmat", leak.run)
		await _until( func() -> bool: return not leak._leak.is_empty(), 10.0)
		leak._leak["cloud"] = 0.9
		leak._leak["spill"] = 0.8
		var at: Vector3 = leak._leak["leak"]
		player.teleport(_ground(at - (leak._leak["wind"] as Vector3) * 40.0) + Vector3(0, 0.5, 0))
		await _wait(3.0)
		var side: = (leak._leak["wind"] as Vector3).rotated(Vector3.UP, PI / 2.0)
		_view(at + side * 45.0 + Vector3(0, 30, 0), at + (leak._leak["wind"] as Vector3) * 10.0)
		await _wait(0.6)
		await _snap("hazmat_plume")
		_check(leak._visual.has("plume"), "pictures of the leak")
		await _end_call()
	Alarm.forced_complications = []
	Alarm.forced = 0
	await _done()
