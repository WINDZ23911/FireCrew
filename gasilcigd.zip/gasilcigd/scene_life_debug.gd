class_name SceneLifeDebug
extends Node





var _prefix: = ""
var _camera: Camera3D


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--scene-life="):
			_prefix = arg.substr(13)
	if _prefix != "":
		_run.call_deferred()


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds).timeout


func _snap(what: String) -> void :
	for layer in get_tree().root.find_children("*", "CanvasLayer", true, false):
		(layer as CanvasLayer).visible = false
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_prefix, what])
	print("scene life: saved ", what)


func _look(from: Vector3, at: Vector3) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 3000.0
		add_child(_camera)
	_camera.look_at_from_position(from, at)
	_camera.make_current()


func _run() -> void :
	await _wait(0.6)
	var wanted: = "House"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
	var building: Building = null
	var best: = INF
	for each in FireService.current.buildings:
		if each.name.begins_with(wanted) and each.position.distance_to(Vector3(40, 0, -60)) < best:
			best = each.position.distance_to(Vector3(40, 0, -60))
			building = each
	CallService.current.hold = true
	FireService.current.run_incident(building)
	await _wait(0.5)
	var at: Vector3 = Game.incident.get("pos", building.position)

	var truck: = Vehicle.named("Fire Truck")
	var out: = (at - Vector3(40, 0, -60)) * Vector3(1, 0, 1)
	out = - out.normalized() if out.length() > 1.0 else Vector3(0, 0, 1)
	truck.global_transform = Transform3D(Basis.looking_at(out.cross(Vector3.UP)), at + out * 40.0 + Vector3(0, 3, 0))
	truck.linear_velocity = Vector3.ZERO
	Game.local_player.teleport(at + out * 30.0 + Vector3(0, 2, 0))

	ScenePolice.delay = 1.0
	print("scene life: fire at ", building.name, " ", at)
	await _wait(3.0)
	var police: = ScenePolice.current
	if police.visit.is_empty():
		print("scene life: no police came")
	else:
		var park: Transform3D = police.visit["park"]
		print("scene life: police to park at ", park.origin, ", driving ", ScenePolice._duration(police.visit["way_in"]), " s")
		await _wait(ScenePolice._duration(police.visit["way_in"]) * 0.6)
		var pose: Array = police.pose_now()
		var car: Transform3D = pose[0]
		_look(car.origin + Vector3(14, 9, 14), car.origin + Vector3(0, 2, 0))
		await _wait(0.1)
		await _snap("coming")
		await _wait(ScenePolice._duration(police.visit["way_in"]) * 0.4 + 3.5)
		var side: = park.basis.x
		_look(park.origin + side * 16.0 - park.basis.z * 10.0 + Vector3(0, 7, 0), park.origin + Vector3(0, 2, 0))
		await _wait(0.1)
		await _snap("parked")
		_look(park.origin - side * 16.0 + park.basis.z * 8.0 + Vector3(0, 6, 0), park.origin + Vector3(0, 2, 0))
		await _wait(1.5)
		await _snap("officer")

	await _wait(20.0)
	SceneCrowd.big_fire = 1
	await _wait(1.5)
	var shooter: Node3D = get_tree().root.find_child("Photographer", true, false)
	if shooter != null:
		var spot: = shooter.global_position
		_look(spot - shooter.global_basis.z * 9.0 + shooter.global_basis.x * 5.0 + Vector3(0, 5, 0), spot + Vector3(0, 3, 0))
		for attempt in 120:
			await _wait(0.06)
			var flash: OmniLight3D = shooter.find_children("*", "OmniLight3D", true, false)[0] if not shooter.find_children("*", "OmniLight3D", true, false).is_empty() else null
			if flash != null and flash.light_energy > 0.0:
				break
		await _snap("press")
	else:
		print("scene life: no photographer")

	var folk: = Townsfolk.current
	var sum: = Vector3.ZERO
	var count: = 0
	for id: int in folk.bodies:
		var body: Townsfolk.Body = folk.bodies[id]
		if body.built and body.person.shown_state == "watch":
			sum += body.head_at
			count += 1
	print("scene life: %d watching" % count)
	if count > 0:
		var middle: = sum / count
		var toward: = (middle - at) * Vector3(1, 0, 1)
		_look(middle - toward.normalized() * 22.0 + Vector3(0, 8, 0), middle)
		await _wait(0.3)
		await _snap("crowd")

		var close: Townsfolk.Body = null
		for attempt in 40:
			for id: int in folk.bodies:
				var body: Townsfolk.Body = folk.bodies[id]
				if body.built and body.person.shown_state == "watch" and (close == null or (posmod(body.person.seed, 4) == 1 and body.gesture > 1.5)):
					close = body
			if close != null and close.gesture > 1.5:
				break
			await _wait(0.25)
		if close != null:
			var ahead: = Basis(Vector3.UP, float(close.yaw)) * Vector3(0, 0, -1)
			_look(close.head_at + ahead * 7.0 + Vector3(2, 1.5, 0), close.head_at - Vector3(0, 1.0, 0))
			await _wait(0.15)
			await _snap("watcher")
	Game.quit()
