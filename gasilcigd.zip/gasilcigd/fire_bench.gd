class_name FireBench
extends Node












const FRAMES: = 240

var _wanted: = "House"
var _grow: = 10.0
var _flames: = 16
var _shots: = ""
var _camera: Camera3D


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		var bits: = arg.split("=", true, 1)
		if bits[0] == "--firebench" and bits.size() > 1:
			_wanted = bits[1]
		elif bits[0] == "--firebench-grow":
			_grow = float(bits[1])
		elif bits[0] == "--firebench-flames":
			_flames = int(bits[1])
		elif bits[0] == "--firebench-shots":
			_shots = bits[1]
	_run.call_deferred()


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false, false, true).timeout


func _building() -> Building:
	for building in FireService.current.buildings:
		if building.name.begins_with(_wanted):
			return building
	return FireService.current.buildings[0]


func _look(from: Vector3, at: Vector3) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.fov = 70.0
		_camera.far = 3000.0
		get_tree().root.add_child(_camera)
	_camera.look_at_from_position(from, at)
	_camera.make_current()



static func particles() -> int:
	var count: = 0
	for flame in Flame.all:
		for child in flame.get_children():
			if child is GPUParticles3D and (child as GPUParticles3D).emitting:
				count += int((child as GPUParticles3D).amount * (child as GPUParticles3D).amount_ratio)
	return count


func _snap_now(tag: String) -> void :
	if _shots.is_empty():
		return
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])


func _measure(tag: String) -> void :
	await _wait(1.0)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	var viewport: = get_viewport().get_viewport_rid()
	RenderingServer.viewport_set_measure_render_time(viewport, true)
	var began: = Time.get_ticks_usec()
	var cpu: = 0.0
	var gpu: = 0.0
	var worst: = 0.0
	var last: = began
	for frame in FRAMES:
		await get_tree().process_frame
		var now: = Time.get_ticks_usec()
		if frame >= FRAMES / 2:
			cpu += RenderingServer.viewport_get_measured_render_time_cpu(viewport)
			gpu += RenderingServer.viewport_get_measured_render_time_gpu(viewport)
			worst = maxf(worst, (now - last) / 1000.0)
		last = now
	var seconds: = (Time.get_ticks_usec() - began) / 1000000.0
	var counted: = FRAMES - FRAMES / 2
	print("firebench %s: %.1f fps, worst frame %.1f ms; render cpu %.2f ms, gpu %.2f ms; draw calls %d; flames %d, particles %d, lights %d" % [
		tag, FRAMES / seconds, worst, cpu / counted, gpu / counted, 
		RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME), 
		Flame.all.size(), particles(), get_tree().root.find_children("*", "OmniLight3D", true, false).size(), 
	])
	if not _shots.is_empty():
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])



func _street_side(middle: Vector3) -> Vector3:
	var out: = Vector3.BACK
	var best: = INF
	for step in 12:
		var direction: = Vector3(sin(TAU * step / 12.0), 0, cos(TAU * step / 12.0))
		var from: = middle + direction * 50.0 + Vector3(0, 10, 0)
		var hit: = Game.world.raycast(from, middle + Vector3(0, 3, 0), World.LAYER_SOLID)
		var near: = 0.0 if hit.is_empty() else (hit["position"] as Vector3).distance_to(middle)
		if near < best:
			best = near
			out = direction
	return out


func _run() -> void :
	await _wait(1.5)
	if OS.get_cmdline_user_args().has("--firebench-water"):
		await _water()
		get_tree().quit()
		return
	if OS.get_cmdline_user_args().has("--firebench-solo"):
		await _solo()
		get_tree().quit()
		return
	var building: = _building()
	CallService.current.hold = true
	seed(7)
	var fire: = FireService.current
	var middle: = building.position
	var out: = _street_side(middle)

	var front: = middle + out * 60.0
	var nodes: Array = (fire._group_of(building)["nodes"] as Array).filter( func(node: Dictionary) -> bool: return float(node.get("fuel", 1.0)) > 0.0)
	nodes.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return (a["position"] as Vector3).distance_to(front) < (b["position"] as Vector3).distance_to(front))
	nodes = nodes.slice(0, _flames)
	var centre: = Vector3.ZERO
	for node: Dictionary in nodes:
		centre += (node["position"] as Vector3) / nodes.size()
	var street: = centre + out * 34.0 + Vector3(0, 8, 0)
	middle = centre
	Game.local_player.teleport(centre + out * 60.0 + Vector3(0, 1, 0))
	_look(street, middle + Vector3(0, 2, 0))
	await _measure("base")
	print("firebench: fire at %s, growing %.0f s" % [building.name, _grow])
	Alarm.forced = 3
	Alarm.begin()
	fire.run_incident(building)
	await _wait(0.5)
	for node: Dictionary in nodes:
		if not node["burning"]:
			fire._ignite(node, 0.8)
	Engine.time_scale = 4.0
	await _wait(_grow)
	Engine.time_scale = 1.0
	_look(street, middle + Vector3(0, 2, 0))
	await _measure("street")

	var flame_at: = middle
	for flame in Flame.all:
		if flame.global_position.distance_to(street) < flame_at.distance_to(street):
			flame_at = flame.global_position
	var toward: = (street - flame_at) * Vector3(1, 0, 1)
	toward = toward.normalized()
	var eye: = flame_at + toward * 10.0 + Vector3(0, 2.5, 0)
	var blocked: = Game.world.raycast(flame_at + Vector3(0, 2.5, 0), eye, World.LAYER_SOLID)
	if not blocked.is_empty():
		eye = (blocked["position"] as Vector3) - toward * 0.6
	_look(eye, flame_at + Vector3(0, 1.5, 0))
	await _measure("close")
	await _warm_check(fire, out)
	if Sky3D.current != null and Sky3D.current.has_method("set_hour"):
		Sky3D.current.set_hour(22.0)
		_look(street, middle + Vector3(0, 2, 0))
		await _measure("night")
	get_tree().quit()



func _warm_check(fire: FireService, out: Vector3) -> void :
	var waited: = 0.0
	while fire._warm_shown.is_empty() and waited < 30.0 and not fire.incident.is_empty():
		await _wait(0.5)
		waited += 0.5
	if fire._warm_shown.is_empty():
		print("firebench warm: nothing heating up")
		return
	var at: int = fire._warm_shown.keys()[0]
	var node: Dictionary = fire.incident["group"]["nodes"][at]
	var spot: Vector3 = node["position"]
	print("firebench warm: %d things heating up; one at %s, heat %.2f" % [fire._warm_shown.size(), spot, node["heat"]])
	_look(spot + out * 9.0 + Vector3(0, 3, 0), spot + Vector3(0, 1, 0))
	await _wait(1.5)
	if not _shots.is_empty():
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("%s_warm.png" % _shots)
	var player: = Game.local_player
	for step in 8:
		fire.spray(player, PackedVector3Array([spot + out * 6.0 + Vector3(0, 1.5, 0), spot]), 0.25, 3.0)
		await _wait(0.25)
	print("firebench warm: after water, heat %.2f, wet for %.0f s, shown %s" % [node["heat"], float(node["wet_until"]) - Game.now(), fire._warm_shown.has(at)])



func _solo() -> void :
	CallService.current.hold = true
	var middle: = _building().position
	var out: = _street_side(middle)
	var at: = middle + out * 34.0
	var ground: = Game.world.raycast(at + Vector3(0, 30, 0), at - Vector3(0, 30, 0), World.LAYER_SOLID)
	at.y = (ground["position"] as Vector3).y if not ground.is_empty() else 0.5
	var flames: Array[Flame] = []
	for index in 3:
		var flame: = Flame.new()
		Game.world.add_child(flame)
		flame.global_position = at + Vector3((index - 1) * 6.0, 0, 0)
		flame.intensity = [0.15, 0.55, 1.0][index]
		flames.append(flame)
	Game.local_player.teleport(at + out * 30.0 + Vector3(0, 1, 0))
	_look(at + out * 14.0 + Vector3(0, 4, 0), at + Vector3(0, 3, 0))
	await _measure("solo")
	if Sky3D.current != null:
		Sky3D.current.set_hour(22.0)
		await _measure("solo_night")
		Sky3D.current.set_hour(12.0)

	flames[1].intensity = 1.0
	await _wait(0.5)
	await _snap_now("solo_flare")

	Blast.show(at + Vector3(0, 1.5, -5), 30.0, 0.2)
	await _wait(0.25)
	await _snap_now("solo_blast")
	await _wait(3.0)

	var spraying: = [true]
	var spray: = func() -> void :
		while spraying[0] and is_instance_valid(flames[2]):
			flames[2].progress = minf(flames[2].progress + 0.0012, 0.9)
			await get_tree().process_frame
	spray.call()
	await _wait(1.0)
	await _measure("solo_hit")
	spraying[0] = false
	FireService.current.steam_puff(flames[2].global_position)
	flames[2].queue_free()
	await _wait(0.5)
	await _measure("solo_out")




func _water() -> void :
	CallService.current.hold = true
	var middle: = _building().position
	var out: = _street_side(middle)
	var at: = middle + out * 34.0
	var ground: = Game.world.raycast(at + Vector3(0, 30, 0), at - Vector3(0, 30, 0), World.LAYER_SOLID)
	at.y = (ground["position"] as Vector3).y if not ground.is_empty() else 0.5
	var flame: = Flame.new()
	Game.world.add_child(flame)
	flame.global_position = at
	flame.intensity = 0.8
	Game.local_player.teleport(at + out * 40.0 + Vector3(0, 1, 0))
	var nozzle: = at + out * 16.0 + Vector3(0, 1.5, 0)
	var jet: = WaterJet.new()
	Game.world.add_child(jet)
	jet.origin = nozzle
	jet.aim = at + Vector3(0, 1.5, 0)
	jet.spraying = true
	var side: = out.cross(Vector3.UP)
	_look(nozzle.lerp(at, 0.5) + side * 14.0 + Vector3(0, 3, 0), nozzle.lerp(at, 0.5))
	await _measure("water_jet")

	_look(nozzle.lerp(at, 0.45) + side * 11.0 + Vector3(0, 9.0, 0), nozzle.lerp(at, 0.5))
	await _wait(0.3)
	await _snap_now("water_above")
	_look(nozzle - (at - nozzle).normalized() * 3.0 + Vector3(0, 0.6, 0) + side * 0.6, at + Vector3(0, 1, 0))
	await _measure("water_behind")
	jet.fog = true
	await _wait(0.6)
	await _measure("water_fog")
	_look(nozzle.lerp(at, 0.5) + side * 10.0 + Vector3(0, 2, 0), nozzle.lerp(at, 0.6))
	await _wait(0.3)
	await _snap_now("water_fog_side")
	jet.fog = false
	if Sky3D.current != null:
		Sky3D.current.set_hour(22.0)
		_look(nozzle.lerp(at, 0.5) + side * 14.0 + Vector3(0, 3, 0), nozzle.lerp(at, 0.5))
		await _measure("water_night")
