extends RefCounted






const FOUNTAIN_PARK: = 60.0
const GREENS: = [Color8(74, 98, 58), Color8(92, 112, 66), Color8(82, 100, 72)]
const BLOOMS: = [Color8(168, 96, 100), Color8(206, 198, 178), Color8(134, 118, 152), Color8(184, 150, 96)]
const PLANTED: = ["flowerbed", "station_bed", "planter"]


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var fountain: = Vector3.INF
	for model in kit.models_under("Map/Parks"):
		if store.nodes[model]["n"] == "fountain":
			for row in store.rows_in(model):
				fountain = store.position(row)
				break
	var cleared: = 0
	var planted: = 0
	for model in kit.models_under("Map/Parks"):
		var kind: String = store.nodes[model]["n"]
		if not PLANTED.has(kind):
			continue
		var rows: = store.rows_in(model)
		if rows.is_empty():
			continue
		var at: = store.position(rows[0])
		if kind == "flowerbed" and Vector2(at.x - fountain.x, at.z - fountain.z).length() < FOUNTAIN_PARK:

			for row in rows:
				store.set_transparency(row, 1.0)
				store.set_flags(row, 0)
			cleared += 1
			continue

		var roll: int = rand_from_seed(hash([roundi(at.x), roundi(at.z)]))[0]
		var bloom: Color = BLOOMS[roll % BLOOMS.size()]
		var index: = 0
		for row in rows:
			if store.name_at(row) != "Flowers":
				continue

			var flowers: = index == 1 if kind != "planter" else true
			store.set_color(row, bloom if flowers else GREENS[(roll / 7 + index) % GREENS.size()])
			index += 1
		planted += 1
	return "park beds: %d taken out of the fountain park, %d planted green" % [cleared, planted]
