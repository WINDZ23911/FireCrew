class_name NavGraph
extends RefCounted

























const DEFAULTS: = {
	"LaneSetback": 6.0, 
	"PavementCentre": 6.4, 
	"RoadsideInset": 2.0, 
	"TurnSteps": 8, 
	"MiterLimit": 2.0, 
	"DoorStep": 2.0, 
	"CrossingReach": 30.0, 
	"SignPair": 20.0, 
	"SignalReach": 60.0, 
	"PathJoin": 3.0, 
	"PathReach": 40.0, 
	"FeatureReach": 25.0, 
	"CarHalf": 3.3, 
	"ParkedHalf": 3.2, 
	"ParkedGap": 0.6, 
}


static var current: NavGraph

var layout: Dictionary
var segments: Array = []
var entries: Array[int] = []
var exits: Array[int] = []
var dead_ends: Array[int] = []
var junctions: Array = []
var crossings: Array = []
var walk: Array = []
var places: Array = []



var bus: Dictionary = {}

var closure: Dictionary = {}


var cordon: Dictionary = {}


var route_length: = 0.0

var route_cost: = 0.0


var _s: Dictionary
var _nodes: Array
var _roads: Array
var _from: = PackedInt32Array()
var _to: = PackedInt32Array()
var _centre: Array = []
var _arms: Array = []
var _grid: Dictionary = {}
var _grid_min: = Vector2i.ZERO
var _grid_max: = Vector2i.ZERO
const _SQUARE: = 80.0






static func _clean(points: Array) -> PackedVector2Array:
	var out: = PackedVector2Array()
	for point: Array in points:
		var made: = Vector2(point[0], point[1])
		if out.is_empty() or absf(made.x - out[out.size() - 1].x) + absf(made.y - out[out.size() - 1].y) > 0.01:
			out.append(made)
	return out


static func _reversed(points: PackedVector2Array) -> PackedVector2Array:
	var out: = points.duplicate()
	out.reverse()
	return out



static func _offset_line(points: PackedVector2Array, offset: float, miter_limit: float) -> PackedVector2Array:
	var out: = PackedVector2Array()
	var count: = points.size()
	for i in count:
		var a: = Vector2.ZERO
		var b: = Vector2.ZERO
		if i > 0:
			a = (points[i] - points[i - 1]).normalized()
		if i < count - 1:
			b = (points[i + 1] - points[i]).normalized()
		if i == 0:
			a = b
		if i == count - 1:
			b = a
		var sum: = a + b
		var length: = sum.length()
		if length < 1e-06:
			sum = a
			length = 1.0
		var t: = sum / length
		var scale: = offset / maxf(t.dot(a), 1.0 / miter_limit)

		out.append(Vector2(points[i].x - t.y * scale, points[i].y + t.x * scale))
	return out


static func _measure(points: PackedVector2Array) -> PackedFloat64Array:
	var cum: = PackedFloat64Array()
	cum.resize(points.size())
	cum[0] = 0.0
	for i in range(1, points.size()):
		cum[i] = cum[i - 1] + points[i - 1].distance_to(points[i])
	return cum



static func _point_along(points: PackedVector2Array, cum: PackedFloat64Array, distance: float) -> Vector4:
	var count: = points.size()
	distance = clampf(distance, 0.0, cum[count - 1])
	var i: = 0
	while i < count - 2 and cum[i + 1] < distance:
		i += 1
	var step: = points[i + 1] - points[i]
	var length: = step.length()
	var d: = step / length if length > 0.0 else Vector2(0, -1)
	var along: = minf(distance - cum[i], length)
	return Vector4(points[i].x + d.x * along, points[i].y + d.y * along, d.x, d.y)



static func _cut_line(points: PackedVector2Array, start_cut: float, end_cut: float) -> PackedVector2Array:
	var cum: = _measure(points)
	var from: = start_cut
	var to: = cum[points.size() - 1] - end_cut
	var at: = _point_along(points, cum, from)
	var out: = PackedVector2Array([Vector2(at.x, at.y)])
	for i in range(1, points.size() - 1):
		if cum[i] > from + 0.01 and cum[i] < to - 0.01:
			out.append(points[i])
	at = _point_along(points, cum, to)
	out.append(Vector2(at.x, at.y))
	return out



static func _project(a: Vector2, b: Vector2, p: Vector2) -> Vector4:
	var d: = b - a
	var squared: = d.length_squared()
	var t: = clampf((p - a).dot(d) / squared, 0.0, 1.0) if squared > 0.0 else 0.0
	var q: = a + d * t
	return Vector4(p.distance_squared_to(q), t, q.x, q.y)



static func _project_on_line(points: PackedVector2Array, cum: PackedFloat64Array, p: Vector2) -> Vector2:
	var best: = INF
	var best_along: = 0.0
	for i in points.size() - 1:
		var a: = points[i]
		var d: = points[i + 1] - a
		var squared: = d.length_squared()
		var t: = clampf((p - a).dot(d) / squared, 0.0, 1.0) if squared > 0.0 else 0.0
		var gap: = p.distance_squared_to(a + d * t)
		if gap < best:
			best = gap
			best_along = cum[i] + (cum[i + 1] - cum[i]) * t
	return Vector2(best, best_along)



static func _curve(a: Vector2, ad: Vector2, b: Vector2, bd: Vector2, steps: int) -> PackedVector2Array:
	var reach: = a.distance_to(b)

	var handle: = reach * (0.66 if ad.dot(bd) < -0.7 else 0.4)
	var c1: = a + ad * handle
	var c2: = b - bd * handle
	var out: = PackedVector2Array()
	for step in steps + 1:
		var t: = float(step) / steps
		var u: = 1.0 - t
		out.append(a * (u * u * u) + c1 * (3 * u * u * t) + c2 * (3 * u * t * t) + b * (t * t * t))
	return out


static func _turn_name(ad: Vector2, bd: Vector2) -> String:
	var angle: = rad_to_deg(atan2(ad.x * bd.y - ad.y * bd.x, ad.dot(bd)))
	if absf(angle) < 30.0:
		return "straight"
	elif absf(angle) > 150.0:
		return "uturn"
	return "right" if angle > 0.0 else "left"





static func build(town_layout: Dictionary, options: = {}) -> NavGraph:
	var graph: = NavGraph.new()
	graph._build(town_layout, options)
	return graph



func _cut_at(r: int, n: int, extra: float) -> float:
	if _nodes[n].get("kind") == "exit":
		return 0.0
	elif _arms[n].size() == 1:
		return float(_roads[r]["width"]) / 2.0
	var widest: = 0.0
	for arm: Dictionary in _arms[n]:
		if arm["road"] != r:
			widest = maxf(widest, _roads[arm["road"]]["width"])
	return widest / 2.0 + extra



func _cuts(r: int, extra: float, length: float) -> Vector2:
	var a: = _cut_at(r, _from[r], extra)
	var b: = _cut_at(r, _to[r], extra)
	var most: = length * 0.8
	if a + b > most:
		var sum: = a + b
		a = a * most / sum
		b = b * most / sum
	return Vector2(a, b)



func _outward(r: int, at_start: bool) -> Vector2:
	var line: PackedVector2Array = _centre[r]
	if at_start:
		return (line[1] - line[0]).normalized()
	return (line[line.size() - 2] - line[line.size() - 1]).normalized()



func _phase_of(n: int, r: int, at_start: bool) -> int:
	if _nodes[n].get("control") != "signals":
		return 0
	var out: = _outward(r, at_start)
	var best: = 0.5
	var phase: = 0
	var reach: float = _s["SignalReach"]
	var here: = Vector2(_nodes[n]["x"], _nodes[n]["z"])
	for found: Dictionary in _list(layout.get("signals")):
		if Vector2(found["x"], found["z"]).distance_squared_to(here) < reach * reach:
			var yaw: = deg_to_rad(found["yaw"])
			var facing: = - sin(yaw) * out.x - cos(yaw) * out.y
			if facing > best:
				best = facing
				phase = int(found["phase"])
	return phase




static func _list(value: Variant) -> Array:
	return value if value is Array else []


func _add_segment(segment: Dictionary, points: PackedVector2Array) -> Dictionary:
	segment["id"] = segments.size()
	segment["points"] = points
	var cum: = _measure(points)
	segment["cum"] = cum
	segment["length"] = cum[points.size() - 1]
	segment["next"] = []
	segment["island"] = 0
	segments.append(segment)
	return segment


func _add_node(x: float, z: float) -> int:
	walk.append({"x": x, "z": z, "links": [], "place": -1, "island": 0})
	return walk.size() - 1



func find_link(a: int, b: int) -> Dictionary:
	for made: Dictionary in walk[a]["links"]:
		if made["to"] == b:
			return made
	return {}



func _link(a: int, b: int, details: Dictionary) -> void :
	if a == b or not find_link(a, b).is_empty():
		return
	var length: = Vector2(walk[a]["x"], walk[a]["z"]).distance_to(Vector2(walk[b]["x"], walk[b]["z"]))
	for pair: Array in [[a, b], [b, a]]:
		var made: = {"kind": "path", "road": -1, "side": 0, "junction": -1, "marked": false, "crossing": -1, "phase": 0}
		made.merge(details, true)
		made["to"] = pair[1]
		made["length"] = length
		walk[pair[0]]["links"].append(made)
		if pair[0] < pair[1]:
			for square in _squares(a, b):
				if not _grid.has(square):
					_grid[square] = []
					if _grid.size() == 1:
						_grid_min = square
						_grid_max = square
					_grid_min = Vector2i(mini(_grid_min.x, square.x), mini(_grid_min.y, square.y))
					_grid_max = Vector2i(maxi(_grid_max.x, square.x), maxi(_grid_max.y, square.y))
				_grid[square].append([pair[0], made])



func _squares(a: int, b: int) -> Array[Vector2i]:
	var x0: = floori(minf(walk[a]["x"], walk[b]["x"]) / _SQUARE)
	var x1: = floori(maxf(walk[a]["x"], walk[b]["x"]) / _SQUARE)
	var z0: = floori(minf(walk[a]["z"], walk[b]["z"]) / _SQUARE)
	var z1: = floori(maxf(walk[a]["z"], walk[b]["z"]) / _SQUARE)
	var out: Array[Vector2i] = []
	for x in range(x0, x1 + 1):
		for z in range(z0, z1 + 1):
			out.append(Vector2i(x, z))
	return out


func _unlink(a: int, b: int) -> void :
	for pair: Array in [[a, b], [b, a]]:
		var links: Array = walk[pair[0]]["links"]
		for i in links.size():
			if links[i]["to"] == pair[1]:
				links.remove_at(i)
				break
	var low: = mini(a, b)
	var high: = maxi(a, b)
	for square in _squares(a, b):
		var held: Array = _grid.get(square, [])
		for i in held.size():
			if held[i][0] == low and held[i][1]["to"] == high:
				held.remove_at(i)
				break




func _node_near(x: float, z: float, accept: Callable) -> Array:
	var p: = Vector2(x, z)
	var best: = INF
	var best_a: = -1
	var best_link: Dictionary = {}
	var best_t: = 0.0
	var best_at: = Vector2.ZERO


	var home: = Vector2i(floori(x / _SQUARE), floori(z / _SQUARE))
	var furthest: = maxi(maxi(absi(home.x - _grid_min.x), absi(home.x - _grid_max.x)), maxi(absi(home.y - _grid_min.y), absi(home.y - _grid_max.y)))
	for ring in furthest + 1:
		if best < INF and (ring - 1) * _SQUARE > sqrt(best):
			break
		for cx in range(home.x - ring, home.x + ring + 1):
			var edge: = absi(cx - home.x) == ring
			var cz: = home.y - ring
			while cz <= home.y + ring:
				for held: Array in _grid.get(Vector2i(cx, cz), []):
					var a: int = held[0]
					var candidate: Dictionary = held[1]
					var node: Dictionary = walk[a]
					var from: = Vector2(node["x"], node["z"])
					var other: Dictionary = walk[candidate["to"]]
					var d: = Vector2(other["x"], other["z"]) - from
					var squared: = d.length_squared()
					var t: = clampf((p - from).dot(d) / squared, 0.0, 1.0) if squared > 0.0 else 0.0
					var q: = from + d * t
					var gap: = p.distance_squared_to(q)

					if gap < best and accept.call(candidate):
						best = gap
						best_a = a
						best_link = candidate
						best_t = t
						best_at = q

				cz += 1 if edge else maxi(ring * 2, 1)
	if best_a < 0:
		return [-1, INF]
	var end: int = best_link["to"]
	var length: float = best_link["length"]
	if best_t * length < 1.0:
		return [best_a, sqrt(best)]
	elif (1.0 - best_t) * length < 1.0:
		return [end, sqrt(best)]
	var details: = best_link.duplicate()
	_unlink(best_a, end)
	var middle: = _add_node(best_at.x, best_at.y)
	_link(best_a, middle, details)
	_link(middle, end, details)
	return [middle, sqrt(best)]



func _add_crossing(a: int, b: int, details: Dictionary) -> void :
	if a == b or not find_link(a, b).is_empty():
		return
	details["kind"] = "crossing"
	details["crossing"] = crossings.size()
	crossings.append({
		"id": crossings.size(), 
		"a": a, 
		"b": b, 
		"road": details.get("road", -1), 
		"junction": details.get("junction", -1), 
		"phase": details.get("phase", 0), 
		"marked": details.get("marked", false), 
		"walkers": 0, 
		"cars": 0, 
	})
	_link(a, b, details)


func _add_place(place: Dictionary) -> Dictionary:
	place["id"] = places.size()
	place["island"] = 0
	places.append(place)
	walk[place["node"]]["place"] = place["id"]
	return place


static func _is_footway(candidate: Dictionary) -> bool:
	return candidate["kind"] == "pavement" or candidate["kind"] == "roadside"


static func _is_walked(candidate: Dictionary) -> bool:
	return candidate["kind"] == "pavement" or candidate["kind"] == "roadside" or candidate["kind"] == "parkpath"



func _attach(x: float, z: float) -> int:
	var near: int = _node_near(x, z, _is_walked)[0]
	var node: = _add_node(x, z)
	if near >= 0:
		_link(node, near, {"kind": "path"})
	return node



func _road_near(x: float, z: float) -> Array:
	var reach: float = _s["CrossingReach"]
	var best: = reach * reach
	var best_road: = -1
	var best_along: = 0.0
	for r in _roads.size():
		if _roads[r]["rank"] >= 1:
			var found: = _project_on_line(_centre[r], _measure(_centre[r]), Vector2(x, z))
			if found.x < best:
				best = found.x
				best_road = r
				best_along = found.y
	return [best_road, best_along]



static func _flood(count: int, neighbours: Callable, mark: Callable) -> void :
	var seen: = PackedByteArray()
	seen.resize(count)
	var islands: = 0
	for start in count:
		if seen[start] == 0:
			islands += 1
			seen[start] = 1
			var queue: Array[int] = [start]
			while not queue.is_empty():
				var id: int = queue.pop_back()
				mark.call(id, islands)
				for other: int in neighbours.call(id):
					if seen[other] == 0:
						seen[other] = 1
						queue.append(other)


func _build(town_layout: Dictionary, options: Dictionary) -> void :
	layout = town_layout
	_s = DEFAULTS.duplicate()
	_s.merge(options, true)
	_nodes = layout["nodes"]
	_roads = layout["roads"]
	var miter: float = _s["MiterLimit"]

	for n in _nodes.size():
		_arms.append([])
	_from.resize(_roads.size())
	_to.resize(_roads.size())
	for r in _roads.size():
		var road: Dictionary = _roads[r]
		_centre.append(_clean(road["points"]))
		_from[r] = int(road["from"]) - 1
		_to[r] = int(road["to"]) - 1
		_arms[_from[r]].append({"road": r, "at_start": true})
		_arms[_to[r]].append({"road": r, "at_start": false})



	var lane_offset: Array = []
	for road: Dictionary in _roads:
		lane_offset.append({1: float(road["width"]) / 4.0, -1: float(road["width"]) / 4.0})
	for prop: Dictionary in _list(layout.get("props")):
		if prop.get("kind") != "car":
			continue
		var at: = Vector2(prop["x"], prop["z"])
		var best: = INF
		var best_road: = -1
		var best_side: = 0
		for r in _roads.size():
			var line: PackedVector2Array = _centre[r]
			var half: float = float(_roads[r]["width"]) / 2.0
			for i in line.size() - 1:
				var squared: = _project(line[i], line[i + 1], at).x
				if squared < best and squared < half * half:
					var d: = (line[i + 1] - line[i]).normalized()
					best = squared
					best_road = r
					best_side = 1 if (at.x - line[i].x) * - d.y + (at.y - line[i].y) * d.x >= 0.0 else -1
		if best_road >= 0:
			var room: float = sqrt(best) - _s["ParkedHalf"] - _s["ParkedGap"] - _s["CarHalf"]
			var offsets: Dictionary = lane_offset[best_road]
			offsets[best_side] = maxf(_s["CarHalf"] + 0.3, minf(offsets[best_side], room))


	var into: Array = []
	var out_of: Array = []
	for n in _nodes.size():
		into.append([])
		out_of.append([])

	for r in _roads.size():
		var road: Dictionary = _roads[r]
		var width: float = road["width"]
		for forward: bool in [true, false]:
			var from: = _from[r]
			var to: = _to[r]
			var line: PackedVector2Array = _centre[r]
			if not forward:
				from = _to[r]
				to = _from[r]
				line = _reversed(line)
			var offset: float = lane_offset[r][1 if forward else -1]

			var pull_over: = 0.0
			if offset > width / 4.0 - 0.01:
				pull_over = width / 2.0 - offset - _s["CarHalf"] - 0.3 + (2.0 if width < 24.0 else 0.0)
			var shifted: = _offset_line(line, offset, miter)
			var cum: = _measure(shifted)
			var cut: = _cuts(r, _s["LaneSetback"], cum[shifted.size() - 1])
			if not forward:
				cut = Vector2(cut.y, cut.x)
			var lane: = _add_segment({
				"kind": "lane", 
				"road": r, 
				"name": road.get("name", ""), 
				"key": road.get("key", ""), 
				"road_class": road.get("class", ""), 
				"rank": int(road["rank"]), 
				"width": width, 
				"from": from, 
				"to": to, 
				"control": _control(to), 
				"phase": _phase_of(to, r, not forward), 
				"offset": offset, 
				"pull_over": pull_over, 
				"exit": false, 
				"start_crossing": -1, 
				"end_crossing": -1, 
				"crossings": [], 
			}, _cut_line(shifted, cut.x, cut.y))
			out_of[from].append(lane)
			into[to].append(lane)
			if _nodes[from].get("kind") == "exit":
				entries.append(lane["id"])
			if _nodes[to].get("kind") == "exit":
				lane["exit"] = true
				exits.append(lane["id"])

	for n in _nodes.size():
		if _nodes[n].get("kind") == "exit":
			continue
		var dead_end: bool = _arms[n].size() == 1
		for lane: Dictionary in into[n]:
			for out: Dictionary in out_of[n]:

				if dead_end or out["road"] != lane["road"]:
					var a: = _point_along(lane["points"], lane["cum"], lane["length"])
					var b: = _point_along(out["points"], out["cum"], 0.0)
					var ad: = Vector2(a.z, a.w)
					var bd: = Vector2(b.z, b.w)
					var turn: = _add_segment({
						"kind": "turn", 
						"node": n, 
						"control": _control(n), 
						"rank": lane["rank"], 
						"width": minf(lane["width"], out["width"]), 
						"from_lane": lane["id"], 
						"to_lane": out["id"], 
						"turn": _turn_name(ad, bd), 
					}, _curve(Vector2(a.x, a.y), ad, Vector2(b.x, b.y), bd, int(_s["TurnSteps"])))
					lane["next"].append(turn["id"])
					turn["next"].append(out["id"])





	var ends: Array = []
	for r in _roads.size():
		var road: Dictionary = _roads[r]
		var paved: bool = road["rank"] >= 1
		var offset: float = float(road["width"]) / 2.0 + (_s["PavementCentre"] if paved else - _s["RoadsideInset"])
		var sides: = {}
		for side: int in [1, -1]:
			var shifted: = _offset_line(_centre[r], offset * side, miter)
			var cum: = _measure(shifted)
			var cut: = _cuts(r, _s["PavementCentre"], cum[shifted.size() - 1])
			var first: = -1
			var last: = -1
			for point in _cut_line(shifted, cut.x, cut.y):
				var node: = _add_node(point.x, point.y)
				if last >= 0:
					_link(last, node, {"kind": "pavement" if paved else "roadside", "road": r, "side": side})
				if first < 0:
					first = node
				last = node
			sides[side] = {"first": first, "last": last}
		ends.append(sides)


	for n in _nodes.size():
		var around: Array = []
		for arm: Dictionary in _arms[n]:
			var out: = _outward(arm["road"], arm["at_start"])
			var sides: Dictionary = ends[arm["road"]]
			var made: = {"road": arm["road"], "phase": _phase_of(n, arm["road"], arm["at_start"])}
			if arm["at_start"]:
				made["right"] = sides[1]["first"]
				made["left"] = sides[-1]["first"]
			else:
				made["right"] = sides[-1]["last"]
				made["left"] = sides[1]["last"]
			made["angle"] = atan2(out.y, out.x)
			around.append(made)
		around.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["angle"] < b["angle"])

		if _nodes[n].get("kind") == "exit":
			for arm: Dictionary in around:
				_add_place({"kind": "exit", "node": arm["right"], "x": walk[arm["right"]]["x"], "z": walk[arm["right"]]["z"]})
				_add_place({"kind": "exit", "node": arm["left"], "x": walk[arm["left"]]["x"], "z": walk[arm["left"]]["z"]})
		else:


			for i in around.size():
				_link(around[i]["right"], around[(i + 1) % around.size()]["left"], {"kind": "corner", "junction": n})
			if around.size() >= 3:
				var marked: = _control(n) == "signals" or _control(n) == "stop"
				for arm: Dictionary in around:
					_add_crossing(arm["right"], arm["left"], {"road": arm["road"], "junction": n, "marked": marked, "phase": arm["phase"]})



	var marks: Array = []
	var signs_on: = {}
	for point: Dictionary in _list(layout.get("points")):
		if point.get("kind") == "crossing":
			var r: int = _road_near(point["x"], point["z"])[0]
			if r >= 0:
				marks.append({"road": r, "x": point["x"], "z": point["z"]})

	if marks.is_empty():
		for found: Dictionary in _list(layout.get("signs")):
			if found.get("kind") == "crossing":
				var near: = _road_near(found["x"], found["z"])
				if near[0] >= 0:
					if not signs_on.has(near[0]):
						signs_on[near[0]] = []
					signs_on[near[0]].append(near[1])
	for r in _roads.size():
		if not signs_on.has(r):
			continue
		var alongs: Array = signs_on[r]
		alongs.sort()
		var cum: = _measure(_centre[r])
		var i: = 0
		while i < alongs.size():
			var at: float = alongs[i]
			if i + 1 < alongs.size() and alongs[i + 1] - at < _s["SignPair"]:
				at = (at + alongs[i + 1]) / 2.0
				i += 1
			var where: = _point_along(_centre[r], cum, at)
			marks.append({"road": r, "x": where.x, "z": where.y})
			i += 1
	for mark: Dictionary in marks:
		var road: int = mark["road"]
		var a: int = _node_near(mark["x"], mark["z"], func(candidate: Dictionary) -> bool: return candidate["road"] == road and candidate["side"] == 1)[0]
		var b: int = _node_near(mark["x"], mark["z"], func(candidate: Dictionary) -> bool: return candidate["road"] == road and candidate["side"] == -1)[0]
		if a < 0 or b < 0:
			continue
		var existing: = find_link(a, b)
		if not existing.is_empty():
			existing["marked"] = true
			find_link(b, a)["marked"] = true
			if existing["crossing"] >= 0:
				crossings[existing["crossing"]]["marked"] = true
		else:
			_add_crossing(a, b, {"road": road, "marked": true})


	for crossing: Dictionary in crossings:
		for segment: Dictionary in segments:
			if segment["kind"] == "lane" and segment["road"] == crossing["road"]:
				if crossing["junction"] >= 0:
					if segment["to"] == crossing["junction"]:
						segment["end_crossing"] = crossing["id"]
					if segment["from"] == crossing["junction"]:
						segment["start_crossing"] = crossing["id"]
				else:
					var a: Dictionary = walk[crossing["a"]]
					var b: Dictionary = walk[crossing["b"]]
					var middle: = Vector2((a["x"] + b["x"]) / 2.0, (a["z"] + b["z"]) / 2.0)
					segment["crossings"].append({"id": crossing["id"], "at": _project_on_line(segment["points"], segment["cum"], middle).y})

	_build_paths()


	var no_door: = {"outbuilding": true, "canopy": true, "garages": true}
	var buildings: = _list(layout.get("buildings"))
	for index in buildings.size():
		var building: Dictionary = buildings[index]
		if not no_door.has(building.get("kind")):
			var yaw: = deg_to_rad(building["yaw"])
			var out: float = float(building["depth"]) / 2.0 + _s["DoorStep"]
			var x: float = building["x"] - sin(yaw) * out
			var z: float = building["z"] - cos(yaw) * out
			_add_place({
				"kind": "door", 
				"node": _attach(x, z), 
				"x": x, 
				"z": z, 
				"building": index, 
				"building_kind": building.get("kind", ""), 
				"label": building.get("label", ""), 
			})

	var feature_places: = {
		"bench": "bench", 
		"shelter": "bus_stop", 
		"bus_canopy": "bus_stop", 
		"fountain": "spot", 
		"monument": "spot", 
		"kiosk": "spot", 
		"column": "spot", 
		"cafe_table": "spot", 
		"flowerbed": "spot", 
		"swing": "spot", 
		"shrine": "spot", 
	}
	for list: Array in [_list(layout.get("features")), _list(layout.get("props"))]:
		for feature: Dictionary in list:
			var kind: String = feature_places.get(feature.get("kind"), "")
			if not kind.is_empty():
				var near: = _node_near(feature["x"], feature["z"], _is_walked)
				var node: int = near[0]
				if node >= 0 and near[1] <= _s["FeatureReach"] and walk[node]["place"] < 0:
					_add_place({"kind": kind, "node": node, "x": feature["x"], "z": feature["z"], "yaw": feature.get("yaw", 0.0), "feature": feature["kind"]})



	var road_island: = PackedInt32Array()
	road_island.resize(_nodes.size())
	_flood(_nodes.size(), func(n: int) -> Array:
		var others: Array = []
		for arm: Dictionary in _arms[n]:
			others.append(_to[arm["road"]] if arm["at_start"] else _from[arm["road"]])
		return others
	, func(n: int, island: int) -> void : road_island[n] = island)
	for segment: Dictionary in segments:
		segment["island"] = road_island[segment["node"] if segment["kind"] == "turn" else segment["from"]]

	_flood(walk.size(), func(id: int) -> Array:
		var others: Array = []
		for made: Dictionary in walk[id]["links"]:
			others.append(made["to"])
		return others
	, func(id: int, island: int) -> void : walk[id]["island"] = island)
	for place: Dictionary in places:
		place["island"] = walk[place["node"]]["island"]


	for n in _nodes.size():
		var top: = 0
		for arm: Dictionary in _arms[n]:
			top = maxi(top, int(_roads[arm["road"]]["rank"]))
		junctions.append({"control": _control(n), "rank": top, "arms": _arms[n].size()})
		if _arms[n].size() == 1 and _nodes[n].get("kind") != "exit":
			dead_ends.append(into[n][0]["id"])

	_s = {}
	_centre = []
	_arms = []
	_grid = {}


func _control(n: int) -> String:
	var control: Variant = _nodes[n].get("control")
	return control if control is String else ""




func _build_paths() -> void :
	var join: float = _s["PathJoin"]
	var runs: Array = []
	for strip: Dictionary in _list(layout.get("strips")):
		if strip.get("kind") == "path":
			var yaw: = deg_to_rad(strip["yaw"])
			var half: = Vector2(sin(yaw), cos(yaw)) * (float(strip["length"]) / 2.0)
			var middle: = Vector2(strip["x"], strip["z"])
			runs.append({"a": middle - half, "b": middle + half, "stops": [0.0, 1.0]})

	for i in runs.size():
		var run: Dictionary = runs[i]
		var ra: Vector2 = run["a"]
		var rb: Vector2 = run["b"]
		var rd: = rb - ra

		var reach: = rd.length() / 2.0 + join
		var centre: = (ra + rb) / 2.0
		for j in runs.size():
			if i == j:
				continue
			var other: Dictionary = runs[j]
			var oa: Vector2 = other["a"]
			var ob: Vector2 = other["b"]
			var od: = ob - oa
			if centre.distance_to((oa + ob) / 2.0) > reach + od.length() / 2.0:
				continue
			var cross: = rd.x * od.y - rd.y * od.x
			var gap: = oa - ra
			if absf(cross) > 1e-06:
				var t: = (gap.x * od.y - gap.y * od.x) / cross
				var u: = (gap.x * rd.y - gap.y * rd.x) / cross
				if t > 0.0 and t < 1.0 and u >= 0.0 and u <= 1.0:
					run["stops"].append(t)
			for tip: Vector2 in [oa, ob]:
				var found: = _project(ra, rb, tip)
				if found.x < join * join and found.y > 0.0 and found.y < 1.0:
					run["stops"].append(found.y)

	var made: Array[int] = []
	var tips: = {}
	for run: Dictionary in runs:
		var stops: Array = run["stops"]
		stops.sort()
		var last: = -1
		for t: float in stops:
			var at: Vector2 = run["a"] + (run["b"] - run["a"]) * t
			var id: = -1
			for candidate in made:
				if Vector2(walk[candidate]["x"], walk[candidate]["z"]).distance_squared_to(at) < join * join:
					id = candidate
					break
			if id < 0:
				id = _add_node(at.x, at.y)
				made.append(id)
			if last >= 0:
				_link(last, id, {"kind": "parkpath"})
			last = id
			if t == 0.0 or t == 1.0:
				tips[id] = true

	for id: int in tips:
		var near: = _node_near(walk[id]["x"], walk[id]["z"], _is_footway)
		if near[0] >= 0 and near[1] <= _s["PathReach"]:
			_link(id, near[0], {"kind": "path"})






static func sample(segment: Dictionary, distance: float) -> Vector4:
	return _point_along(segment["points"], segment["cum"], distance)



static func sample_position(segment: Dictionary, distance: float, height: = 0.0) -> Vector3:
	var at: = _point_along(segment["points"], segment["cum"], distance)
	return Vector3(at.x, height, at.y)


static func _heap_push(costs: PackedFloat64Array, ids: PackedInt32Array, cost: float, id: int) -> void :
	var i: = ids.size()
	costs.append(cost)
	ids.append(id)
	while i > 0:
		var parent: = (i - 1) >> 1
		if costs[parent] <= cost:
			break
		costs[i] = costs[parent]
		ids[i] = ids[parent]
		i = parent
	costs[i] = cost
	ids[i] = id



static var _popped: = 0.0


static func _heap_pop(costs: PackedFloat64Array, ids: PackedInt32Array) -> int:
	var top: = ids[0]
	_popped = costs[0]
	var last: = ids.size() - 1
	var cost: = costs[last]
	var id: = ids[last]
	costs.resize(last)
	ids.resize(last)
	if last == 0:
		return top
	var i: = 0
	while true:
		var child: = i * 2 + 1
		if child >= last:
			break
		if child + 1 < last and costs[child + 1] < costs[child]:
			child += 1
		if costs[child] >= cost:
			break
		costs[i] = costs[child]
		ids[i] = ids[child]
		i = child
	costs[i] = cost
	ids[i] = id
	return top


static func _trace(previous: PackedInt32Array, goal: int) -> Array[int]:
	var route: Array[int] = []
	var id: = goal
	while id >= 0:
		route.append(id)
		id = previous[id]
	route.reverse()
	return route






func drive_route(from: int, to: int, avoid: = {}, weigh: = Callable()) -> Array[int]:
	var count: = segments.size()
	var cost: = PackedFloat64Array()
	cost.resize(count)
	cost.fill(INF)
	var previous: = PackedInt32Array()
	previous.resize(count)
	previous.fill(-1)
	var heap_cost: = PackedFloat64Array()
	var heap_id: = PackedInt32Array()
	var weighed: = weigh.is_valid()
	cost[from] = 0.0
	_heap_push(heap_cost, heap_id, 0.0, from)
	while not heap_id.is_empty():
		var current_id: = _heap_pop(heap_cost, heap_id)
		if _popped > cost[current_id]:
			continue
		if current_id == to:
			break
		for next_id: int in segments[current_id]["next"]:
			if avoid.has(next_id):
				continue
			var step: float = weigh.call(segments[next_id]) if weighed else float(segments[next_id]["length"])
			var total: float = cost[current_id] + step
			if total < cost[next_id]:
				cost[next_id] = total
				previous[next_id] = current_id
				_heap_push(heap_cost, heap_id, total, next_id)
	if cost[to] == INF:
		return []
	var route: = _trace(previous, to)
	route_length = cost[to]
	route_cost = cost[to]
	if weighed:
		route_length = 0.0
		for index in range(1, route.size()):
			route_length += float(segments[route[index]]["length"])
	return route




func walk_route(from: int, to: int, weigh: = Callable()) -> Array[int]:
	var count: = walk.size()
	var cost: = PackedFloat64Array()
	cost.resize(count)
	cost.fill(INF)
	var previous: = PackedInt32Array()
	previous.resize(count)
	previous.fill(-1)
	var heap_cost: = PackedFloat64Array()
	var heap_id: = PackedInt32Array()
	var weighed: = weigh.is_valid()
	cost[from] = 0.0
	_heap_push(heap_cost, heap_id, 0.0, from)
	while not heap_id.is_empty():
		var current_id: = _heap_pop(heap_cost, heap_id)
		var so_far: = _popped
		if so_far > cost[current_id]:
			continue
		if current_id == to:
			break
		for made: Dictionary in walk[current_id]["links"]:
			var step: float = made["length"]
			if weighed:
				var weight: Variant = weigh.call(made)
				if weight == null:
					continue
				step = weight
			var next_id: int = made["to"]
			var total: = so_far + step
			if total < cost[next_id]:
				cost[next_id] = total
				previous[next_id] = current_id
				_heap_push(heap_cost, heap_id, total, next_id)
	if cost[to] == INF:
		return []
	route_length = cost[to]
	return _trace(previous, to)




func nearest_lane(x: float, z: float, accept: = Callable()) -> Array:
	var best: = INF
	var best_id: = -1
	var best_along: = 0.0
	var p: = Vector2(x, z)
	var filtered: = accept.is_valid()
	for segment: Dictionary in segments:
		if segment["kind"] == "lane" and ( not filtered or accept.call(segment)):
			var found: = _project_on_line(segment["points"], segment["cum"], p)
			if found.x < best:
				best = found.x
				best_id = segment["id"]
				best_along = found.y
	return [best_id, best_along, sqrt(best)]




func nearest_walk(x: float, z: float, island: = 0) -> Array:
	var best: = INF
	var best_id: = -1
	for id in walk.size():
		var node: Dictionary = walk[id]
		if island != 0 and node["island"] != island:
			continue
		var dx: float = node["x"] - x
		var dz: float = node["z"] - z
		var gap: = dx * dx + dz * dz
		if gap < best:
			best = gap
			best_id = id
	return [best_id, sqrt(best)]
