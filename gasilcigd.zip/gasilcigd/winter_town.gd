class_name WinterTown
extends Node3D













const BIRDS: = ["WireBird", "WireBirdHead", "WireBirdTail"]


const BLOOMS: = ["Bloom", "FlowerLeaves", "Flowers", "Plant", "BasketFlowers", "BasketLeaves", "BasketChain"]
const CAFE: = ["TableLeg", "TableTop", "ChairSeat", "ChairBack", "ChairLegs", "Parasol", "ParasolPole", "ParasolValance"]
const SQUARE_REACH: = 260.0
const LIT_NEAR: = 0.75
const LIT_FAR: = 0.3
const BULB_GAP: = 1.25
const HOOK_GAP: = 5.0
const SAG: = 0.35
const BULB: = 0.34

const WARM: = Color(1.0, 0.78, 0.46)
const COLOURS: = [Color(1.0, 0.25, 0.18), Color(0.25, 0.9, 0.35), Color(0.3, 0.45, 1.0), Color(1.0, 0.7, 0.2)]
const SMOKING: = 0.65
const SMOKE_REACH: = 330.0
const SMOKES: = [3, 6, 9]
const LOOK_EVERY: = 1.0

var _cafe: PackedInt32Array = []
var _birds: PackedInt32Array = []
var _blooms: PackedInt32Array = []
var _lights: MultiMeshInstance3D
var _light_material: ShaderMaterial
var _chimneys: Array[Vector3] = []
var _smokes: Array[GPUParticles3D] = []
var _since: = LOOK_EVERY
var _shown: = false


func _ready() -> void :
	var store: = Game.store
	var shopfronts: = _folder(store, ["Map", "Polish", "Shopfronts"])
	if shopfronts >= 0:
		for row in store.rows_in(shopfronts):
			if store.name_at(row) in CAFE:
				_cafe.append(store.id_at(row))
	for part_name: String in BIRDS:
		for row in store.rows_named(part_name):
			_birds.append(store.id_at(row))
	for part_name: String in BLOOMS:
		for row in store.rows_named(part_name):
			_blooms.append(store.id_at(row))
	_make_lights(store)
	for row in store.rows_named("Chimney"):
		var top: = store.position(row) + store.basis(row).y.normalized() * store.size(row).y / 2.0
		if _roll(int(top.x * 3.0), int(top.z * 3.0)) < SMOKING:
			_chimneys.append(top + Vector3(0, 0.6, 0))
	for index in SMOKES[SMOKES.size() - 1]:
		var smoke: = _make_smoke()
		smoke.emitting = false
		add_child(smoke)
		_smokes.append(smoke)
	Style.current.changed.connect( func(_style: int) -> void : _show())
	_show()
	if OS.get_cmdline_user_args().has("--winter-trace"):
		print("winter town: %d café pieces, %d bird pieces, %d flowering pieces, %d bulbs, %d smoking chimneys" % [_cafe.size(), _birds.size(), _blooms.size(), _lights.multimesh.instance_count, _chimneys.size()])
		if not _birds.is_empty():
			print("  a bird on the wires at ", store.position(store.row_of[_birds[0]]))


func _show() -> void :
	var winter: = Style.winter()
	if winter == _shown:
		return
	_shown = winter
	for id in _cafe:
		Game.world.set_hidden(id, winter)
		Game.world.set_solid(id, not winter)
	for id in _birds:
		Game.world.set_hidden(id, winter)
	for id in _blooms:
		Game.world.set_hidden(id, winter)
	_lights.visible = winter
	for smoke in _smokes:
		smoke.emitting = false
	_since = LOOK_EVERY


static func _folder(store: PartStore, path: Array) -> int:
	var id: = 0
	for part_name: String in path:
		var next: = -1
		for child: int in store.nodes_under.get(id, PackedInt32Array()):
			if store.nodes[child]["n"] == part_name:
				next = child
				break
		if next < 0:
			return -1
		id = next
	return id


static func _roll(a: int, b: int) -> float:
	return float(rand_from_seed(hash([a, b]))[0] %100000) / 100000.0



static func _square() -> Vector3:
	var layout: Dictionary = Rbx.module("TownLayout")
	for feature: Dictionary in layout.get("features", []):
		if feature.get("kind", "") == "fountain":
			return Vector3(float(feature["x"]), 0, float(feature["z"]))
	return Vector3(-20, 0, 445)


func _make_lights(store: PartStore) -> void :
	var square: = _square()
	var places: Array[Transform3D] = []
	var colours: Array[Color] = []
	for row in store.rows_named("Gutter"):
		var at: = store.transform(row).orthonormalized()
		var length: = store.size(row).x
		var near: = Vector2(at.origin.x - square.x, at.origin.z - square.z).length() < SQUARE_REACH
		var seed_x: = int(at.origin.x * 2.0)
		var seed_z: = int(at.origin.z * 2.0)
		if _roll(seed_x, seed_z) >= (LIT_NEAR if near else LIT_FAR):
			continue
		var coloured: = _roll(seed_z, seed_x) < 0.3
		var count: = int(length / BULB_GAP)
		for index in count + 1:
			var x: = - length / 2.0 + 0.4 + index * (length - 0.8) / maxf(count, 1)
			var between: = fposmod(x + length / 2.0, HOOK_GAP) / HOOK_GAP
			var drop: = 0.45 + SAG * sin(between * PI)
			var colour: Color = COLOURS[index % COLOURS.size()] if coloured else WARM
			places.append(Transform3D(at.basis.scaled(Vector3.ONE * BULB), at * Vector3(x, - drop, 0.05)))
			colours.append(colour)
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = true
	multimesh.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	multimesh.instance_count = places.size()
	for index in places.size():
		multimesh.set_instance_transform(index, places[index])
		multimesh.set_instance_color(index, colours[index])
	_light_material = ShaderMaterial.new()
	_light_material.shader = load("res://shaders/fairy_lights.gdshader")
	_lights = MultiMeshInstance3D.new()
	_lights.name = "ChristmasLights"
	_lights.multimesh = multimesh
	_lights.material_override = _light_material
	_lights.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_lights.visible = false
	add_child(_lights)


func _make_smoke() -> GPUParticles3D:
	var rising: = ParticleProcessMaterial.new()
	rising.direction = Vector3(0, 1, 0)
	rising.spread = 8.0
	rising.initial_velocity_min = 1.6
	rising.initial_velocity_max = 2.6
	rising.gravity = World.WIND * 0.9 + Vector3(0, 0.25, 0)
	rising.damping_min = 0.2
	rising.damping_max = 0.4
	rising.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	rising.emission_sphere_radius = 0.4
	var grow: = Curve.new()
	grow.add_point(Vector2(0, 0.5))
	grow.add_point(Vector2(1, 4.0))
	var grow_texture: = CurveTexture.new()
	grow_texture.curve = grow
	rising.scale_curve = grow_texture
	var fade: = Gradient.new()
	fade.set_color(0, Color(0.62, 0.6, 0.6, 0.0))
	fade.set_color(1, Color(0.82, 0.83, 0.86, 0.0))
	fade.add_point(0.12, Color(0.58, 0.57, 0.57, 0.5))
	fade.add_point(0.5, Color(0.72, 0.72, 0.74, 0.28))
	var fade_texture: = GradientTexture1D.new()
	fade_texture.gradient = fade
	rising.color_ramp = fade_texture
	var puff: = QuadMesh.new()
	puff.size = Vector2(2.0, 2.0)
	var look: = StandardMaterial3D.new()
	look.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	look.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	look.vertex_color_use_as_albedo = true
	look.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	var soft: = GradientTexture2D.new()
	soft.fill = GradientTexture2D.FILL_RADIAL
	soft.fill_from = Vector2(0.5, 0.5)
	soft.fill_to = Vector2(1.0, 0.5)
	var edge: = Gradient.new()
	edge.set_color(0, Color(1, 1, 1, 1))
	edge.set_color(1, Color(1, 1, 1, 0))
	soft.gradient = edge
	look.albedo_texture = soft
	puff.material = look
	var smoke: = GPUParticles3D.new()
	smoke.amount = 20
	smoke.lifetime = 8.0
	smoke.preprocess = 8.0
	smoke.local_coords = false
	smoke.process_material = rising
	smoke.draw_pass_1 = puff
	smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	smoke.visibility_aabb = AABB(Vector3(-30, -5, -30), Vector3(60, 50, 60))
	return smoke


func _process(delta: float) -> void :
	if not _shown:
		return

	var daylight: = Sky3D.current.daylight() if Sky3D.current else 1.0
	_light_material.set_shader_parameter("energy", lerpf(6.0, 2.2, daylight))
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var eye: = camera.global_position
	var near: Array = []
	for top in _chimneys:
		var far: = Vector2(top.x - eye.x, top.z - eye.z).length()
		if far < SMOKE_REACH:
			near.append([far, top])
	near.sort_custom( func(a: Array, b: Array) -> bool: return a[0] < b[0])
	var most: int = 1 if Settings.quality <= Graphics.VERY_LOW else SMOKES[clampi(Settings.quality, 0, SMOKES.size() - 1)]
	var wanted: Array = []
	for index in mini(most, near.size()):
		wanted.append(near[index][1])

	var free: Array[GPUParticles3D] = []
	for smoke in _smokes:
		var at: = wanted.find(smoke.global_position)
		if smoke.emitting and at >= 0:
			wanted.remove_at(at)
		else:
			free.append(smoke)
	for smoke in free:
		if wanted.is_empty():
			smoke.emitting = false
			continue
		smoke.global_position = wanted.pop_back()
		smoke.restart()
		smoke.emitting = true
