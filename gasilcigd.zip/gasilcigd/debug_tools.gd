class_name DebugTools
extends Node







var _shot: = ""
var _frames: = 30
var _camera: Camera3D
var _fly: = false
var _yaw: = 0.0
var _pitch: = 0.0
var _extra: Array = []
var _scenario_data: Dictionary = {}


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--cam="):
			_place(arg.substr(6))
		elif arg.begins_with("--shot="):
			_shot = arg.substr(7)
		elif arg.begins_with("--frames="):
			_frames = int(arg.substr(9))
		elif arg.begins_with("--also="):

			var bits: = arg.substr(7).split(",")
			_extra.append([",".join(bits.slice(0, 6)), bits[6]])
		elif arg.begins_with("--seat="):
			_seat.call_deferred(arg.substr(7))
		elif arg.begins_with("--hold="):

			for action in arg.substr(7).split(","):
				Input.action_press(action)
		elif arg.begins_with("--at="):
			var n: = arg.substr(5).split_floats(",")
			( func() -> void : Game.local_player.teleport(Vector3(n[0], n[1], n[2]))).call_deferred()
		elif arg.begins_with("--orbit="):

			_orbit.call_deferred(arg.substr(8))
		elif arg.begins_with("--room="):

			_room.call_deferred(arg.substr(7))
		elif arg.begins_with("--scenario="):
			if has_method("_scenario_" + arg.substr(11)):
				call_deferred("_scenario_" + arg.substr(11))
		elif arg == "--fly":
			_fly = true
			_make_camera()
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if not _shot.is_empty():
		_take.call_deferred()
	if OS.get_cmdline_user_args().has("--audio-trace"):
		_audio_trace.call_deferred()


func _orbit(text: String) -> void :
	var bits: = text.split(",")
	var building: = _nearest_building(Vector3(120, 0, 40), bits[0])
	var angle: = deg_to_rad(float(bits[3])) if bits.size() > 3 else 0.0
	var from: = building.position + Vector3(sin(angle), 0, cos(angle)) * float(bits[1]) + Vector3(0, float(bits[2]) - building.position.y, 0)
	_make_camera()
	_camera.look_at_from_position(from, building.position)
	_camera.make_current()


func _room(text: String) -> void :
	var bits: = text.split(",")
	var house: = _nearest_building(Vector3(120, 0, 40), bits[0]) as House
	var room: Dictionary = house.rooms[bits[1]]
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var corner: Vector3 = house.lot * Vector3(low.x + 1.5, low.y + 6.5, low.z + 1.5)
	var middle: Vector3 = house.lot * Vector3((low.x + high.x) / 2, low.y + 3.5, (low.z + high.z) / 2)
	_make_camera()
	_camera.fov = 90
	_camera.look_at_from_position(corner, middle)
	_camera.make_current()



func _seat(text: String) -> void :
	var bits: = text.split(",")
	var vehicle: = Vehicle.named(bits[0])
	Game.station.set_door(int(vehicle.spec["bay"]), true)
	if bits.size() > 1:

		var index: = int(bits[1])
		vehicle.riders[index] = Game.local_player
		Game.local_player.sit(vehicle.seats[index])
		Game.local_player.set_attr("Vehicle", vehicle)
		Game.local_player.set_attr("Seat", index)
		var camera: = Game.local_player.camera
		camera.subject = vehicle
		camera.subject_height = float(vehicle.data["top"]) * 0.75
		camera.subject_distance = 16.0
		camera.yaw = vehicle.global_rotation.y
		for i in vehicle.seats.size():
			var turn: = (vehicle.global_basis.inverse() * vehicle.seats[i].global_basis).get_euler().y
			print("seat %d at %s: turned %.0f° from the vehicle" % [i, vehicle.seats[i].position, rad_to_deg(turn)])
	else:
		vehicle._board(Game.local_player, "DoorCabLeft")
	if OS.get_cmdline_user_args().has("--cab"):
		Game.local_player.camera.driver_view = true


func _make_camera() -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 6000.0
		_camera.near = 0.5
		_camera.fov = 70.0
		add_child(_camera)
		_camera.make_current()


func _place(text: String) -> void :
	_make_camera()
	var n: = text.split_floats(",")
	_camera.look_at_from_position(Vector3(n[0], n[1], n[2]), Vector3(n[3], n[4], n[5]))
	_camera.make_current()


func _take() -> void :
	var began: = Time.get_ticks_usec()
	var measuring: = OS.get_cmdline_user_args().has("--fps")
	if measuring:
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
		Engine.max_fps = 0
	var viewport: = get_viewport().get_viewport_rid()
	RenderingServer.viewport_set_measure_render_time(viewport, measuring)
	var cpu: = 0.0
	for frame in _frames:
		await get_tree().process_frame
		if measuring and frame >= _frames / 2:
			cpu += RenderingServer.viewport_get_measured_render_time_cpu(viewport)
	if measuring:
		var seconds: = (Time.get_ticks_usec() - began) / 1000000.0
		var counted: = _frames - _frames / 2
		print("fps: %.1f over %d frames; render cpu %.2f ms; draw calls %d, objects %d, primitives %d" % [
			_frames / seconds, _frames, cpu / counted, 
			RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME), 
			RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME), 
			RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME), 
		])
	if OS.get_cmdline_user_args().has("--no-hud"):
		_hide_hud()
	await RenderingServer.frame_post_draw
	if OS.get_cmdline_user_args().has("--hud-dump") and Hud.current:
		Hud.current._debug_dump()
	get_viewport().get_texture().get_image().save_png(_shot)
	for extra in _extra:
		_place(extra[0])
		for frame in 6:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(extra[1])
	Game.quit()



func _hide_hud() -> void :
	for layer in get_tree().root.find_children("*", "CanvasLayer", true, false):
		(layer as CanvasLayer).visible = false


func _unhandled_input(event: InputEvent) -> void :
	if _fly and event is InputEventMouseMotion:
		_yaw -= event.relative.x * 0.003
		_pitch = clampf(_pitch - event.relative.y * 0.003, -1.5, 1.5)
		_camera.rotation = Vector3(_pitch, _yaw, 0)


func _process(delta: float) -> void :
	if not _fly:
		return
	var move: = Vector3(
		Input.get_axis("move_left", "move_right"), 0, Input.get_axis("move_forward", "move_back")
	)
	var speed: = 400.0 if Input.is_action_pressed("sprint") else 80.0
	_camera.position += _camera.basis * move * speed * delta






func _nearest_building(at: Vector3, prefix: = "") -> Building:
	var best: Building = null
	var best_distance: = INF
	for building in FireService.current.buildings:
		if not prefix.is_empty() and not building.name.begins_with(prefix):
			continue
		var distance: = building.position.distance_to(at)
		if distance < best_distance:
			best = building
			best_distance = distance
	return best



func _scenario_fire() -> void :
	await get_tree().create_timer(0.5).timeout
	var player: = Game.local_player
	var wanted: = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
	var building: = _nearest_building(Vector3(120, 0, 40), wanted)
	print("scenario: fire at ", building.name, " ", building.position)
	CallService.current.hold = true
	FireService.current.run_incident(building)
	await get_tree().create_timer(0.3).timeout
	var flame_at: = building.position
	for flame in Flame.all:
		flame_at = flame.global_position
	var truck: = Vehicle.named("Fire Truck")

	var away: = Vector3(0, 0, 1)
	for angle in 8:
		var direction: = Vector3(sin(angle * PI / 4), 0, cos(angle * PI / 4))
		var hit: = Game.world.raycast(flame_at + Vector3(0, 4, 0), flame_at + Vector3(0, 4, 0) + direction * 70, World.LAYER_SOLID)
		if hit.is_empty():
			away = direction
			break
	var beside: = flame_at + away * 55
	beside.y = 3.0
	truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(away.x, away.z) + PI / 2), beside)
	truck.linear_velocity = Vector3.ZERO
	await get_tree().create_timer(0.5).timeout
	var stand: = flame_at + away * 26
	stand.y = 1.0
	player.teleport(stand)
	await get_tree().create_timer(0.3).timeout
	var hoses: = HoseService.current
	hoses._connect_line(hoses.lines[0], player)
	(hoses.lines[0]["hose"] as HoseLine).lay_to(player.global_position)
	var toward: = flame_at + Vector3(0, 1, 0) - player.head_position()
	player.camera.yaw = atan2( - toward.x, - toward.z)
	player.camera.pitch = asin(clampf(toward.normalized().y, -1, 1)) + 0.1
	_scenario_data = {"flame": flame_at, "away": away}
	if OS.get_cmdline_user_args().has("--side"):
		var middle: = (flame_at + stand) / 2.0
		var across: = away.cross(Vector3.UP)
		_make_camera()
		_camera.look_at_from_position(middle + across * 26 + Vector3(0, 9, 0), middle + Vector3(0, 3, 0))
		_camera.make_current()
	elif OS.get_cmdline_user_args().has("--close"):
		_make_camera()
		_camera.look_at_from_position(flame_at + away * 12 + Vector3(4, 5, 0), flame_at + Vector3(0, 2.5, 0))
		_camera.make_current()
	await get_tree().create_timer(0.4).timeout
	if not OS.get_cmdline_user_args().has("--dry"):
		Input.action_press("fire")





func _scenario_firelook() -> void :
	await get_tree().create_timer(0.5).timeout
	var wanted: = "House"
	var grow: = 15.0
	var prefix: = "/tmp/firelook"
	var stand_off: = 22.0
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
		elif arg.begins_with("--grow="):
			grow = float(arg.substr(7))
		elif arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--stand="):
			stand_off = float(arg.substr(8))
	var inside: = OS.get_cmdline_user_args().has("--inside")
	if inside and stand_off == 22.0:
		stand_off = 8.0
	var player: = Game.local_player
	var building: = _nearest_building(Vector3(40, 0, -60), wanted)
	print("firelook: ", building.name, " at ", building.position)
	CallService.current.hold = true
	FireService.current.run_incident(building)
	await get_tree().create_timer(grow).timeout
	var flame: Flame = null

	for each in Flame.all:
		if flame == null or each.global_position.y < flame.global_position.y - 0.5:
			flame = each
	if flame == null:
		print("firelook: no flame")
		Game.quit()
		return
	var at: = flame.global_position


	var out: = (at - building.position) * Vector3(1, 0, 1) * (-1.0 if inside else 1.0)
	var out_angle: = atan2(out.x, out.z) if out.length() > 0.5 else 0.0
	var away: = Vector3(0, 0, 1)
	var best: = -1.0
	for step in [0, 1, -1, 2, -2, 3, -3]:
		var angle: float = out_angle + step * PI / 10.0
		var direction: = Vector3(sin(angle), 0, cos(angle))
		var hit: = Game.world.raycast(at + Vector3(0, 1.5, 0), at + Vector3(0, 1.5, 0) + direction * stand_off, World.LAYER_SOLID)
		var free: = stand_off if hit.is_empty() else at.distance_to(hit["position"])
		if free > best + 2.0:
			best = free
			away = direction
	if OS.get_cmdline_user_args().has("--far"):

		_make_camera()
		_camera.fov = 60.0
		_camera.look_at_from_position(at + away * 240.0 + Vector3(0, 30, 0), at + Vector3(0, 35, 0))
		_camera.make_current()
		await get_tree().create_timer(2.0).timeout
		await _snap_to(prefix + "_far.png")
		Game.quit()
		return
	var stand: = at + away * minf(stand_off, best - 1.5)
	var truck: = Vehicle.named("Fire Truck")
	var beside: = at + away * (stand_off + 35.0)
	beside.y = at.y + 3.0 if not inside else 3.0
	truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(away.x, away.z) + PI / 2), Vector3(beside.x, 3.0, beside.z))
	truck.linear_velocity = Vector3.ZERO
	await get_tree().create_timer(0.5).timeout
	player.teleport(Vector3(stand.x, at.y + 0.5, stand.z))
	await get_tree().create_timer(0.4).timeout
	var hoses: = HoseService.current
	hoses._connect_line(hoses.lines[0], player)
	(hoses.lines[0]["hose"] as HoseLine).lay_to(player.global_position)
	var toward: = at + Vector3(0, 1, 0) - player.head_position()
	player.camera.yaw = atan2( - toward.x, - toward.z)
	player.camera.pitch = asin(clampf(toward.normalized().y, -1, 1)) + 0.12


	if inside:
		await get_tree().create_timer(1.0).timeout
		await _snap_to(prefix + "_before.png")

		Input.action_press("crouch")
		await get_tree().create_timer(1.2).timeout
		await _snap_to(prefix + "_crouch.png")
		Input.action_release("crouch")
		await get_tree().create_timer(0.8).timeout
		Input.action_press("fire")
		for stage: Array in [[1.2, "_spray1"], [3.0, "_spray2"], [6.0, "_spray3"]]:
			await get_tree().create_timer(stage[0]).timeout
			await _snap_to(prefix + stage[1] + ".png")
		Input.action_release("fire")
		await get_tree().create_timer(2.5).timeout
		await _snap_to(prefix + "_after.png")
		Game.quit()
		return
	_make_camera()
	var side: = away.cross(Vector3.UP)
	var eye: = player.head_position() + away * 5.0 - side * 3.5 + Vector3(0, 1.5, 0)
	_camera.fov = 60.0
	_camera.look_at_from_position(eye, at + Vector3(0, 2.0, 0))
	_camera.make_current()
	await get_tree().create_timer(1.0).timeout
	await _snap_to(prefix + "_before.png")
	await get_tree().process_frame
	Input.action_press("fire")
	for stage: Array in [[1.2, "_spray1"], [3.0, "_spray2"], [6.0, "_spray3"]]:
		await get_tree().create_timer(stage[0]).timeout
		await _snap_to(prefix + stage[1] + ".png")
	Input.action_release("fire")
	await get_tree().create_timer(2.5).timeout
	await _snap_to(prefix + "_after.png")
	print("firelook: done, %d flames left" % Flame.all.size())
	Game.quit()




func _scenario_smokelook() -> void :
	await get_tree().create_timer(0.5).timeout
	var wanted: = "Family house"
	var room_name: = "Kitchen"
	var prefix: = "/tmp/smokelook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
		elif arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--smoke-room="):
			room_name = arg.substr(13)
	var house: = _nearest_building(Vector3(120, 0, 40), wanted) as House
	var room: Dictionary = house.rooms[room_name]
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var middle: Vector3 = house.lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0)
	_make_camera()
	_camera.fov = 80
	var scorch_only: = OS.get_cmdline_user_args().has("--scorch")
	for level: float in [0.3, 0.6, 0.95]:
		if scorch_only:
			house.show_scorch(room_name, level)
		else:
			house.show_smoke(room_name, level)
		for height: Array in [[6.0, "stand"], [2.6, "crouch"]]:
			var corner: Vector3 = house.lot * Vector3(low.x + 1.2, low.y + height[0], low.z + 1.2)
			_camera.look_at_from_position(corner, Vector3(middle.x, low.y + height[0] - 0.5 + (house.lot.origin.y - house.lot.origin.y), middle.z))
			_camera.make_current()
			await get_tree().create_timer(0.6).timeout
			await _snap_to("%s_%d_%s.png" % [prefix, int(level * 100), height[1]])
	Game.quit()




func _scenario_flashlook() -> void :
	await get_tree().create_timer(0.5).timeout
	var wanted: = "Family house"
	var room_name: = "Kitchen"
	var prefix: = "/tmp/flashlook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
		elif arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--smoke-room="):
			room_name = arg.substr(13)
	var house: = _nearest_building(Vector3(120, 0, 40), wanted) as House
	CallService.current.hold = true
	FireService.current.run_incident(house)
	var room: Dictionary = house.rooms[room_name]
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var middle: Vector3 = house.lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0)
	var corner: Vector3 = house.lot * Vector3(low.x + 1.2, low.y + 5.0, low.z + 1.2)
	house.show_smoke(room_name, 0.7)
	_make_camera()
	_camera.fov = 80
	_camera.look_at_from_position(corner, middle)
	_camera.make_current()
	house.show_flashover(room_name, true)
	await get_tree().create_timer(1.0).timeout
	await _snap_to(prefix + "_warn1.png")
	await get_tree().create_timer(2.5).timeout
	await _snap_to(prefix + "_warn3.png")
	await get_tree().create_timer(0.5).timeout
	house.show_flashover(room_name, false)
	FireService.current._show_flash(house, room_name)
	await get_tree().create_timer(0.15).timeout
	await _snap_to(prefix + "_flash.png")
	await get_tree().create_timer(0.6).timeout
	await _snap_to(prefix + "_after.png")

	house.show_flashover(room_name, true)
	var out: = (middle - house.position) * Vector3(1, 0, 1)
	out = out.normalized() if out.length() > 0.1 else Vector3.FORWARD
	_camera.look_at_from_position(middle + out * 30.0 + Vector3(0, 6, 0), middle)
	await get_tree().create_timer(3.5).timeout
	house.show_flashover(room_name, false)
	FireService.current._show_flash(house, room_name)
	await get_tree().create_timer(0.3).timeout
	await _snap_to(prefix + "_outside.png")
	Game.quit()



func _scenario_collapselook() -> void :
	await get_tree().create_timer(0.5).timeout
	var wanted: = "House"
	var prefix: = "/tmp/collapse"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
		elif arg.begins_with("--shots="):
			prefix = arg.substr(8)
	var building: = _nearest_building(Vector3(40, 0, -60), wanted)
	_make_camera()
	_camera.fov = 60
	var at: = building.position
	_camera.look_at_from_position(at + Vector3(45, 28, 45), at + Vector3(0, 4, 0))
	_camera.make_current()
	await get_tree().create_timer(0.5).timeout
	await _snap_to(prefix + "_0.png")
	building.set_charred(true)
	for stage: Array in [[0.5, "_1"], [0.7, "_2"], [1.5, "_3"]]:
		await get_tree().create_timer(stage[0]).timeout
		await _snap_to(prefix + stage[1] + ".png")
	building.set_charred(false)
	await get_tree().create_timer(0.5).timeout
	await _snap_to(prefix + "_back.png")
	Game.quit()




func _scenario_doorlook() -> void :
	await get_tree().create_timer(1.0).timeout
	var wanted: = ""
	var prefix: = "/tmp/doorlook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--vehicle="):
			wanted = arg.substr(10)
		elif arg.begins_with("--shots="):
			prefix = arg.substr(8)
	var vehicle: Vehicle = Vehicle.named(wanted) if wanted != "" else Vehicle.all[Vehicle.all.size() - 1]
	var player: = Game.local_player

	var ahead: = - vehicle.global_basis.z
	var spot: = vehicle.global_position + ahead * (float(vehicle.data.get("length", 30.0)) * 0.5 + 4.0) - vehicle.global_basis.x * 5.0
	player.teleport(Vector3(spot.x, 1.0, spot.z))
	await get_tree().create_timer(3.0).timeout
	var toward: = vehicle.global_position + Vector3(0, 2, 0) - player.head_position()
	for turn in 4:
		player.camera.yaw = atan2( - toward.x, - toward.z) - 0.12 * turn
		player.camera.pitch = asin(clampf(toward.normalized().y, -1, 1))
		await get_tree().create_timer(1.0).timeout
		await _snap_to("%s_%d.png" % [prefix, turn])
	Game.quit()


func _snap_to(path: String) -> void :
	if OS.get_cmdline_user_args().has("--no-hud"):
		_hide_hud()
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)






func _scenario_cinematic() -> void :
	_hide_hud()
	var secs: = 12.0
	var wait: = 3.0
	var grow: = 20.0
	var burn: = ""
	var path: = PackedFloat64Array()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--secs="):
			secs = float(arg.substr(7))
		elif arg.begins_with("--wait="):
			wait = float(arg.substr(7))
		elif arg.begins_with("--grow="):
			grow = float(arg.substr(7))
		elif arg.begins_with("--burn="):
			burn = arg.substr(7)
		elif arg.begins_with("--path="):
			path = arg.substr(7).split_floats(",")
	_make_camera()
	_camera.fov = 55.0
	if OS.get_cmdline_user_args().has("--parade"):


		var x: = 14.0
		var back: = OS.get_cmdline_user_args().has("--parade-back")
		var gap: = 17.0
		var names: Array = ["Fire Truck", "Tanker", "Ladder Truck", "Command Vehicle"]
		for arg in OS.get_cmdline_user_args():
			if arg.begins_with("--parade-gap="):
				gap = float(arg.substr(13))
			elif arg.begins_with("--parade-only="):
				names = [arg.substr(14)]
		for vehicle_name in names:
			var vehicle: = Vehicle.named(vehicle_name)
			if vehicle == null:
				continue
			vehicle.global_transform = Transform3D(Basis(Vector3.UP, 0.0 if back else PI), Vector3(x, 3.0, -26.0 if back else -30.0))
			vehicle.linear_velocity = Vector3.ZERO
			vehicle.blue_on = true
			vehicle.headlights_on = true
			x -= gap
	var from_eye: Vector3
	var to_eye: Vector3
	var from_look: Vector3
	var to_look: Vector3
	if not burn.is_empty():
		var building: = _nearest_building(Vector3(40, 0, -60), burn)
		CallService.current.hold = true
		FireService.current.run_incident(building)
		_camera.look_at_from_position(building.position + Vector3(0, 80, 80), building.position)
		await get_tree().create_timer(grow).timeout
		var at: = building.position
		for flame in Flame.all:
			if flame.global_position.y < at.y + 40.0:
				at = flame.global_position

		var out: = (at - building.position) * Vector3(1, 0, 1)
		var out_angle: = atan2(out.x, out.z) if out.length() > 0.5 else 0.0
		var away: = Vector3(0, 0, 1)
		var best: = -1.0
		for step in [0, 1, -1, 2, -2, 3, -3]:
			var angle: float = out_angle + step * PI / 10.0
			var direction: = Vector3(sin(angle), 0, cos(angle))
			var hit: = Game.world.raycast(at + Vector3(0, 1.5, 0), at + Vector3(0, 1.5, 0) + direction * 30.0, World.LAYER_SOLID)
			var free: = 30.0 if hit.is_empty() else at.distance_to(hit["position"])
			if free > best + 2.0:
				best = free
				away = direction
		var side: = away.cross(Vector3.UP)
		var stand: = at + away * minf(20.0, best - 1.5)
		var truck: = Vehicle.named("Fire Truck")
		var park: = at + away * (minf(20.0, best - 1.5) + 14.0) + side * 9.0
		truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(away.x, away.z) + PI / 2), Vector3(park.x, 3.0, park.z))
		truck.linear_velocity = Vector3.ZERO
		truck.blue_on = true
		truck.headlights_on = true
		Game.local_player.teleport(Vector3(stand.x, at.y + 0.5, stand.z))
		await get_tree().create_timer(0.4).timeout
		HoseService.current._connect_line(HoseService.current.lines[0], Game.local_player)
		var toward: = at + Vector3(0, 1, 0) - Game.local_player.head_position()
		Game.local_player.camera.yaw = atan2( - toward.x, - toward.z)
		Game.local_player.camera.pitch = asin(clampf(toward.normalized().y, -1, 1)) + 0.12
		Input.action_press("fire")
		for label in get_tree().root.find_children("*", "Label3D", true, false):
			(label as Label3D).visible = false
		var head: = Game.local_player.head_position()
		from_eye = head + away * 5.0 - side * 3.5 + Vector3(0, 1.5, 0)
		to_eye = head + away * 7.0 + side * 0.5 + Vector3(0, 3.5, 0)
		from_look = at + Vector3(0, 2.0, 0)
		to_look = at + Vector3(0, 2.5, 0)
	else:
		from_eye = Vector3(path[0], path[1], path[2])
		from_look = Vector3(path[3], path[4], path[5])
		to_eye = Vector3(path[6], path[7], path[8])
		to_look = Vector3(path[9], path[10], path[11])
	_camera.look_at_from_position(from_eye, from_look)
	await get_tree().create_timer(wait).timeout
	var began: = 0.0
	while began < secs:
		await get_tree().process_frame
		began += get_process_delta_time()
		var t: = smoothstep(0.0, 1.0, began / secs)
		_camera.look_at_from_position(from_eye.lerp(to_eye, t), from_look.lerp(to_look, t))
	Game.quit()



func _scenario_drive() -> void :
	await get_tree().create_timer(0.5).timeout
	_seat("Fire Truck")
	var truck: = Vehicle.named("Fire Truck")
	await get_tree().create_timer(2.6).timeout
	Input.action_press("move_forward")
	for second in 14:
		if second == 4:
			Input.action_press("move_left")
		if second == 6:
			Input.action_release("move_left")
		if second == 11:
			Input.action_release("move_forward")
			Input.action_press("move_back")
		await get_tree().create_timer(1.0).timeout
		var up: = truck.global_basis.y
		if absf(truck.forward_speed) < 2.0 and second > 2:

			var space: = truck.get_world_3d().direct_space_state
			for height: float in [-1.5, -0.5, 1.0, 4.0]:
				for side: float in [-4.5, 0.0, 4.5]:
					var from: Vector3 = truck.global_transform * Vector3(side, height, -10.0)
					var to: Vector3 = truck.global_transform * Vector3(side, height, -17.5)
					var hit: = space.intersect_ray(PhysicsRayQueryParameters3D.create(from, to, World.LAYER_SOLID, [truck.get_rid()]))
					if not hit.is_empty():
						var row: = Game.world.row_hit(hit)
						print("   blocked at h=%.1f side=%.1f by %s size=%s at %s" % [height, side, Game.world.name_hit(hit), Game.store.size(row) if row >= 0 else Vector3.ZERO, hit["position"]])
		print("t=%d pos=(%.0f, %.1f, %.0f) speed=%.1f gear=%d rpm=%.0f tilt=%.2f" % [second + 1, truck.global_position.x, truck.global_position.y, truck.global_position.z, truck.forward_speed, truck.drive.gear, truck.drive.rpm, up.angle_to(Vector3.UP)])




func _scenario_face() -> void :
	await get_tree().create_timer(1.0).timeout
	var turn: = 0.0
	var off: = 3.2
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--face-turn="):
			turn = deg_to_rad(float(arg.substr(12)))
		elif arg.begins_with("--face-off="):
			off = float(arg.substr(11))
	var rig: = Game.local_player.rig
	if OS.get_cmdline_user_args().has("--face-bare"):
		var sheets: Dictionary = rig._shown.duplicate()
		for sheet: String in sheets.keys():
			if sheet.begins_with("visor") or sheet.begins_with("helmet"):
				sheets.erase(sheet)
		rig.wear(sheets)
	if OS.get_cmdline_user_args().has("--face-mask"):

		Game.local_player.set_attr("Scba", true)
		Game.local_player.set_attr("Mask", true)
		Game.local_player.set_attr("AirBar", Config.Air.Capacity)
		GearService.current.set_mask_worn(Game.local_player, true)
	var head: = rig.head.global_position
	var ahead: = - rig.global_basis.z.rotated(Vector3.UP, turn)
	_make_camera()
	_camera.near = 0.05
	_camera.look_at_from_position(head + ahead * off + Vector3(0, 0.2, 0), head)
	_camera.make_current()








func _scenario_gearlook() -> void :
	await get_tree().create_timer(1.5).timeout
	_hide_hud()
	var prefix: = "/tmp/gearlook"
	var suit_id: Variant = null
	var helmet: = "helmet"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--suit="):
			suit_id = arg.substr(7)
		elif arg.begins_with("--helmet="):
			helmet = arg.substr(9)
	var gear: = GearService.current
	var front: = float(Game.station.front) if Game.station else -50.0
	var spot: = Vector3(-27.0, 0.0, front + 22.0)
	var ground: = func(at: Vector3) -> Vector3:
		var hit: = Game.world.raycast(at + Vector3(0, 40, 0), at - Vector3(0, 80, 0), World.LAYER_SOLID)
		return hit["position"] if not hit.is_empty() else at
	var stand: = func(sheets: Dictionary, at: Vector3, turn: float) -> FirefighterRig:
		var rig: = FirefighterRig.new()
		rig.outfit = sheets
		rig.springs = false
		add_child(rig)
		rig.global_position = ground.call(at)
		rig.rotation.y = turn
		return rig

	var sheets: = gear.suit_sheets(suit_id)
	sheets[helmet] = true
	var one: FirefighterRig = stand.call(sheets, spot, PI)
	_make_camera()
	_camera.near = 0.05
	var o: = one.global_position
	var looks: = {
		"front": [o + Vector3(1.5, 4.2, 9.0), o + Vector3(0, 3.0, 0)], 
		"side": [o + Vector3(-9.5, 4.0, 0.3), o + Vector3(0, 3.0, 0)], 
		"back": [o + Vector3(-1.5, 4.2, -9.0), o + Vector3(0, 3.0, 0)], 
		"left": [o + Vector3(8.0, 4.4, 4.5), o + Vector3(0, 3.4, 0)], 
		"helmet_side": [o + Vector3(-4.2, 5.05, 0.3), o + Vector3(0, 4.95, 0.3)], 
		"helmet_front": [o + Vector3(0.9, 5.4, 3.3), o + Vector3(0, 5.0, 0)], 
		"helmet_back": [o + Vector3(-1.6, 6.2, -3.0), o + Vector3(0, 5.0, 0)], 
	}
	for what: String in looks:
		var pair: Array = looks[what]
		_camera.look_at_from_position(pair[0], pair[1])
		for frame in 6:
			await get_tree().process_frame
		await _snap_to("%s_%s.png" % [prefix, what])
	one.queue_free()

	var row: Array = []
	for rank: Dictionary in Config.Gear.Ranks:
		var with_helmet: = gear.suit_sheets(null)
		with_helmet[rank["sheet"] if gear.has_sheet(rank["sheet"]) else "helmet"] = true
		row.append(with_helmet)
	for suit: Dictionary in Config.Gear.Suits:
		var dressed: = gear.suit_sheets(suit["id"])
		dressed["helmet"] = true
		row.append(dressed)
	var made: Array = []
	for index in row.size():
		made.append(stand.call(row[index], spot + Vector3((index - (row.size() - 1) / 2.0) * 3.6, 0, 0), PI))
	_camera.look_at_from_position(spot + Vector3(0, 6.5, 26.0), spot + Vector3(0, 3.2, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_row.png" % prefix)
	for rig: FirefighterRig in made:
		rig.queue_free()

	var civil: FirefighterRig = stand.call({"civil": true}, spot + Vector3(-2.0, 0, 0), PI)
	var officer: = PoliceOfficer.new(1)
	add_child(officer)
	officer.global_position = ground.call(spot + Vector3(2.0, 0, 0))
	officer.rotation.y = PI
	var back_civil: FirefighterRig = stand.call({"civil": true}, spot + Vector3(-2.0, 0, -5.0), 0.0)
	_camera.look_at_from_position(spot + Vector3(0, 4.2, 10.5), spot + Vector3(0, 3.0, -2.0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_civil.png" % prefix)
	_camera.look_at_from_position(spot + Vector3(1.0, 4.2, -14.0), spot + Vector3(0, 3.0, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_civil_back.png" % prefix)
	civil.queue_free()
	back_civil.queue_free()
	officer.queue_free()

	var player: = Game.local_player
	player.teleport(ground.call(spot) + Vector3(0, 0.2, 0))
	gear._gear_up(player, suit_id, true)
	await get_tree().create_timer(0.6).timeout
	var at: = player.rig.global_position + Vector3(0, 2.4, 0)
	var ahead: = - player.rig.global_basis.z
	var right: = player.rig.global_basis.x
	_camera.look_at_from_position(at + ahead * 9.0 + right * 2.0 + Vector3(0, 1.5, 0), at + Vector3(0, 0.6, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_player.png" % prefix)
	player.set_attr("Scba", true)
	player.set_attr("Mask", true)
	player.set_attr("AirBar", Config.Air.Capacity)
	gear.set_mask_worn(player, true)
	await get_tree().create_timer(0.6).timeout
	print("gearlook: player sheets %s" % str(player.rig.shown_sheets()))
	_camera.look_at_from_position(at + ahead * 7.0 + right * 2.5 + Vector3(0, 2.2, 0), at + Vector3(0, 1.0, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_player_mask.png" % prefix)
	_camera.look_at_from_position(at - ahead * 7.5 + right * 3.0 + Vector3(0, 2.0, 0), at + Vector3(0, 0.6, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_player_back.png" % prefix)
	var head: = player.rig.head.global_position
	_camera.look_at_from_position(head + ahead * 3.0 + right * 1.3 + Vector3(0, 0.3, 0), head + Vector3(0, -0.5, 0))
	for frame in 6:
		await get_tree().process_frame
	await _snap_to("%s_player_face.png" % prefix)
	Game.quit()





func _scenario_policelook() -> void :
	await get_tree().create_timer(1.0).timeout
	var prefix: = "/tmp/policelook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)

	var best: Dictionary = {}
	for segment: Dictionary in NavGraph.current.segments:
		if segment["kind"] == "lane" and (best.is_empty() or float(segment["length"]) > float(best["length"])):
			best = segment
	var s: = NavGraph.sample(best, float(best["length"]) * 0.5)
	var y: = AmbulanceService.current.ground_at(s.x, s.y) if AmbulanceService.current else 0.25
	var park: = Transform3D(Basis.looking_at(Vector3(s.z, 0, s.w)), Vector3(s.x, y, s.y))
	ScenePolice.stay = true

	ScenePolice.current.visit = {"id": 1, "park": park, "way_in": PackedVector3Array(), "t_in": HostClock.now() + 1000.0, 
		"way_out": PackedVector3Array(), "t_out": -1.0, "seg": int(best["id"]), "along": 0.0, "aside": Vector3( - s.w, 0, s.z)}
	if Traffic.current:
		Traffic.current.process_mode = Node.PROCESS_MODE_DISABLED
	Game.local_player.teleport(park.origin + park.basis.z * 60.0 + Vector3(0, 2, 0))
	await get_tree().create_timer(1.0).timeout
	var o: = park.origin
	var x: = park.basis.x
	var z: = park.basis.z
	var looks: = {
		"front": [o - z * 15.0 + x * 7.0 + Vector3(0, 5, 0), o + Vector3(0, 2.5, 0)], 
		"side": [o + x * 17.0 - z * 1.0 + Vector3(0, 3.5, 0), o + Vector3(0, 2.5, 0)], 
		"back": [o + z * 15.0 - x * 6.0 + Vector3(0, 5, 0), o + Vector3(0, 2.5, 0)], 
		"other": [o - x * 15.0 - z * 8.0 + Vector3(0, 5, 0), o + Vector3(0, 2.5, 0)], 
		"top": [o - z * 9.0 + x * 8.0 + Vector3(0, 15, 0), o + Vector3(0, 1.5, 0)], 
		"far": [o + x * 30.0 + z * 22.0 + Vector3(0, 10, 0), o + Vector3(0, 2.5, 0)], 
	}
	_make_camera()
	for what: String in looks:
		var pair: Array = looks[what]
		if what == "far":
			ScenePolice.current.visit["t_in"] = HostClock.now() - 10.0
		_camera.look_at_from_position(pair[0], pair[1])
		_camera.make_current()
		for frame in 8:
			await get_tree().process_frame
		await _snap_to("%s_%s.png" % [prefix, what])
	Game.quit()








func _scenario_fleetlook() -> void :
	await get_tree().create_timer(1.0).timeout
	var prefix: = "/tmp/fleetlook"
	var wanted: = ""
	var args: = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--vehicle="):
			wanted = arg.substr(10)
	if Traffic.current:
		Traffic.current.process_mode = Node.PROCESS_MODE_DISABLED
	var spot: = Transform3D(Basis.IDENTITY, Vector3(-21, 3.0, -14))
	var parked: = args.has("--parked")
	Game.local_player.teleport(Vector3(40, 2, -20))
	_make_camera()
	for vehicle: Vehicle in Vehicle.all.duplicate():
		if wanted != "" and vehicle.spec["name"] != wanted:
			continue
		if parked:
			await _parked_looks(vehicle, prefix)
			continue

		for other: Vehicle in Vehicle.all:
			if other != vehicle:
				other.global_position = Vector3(400 + 40 * Vehicle.all.find(other), 3, 400)
		vehicle.global_transform = Transform3D(Basis.IDENTITY, spot.origin + Vector3(0, float(vehicle.data["axleY"]), 0))
		vehicle.linear_velocity = Vector3.ZERO
		vehicle.headlights_on = args.has("--lit")
		vehicle.blue_on = args.has("--lit")
		vehicle.arrows = 1 if args.has("--arrows") else 0
		if args.has("--mast"):
			var trucks: = get_tree().root.find_child("TruckService", true, false) as TruckService
			if trucks and trucks._masts.has(vehicle):
				trucks.set_mast(vehicle, true)
				await get_tree().create_timer(float(Config.Truck.Mast.Time) + 0.5).timeout
		if args.has("--open"):
			for door_name: String in vehicle.doors:
				vehicle.set_door(door_name, true)
			vehicle.set_lockers(true)
		await get_tree().create_timer(1.5).timeout
		var o: = vehicle.global_position
		o.y = spot.origin.y
		var length: = float(vehicle.data["rear"]) - float(vehicle.data["front"])
		var r: = maxf(length * 1.15, 18.0)
		var nose: = o + Vector3(0, 0, float(vehicle.data["front"]))
		var tail: = o + Vector3(0, 0, float(vehicle.data["rear"]))
		var wheel: Dictionary = vehicle.wheels[0]
		var hub: Vector3 = wheel["hub"].global_position
		var looks: = {
			"front": [o + Vector3(r * 0.45, r * 0.2, - r * 0.85), o + Vector3(0, 2, - length * 0.2)], 
			"side": [o + Vector3( - r * 1.05, 4, 0), o + Vector3(0, 3, 0)], 
			"back": [o + Vector3( - r * 0.45, r * 0.25, r * 0.85), o + Vector3(0, 3, 0)], 
			"other": [o + Vector3(r * 1.05, 6, - r * 0.2), o + Vector3(0, 3, 0)], 
			"top": [o + Vector3(r * 0.35, r * 0.8, r * 0.4), o], 
			"low": [nose + Vector3(-4, 0.5, -9), nose + Vector3(0, 1.5, 0)], 
			"rear": [tail + Vector3(4, 4, 10), tail + Vector3(0, 3, 0)], 
			"wheel": [hub + Vector3(-7, 1.5, -3), hub], 
			"inside_l": [o + Vector3(-8.5, 4.2, 6.7), o + Vector3(-1.5, 3.4, 6.7)], 
			"inside_r": [o + Vector3(8.5, 4.2, 6.7), o + Vector3(1.5, 3.4, 6.7)], 
			"inside_front": [o + Vector3(-6.5, 3.2, 3.5), o + Vector3(0.0, 2.2, -0.3)], 
			"beacon": [o + Vector3(4.5, float(vehicle.data["top"]) + 2.5, float(vehicle.data["front"]) - 5.5), o + Vector3(0, float(vehicle.data["top"]) + 0.2, float(vehicle.data["front"]) + 2.0)], 
			"cab": [vehicle.global_transform * (vehicle.seats[0].position + Vector3(0, float(vehicle.spec["eyeHeight"]) - vehicle.seats[0].position.y, - float(vehicle.spec["eyeLead"]))), 
				vehicle.global_transform * (vehicle.seats[0].position + Vector3(0.6, float(vehicle.spec["eyeHeight"]) - vehicle.seats[0].position.y - 1.2, -10))], 
		}
		for what: String in looks:
			var pair: Array = looks[what]
			_camera.fov = 75.0 if what == "cab" else 55.0
			_camera.near = 0.05
			_camera.look_at_from_position(pair[0], pair[1])
			_camera.make_current()
			for frame in 6:
				await get_tree().process_frame
			await _snap_to("%s_%s_%s.png" % [prefix, String(vehicle.name), what])
	if args.has("--town"):
		await _townlook(prefix, spot.origin)
	Game.quit()




func _parked_looks(vehicle: Vehicle, prefix: String) -> void :
	await get_tree().create_timer(1.5).timeout
	var front: = float(vehicle.data["front"])
	var top: = float(vehicle.data["top"])
	var w: = float(vehicle.data["halfWidth"])
	var looks: = {
		"near": [Vector3(w + 6.0, 4.6, front + 1.0), Vector3(0, 2.2, front + 7.0)], 
		"near_front": [Vector3(w + 3.0, 5.0, front - 6.0), Vector3(0, 2.0, front + 3.0)], 
		"near_roof": [Vector3(w + 4.0, top + 3.5, front + 2.0), Vector3(0, top, front + 9.0)], 
		"near_door": [Vector3(w + 4.5, 4.0, front + 6.5), Vector3(w, 2.5, front + 6.5)], 
		"near_rear": [Vector3( - w - 5.0, 5.0, - front + 3.0), Vector3(0, 2.5, - front - 6.0)], 
	}
	for what: String in looks:
		var pair: Array = looks[what]
		_camera.fov = 70.0
		_camera.near = 0.05
		_camera.look_at_from_position(vehicle.global_transform * (pair[0] as Vector3), vehicle.global_transform * (pair[1] as Vector3))
		_camera.make_current()
		for frame in 6:
			await get_tree().process_frame
		await _snap_to("%s_%s_%s.png" % [prefix, String(vehicle.name), what])






func _scenario_drivelook() -> void :
	await get_tree().create_timer(1.0).timeout
	var prefix: = "/tmp/drivelook"
	var wanted: = "Fire Truck"
	var args: = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--vehicle="):
			wanted = arg.substr(10)
	var vehicle: = Vehicle.named(wanted)
	Game.station.set_door(int(vehicle.spec["bay"]), true)
	vehicle._board(Game.local_player, "DoorCabLeft")
	await get_tree().create_timer(2.5).timeout
	if args.has("--lit"):
		vehicle.headlights_on = true
		vehicle.blue_on = true
	var steps: Array = [
		["out", "move_forward", 2.2], ["road", "move_forward", 2.0], ["turn", "move_forward,move_right", 1.2], 
		["beside", "move_forward", 0.6], ["brake", "move_back", 0.5], ["stop", "move_back", 2.5], ["reverse", "move_back", 2.0], 
	]
	for step: Array in steps:
		for action in String(step[1]).split(","):
			Input.action_press(action)
		await get_tree().create_timer(step[2]).timeout
		if step[0] == "beside":
			_make_camera()
			var side: = vehicle.global_basis.x
			_camera.fov = 60.0
			_camera.look_at_from_position(vehicle.global_position + side * 22.0 + vehicle.global_basis.z * 4.0 + Vector3(0, 3, 0), vehicle.global_position + Vector3(0, 1, 0))
			_camera.make_current()
		await _snap_to("%s_%s.png" % [prefix, step[0]])
		if step[0] == "beside":
			Game.local_player.camera.camera.make_current()
		for action in String(step[1]).split(","):
			Input.action_release(action)
		print("drivelook %s: speed %.1f gear %d rpm %.0f brake %.2f reverse %s at %s" % [step[0], vehicle.forward_speed, vehicle.drive.gear, vehicle.drive.rpm, vehicle.drive.brake, vehicle.drive.reverse, vehicle.global_position.snapped(Vector3.ONE)])
	Game.quit()




func _scenario_pvkit() -> void :
	await get_tree().create_timer(1.5).timeout
	var player: = Game.local_player
	var command: = Vehicle.named("Command Vehicle")
	GearService.current._gear_up(player, null, true)
	await get_tree().create_timer(0.5).timeout
	var air: = AirService.current
	print("pvkit: sets in the PV-1 %d; Set1 shown %s" % [air.pool["command"], command.props["Set1"]["node"].visible])
	air.take_set(player, "command")
	print("pvkit: after taking: wearing %s, left %d, Set2 shown %s" % [air.sets.has(player), air.pool["command"], command.props["Set2"]["node"].visible])
	air._on_set_prompt(player, "command")
	print("pvkit: put back: wearing %s, left %d" % [air.sets.has(player), air.pool["command"]])
	var tools: = ToolService.current
	for item: Dictionary in tools.items:
		if item["vehicle"] == command and item["name"] == "Extinguisher":
			tools._on_line(player, item)
			await get_tree().create_timer(0.3).timeout
			print("pvkit: extinguisher from the PV-1's locker: in hand '%s', stowed one shown %s" % [tools.held(player), command.props["Extinguisher1"]["node"].visible])
			tools._on_line(player, item)
			await get_tree().create_timer(0.3).timeout
			print("pvkit: put back: in hand '%s', stowed shown %s" % [tools.held(player), command.props["Extinguisher1"]["node"].visible])
		if item["vehicle"] == command and item["name"] == "Thermal camera":
			tools._on_line(player, item)
			await get_tree().create_timer(0.3).timeout
			print("pvkit: thermal camera from the PV-1's locker: in hand '%s'" % tools.held(player))
			tools._on_line(player, item)
			await get_tree().create_timer(0.3).timeout

	for item: Dictionary in Cordon.current.items:
		if item["truck"] == command and item["name"] == "First aid kit":
			item["line"].chosen.emit(player)
			await get_tree().create_timer(0.3).timeout
			print("pvkit: first aid kit from the PV-1: carried %s, stowed shown %s" % [CallGear.has(player, "First aid kit"), item["stowed"].visible])
			item["line"].chosen.emit(player)
			await get_tree().create_timer(0.3).timeout
			print("pvkit: put back: carried %s, stowed shown %s" % [CallGear.has(player, "First aid kit"), item["stowed"].visible])
	Game.quit()



func _scenario_nozzlelook() -> void :
	await get_tree().create_timer(1.0).timeout
	var prefix: = "/tmp/nozzlelook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
	var holder: = Node3D.new()
	add_child(holder)
	holder.global_position = Vector3(-21, 4, -20)
	var nozzle: = Nozzle.new()
	holder.add_child(nozzle)
	_make_camera()
	_camera.near = 0.05
	_camera.fov = 40.0
	var o: = holder.global_position + Vector3(0, 0, -0.6)
	for look: Array in [["side", Vector3(-4.2, 0.6, -0.4)], ["front", Vector3(-2.2, 1.0, -3.4)], ["back", Vector3(2.2, 1.6, 3.0)]]:
		_camera.look_at_from_position(o + look[1], o)
		_camera.make_current()
		for frame in 4:
			await get_tree().process_frame
		await _snap_to("%s_%s.png" % [prefix, look[0]])
	Game.quit()




func _scenario_trafficlook() -> void :
	await get_tree().create_timer(4.0).timeout
	var prefix: = "/tmp/trafficlook"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
	_make_camera()
	_camera.fov = 60.0
	var shot: = 0
	var view: = TrafficView.current
	for record: TrafficView.Drawn in view.drawn.values():
		if shot >= 4:
			break
		if record.model == null or record.car.kind == "bus" and shot > 0:
			continue
		for look: String in ["behind", "ahead"]:
			var place: = record.model.global_transform
			var along: = place.basis.z if look == "behind" else - place.basis.z
			_camera.look_at_from_position(place.origin + along * 22.0 + place.basis.x * 7.0 + Vector3(0, 6, 0), place.origin + Vector3(0, 2, 0))
			_camera.make_current()
			for frame in 3:
				await get_tree().process_frame
			await _snap_to("%s_%d_%s.png" % [prefix, shot, look])
		shot += 1
	Game.quit()





func _scenario_coachlook() -> void :
	await get_tree().create_timer(2.0).timeout
	var prefix: = "/tmp/coachlook"
	var livery: = 1
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
		elif arg.begins_with("--livery="):
			livery = int(arg.substr(9))
	var traffic: = Traffic.current
	if traffic == null or traffic.bus_stop.is_empty():
		push_error("coachlook: no bus stop")
		Game.quit()
		return
	traffic.process_mode = Node.PROCESS_MODE_DISABLED
	if TrafficView.current:
		TrafficView.current.visible = false
	var lane: Dictionary = traffic.segments[traffic.bus_stop["lane"]]
	var at: float = traffic.bus_stop["at"]
	var ahead: = NavGraph.sample_position(lane, at + 1.0) - NavGraph.sample_position(lane, at - 1.0)
	var middle: = NavGraph.sample_position(lane, at, Traffic.ROAD)
	var bus: = MeshInstance3D.new()
	bus.mesh = BusBody.body_mesh(livery)
	bus.material_override = BusBody.paint()
	for piece: Dictionary in BusBody.pieces(livery):
		if piece.has("text"):
			bus.add_child(BusBody.letter(piece))
		if piece.has("lamp"):

			var lamp: = MeshInstance3D.new()
			lamp.mesh = BusBody.unit(piece)
			lamp.transform = BusBody.stretch(piece)
			var paint: = StandardMaterial3D.new()
			paint.albedo_color = piece["color"]
			lamp.material_override = paint
			bus.add_child(lamp)
	add_child(bus)
	bus.global_transform = Transform3D(Basis(Vector3.UP, atan2( - ahead.x, - ahead.z)), middle)
	_make_camera()
	_camera.fov = 55.0
	var place: = bus.global_transform
	var looks: = {
		"front": [Vector3(9, 8, -46), Vector3(0, 5, -20)], 
		"right": [Vector3(30, 7, -6), Vector3(0, 5, -2)], 
		"back": [Vector3(-9, 8, 46), Vector3(0, 5, 20)], 
		"left": [Vector3(-30, 7, 4), Vector3(0, 5, 2)], 
		"rear_left": [Vector3(-22, 6, 36), Vector3(0, 5, 12)], 
		"arch": [Vector3(-12, 3.5, -8), Vector3(0, 3, -13.5)], 
		"station": [Vector3(70, 40, -50), Vector3(0, 0, 0)], 
	}
	for what: String in looks:
		var pair: Array = looks[what]
		_camera.look_at_from_position(place * pair[0], place * pair[1])
		_camera.make_current()
		for frame in 6:
			await get_tree().process_frame
		await _snap_to("%s_%s.png" % [prefix, what])
	Game.quit()



func _townlook(prefix: String, at: Vector3) -> void :
	for vehicle: Vehicle in Vehicle.all:
		vehicle.global_position = Vector3(400 + 40 * Vehicle.all.find(vehicle), 3, 400)
	var ground: = at.y - 2.8
	var row: = Node3D.new()
	add_child(row)
	var x: = -36.0
	var shapes: = CarKit.shapes()
	for index in shapes.size():
		var car: = CarKit.build(shapes[index], CarKit.paint_of(index + 1))
		row.add_child(car)
		car.global_position = Vector3(at.x + x, ground, at.z)
		x += 11.0

	var bus: = MeshInstance3D.new()
	bus.mesh = BusBody.body_mesh(2)
	bus.material_override = BusBody.paint()
	row.add_child(bus)
	for piece: Dictionary in BusBody.pieces(2):
		if piece.has("text"):
			bus.add_child(BusBody.letter(piece))
	x += 8.0
	var bx: = at.x + x
	bus.global_position = Vector3(bx, ground, at.z)
	x += 22.0
	var ambulance: = Ambulance.new()
	row.add_child(ambulance)
	var ax: = at.x + x + 2.0
	ambulance.global_position = Vector3(ax, ground, at.z)
	await get_tree().create_timer(0.5).timeout
	var nose: = at.z + BusBody.FRONT
	var tail: = at.z + BusBody.BACK
	var looks: = {
		"cars": [Vector3(at.x - 20, ground + 10, at.z - 26), Vector3(at.x - 16, ground + 2, at.z)], 
		"cars_back": [Vector3(at.x - 20, ground + 9, at.z + 26), Vector3(at.x - 16, ground + 2, at.z)], 
		"bus": [Vector3(bx + 34, ground + 12, at.z - 46), Vector3(bx, ground + 4, at.z)], 
		"ambulance": [Vector3(ax + 10, ground + 8, at.z - 22), Vector3(ax - 3, ground + 3, at.z)], 
		"car_close": [Vector3(at.x - 30, ground + 4, at.z - 11), Vector3(at.x - 36, ground + 2, at.z)], 
		"car_rear": [Vector3(at.x - 33, ground + 3.5, at.z + 15), Vector3(at.x - 36, ground + 1.8, at.z + 7.5)], 
		"bus_front": [Vector3(bx - 9, ground + 7, nose - 20), Vector3(bx, ground + 5, nose)], 
		"bus_side": [Vector3(bx + 17, ground + 6, at.z - 4), Vector3(bx, ground + 5, at.z)], 
		"bus_back": [Vector3(bx - 9, ground + 7, tail + 20), Vector3(bx, ground + 5, tail)], 
		"amb_side": [Vector3(ax + 26, ground + 6, at.z + 4), Vector3(ax, ground + 3.5, at.z)], 
		"amb_back": [Vector3(ax + 9, ground + 7, at.z + 24), Vector3(ax, ground + 3.5, at.z)], 
		"amb_front": [Vector3(ax - 8, ground + 5, at.z - 22), Vector3(ax, ground + 3.5, at.z)], 
	}
	for what: String in looks:
		var pair: Array = looks[what]
		_camera.fov = 55.0
		_camera.look_at_from_position(pair[0], pair[1])
		for frame in 6:
			await get_tree().process_frame
		await _snap_to("%s_town_%s.png" % [prefix, what])




func _audio_trace() -> void :
	while true:
		await get_tree().create_timer(3.0).timeout
		var camera: = get_viewport().get_camera_3d()
		var heard: Array = []
		for node in get_tree().root.find_children("*", "AudioStreamPlayer3D", true, false):
			var player: = node as AudioStreamPlayer3D
			if not player.playing or player.stream == null or camera == null:
				continue
			var distance: = camera.global_position.distance_to(player.global_position)
			var falloff: = 0.0 if distance <= player.unit_size else linear_to_db(player.unit_size / distance)
			heard.append([player.volume_db + falloff + AudioServer.get_bus_volume_db(AudioServer.get_bus_index(player.bus)), "3d %5.1f studs unit %4.0f" % [distance, player.unit_size], player])
		for node in get_tree().root.find_children("*", "AudioStreamPlayer", true, false):
			var player: = node as AudioStreamPlayer
			if player.playing and player.stream != null:
				heard.append([player.volume_db + AudioServer.get_bus_volume_db(AudioServer.get_bus_index(player.bus)), "flat bus " + player.bus, player])
		heard.sort_custom( func(a: Array, b: Array) -> bool: return a[0] > b[0])
		print("audio at %.0f s:" % Game.now())
		for entry: Array in heard.slice(0, 14):
			var player: Node = entry[2]
			print("  %6.1f dB  %-30s %-34s %s" % [entry[0], entry[1], player.stream.resource_path.get_file(), player.get_parent().name])












func _scenario_fpv() -> void :
	await get_tree().create_timer(1.0).timeout
	var player: = Game.local_player
	var names: PackedStringArray = []
	var prefix: = ""
	var args: = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--fpv="):
			names = arg.substr(6).split(",")
		elif arg.begins_with("--fpv-shots="):
			prefix = arg.substr(12)
		elif arg.begins_with("--fpv-pitch="):
			player.camera.pitch = deg_to_rad(float(arg.substr(12)))
		elif arg.begins_with("--fpv-turn="):
			player.camera.yaw += deg_to_rad(float(arg.substr(11)))
	player.camera.wanted_distance = 0.0
	if args.has("--fpv-walk"):
		Input.action_press("move_forward")
	for thing: String in names:
		var item: = {}
		if thing == "nozzle":
			HoseService.current._connect_line(HoseService.current.lines[0], player)
		else:
			for one: Dictionary in ToolService.current.items:
				if one["name"] == thing and one["holder"] == null and not one["standing"]:
					item = one
			if item.is_empty():
				print("fpv: no %s to take" % thing)
				continue
			ToolService.current._on_line(player, item)
		await get_tree().create_timer(0.8).timeout
		if args.has("--fpv-swing") and not item.is_empty():

			ToolService.current._swing(item, player)
			for step in 6:
				await get_tree().create_timer(float(Config.Tools.SwingTime) / 6.0).timeout
				var eyes: = player.camera.camera.global_transform.affine_inverse()
				print("fpv: swing %d/6, hand at %s from the eyes" % [step + 1, (eyes * player.rig.hand_right.global_position).snappedf(0.01)])
				if step == 1:
					await _fpv_shot(prefix + "_" + thing.replace(" ", "_").to_lower() + "_swing.png")
			await get_tree().create_timer(0.3).timeout
		if args.has("--fpv-work"):
			Input.action_press("fire")
			await get_tree().create_timer(1.2).timeout
		var base: = prefix + "_" + thing.replace(" ", "_").to_lower()
		if args.has("--fpv-sweep") or args.has("--fpv-still"):
			await _fpv_sweep(base, args.has("--fpv-still"))
		await _fpv_shot(base + ".png")
		if args.has("--fpv-burst"):

			for frame in 3:
				await _fpv_shot(base + "_%d.png" % (frame + 1))
		if args.has("--fpv-out"):
			player.camera.wanted_distance = 16.0
			await get_tree().create_timer(0.8).timeout
			await _fpv_shot(base + "_out.png")
			player.camera.wanted_distance = 0.0
		Input.action_release("fire")
		print("fpv: %s in hand, hold '%s', first person %s, rig shown %s" % [thing, player.rig.hold, player.camera.first_person(), player.rig.visible])
		if thing == "nozzle":
			HoseService.current.disconnect_line(HoseService.current.lines[0])
		else:
			ToolService.current._on_line(player, item)
		await get_tree().create_timer(0.5).timeout
	if not names.is_empty() and not prefix.is_empty():
		Game.quit()




func _fpv_sweep(base: String, still: = false) -> void :
	var player: = Game.local_player
	var moves: Array = []
	var steps: = [[30, Vector2(-12, 0)], [60, Vector2(12, 0)], [30, Vector2(-12, 0)], [25, Vector2(0, -10)], 
		[50, Vector2(0, 10)], [25, Vector2(0, -10)], [6, Vector2(90, 0)], [6, Vector2(-90, 0)], [20, Vector2.ZERO]]
	for step: Array in [[90, Vector2.ZERO]] if still else steps:
		for i in step[0]:
			moves.append(step[1])
	var camera: = player.camera.camera
	for index in moves.size():
		var motion: = InputEventMouseMotion.new()
		motion.relative = moves[index]
		Input.parse_input_event(motion)
		await get_tree().process_frame
		var held: Node3D = null
		for child in player.rig.hand_right.get_children():
			if child is Node3D and child.visible:
				held = child
		if held == null:
			continue
		var grip: = camera.unproject_position(player.rig.hand_right.global_position)
		var tip: = camera.unproject_position(held.global_position - held.global_basis.z * 1.5)
		print("fpv sweep %d move %s yaw %.3f pitch %.3f grip %s tip %s" % [index, moves[index], player.camera.yaw, player.camera.pitch, grip.round(), tip.round()])
		if index % 15 == 0:
			await _fpv_shot(base + "_sweep_%03d.png" % index)


func _fpv_shot(path: String) -> void :
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)
	print("fpv: shot ", path)
