class_name SnowCover
extends Node













const PIXELS: = 2048
const MARGIN: = 160.0
const LAYER: = 1 << 19
const OFFSET: = 100.0

static var current: SnowCover

var done: = false
var _viewport: SubViewport
var _frames: = 0
var _taken_winter: = false


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	Style.current.changed.connect( func(_style: int) -> void : _want())

	_want.call_deferred()


func _want() -> void :
	if _viewport == null and ( not done or _taken_winter != Style.winter()):
		_take()



static func area() -> Rect2:
	var low: = Vector2(INF, INF)
	var high: = Vector2( - INF, - INF)
	for building: Dictionary in Rbx.module("TownLayout").get("buildings", []):
		var at: = Vector2(float(building["x"]), float(building["z"]))
		low = low.min(at)
		high = high.max(at)
	if low.x == INF:
		return Rect2(-1400, -1400, 3000, 3000)
	var side: = maxf(high.x - low.x, high.y - low.y) + MARGIN * 2.0
	var middle: = (low + high) / 2.0
	return Rect2(middle - Vector2(side, side) / 2.0, Vector2(side, side))


static func _crown(instance: GeometryInstance3D) -> bool:
	var material: = instance.material_override as ShaderMaterial
	return material != null and float(material.get_shader_parameter("sway") if material.get_shader_parameter("sway") != null else 0.0) > 0.0



func _drawn() -> Array[GeometryInstance3D]:
	var found: Array[GeometryInstance3D] = []
	for holder: Node in [Game.world, TreeKit.current]:
		if holder == null:
			continue
		for child in holder.get_children():
			if child is GeometryInstance3D:
				found.append(child)
	return found


func _take() -> void :
	var square: = area()
	var world: = Game.world
	if world == null:
		return

	_taken_winter = Style.winter()
	for child in _drawn():
		if not (_taken_winter and _crown(child)):
			child.layers |= LAYER
	_viewport = SubViewport.new()
	_viewport.size = Vector2i(PIXELS, PIXELS)
	_viewport.use_hdr_2d = true
	_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_viewport.positional_shadow_atlas_size = 0
	add_child(_viewport)
	var camera: = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = square.size.x
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.near = 1.0
	camera.far = 900.0
	camera.cull_mask = LAYER
	var middle: = square.get_center()
	camera.position = Vector3(middle.x, 600.0, middle.y)

	camera.basis = Basis(Vector3.RIGHT, - PI / 2.0)
	var plain: = Environment.new()
	plain.background_mode = Environment.BG_COLOR
	plain.background_color = Color(0, 0, 0)
	plain.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	camera.environment = plain
	_viewport.add_child(camera)
	camera.make_current()

	var sheet: = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = Vector2(square.size.x * 1.2, square.size.y * 1.2)
	sheet.mesh = quad
	sheet.layers = LAYER
	sheet.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sheet.extra_cull_margin = 10000.0
	var material: = ShaderMaterial.new()
	material.shader = load("res://shaders/snow_cover.gdshader")
	material.set_shader_parameter("offset", OFFSET)
	sheet.material_override = material
	camera.add_child(sheet)
	sheet.position = Vector3(0, 0, -2.0)
	RenderingServer.global_shader_parameter_set("snow_cover_area", Vector4(square.position.x, square.position.y, square.size.x, square.size.y))
	_frames = 0


func _process(_delta: float) -> void :
	if _viewport == null:
		return
	_frames += 1
	if _frames < 3:
		return
	var started: = Time.get_ticks_msec()
	var image: = _viewport.get_texture().get_image()
	if image == null:

		_viewport.queue_free()
		_viewport = null
		done = true
		return
	image.convert(Image.FORMAT_RH)
	image.generate_mipmaps()
	var heights: = ImageTexture.create_from_image(image)
	RenderingServer.global_shader_parameter_set("snow_cover", heights)
	RenderingServer.global_shader_parameter_set("cover_soft", heights)
	_viewport.queue_free()
	_viewport = null
	for child in _drawn():
		child.layers &= ~ LAYER
	done = true
	if OS.get_cmdline_user_args().has("--snow-trace"):
		var square: = area()
		print("snow cover: %d px over %s, read in %d ms" % [PIXELS, square, Time.get_ticks_msec() - started])
		for probe: Vector3 in [Vector3(-20, 0, -60), Vector3(-20, 0, -25), Vector3(150, 0, 560), Vector3(20, 0, 445)]:
			var uv: = (Vector2(probe.x, probe.z) - square.position) / square.size
			var height: = image.get_pixelv(Vector2i(uv * PIXELS)).r - OFFSET
			var hit: = Game.world.raycast(probe + Vector3(0, 400, 0), probe - Vector3(0, 50, 0), World.LAYER_SOLID | World.LAYER_QUERY)
			print("  at %s: cover %.2f, ray %s" % [probe, height, str(hit["position"].y) if not hit.is_empty() else "-"])
