class_name HudRadioWheel
extends Control





const ITEM: = Vector2(210, 42)

var _down_at: = -1.0
var _open: = false
var _chosen: = -1
var _pointer: = Vector2.ZERO
var _wheel: Control
var _items: Array[Control] = []
var _labels: Array[Label] = []
var _middle: Label


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wheel = Control.new()
	_wheel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wheel.visible = false
	add_child(_wheel)
	var middle: = Ui.plate(Vector2(150, 48))
	middle.position = Vector2(-75, -24)
	_wheel.add_child(middle)
	_middle = Ui.display("", 22, Ui.YELLOW)
	_middle.position = Vector2(0, 6)
	_middle.size = Vector2(150, 34)
	_middle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(_middle)
	var lines: Array = Config.Talk.RadioLines
	var radius: = float(Config.Talk.RadioRadius)
	for index in lines.size():
		var item: = Ui.plate(ITEM)
		var angle: = TAU * index / lines.size() - PI / 2.0
		item.position = Vector2(cos(angle) * radius * float(Config.Talk.RadioStretch), sin(angle) * radius) - ITEM / 2.0
		_wheel.add_child(item)
		var key: = Ui.caps(str(index + 1), int(Config.Hud.CapsFloor))
		key.position = Vector2(10, 11)
		item.add_child(key)
		var label: = Ui.label("", int(Config.Hud.TextFloor) + 2)
		label.position = Vector2(30, 0)
		label.size = Vector2(ITEM.x - 38, ITEM.y)
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.clip_text = true
		label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		item.add_child(label)
		_items.append(item)
		_labels.append(label)


func is_open() -> bool:
	return _open


func _usable() -> bool:
	var me: = Game.local_player
	if me == null or me.camera == null or me.health <= 0.0:
		return false

	return not (LadderService.current and LadderService.current.controller == me) and not (TruckRoof.current and TruckRoof.current.operating(me))


func _process(_delta: float) -> void :
	if not _open:
		if Game.ui_open or not _usable() or not Game.local_player.camera.captured:
			_down_at = -1.0
			return
		if Input.is_action_just_pressed("radio"):
			_down_at = Game.now()
		if _down_at >= 0.0:
			if not Input.is_action_pressed("radio"):
				_down_at = -1.0
			elif Game.now() - _down_at >= float(Config.Talk.RadioHold):
				_down_at = -1.0
				_show()
		return
	if not Input.is_action_pressed("radio"):
		_send()
		return
	for index in _items.size():
		var lit: = index == _chosen
		_items[index].modulate = Color(1.15, 1.15, 1.0) if lit else Color(1, 1, 1, 0.85)
		_labels[index].add_theme_color_override("font_color", Ui.YELLOW if lit else Ui.TEXT)


func _input(event: InputEvent) -> void :
	if not _open:
		return
	if event is InputEventMouseMotion:
		_pointer = (_pointer + event.relative).limit_length(120.0)
		if _pointer.length() > 30.0:
			var angle: = fposmod(atan2(_pointer.y, _pointer.x / float(Config.Talk.RadioStretch)) + PI / 2.0, TAU)
			_chosen = int(roundf(angle / TAU * _items.size())) % _items.size()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_send()
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			_close()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("pause"):
		_close()
		get_viewport().set_input_as_handled()
	else:
		for index in mini(_items.size(), MenuKit.KEYS.size()):
			if event.is_action_pressed(MenuKit.KEYS[index]):
				_chosen = index
				_send()
				get_viewport().set_input_as_handled()
				return


func _show() -> void :
	_open = true
	_chosen = -1
	_pointer = Vector2.ZERO
	_wheel.visible = true
	Game.ui_open = true
	_middle.text = Text.say(Text.m("talk.radioTitle"))
	var lines: Array = Config.Talk.RadioLines
	for index in lines.size():
		_labels[index].text = Text.say(Text.m("talk.radio." + str(lines[index])))
	Sounds.ui("ui_wheel_open")



func _send() -> void :
	if _chosen >= 0:
		Net.request("talk.radio", [str(Config.Talk.RadioLines[_chosen])])
	_close()


func _close() -> void :
	if not _open:
		return
	_open = false
	_wheel.visible = false
	Game.ui_open = false
	Sounds.ui("ui_wheel_close")
