class_name Dogs
extends Node3D



const NEAR: = 50.0
const FAR: = 190.0
const DAY_GAP: = Vector2(25.0, 60.0)
const NIGHT_GAP: = Vector2(9.0, 26.0)
const VOICES: = ["dog_bark_1", "dog_bark_2", "dog_bark_3"]

var _yards: Array[Vector3] = []
var _next: = 8.0
var _trace: = false


func _ready() -> void :
	_trace = OS.get_cmdline_user_args().has("--sound-trace")
	var store: = Game.store
	var buildings: = -1
	for id: int in store.nodes_under.get(0, PackedInt32Array()):
		if store.nodes[id]["n"] == "Map":
			for child: int in store.nodes_under.get(id, PackedInt32Array()):
				if store.nodes[child]["n"] == "Buildings":
					buildings = child
	if buildings < 0:
		return
	for model: int in store.nodes_under.get(buildings, PackedInt32Array()):
		var row: = store.find_row(model, "Body")
		if row < 0:
			continue
		var size: = store.size(row)
		if size.y > 30.0:
			continue
		var place: = store.transform(row)

		_yards.append(place.origin * Vector3(1, 0, 1) + place.basis.z.normalized() * (size.z / 2.0 + 7.0) + Vector3(0, 1.5, 0))


func _process(_delta: float) -> void :
	if Game.now() < _next or _yards.is_empty():
		return
	var gap: = NIGHT_GAP if Game.night else DAY_GAP
	_next = Game.now() + randf_range(gap.x, gap.y)
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var at: = camera.global_position
	var near: Array[Vector3] = []
	for yard in _yards:
		var distance: = Vector2(yard.x - at.x, yard.z - at.z).length()
		if distance > NEAR and distance < FAR:
			near.append(yard)
	if near.is_empty():
		return
	var first: Vector3 = near[randi() % near.size()]
	_bout(first)
	if near.size() > 1 and randf() < 0.35:
		var second: Vector3 = near[randi() % near.size()]
		if second.distance_to(first) > 40.0:
			get_tree().create_timer(randf_range(1.2, 3.0), false).timeout.connect(_bout.bind(second))



func _bout(yard: Vector3) -> void :
	var voice: String = VOICES[posmod(int(yard.x * 3.0 + yard.z * 7.0), VOICES.size())]
	var pitch: = 0.9 + fposmod(yard.x * 0.37 + yard.z * 0.11, 0.25)
	if _trace:
		print("sound: dog at %s (%s)" % [yard.snapped(Vector3.ONE), voice])
	for bark in randi_range(2, 6):
		Sounds.once_at(yard, voice, 0.75, 18.0, 260.0, pitch * randf_range(0.96, 1.04))
		await get_tree().create_timer(randf_range(0.32, 0.75), false).timeout
		if not is_inside_tree():
			return
