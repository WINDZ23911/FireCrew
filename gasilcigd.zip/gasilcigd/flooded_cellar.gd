class_name FloodedCellar
extends Node

















const TICK: = 0.25
const TRIES: = 20
const OUT: = 2.1
const SIZE: = Vector3(5, 0.6, 3.6)
const PLAYER_ROOM: = 60.0
const VALVE_HINT: = 20.0
const FADE: = 2.5
const SWITCH_SIZE: = Vector3(2.2, 2.8, 0.6)

const STONE: = Color8(150, 146, 138)
const FLAP: = Color8(70, 92, 76)
const WATER: = Color8(70, 110, 130)
const OIL: = Color8(92, 84, 52)
const PUMP: = Color8(214, 120, 30)
const HOSE: = Color8(40, 120, 200)
const BOOM: = Color8(250, 200, 40)

static var current: FloodedCellar

var kind: = "flood"
var position: = Vector3.ZERO
var source: Dictionary = {}
var discharge: Dictionary = {}
var _places: Array = []
var _layout: Dictionary = {}
var _serial: = 0
var _shown: Array = []
var _mirrors: Dictionary = {}
var _hatch: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Incidents.Flood



func _find_places(layout: Dictionary, buildings: Array) -> void :
	for building: Building in buildings:
		var row: int = Game.store.row_of.get(int(building.record.get("body", 0)), -1)
		if building.roof.is_empty() or row < 0 or building is House:
			continue
		var size: = Game.store.size(row)
		var front: = building.place * Transform3D(Basis.IDENTITY, Vector3(0, 0, - (size.z / 2.0 + OUT)))
		var found: = Roads.nearest(layout, front.origin.x, front.origin.z)
		if not found[0].is_empty() and found[0]["distance"] <= float(Config.Incidents.Flood.StreetReach) and size.x >= 18.0:
			var hatches: Array[Transform3D] = []
			for side: float in [-1.0, 1.0]:
				hatches.append(front * Transform3D(Basis.IDENTITY, Vector3(side * size.x * 0.28, 0, 0)))
			_places.append({"building": building, "hatches": hatches, "street": found[1]})







func _build(place: Transform3D, building: Building) -> Dictionary:
	var own: = CallKit.rows_of(building.model)

	var from: = place.origin + Vector3(0, 6, 0)
	var ground: = {}
	for attempt in 4:
		ground = Game.world.raycast(from, place.origin + Vector3(0, -6, 0), World.LAYER_SOLID)
		if ground.is_empty() or not own.has(Game.world.row_hit(ground)):
			break
		from = ground["position"] + Vector3(0, -0.05, 0)
	if ground.is_empty() or own.has(Game.world.row_hit(ground)):
		return {}
	place = Transform3D(place.basis, ground["position"])
	if not CallKit.box_clear(place * Transform3D(Basis.IDENTITY, Vector3(0, 2.2, 0)), Vector3(SIZE.x + 1.0, 3, SIZE.z), own):
		return {}
	var drain: Variant = _drain_for(place)
	if drain == null:
		return {}
	var switch_at: Variant = _switch_spot(place, own)
	if switch_at == null:
		return {}
	_serial += 1
	return _make(place, _serial, drain, switch_at)





func _switch_spot(place: Transform3D, own: Dictionary) -> Variant:
	var half: = SIZE.x / 2.0
	var y: = SWITCH_SIZE.y / 2.0 + 0.8
	var wall_at: = func(x: float) -> float:
		var from: Vector3 = (place * Transform3D(Basis.IDENTITY, Vector3(x, y, -1.0))).origin
		var to: Vector3 = (place * Transform3D(Basis.IDENTITY, Vector3(x, y, OUT + 4.0))).origin
		var hit: = Game.world.raycast(from, to, World.LAYER_SOLID)
		if hit.is_empty() or not own.has(Game.world.row_hit(hit)):
			return -1.0
		return (place.affine_inverse() * (hit["position"] as Vector3)).z
	for x: float in [half + 3.4, - (half + 3.4), half + 4.6, - (half + 4.6), half + 5.8, - (half + 5.8)]:
		var z: float = wall_at.call(x)
		if z < OUT - 1.5 or z > OUT + 3.0:
			continue

		var flat: = true
		for edge: float in [ - SWITCH_SIZE.x / 2.0 - 0.3, SWITCH_SIZE.x / 2.0 + 0.3]:
			flat = flat and absf(float(wall_at.call(x + edge)) - z) < 0.25
		if not flat:
			continue
		var middle: = z - SWITCH_SIZE.z / 2.0 - 0.05
		var cabinet: = place * Transform3D(Basis.IDENTITY, Vector3(x, y, middle))
		var stand: = place * Transform3D(Basis.IDENTITY, Vector3(x, 2.8, z - 2.2))
		if CallKit.box_clear(cabinet, SWITCH_SIZE - Vector3(0.1, 0.1, 0.1), own) and CallKit.box_clear(stand, Vector3(2.6, 3.6, 3.0)):
			return Vector3(x, y, middle)
	return null



func _drain_for(place: Transform3D) -> Variant:
	if _layout.is_empty():
		return null
	var found: = Roads.nearest(_layout, place.origin.x, place.origin.z)
	if found[0].is_empty():
		return null
	var middle: = Vector3(found[0]["x"], place.origin.y, found[0]["z"])
	var toward: = Vector3(place.origin.x - middle.x, 0, place.origin.z - middle.z)
	if toward.length() < 0.5:
		return null
	var at: = middle + toward.normalized() * maxf(float(found[1]["width"]) / 2.0 - 1.4, 1.0)
	if Vector2(at.x - place.origin.x, at.z - place.origin.z).length() > float(settings()["DrainReach"]):
		return null
	return CallKit.ground_at(at + Vector3(0, 4, 0))




func _make(place: Transform3D, serial: int, drain_at: Vector3, switch_at: Vector3) -> Dictionary:
	var model: = CallKit.model("FloodedCellar")
	var at: = func(x: float, y: float, z: float) -> Transform3D:
		return place * Transform3D(Basis.IDENTITY, Vector3(x, y, z))

	var half: = SIZE.x / 2.0
	var deep: = SIZE.z
	for kerb: Array in [[Vector3(0.5, SIZE.y, deep), at.call( - half, SIZE.y / 2.0, 0)], [Vector3(0.5, SIZE.y, deep), at.call(half, SIZE.y / 2.0, 0)], [Vector3(SIZE.x + 0.5, SIZE.y, 0.5), at.call(0, SIZE.y / 2.0, - deep / 2.0)]]:
		CallKit.part(model, CallKit.BLOCK, kerb[0], kerb[1], STONE, "Concrete", true, 0.0, "Kerb")
	CallKit.part(model, CallKit.BLOCK, Vector3(SIZE.x - 0.5, 0.1, deep - 0.25), at.call(0, 0.06, 0.12), Color8(16, 18, 20), "SmoothPlastic", false, 0.0, "Well")
	var level: Transform3D = at.call(0, SIZE.y - 0.12, 0.12)
	var water: = CallKit.part(model, CallKit.BLOCK, Vector3(SIZE.x - 0.5, 0.1, deep - 0.25), level, WATER, "Glass", false, 0.25, "Water")

	for side: float in [-1.0, 1.0]:
		var leaning: Transform3D = at.call(side * (half + 0.3), SIZE.y, 0) * Rbx.angles(0, 0, deg_to_rad( - side * 20)) * Transform3D(Basis.IDENTITY, Vector3(0, SIZE.x / 4.0, 0))
		CallKit.part(model, CallKit.BLOCK, Vector3(0.15, SIZE.x / 2.0, deep - 0.3), leaning, FLAP, "Metal", false, 0.0, "Flap")

	var spread: Transform3D = at.call(0, 0.07, - deep / 2.0 - 3.0) * Rbx.angles(0, 0, PI / 2)
	var pool: = CallKit.part(model, CallKit.CYLINDER, Vector3(0.08, 1, 1), spread, WATER, "Glass", false, 0.35, "Pool")
	pool.mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	water.mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


	var inlet: = Node3D.new()
	inlet.name = "Inlet"
	model.add_child(inlet)
	inlet.global_transform = at.call(0, SIZE.y, 0)
	var prompt: = CallKit.prompt(inlet, "flood.%d.inlet" % serial, Text.m("calls.flood.hoseIn"), Text.m("calls.flood.title"), 0.3, 10.0)

	prompt.condition = func(player: Player) -> bool: return CallGear.carried(player).is_empty() and player.get_attr("Discharge") == null
	var stream: AudioStream = Sounds.loop(Config.Hose.SpraySoundId)
	if stream:
		var running: = Sounds.emitter(inlet, stream, 0.25, 8.0, 90.0, true)
		running.pitch_scale = 0.7
	var marker: = CallMarker.make(inlet.global_position + Vector3(0, 7, 0), "", Color8(40, 110, 170))
	marker.own = true


	var pump_at: = Node3D.new()
	pump_at.name = "PumpPlace"
	model.add_child(pump_at)
	pump_at.global_transform = at.call(half - 0.9, SIZE.y + 0.4, -0.4)
	var pump_prompt: = CallKit.prompt(pump_at, "flood.%d.pump" % serial, Text.m("calls.flood.pump.lower"), Text.m("calls.flood.pump.object"), float(settings()["LowerHold"]), 9.0)
	pump_prompt.condition = func(player: Player) -> bool: return CallGear.carried(player) == "Portable pump"


	var switch: = CallKit.part(model, CallKit.BLOCK, SWITCH_SIZE, at.call(switch_at.x, switch_at.y, switch_at.z), CallFixture.GREY, "Metal", true, 0.0, "Isolator")
	CallFixture.dress_switch(switch)
	var switch_prompt: = CallKit.prompt(switch, "flood.%d.power" % serial, Text.m("calls.flood.power.action"), Text.m("calls.flood.power.object"), float(settings()["PowerHold"]), 9.0)
	switch_prompt.position = Vector3(0, 0, - SWITCH_SIZE.z / 2.0 - 0.3)


	var drain: = Node3D.new()
	drain.name = "Drain"
	model.add_child(drain)
	var facing: = Vector3(place.origin.x - drain_at.x, 0, place.origin.z - drain_at.z)
	drain.global_transform = Rbx.look_at(drain_at, drain_at + (facing.normalized() if facing.length() > 0.1 else Vector3.FORWARD))
	CallKit.piece(drain, CallKit.BLOCK, Vector3(2.6, 0.08, 1.4), Transform3D(Basis.IDENTITY, Vector3(0, 0.05, 0)), Color8(24, 24, 26))
	for bar in 6:
		CallKit.piece(drain, CallKit.BLOCK, Vector3(0.14, 0.1, 1.3), Transform3D(Basis.IDENTITY, Vector3(-1.0 + bar * 0.4, 0.1, 0)), Color8(70, 70, 74))
	var drain_label: = CallKit.words(drain, Text.m("calls.flood.drain.mark"), Color8(120, 200, 255), 2.2, 60.0)
	var drain_prompt: = CallKit.prompt(drain, "flood.%d.drain" % serial, Text.m("calls.flood.drain.action"), Text.m("calls.flood.drain.object"), 0.6, 9.0)
	drain_prompt.position = Vector3(0, 1.0, 0)
	drain_prompt.condition = func(player: Player) -> bool: return player.get_attr("Discharge") != null


	var boom_prompt: = CallKit.prompt(inlet, "flood.%d.boom" % serial, Text.m("calls.flood.oil.action"), Text.m("calls.flood.oil.object"), float(settings()["BoomHold"]), 9.0)
	boom_prompt.position = Vector3( - half + 0.8, 0.3, 0)
	boom_prompt.enabled = false
	return {
		"model": model, "place": place, "water": water, "pool": pool, "marker": marker, "inlet": inlet, "prompt": prompt, "level": level, "spread": spread, 
		"serial": serial, "switch_at": switch_at, "share": 1.0, "litres": -1, "over": false, "dry": false, 
		"pump_at": pump_at, "pump_prompt": pump_prompt, "switch": switch, "switch_prompt": switch_prompt, "drain": drain, "drain_at": drain_at, 
		"drain_prompt": drain_prompt, "drain_label": drain_label, "boom_prompt": boom_prompt, 
		"power": true, "oil": false, "boomed": false, "pumps": [], "drawn": [], 
	}



func _show_level(hatch: Dictionary, share: float, litres: int) -> void :
	hatch["share"] = share
	hatch["litres"] = litres
	if not is_instance_valid(hatch["model"]):
		return
	CallKit.set_marker(hatch["marker"], Text.f("calls.markers.litres", [Ui.thousands(litres)]))
	var level: Transform3D = hatch["level"]
	hatch["water"].global_transform = level * Transform3D(Basis.IDENTITY, Vector3(0, - (1.0 - share) * (SIZE.y - 0.25), 0))
	var across: = 4.0 + 12.0 * share
	hatch["pool"].mesh.scale = Vector3(0.08, across, across)




func _show_power(hatch: Dictionary) -> void :
	if not is_instance_valid(hatch["model"]):
		return
	hatch["switch_prompt"].enabled = hatch["power"] and not hatch["over"]
	if not hatch["power"]:
		CallFixture.done(hatch["switch"])
	var oily: bool = hatch["oil"] and not hatch["boomed"]
	(hatch["water"] as PartNode).set_color(OIL if oily else WATER, 0.25)
	hatch["boom_prompt"].enabled = oily and not hatch["over"]
	if hatch["boomed"] and not hatch.has("boom"):

		var boom: = Node3D.new()
		hatch["model"].add_child(boom)
		boom.global_transform = (hatch["level"] as Transform3D) * Transform3D(Basis.IDENTITY, Vector3(0, 0.12, 0))
		for side: float in [-1.0, 1.0]:
			CallKit.piece(boom, CallKit.BLOCK, Vector3(SIZE.x - 0.8, 0.3, 0.3), Transform3D(Basis.IDENTITY, Vector3(0, 0, side * (SIZE.z / 2.0 - 0.5))), BOOM)
		hatch["boom"] = boom



func _show_over(hatch: Dictionary, dry: bool) -> void :
	hatch["over"] = true
	hatch["dry"] = dry
	if not is_instance_valid(hatch["model"]):
		return
	for key: String in ["prompt", "pump_prompt", "switch_prompt", "drain_prompt", "boom_prompt"]:
		hatch[key].enabled = false
	if is_instance_valid(hatch["drain_label"]):
		hatch["drain_label"].visible = false
	if is_instance_valid(hatch["marker"]):
		hatch["marker"].queue_free()
	if dry:
		hatch["water"].visible = false
		hatch["pool"].visible = false








func _draw_pumps(hatch: Dictionary, pumps: Array) -> void :
	if not is_instance_valid(hatch["model"]):
		return
	var drawn: Array = hatch["drawn"]
	while drawn.size() < pumps.size():
		var index: = drawn.size()
		var holder: = Node3D.new()
		hatch["model"].add_child(holder)

		var body: = CallKit.piece(holder, CallKit.CYLINDER, Vector3(1.1, 0.9, 0.9), (hatch["pump_at"] as Node3D).global_transform * Transform3D(Basis(Vector3.BACK, PI / 2), Vector3( - index * 1.3, -0.3, 0)), PUMP)
		var segments: Array = []
		for part in 3:
			segments.append(CallKit.piece(holder, CallKit.CYLINDER, Vector3(1, 0.32, 0.32), Transform3D.IDENTITY, HOSE))
		drawn.append({"holder": holder, "body": body, "segments": segments})
	var out: Transform3D = (hatch["place"] as Transform3D) * Transform3D(Basis.IDENTITY, Vector3(0, 0.2, - SIZE.z / 2.0 - 0.8))
	for index in drawn.size():
		var made: Dictionary = drawn[index]
		made["holder"].visible = index < pumps.size()
		if index >= pumps.size():
			continue
		var start: Vector3 = (made["body"] as Node3D).global_position + Vector3(0, 0.5, 0)
		var edge: = out.origin + out.basis.x * (index * 1.2)
		var finish: = edge + ( - out.basis.z) * 2.0
		var end: Variant = pumps[index][0]
		if pumps[index][1]:
			finish = (hatch["drain_at"] as Vector3) + Vector3(index * 0.6, 0.25, 0)
		elif end is Player and is_instance_valid(end) and end.rig != null:
			finish = end.rig.hand_right.global_position

		var middle: = (edge + finish) / 2.0
		if Game.world != null:
			var top: = maxf(edge.y, finish.y - 0.25)
			for along: float in [0.25, 0.5, 0.75]:
				var probe: = edge.lerp(finish, along)
				top = maxf(top, CallKit.ground_at(probe + Vector3(0, 3, 0)).y + 0.2)
			middle.y = maxf(middle.y, top)
		_stretch(made["segments"][0], start, edge)
		_stretch(made["segments"][1], edge, middle)
		_stretch(made["segments"][2], middle, finish)



static func _stretch(piece: MeshInstance3D, a: Vector3, b: Vector3) -> void :
	var span: = b - a
	var length: = maxf(span.length(), 0.05)
	var along: = span / length
	var up: = Vector3.UP if absf(along.dot(Vector3.UP)) < 0.95 else Vector3.RIGHT
	var side: = along.cross(up).normalized()
	var other: = side.cross(along).normalized()
	piece.global_transform = Transform3D(Basis(along * length, other * 0.55, side * 0.55), (a + b) / 2.0)










func _fit_discharge(vehicle: Vehicle) -> Dictionary:

	var sides: = {}
	for other: Dictionary in HoseService.current.lines:
		if other["kind"] == "outlet" and other["rig"]["vehicle"] == vehicle:
			var side: = 1 if vehicle.to_local((other["source"] as Node3D).global_position).x >= 0.0 else -1
			var best: Dictionary = sides.get(side, {})
			if best.is_empty() or (best["player"] != null and other["player"] == null):
				sides[side] = other
	if sides.is_empty():
		return {}
	var line: Dictionary = {}
	for side: int in sides:
		if line.is_empty() or (line["player"] != null and sides[side]["player"] == null):
			line = sides[side]
	var made: = {"vehicle": vehicle, "open": false, "pumped": 0.0, "valves": []}
	made.merge(_spout_at(vehicle, line))
	for side: int in sides:
		var each: Dictionary = sides[side]
		var prompt: Prompt = each["prompt"]
		made["valves"].append([each, prompt, prompt.action])
		prompt.action = Text.m("calls.flood.openValve")
		each["divert"] = func(_player: Player) -> void : _turn_valve(made, each)
	return made




func _spout_at(vehicle: Vehicle, line: Dictionary) -> Dictionary:
	var outlet: Node3D = line["source"]
	var centre: = vehicle.global_position
	var away: = Vector3(outlet.global_position.x - centre.x, 0, outlet.global_position.z - centre.z)
	away = away.normalized() if away.length() > 0.1 else Vector3.RIGHT

	var landing: = outlet.global_position + away * 5.0
	var ground: = Game.world.raycast(landing + Vector3(0, 2, 0), landing + Vector3(0, -12, 0), World.LAYER_SOLID)
	var runoff_at: Vector3 = ground["position"] if not ground.is_empty() else landing - Vector3(0, 3, 0)
	var made: = _spout(outlet, Rbx.look_at(outlet.global_position, outlet.global_position + away - Vector3(0, 0.25, 0)), runoff_at)
	made["line"] = line
	made["to_drain"] = false
	if not _hatch.is_empty():
		var drain: Vector3 = _hatch["drain_at"]
		made["to_drain"] = Vector2(runoff_at.x - drain.x, runoff_at.z - drain.z).length() <= float(settings()["DrainNear"])
	made["on_truck"] = vehicle.global_transform.affine_inverse() * made["spout"].global_transform
	return made



func _turn_valve(made: Dictionary, line: Dictionary) -> void :
	if made["open"] and is_same(made["line"], line):
		_set_valve(made, false)
		return
	if not is_same(made["line"], line):
		_take_spout(made)
		made.merge(_spout_at(made["vehicle"], line), true)
		made["pumped"] = 0.0
	_set_valve(made, true)




func _spout(parent: Node3D, place: Transform3D, runoff_at: Vector3) -> Dictionary:
	var spout: = Node3D.new()
	spout.name = "Discharge"
	parent.add_child(spout)
	spout.global_transform = place
	var gush: = RbxEmitter.make(spout, {
		"Enabled": false, 
		"Texture": Config.Hose.DropletTexture, 
		"Color": Color8(150, 180, 190), 
		"LightInfluence": 1, 
		"Rate": 110, 
		"Speed": [10, 14], 
		"Lifetime": [0.5, 0.75], 
		"SpreadAngle": 7, 
		"Acceleration": Vector3(0, -45, 0), 
		"Size": [0.9, 1.6], 
		"Transparency": [0.25, 0.8], 
		"Direction": Vector3.FORWARD, 
	})
	var rush: AudioStreamPlayer3D = null
	var stream: AudioStream = Sounds.loop(Config.Hose.SpraySoundId)
	if stream:
		rush = Sounds.emitter(spout, stream, 0.6, 10.0, 120.0)

	var runoff: = CallKit.part(Game.world, CallKit.CYLINDER, Vector3(0.08, 1, 1), Transform3D(Basis(Vector3.BACK, PI / 2), runoff_at + Vector3(0, 0.06, 0)), WATER, "Glass", false, 0.4, "Runoff")
	runoff.mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	runoff.visible = false

	return {"spout": spout, "gush": gush, "rush": rush, "runoff": runoff, "runoff_at": runoff_at}


func _set_valve(made: Dictionary, open: bool) -> void :
	_show_valve(made, open)
	for valve: Array in made["valves"]:
		(valve[1] as Prompt).action = Text.m("calls.flood.closeValve" if open else "calls.flood.openValve")


func _show_valve(made: Dictionary, open: bool) -> void :
	made["open"] = open
	if not is_instance_valid(made["spout"]):
		return
	made["gush"].emitting = open
	var rush: AudioStreamPlayer3D = made["rush"]
	if rush:
		if open and not rush.playing:
			rush.play()
		elif not open:
			rush.stop()



func _spread(made: Dictionary, litres: float) -> void :
	made["pumped"] += litres
	if not made.get("to_drain", false):
		_show_runoff(made)


func _show_runoff(made: Dictionary) -> void :
	var across: = minf(6.0 + made["pumped"] / 350.0, 30.0)
	var runoff: PartNode = made["runoff"]
	if not is_instance_valid(runoff):
		return
	runoff.visible = true
	runoff.mesh.scale = Vector3(0.08, across, across)


func _remove_discharge(made: Dictionary) -> void :

	for valve: Array in made["valves"]:
		var line: Dictionary = valve[0]
		line.erase("divert")
		var words: String = HoseService.current.kind_of(line["kind"])["words"]
		(valve[1] as Prompt).action = Text.m(words + (".back" if line["player"] != null else ".take"))
	_take_spout(made)


func _take_spout(made: Dictionary) -> void :
	if is_instance_valid(made["spout"]):
		made["spout"].queue_free()
	var runoff: PartNode = made["runoff"] if is_instance_valid(made["runoff"]) else null
	if is_instance_valid(runoff):
		var tween: = runoff.create_tween()
		tween.tween_property(runoff.mesh, "scale", Vector3(0.08, 0.1, 0.1), 20.0)
		tween.tween_callback(runoff.queue_free)





func available() -> bool:
	return not _places.is_empty() and HoseService.current != null



func _shock(hatch: Dictionary, player: Player) -> void :
	var at: Vector3 = (hatch["inlet"] as Node3D).global_position
	Blast.at(at + Vector3(0, 1, 0), 3.0, 0.4, 2.2)
	if is_instance_valid(player):
		player.take_damage(float(settings()["Shock"]))
		Game.notify(Text.m("calls.flood.power.shock"), "danger", player)
	Alarm.check("power", false)
	hatch["shocked"] = true


func run() -> bool:
	var flood: Dictionary = settings()
	var hatch: Dictionary = {}
	var where: Dictionary = {}
	for attempt in TRIES:
		var place: Dictionary = _places[randi() % _places.size()]
		var building: Building = place["building"]
		if building.ruined or CallKit.player_near(building.position, PLAYER_ROOM):
			continue
		var hatches: Array = place["hatches"]
		var first: = randi() % hatches.size()
		for offset in hatches.size():
			hatch = _build(hatches[(first + offset) % hatches.size()], building)
			if not hatch.is_empty():
				break
		if not hatch.is_empty():
			where = place
			break
	if hatch.is_empty():
		return false
	_shown.append(hatch)
	_hatch = hatch
	hatch["pumps"] = []

	var total: = float(CallKit.by_crew(flood["Litres"]))
	var left: = [total]

	var inflow: = float(flood["Inflow"]) if Alarm.complicated("flood", "inflow") else 0.0
	hatch["oil"] = Alarm.complicated("flood", "oil")
	_show_power(hatch)
	discharge = {}
	var inlet: Node3D = hatch["inlet"]
	var road: = [0.0]
	var pumped: = [0.0]

	source = {
		"position": inlet.global_position, 
		"node": inlet, 
		"prompt": hatch["prompt"], 
		"connect_text": Text.m("calls.flood.hoseIn"), 
		"pump": func(dt: float) -> void :
			if not discharge.is_empty() and discharge["open"] and left[0] > 0.0:
				var litres: = minf(float(flood["Flow"]) * dt, left[0])
				left[0] -= litres
				pumped[0] += litres
				if not discharge.get("to_drain", false):
					road[0] += litres
				_spread(discharge, litres), 
	}
	HoseService.current.add_source(source)

	var building: Building = where["building"]
	var call_name: = Text.join([Text.m("calls.flood.title"), Text.m("calls.separator"), CallKit.building_name(building)])
	position = inlet.global_position
	CallService.current.publish("flood", call_name, position, int(total))


	var par: Dictionary = Alarm.settings()["Grade"]["Job"]["flood"]
	Alarm.par(total / float(flood["Flow"]) + float(par["Base"]))
	Game.notify(Text.f("calls.flood.alarm", [call_name]))
	Game.notify(Text.m("calls.flood.briefPower"))
	if inflow > 0.0:
		Game.notify(Text.m("calls.flood.inflow"), "warning")
	if hatch["oil"]:
		Game.notify(Text.m("calls.flood.oil.told"), "warning")
	Escalation.begin_other(["rising"])


	hatch["switch_prompt"].triggered.connect( func(player: Player) -> void :
		if not hatch["power"] or hatch["over"]:
			return
		hatch["power"] = false
		_show_power(hatch)
		if not hatch.has("shocked"):
			Alarm.check("power", true)
		Game.notify(Text.f("calls.flood.power.off", [player.display_name]), "good")
	)
	hatch["pump_prompt"].triggered.connect( func(player: Player) -> void :
		if hatch["over"] or CallGear.carried(player) != "Portable pump":
			return
		if hatch["pumps"].size() >= int(flood["Pumps"]):
			Game.notify(Text.m("calls.flood.pump.full"), "", player)
			return
		if hatch["power"]:
			_shock(hatch, player)
			return
		CallGear.current.use(player, "Portable pump")
		hatch["pumps"].append({"end": player, "drain": false, "lowered_at": Game.now()})
		player.set_attr("Discharge", hatch["serial"])
		Game.notify(Text.m("calls.flood.pump.lowered"), "", player)
	)
	hatch["drain_prompt"].triggered.connect( func(player: Player) -> void :
		for pump: Dictionary in hatch["pumps"]:
			if pump["end"] == player:
				pump["end"] = null
				pump["drain"] = true
				pump["laid_at"] = Game.now()
				player.set_attr("Discharge", null)
				Game.notify(Text.m("calls.flood.drain.laid"), "good", player)
				return
	)
	hatch["boom_prompt"].triggered.connect( func(_player: Player) -> void :
		if hatch["oil"] and not hatch["boomed"]:
			hatch["boomed"] = true
			_show_power(hatch)
			Game.notify(Text.m("calls.flood.oil.boomed"), "good")
	)


	var tell_crew: = func(text: Variant) -> void :
		for player in CallKit.crew_near(inlet.global_position, float(flood["Range"])):
			Game.notify(text, "", player)

	var waited: = 0.0
	var hinted: = 0.0
	var shown: = -1
	var started_at: = -1.0
	var running_at: = -1.0
	var fitted_at: = -1.0
	var oiled: = false
	while left[0] > 0.0 and not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK

		if Escalation.due() == "rising":
			rise(float(Config.Alarm.Escalations.flood.Share))
		if hatch.has("rise"):
			left[0] += total * float(hatch["rise"])
			total *= 1.0 + float(hatch["rise"])
			hatch.erase("rise")
			Game.incident["total"] = int(total)

		left[0] = minf(left[0] + inflow * TICK, total * 1.5)
		var running: = 0
		for pump: Dictionary in hatch["pumps"]:
			var end: Variant = pump["end"]
			if end != null and ( not is_instance_valid(end) or end.health <= 0.0):

				if is_instance_valid(end):
					end.set_attr("Discharge", null)
				pump["end"] = null
			if pump["drain"]:
				running += 1
		var flow: = minf(float(flood["PumpFlow"]) * running * TICK, left[0])
		if flow > 0.0:
			left[0] -= flow
			pumped[0] += flow
		var share: float = clampf(left[0] / total, 0.0, 1.0)
		var litres: = ceili(left[0] / 10.0) * 10
		if litres != shown:
			shown = litres
			CallService.current.progress(int(maxf(total - left[0], 0.0)))
			_show_level(hatch, share, litres)

		var vehicle: Vehicle = source["rig"]["vehicle"] if source.get("rig") != null else null
		if not discharge.is_empty() and discharge["vehicle"] != vehicle:
			_set_valve(discharge, false)
			_remove_discharge(discharge)
			discharge = {}
		if vehicle != null and started_at < 0.0:
			started_at = Game.now()
		if vehicle != null and discharge.is_empty():
			if hatch["power"] and not hatch.has("shocked"):

				var nearest: Player = null
				for player in Game.players:
					if is_instance_valid(player) and (nearest == null or player.root_position().distance_to(inlet.global_position) < nearest.root_position().distance_to(inlet.global_position)):
						nearest = player
				_shock(hatch, nearest)
			discharge = _fit_discharge(vehicle)
			if fitted_at < 0.0:
				fitted_at = Game.now()
			hinted = waited
			tell_crew.call(Text.m("calls.flood.fitted") if not discharge.get("to_drain", false) else Text.m("calls.flood.fittedDrain"))
		if not discharge.is_empty() and not discharge["open"] and waited - hinted > VALVE_HINT:
			hinted = waited
			tell_crew.call(Text.m("calls.flood.valveShut"))
		for pump: Dictionary in hatch["pumps"]:
			if started_at < 0.0:
				started_at = float(pump["lowered_at"])
			if fitted_at < 0.0:
				fitted_at = float(pump["lowered_at"])
		var truck_running: bool = not discharge.is_empty() and discharge["open"]
		if running_at < 0.0 and (running > 0 or truck_running):
			running_at = Game.now()
		if (running > 0 or truck_running) and hatch["oil"] and not hatch["boomed"]:
			oiled = true
		_show_power(hatch)
		CallService.current.next_step(_next_step(hatch, vehicle, running, shown))

	var dry: bool = left[0] <= 0.0


	var rules: Dictionary = Alarm.settings()["Grade"]["Procedure"]
	if not hatch.has("shocked"):
		Alarm.check("power", not hatch["power"] and (started_at < 0.0 or Alarm.checks.get("power", false)))
	Alarm.check("hose", started_at >= 0.0 and Alarm.arrived_at >= 0.0 and started_at - Alarm.arrived_at <= float(rules["FloodHose"]))
	Alarm.check("valve", running_at >= 0.0 and running_at - fitted_at <= float(rules["FloodValve"]))
	Alarm.check("drain", pumped[0] > 0.0 and road[0] <= pumped[0] * float(flood["RoadShare"]))
	if hatch["oil"]:
		Alarm.check("oil", not oiled)
	if dry:
		Alarm.done()
	HoseService.current.remove_source(source, Text.m("calls.flood.dry") if dry else null)
	if not discharge.is_empty():
		_set_valve(discharge, false)
		_remove_discharge(discharge)
		discharge = {}
	for pump: Dictionary in hatch["pumps"]:
		if is_instance_valid(pump["end"]):
			pump["end"].set_attr("Discharge", null)
	_show_over(hatch, dry)
	if dry:
		CallService.current.progress(int(total))
		if road[0] > pumped[0] * float(flood["RoadShare"]):
			Game.notify(Text.m("calls.flood.road"), "warning")
		CallKit.pay_helpers(CallKit.crew_near(inlet.global_position, float(flood["Range"])), int(flood["Reward"]), "", "bonus")
		Game.notify(Text.f("calls.flood.done", [call_name, Alarm.pay(int(flood["Reward"]))]), "good")
	else:
		Game.notify(Text.f("calls.flood.closed", [call_name]), "warning")
	Escalation.reset()
	source = {}
	_hatch = {}
	Game.incident.erase("next")

	await CallService.current.settle()
	CallService.current.clear( not dry)


	var model: Node3D = hatch["model"]
	get_tree().create_timer(8.0, false).timeout.connect( func() -> void : CallKit.fade(model, FADE))
	return true



func _next_step(hatch: Dictionary, vehicle: Vehicle, running: int, litres: int) -> Variant:
	if hatch["power"]:
		return Text.m("calls.flood.next.power")
	if hatch["oil"] and not hatch["boomed"]:
		return Text.m("calls.flood.next.oil")
	var carrying: = false
	for pump: Dictionary in hatch["pumps"]:
		carrying = carrying or pump["end"] != null
	if carrying:
		return Text.m("calls.flood.next.drain")
	if vehicle != null and (discharge.is_empty() or not discharge["open"]):
		return Text.m("calls.flood.next.valve")
	if running == 0 and vehicle == null:
		return Text.m("calls.flood.next.pump")
	if running < int(settings()["Pumps"]) and Alarm.complicated("flood", "inflow"):
		return Text.f("calls.flood.next.second", [litres])
	return Text.f("calls.flood.next.pumping", [litres])




func rise(share: float) -> void :
	if _hatch.is_empty():
		return
	var hatch: = _hatch
	hatch["rise"] = share
	if hatch["power"]:
		var at: Vector3 = (hatch["inlet"] as Node3D).global_position
		Blast.at(at + Vector3(0, 1, 0), 4.0, 0.6, 1.6)
		var reach: = float(Config.Alarm.Escalations.flood.Reach)
		for player in Game.players:
			if is_instance_valid(player) and player.root_position().distance_to(at) <= reach:
				player.take_damage(float(Config.Alarm.Escalations.flood.Damage))



func start(layout: Dictionary, buildings: Array) -> void :
	_layout = layout
	_find_places(layout, buildings)
	CallGear.ensure(get_parent())
	Net.share("call.flood", _net_state, _net_apply, 4.0)
	Net.stopped.connect( func() -> void : _net_apply([], true))


func _process(_delta: float) -> void :
	if Net.is_client():
		for serial: int in _mirrors:
			var hatch: Dictionary = _mirrors[serial]
			_draw_pumps(hatch, hatch.get("pumps_told", []))
	elif not _hatch.is_empty():
		var pumps: Array = []
		for pump: Dictionary in _hatch["pumps"]:
			pumps.append([pump["end"], pump["drain"]])
		_draw_pumps(_hatch, pumps)







func _net_state() -> Variant:
	var list: Array = []
	for hatch: Dictionary in _shown.duplicate():
		if not CallKit.there(hatch["model"]):
			_shown.erase(hatch)
			continue
		var pumping: Variant = null
		if is_same(hatch, _hatch) and not discharge.is_empty() and is_instance_valid(discharge["vehicle"]):
			pumping = [String(discharge["vehicle"].get_path()), discharge["on_truck"], discharge["runoff_at"], discharge["open"], snappedf(discharge["pumped"], 50.0), discharge.get("to_drain", false)]
		var pumps: Array = []
		for pump: Dictionary in hatch.get("pumps", []):
			pumps.append([Net.peer_of(pump["end"]) if is_instance_valid(pump["end"]) else 0, pump["drain"]])
		list.append({
			"serial": hatch["serial"], "place": hatch["place"], "share": snappedf(hatch["share"], 0.002), "litres": hatch["litres"], 
			"over": hatch["over"], "dry": hatch["dry"], "fading": CallKit.fading(hatch["model"]), "pumping": pumping, 
			"drain": hatch["drain_at"], "switch_at": hatch["switch_at"], "power": hatch["power"], "oil": hatch["oil"], "boomed": hatch["boomed"], "pumps": pumps, 
		})
	return list




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array or (leaving and _mirrors.is_empty()):
		return
	var told: = {}
	for state: Dictionary in list:
		var serial: int = state["serial"]
		told[serial] = true
		var hatch: Dictionary = _mirrors.get(serial, {})
		if hatch.is_empty():
			hatch = _make(state["place"], serial, state["drain"], state["switch_at"])
			hatch["pumping"] = {}
			_mirrors[serial] = hatch
		if state["litres"] != hatch["litres"] and state["litres"] >= 0:
			_show_level(hatch, state["share"], state["litres"])
		if state["over"] and not hatch["over"]:
			_show_over(hatch, state["dry"])
		if state["power"] != hatch["power"] or state["oil"] != hatch["oil"] or state["boomed"] != hatch["boomed"]:
			hatch["power"] = state["power"]
			hatch["oil"] = state["oil"]
			hatch["boomed"] = state["boomed"]
			_show_power(hatch)
		var pumps: Array = []
		for row: Array in state["pumps"]:
			pumps.append([Net.player_of(row[0]) if row[0] != 0 else null, row[1]])
		hatch["pumps_told"] = pumps
		if state["fading"]:
			CallKit.fade(hatch["model"], FADE)

		var pumping: Variant = state["pumping"]
		var made: Dictionary = hatch["pumping"]
		if not made.is_empty() and (pumping == null or pumping[0] != made["path"] or not (made["on_truck"] as Transform3D).is_equal_approx(pumping[1])):
			_show_valve(made, false)
			_take_spout(made)
			made = {}
		if pumping != null:
			if made.is_empty():
				var vehicle: = get_node_or_null(NodePath(pumping[0])) as Node3D
				if vehicle != null:
					made = _spout(vehicle, vehicle.global_transform * pumping[1], pumping[2])
					made.merge({"path": pumping[0], "on_truck": pumping[1], "open": false, "pumped": 0.0, "to_drain": pumping[5]})
			if not made.is_empty():
				if made["open"] != pumping[3]:
					_show_valve(made, pumping[3])
				if pumping[4] > 0.0 and not is_equal_approx(made["pumped"], pumping[4]) and not made["to_drain"]:
					made["pumped"] = pumping[4]
					_show_runoff(made)
		hatch["pumping"] = made
	for serial: int in _mirrors.keys():
		if not told.has(serial):
			var gone: Dictionary = _mirrors[serial]
			_mirrors.erase(serial)
			if not gone["pumping"].is_empty():
				_show_valve(gone["pumping"], false)
				_take_spout(gone["pumping"])
			if is_instance_valid(gone["marker"]):
				gone["marker"].queue_free()
			if is_instance_valid(gone["model"]):
				gone["model"].queue_free()
