class_name AmbulanceService
extends Node

















const STEP: = 4.0
const JUNCTION_ROOM: = 14.0
const TRIES: = 80
const STRETCHER_GAP: = 2.2
const ZONE_GAP: = 4.2
const MEDIC_ASIDE: = 4.9
const MEDIC_PACE: = 9.0
const STEP_OUT_TIME: = 0.7
const DRIVE_STEP: = 4.0
const KERB_RUN: = 16.0
const ACCELERATION: = 14.0
const BRAKING: = 16.0
const LOOK: = 5.0
const RECHECK: = 90.0

static var current: AmbulanceService


var graph: NavGraph

var drive_from: = -1.0


var keep_clear: Dictionary = {}

var _scene: Dictionary = {}
var _arrival: = 0
var _surfaces: = -1
var _query_box: BoxShape3D
var _shown: Array = []
var _medics_made: = 0
var _mirrors: Dictionary = {}
var _mirroring: = false


func _init() -> void :
	current = self
	process_mode = Node.PROCESS_MODE_PAUSABLE


func _ready() -> void :
	Net.share("ambulance", _net_state, _net_apply, 5.0)
	Net.share("ambulance.motion", _net_motion, _net_apply_motion, 20.0, true)
	Net.stopped.connect( func() -> void :
		if _mirroring:
			_net_apply([], true)
	)


func _exit_tree() -> void :
	if current == self:
		current = null



func _frame() -> float:
	await get_tree().process_frame
	return 0.0 if get_tree().paused else get_process_delta_time()


func _wait(seconds: float) -> void :
	var left: = seconds
	while left > 0.0:
		left -= await _frame()






static func footprint(target: Variant) -> Dictionary:
	if target is Dictionary:
		return target
	var building: Building = target
	if building is House:
		var house: House = building
		return {"lot": house.lot, "size": Rbx.v3(house.data["size"]), "name": building.name}
	var row: int = Game.store.row_of.get(int(building.record.get("body", 0)), -1)
	if row >= 0:
		var size: = Game.store.size(row)
		return {"lot": Game.store.transform(row) * Transform3D(Basis.IDENTITY, Vector3(0, - size.y / 2.0, 0)), "size": size, "name": building.name}

	var at: = building.position
	return {"lot": Transform3D(building.place.basis.orthonormalized(), Vector3(at.x, at.y - building.height / 2.0, at.z)), "size": Vector3(8, building.height, 8), "name": building.name}



func ground_at(x: float, z: float) -> float:
	var world: = Game.world
	if world == null:
		return 0.2
	if _surfaces < 0:
		_surfaces = 0
		for id: int in Game.store.nodes:
			if Game.store.nodes[id]["n"] == "Surfaces" and Game.store.nodes[id]["c"] == "Folder":
				_surfaces = id
				break
	var from: = 30.0

	for attempt in 6:
		var hit: = world.raycast(Vector3(x, from, z), Vector3(x, -30.0, z), World.LAYER_SOLID)
		if hit.is_empty():
			break
		var row: = world.row_hit(hit)
		if row >= 0 and (Game.store.parent(row) == _surfaces or Game.store.name_at(row) == "Ground"):
			return hit["position"].y
		from = hit["position"].y - 0.05
	return 0.2



func standing(x: float, z: float, dx: float, dz: float) -> Transform3D:
	var at: = Vector3(x, ground_at(x, z), z)
	return Transform3D(Basis.looking_at(Vector3(dx, 0, dz).normalized()), at)



func has_room(base: Transform3D) -> bool:
	var zone: Vector3 = Config.Victims.Zone
	var front: = Ambulance.front() - 1.0
	var back: = Ambulance.rear() + ZONE_GAP + zone.z + 1.0
	var half: = maxf(Ambulance.half_width(), maxf(zone.x / 2.0, MEDIC_ASIDE + 1.0)) + 0.5
	if _query_box == null:
		_query_box = BoxShape3D.new()

	_query_box.size = Vector3(half * 2.0, 8.4, back - front)
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = _query_box
	query.transform = base * Transform3D(Basis.IDENTITY, Vector3(0, 5.4, (front + back) / 2.0))
	query.collision_mask = World.LAYER_SOLID | World.LAYER_VEHICLE
	if not Game.world.get_world_3d().direct_space_state.intersect_shape(query, 1).is_empty():
		return false
	for spot: Dictionary in keep_clear.values():
		if _takes(base, spot["at"], spot["radius"]):
			return false
	return true



static func _takes(base: Transform3D, at: Vector3, radius: float) -> bool:
	var zone: Vector3 = Config.Victims.Zone
	var front: = Ambulance.front() - 1.0
	var back: = Ambulance.rear() + ZONE_GAP + zone.z + 1.0
	var half: = maxf(Ambulance.half_width(), maxf(zone.x / 2.0, MEDIC_ASIDE + 1.0)) + 0.5
	var p: = base.affine_inverse() * at
	return Vector2(maxf(absf(p.x) - half, 0.0), maxf(maxf(front - p.z, p.z - back), 0.0)).length() < radius




func covers(at: Vector3, radius: float) -> bool:
	if _scene.is_empty() or not _scene.has("place"):
		return false
	var car: Variant = _scene["car"]
	var base: Transform3D = _scene["place"]["base"]
	if _scene["arrived"] and car != null and is_instance_valid(car):
		base = Transform3D((car as Node3D).global_basis.orthonormalized(), (car as Node3D).global_position)
	return _takes(base, at, radius)




func find_place(target: Dictionary) -> Dictionary:
	var settings: Dictionary = Config.Victims
	var size: Vector3 = target["size"]
	var lot: Transform3D = target["lot"]
	var inverse: = lot.affine_inverse()
	var half_width: = size.x / 2.0
	var half_depth: = size.z / 2.0
	var front: = lot * Vector3(0, 0, - (half_depth + 10.0))
	var near: float = settings["ParkNear"]
	var far: float = settings["ParkFar"]

	var candidates: Array = []
	for segment: Dictionary in (graph.segments if graph else []):
		if segment["kind"] != "lane":
			continue
		var length: float = segment["length"]

		var aside: = maxf(float(segment.get("pull_over", 0.0)) - 1.0, 0.0)
		var along: = JUNCTION_ROOM
		while along <= length - JUNCTION_ROOM:
			var s: = NavGraph.sample(segment, along)
			var x: = s.x - s.w * aside
			var z: = s.y + s.z * aside
			var p: = inverse * Vector3(x, lot.origin.y, z)
			var away: = Vector2(maxf(absf(p.x) - half_width, 0.0), maxf(absf(p.z) - half_depth, 0.0)).length()
			if away >= near and away <= far:
				candidates.append({"x": x, "z": z, "dx": s.z, "dz": s.w, "seg": int(segment["id"]), "along": along, "score": Vector2(x - front.x, z - front.z).length()})
			along += STEP
	candidates.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["score"] < b["score"])
	for index in mini(candidates.size(), TRIES):
		var candidate: Dictionary = candidates[index]
		var base: = standing(candidate["x"], candidate["z"], candidate["dx"], candidate["dz"])
		if has_room(base):
			return {"base": base, "seg": candidate["seg"], "along": candidate["along"]}


	push_warning("Ambulance: no clear place to park near %s; standing in front of it" % str(target.get("name", "")))
	var side: = lot.basis.x
	var look: = - lot.basis.z
	return {"base": standing(front.x + look.x * 12.0, front.z + look.z * 12.0, side.x, side.z), "seg": -1, "along": 0.0}





func _stand_medic(medic: Medic, ground: Transform3D) -> void :
	medic.speed = 0.0
	medic.stand(ground)



func _walk_to(medic: Medic, target: Vector3) -> void :
	var from: = medic.global_position
	var flat: = Vector3(target.x, from.y, target.z)
	var span: = (flat - from).length()
	if span < 0.5:
		return
	var facing: = Transform3D(Basis.looking_at((flat - from).normalized()), from)
	var gone: = 0.0
	medic.speed = MEDIC_PACE
	while gone < span and is_instance_valid(medic):
		gone = minf(span, gone + MEDIC_PACE * await _frame())
		if not is_instance_valid(medic):
			return
		medic.stand(facing.translated( - facing.basis.z * gone + Vector3(0, (target.y - from.y) * gone / span, 0)))
	if is_instance_valid(medic):
		medic.speed = 0.0



func _medic_out(held: Dictionary, id: int, index: int, place: Transform3D) -> void :
	var called_off: = func() -> bool: return _arrival != id or not is_instance_valid(held["folder"])
	var side: = -1 if index % 2 == 1 else 1

	@warning_ignore("integer_division")
	await _wait(((index - 1) / 2) * 1.6)
	if called_off.call():
		return
	var car: Ambulance = held["car"]
	var door: = car.crew_door(side)
	var chassis: = car.chassis.global_transform
	var outward: = chassis.basis.x * side
	var facing_out: = func(point: Vector3) -> Transform3D:
		return Transform3D(Basis.looking_at(Vector3(outward.x, 0, outward.z).normalized()), chassis * point)
	var inside: Transform3D = facing_out.call(door["inside"])
	var outside: Transform3D = facing_out.call(door["outside"])


	door["open"].call(true)
	await _wait(0.45)
	if called_off.call():
		return
	var skin: = randi() % Medic.SKIN.size()
	var medic: = Medic.new(Medic.SKIN[skin])
	_medics_made += 1
	medic.set_meta("id", _medics_made)
	medic.set_meta("skin", skin)
	held["crew"].append(medic)
	held["folder"].add_child(medic)
	_stand_medic(medic, inside)
	var stepped: = 0.0
	while stepped < STEP_OUT_TIME:
		stepped += await _frame()
		if called_off.call():
			medic.queue_free()
			return
		_stand_medic(medic, inside.interpolate_with(outside, minf(stepped / STEP_OUT_TIME, 1.0)))
	var car_id: = car.get_instance_id()
	var door_name: = "DoorCabLeft" if side < 0 else "DoorCabRight"
	get_tree().create_timer(0.8, false).timeout.connect( func() -> void :
		var still: = instance_from_id(car_id) as Ambulance
		if still:
			still.swing(door_name, 0.0)
	)


	var base: Transform3D = held["place"]["base"]
	await _walk_to(medic, base * Vector3(side * (Ambulance.half_width() + 1.7), 0, Ambulance.rear() + 0.8))
	if called_off.call():
		if is_instance_valid(medic):
			medic.queue_free()
		return
	await _walk_to(medic, place.origin)
	if is_instance_valid(medic):
		_stand_medic(medic, place)
		medic.side = side
		held["medics"].append(medic)



func _medic_in(held: Dictionary, medic: Medic) -> void :
	var car: Ambulance = held["car"]
	var side: = medic.side
	var door: = car.crew_door(side)
	var chassis: = car.chassis.global_transform
	var inward: = - chassis.basis.x * side
	var facing_in: = func(point: Vector3) -> Transform3D:
		return Transform3D(Basis.looking_at(Vector3(inward.x, 0, inward.z).normalized()), chassis * point)
	var inside: Transform3D = facing_in.call(door["inside"])
	var outside: Transform3D = facing_in.call(door["outside"])

	var base: Transform3D = held["place"]["base"]
	await _walk_to(medic, base * Vector3(side * (Ambulance.half_width() + 1.7), 0, Ambulance.rear() + 0.8))
	if not is_instance_valid(medic):
		return
	await _walk_to(medic, outside.origin)
	if not is_instance_valid(medic) or not is_instance_valid(car):
		return
	_stand_medic(medic, outside)
	door["open"].call(true)
	await _wait(0.5)
	var stepped: = 0.0
	while stepped < STEP_OUT_TIME and is_instance_valid(medic):
		stepped += await _frame()
		if is_instance_valid(medic):
			_stand_medic(medic, outside.interpolate_with(inside, minf(stepped / STEP_OUT_TIME, 1.0)))
	if is_instance_valid(medic):
		medic.queue_free()
	if is_instance_valid(car):
		door["open"].call(false)
	await _wait(0.6)






func _lane_points(route: Array, from_along: float, to_along: float) -> Array:
	var points: Array = []
	for index in route.size():
		var id: int = route[index]
		var segment: Dictionary = graph.segments[id]
		var length: float = segment["length"]
		var first: = from_along if index == 0 else 0.0
		var last: = minf(to_along, length) if index == route.size() - 1 else length
		var along: = first
		while along < last:
			var s: = NavGraph.sample(segment, along)
			points.append({"x": s.x, "z": s.y, "seg": id, "along": along})
			along += DRIVE_STEP
		if last >= first:
			var s: = NavGraph.sample(segment, last)
			points.append({"x": s.x, "z": s.y, "seg": id, "along": last})
	return points



func _measured(points: Array) -> Array:
	var at: = 0.0
	for index in points.size():
		var point: Dictionary = points[index]
		point["position"] = Vector3(point["x"], ground_at(point["x"], point["z"]), point["z"])
		if index > 0:
			at += point["position"].distance_to(points[index - 1]["position"])
		point["at"] = at
	return points if points.size() > 1 and at > 1.0 else []



static func _on_path(path: Array, distance: float) -> Array:
	distance = clampf(distance, 0.0, path[path.size() - 1]["at"])
	var index: = 0
	while index < path.size() - 2 and path[index + 1]["at"] < distance:
		index += 1
	var a: Dictionary = path[index]
	var b: Dictionary = path[index + 1]
	var span: float = b["at"] - a["at"]
	var position: Vector3 = a["position"].lerp(b["position"], (distance - a["at"]) / span if span > 0.0 else 0.0)
	return [position, a]



func _shortest_route(ends: Array, lane: int, inward: bool) -> Array:
	var best: Array = []
	var best_length: = INF
	for id: int in ends:
		var route: = graph.drive_route(id if inward else lane, lane if inward else id)
		if not route.is_empty() and graph.route_length < best_length:
			best = route
			best_length = graph.route_length
	return best



static func _pose_on(path: Array, distance: float, fallback: Basis) -> Transform3D:
	var position: Vector3 = _on_path(path, distance)[0]
	var way: Vector3 = _on_path(path, distance + LOOK)[0] - _on_path(path, distance - LOOK)[0]
	way.y = 0.0
	return Transform3D(Basis.looking_at(way.normalized()) if way.length() > 0.1 else fallback, position)




func _drive(car: Ambulance, path: Array, from: float, to: float, check: = Callable()) -> bool:
	var speed: float = Config.Victims.DriveSpeed
	var travelled: = from
	var pace: = speed * 0.7

	car.set_solid(false)
	car.place(_pose_on(path, from, car.global_basis))
	while travelled < to:
		var dt: float = await _frame()
		if not is_instance_valid(car) or car.cancelled:
			return false
		var wanted: = minf(speed, sqrt(2.0 * BRAKING * (to - travelled)) + 3.0)
		pace += clampf(wanted - pace, - BRAKING * dt, ACCELERATION * dt)
		travelled = minf(to, travelled + pace * dt)
		var found: = _on_path(path, travelled)
		car.place(_pose_on(path, travelled, car.global_basis))
		var other: Array = check.call(found[1], to - travelled) if check.is_valid() else []
		if not other.is_empty():

			path = other
			to = other[other.size() - 1]["at"]
			travelled = minf(found[0].distance_to(other[0]["position"]), to)
	return true






func _mark_zone(held: Dictionary) -> void :
	var settings: Dictionary = Config.Victims
	if is_instance_valid(held.get("zone_model")):
		held["zone_model"].queue_free()
	var base: Transform3D = held["place"]["base"]
	var zone_size: Vector3 = settings["Zone"]
	var zone_at: = base * Vector3(0, 0, Ambulance.rear() + ZONE_GAP + zone_size.z / 2.0)
	var look: = - base.basis.z
	held["zone"] = standing(zone_at.x, zone_at.z, look.x, look.z)
	var model: = AmbulanceBuilder.zone()
	held["folder"].add_child(model)
	model.global_transform = held["zone"]
	held["zone_model"] = model



func _set_up(held: Dictionary, id: int) -> void :
	var settings: Dictionary = Config.Victims
	var base: Transform3D = held["place"]["base"]

	var behind: = base * Transform3D(Basis.IDENTITY, Vector3(0, 0, Ambulance.rear() + STRETCHER_GAP))
	held["stretcher_base"] = behind * Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3.ZERO)
	var stretcher: = AmbulanceBuilder.stretcher()
	held["top"] = stretcher.get_meta("top")

	held["car"].back_doors(true)
	get_tree().create_timer(0.6, false).timeout.connect( func() -> void :
		if _arrival == id and is_instance_valid(held["folder"]) and not held["packing"]:
			held["folder"].add_child(stretcher)
			stretcher.global_transform = held["stretcher_base"]
			held["stretcher"] = stretcher
		else:
			stretcher.free()
	)



	for index in range(1, int(settings["Medics"]) + 1):
		var side: = -1.0 if index % 2 == 1 else 1.0
		@warning_ignore("integer_division")
		var row: = (index - 1) / 2
		var at: = behind * Vector3(side * (MEDIC_ASIDE + row * 2.4), 0, 0.3)
		var place: = standing(at.x, at.z, base.basis.z.x, base.basis.z.z)
		held["coming_out"] += 1
		_medic_out_counted(held, id, index, place)

	held["arrived"] = true

	for figure: Node3D in held["waiting"]:
		_free_later(figure, float(settings["LoadTime"]))
	held["waiting"].clear()



func _medic_out_counted(held: Dictionary, id: int, index: int, place: Transform3D) -> void :
	await _medic_out(held, id, index, place)
	held["coming_out"] -= 1




func _free_later(node: Node, after: float) -> void :
	var id: = node.get_instance_id()
	get_tree().create_timer(after, false).timeout.connect( func() -> void :
		var found: = instance_from_id(id)
		if found is Node:
			found.queue_free()
	)



func _drive_in(held: Dictionary, id: int, target: Dictionary) -> void :
	var settings: Dictionary = Config.Victims
	var place: Dictionary = held["place"]
	var points: Array = []
	if place["seg"] >= 0:
		var route: = _shortest_route(graph.entries, place["seg"], true)
		if not route.is_empty():
			points = _lane_points(route, 0.0, maxf(place["along"] - KERB_RUN, 0.0))
			points.append({"x": place["base"].origin.x, "z": place["base"].origin.z, "seg": -1, "along": 0.0})
	var path: = _measured(points)

	var car: = Ambulance.new()
	held["car"] = car
	add_child(car)
	car.place(place["base"])
	if not path.is_empty():
		car.set_siren(true)
		var checked: = [false]
		var end: float = path[path.size() - 1]["at"]
		var seen: float = drive_from if drive_from >= 0.0 else float(settings["DriveFrom"])
		var arrived: bool = await _drive(car, path, maxf(end - seen, 0.0), end, func(point: Dictionary, remaining: float) -> Array:

			if checked[0] or remaining > RECHECK or point["seg"] < 0:
				return []
			checked[0] = true
			if has_room(held["place"]["base"]):
				return []
			var other: = find_place(target)
			if other["seg"] < 0:
				return []
			var onward: = graph.drive_route(point["seg"], other["seg"])
			if onward.is_empty() or (onward.size() == 1 and other["along"] - KERB_RUN <= point["along"]):
				return []
			var rest: = _lane_points(onward, point["along"], maxf(other["along"] - KERB_RUN, 0.0))
			rest.append({"x": other["base"].origin.x, "z": other["base"].origin.z, "seg": -1, "along": 0.0})
			var detour: = _measured(rest)
			if not detour.is_empty():
				held["place"] = other
				_mark_zone(held)
			return detour
		)
		if not arrived:
			return
		car.set_siren(false)
	if _arrival != id or not is_same(_scene, held):
		return

	car.place(held["place"]["base"])
	car.set_solid(true)
	_set_up(held, id)



func _drive_out(held: Dictionary) -> void :
	var car: Ambulance = held["car"]
	var place: Dictionary = held["place"]
	var points: Array = []
	if held["arrived"] and place["seg"] >= 0:
		var route: = _shortest_route(graph.exits, place["seg"], false)
		if not route.is_empty():
			points = _lane_points(route, place["along"] + KERB_RUN, INF)
			points.push_front({"x": place["base"].origin.x, "z": place["base"].origin.z, "seg": -1, "along": 0.0})
	var path: = _measured(points)
	if not path.is_empty():
		await _drive(car, path, 0.0, minf(path[path.size() - 1]["at"], float(Config.Victims.DriveAway)))
	if is_instance_valid(car):
		car.queue_free()







func arrive(target: Variant) -> Vector3:
	leave(0.0)
	_arrival += 1
	var id: = _arrival
	var plan: = footprint(target)

	var folder: = Node3D.new()
	folder.name = "AmbulanceScene"
	folder.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	add_child(folder)
	var held: = {
		"folder": folder, "place": find_place(plan), "waiting": [], "arrived": false, "medics": [], "coming_out": 0, 
		"car": null, "loading": null, "packing": false, "zone_model": null, 
		"id": id, "crew": [], "stretcher": null, 
	}
	_scene = held
	_shown.append(held)
	_mark_zone(held)
	_drive_in(held, id, plan)
	return held["zone"].origin



func arrive_at(at: Vector3, room: = 6.0, facing: = Vector3.FORWARD) -> Vector3:
	var flat: = Vector3(facing.x, 0, facing.z)
	var basis: = Basis.looking_at(flat.normalized()) if flat.length() > 0.01 else Basis.IDENTITY
	return arrive({"lot": Transform3D(basis, at), "size": Vector3(room * 2.0, 6.0, room * 2.0), "name": "the scene"})



func called() -> bool:
	return not _scene.is_empty()



func arrived() -> bool:
	return not _scene.is_empty() and _scene["arrived"]




func zone_position() -> Variant:
	return _scene["zone"].origin if not _scene.is_empty() else null



func car() -> Ambulance:
	if _scene.is_empty() or not is_instance_valid(_scene["car"]):
		return null
	return _scene["car"]



func in_zone(position: Vector3) -> bool:
	if _scene.is_empty():
		return false
	var size: Vector3 = Config.Victims.Zone
	var zone: Transform3D = _scene["zone"]
	var p: = zone.affine_inverse() * position
	return absf(p.x) <= size.x / 2.0 and absf(p.z) <= size.z / 2.0 and p.y > -3.0 and p.y < size.y + 4.0




func at_medic(position: Vector3) -> bool:
	if _scene.is_empty() or not _scene["arrived"]:
		return false
	var reach: = float(Config.Victims.Handover.HandRange)
	for medic: Variant in _scene["medics"]:
		if _there(medic):
			var at: Vector3 = medic.global_position
			if Vector2(at.x - position.x, at.z - position.z).length() <= reach and absf(at.y - position.y) < 6.0:
				return true
	return false





func _meet(delta: float) -> void :
	if _scene.is_empty() or not _scene["arrived"] or _scene["packing"]:
		return
	var medics: Array = _scene["medics"]
	if medics.is_empty():
		return
	var settings: Dictionary = Config.Victims.Handover
	var people: = VictimService.current
	var carriers: Array[Vector3] = people.carriers() if people != null else ([] as Array[Vector3])
	var zone: Vector3 = _scene["zone"].origin
	var target: = Vector3.INF
	var best: = INF
	for at: Vector3 in carriers:
		var distance: = Vector2(at.x - zone.x, at.z - zone.z).length()
		if distance <= float(settings["MeetRange"]) and distance < best:
			best = distance
			target = at
	var walker: Variant = null
	if target != Vector3.INF:
		var nearest: = INF
		for medic: Variant in medics:
			if _there(medic):
				var distance: float = medic.global_position.distance_to(target)
				if distance < nearest:
					nearest = distance
					walker = medic
	for medic: Variant in medics:
		if not _there(medic):
			continue
		if not medic.has_meta("home"):
			medic.set_meta("home", medic.global_transform)
		var home: Transform3D = medic.get_meta("home")
		var goal: = home.origin
		if medic == walker:
			var toward: = target - home.origin
			toward.y = 0.0
			var reach: = clampf(toward.length() - float(settings["HandRange"]) * 0.6, 0.0, float(settings["MeetReach"]))
			if toward.length() > 0.01:
				goal = home.origin + toward.normalized() * reach
		_step_medic(medic, goal, home, delta)



func _step_medic(medic: Medic, goal: Vector3, home: Transform3D, delta: float) -> void :
	var at: = medic.global_position
	var flat: = Vector3(goal.x - at.x, 0, goal.z - at.z)
	if flat.length() < 0.2:
		if medic.speed != 0.0 and goal.distance_to(home.origin) < 0.3:
			_stand_medic(medic, home)
		medic.speed = 0.0
		return
	var stride: = minf(MEDIC_PACE * delta, flat.length())
	var next: = at + flat.normalized() * stride
	next.y = ground_at(next.x, next.z)
	medic.speed = MEDIC_PACE
	medic.stand(Transform3D(Basis.looking_at(flat.normalized()), next))




func receive(figure: Figure) -> void :
	if _scene.is_empty():

		figure.visible = false
		_free_later(figure, 0.25)
		return
	var held: = _scene
	if figure.get_parent():
		figure.get_parent().remove_child(figure)
	held["folder"].add_child(figure)
	if not held["arrived"]:
		figure.pose("lying")
		var zone: Transform3D = held["zone"]
		var row: int = held["waiting"].size() % 3 - 1
		figure.global_transform = Figure.lying(zone * Vector3(row * 3.0, 0, 0), - zone.basis.z, 0.05)
		held["waiting"].append(figure)
		return

	if is_instance_valid(held["loading"]):
		held["loading"].queue_free()
	held["loading"] = figure
	figure.pose("stretcher")

	var stretcher: Transform3D = held["stretcher_base"]
	figure.global_transform = Figure.lying(stretcher.origin, stretcher.basis.z, held["top"])
	var id: = figure.get_instance_id()
	get_tree().create_timer(float(Config.Victims.LoadTime), false).timeout.connect( func() -> void :
		var found: = instance_from_id(id)
		if found is Node:
			if is_same(held["loading"], found):
				held["loading"] = null
			found.queue_free()
	)



func leave(after: = 0.0) -> void :
	if _scene.is_empty():
		return
	var leaving: = _scene
	_scene = {}
	if after > 0.0:
		get_tree().create_timer(after, false).timeout.connect( func() -> void : _go(leaving))
	else:
		_go(leaving)


func _go(leaving: Dictionary) -> void :
	var car: Ambulance = leaving["car"] if is_instance_valid(leaving["car"]) else null
	if car == null or not leaving["arrived"]:

		leaving["folder"].queue_free()
		if car:
			car.cancelled = true
			car.set_siren(false)
			car.queue_free()
		return



	var waited: = 0.0
	while leaving["coming_out"] > 0 and waited < 15.0:
		waited += await _frame()
	leaving["packing"] = true
	for child in leaving["folder"].get_children():
		if not leaving["medics"].has(child):
			child.queue_free()
	car.back_doors(false)
	var boarding: = [0]
	for medic: Medic in leaving["medics"]:
		boarding[0] += 1
		_board(leaving, medic, boarding)
	waited = 0.0
	while boarding[0] > 0 and waited < 20.0:
		waited += await _frame()
	leaving["folder"].queue_free()
	_drive_out(leaving)


func _board(leaving: Dictionary, medic: Medic, boarding: Array) -> void :
	await _medic_in(leaving, medic)
	boarding[0] -= 1


func _process(delta: float) -> void :
	if Net.is_client():
		_follow(delta)
	else:
		_meet(delta)

	if _scene.is_empty() or not is_instance_valid(_scene["zone_model"]):
		return
	var pad: MeshInstance3D = _scene["zone_model"].get_meta("pad")
	var glow: = 0.5 + 0.5 * sin(Game.now() * 3.0)
	var material: StandardMaterial3D = pad.material_override
	material.albedo_color.a = 1.0 - (0.3 + 0.35 * glow)





static func _there(node: Variant) -> bool:
	return is_instance_valid(node) and not node.is_queued_for_deletion() and node.is_inside_tree()




func _net_state() -> Variant:
	var list: Array = []
	for held: Dictionary in _shown.duplicate():
		var here: = _there(held["folder"])
		var car: Ambulance = held["car"] if _there(held["car"]) else null
		if not here and car == null:
			_shown.erase(held)
			continue
		var figures: Array = []
		if here:
			for child in held["folder"].get_children():
				if child is Figure and child.visible and not child.is_queued_for_deletion():
					figures.append([child.seed_number, child.global_transform, child.pose_name])
		list.append({
			"id": held["id"], 
			"current": is_same(held, _scene), 
			"base": held["place"]["base"], 
			"seg": held["place"]["seg"], 
			"zone": held["zone"] if _there(held["zone_model"]) else null, 
			"arrived": held["arrived"], 
			"car": car != null, 
			"siren": car.siren if car else 0, 
			"solid": car.is_solid() if car else false, 
			"doors": car.door_angles.duplicate() if car else {}, 
			"stretcher": held["stretcher"].global_transform if _there(held["stretcher"]) else null, 
			"figures": figures, 
		})
	return list




func _net_motion() -> Variant:
	var all: = {}
	for held: Dictionary in _shown:
		var crew: Array = []
		for medic: Variant in held["crew"]:
			if _there(medic):
				crew.append([medic.get_meta("id"), medic.get_meta("skin"), medic.global_transform, medic.speed])
		var car: Variant = held["car"]
		all[held["id"]] = [car.global_transform if (_there(car) and car.is_placed()) else null, crew]
	return all




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array:
		return
	_mirroring = not leaving
	var told: = {}
	_scene = {}
	for state: Dictionary in list:
		var id: int = state["id"]
		told[id] = true
		var mirror: Dictionary = _mirrors.get(id, {})
		if mirror.is_empty():
			var folder: = Node3D.new()
			folder.name = "AmbulanceScene"
			folder.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
			add_child(folder)
			mirror = {"folder": folder, "zone": Transform3D.IDENTITY, "zone_model": null, "car": null, "medics": {}, "stretcher": null, "figures": {}, "arrived": false, "place": {}}
			_mirrors[id] = mirror
		var folder: Node3D = mirror["folder"]
		mirror["arrived"] = state["arrived"]
		mirror["place"] = {"base": state["base"], "seg": state["seg"], "along": 0.0}


		var zone: Variant = state["zone"]
		if zone == null and is_instance_valid(mirror["zone_model"]):
			mirror["zone_model"].queue_free()
			mirror["zone_model"] = null
		elif zone != null:
			if not is_instance_valid(mirror["zone_model"]):
				mirror["zone_model"] = AmbulanceBuilder.zone()
				folder.add_child(mirror["zone_model"])
			mirror["zone"] = zone
			mirror["zone_model"].global_transform = zone


		var car: Ambulance = mirror["car"] if is_instance_valid(mirror["car"]) else null
		if state["car"] and car == null:
			car = Ambulance.new()
			car.visible = false
			add_child(car)
			car.place(state["base"])
			mirror["car"] = car
			mirror.erase("car_to")
		elif not state["car"] and car != null:
			car.queue_free()
			car = null
			mirror["car"] = null
		if car != null:
			if (car.siren > 0) != (int(state["siren"]) > 0):
				car.set_siren(int(state["siren"]) > 0)
			if car.is_solid() != state["solid"]:
				car.set_solid(state["solid"])
			var doors: Dictionary = state["doors"]
			for door_name: String in doors:
				if not is_equal_approx(float(car.door_angles.get(door_name, 0.0)), float(doors[door_name])):
					car.swing(door_name, doors[door_name])


		var stretcher: Variant = state["stretcher"]
		if stretcher == null and is_instance_valid(mirror["stretcher"]):
			mirror["stretcher"].queue_free()
			mirror["stretcher"] = null
		elif stretcher != null:
			if not is_instance_valid(mirror["stretcher"]):
				mirror["stretcher"] = AmbulanceBuilder.stretcher()
				folder.add_child(mirror["stretcher"])
			mirror["stretcher"].global_transform = stretcher
		var lying: Dictionary = mirror["figures"]
		var listed: = {}
		for row: Array in state["figures"]:
			listed[row[0]] = true
			var figure: Figure = lying.get(row[0])
			if not is_instance_valid(figure):
				figure = Figure.build(row[0])
				folder.add_child(figure)
				lying[row[0]] = figure
			if figure.pose_name != row[2]:
				figure.pose(row[2])
			figure.global_transform = row[1]
		for person_seed: int in lying.keys():
			if not listed.has(person_seed):
				if is_instance_valid(lying[person_seed]):
					lying[person_seed].queue_free()
				lying.erase(person_seed)
		if state["current"]:
			_scene = mirror
	for id: int in _mirrors.keys():
		if not told.has(id):
			var gone: Dictionary = _mirrors[id]
			_mirrors.erase(id)
			if is_instance_valid(gone["folder"]):
				gone["folder"].queue_free()
			if is_instance_valid(gone["car"]):
				gone["car"].set_siren(false)
				gone["car"].queue_free()


func _net_apply_motion(all: Variant) -> void :
	if not Net.is_client() or not all is Dictionary:
		return
	for id: int in _mirrors:
		var entry: Variant = all.get(id)
		if not entry is Array:
			continue
		var mirror: Dictionary = _mirrors[id]
		if entry[0] != null and is_instance_valid(mirror["car"]):
			if not mirror.has("car_to"):
				mirror["car"].place(entry[0])
				mirror["car"].visible = true
			mirror["car_to"] = entry[0]
		var medics: Dictionary = mirror["medics"]
		var listed: = {}
		for row: Array in entry[1]:
			listed[row[0]] = true
			var medic: Medic = medics.get(row[0])
			if not is_instance_valid(medic):
				if not is_instance_valid(mirror["folder"]):
					continue
				medic = Medic.new(Medic.SKIN[int(row[1]) % Medic.SKIN.size()])
				mirror["folder"].add_child(medic)
				medic.stand(row[2])
				medics[row[0]] = medic
			medic.set_meta("to", row[2])
			medic.speed = row[3]
		for medic_id: int in medics.keys():
			if not listed.has(medic_id):
				if is_instance_valid(medics[medic_id]):
					medics[medic_id].queue_free()
				medics.erase(medic_id)



func _follow(delta: float) -> void :
	var ease: = 1.0 - exp( - delta * 16.0)
	for mirror: Dictionary in _mirrors.values():
		var car: Variant = mirror["car"]
		if is_instance_valid(car) and mirror.has("car_to"):
			var to: Transform3D = mirror["car_to"]
			car.place(to if car.global_position.distance_to(to.origin) > 25.0 else car.global_transform.interpolate_with(to, ease))
		for medic: Variant in mirror["medics"].values():
			if is_instance_valid(medic) and medic.has_meta("to"):
				var to: Transform3D = medic.get_meta("to")
				medic.stand(to if medic.global_position.distance_to(to.origin) > 8.0 else medic.global_transform.interpolate_with(to, ease))
