extends RefCounted
















const CHURCH: = Vector2(1226, -279)
const CASTLE: = Vector2(1639, -674)
const SHORTEN: = 0.55
const TERRACE_TOP: = 34.0
const TERRACE: = Vector3(150.0, 270.0, 135.0)

const LIMEWASH: = Color8(237, 230, 214)
const OCHRE: = Color8(217, 164, 91)
const PALE_OCHRE: = Color8(228, 196, 140)
const ROSE: = Color8(214, 176, 158)
const TILES: = Color8(154, 75, 53)
const OLD_TILES: = Color8(126, 63, 48)
const TIN: = Color8(150, 156, 162)
const STONE: = Color8(176, 170, 156)
const MEADOW: = Color8(112, 140, 82)
const DARK: = Color8(58, 60, 66)
const LIME: = Color8(52, 86, 50)


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	OldTown.lit.clear()
	var gone: = _clear(kit)
	var parent: = kit.own_folder("OldTown")
	var rng: = kit.rng("old town")
	var along: = (CASTLE - CHURCH).normalized()
	var across: = Vector2( - along.y, along.x)
	var axis: = Basis(Vector3(across.x, 0, across.y), Vector3.UP, Vector3(along.x, 0, along.y))
	var length: = (CASTLE - CHURCH).length() * SHORTEN
	var spot: = func(s: float, t: float) -> Vector3:
		var at: = CHURCH + along * s + across * t
		return Vector3(at.x, _height(s, t), at.y)
	var before: = store.count


	var middle: Vector3 = spot.call(TERRACE.x, 0.0)
	var mound: = Transform3D(axis, Vector3(middle.x, 0.0, middle.z))
	store.add(PartStore.Shape.ELLIPSOID, mound, Vector3(TERRACE.z * 2.0, TERRACE_TOP * 2.0, TERRACE.y * 2.0), MEADOW, "Grass", "OldTownTerrace", parent, PolishKit.LOOK)
	for s: float in [-20.0, 60.0, 140.0, 220.0, 300.0]:
		var t: = - TERRACE.z * 0.62
		var foot: Vector3 = spot.call(s, t)
		kit.box(parent, Transform3D(axis, foot + Vector3(0, -3, 0)), Vector3(3.0, 12.0, 84.0), STONE, "Cobblestone", "OldTownWall")


	_house(kit, parent, axis, spot.call(-38.0, 0.0), Vector3(30, 30, 64), 17.0, LIMEWASH, OLD_TILES, "Church", -1.0)
	var tower: Vector3 = spot.call(2.0, 0.0)
	kit.box(parent, Transform3D(axis, tower + Vector3(0, 36, 0)), Vector3(17, 92, 17), LIMEWASH, "Plaster", "ChurchTower")
	for side: float in [-1.0, 1.0]:
		kit.box(parent, Transform3D(axis, tower + axis * Vector3(side * 8.6, 70, 0)), Vector3(0.4, 8, 5), DARK, "SmoothPlastic", "Belfry")
		kit.box(parent, Transform3D(axis, tower + axis * Vector3(0, 70, side * 8.6)), Vector3(5, 8, 0.4), DARK, "SmoothPlastic", "Belfry")
	kit.box(parent, Transform3D(axis, tower + Vector3(0, 82.5, 0)), Vector3(19, 1.5, 19), STONE, "Plaster", "TowerCornice")
	_pyramid(kit, parent, axis, tower + Vector3(0, 83, 0), 19.0, 26.0, TIN, "Metal", "TowerRoof")
	OldTown.bell_at = tower + Vector3(0, 70, 0)
	OldTown.lit.append({"at": tower + Vector3(0, 41, 0), "size": Vector3(17.6, 82, 17.6), "basis": axis, "color": LIMEWASH})


	_house(kit, parent, axis, spot.call(34.0, -40.0), Vector3(22, 32, 46), 12.0, PALE_OCHRE, OLD_TILES, "Commandery", -1.0)


	var s: = 60.0
	var palette: = [LIMEWASH, OCHRE, LIMEWASH, ROSE, PALE_OCHRE, LIMEWASH]
	var index: = 0
	while s < length - 70.0:
		var width: = rng.randf_range(20.0, 30.0)
		var half_square: = 16.0 + (s - 60.0) * 0.07
		for side: float in [-1.0, 1.0]:
			var height: = 24.0 if rng.randf() < 0.75 else 33.0
			var depth: = rng.randf_range(18.0, 24.0)
			var colour: Color = palette[(index + int(side > 0) * 3) % palette.size()]
			var foot: Vector3 = spot.call(s + width / 2.0, side * (half_square + depth / 2.0))
			_house(kit, parent, axis, foot, Vector3(depth, height, width - 1.5), depth * 0.38, colour, TILES if rng.randf() < 0.6 else OLD_TILES, "SquareHouse", -1.0 if side < 0.0 else 0.0)
		s += width
		index += 1

	var paved_from: = 46.0
	var paved_to: = s
	var paving: Vector3 = spot.call((paved_from + paved_to) / 2.0, 0.0)
	kit.box(parent, Transform3D(axis, paving + Vector3(0, -0.8, 0)), Vector3(34, 2.0, paved_to - paved_from), STONE, "Cobblestone", "MestniTrg")
	var lime: Vector3 = spot.call(80.0, 4.0)
	kit.post(parent, lime + Vector3(0, -1, 0), 10.0, 2.4, Color8(84, 66, 52), "Wood", "SquareLimeTrunk")
	kit.ball(parent, lime + Vector3(0, 16, 0), Vector3(22, 17, 22), LIME, "Grass", "SquareLimeCrown")



	var castle_front: = length - 30.0
	var court: = 26.0
	var cross: = axis * Basis(Vector3.UP, PI / 2.0)
	_house(kit, parent, cross, spot.call(castle_front, 0.0), Vector3(16, 30, 2.0 * court + 16.0), 9.0, LIMEWASH, TILES, "Castle", 1.0)
	for side: float in [-1.0, 1.0]:
		_house(kit, parent, axis, spot.call(castle_front + 34.0, side * (court + 8.0)), Vector3(16, 28, 54), 9.0, LIMEWASH, TILES, "Castle", -1.0 if side < 0.0 else 0.0)
	_house(kit, parent, cross * Basis(Vector3.UP, 0.22), spot.call(castle_front + 66.0, 4.0), Vector3(15, 27, 2.0 * court + 10.0), 8.0, LIMEWASH, OLD_TILES, "Castle")
	var gate: Vector3 = spot.call(castle_front - 9.0, 0.0)
	kit.box(parent, Transform3D(axis, gate + Vector3(0, 17, 0)), Vector3(15, 54, 15), LIMEWASH, "Plaster", "CastleGateTower")
	kit.box(parent, Transform3D(axis, gate + axis * Vector3(0, 6, -7.6)), Vector3(6, 11, 0.4), DARK, "SmoothPlastic", "CastleGate")
	_pyramid(kit, parent, axis, gate + Vector3(0, 44, 0), 17.0, 13.0, TILES, "ClayRoofTiles", "CastleGateRoof")
	OldTown.lit.append({"at": gate + Vector3(0, 22, 0), "size": Vector3(15.6, 44, 15.6), "basis": axis, "color": LIMEWASH})
	OldTown.lit.append({"at": spot.call(castle_front, 0.0) + Vector3(0, 15, 0), "size": Vector3(2.0 * court + 16.6, 30, 16.6), "basis": axis, "color": LIMEWASH})

	_house(kit, parent, axis, spot.call(castle_front + 20.0, - (court + 40.0)), Vector3(14, 15, 50), 7.0, PALE_OCHRE, TILES, "FireMuseum", -1.0)
	return "the old town on the skyline (%d parts; %d of the export's backdrop taken away)" % [store.count - before, gone]



static func _height(s: float, t: float) -> float:
	var u: = (s - TERRACE.x) / TERRACE.y
	var v: = t / TERRACE.z
	return TERRACE_TOP * sqrt(maxf(0.0, 1.0 - u * u - v * v)) - 1.0




static func _clear(kit: PolishKit) -> int:
	var store: = kit.store
	var along: = (CASTLE - CHURCH).normalized()
	var across: = Vector2( - along.y, along.x)
	var gone: = 0
	var rows: = kit.rows_under("Map/Backdrop")
	rows.append_array(kit.rows_under("Map/Polish/Backdrop"))
	for row in rows:
		var part_name: = store.name_at(row)
		var at: = store.position(row)
		var local: = Vector2(at.x, at.z) - CHURCH
		var s: = local.dot(along)
		var t: = local.dot(across)
		var inside: = absf((s - TERRACE.x) / TERRACE.y) < 1.0 and absf(t / TERRACE.z) < 1.0 and store.size(row).x < 400.0
		if part_name.begins_with("Church") or inside:
			store.set_transparency(row, 1.0)
			gone += 1
	return gone





static func _house(kit: PolishKit, parent: int, axis: Basis, foot: Vector3, size: Vector3, rise: float, wall: Color, roof: Color, part_name: String, windows: = 0.0) -> void :

	kit.box(parent, Transform3D(axis, foot + Vector3(0, size.y / 2.0 - 7.0, 0)), size + Vector3(0, 14, 0), wall, "Plaster", part_name)
	var top: = foot + Vector3(0, size.y, 0)
	for flip: float in [0.0, PI]:
		var turn: = axis * Basis(Vector3.UP, PI / 2.0 + flip)
		kit.wedge(parent, Transform3D(turn, top + turn * Vector3(0, rise / 2.0, - size.x / 4.0 - 0.2)), Vector3(size.z + 1.2, rise, size.x / 2.0 + 0.4), roof, "ClayRoofTiles", part_name + "Roof")
	if windows == 0.0:
		return
	for storey in maxi(1, int(size.y / 11.0)):
		var at: = foot + axis * Vector3(windows * (size.x / 2.0 + 0.15), 6.0 + storey * 11.0, 0)
		kit.box(parent, Transform3D(axis, at), Vector3(0.3, 3.4, size.z * 0.8), DARK, "SmoothPlastic", part_name + "Windows")




static func _pyramid(kit: PolishKit, parent: int, axis: Basis, base: Vector3, width: float, rise: float, color: Color, material: String, part_name: String) -> void :
	for quarter in 4:
		var turn: = axis * Basis(Vector3.UP, quarter * PI / 2.0)
		var place: = Transform3D(turn, base + turn * Vector3( - width / 4.0, rise / 2.0, width / 4.0))
		kit.store.add(PartStore.Shape.CORNER_WEDGE, place, Vector3(width / 2.0, rise, width / 2.0), color, material, part_name, parent, PolishKit.LOOK)
