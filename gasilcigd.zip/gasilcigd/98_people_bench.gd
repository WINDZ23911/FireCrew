extends RefCounted



static func start(main: Node) -> void :
	if OS.get_cmdline_user_args().has("--peoplebench"):
		var bench: = PeopleBench.new()
		bench.name = "PeopleBench"
		main.add_child(bench)
