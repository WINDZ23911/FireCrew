extends RefCounted



static func start(main: Node) -> void :
	var weather: = Weather.new()
	weather.name = "Weather"
	main.add_child(weather)
