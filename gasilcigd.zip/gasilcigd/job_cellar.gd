class_name JobCellar
extends CrewJob




func _init() -> void :
	kind = "pump"
	role = "pump"


func place() -> Vector3:
	return FloodedCellar.current.position


func run() -> bool:
	var cellar: = FloodedCellar.current
	if cellar == null or cellar.source.is_empty():
		return fail("crew.say.nothingThere")
	var source: Dictionary = cellar.source
	var held: = who.token()
	if source.get("rig") == null:

		var truck: Vehicle = null
		var best: = float(Config.Hose.SupplyLength) - 10.0
		for vehicle in Vehicle.all:
			var rig: = CrewWater.rig_of(vehicle)
			if rig.is_empty() or vehicle.intake.is_empty() or vehicle.outlets.is_empty() or rig["supply"]["state"] != "stowed":
				continue
			var distance: float = vehicle.intake["node"].global_position.distance_to(source["position"])
			if distance < best:
				best = distance
				truck = vehicle
		if truck == null:
			return fail("crew.say.hoseShort")
		var job: = JobSupply.new(truck, source)
		job.who = who
		if not await job.run():
			job.finish(false)
			reason = job.reason
			return false
	if not on(held):
		return false
	await who.wait(0.6, held)
	var discharge: Dictionary = cellar.discharge
	if discharge.is_empty():
		return fail("crew.say.cannot")
	if not discharge["open"]:
		if not await who.press(discharge["prompt"]):
			return fail("crew.say.stuck") if on(held) else false
	return discharge["open"]
