extends ProofDebug






func _ladder_ready() -> Array:
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var away: = Vector3(1, 0, 0)
	var stand: = _open_spot(Vector3(-12, 0, -22) + away * 10.0, away, truck)
	_park(truck, stand, PI / 2)
	player.teleport(_ground(truck.global_position + away * 12.0) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	var settling: = 0.0
	while truck.linear_velocity.length() > 0.5 and settling < 8.0:
		await _wait(0.25)
		settling += 0.25
	return [ladder, truck, away]


func _scenario_ladderlow() -> void :
	await _wait(1.0)
	var ready: Array = await _ladder_ready()
	var ladder: LadderService = ready[0]
	var truck: Vehicle = ready[1]
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME + 0.6)
	if not _check(ladder.state == "ready", "the stabilisers go down"):
		await _done()
		return
	ladder.sit(player, false)
	await _wait(0.4)
	_check(ladder.controller == player, "the player takes the turntable's controls")
	_view(truck.global_position + Vector3(40, 18, 40), truck.global_position + Vector3(0, 6, 0))

	Input.action_press("move_forward")
	while ladder.elevation < 30.0:
		await _wait(0.1)
	Input.action_release("move_forward")
	Input.action_press("move_right")
	var turning: = 0.0
	while absf(ladder.turned) < 85.0 and turning < 12.0:
		await _wait(0.1)
		turning += 0.1
	Input.action_release("move_right")
	Input.action_press("ladder_extend")
	await _wait(2.5)
	Input.action_release("ladder_extend")
	await _wait(0.3)
	print("ladderlow: raised %.0f°, turned %.0f°, out %.1f studs; basket %.1f studs up" % [ladder.elevation, ladder.turned, ladder.extension, ladder.height()])
	Input.action_press("move_back")
	var lowering: = 0.0
	var last: = ladder.elevation
	var still: = 0.0
	var said: Variant = null
	while lowering < 20.0:
		await _wait(0.1)
		lowering += 0.1
		if ladder.blocked != null:
			said = ladder.blocked
		if absf(ladder.elevation - last) < 0.01:
			still += 0.1
			if still > 0.8:
				break
		else:
			still = 0.0
		last = ladder.elevation
	Input.action_release("move_back")
	await _wait(0.4)
	var room: = ladder._floor_room(ladder.elevation, ladder.extension)
	print("ladderlow: lowest: %.1f° (turned %.0f°, out %.1f), the basket's floor %.2f studs off the ground, %.1f up by height(); said '%s'" % [ladder.elevation, ladder.turned, ladder.extension, room, ladder.height(), Text.say(said, "en") if said != null else ""])
	_check(ladder.elevation < -6.0, "turned off the body the ladder goes below level")
	_check(room >= 0.0 and room < 1.5, "and stops with the basket's floor just off the ground, not in it")
	_check(said != null and Text.say(said, "en").contains("ground"), "the panel says the basket is on the ground")
	await _snap("basket_on_road")

	var basket: Vector3 = ladder.basket_position()
	print("ladderlow: the basket's floor at %s; the perch prompt reaches %.0f" % [basket, LadderService.PERCH_REACH])

	ladder.stowing = true
	var stowing: = 0.0
	var lowest_turned: = 0.0
	var crossed_low: = false
	while not ladder.lies_stowed() and stowing < 40.0:
		await _wait(0.2)
		stowing += 0.2
		if absf(ladder.turned) > 4.0 and absf(ladder.turned) < LadderService.LOW_TURN and ladder.elevation < LadderService.CLEAR_ELEVATION - 0.5:
			crossed_low = true
	print("ladderlow: stowed in %.0f s: %.1f°, turned %.0f°, out %.1f; swung back low %s" % [stowing, ladder.elevation, ladder.turned, ladder.extension, crossed_low])
	_check(ladder.lies_stowed(), "stowing brings it back onto its rest")
	_check( not crossed_low, "it came up before swinging back over the body")
	await _done()


func _scenario_ladderboard() -> void :
	await _wait(1.0)
	var ready: Array = await _ladder_ready()
	var truck: Vehicle = ready[1]

	var data: = truck.data
	var given: Variant = data.get("rearLadder")
	var rungs: Dictionary = Vehicle.table(given[0] if given is Array and not given.is_empty() else given)
	if not _check( not rungs.is_empty(), "the ladder truck has steps up onto its deck"):
		await _done()
		return
	var half: = float(data["halfWidth"])
	var side: = float(rungs.get("side", 0.0))
	var out: = Vector3(side, 0, 0) if side != 0.0 else Vector3(0, 0, 1)
	var anchor: = Vector3(float(rungs["x"]), 0, float(rungs["z"]))
	player.teleport(truck.to_global(anchor + out * 2.2 + Vector3(0, float(data["ground"]) + 0.3, 0)))
	await _wait(0.4)
	_look_at(truck.to_global(anchor - out * 2.0 + Vector3(0, float(data["ground"]) + 3.0, 0)))
	await _wait(0.2)
	var start_y: = player.global_position.y
	var deck_y: float = truck.to_global(anchor - out * 3.0 + Vector3(0, float(rungs["top"]), 0)).y
	_view(truck.to_global(anchor + out * 9.0 + Vector3( - out.z, 0, out.x) * 8.0 + Vector3(0, 7.0, 0)), truck.to_global(anchor - out * 2.0 + Vector3(0, 4.0, 0)))
	Input.action_press("move_forward")
	var walked: = 0.0
	var top: = start_y
	while walked < 7.0:
		await _wait(0.1)
		walked += 0.1
		top = maxf(top, player.global_position.y)
		var on: = truck.to_local(player.global_position)
		if on.y >= float(rungs["top"]) - 0.3 and (on - anchor).dot(out) < -0.2 and walked > 1.0:
			break
	Input.action_release("move_forward")
	await _wait(0.5)
	var local: = truck.to_local(player.global_position)
	print("ladderboard: from %.1f up to %.1f (deck at %.1f) in %.1f s; now at %s in the truck's space" % [start_y, top, deck_y, walked, local])
	_check(local.y >= float(rungs["top"]) - 0.4 and (local - anchor).dot(out) < 0.0, "the steps are climbed up onto the deck")
	_check(absf(local.x) < half, "and the firefighter stands on the truck")
	await _snap("on_deck")
	await _done()




func _scenario_ladderlook() -> void :
	await _wait(1.0)
	var ready: Array = await _ladder_ready()
	var ladder: LadderService = ready[0]
	var truck: Vehicle = ready[1]
	player.teleport(truck.to_global(Vector3(30, 0, 40)))
	for view: Array in [["left", Vector3(-38, 5, 1), Vector3(0, 4, 1)], ["right", Vector3(38, 5, 1), Vector3(0, 4, 1)], 
			["front", Vector3(0, 5, -48), Vector3(0, 4, 0)], ["rear", Vector3(0, 7, 44), Vector3(0, 5, 4)], 
			["frontleft", Vector3(-22, 7, -34), Vector3(0, 4, 0)], ["frontright", Vector3(22, 7, -34), Vector3(0, 4, 0)], 
			["turntable", Vector3(-14, 12, 24), Vector3(0, 6, 10)], ["wheelwell", Vector3(-12, 0, 6), Vector3(-4, 0, 8)]]:
		_view(truck.to_global(view[1]), truck.to_global(view[2]))
		await _wait(0.6)
		await _snap(view[0])
	truck.blue_on = true
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME + 0.6)
	ladder.sit(player, false)
	await _wait(0.4)
	Input.action_press("move_forward")
	await _wait(2.5)
	Input.action_release("move_forward")
	Input.action_press("ladder_extend")
	await _wait(2.0)
	Input.action_release("ladder_extend")
	await _wait(0.5)
	_view(truck.to_global(Vector3(-40, 15, 30)), truck.to_global(Vector3(0, 14, 0)))
	await _wait(0.6)
	await _snap("raised")
	_check(ladder.elevation > 10.0, "the ladder goes up")
	await _done()
