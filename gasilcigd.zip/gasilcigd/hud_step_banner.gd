class_name HudStepBanner
extends Control






static var current: HudStepBanner

var _pill: PanelContainer
var _words: Label
var _said: = ""
var _call: = ""
var _pending: Variant = null
var _shown_at: = -100.0

var last_shown: = ""


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pill = PanelContainer.new()
	_pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(Ui.PANEL, 0.72)
	box.set_corner_radius_all(10)
	box.content_margin_left = 26
	box.content_margin_right = 26
	box.content_margin_top = 8
	box.content_margin_bottom = 10
	box.border_width_left = 4
	box.border_color = Ui.YELLOW
	_pill.add_theme_stylebox_override("panel", box)
	_pill.visible = false
	add_child(_pill)
	_words = Ui.display("", int(settings()["BannerSize"]), Color(1.0, 0.93, 0.6))
	_words.add_theme_constant_override("outline_size", 6)
	_words.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	_words.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_pill.add_child(_words)


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Onboarding.NextSteps


func _process(_delta: float) -> void :
	var incident: = Game.incident
	var next: Variant = null if incident.is_empty() or incident.has("failed") else incident.get("next")
	var call_name: = Text.say(incident.get("name", ""), "sl") if not incident.is_empty() else ""
	var said: = ""
	if next is Dictionary:
		said = str(next.get("k", Text.say(next, "sl")))
	elif next != null:
		said = Text.say(next, "sl")
	if call_name != _call:
		_call = call_name
		_said = ""
	if said != _said:
		var first: = _said.is_empty()
		_said = said
		if next != null:
			_pending = next
			if first:
				Sounds.ui("ui_tick")

	if _pending != null and not HudFireOut.holding() and not Game.ui_open:
		_words.text = Text.say(_pending)
		last_shown = _words.text
		_pending = null
		_shown_at = Game.now()
	var age: = Game.now() - _shown_at
	var time: = float(settings()["BannerTime"])
	var fade: = float(settings()["BannerFade"])
	var shown: = age < time + fade and not Game.ui_open and not HudFireOut.holding() and not incident.is_empty()
	_pill.visible = shown
	if not shown:
		return
	_pill.modulate.a = clampf(age / fade, 0.0, 1.0) * clampf((time + fade - age) / fade, 0.0, 1.0)
	var view: = get_parent_area_size()
	_pill.size = Vector2.ZERO
	_pill.position = Vector2((view.x - _pill.size.x) / 2.0, view.y * float(settings()["BannerAt"]))



func showing() -> bool:
	return _pill.visible
