extends RefCounted










const WHITE: = Color8(242, 240, 234)
const ROOF: = Color8(58, 60, 64)
const GOLD: = Color8(214, 176, 60)
const LOUVRE: = Color8(70, 72, 76)
const BARN: = Color8(150, 40, 32)
const STAVE: = Color8(196, 192, 182)
const BLUE_SILO: = Color8(36, 58, 104)
const MORAVIAN: = Vector3(-1350, 0, -400)
const FARM: = Vector3(260, 0, 1290)


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "us":
		return ""
	var folder: = kit.own_folder("Landmarks")
	var said: Array[String] = []
	_church(kit, folder, _ground(kit, MORAVIAN), Vector3.RIGHT)
	said.append("the Moravian church on the skyline")
	_farm(kit, folder, _ground(kit, FARM), Vector3.BACK)
	said.append("a farm with its barn and silos")
	return "USA landmarks: " + ", ".join(said)



static func _ground(kit: PolishKit, at: Vector3) -> Vector3:
	var top: = 0.0
	for row in kit.parts_at(Vector3(at.x, 0, at.z)):
		var height: = kit._top(row)
		if height < 80.0 and kit.store.name_at(row) in ["Hill", "Ground", "Backdrop", "Field", "Meadow", "Edge", "Floor", "land", "ground"]:
			top = maxf(top, height)
	return Vector3(at.x, top, at.z)



static func _steeple(kit: PolishKit, folder: int, foot: Vector3, front: Vector3, high: float, wide: float) -> void :
	var place: = PolishKit.facing(foot, front)
	kit.box(folder, place.translated_local(Vector3(0, high / 2.0, 0)), Vector3(wide, high, wide), WHITE, "Siding", "SteepleTower")
	kit.box(folder, place.translated_local(Vector3(0, high + 0.4, 0)), Vector3(wide + 1.0, 0.8, wide + 1.0), WHITE, "SmoothPlastic", "SteepleCornice")
	var belfry: = wide - 1.6
	kit.box(folder, place.translated_local(Vector3(0, high + 0.8 + belfry / 2.0, 0)), Vector3(belfry, belfry, belfry), WHITE, "SmoothPlastic", "Belfry")
	for turn in 4:
		var face: = place * Transform3D(Basis(Vector3.UP, turn * PI / 2.0), Vector3.ZERO)
		kit.box(folder, face.translated_local(Vector3(0, high + 0.8 + belfry / 2.0, - belfry / 2.0 - 0.06)), Vector3(belfry * 0.45, belfry * 0.62, 0.12), LOUVRE, "WoodPlanks", "BelfryLouvre")
	var y: = high + 0.8 + belfry
	kit.box(folder, place.translated_local(Vector3(0, y + 0.3, 0)), Vector3(belfry + 0.8, 0.6, belfry + 0.8), WHITE, "SmoothPlastic", "SteepleCornice")
	y += 0.6

	var steps: = 9
	var spire: = wide * 2.4
	for step in steps:
		var t: = float(step) / steps
		var width: = belfry * 0.82 * (1.0 - t) + 0.25
		var turn: = Basis(Vector3.UP, PI / 4.0 if step % 2 == 1 else 0.0)
		kit.box(folder, place * Transform3D(turn, Vector3(0, y + spire / steps * (step + 0.5), 0)), Vector3(width, spire / steps + 0.05, width), WHITE, "SmoothPlastic", "Spire")
	y += spire
	kit.ball(folder, (place * Transform3D(Basis(), Vector3(0, y + 0.6, 0))).origin, Vector3(1.2, 1.2, 1.2), GOLD, "Metal", "SpireBall")
	kit.box(folder, place.translated_local(Vector3(0, y + 2.6, 0)), Vector3(0.25, 3.2, 0.25), GOLD, "Metal", "Weathervane")



static func _church(kit: PolishKit, folder: int, foot: Vector3, front: Vector3) -> void :
	var place: = PolishKit.facing(foot, front)
	var w: = 34.0
	var length: = 56.0
	var walls: = 26.0
	kit.box(folder, place.translated_local(Vector3(0, walls / 2.0, length / 2.0)), Vector3(w, walls, length), WHITE, "Siding", "ChurchNave")

	var pitch: = 13.0
	for side: float in [-1.0, 1.0]:
		var half: = Transform3D(Basis(Vector3.UP, PI / 2.0 if side > 0 else - PI / 2.0), Vector3.ZERO)
		kit.wedge(folder, place * Transform3D(Basis(), Vector3(side * w / 4.0, walls + pitch / 2.0, length / 2.0)) * half, Vector3(length + 2.0, pitch, w / 2.0 + 1.0), ROOF, "Slate", "ChurchRoof")
	for index in 5:
		for side: float in [-1.0, 1.0]:
			kit.box(folder, place.translated_local(Vector3(side * (w / 2.0 + 0.08), walls * 0.52, 10.0 + index * 9.5)), Vector3(0.2, 12.0, 4.2), Color8(60, 74, 92), "Glass", "ChurchWindow")
	_steeple(kit, folder, foot + front * 0.0, front, walls + 8.0, 13.0)



static func _farm(kit: PolishKit, folder: int, foot: Vector3, front: Vector3) -> void :
	var place: = PolishKit.facing(foot, front)
	kit.box(folder, place.translated_local(Vector3(0, 13.0, 0)), Vector3(44.0, 26.0, 70.0), BARN, "WoodPlanks", "Barn")
	for side: float in [-1.0, 1.0]:
		var half: = Transform3D(Basis(Vector3.UP, PI / 2.0 if side > 0 else - PI / 2.0), Vector3.ZERO)
		kit.wedge(folder, place * Transform3D(Basis(), Vector3(side * 11.0, 26.0 + 7.0, 0)) * half, Vector3(72.0, 14.0, 23.0), Color8(112, 116, 120), "Metal", "BarnRoof")
	kit.box(folder, place.translated_local(Vector3(0, 9.0, -35.1)), Vector3(16.0, 18.0, 0.3), Color8(236, 232, 224), "WoodPlanks", "BarnDoorTrim")
	kit.box(folder, place.translated_local(Vector3(0, 9.0, -35.25)), Vector3(14.0, 16.0, 0.3), BARN.darkened(0.15), "WoodPlanks", "BarnDoor")
	var silo: = (place * Transform3D(Basis(), Vector3(32.0, 0, 18.0))).origin
	kit.post(folder, silo, 58.0, 13.0, STAVE, "Concrete", "Silo")
	kit.ball(folder, silo + Vector3(0, 58.0, 0), Vector3(13.4, 7.0, 13.4), Color8(150, 154, 158), "Metal", "SiloDome")
	var blue: = (place * Transform3D(Basis(), Vector3(32.0, 0, -2.0))).origin
	kit.post(folder, blue, 64.0, 12.0, BLUE_SILO, "Metal", "Silo")
	kit.ball(folder, blue + Vector3(0, 64.0, 0), Vector3(12.4, 6.0, 12.4), BLUE_SILO, "Metal", "SiloDome")
