class_name FuelService
extends Node






const TICK: = 0.25
const PUMP_NAME: = "FuelPump"
const HOSE_COLOR: = Color(24 / 255.0, 24 / 255.0, 26 / 255.0)
const METER_COLOR: = Color(235 / 255.0, 200 / 255.0, 90 / 255.0)
const METER_STAYS: = 4.0

static var current: FuelService

var stations: Array = []
var pumps: Array = []
var _clock: = 0.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null



func _ready() -> void :
	var store: = Game.store
	for house in House.all:
		var count: = 0
		var middle: = Vector3.ZERO
		for id in house.part_ids:
			var row: int = store.row_of.get(id, -1)
			if row >= 0 and store.name_at(row) == PUMP_NAME:
				_add_pump(house, store.position(row), store.size(row))
				count += 1
				middle += store.position(row)
		if count > 0:

			stations.append({"building": house, "position": middle / count})

	Net.share("fuel.pumps", _net_pumps, _net_apply_pumps, 5.0)
	Net.stopped.connect( func() -> void :

		for pump: Dictionary in pumps:
			if pump["shown"] != null:
				_net_clear(pump)
	)
	_debug.call_deferred()


func _add_pump(building: Building, at: Vector3, size: Vector3) -> void :
	var node: = Node3D.new()
	node.name = "FuelPump"
	add_child(node)
	node.global_position = at
	var pump: = {"building": building, "position": at, "size": size, "node": node, "fill": null, "meter": null, "shown": null}
	var prompt: = Prompt.make(node, Text.m("gear.fuel.fill"), Text.m("gear.fuel.pump"), 0.4, 9.0)
	prompt.triggered.connect( func(player: Player) -> void : _use(pump, player))
	pump["prompt"] = prompt
	pumps.append(pump)




static func body_distance(vehicle: Vehicle, at: Vector3) -> float:
	var local: = vehicle.to_local(at)
	var half_width: = float(vehicle.data.get("halfWidth", 5.0))
	var front: = float(vehicle.data.get("front", -17.0))
	var rear: = float(vehicle.data.get("rear", 17.0))
	var dx: = maxf(absf(local.x) - half_width, 0.0)
	var dz: = maxf(maxf(front - local.z, local.z - rear), 0.0)
	return Vector2(dx, dz).length()



static func room(vehicle: Vehicle) -> float:
	return maxf(0.0, vehicle.fuel_capacity - vehicle.fuel)


static func to_low(vehicle: Vehicle) -> float:
	return maxf(0.0, vehicle.fuel_capacity * float(Config.Truck.Fuel.Low) - vehicle.fuel)



func _vehicle_at(pump: Dictionary) -> Array:
	var settings: Dictionary = Config.Truck.Fuel
	var nearest: Vehicle = null
	var nearest_distance: = INF
	var any: = false
	for vehicle in Vehicle.all:
		var distance: = body_distance(vehicle, pump["position"])
		if distance <= float(settings["PumpReach"]):
			any = true
			if vehicle.linear_velocity.length() < 1.0 and room(vehicle) >= 1.0 and distance < nearest_distance:
				nearest = vehicle
				nearest_distance = distance
	return [nearest, any]


func _use(pump: Dictionary, player: Player) -> void :
	if pump["fill"] != null:
		pump["fill"]["stop"] = true
		return
	if pump["building"].ruined:
		Game.notify(Text.m("gear.fuel.shut"), "warning", player)
		return
	var found: = _vehicle_at(pump)
	var vehicle: Vehicle = found[0]
	if vehicle == null:
		Game.notify(Text.m("gear.fuel.full" if found[1] else "gear.fuel.noVehicle"), "", player)
		return
	pump["prompt"].action = Text.m("gear.fuel.stop")
	var fill: = {"player": player, "vehicle": vehicle, "litres": 0.0, "paid": 0, "owed": 0.0, "stop": false}
	pump["fill"] = fill
	fill["to"] = vehicle.global_position + (pump["position"] - vehicle.global_position).normalized() * 3.0
	_create_hose(pump, fill)

	vehicle.set_meta("Fuelling", fill)
	player.set_attr("FuelVehicle", vehicle)
	_show(pump, fill)



func _create_hose(pump: Dictionary, fill: Dictionary) -> void :
	var at: Vector3 = pump["position"]
	var from: = at + Vector3(0, 0.5, 0)
	var to: Vector3 = fill["to"]

	var sag: = Vector3(0, -3, 0)
	var path: = PackedVector3Array()
	for index in 13:
		var t: = index / 12.0
		var u: = 1.0 - t
		path.append(from * u * u * u + (from + sag) * 3.0 * u * u * t + (to + sag) * 3.0 * u * t * t + to * t * t * t)
	var hose: = MeshInstance3D.new()
	hose.mesh = HoseLine.tube(path, 0.15, 6)
	var material: = StandardMaterial3D.new()
	material.albedo_color = HOSE_COLOR
	material.roughness = 0.8
	hose.material_override = material
	add_child(hose)
	fill["hose"] = hose
	_create_meter(pump)
	var settings: Dictionary = Config.Truck.Fuel
	fill["sound"] = Sounds.emitter(pump["node"], Sounds.loop(settings["PumpSoundId"]), float(settings["PumpVolume"]), 10.0, 90.0, true)


func _create_meter(pump: Dictionary) -> void :
	if pump["meter"] != null and is_instance_valid(pump["meter"]):
		pump["meter"].queue_free()
	var meter: = Label3D.new()
	meter.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	meter.no_depth_test = true
	meter.fixed_size = true
	meter.pixel_size = 0.0009
	meter.font = Ui.display_font()
	meter.font_size = 44
	meter.outline_size = 14
	meter.modulate = METER_COLOR
	meter.outline_modulate = Color(20 / 255.0, 24 / 255.0, 28 / 255.0, 0.9)
	meter.visibility_range_end = 120.0
	pump["node"].add_child(meter)
	meter.position = Vector3(0, float(pump["size"].y) / 2.0 + 4.0, 0)
	pump["meter"] = meter


func _show(pump: Dictionary, fill: Dictionary, done: = false) -> void :
	var litres: float = fill["litres"]
	pump["meter"].text = "%d L   %s" % [int(floorf(litres + 0.5)) if done else int(floorf(litres)), Ui.money(fill["paid"])]


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_clock += delta
	if _clock < TICK:
		return
	_clock -= TICK
	for pump: Dictionary in pumps:
		if pump["fill"] != null:
			_step(pump, pump["fill"])


func _step(pump: Dictionary, fill: Dictionary) -> void :
	var settings: Dictionary = Config.Truck.Fuel
	var player: Player = fill["player"]
	var vehicle: Vehicle = fill["vehicle"]
	if fill["stop"] or not is_instance_valid(player) or not is_instance_valid(vehicle):
		_finish(pump, fill, null, false)
		return
	var reason: Variant = null
	var full: = false
	if pump["building"].ruined:
		reason = Text.m("gear.fuel.shut")
	elif player.health <= 0.0 or player.root_position().distance_to(pump["position"]) > float(settings["PayerReach"]):
		_finish(pump, fill, null, false)
		return
	elif body_distance(vehicle, pump["position"]) > float(settings["PumpReach"]) or vehicle.linear_velocity.length() > 2.0:
		reason = Text.m("gear.fuel.movedOff")
	elif room(vehicle) < 0.05:
		reason = Text.m("gear.fuel.full")
		full = true
	if reason != null:
		_finish(pump, fill, reason, full)
		return

	var amount: = minf(float(settings["PumpFlow"]) * TICK, room(vehicle))

	var free: = minf(to_low(vehicle), amount)
	fill["owed"] += (amount - free) * float(settings["Price"])
	var due: = int(floorf(fill["owed"]))
	if due > 0:
		if not PlayerData.spend(player, due):
			_finish(pump, fill, Text.m("gear.fuel.noCash"), false)
			return
		fill["owed"] -= due
		fill["paid"] += due
	vehicle.fuel = minf(vehicle.fuel_capacity, vehicle.fuel + amount)
	fill["litres"] += amount
	_show(pump, fill)


func _finish(pump: Dictionary, fill: Dictionary, reason: Variant, full: bool) -> void :
	_show(pump, fill, true)
	pump["fill"] = null
	pump["prompt"].action = Text.m("gear.fuel.fill")
	if is_instance_valid(fill["hose"]):
		fill["hose"].queue_free()
	if is_instance_valid(fill["sound"]):
		fill["sound"].queue_free()

	var meter: Label3D = pump["meter"]
	get_tree().create_timer(METER_STAYS).timeout.connect( func() -> void :
		if is_instance_valid(meter) and pump["fill"] == null:
			meter.queue_free()
	)
	var vehicle: Vehicle = fill["vehicle"]
	if is_instance_valid(vehicle) and vehicle.has_meta("Fuelling") and is_same(vehicle.get_meta("Fuelling"), fill):
		vehicle.remove_meta("Fuelling")
	var player: Player = fill["player"]
	if is_instance_valid(player):
		player.set_attr("FuelVehicle", null)
		if reason != null:
			Game.notify(reason, "good" if full else "warning", player)
		if fill["litres"] >= 1.0:
			Game.notify(Text.f("gear.fuel.paid", [int(floorf(fill["litres"] + 0.5)), fill["paid"]]), "", player)







func _net_pumps() -> Variant:
	var all: Array = []
	for pump: Dictionary in pumps:
		var fill: Variant = pump["fill"]
		var meter: Variant = pump["meter"]
		var reads: String = meter.text if (meter != null and is_instance_valid(meter) and not meter.is_queued_for_deletion()) else ""
		if fill == null:
			all.append([false, reads])
		else:
			all.append([true, reads, fill["to"], String(fill["vehicle"].get_path()), int(floorf(fill["litres"])), fill["paid"]])
	return all


func _net_apply_pumps(all: Variant) -> void :
	for index in mini(pumps.size(), all.size()):
		var pump: Dictionary = pumps[index]
		var now: Array = all[index]
		var shown: Variant = pump["shown"]

		if shown != null and ( not now[0] or shown["to"] != now[2] or shown["path"] != now[3]):
			_net_clear(pump)
			shown = null
		if now[0] and shown == null:
			shown = {"to": now[2], "path": now[3], "litres": 0, "paid": 0, "vehicle": get_node_or_null(NodePath(now[3]))}
			_create_hose(pump, shown)
			pump["shown"] = shown
			if shown["vehicle"] != null:
				shown["vehicle"].set_meta("Fuelling", shown)
		if shown != null:
			shown["litres"] = now[4]
			shown["paid"] = now[5]
		var meter: Variant = pump["meter"]
		var has_meter: bool = meter != null and is_instance_valid(meter) and not meter.is_queued_for_deletion()
		if now[1] == "":
			if has_meter:
				meter.queue_free()
				pump["meter"] = null
		else:
			if not has_meter:
				_create_meter(pump)
			pump["meter"].text = now[1]


func _net_clear(pump: Dictionary) -> void :
	var shown: Dictionary = pump["shown"]
	pump["shown"] = null
	if is_instance_valid(shown["hose"]):
		shown["hose"].queue_free()
	if is_instance_valid(shown["sound"]):
		shown["sound"].queue_free()
	var vehicle: Variant = shown["vehicle"]
	if vehicle != null and is_instance_valid(vehicle) and vehicle.has_meta("Fuelling") and is_same(vehicle.get_meta("Fuelling"), shown):
		vehicle.remove_meta("Fuelling")



func nearest(position: Vector3) -> Variant:
	var best: Variant = null
	var best_distance: = INF
	for station: Dictionary in stations:
		var distance: float = station["position"].distance_to(position)
		if not station["building"].ruined and distance < best_distance:
			best = station["position"]
			best_distance = distance
	return best



static func filling(vehicle: Vehicle) -> Variant:
	if vehicle != null and is_instance_valid(vehicle) and vehicle.has_meta("Fuelling"):
		return vehicle.get_meta("Fuelling")
	return null










func _debug() -> void :
	var joining: = false
	for arg in OS.get_cmdline_user_args():
		joining = joining or arg.begins_with("--join=")
	if OS.get_cmdline_user_args().has("--fuel-trace"):
		_trace()
	for arg in OS.get_cmdline_user_args():
		var park: = arg.begins_with("--fuel-park")
		if not (arg == "--fuel" or arg.begins_with("--fuel=") or park) or pumps.is_empty():
			continue
		var cash: = int(arg.get_slice("=", 1)) if arg.contains("=") else 500
		var pump: Dictionary = pumps[0]
		var house: House = pump["building"]
		var at: Vector3 = pump["position"]
		var player: = Game.local_player
		var truck: = Vehicle.named("Fire Truck")

		var out: = (at - house.lot.origin)
		out.y = 0.0
		out = out.normalized()
		if not joining:
			var spawn: Transform3D = truck.spec["spawn"]
			truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(out.z, - out.x)), Vector3(at.x, spawn.origin.y, at.z) + out * 9.0)
			truck.reset_physics_interpolation()
			truck.fuel = truck.fuel_capacity * 0.2

			if OS.get_cmdline_user_args().has("--no-save"):
				if park:
					Net.peer_joined.connect( func(joined: Player) -> void : joined.set_attr("Cash", cash))
				else:
					player.set_attr("Cash", cash)
		print("fuel: pump at ", at, " of ", house.name, "; ", pumps.size(), " pumps, ", stations.size(), " stations")
		var view: = Camera3D.new()
		add_child(view)
		view.look_at_from_position(at - out * 16.0 + out.cross(Vector3.UP) * 14.0 + Vector3(0, 6, 0), at + out * 4.0)
		view.make_current.call_deferred()
		if park:
			continue
		var stand: = Vector3(at.x, at.y - 4.0, at.z) - out * 3.0 + out.cross(Vector3.UP) * 3.0
		if joining:
			while not (Net.is_client() and Net.players.size() > 1):
				await get_tree().create_timer(0.2).timeout
			await get_tree().create_timer(2.0).timeout
			player.teleport(stand)
			await get_tree().create_timer(0.7).timeout
			Net.request("prompt", [pump["prompt"].net_id, "tap"])
		else:
			player.teleport(stand)
			await get_tree().create_timer(0.5).timeout
			_use(pump, player)



func _trace() -> void :
	while true:
		await get_tree().create_timer(1.0).timeout
		var pump: Dictionary = pumps[0]
		var truck: = Vehicle.named("Fire Truck")
		var meter: Variant = pump["meter"]
		var fill: Variant = filling(truck)
		var line: = "fuel %.0f s: meter '%s' hose %s | truck %.1f L | plate %s" % [
			HostClock.now(), meter.text if (meter != null and is_instance_valid(meter)) else "", pump["fill"] != null or pump["shown"] != null, 
			truck.fuel, "%d L $%d" % [int(fill["litres"]), int(fill["paid"])] if fill != null else "-", 
		]
		for player in Game.players:
			line += " | %s cash %d paying %s" % [player.display_name, int(player.get_attr("Cash", 0)), player.get_attr("FuelVehicle") != null]
		print(line + " | prompt '%s'" % Text.say(pump["prompt"].action, "en"))
