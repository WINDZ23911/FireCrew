class_name Figure
extends Node3D












const ROOT_HEIGHT: = 3.0

const SKIN: Array[Color] = [
	Color8(255, 222, 194), Color8(244, 198, 164), Color8(228, 176, 138), 
	Color8(200, 142, 102), Color8(156, 104, 72), Color8(108, 70, 50), 
]




const TOPS: Array[Color] = [
	Color8(93, 122, 168), Color8(63, 140, 136), Color8(246, 242, 232), Color8(119, 128, 79), Color8(201, 164, 82), 
	Color8(54, 58, 72), Color8(125, 90, 134), Color8(169, 163, 154), Color8(47, 58, 85), Color8(201, 128, 143), 
	Color8(98, 134, 152), Color8(150, 120, 96), Color8(160, 160, 166), Color8(120, 52, 60), 
]
const ACCENTS: Array[Color] = [
	Color8(250, 250, 246), Color8(34, 36, 44), Color8(201, 164, 82), Color8(150, 70, 62), Color8(93, 122, 168), 
	Color8(150, 176, 196), Color8(214, 196, 160), 
]
const LEGS: Array[Color] = [
	Color8(46, 64, 108), Color8(36, 38, 46), Color8(118, 100, 78), Color8(84, 112, 160), Color8(72, 78, 60), 
	Color8(170, 156, 130), Color8(110, 60, 52), Color8(64, 64, 72), 
]
const SHOES: Array[Color] = [
	Color8(30, 30, 34), Color8(244, 244, 240), Color8(96, 62, 40), Color8(130, 58, 52), Color8(62, 80, 120), 
]
const HAIR: Array[Color] = [
	Color8(36, 28, 24), Color8(84, 56, 38), Color8(142, 98, 56), Color8(226, 190, 112), Color8(176, 70, 40), 
	Color8(196, 196, 198), Color8(240, 240, 236), 
]
const BAGS: Array[Color] = [Color8(214, 176, 120), Color8(240, 238, 230), Color8(60, 120, 80), Color8(150, 70, 62)]
const STRAW: = Color8(232, 204, 132)


const COATS: Array[Color] = [
	Color8(52, 54, 62), Color8(38, 48, 72), Color8(150, 110, 70), Color8(70, 72, 78), Color8(140, 60, 54), 
	Color8(48, 90, 64), Color8(92, 80, 70), Color8(30, 30, 34), Color8(60, 110, 170), 
]
const KNITS: Array[Color] = [
	Color8(176, 70, 64), Color8(240, 236, 226), Color8(62, 92, 150), Color8(201, 164, 82), Color8(96, 130, 96), 
	Color8(140, 70, 140), Color8(70, 70, 76), 
]

const WOOL: Array[Color] = [Color8(96, 92, 88), Color8(110, 86, 64), Color8(132, 124, 108), Color8(52, 58, 76), Color8(64, 74, 60)]




const TYPE_PENSIONER: = "pensioner"
const TYPE_VINEDRESSER: = "vinedresser"
const TYPE_COMMUTER: = "commuter"
const TYPE_SHOP: = "shop_worker"
const TYPE_STUDENT: = "student"
const TYPE_PARENT: = "parent"
const TYPE_CHILD: = "child"
const TYPES: = {
	"child": [[TYPE_CHILD, 100]], 
	"teen": [[TYPE_STUDENT, 100]], 
	"adult": [[TYPE_COMMUTER, 38], [TYPE_PARENT, 27], [TYPE_SHOP, 22], [TYPE_VINEDRESSER, 13]], 
	"older": [[TYPE_COMMUTER, 30], [TYPE_VINEDRESSER, 30], [TYPE_PENSIONER, 25], [TYPE_SHOP, 15]], 
	"old": [[TYPE_PENSIONER, 85], [TYPE_VINEDRESSER, 15]], 
}


const DRAB: Array[Color] = [
	Color8(92, 76, 62), Color8(110, 104, 96), Color8(52, 58, 76), Color8(128, 112, 92), Color8(74, 72, 70), 
	Color8(146, 136, 120), Color8(70, 60, 54), 
]
const DARK: Array[Color] = [Color8(30, 30, 34), Color8(46, 48, 54), Color8(34, 38, 52)]
const WORK: Array[Color] = [Color8(62, 84, 120), Color8(88, 96, 64), Color8(110, 86, 62), Color8(140, 132, 118), Color8(96, 52, 48)]

const SHOPPING: = [Color8(226, 220, 204), Color8(150, 124, 92), Color8(96, 118, 90)]
const BRIEF: = Color8(44, 36, 30)
const BOOTS: = [Color8(36, 52, 40), Color8(28, 28, 30)]
const STICK: = Color8(98, 72, 52)
const APRONS: = [Color8(236, 236, 230), Color8(70, 96, 140), Color8(150, 50, 52)]

const RUTAS: Array[Color] = [Color8(236, 232, 222), Color8(52, 56, 70), Color8(120, 52, 56), Color8(96, 80, 64)]




const AGE_CHILD: = "child"
const AGE_TEEN: = "teen"
const AGE_ADULT: = "adult"
const AGE_OLDER: = "older"
const AGE_OLD: = "old"
const AGE_SHARES: = [[AGE_TEEN, 12], [AGE_ADULT, 50], [AGE_OLDER, 18], [AGE_OLD, 20]]




const GAITS: = {
	AGE_CHILD: {"speed": 1.0, "stride": 1.35, "arms": 1.0, "legs": 1.0, "stoop": 0.0}, 
	AGE_TEEN: {"speed": 1.05, "stride": 1.0, "arms": 0.2, "legs": 1.0, "stoop": 0.0}, 
	AGE_ADULT: {"speed": 1.0, "stride": 1.0, "arms": 1.0, "legs": 1.0, "stoop": 0.0}, 
	AGE_OLDER: {"speed": 0.92, "stride": 1.05, "arms": 0.75, "legs": 0.9, "stoop": 0.03}, 
	AGE_OLD: {"speed": 0.75, "stride": 1.3, "arms": 0.45, "legs": 0.7, "stoop": 0.12}, 
}

const POSES: = {
	"stand": {"arm": 0.0, "leg": 0.0, "head": 0.0}, 
	"lying": {"arm": 0.12, "leg": 0.0, "head": 0.0}, 

	"carried": {"arm": 1.4, "leg": 1.5, "head": 0.6}, 
	"stretcher": {"arm": 0.0, "leg": 0.0, "head": 0.0}, 
	"wave": {"arm": 2.8, "leg": 0.0, "head": -0.15}, 
	"sit": {"arm": 0.5, "leg": 1.45, "head": 0.35}, 
}

const SHUT_EYES: = ["lying", "carried", "stretcher"]

const BOX: = 0
const HEAD: = 1
const DOME: = 2

const SHADER: = "\nshader_type spatial;\n// One of a blocky person's pieces. Its colour is `tint`, or in a crowd the instance's own; `face` puts a cartoon\n// face on the front of a head, which one by `face_style` (one person's) or the instance's custom data (a\n// crowd's): the game's one face (shaders/face.gdshaderinc: eyes, mouth, blush, spectacles, shut). Less than whole (alpha below 1) it is drawn as a scatter of dots, which is how someone\n// fades in at a door.\nuniform vec4 tint : source_color = vec4(1.0);\nuniform float face = 0.0;\n// A share of the night's lift (art.gdshaderinc), as a car's paint has, so people stay figures after dark.\nglobal uniform vec4 ground_lift;\ninstance uniform float face_style = -1.0;\n// One person's look and mood (a crowd's come in the custom data: g the eyes' turn across, b the mood of 8).\ninstance uniform vec2 face_gaze = vec2(0.0);\ninstance uniform float face_feel = 0.0;\nvarying vec3 local;\nvarying float style;\nvarying float seed;\nvarying vec2 eyes_turn;\nvarying float mood_of;\n\nvoid vertex() {\n\tlocal = VERTEX;\n\tbool own = face_style >= 0.0;\n\tstyle = own ? face_style : floor(INSTANCE_CUSTOM.r * 255.0 + 0.5);\n\teyes_turn = own ? face_gaze : vec2(INSTANCE_CUSTOM.g * 2.0 - 1.0, 0.0);\n\tmood_of = own ? face_feel : floor(INSTANCE_CUSTOM.b * 8.0 + 0.5);\n\tseed = fract(style * 0.37 + float(INSTANCE_ID) * 0.173 + NODE_POSITION_WORLD.x * 0.011 + NODE_POSITION_WORLD.z * 0.017);\n}\n\n#include \"res://shaders/face.gdshaderinc\"\n\nvoid fragment() {\n\tvec3 color = tint.rgb * pow(COLOR.rgb, vec3(2.2));\n\tif (face > 0.5 && local.z < -0.3) {\n\t\tcolor = cartoon_face_live(local.xy, int(style + 0.5), color, TIME, seed, eyes_turn, int(mood_of + 0.5));\n\t}\n\t// Soft bevels (AR-25, AR-26): a box's edges a shade darker, where two of its faces meet, so the blocks read\n\t// as rounded toys and not as hard cubes. (A sphere never has two coordinates that far out.)\n\tvec3 edged = step(vec3(0.44), abs(local));\n\tif (edged.x + edged.y + edged.z >= 2.0) {\n\t\tcolor *= 0.8;\n\t}\n\tALBEDO = color;\n\tEMISSION = color * ground_lift.rgb * 0.55;\n\tROUGHNESS = 0.6;\n\tfloat alpha = tint.a * COLOR.a;\n\tif (alpha < 0.999) {\n\t\tfloat dither = fract(52.9829189 * fract(dot(FRAGCOORD.xy, vec2(0.06711056, 0.00583715))));\n\t\tif (alpha <= dither) {\n\t\t\tdiscard;\n\t\t}\n\t}\n}\n"






















































static var _shader: Shader
static var _materials: Dictionary = {}
static var _meshes: Dictionary = {}

var seed_number: = 0
var colours: Dictionary = {}
var joints: Array = []
var parts: Dictionary = {}
var pose_name: = "stand"







static func age_of(person_seed: int) -> String:
	var roll: int = rand_from_seed(hash([person_seed, "age"]))[0] %100
	for share: Array in AGE_SHARES:
		if roll < share[1]:
			return share[0]
		roll -= share[1]
	return AGE_ADULT



static func type_of(person_seed: int, age: String) -> String:
	var shares: Array = TYPES.get(age, TYPES[AGE_ADULT])
	var roll: int = rand_from_seed(hash([person_seed, "type"]))[0] %100
	for share: Array in shares:
		if roll < share[1]:
			return share[0]
		roll -= share[1]
	return shares[0][0]













static func looks(person_seed: int, look: = {}, age: = "", type: = "") -> Dictionary:
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash(person_seed)
	var made: = {}

	var rolled_age: = age.is_empty()
	if age.is_empty():
		age = age_of(person_seed)
	made["age"] = age
	if type.is_empty():
		type = type_of(person_seed, age)
	made["type"] = type
	var young: = age == AGE_CHILD or age == AGE_TEEN
	var greying: = age == AGE_OLDER or age == AGE_OLD
	made["scale"] = rng.randf_range(0.93, 1.06) * ({AGE_TEEN: 0.88, AGE_OLD: 0.95}.get(age, 1.0) if rolled_age else 1.0)
	var roll: = rng.randf()
	made["build"] = 0 if roll < 0.5 else (1 if roll < 0.75 else 2)
	made["skin"] = SKIN[rng.randi() % SKIN.size()]
	made["top"] = TOPS[rng.randi() % TOPS.size()]
	made["accent"] = ACCENTS[rng.randi() % ACCENTS.size()]
	if (made["accent"] as Color).is_equal_approx(made["top"]):
		made["accent"] = ACCENTS[(ACCENTS.find(made["accent"]) + 1) % ACCENTS.size()]
	made["legs"] = LEGS[rng.randi() % LEGS.size()]
	made["shoes"] = SHOES[rng.randi() % SHOES.size()]

	made["hair"] = HAIR[rng.randi() % 5]
	if age == AGE_OLD and rng.randf() < 0.8 or age == AGE_OLDER and rng.randf() < 0.4:
		made["hair"] = HAIR[5 + rng.randi() % 2]
	made["cap"] = TOPS[rng.randi() % TOPS.size()]
	var summer: = not Style.winter()
	roll = rng.randf()
	made["outfit"] = "tee" if roll < 0.3 else ("shirt" if roll < 0.48 else ("jacket" if roll < 0.64 else ("hoodie" if roll < 0.76 else ("stripes" if roll < 0.88 else "dress"))))
	roll = rng.randf()
	made["bottoms"] = "shorts" if (summer and roll < 0.28 and not greying) else ("skirt" if roll < 0.4 else "trousers")
	if made["outfit"] == "dress":
		made["bottoms"] = "skirt"
	made["sleeves"] = made["top"]
	if made["outfit"] == "jacket":

		var jacket: Color = LEGS[rng.randi() % LEGS.size()] if rng.randf() < 0.5 else TOPS[rng.randi() % TOPS.size()]
		made["accent"] = made["top"]
		made["top"] = jacket
		made["sleeves"] = jacket
	roll = rng.randf()
	var style: = HAIR_SHORT
	if roll < 0.28:
		style = HAIR_SHORT
	elif roll < 0.44:
		style = HAIR_LONG
	elif roll < 0.54:
		style = HAIR_PONYTAIL
	elif roll < 0.62:
		style = HAIR_BUN
	elif roll < 0.7:
		style = HAIR_BALD if not young else HAIR_SHORT
	elif roll < 0.84:
		style = HAT_CAP
	else:
		style = HAIR_SHORT

	made["style"] = style
	roll = rng.randf()
	made["beard"] = 0 if (roll > 0.26 or young or style in [HAIR_LONG, HAIR_PONYTAIL, HAIR_BUN] or made["outfit"] == "dress") else (1 if roll < 0.15 else 2)
	made["shades"] = summer and rng.randf() < 0.14 and age != AGE_CHILD
	roll = rng.randf()
	made["bag"] = 0 if roll < 0.6 else (1 if roll < 0.8 else 2)
	if age == AGE_CHILD and made["bag"] == 2:
		made["bag"] = 1
	made["bag_color"] = BAGS[rng.randi() % BAGS.size()] if made["bag"] == 2 else TOPS[rng.randi() % TOPS.size()]
	made["face"] = rng.randi() % 32
	if made["shades"]:
		made["face"] = int(made["face"]) & 15
	if look.is_empty():
		_dress_type(made, type, summer, rng)
	if not look.is_empty():

		made["outfit"] = "shirt"
		made["bottoms"] = "trousers"
		made["bag"] = 0
		made["shades"] = false
		made["skin"] = look.get("skin", made["skin"])
		made["top"] = look.get("top", made["top"])
		made["legs"] = look.get("legs", made["legs"])
		made["hair"] = look.get("hair", made["hair"])
		made["sleeves"] = look.get("sleeves", made["top"])
		made["shoes"] = Color8(30, 30, 34)
		if look.has("cap"):
			made["cap"] = look["cap"]
			made["style"] = HAT_CAP
		elif style == HAT_CAP:
			made["style"] = HAIR_SHORT
		if look.has("bands"):
			made["bands"] = look["bands"]
	elif not summer:


		var coat: Color = COATS[rng.randi() % COATS.size()]
		made["top"] = coat
		made["sleeves"] = coat
		made["coat"] = coat
		made["outfit"] = "shirt"
		made["bottoms"] = "trousers"
		made["legs"] = (made["legs"] as Color).darkened(0.25)
		made["shoes"] = SHOES[0] if rng.randf() < 0.6 else SHOES[2]
		if type == TYPE_PENSIONER:
			coat = DRAB[rng.randi() % DRAB.size()]
			made["coat"] = coat
			made["top"] = coat
			made["sleeves"] = coat
		elif type == TYPE_STUDENT:

			made["puffer"] = true
			made["coat"] = DARK[rng.randi() % DARK.size()] if rng.randf() < 0.7 else COATS[rng.randi() % COATS.size()]
			coat = made["coat"]
			made["top"] = coat
			made["sleeves"] = coat
		elif type == TYPE_VINEDRESSER and rng.randf() < 0.5:
			made["boots"] = BOOTS[rng.randi() % BOOTS.size()]
		var knit: Color = KNITS[rng.randi() % KNITS.size()]
		made["scarf"] = knit if rng.randf() < 0.6 else Color(0, 0, 0, 0)
		if rng.randf() < 0.4:
			made["gloves"] = knit if rng.randf() < 0.5 else Color8(40, 40, 44)


		var hat: = float(rand_from_seed(hash([person_seed, "hat"]))[0] %1000) / 1000.0
		var short_haired: bool = made["style"] in [HAIR_SHORT, HAIR_BALD, HAT_CAP]
		var long_haired: bool = made["style"] in [HAIR_LONG, HAIR_PONYTAIL, HAIR_BUN]
		if greying and short_haired and hat < 0.7:
			made["style"] = HAT_FLAT
			made["cap"] = WOOL[rng.randi() % WOOL.size()]
		elif age == AGE_OLD and long_haired and hat < 0.55:
			made["style"] = HAT_RUTA
			made["cap"] = RUTAS[rng.randi() % RUTAS.size()]
		elif hat < (0.7 if age == AGE_CHILD else 0.2):
			made["style"] = HAT_KNIT
			made["cap"] = knit if rng.randf() < 0.6 else KNITS[rng.randi() % KNITS.size()]
	return made




static func _dress_type(made: Dictionary, type: String, summer: bool, rng: RandomNumberGenerator) -> void :
	var bag: = 0
	var bag_color: Color = made["bag_color"]
	match type:
		TYPE_PENSIONER:
			made["top"] = DRAB[rng.randi() % DRAB.size()]
			made["legs"] = DRAB[rng.randi() % DRAB.size()].darkened(0.15)
			made["shoes"] = SHOES[2] if rng.randf() < 0.5 else SHOES[0]
			if made["outfit"] in ["hoodie", "stripes", "tee"]:
				made["outfit"] = "shirt" if rng.randf() < 0.6 else "jacket"
			if made["outfit"] == "jacket":
				made["accent"] = ACCENTS[rng.randi() % 2 + 5]
			made["vest"] = DRAB[rng.randi() % DRAB.size()].darkened(0.1) if rng.randf() < 0.35 else Color(0, 0, 0, 0)
			if made["age"] == AGE_OLD and rng.randf() < 0.2:
				made["stick"] = true
			elif rng.randf() < 0.3:
				bag = 2
				bag_color = SHOPPING[rng.randi() % SHOPPING.size()]
		TYPE_VINEDRESSER:
			made["top"] = WORK[rng.randi() % WORK.size()]
			made["legs"] = WORK[rng.randi() % 3]
			if made["outfit"] in ["dress", "stripes", "hoodie"]:
				made["outfit"] = "shirt"
				made["bottoms"] = "trousers"
			if made["bottoms"] == "skirt" and rng.randf() < 0.5:
				made["bottoms"] = "trousers"
			made["vest"] = Color8(70, 72, 60) if rng.randf() < 0.3 else Color(0, 0, 0, 0)
			if rng.randf() < 0.35:
				made["boots"] = BOOTS[rng.randi() % BOOTS.size()]
		TYPE_STUDENT:

			made["top"] = DARK[rng.randi() % DARK.size()] if rng.randf() < 0.65 else made["top"]
			made["legs"] = DARK[rng.randi() % DARK.size()] if rng.randf() < 0.6 else LEGS[0]
			made["shoes"] = SHOES[1] if rng.randf() < 0.6 else made["shoes"]
			if made["outfit"] in ["dress", "jacket"]:
				made["outfit"] = "hoodie"
			if rng.randf() < 0.3 and made["bottoms"] != "skirt":
				made["tracksuit"] = true
				made["outfit"] = "shirt"
				made["bottoms"] = "trousers"
				made["legs"] = made["top"]
			made["accent"] = [Color8(214, 196, 160), Color8(250, 250, 246), Color8(150, 176, 196)][rng.randi() % 3]
			bag = 1 if rng.randf() < 0.7 else 0
		TYPE_COMMUTER:
			if made["outfit"] in ["hoodie", "stripes"]:
				made["outfit"] = "jacket"
				made["accent"] = ACCENTS[0]
			if rng.randf() < 0.35:
				bag = 2
				bag_color = BRIEF
		TYPE_SHOP:
			made["outfit"] = "shirt" if made["outfit"] != "dress" else "dress"
			made["apron"] = APRONS[rng.randi() % APRONS.size()] if rng.randf() < 0.5 else Color(0, 0, 0, 0)
		TYPE_PARENT:
			bag = 2 if rng.randf() < 0.3 else (1 if rng.randf() < 0.15 else 0)
			if bag == 2:
				bag_color = SHOPPING[rng.randi() % SHOPPING.size()]
		TYPE_CHILD:
			bag = 1 if rng.randf() < 0.3 else 0
	made["sleeves"] = made["top"]
	if made["outfit"] == "jacket":
		made["sleeves"] = made["top"]
	made["bag"] = bag
	made["bag_color"] = bag_color if bag > 0 else made["bag_color"]









static func pieces(made: Dictionary) -> Array:
	var list: Array = []
	var neck: = Vector3(0, 4, 0)
	var build: int = made.get("build", 0)
	var width: float = [2.0, 1.8, 2.3][build]
	var depth: float = [1.0, 0.9, 1.2][build]
	var limb: float = [1.0, 0.86, 1.1][build]
	var skin: Color = made["skin"]
	var outfit: String = made.get("outfit", "shirt")
	var bottoms: String = made.get("bottoms", "trousers")
	var top: Color = made["top"]
	var accent: Color = made.get("accent", top.darkened(0.2))
	var front: = - depth / 2.0 - 0.03

	list.append(_piece("Torso", BOX, Vector3(width, 2, depth), top, Vector3(0, 3, 0), Vector3.ZERO, "", 0, "top"))
	match outfit:
		"jacket":
			list.append(_piece("Shirt", BOX, Vector3(width * 0.34, 1.96, 0.06), accent, Vector3(0, 3, 0), Vector3(0, 0, front), "", 0, "trim"))
		"stripes":
			for y: float in [0.45, -0.15]:
				list.append(_piece("Stripe", BOX, Vector3(width + 0.04, 0.3, depth + 0.04), accent, Vector3(0, 3, 0), Vector3(0, y, 0), "", 0, "trim"))
		"hoodie":
			list.append(_piece("Hood", BOX, Vector3(1.4, 0.55, 0.45), top.darkened(0.15), Vector3(0, 3, 0), Vector3(0, 0.85, depth / 2.0 + 0.15), "", 0, "top"))
			list.append(_piece("Pocket", BOX, Vector3(width * 0.6, 0.5, 0.06), top.darkened(0.15), Vector3(0, 3, 0), Vector3(0, -0.55, front), "", 0, "top"))
	if bottoms != "skirt" and not made.has("coat"):
		list.append(_piece("Belt", BOX, Vector3(width + 0.04, 0.2, depth + 0.04), Color8(44, 36, 30), Vector3(0, 3, 0), Vector3(0, -0.92, 0), "", 0, "trim"))


	var shoulder: = width / 2.0 + limb / 2.0
	var hands: Color = made.get("gloves", skin)
	for side: float in [-1.0, 1.0]:
		var pivot: = Vector3(side * shoulder, 3.8, 0)
		var swing: = 1 if side < 0.0 else -1
		var arm: Array = []
		if outfit == "tee" or outfit == "dress":
			arm.append(_piece("Arm", BOX, Vector3(limb * 0.92, 2.0, limb * 0.92), skin, pivot, Vector3(0, -0.8, 0), "arm", swing, "skin"))
			arm.append(_piece("Sleeve", BOX, Vector3(limb * 1.04, 0.72, limb * 1.04), made["sleeves"], pivot, Vector3(0, -0.15, 0), "arm", swing, "sleeve"))
		else:
			arm.append(_piece("Sleeve", BOX, Vector3(limb, 1.56, limb), made["sleeves"], pivot, Vector3(0, -0.58, 0), "arm", swing, "sleeve"))
			arm.append(_piece("Hand", BOX, Vector3(limb * 0.84, 0.46, limb * 0.84), hands, pivot, Vector3(0, -1.58, 0), "arm", swing, "skin"))
		if side < 0.0 and int(made.get("bag", 0)) == 2:
			arm.append(_piece("Bag", BOX, Vector3(0.5, 0.75, 0.95), made["bag_color"], pivot, Vector3(0, -2.15, 0), "arm", swing, "bag"))
		for piece: Dictionary in arm:
			piece["hand"] = side > 0.0
			list.append(piece)


	for side: float in [-1.0, 1.0]:
		var pivot: = Vector3(side * width / 4.0, 2, 0)
		var swing: = -1 if side < 0.0 else 1
		var thick: = minf(limb, width / 2.0)
		if bottoms == "trousers":
			list.append(_piece("Leg", BOX, Vector3(thick, 1.64, thick), made["legs"], pivot, Vector3(0, -0.82, 0), "leg", swing, "legs"))
		else:
			list.append(_piece("Leg", BOX, Vector3(thick * 0.88, 1.64, thick * 0.88), skin, pivot, Vector3(0, -0.82, 0), "leg", swing, "skin"))
			if bottoms == "shorts":
				list.append(_piece("Shorts", BOX, Vector3(thick * 1.03, 0.82, thick * 1.03), made["legs"], pivot, Vector3(0, -0.41, 0), "leg", swing, "legs"))
		if made.has("boots"):

			list.append(_piece("Boot", BOX, Vector3(thick * 1.1, 1.15, thick * 1.25), made["boots"], pivot, Vector3(0, -1.45, -0.08), "leg", swing, "shoe"))
		else:
			list.append(_piece("Shoe", BOX, Vector3(thick * 1.04, 0.42, thick * 1.3), made["shoes"], pivot, Vector3(0, -1.79, -0.13), "leg", swing, "shoe"))
		if made.get("tracksuit", false):
			list.append(_piece("Stripe", BOX, Vector3(0.1, 1.5, thick * 0.32), made["accent"], pivot, Vector3(side * (thick / 2.0 + 0.02), -0.8, 0), "leg", swing, "trim"))
	if bottoms == "skirt":
		var skirt: Color = top if outfit == "dress" else made["legs"]
		list.append(_piece("Skirt", BOX, Vector3(width + 0.3, 1.0, depth + 0.35), skirt, Vector3(0, 3, 0), Vector3(0, -1.45, 0), "", 0, "legs"))


	if made.has("bands"):
		var bands: Color = made["bands"]
		list.append(_piece("Band", BOX, Vector3(width + 0.06, 0.3, depth + 0.06), bands, Vector3(0, 3, 0), Vector3(0, -0.35, 0), "", 0, "band"))
		for x: float in [ - shoulder, shoulder]:
			list.append(_piece("Band", BOX, Vector3(limb + 0.06, 0.25, limb + 0.06), bands, Vector3(x, 3.8, 0), Vector3(0, -1.15, 0), "arm", 1 if x < 0 else -1, "band"))
		for x: float in [ - width / 4.0, width / 4.0]:
			list.append(_piece("Band", BOX, Vector3(minf(limb, width / 2.0) + 0.06, 0.25, minf(limb, width / 2.0) + 0.06), bands, Vector3(x, 2, 0), Vector3(0, -1.35, 0), "leg", -1 if x < 0 else 1, "band"))


	var vest: Color = made.get("vest", Color(0, 0, 0, 0))
	if vest.a > 0.0 and not made.has("coat"):
		list.append(_piece("Vest", BOX, Vector3(width + 0.1, 1.72, depth + 0.1), vest, Vector3(0, 3, 0), Vector3(0, 0.1, 0), "", 0, "top"))
		list.append(_piece("Quilting", BOX, Vector3(width + 0.13, 0.07, depth + 0.13), vest.darkened(0.3), Vector3(0, 3, 0), Vector3(0, 0.35, 0), "", 0, "trim"))
	var apron: Color = made.get("apron", Color(0, 0, 0, 0))
	if apron.a > 0.0 and not made.has("coat"):
		list.append(_piece("Apron", BOX, Vector3(width * 0.78, 2.5, 0.06), apron, Vector3(0, 3, 0), Vector3(0, -0.55, front - 0.02), "", 0, "trim"))
	if made.get("tracksuit", false):
		for x: float in [-1.0, 1.0]:
			list.append(_piece("Stripe", BOX, Vector3(0.1, 1.9, depth * 0.3), made["accent"], Vector3(0, 3, 0), Vector3(x * (width / 2.0 + 0.02), 0, 0), "", 0, "trim"))

	if made.get("stick", false):
		var stick: = _piece("Stick", BOX, Vector3(0.16, 2.3, 0.16), STICK, Vector3(shoulder, 3.8, 0), Vector3(0, -2.55, -0.35), "arm", -1, "bag")
		stick["hand"] = true
		list.append(stick)

	if made.get("puffer", false):
		var puffer: Color = made["coat"]
		list.append(_piece("Puffer", BOX, Vector3(width + 0.24, 1.9, depth + 0.28), puffer, Vector3(0, 3, 0), Vector3(0, 0.05, 0), "", 0, "top"))
		for y: float in [0.4, -0.25]:
			list.append(_piece("Quilting", BOX, Vector3(width + 0.27, 0.07, depth + 0.31), puffer.darkened(0.35), Vector3(0, 3, 0), Vector3(0, y, 0), "", 0, "trim"))

	if made.has("coat"):
		if not made.get("puffer", false):
			list.append(_piece("CoatSkirt", BOX, Vector3(width + 0.12, 0.95, depth + 0.12), (made["coat"] as Color).darkened(0.06), Vector3(0, 3, 0), Vector3(0, -1.42, 0), "", 0, "top"))
			list.append(_piece("Buttons", BOX, Vector3(0.12, 1.8, 0.06), (made["coat"] as Color).darkened(0.35), Vector3(0, 3, 0), Vector3(0, -0.2, front), "", 0, "trim"))
		var scarf: Color = made.get("scarf", Color(0, 0, 0, 0))
		if scarf.a > 0.0:
			list.append(_piece("Scarf", BOX, Vector3(1.5, 0.42, 1.2), scarf, neck, Vector3(0, -0.12, 0), "", 0, "trim"))
			list.append(_piece("ScarfEnd", BOX, Vector3(0.42, 1.0, 0.2), scarf, neck, Vector3(0.38, -0.7, -0.58), "", 0, "trim"))

	if int(made.get("bag", 0)) == 1:
		list.append(_piece("Backpack", BOX, Vector3(width * 0.7, 1.4, 0.6), made["bag_color"], Vector3(0, 3, 0), Vector3(0, 0.05, depth / 2.0 + 0.3), "", 0, "bag"))
		list.append(_piece("BackpackFlap", BOX, Vector3(width * 0.72, 0.45, 0.64), (made["bag_color"] as Color).darkened(0.2), Vector3(0, 3, 0), Vector3(0, 0.5, depth / 2.0 + 0.3), "", 0, "bag"))


	var big: = 1.12
	var head: = _piece("Head", HEAD, Vector3.ONE * big, skin, neck, Vector3(0, 0.6 * big, 0), "head", 0, "skin")
	head["face"] = int(made.get("face", 0))
	list.append(head)
	var at: = func(x: float, y: float, z: float) -> Vector3: return Vector3(x, y, z) * big
	var hair: Color = made["hair"]
	var style: int = made.get("style", HAIR_SHORT)
	match style:
		HAIR_SHORT, HAIR_LONG, HAIR_PONYTAIL, HAIR_BUN:
			list.append(_piece("Hair", DOME, Vector3(1.34, 0.78, 1.34) * big, hair, neck, at.call(0, 1.02, 0.04), "head", 0, "hair"))
			if style == HAIR_LONG:
				list.append(_piece("HairBack", BOX, Vector3(1.3, 1.15, 0.4) * big, hair, neck, at.call(0, 0.55, 0.52), "head", 0, "hair"))
			elif style == HAIR_PONYTAIL:
				list.append(_piece("Ponytail", BOX, Vector3(0.36, 0.95, 0.36) * big, hair, neck, at.call(0, 0.62, 0.78), "head", 0, "hair"))
			elif style == HAIR_BUN:
				list.append(_piece("Bun", DOME, Vector3(0.62, 0.6, 0.62) * big, hair, neck, at.call(0, 1.42, 0.3), "head", 0, "hair"))
		HAIR_BALD:
			pass
		HAT_CAP:
			list.append(_piece("Cap", DOME, Vector3(1.36, 0.78, 1.36) * big, made["cap"], neck, at.call(0, 1.02, 0.04), "head", 0, "hat"))
			list.append(_piece("CapPeak", BOX, Vector3(1.1, 0.1, 0.62) * big, made["cap"], neck, at.call(0, 0.9, -0.8), "head", 0, "hat"))
		HAT_FLAT:

			list.append(_piece("Cap", DOME, Vector3(1.4, 0.62, 1.42) * big, made["cap"], neck, at.call(0, 1.05, 0.0), "head", 0, "hat"))
			list.append(_piece("CapPeak", BOX, Vector3(1.0, 0.09, 0.42) * big, (made["cap"] as Color).darkened(0.1), neck, at.call(0, 0.98, -0.72), "head", 0, "hat"))
		HAT_SUN:
			list.append(_piece("SunHat", DOME, Vector3(1.32, 0.8, 1.32) * big, STRAW, neck, at.call(0, 1.05, 0.03), "head", 0, "hat"))
			list.append(_piece("SunBrim", BOX, Vector3(2.1, 0.08, 2.1) * big, STRAW, neck, at.call(0, 0.92, 0.03), "head", 0, "hat"))
			list.append(_piece("SunBand", BOX, Vector3(1.36, 0.16, 1.36) * big, made["cap"], neck, at.call(0, 1.0, 0.03), "head", 0, "hat"))
		HAT_RUTA:

			var ruta: Color = made["cap"]
			list.append(_piece("Ruta", DOME, Vector3(1.42, 0.92, 1.44) * big, ruta, neck, at.call(0, 1.02, 0.02), "head", 0, "hat"))
			list.append(_piece("RutaBack", BOX, Vector3(1.34, 0.95, 0.4) * big, ruta, neck, at.call(0, 0.62, 0.5), "head", 0, "hat"))
			list.append(_piece("RutaKnot", BOX, Vector3(0.32, 0.2, 0.22) * big, ruta.darkened(0.12), neck, at.call(0, 0.02, -0.5), "head", 0, "hat"))
		HAT_KNIT:

			var knit: Color = made["cap"]
			list.append(_piece("Hat", DOME, Vector3(1.42, 1.0, 1.42) * big, knit, neck, at.call(0, 1.0, 0.03), "head", 0, "hat"))
			list.append(_piece("HatBrim", BOX, Vector3(1.36, 0.3, 1.36) * big, knit.darkened(0.12), neck, at.call(0, 0.88, 0.03), "head", 0, "hat"))
			list.append(_piece("Bobble", DOME, Vector3(0.45, 0.45, 0.45) * big, knit.lightened(0.2), neck, at.call(0, 1.55, 0.03), "head", 0, "hat"))
	match int(made.get("beard", 0)):
		1:

			list.append(_piece("Beard", BOX, Vector3(1.08, 0.3, 0.2) * big, hair, neck, at.call(0, 0.12, -0.55), "head", 0, "hair"))
			list.append(_piece("Sideburns", BOX, Vector3(1.27, 0.46, 0.42) * big, hair, neck, at.call(0, 0.32, -0.24), "head", 0, "hair"))
		2:
			list.append(_piece("Moustache", BOX, Vector3(0.56, 0.12, 0.1) * big, hair, neck, at.call(0, 0.5, -0.66), "head", 0, "hair"))
	if made.get("shades", false):

		for x: float in [-0.22, 0.22]:
			list.append(_piece("Lens", BOX, Vector3(0.34, 0.24, 0.07) * big, Color8(24, 24, 30), neck, at.call(x, 0.73, -0.64), "head", 0, "trim"))
		list.append(_piece("Bridge", BOX, Vector3(0.8, 0.05, 0.07) * big, Color8(24, 24, 30), neck, at.call(0, 0.8, -0.64), "head", 0, "trim"))
	return list


const HAIR_SHORT: = 1
const HAIR_LONG: = 5
const HAIR_PONYTAIL: = 6
const HAIR_BUN: = 7
const HAT_CAP: = 8
const HAIR_BALD: = 10
const HAT_KNIT: = 11
const HAT_SUN: = 13
const HAT_FLAT: = 14
const HAT_RUTA: = 15


static func _piece(piece_name: String, shape: int, size: Vector3, color: Color, pivot: Vector3, rest: Vector3, role: String, swing: int, part: = "") -> Dictionary:
	return {"name": piece_name, "shape": shape, "size": size, "color": color, "pivot": pivot, "rest": rest, "role": role, "swing": swing, "hand": false, "part": part, "face": -1}




static func mesh_of(shape: int) -> Mesh:
	if _meshes.has(shape):
		return _meshes[shape]
	var mesh: Mesh
	match shape:
		HEAD:
			var drum: = CylinderMesh.new()
			drum.top_radius = 0.56
			drum.bottom_radius = 0.56
			drum.height = 1.25
			drum.radial_segments = 14
			drum.rings = 1
			mesh = _rounded(drum)
		DOME:
			var ball: = SphereMesh.new()
			ball.radius = 0.5
			ball.height = 1.0
			ball.radial_segments = 12
			ball.rings = 6
			mesh = ball
		_:
			var box: = BoxMesh.new()
			box.size = Vector3.ONE
			mesh = box
	_meshes[shape] = mesh
	return mesh




static func _rounded(source: CylinderMesh) -> ArrayMesh:
	var arrays: = source.get_mesh_arrays()
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	for i in vertices.size():
		var v: = vertices[i]
		var edge: = absf(v.y) / 0.625
		var out: = 0.625 / 0.56 * (1.0 - 0.14 * pow(edge, 4.0))
		vertices[i] = Vector3(v.x * out, v.y, v.z * out)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


static func shader() -> Shader:
	if _shader == null:
		_shader = Shader.new()
		_shader.code = SHADER
	return _shader



static func material(color: Color, face: = false) -> ShaderMaterial:
	var key: = [color, face]
	if _materials.has(key):
		return _materials[key]
	var made: = ShaderMaterial.new()
	made.shader = shader()
	made.set_shader_parameter("tint", color)
	made.set_shader_parameter("face", 1.0 if face else 0.0)
	_materials[key] = made
	return made







static func build(person_seed: int, look: = {}) -> Figure:
	var figure: = Figure.new()
	figure.name = "Figure"
	figure.seed_number = person_seed
	figure.colours = looks(person_seed, look)
	for piece: Dictionary in pieces(figure.colours):

		var hang: = Node3D.new()
		hang.name = piece["name"] + "Pivot"
		hang.position = piece["pivot"] - Vector3(0, ROOT_HEIGHT, 0)
		figure.add_child(hang)
		var mesh: = MeshInstance3D.new()
		mesh.name = piece["name"]
		mesh.mesh = mesh_of(piece["shape"])
		mesh.material_override = material(piece["color"], piece["shape"] == HEAD)
		mesh.position = piece["rest"]
		mesh.scale = piece["size"]
		if piece["shape"] == HEAD:
			mesh.set_instance_shader_parameter("face_style", float(piece["face"]))
		hang.add_child(mesh)
		if not figure.parts.has(piece["name"]):
			figure.parts[piece["name"]] = mesh
		if piece["role"] != "":
			figure.joints.append({"node": hang, "role": piece["role"]})
	return figure



func pose(pose_to: String) -> void :
	pose_name = pose_to if POSES.has(pose_to) else "stand"
	var angles: Dictionary = POSES[pose_name]
	for joint: Dictionary in joints:
		joint["node"].basis = Basis(Vector3.RIGHT, angles[joint["role"]])

	var head: MeshInstance3D = parts.get("Head")
	if head != null:
		var shut: = 32 if pose_name in SHUT_EYES else 0
		head.set_instance_shader_parameter("face_style", float((int(colours.get("face", 0)) & 31) | shut))




func turn(role: String, angle: float) -> void :
	for joint: Dictionary in joints:
		if joint["role"] == role:
			joint["node"].basis = Basis(Vector3.RIGHT, angle)



static func standing(ground: Vector3, look: = Vector3.FORWARD) -> Transform3D:
	var flat: = Vector3(look.x, 0, look.z)
	var basis: = Basis.looking_at(flat.normalized()) if flat.length() > 0.001 else Basis.IDENTITY
	return Transform3D(basis, ground + Vector3(0, ROOT_HEIGHT, 0))




static func lying(position: Vector3, feet: Vector3, lift: = 0.0) -> Transform3D:

	var up: = - feet
	var right: = Vector3.UP.cross(up)

	return Transform3D(Basis(right, up, - Vector3.UP), position + Vector3(0, lift + 0.5, 0))
