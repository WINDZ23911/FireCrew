class_name StationPosters
extends Node3D






const PAPER: = Color(1.0, 1.0, 0.98)


const POSTERS: = [
	[Vector3(-39.0, 12.6, -104.94), Vector3.BACK, Vector2(5.0, 6.4), Color(0.78, 0.12, 0.1), "emergency", "emergencyLine"], 
	[Vector3(-21.0, 12.6, -104.94), Vector3.BACK, Vector2(5.0, 6.4), Color(0.72, 0.1, 0.08), "brigade", "brigadeLine"], 
	[Vector3(-4.8, 12.6, -104.94), Vector3.BACK, Vector2(5.0, 6.4), Color(0.16, 0.32, 0.62), "contest", "contestLine"], 
	[Vector3(14.94, 12.6, -91.43), Vector3.LEFT, Vector2(4.4, 5.6), Color(0.86, 0.66, 0.1), "safety", "safetyLine"], 
]

var _labels: Array = []


func _ready() -> void :
	var reach: = float(Config.Art.Station.Reach) * _reach_scale()
	for poster: Array in POSTERS:
		_poster(poster, reach)
	_coffee(reach)
	Text.language_changed.connect(_say)
	_say()


func _exit_tree() -> void :
	if Text.language_changed.is_connected(_say):
		Text.language_changed.disconnect(_say)


static func _reach_scale() -> float:
	var levels: Array = Graphics.LEVELS
	return float(levels[clampi(Settings.quality, Graphics.LOW, Graphics.HIGH)][6])


func _say(_code: = "") -> void :
	for entry: Array in _labels:
		(entry[0] as Label3D).text = Text.say(Text.m("world.posters." + String(entry[1])))


func _quad(size: Vector2, color: Color, place: Transform3D, reach: float) -> void :
	var mesh: = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = size
	mesh.mesh = quad
	var material: = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.9
	mesh.material_override = material
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mesh.visibility_range_end = reach
	add_child(mesh)
	mesh.global_transform = place


func _words(key: String, place: Transform3D, size: int, color: Color, width: float, reach: float) -> void :
	var label: = Label3D.new()
	label.font = Ui.label_font()
	label.font_size = size
	label.pixel_size = 0.01
	label.modulate = color
	label.outline_size = 0
	label.double_sided = false
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.width = width / label.pixel_size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.visibility_range_end = reach
	add_child(label)
	label.global_transform = place
	_labels.append([label, key])


func _poster(poster: Array, reach: float) -> void :
	var at: Vector3 = poster[0]
	var out: Vector3 = poster[1]
	var size: Vector2 = poster[2]
	var basis: = Basis.looking_at( - out)
	var place: = Transform3D(basis, at)
	_quad(size + Vector2(0.3, 0.3), Color(0.16, 0.16, 0.18), place.translated_local(Vector3(0, 0, -0.02)), reach)
	_quad(size, PAPER, place, reach)

	_quad(Vector2(size.x, size.y * 0.36), poster[3], place.translated_local(Vector3(0, size.y * 0.32, 0.02)), reach)
	_words(poster[4], place.translated_local(Vector3(0, size.y * 0.32, 0.04)), 120 if poster[4] == "emergency" else 64, Color(0.98, 0.97, 0.94), size.x * 0.9, reach)
	_words(poster[5], place.translated_local(Vector3(0, - size.y * 0.15, 0.04)), 40, Color(0.12, 0.12, 0.14), size.x * 0.85, reach)



func _coffee(reach: float) -> void :
	var bench: = Vector3(19.2, 3.62, -66.42)
	var parts: = [
		[Vector3(1.0, 1.5, 0.9), Vector3(0, 0.75, 0), Color(0.12, 0.12, 0.13)], 
		[Vector3(0.7, 0.18, 0.5), Vector3(0, 0.25, -0.25), Color(0.6, 0.6, 0.62)], 
		[Vector3(0.45, 0.6, 0.45), Vector3(1.0, 0.3, 0.1), Color(0.72, 0.1, 0.08)], 
		[Vector3(0.3, 0.36, 0.3), Vector3(-0.9, 0.18, -0.2), Color(0.84, 1.0, 0.24)], 
		[Vector3(0.3, 0.36, 0.3), Vector3(-1.4, 0.18, 0.1), Color(0.95, 0.94, 0.9)], 
		[Vector3(0.3, 0.36, 0.3), Vector3(-1.9, 0.18, -0.15), Color(0.16, 0.32, 0.62)], 
	]
	for part: Array in parts:
		var mesh: = MeshInstance3D.new()
		var box: = BoxMesh.new()
		box.size = part[0]
		mesh.mesh = box
		var material: = StandardMaterial3D.new()
		material.albedo_color = part[2]
		material.roughness = 0.5
		mesh.material_override = material
		mesh.visibility_range_end = reach
		add_child(mesh)
		mesh.global_position = bench + (part[1] as Vector3)
