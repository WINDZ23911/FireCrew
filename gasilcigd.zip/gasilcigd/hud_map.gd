class_name HudMap
extends Control






const SHEET: = 860.0
const HEADER: = 44.0
const PAD: = 14.0
const GROUND: = Color(26 / 255.0, 28 / 255.0, 32 / 255.0)
const BUILDING: = Color(62 / 255.0, 65 / 255.0, 72 / 255.0)
const WORDS: = {
	"title": {"sl": "ZEMLJEVID", "en": "MAP", "de": "KARTE"}, 
	"close": {"sl": "ZAPRI", "en": "CLOSE", "de": "SCHLIESSEN"}, 
	"station": {"sl": "GASILSKI DOM", "en": "STATION", "de": "FEUERWEHRHAUS"}, 
	"call": {"sl": "INTERVENCIJA", "en": "CALL", "de": "EINSATZ"}, 
	"hydrant": {"sl": "HIDRANT", "en": "HYDRANT", "de": "HYDRANT"}, 
	"vehicle": {"sl": "VOZILO", "en": "VEHICLE", "de": "FAHRZEUG"}, 
	"fuel": {"sl": "ČRPALKA", "en": "FUEL", "de": "TANKSTELLE"}, 
	"ambulance": {"sl": "REŠEVALCI", "en": "AMBULANCE", "de": "RETTUNGSDIENST"}, 
}

static var current: HudMap

var _plate: Control
var _sheet: Control
var _title: Label
var _close: Label
var _legend: Array = []
var _min: = Vector2(-920, -920)
var _span: = 2040.0


static func word(key: String) -> String:
	var entry: Dictionary = WORDS[key]
	return entry.get(Text.language, entry["en"])


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false

	_plate = Ui.plate(Vector2(SHEET + PAD * 2, SHEET + HEADER + PAD))
	_plate.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_plate.position = - _plate.size / 2
	add_child(_plate)
	Ui.stripe(_plate, 120)
	_title = Ui.display("", 26)
	_title.position = Vector2(PAD, 6)
	_plate.add_child(_title)
	var cap: = Ui.key(Controls.key_name("map"))
	cap.position = Vector2(_plate.size.x - PAD - cap.size.x, 8)
	_plate.add_child(cap)
	_close = Ui.caps("", 14)
	_close.size = Vector2(120, 30)
	_close.position = Vector2(cap.position.x - 128, 8)
	_close.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_close.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_plate.add_child(_close)


	var x: = 190.0
	for entry: Array in [["house", Ui.YELLOW, "station"], ["flame", Ui.RED, "call"], ["truck", Ui.TEXT, "vehicle"], ["dot", Ui.BLUE, "hydrant"], ["pump", HudRadar.FUEL, "fuel"], ["heart", Ui.GREEN, "ambulance"]]:
		var picture: = Ui.icon(entry[0], 20, entry[1])
		picture.position = Vector2(x, 13)
		_plate.add_child(picture)
		var label: = Ui.caps("", int(Config.Hud.CapsFloor))
		label.position = Vector2(x + 24, 14)
		_plate.add_child(label)
		_legend.append([label, entry[2], picture])
		x += 130.0

	_sheet = Control.new()
	_sheet.position = Vector2(PAD, HEADER)
	_sheet.size = Vector2(SHEET, SHEET)
	_sheet.clip_contents = true
	_sheet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sheet.draw.connect(_draw_sheet)
	_plate.add_child(_sheet)

	HudRadar.roads()
	_min = HudRadar.town.position
	_span = maxf(HudRadar.town.size.x, HudRadar.town.size.y)
	_setup_town_map()

	for arg in OS.get_cmdline_user_args():
		if arg == "--hud-open=map":
			visible = true


func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("map") and not Game.ui_open:
		visible = not visible
		get_viewport().set_input_as_handled()
		_free_mouse(visible)


func _process(_delta: float) -> void :
	if not visible:
		if _mouse_freed:
			if Game.ui_open:
				_mouse_freed = false
			else:
				_free_mouse(false)
		return
	_title.text = word("title")
	_close.text = word("close")
	var x: = 190.0
	for entry: Array in _legend:
		var label: Label = entry[0]
		label.text = word(entry[1])
		label.position.x = x + 24
		entry[2].position.x = x
		x += 24 + label.get_minimum_size().x + 22
	_sheet.queue_redraw()



func _spot(x: float, z: float) -> Vector2:
	return (Vector2(x, z) - _min) / _span * SHEET


func _at(place: Vector3) -> Vector2:
	var spot: = _spot(place.x, place.z)
	return Vector2(clampf(spot.x, 10, SHEET - 10), clampf(spot.y, 10, SHEET - 10))


func _draw_sheet() -> void :
	var scale_by: = SHEET / _span
	_sheet.draw_rect(Rect2(Vector2.ZERO, _sheet.size), GROUND)
	for corners: PackedVector2Array in HudRadar.buildings:
		var shape: = PackedVector2Array()
		for corner in corners:
			shape.append(_spot(corner.x, corner.y))
		_sheet.draw_colored_polygon(shape, BUILDING)

	for main: bool in [false, true]:
		for road: Array in HudRadar.roads():
			if road[3] != main:
				continue
			var points: PackedVector2Array = road[0]
			var line: = PackedVector2Array()
			for point in points:
				line.append(_spot(point.x, point.y))
			var width: = maxf(2.0, road[1] * HudRadar.ROAD_SHARE * scale_by)
			var color: = HudRadar.ROAD_MAIN if main else HudRadar.ROAD
			_sheet.draw_polyline(line, color, width, true)
			for point in line:
				_sheet.draw_circle(point, width / 2, color, true, -1.0, true)

	_draw_town(scale_by)
	var way: = HudRadar.full_route if HudRadar.full_route.size() >= 2 else HudRadar.route
	if way.size() >= 2:
		var line: = PackedVector2Array()
		for point in way:
			line.append(_spot(point.x, point.z))
		_sheet.draw_polyline(line, HudRadar.route_color(), 4.0, true)
	_draw_waypoint()

	for hydrant in HudRadar.hydrants():
		var kind: = HoseService.current.hydrant_kind_at(hydrant) if HoseService.current != null else ""
		HudRadar.draw_hydrant(_sheet, _at(hydrant), 10, kind)
	if Game.station:
		HudRadar.draw_icon(_sheet, "house", _at(Game.station.door_position), 26, Ui.YELLOW)
	if FuelService.current:
		for station: Dictionary in FuelService.current.stations:
			HudRadar.draw_icon(_sheet, "pump", _at(station["position"]), 24, HudRadar.FUEL)
	if AmbulanceService.current:
		var box: Variant = AmbulanceService.current.zone_position()
		if box != null:
			HudRadar.draw_icon(_sheet, "heart", _at(box), 24, Ui.GREEN)
	_draw_vehicles()
	var incident: = Game.incident
	if incident.has("pos"):
		var at: = _at(incident["pos"])
		var beat: = fmod(Game.now(), 1.4) / 1.4
		HudRadar.draw_icon(_sheet, "ring", at, 24 + 50 * beat, Color(Ui.RED, 1.0 - beat))
		HudRadar.draw_icon(_sheet, HudRadar.KIND_ICONS.get(incident.get("kind", "fire"), "flame"), at, 32, Ui.RED)
	var player: = Game.local_player
	for other in Game.players:
		if other != player and is_instance_valid(other):
			HudRadar.draw_icon(_sheet, "dot", _at(other.global_position), 14, Ui.YELLOW)
	if player:
		var facing: = player.facing()
		HudRadar.draw_icon(_sheet, "arrow", _at(player.global_position), 28, Ui.YELLOW, atan2(facing.x, - facing.z))


	var letter: = Text.say(Text.m("hud.radar.north"))
	_sheet.draw_string(Ui.display_font(), Vector2(SHEET - 30, 30), letter, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Ui.YELLOW)
	_draw_way_length()





const LABEL: = Color(0.86, 0.87, 0.9, 0.9)
const DISTRICT: = Color(1.0, 1.0, 1.0, 0.32)

var _streets: Array = []
var _places: Array = []
var _hint: Label
var _mouse_freed: = false



func _setup_town_map() -> void :
	var longest: = {}
	for road: Dictionary in Rbx.module("TownLayout")["roads"]:
		var road_name: = String(road.get("name", ""))
		if road_name.is_empty() or int(road.get("rank", 0)) < int(Config.Map.StreetRank):
			continue
		var length: = 0.0
		var points: Array = road["points"]
		for index in points.size() - 1:
			length += Vector2(points[index][0], points[index][1]).distance_to(Vector2(points[index + 1][0], points[index + 1][1]))
		if length > float(longest.get(road_name, [0.0])[0]):
			longest[road_name] = [length, points]
	for road_name: String in longest:
		var points: Array = longest[road_name][1]
		var half: = float(longest[road_name][0]) / 2.0
		for index in points.size() - 1:
			var a: = Vector2(points[index][0], points[index][1])
			var b: = Vector2(points[index + 1][0], points[index + 1][1])
			if half <= a.distance_to(b):
				var angle: = (b - a).angle()
				if absf(angle) > PI / 2.0:
					angle = wrapf(angle + PI, - PI, PI)
				_streets.append([road_name, a.lerp(b, half / maxf(a.distance_to(b), 0.01)), angle])
				break
			half -= a.distance_to(b)

	for building: Dictionary in Rbx.module("TownLayout")["buildings"]:
		if building.has("label"):
			_places.append([Text.named("calls.buildings", String(building["label"])), Vector2(building["x"], building["z"]), "pin"])

	for place: Array in VistaClosers.places:
		_places.append([Text.m(place[0]), place[1], "pin"])

	for place: Array in OldTownDe.places:
		_places.append([place[0], place[1], "pin"])
	if Game.station:
		_places.append([Text.m("hud.map.station"), Vector2(Game.station.door_position.x, Game.station.door_position.z), ""])
	if NavGraph.current != null:
		var middle: = Vector2.ZERO
		var count: = 0
		for spot: Dictionary in NavGraph.current.places:
			if spot["kind"] == "bus_stop":
				middle += Vector2(spot["x"], spot["z"])
				count += 1
		if count > 0:
			_places.append([Text.m("hud.map.busStation"), middle / count, "pin"])
	_thin_places()
	_sheet.mouse_filter = Control.MOUSE_FILTER_STOP
	_sheet.gui_input.connect(_on_sheet_input)
	_hint = Ui.caps("", int(Config.Hud.CapsFloor))
	_hint.position = Vector2(PAD, SHEET + HEADER - 2)
	_hint.size = Vector2(SHEET, 20)
	_plate.add_child(_hint)
	_plate.size.y += 20




func _thin_places() -> void :
	_places.sort_custom( func(a: Array, b: Array) -> bool: return String(a[2]).is_empty() and not String(b[2]).is_empty())
	var kept: Array = []
	var seen: = {}
	var room: = float(Config.Map.LabelRoom)
	for place: Array in _places:
		var words: = Text.say(place[0], "en")
		var at: = _spot(place[1].x, place[1].y)
		var clear: = not seen.has(words)
		for other: Array in kept:
			var there: = _spot(other[1].x, other[1].y)
			clear = clear and (absf(there.x - at.x) > room or absf(there.y - at.y) > 16.0)
		if clear:
			kept.append(place)
			seen[words] = true
	_places = kept



func _free_mouse(open: bool) -> void :
	_mouse_freed = open
	var player: = Game.local_player
	if player != null and player.camera != null:
		player.camera.capture( not open)



func _on_sheet_input(event: InputEvent) -> void :
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			set_waypoint_at(event.position)
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			Guide.waypoint = Vector3.INF
		_sheet.accept_event()



func _place_at(spot: Vector2) -> Vector3:
	var flat: = spot / SHEET * _span + _min
	return Vector3(flat.x, 0.0, flat.y)



func set_waypoint_at(spot: Vector2) -> void :
	Guide.waypoint = _place_at(spot)
	if Guide.current != null:
		Guide.current._clock = 0.0


func _draw_town(scale_by: float) -> void :
	var font: = Ui.label_font()
	var size: = int(Config.Map.StreetSize)

	for district: Dictionary in Config.Map.Districts:
		var words: = Text.say(Text.m("hud.map.districts.%s" % district["key"])).to_upper()
		var at: = _spot(float(district["x"]), float(district["z"]))
		var wide: = Ui.display_font().get_string_size(words, HORIZONTAL_ALIGNMENT_LEFT, -1, 24).x
		if district.has("toward"):


			_sheet.draw_string(Ui.display_font(), at - Vector2(wide, 0), words, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, DISTRICT)
			var way: = (_spot(float(district["toward"][0]), float(district["toward"][1])) - at).normalized()
			var tip: = at + Vector2(8, -8) + way * 22.0
			var side: = Vector2( - way.y, way.x) * 4.5
			_sheet.draw_colored_polygon(PackedVector2Array([tip, tip - way * 16.0 + side, tip - way * 16.0 - side]), DISTRICT)
			continue
		_sheet.draw_string(Ui.display_font(), at - Vector2(wide / 2.0, 0), words, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, DISTRICT)
	for street: Array in _streets:
		var at: = _spot(street[1].x, street[1].y)
		var wide: = font.get_string_size(street[0], HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
		_sheet.draw_set_transform(at, street[2])
		_sheet.draw_string_outline(font, Vector2( - wide / 2.0, size * 0.35), street[0], HORIZONTAL_ALIGNMENT_LEFT, -1, size, 3, Color(GROUND, 0.9))
		_sheet.draw_string(font, Vector2( - wide / 2.0, size * 0.35), street[0], HORIZONTAL_ALIGNMENT_LEFT, -1, size, LABEL)
		_sheet.draw_set_transform(Vector2.ZERO)
	for place: Array in _places:
		var at: = _spot(place[1].x, place[1].y)
		if not String(place[2]).is_empty():
			HudRadar.draw_icon(_sheet, place[2], at, 14, Ui.AMBER)
		var words: = Text.say(place[0])
		_sheet.draw_string_outline(font, at + Vector2(9, 5), words, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 3, Color(GROUND, 0.9))
		_sheet.draw_string(font, at + Vector2(9, 5), words, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Ui.AMBER)




func _draw_vehicles() -> void :
	var font: = Ui.display_font()
	for vehicle in Vehicle.all:
		if not is_instance_valid(vehicle):
			continue
		var color: = Ui.TEXT
		var at: = _at(vehicle.global_position)
		var ahead: = - vehicle.global_basis.z
		HudRadar.draw_icon(_sheet, "arrow", at, 26, color, atan2(ahead.x, - ahead.z))
		HudRadar.draw_icon(_sheet, "truck", at + Vector2(0, -16), 16, color)
		var number: = HudRadar.fleet_number(vehicle)
		if not number.is_empty():
			_sheet.draw_string_outline(font, at + Vector2(12, -10), number, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, 4, Color(GROUND, 0.9))
			_sheet.draw_string(font, at + Vector2(12, -10), number, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, color)
		if vehicle.driver() != null:
			_sheet.draw_circle(at, 3.0, Ui.YELLOW)


func _draw_waypoint() -> void :
	if Guide.waypoint == Vector3.INF:
		return
	var at: = _at(Guide.waypoint)
	HudRadar.draw_icon(_sheet, "pin", at + Vector2(0, -12), 28, Ui.ROUTES["waypoint"])
	HudRadar.draw_icon(_sheet, "ring", at, 18, Ui.ROUTES["waypoint"])



func _draw_way_length() -> void :
	if _hint == null:
		return
	if HudRadar.full_length > 0.0:
		var metres: = HudRadar.full_length * float(Config.Hud.MetresPerStud)
		var seconds: = metres / (float(Config.Map.EtaSpeed) / 3.6)
		var distance: = ("%.1f km" % (metres / 1000.0)) if metres >= 1000.0 else ("%d m" % int(round(metres / 10.0) * 10))
		if Ui.imperial():
			var feet: = metres * 3.28084
			distance = ("%.1f mi" % (feet / 5280.0)) if feet >= 1000.0 else ("%d ft" % int(round(feet / 10.0) * 10))
		_hint.text = Text.say(Text.f("hud.map.way", [distance, HudDuty.clock(seconds)]))
		_hint.add_theme_color_override("font_color", HudRadar.route_color())
	else:
		_hint.text = Text.say(Text.m("hud.map.waypointHint"))
		_hint.add_theme_color_override("font_color", Ui.DIM)
