class_name MenuKit
extends RefCounted



const KEYS: Array[String] = ["slot_1", "slot_2", "slot_3", "slot_4", "slot_5", "slot_6", "slot_7", "slot_8", "slot_9"]


static func _box(color: Color) -> StyleBoxFlat:
	var style: = StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(4)
	return style




static func row(size: Vector2, text: String, detail: String, color: Color, choose: Callable, key: = "", icon: = "", text_size: = 22) -> Button:
	var button: = Button.new()
	button.size = size
	button.custom_minimum_size = size
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_stylebox_override("normal", _box(Color(Ui.INSET, 0.6)))
	button.add_theme_stylebox_override("hover", _box(Color(Ui.INSET.lightened(0.12), 0.85)))
	button.add_theme_stylebox_override("pressed", _box(Color(Ui.INSET.lightened(0.2), 0.95)))
	button.add_theme_stylebox_override("disabled", _box(Color(Ui.INSET, 0.35)))
	button.pressed.connect(choose)
	var left: = 14.0
	if not key.is_empty():
		var cap: = Ui.key(key)
		cap.position = Vector2(8, (size.y - cap.size.y) / 2.0)
		button.add_child(cap)
		left = 48.0
	if not icon.is_empty():
		var picture: = Ui.icon(icon, 30, color)
		picture.position = Vector2(left - 4 if key.is_empty() else left, (size.y - 30) / 2.0)
		button.add_child(picture)
		left += 36.0
	var words: = Ui.display(text, text_size, color)
	words.clip_text = true
	words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	words.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	words.position = Vector2(left, 2 if not detail.is_empty() else 0)
	words.size = Vector2(size.x - left - 8, size.y * 0.55 if not detail.is_empty() else size.y)
	button.add_child(words)
	if not detail.is_empty():
		var small: = Ui.caps(detail, maxi(11, text_size - 8))
		small.clip_text = true
		small.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		small.position = Vector2(left, size.y * 0.55)
		small.size = Vector2(size.x - left - 8, size.y * 0.4)
		button.add_child(small)
	return button



static func cross(close: Callable) -> Button:
	var button: = Button.new()
	button.size = Vector2(34, 34)
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_stylebox_override("normal", _box(Color(Ui.INSET, 0.6)))
	button.add_theme_stylebox_override("hover", _box(Color(Ui.INSET.lightened(0.15), 0.9)))
	button.add_theme_stylebox_override("pressed", _box(Color(Ui.INSET.lightened(0.25), 1.0)))
	button.pressed.connect(close)
	var letter: = Ui.label("X", 22)
	letter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	letter.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	letter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	button.add_child(letter)
	return button



static func take_mouse(player: Player, on: bool) -> void :
	Game.ui_open = on
	if player != null and player.camera != null:
		player.camera.capture( not on)



static func number_key(event: InputEvent) -> int:
	for index in KEYS.size():
		if event.is_action_pressed(KEYS[index]):
			return index + 1
	return 0
