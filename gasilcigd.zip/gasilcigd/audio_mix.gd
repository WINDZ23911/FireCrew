class_name AudioMix
extends Node










const BUS: = "World"

var _low: AudioEffectLowPassFilter
var _room: AudioEffectReverb
var _cutoff: = 20000.0
var _wet: = 0.0
var _duck: = 0.0


func _ready() -> void :
	_make_bus()
	get_tree().node_added.connect(_on_node_added)
	_move_all(get_tree().root)


func _make_bus() -> void :
	var index: = AudioServer.get_bus_index(BUS)
	if index < 0:
		index = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, BUS)
		AudioServer.set_bus_send(index, "Master")
		_low = AudioEffectLowPassFilter.new()
		_low.cutoff_hz = 20000.0
		_low.resonance = 0.4
		AudioServer.add_bus_effect(index, _low, 0)
		_room = AudioEffectReverb.new()
		_room.room_size = float(Config.Mix.RoomSize)
		_room.damping = 0.6
		_room.dry = 1.0
		_room.wet = 0.0
		AudioServer.add_bus_effect(index, _room, 1)
	else:
		_low = AudioServer.get_bus_effect(index, 0) as AudioEffectLowPassFilter
		_room = AudioServer.get_bus_effect(index, 1) as AudioEffectReverb
	AudioServer.set_bus_effect_enabled(index, 0, false)
	AudioServer.set_bus_effect_enabled(index, 1, false)


func _on_node_added(node: Node) -> void :
	if node is AudioStreamPlayer3D and (node as AudioStreamPlayer3D).bus == &"Master":
		(node as AudioStreamPlayer3D).bus = BUS


func _move_all(node: Node) -> void :
	_on_node_added(node)
	for child in node.get_children():
		_move_all(child)



static func masked() -> bool:
	var me: = Game.local_player
	return me != null and is_instance_valid(me) and me.get_attr("Mask", false) == true and me.get_attr("Scba", false) != false



static func inside() -> bool:
	var me: = Game.local_player
	return me != null and is_instance_valid(me) and me.camera != null and me.seat == null and me.camera.indoors()


func _process(delta: float) -> void :
	var index: = AudioServer.get_bus_index(BUS)
	if index < 0 or _low == null:
		return
	var settings: Dictionary = Config.Mix
	var mask: = masked()
	var room: = inside()
	var cutoff: = 20000.0
	if mask:
		cutoff = float(settings["MaskCutoff"])
	elif room:
		cutoff = float(settings["InsideCutoff"])
	var ease: = 1.0 - exp( - delta * float(settings["Ease"]))

	_cutoff = exp(lerpf(log(_cutoff), log(cutoff), ease))
	_wet = lerpf(_wet, float(settings["RoomWet"]) if room else 0.0, ease)
	var duck: = float(settings["MaskDuck"]) if mask else 0.0
	if TeamRadio.hearing():
		duck += float(Config.TeamRadio.Duck)
	_duck = lerpf(_duck, duck, ease)
	_low.cutoff_hz = _cutoff
	_room.wet = _wet
	AudioServer.set_bus_effect_enabled(index, 0, _cutoff < 19000.0)
	AudioServer.set_bus_effect_enabled(index, 1, _wet > 0.01)
	AudioServer.set_bus_volume_db(index, _duck)
