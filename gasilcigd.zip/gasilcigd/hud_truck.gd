class_name HudTruck
extends Control







const WIDTH: = 236.0
const ROW: = 36.0
const FUEL_ROW: = 30.0
const WATER_ROW: = 24.0
const TOP: = 72.0

const CONTROLS: = [
	["veh_headlights", "hud.truck.headlights", "headlights_on"], 
	["veh_blue", "hud.truck.blueLights", "blue_on"], 

	["veh_siren", "hud.truck.siren", "siren"], 
	["veh_horn", "hud.truck.horn", ""], 
	["veh_door", "hud.truck.door", ""], 


	["veh_arrows", "hud.truck.arrows", "arrows"], 
	["mast", "hud.truck.mast", "mast"], 
	["veh_exit", "hud.truck.exit", ""], 
]

var _panel: Control
var _name: Label
var _speed: Label
var _unit: Label
var _gear: Label
var _rows: Array = []
var _fuel_caps: Label
var _fuel_bar: Control
var _fuel: Label
var _water_caps: Label
var _water_bar: Control
var _water: Label
var _trucks: TruckService
var _caps: Array[Control] = []
var _wheel_hint: Control
var _wheel_cap: Control
var _wheel_words: Label


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var height: = TOP + CONTROLS.size() * ROW + 8 + FUEL_ROW + WATER_ROW
	_panel = Ui.plate(Vector2(WIDTH, height))
	_panel.position = Vector2( - WIDTH - 28, - height / 2)
	_panel.visible = false
	add_child(_panel)
	Ui.stripe(_panel, 90)

	_name = Ui.caps("", 13)
	_name.position = Vector2(14, 12)
	_name.size = Vector2(120, 16)
	_name.clip_text = true
	_panel.add_child(_name)
	var picture: = Ui.icon("truck", 30, Ui.DIM)
	picture.position = Vector2(14, 32)
	_panel.add_child(picture)
	_gear = Ui.caps("", 13)
	_gear.add_theme_color_override("font_color", Ui.TEXT)
	_gear.position = Vector2(52, 40)
	_panel.add_child(_gear)
	_speed = Ui.display("0", 44)
	_speed.position = Vector2(WIDTH - 52 - 90, 6)
	_speed.size = Vector2(90, 56)
	_speed.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_speed.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_panel.add_child(_speed)
	_unit = Ui.caps("", 13)
	_unit.position = Vector2(WIDTH - 14 - 34, 40)
	_unit.size = Vector2(34, 16)
	_panel.add_child(_unit)
	var rule: = ColorRect.new()
	rule.color = Color(1, 1, 1, 0.12)
	rule.position = Vector2(12, 68)
	rule.size = Vector2(WIDTH - 24, 1)
	_panel.add_child(rule)


	for index in CONTROLS.size():
		var control: Array = CONTROLS[index]
		var row: = Control.new()
		row.position = Vector2(8, TOP + index * ROW)
		row.size = Vector2(WIDTH - 16, ROW - 4)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_panel.add_child(row)

		var cap: = Ui.key(Controls.bound_name(control[0]))
		cap.position = Vector2(6, 1)
		row.add_child(cap)
		_caps.append(cap)
		var label: = Ui.label("", 16)
		label.position = Vector2(46, 0)
		label.size = Vector2(row.size.x - 76, row.size.y)
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.clip_text = true
		row.add_child(label)
		var entry: = {"label": label}
		if control[0] == "veh_siren":

			label.position = Vector2(46, -2)
			label.size = Vector2(row.size.x - 76, 20)
			var hold: = Ui.caps("", 11)
			hold.position = Vector2(46, 17)
			row.add_child(hold)
			entry["hold"] = hold
		if control[2] != "":
			var glow: = TextureRect.new()
			glow.texture = Ui.image("glow")
			glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			glow.size = Vector2(34, 34)
			glow.position = Vector2(row.size.x - 16 - 17, row.size.y / 2 - 17)
			glow.modulate = Ui.YELLOW
			glow.visible = false
			glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
			row.add_child(glow)
			var lamp: = Ui.icon("dot", 16, Ui.INSET)
			lamp.position = Vector2(row.size.x - 16 - 8, row.size.y / 2 - 8)
			row.add_child(lamp)
			entry["glow"] = glow
			entry["lamp"] = lamp
		_rows.append(entry)
		_fit_row(index)


	var y: = TOP + CONTROLS.size() * ROW + 8
	_fuel_caps = Ui.caps("", 13)
	_fuel_caps.position = Vector2(14, y - 2)
	_panel.add_child(_fuel_caps)
	_fuel_bar = Ui.bar(Vector2(92, 14), Ui.YELLOW)
	_fuel_bar.position = Vector2(78, y)
	_panel.add_child(_fuel_bar)
	_fuel = _amount(y - 2)
	y += WATER_ROW
	_water_caps = Ui.caps("", 13)
	_water_caps.position = Vector2(14, y - 2)
	_panel.add_child(_water_caps)
	_water_bar = Ui.bar(Vector2(92, 14), Ui.BLUE)
	_water_bar.position = Vector2(78, y)
	_panel.add_child(_water_bar)
	_water = _amount(y - 2)


	_wheel_hint = Ui.plate(Vector2(WIDTH, 44))
	_wheel_hint.visible = false
	add_child(_wheel_hint)
	_wheel_cap = Ui.key(Controls.bound_name("interact"))
	_wheel_cap.position = Vector2(10, 7)
	_wheel_hint.add_child(_wheel_cap)
	_wheel_words = Ui.display("", 18)
	_wheel_words.position = Vector2(20 + _wheel_cap.size.x, 6)
	_wheel_words.size = Vector2(WIDTH - 30 - _wheel_cap.size.x, 32)
	_wheel_hint.add_child(_wheel_words)



func _fit_row(index: int) -> void :
	var push: = maxf(0.0, _caps[index].size.x - 34)
	for part: String in ["label", "hold"]:
		if _rows[index].has(part):
			var words: Label = _rows[index][part]
			words.position.x = 46 + push
			words.size.x = words.get_parent().size.x - 76 - push


func _amount(y: float) -> Label:
	var label: = Ui.caps("", 13)
	label.add_theme_color_override("font_color", Ui.TEXT)
	label.position = Vector2(WIDTH - 14 - 60, y)
	label.size = Vector2(60, 18)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_panel.add_child(label)
	return label



static func driven() -> Vehicle:
	var player: = Game.local_player
	if player == null:
		return null
	var vehicle: Variant = player.get_attr("Vehicle")
	if vehicle is Vehicle and is_instance_valid(vehicle) and vehicle.driver() == player:
		return vehicle
	return null


func _process(_delta: float) -> void :
	var vehicle: = driven()
	_panel.visible = vehicle != null
	if vehicle == null:
		_wheel_hint.visible = false
		return
	if Input.is_action_just_pressed("veh_door") and not Game.ui_open:
		bay_door(vehicle)

	_name.text = Text.say(Text.named("vehicles", vehicle.spec["name"])).to_upper()

	_speed.text = str(Ui.speed(absf(vehicle.forward_speed) * float(Config.Hud.MetresPerStud) * 3.6))
	_unit.text = Text.say(Text.m("hud.truck.speedUnit"))
	var state: = vehicle.drive
	_gear.text = "R" if state.reverse else ("N" if state.standing > 0.6 else str(state.gear))

	for index in CONTROLS.size():
		var control: Array = CONTROLS[index]
		var entry: Dictionary = _rows[index]
		var active: = false
		var words: = Text.say(Text.m(control[1]))
		if control[0] == "veh_siren":
			active = vehicle.siren != 0
			words = Text.say(Text.f("hud.truck.siren", [vehicle.siren_name()]))
			entry["hold"].text = Text.say(Text.m("hud.truck.sirenHold")).to_upper()
		elif control[2] == "mast":
			active = _mast_up(vehicle)
		elif control[2] == "arrows":
			active = vehicle.arrows != 0
			words = Text.say(Text.m(["hud.truck.arrows", "hud.truck.arrowsLeft", "hud.truck.arrowsRight"][vehicle.arrows]))
		elif control[2] != "":
			active = vehicle.get(control[2]) == true
		var label: Label = entry["label"]
		label.text = words.to_upper()
		label.add_theme_color_override("font_color", Ui.YELLOW if active else Ui.TEXT)
		if entry.has("lamp"):
			entry["lamp"].modulate = Ui.YELLOW if active else Ui.INSET
			entry["glow"].visible = active


	var rows: = 0
	for index in CONTROLS.size():
		var row: Control = _rows[index]["label"].get_parent()
		var kind: String = CONTROLS[index][2]
		row.visible = (kind != "mast" or vehicle.data.has("mast")) and (kind != "arrows" or vehicle.has_arrows())
		if row.visible:
			row.position.y = TOP + rows * ROW
			rows += 1
	_place_bars(TOP + rows * ROW + 8)
	for index in CONTROLS.size():
		var said: = Controls.bound_name(CONTROLS[index][0])
		var letter: = _caps[index].get_child(0) as Label
		if letter.text != said:
			letter.text = said
			Ui._fit_key(_caps[index])
			_fit_row(index)
	var simple: = Settings.simple()
	_wheel_hint.visible = simple
	if simple:
		_wheel_hint.position = _panel.position + Vector2(0, _panel.size.y + 8)
		(_wheel_cap.get_child(0) as Label).text = Controls.bound_name("interact")
		_wheel_words.text = Text.say(Text.m("hud.cab.hint")).to_upper()
	var has_fuel: = vehicle.fuel_capacity > 0.0
	var share: = vehicle.fuel / vehicle.fuel_capacity if has_fuel else 0.0
	_fuel_caps.text = Text.say(Text.m("hud.truck.fuel")).to_upper()
	Ui.set_bar(_fuel_bar, share, Ui.state(Ui.RED) if share < float(Config.Truck.Fuel.Low) else Ui.YELLOW)
	_fuel.text = "%d L" % int(vehicle.fuel)
	var has_tank: = vehicle.capacity > 0.0
	_water_caps.visible = has_tank
	_water_bar.visible = has_tank
	_water.visible = has_tank
	_panel.size.y = TOP + rows * ROW + 8 + FUEL_ROW + (WATER_ROW if has_tank else 0.0)
	if has_tank:
		_water_caps.text = Text.say(Text.m("hud.ladder.water")).to_upper()
		Ui.set_bar(_water_bar, vehicle.water / vehicle.capacity, Ui.BLUE)
		_water.text = "%d L" % int(vehicle.water)



func _place_bars(y: float) -> void :
	_fuel_caps.position.y = y - 2
	_fuel_bar.position.y = y
	_fuel.position.y = y - 2
	_water_caps.position.y = y + WATER_ROW - 2
	_water_bar.position.y = y + WATER_ROW
	_water.position.y = y + WATER_ROW - 2



func _mast_up(vehicle: Vehicle) -> bool:
	if _trucks == null or not is_instance_valid(_trucks):
		_trucks = get_tree().root.find_child("TruckService", true, false) as TruckService
	if _trucks == null:
		return false
	var mast: Dictionary = _trucks._masts.get(vehicle, {})
	return bool(mast.get("up", false))



static func bay_door(vehicle: Vehicle) -> void :
	var station: = Game.station
	var bay: = int(vehicle.spec.get("bay", 0))
	if station == null or bay < 1 or bay > station.doors.size():
		Game.notify(Text.m("gear.truck.noBayDoor"), "warning", Game.local_player)
	elif vehicle.global_position.distance_to(station.door_position) <= float(Config.Truck.DoorRemoteRange):
		Net.request("station.door", [String(vehicle.get_path())])
	else:
		Game.notify(Text.m("gear.truck.doorTooFar"), "warning", Game.local_player)
