extends RefCounted






static func start(main: Node) -> void :
	var world: = NetWorld.new()
	world.name = "NetWorld"
	main.add_child(world)
	var port: = Net.PORT
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--port="):
			port = int(arg.substr(7))
	for arg in OS.get_cmdline_user_args():
		if arg == "--host":

			for other in OS.get_cmdline_user_args():
				if other.begins_with("--server-password="):
					Net._password = other.substr(18)
			Net.host.call_deferred(port)
		elif arg == "--host-online":
			Net.online.connect( func(code: String) -> void : print("Net: online, code ", code if code else "(none: the noray server was not reached)"))
			Net.listed.connect( func(ok: bool) -> void : print("Net: on the server list: ", ok))
			var shown_name: = ""
			var password: = ""
			for other in OS.get_cmdline_user_args():
				if other.begins_with("--server-name="):
					shown_name = other.substr(14)
				elif other.begins_with("--server-password="):
					password = other.substr(18)
			Net.host_online.call_deferred(port, shown_name, password)
		elif arg.begins_with("--join=") and Net.is_code(arg.substr(7)):
			Net.join_code.call_deferred(arg.substr(7))
		elif arg.begins_with("--join="):
			Net.join.call_deferred(arg.substr(7), port)
