extends RefCounted



static func start(main: Node) -> void :
	var crew: = CrewService.new()
	crew.name = "Crew"
	main.add_child(crew)
