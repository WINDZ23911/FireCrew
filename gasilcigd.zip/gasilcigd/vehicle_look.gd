class_name VehicleLook
extends RefCounted








const GLASS_SHADER: = preload("res://shaders/vehicle_glass.gdshader")
const FLARE_SHADER: = preload("res://shaders/lamp_flare.gdshader")
const SHADOW_SHADER: = preload("res://shaders/contact_shadow.gdshader")
const TAPE_SHADER: = preload("res://shaders/vehicle_tape.gdshader")


const PAINT_SURFACES: = ["sideL", "sideR", "ends"]

const COAT: = 0.62
const COAT_AGE: = 0.4

const FLEET_KEYS: = {"Fire Truck": "pumper", "Tanker": "tanker", "Ladder Truck": "ladder", "Command Vehicle": "pickup", "Ambulance": "ambulance"}


const SWATCH_MIDDLES: = {"white": Vector2(145, 845), "yellow": Vector2(545, 745), "green": Vector2(645, 945), "lime": Vector2(745, 945)}
const SHEET: = 1024.0







const TRUCK_TAPE: = {"swatches": ["white", "yellow"], "pieces": ["Body", "DoorCab", "Shutter", "Flap"], "arches": Vector4(-8.7, 7.6, -0.8, 2.85), "bumper": Vector2(-10.5, 0.15)}
const TAPE: = {
	"pumper": TRUCK_TAPE, 
	"tanker": TRUCK_TAPE, 
	"ladder": {"swatches": ["white"], "pieces": ["Shutter"]}, 
	"pickup": {"swatches": ["white"], "pieces": ["Body", "DoorCab", "DoorCrew", "Hatch"]}, 
	"ambulance": {"swatches": ["green", "lime"], "pieces": ["Body", "DoorCab", "DoorCrew", "DoorBack"]}, 
}

static var _glass: Dictionary = {}
static var _flares: Dictionary = {}
static var _flare_mesh: QuadMesh
static var _shadow: ShaderMaterial
static var _shadow_mesh: PlaneMesh
static var _coated: Dictionary = {}
static var _taped: Dictionary = {}
static var _tapes: Dictionary = {}
static var _taped_meshes: Array[WeakRef] = []
static var _lifted: Dictionary = {}


const NIGHT_LIFT: = 0.9



static func glass(tint: Color, inside: = 0.1) -> ShaderMaterial:
	var key: = [tint, inside]
	if not _glass.has(key):
		var made: = ShaderMaterial.new()
		made.shader = GLASS_SHADER
		made.set_shader_parameter("tint", tint)
		made.set_shader_parameter("inside", inside)
		_glass[key] = made
	return _glass[key]








static func coat(mesh: MeshInstance3D, vehicle_name: = "", own_tape: = {}) -> void :
	if mesh.mesh == null:
		return
	var key: String = FLEET_KEYS.get(vehicle_name, "")
	var age: float = Edition.fleet(key).get("age", COAT_AGE)
	for surface in mesh.mesh.get_surface_count():
		var material: = mesh.mesh.surface_get_material(surface) as StandardMaterial3D
		if material != null and not _lifted.has(material) and String(material.resource_name) != "glass" and material.albedo_texture != null:

			_lifted[material] = true
			material.emission_enabled = true
			material.emission_operator = BaseMaterial3D.EMISSION_OP_MULTIPLY
			material.emission_texture = material.albedo_texture
			material.emission = _lift_now
		if material == null or _coated.has(material) or not String(material.resource_name) in PAINT_SURFACES:
			continue
		_coated[material] = true
		material.clearcoat_enabled = true
		material.clearcoat = COAT * (1.0 - age)
		material.clearcoat_roughness = 0.12 + 0.3 * age
	if not own_tape.is_empty():
		var which: = {"swatches": own_tape.get("swatches", []), "pieces": own_tape.get("pieces", [])}
		var arches: Array = own_tape.get("arches", [])
		if arches.size() == 4:
			which["arches"] = Vector4(arches[0], arches[1], arches[2], arches[3])
		var bumper: Array = own_tape.get("bumper", [])
		if bumper.size() == 2:
			which["bumper"] = Vector2(bumper[0], bumper[1])
		tape(mesh, which)
	elif TAPE.has(key):
		tape(mesh, TAPE[key])


static var _lift_now: = Color.BLACK



static func night_lift(lifted: Color) -> void :
	var lift: = Color(lifted.r, lifted.g, lifted.b) * NIGHT_LIFT
	if lift.is_equal_approx(_lift_now):
		return
	_lift_now = lift
	for material: StandardMaterial3D in _lifted:
		material.emission = lift




static func tape(mesh: MeshInstance3D, which: Dictionary) -> void :
	var swatches: Array = which["swatches"]
	var pieces: Array = which["pieces"]
	var bits: = String(mesh.name).split("_")
	if bits.size() != 2 or bits[1] != "interior" or not pieces.any( func(piece: String) -> bool: return bits[0].begins_with(piece)):
		return
	var material: = mesh.mesh.surface_get_material(0) as StandardMaterial3D
	if material == null or material.albedo_texture == null:
		return
	var middles: Array[Vector2] = []
	for swatch: String in swatches:
		middles.append(SWATCH_MIDDLES[swatch] / SHEET)
	var key: = [mesh.mesh, swatches]
	if not _taped.has(key):
		var found: = false
		var uvs: PackedVector2Array = mesh.mesh.surface_get_arrays(0)[Mesh.ARRAY_TEX_UV]
		for uv in uvs:
			for middle in middles:
				if uv.distance_squared_to(middle) < 1e-05:
					found = true
					break
			if found:
				break
		_taped[key] = found
	if not _taped[key]:
		return
	var sheet_key: = [material.albedo_texture, which]
	if not _tapes.has(sheet_key):
		var made: = ShaderMaterial.new()
		made.shader = TAPE_SHADER
		made.set_shader_parameter("sheet", material.albedo_texture)
		var packed: Array[Vector4] = []
		for index in 4:
			var middle: Vector2 = middles[index] if index < middles.size() else Vector2(-1, -1)
			packed.append(Vector4(middle.x, middle.y, 0, 0))
		made.set_shader_parameter("swatches", packed)
		made.set_shader_parameter("arches", which.get("arches", Vector4(0, 0, 0, -1)))
		made.set_shader_parameter("bumper", which.get("bumper", Vector2(-10000.0, -10000.0)))
		_tapes[sheet_key] = made
	mesh.set_meta("tape", _tapes[sheet_key])
	_taped_meshes.append(weakref(mesh))
	mesh.material_overlay = _tapes[sheet_key] if Settings.quality >= Graphics.MEDIUM else null



static func tape_level(level: int) -> void :
	var kept: Array[WeakRef] = []
	for ref in _taped_meshes:
		var mesh: = ref.get_ref() as MeshInstance3D
		if mesh == null:
			continue
		mesh.material_overlay = mesh.get_meta("tape") if level >= Graphics.MEDIUM else null
		kept.append(ref)
	_taped_meshes = kept




static func flare(parent: Node3D, at: Vector3, color: Color, size: float, aim: = 0.0) -> MeshInstance3D:
	if _flare_mesh == null:
		_flare_mesh = QuadMesh.new()
		_flare_mesh.size = Vector2.ONE
	var key: = [color, size, aim]
	if not _flares.has(key):
		var made: = ShaderMaterial.new()
		made.shader = FLARE_SHADER
		made.set_shader_parameter("color", color)
		made.set_shader_parameter("near_size", size)
		made.set_shader_parameter("aim", aim)
		_flares[key] = made
	var quad: = MeshInstance3D.new()
	quad.name = "Flare"
	quad.mesh = _flare_mesh
	quad.material_override = _flares[key]
	quad.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	quad.extra_cull_margin = size * 4.0
	quad.visible = false
	parent.add_child(quad)
	quad.position = at
	return quad



static func shine(quad: MeshInstance3D, amount: float) -> void :
	if quad == null:
		return
	quad.visible = amount > 0.01
	if quad.visible:
		quad.set_instance_shader_parameter("glow", amount)



static func glare_now() -> float:
	if Sky3D.current == null:
		return 1.0
	return lerpf(1.0, 0.3, Sky3D.current.daylight())




static func contact_shadow(parent: Node3D, at: Vector3, width: float, length: float) -> MeshInstance3D:
	if _shadow == null:
		_shadow = ShaderMaterial.new()
		_shadow.shader = SHADOW_SHADER
		_shadow_mesh = PlaneMesh.new()
		_shadow_mesh.size = Vector2.ONE
	var quad: = MeshInstance3D.new()
	quad.name = "ContactShadow"
	quad.mesh = _shadow_mesh
	quad.material_override = _shadow
	quad.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(quad)

	quad.transform = Transform3D(Basis.from_scale(Vector3(width * 1.12, 1, length * 1.06)), at + Vector3(0, 0.06, 0))
	return quad








const LAMP_COLOURS: = {
	"blue": {"lens": Color(0.12, 0.3, 1.0), "glow": Color(0.3, 0.55, 1.0), "core": Color(0.05, 0.1, 0.32), "core_on": Color(0.45, 0.68, 1.0), 
		"light": Color(70 / 255.0, 120 / 255.0, 1.0), "glare": Color(0.25, 0.45, 1.0)}, 
	"red": {"lens": Color(0.85, 0.06, 0.05), "glow": Color(1.0, 0.18, 0.12), "core": Color(0.3, 0.03, 0.03), "core_on": Color(1.0, 0.3, 0.22), 
		"light": Color(1.0, 0.16, 0.1), "glare": Color(1.0, 0.16, 0.1)}, 
	"white": {"lens": Color(0.88, 0.9, 0.93), "glow": Color(1.0, 1.0, 0.98), "core": Color(0.4, 0.42, 0.45), "core_on": Color(1.0, 1.0, 0.97), 
		"light": Color(1.0, 0.97, 0.92), "glare": Color(1.0, 0.97, 0.9)}, 
	"amber": {"lens": Color(1.0, 0.55, 0.05), "glow": Color(1.0, 0.62, 0.15), "core": Color(0.35, 0.18, 0.02), "core_on": Color(1.0, 0.7, 0.25), 
		"light": Color(1.0, 0.6, 0.15), "glare": Color(1.0, 0.6, 0.15)}, 
}




static func lamp_colour(info: Dictionary) -> String:
	var own: = str(info.get("colour", ""))
	if LAMP_COLOURS.has(own):
		return own
	var colours: Array = Edition.data().get("lamps", {}).get("colours", [])
	if not colours.is_empty():
		var chosen: = str(colours[int(info.get("phase", 0)) % colours.size()])
		if LAMP_COLOURS.has(chosen):
			return chosen
	return "blue"








static func beacon(parent: Node3D, at: Vector3, size: Vector3, colour: = "blue") -> Dictionary:
	var paint: Dictionary = LAMP_COLOURS.get(colour, LAMP_COLOURS["blue"])
	var root: = Node3D.new()
	root.name = "Beacon"
	parent.add_child(root)
	root.position = at
	var lens: = StandardMaterial3D.new()
	lens.albedo_color = Color(paint["lens"], 0.74)
	lens.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	lens.roughness = 0.06
	lens.metallic_specular = 0.9
	lens.rim_enabled = true
	lens.rim = 0.6
	lens.rim_tint = 0.3
	lens.clearcoat_enabled = true
	lens.clearcoat = 1.0
	lens.clearcoat_roughness = 0.05
	lens.emission_enabled = true
	lens.emission = paint["glow"]
	lens.emission_energy_multiplier = 0.0
	var core: = StandardMaterial3D.new()
	core.albedo_color = paint["core"]
	core.roughness = 0.3
	core.emission_enabled = true
	core.emission = paint["core_on"]
	core.emission_energy_multiplier = 0.0
	var thin: = minf(size.x, size.z)
	var flat: = thin < 0.2
	if flat:

		var across_x: = size.x >= size.z
		var width: = maxf(size.x, size.z)
		var face: = Basis.IDENTITY if across_x else Basis(Vector3.UP, PI / 2.0)
		_piece(root, _box(Vector3(width, size.y, thin * 0.6)), face, Vector3.ZERO, _black())
		var pill: = CapsuleMesh.new()
		pill.radius = size.y * 0.42
		pill.height = width * 0.92
		pill.radial_segments = 12
		pill.rings = 3
		var lying: = face * Basis(Vector3.BACK, PI / 2.0) * Basis.from_scale(Vector3(1, 1, thin * 1.2 / (size.y * 0.84)))
		_piece(root, pill, lying, Vector3.ZERO, lens)
		var led: = _box(Vector3(width * 0.8, size.y * 0.35, thin * 0.5))
		_piece(root, led, face, Vector3.ZERO, core)
	elif size.x > size.z * 1.8 or size.z > size.x * 1.8:

		var along_x: = size.x > size.z
		var length: = maxf(size.x, size.z)
		var depth: = minf(size.x, size.z)
		var turn: = Basis.IDENTITY if along_x else Basis(Vector3.UP, PI / 2.0)
		_piece(root, _box(Vector3(length, size.y * 0.32, depth)), turn, Vector3(0, - size.y * 0.34, 0), _black())
		var pill: = CapsuleMesh.new()
		pill.radius = size.y * 0.42
		pill.height = length * 0.98
		pill.radial_segments = 14
		pill.rings = 4
		var lying: = turn * Basis(Vector3.BACK, PI / 2.0) * Basis.from_scale(Vector3(1, 1, depth * 0.92 / (size.y * 0.84)))
		_piece(root, pill, lying, Vector3(0, size.y * 0.08, 0), lens)
		_piece(root, _box(Vector3(length * 0.9, size.y * 0.18, depth * 0.3)), turn, Vector3(0, size.y * 0.02, 0), _chrome())
		for step in 4:
			var x: = (step - 1.5) * length * 0.22
			_piece(root, _box(Vector3(length * 0.12, size.y * 0.3, depth * 0.55)), turn, turn * Vector3(x, size.y * 0.08, 0), core)
	else:

		var radius: = minf(size.x, size.z) * 0.46
		var foot: = CylinderMesh.new()
		foot.top_radius = radius * 1.08
		foot.bottom_radius = radius * 1.15
		foot.height = size.y * 0.24
		foot.radial_segments = 16
		_piece(root, foot, Basis.IDENTITY, Vector3(0, - size.y * 0.38, 0), _black())
		var body: = CylinderMesh.new()
		body.top_radius = radius
		body.bottom_radius = radius
		body.height = size.y * 0.5
		body.radial_segments = 16
		_piece(root, body, Basis.IDENTITY, Vector3(0, - size.y * 0.01, 0), lens)
		var dome: = SphereMesh.new()
		dome.radius = radius
		dome.height = radius
		dome.is_hemisphere = true
		dome.radial_segments = 16
		dome.rings = 5
		_piece(root, dome, Basis.from_scale(Vector3(1, size.y * 0.32 / radius, 1)), Vector3(0, size.y * 0.24, 0), lens)
		var mirror: = CylinderMesh.new()
		mirror.top_radius = radius * 0.5
		mirror.bottom_radius = radius * 0.62
		mirror.height = size.y * 0.42
		mirror.radial_segments = 10
		_piece(root, mirror, Basis.IDENTITY, Vector3(0, - size.y * 0.02, 0), _chrome())
		var led: = _box(Vector3(radius * 0.7, size.y * 0.3, radius * 0.7))
		_piece(root, led, Basis.IDENTITY, Vector3(0, 0.0, 0), core)
	return {"root": root, "lens": lens, "core": core}



static func beacon_lit(lamp: Dictionary, on: bool) -> void :
	(lamp["lens"] as StandardMaterial3D).emission_energy_multiplier = 1.6 if on else 0.0
	(lamp["lens"] as StandardMaterial3D).albedo_color.a = 0.86 if on else 0.74
	(lamp["core"] as StandardMaterial3D).emission_energy_multiplier = 7.0 if on else 0.0


static var _black_material: StandardMaterial3D
static var _chrome_material: StandardMaterial3D


static func _black() -> StandardMaterial3D:
	if _black_material == null:
		_black_material = StandardMaterial3D.new()
		_black_material.albedo_color = Color(0.05, 0.05, 0.06)
		_black_material.roughness = 0.45
	return _black_material


static func _chrome() -> StandardMaterial3D:
	if _chrome_material == null:
		_chrome_material = StandardMaterial3D.new()
		_chrome_material.albedo_color = Color(0.85, 0.87, 0.9)
		_chrome_material.metallic = 1.0
		_chrome_material.roughness = 0.15
	return _chrome_material


static func _box(size: Vector3) -> BoxMesh:
	var box: = BoxMesh.new()
	box.size = size
	return box


static func _piece(parent: Node3D, mesh: Mesh, basis: Basis, at: Vector3, material: Material) -> MeshInstance3D:
	var piece: = MeshInstance3D.new()
	piece.mesh = mesh
	piece.material_override = material
	piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(piece)
	piece.transform = Transform3D(basis, at)
	return piece
