class_name FireAlarm
extends Node













const TICK: = 0.25
const PANEL_HOLD: = 1.5
const CHECK_REACH: = 4.0
const CAUSES: = 3
const ALARM_COLOR: = Color(230 / 255.0, 120 / 255.0, 30 / 255.0)
const FIRE_COLOR: = Color(200 / 255.0, 50 / 255.0, 30 / 255.0)
const LCD_INK: = Color(0.05, 0.2, 0.08)

static var current: FireAlarm

var kind: = "alarm"
var _houses: Array[House] = []
var _panel: Dictionary = {}
var _lcd: Array = []
var _mirrored: = false
var _mystery: = false
var _mystery_room: = ""
var forced_real: = -1


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	Net.share("alarm.panel", _net_state, _net_apply, 2.0)

	Net.stopped.connect( func() -> void :
		if _mirrored:
			_mirrored = false
			_drop_panel())
	Text.language_changed.connect( func(_code: String) -> void : _show_lcd())


func start() -> void :
	for house: House in IndustryZone.houses.values():
		if not house.scenarios.is_empty():
			_houses.append(house)


func available() -> bool:
	for house in _houses:
		if not house.ruined:
			return true
	return false


func _level() -> int:
	return clampi(Alarm.level, 1, 3)



static func real_chance(level: int) -> float:
	var chances: Array = Config.Incidents.Alarm.RealChance
	return float(chances[clampi(level, 1, chances.size()) - 1])


func run() -> bool:
	if Net.is_client():
		return false
	var open: Array[House] = []
	var fresh: Array[House] = []
	for house in _houses:
		if not house.ruined:
			open.append(house)
			if CallService.current == null or not CallService.current.burnt_lately(house):
				fresh.append(house)
	if open.is_empty():
		return false
	if not fresh.is_empty():
		open = fresh
	var house: House = open[randi() % open.size()]
	var real: bool = randf() < real_chance(_level()) if forced_real < 0 else forced_real == 1
	if real and FireService.current != null:

		_mystery = true
		_watch_mystery(house)
		await FireService.current.run_incident(house, {"alarm": true})
		_mystery = false
		_drop_panel()
		return true
	await _false_alarm(house)
	return true







static func mask(incident: Dictionary) -> void :
	if current == null or not current._mystery or incident.is_empty() or incident.get("kind") != "fire":
		return
	incident["kind"] = "alarm"
	for key: String in ["flames", "flames_out", "victims", "victims_out", "victims_fetched", "victims_lost", "progress_text"]:
		incident.erase(key)
	incident["health"] = 100.0
	incident["total"] = 3
	incident["done"] = 0
	var marker: Variant = FireService.current.incident.get("marker") if FireService.current != null else null
	if marker is CallMarker and is_instance_valid(marker) and Text.say(marker.get_meta("text", ""), "en") != Text.say(Text.m("calls.markers.alarm"), "en"):
		(marker as CallMarker).recolor(Text.m("calls.markers.alarm"), ALARM_COLOR)




func _watch_mystery(house: House) -> void :
	await get_tree().process_frame
	_mystery_room = _fire_room(house)
	while _mystery and is_inside_tree():
		var fire: = FireService.current
		if fire == null or fire.incident.is_empty():
			return
		for player in Game.players:
			if is_instance_valid(player) and player.brain == null and house.room_at(player.root_position()) != null and fire.smoke_at(player.head_position()) >= float(Config.Incidents.Alarm.SeenSmoke):
				_reveal()
				return
		await get_tree().create_timer(TICK, false).timeout



func _reveal() -> void :
	if not _mystery:
		return
	_mystery = false
	var marker: Variant = FireService.current.incident.get("marker") if FireService.current != null else null
	if marker is CallMarker and is_instance_valid(marker):
		(marker as CallMarker).recolor(Text.m("calls.markers.fire"), FIRE_COLOR)
	Game.notify(Text.m("calls.alarm.confirmed"), "danger")




static func _fire_room(house: House) -> String:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return ""
	var counts: Dictionary = {}
	for node: Dictionary in fire.incident["group"]["nodes"]:
		var room: Variant = node.get("room")
		if not node["burning"] or not room is String or not house.rooms.has(room):
			continue
		for scenario: Dictionary in house.scenarios:
			if node["name"] == scenario.get("origin") and room == scenario.get("room"):
				return room
		counts[room] = int(counts.get(room, 0)) + 1
	var best: = ""
	for room: String in counts:
		if best.is_empty() or counts[room] > counts[best]:
			best = room
	return best






func put_panel(house: House, on_read: Callable) -> void :
	_drop_panel()
	var holder: = Node3D.new()
	add_child(holder)
	holder.global_position = panel_position(house)

	CallFixture.panel(holder, house)
	var prompt: = Prompt.new()
	prompt.net_id = "alarm.panel"
	prompt.action = Text.m("calls.alarm.panel.action")
	prompt.object = Text.m("calls.alarm.panel.object")
	prompt.hold = PANEL_HOLD
	prompt.reach = 8.0
	holder.add_child(prompt)
	_panel = {"house": house, "prompt": prompt, "holder": holder, "read": false, "on_read": on_read, "lcd": _make_lcd(holder)}
	set_lcd([Text.m("calls.alarm.lcd.alarm"), Text.m("calls.alarm.lcd.zones")])
	prompt.triggered.connect( func(player: Player) -> void :
		if Net.is_client() or _panel.is_empty():
			return
		var first: bool = not _panel["read"]
		_panel["read"] = true
		if first and _mystery:

			var room_name: = _mystery_room if not _mystery_room.is_empty() else _fire_room(house)
			if not room_name.is_empty():
				set_lcd(lcd_zone(house, room_name))
			_reveal()
		_panel["on_read"].call(player, first)
	)



func _make_lcd(holder: Node3D) -> Label3D:
	var face: Node3D = holder.get_node_or_null("Panel")
	if face == null:
		return null
	var label: = Label3D.new()
	label.name = "Display"
	label.font = Ui.label_font()
	label.font_size = 48
	label.pixel_size = 0.0016
	label.outline_size = 0
	label.modulate = LCD_INK
	label.line_spacing = 2
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.width = 1.5 / label.pixel_size
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.double_sided = false
	label.shaded = false

	label.position = Vector3(-0.72, 0.2, CallFixture.PANEL_SIZE.z / 2.0 + 0.07)
	face.add_child(label)
	return label



func set_lcd(lines: Array) -> void :
	_lcd = lines
	_show_lcd()


func _show_lcd() -> void :
	if _panel.is_empty() or not is_instance_valid(_panel.get("lcd")):
		return
	var said: PackedStringArray = []
	for line: Variant in _lcd:
		said.append(Text.say(line))
	(_panel["lcd"] as Label3D).text = "\n".join(said)



static func lcd_zone(house: House, room_name: String) -> Array:
	var number: = house.rooms.keys().find(room_name) + 1
	var floor_number: = int(house.rooms[room_name]["floor"]) if house.rooms.has(room_name) else 0
	var storey: = Text.m("calls.floors.ground" if floor_number == 0 else ("calls.floors.first" if floor_number == 1 else "calls.floors.upper"))
	return [Text.m("calls.alarm.lcd.alarm"), Text.f("calls.alarm.lcd.zone", [number, Text.upper(Text.m("calls.rooms.%s.name" % room_name))]), Text.upper(storey)]


func _drop_panel() -> void :
	if not _panel.is_empty() and is_instance_valid(_panel["holder"]):
		_panel["holder"].queue_free()
	_panel = {}
	_lcd = []



static func panel_position(house: House) -> Vector3:
	var at: Variant = house.data.get("panel")
	if at is Array and (at as Array).size() == 3:
		return house.lot * Rbx.v3(at)
	var door: Variant = house.outside_door()
	if door is Dictionary:
		var shut: Transform3D = door["shut"]
		var inward: = shut.basis.z
		if inward.dot(house.position - shut.origin) < 0.0:
			inward = - inward
		return shut.origin + inward * 2.0 + Vector3(0, 4.5, 0)
	return house.position



static func zone_words(house: House, room_name: String) -> Dictionary:
	var names: Array = house.rooms.keys()
	var number: = names.find(room_name) + 1
	var floor_number: = int(house.rooms[room_name]["floor"]) if house.rooms.has(room_name) else 0
	var storey: = Text.m("calls.floors.ground" if floor_number == 0 else ("calls.floors.first" if floor_number == 1 else "calls.floors.upper"))
	return Text.f("calls.alarm.zone", [number, Text.m("calls.rooms.%s.name" % room_name), storey])


func _false_alarm(house: House) -> void :
	house.ruined = true
	var rooms: Array = house.rooms.keys()
	var room_name: String = rooms[randi() % rooms.size()]
	var room: Dictionary = house.rooms[room_name]
	var call_name: = Text.join([Text.m("calls.alarm.title"), Text.m("calls.separator"), CallKit.building_name(house)])
	var marker: = CallMarker.make(house.position + Vector3(0, house.height / 2.0 + 10.0, 0), Text.m("calls.markers.alarm"), ALARM_COLOR)
	CallService.current.publish("alarm", call_name, house.position, 3)
	Alarm.par(float(Alarm.settings()["Grade"]["Job"]["alarm"]["Base"]))
	if house.approach != null:
		Game.incident["approach"] = house.approach
	Game.notify(Text.f("calls.alarm.alarm", [call_name]), "warning")
	Game.notify(Text.m("calls.alarm.brief"), "")

	house.show_smoke(room_name, 0.25)
	var state: = {"read": false, "checked": false, "reset": false, "who": {}}
	put_panel(house, func(player: Player, first: bool) -> void :
		state["who"][player] = true
		if first:
			state["read"] = true
			set_lcd(lcd_zone(house, room_name))
			Game.notify(zone_words(house, room_name), "warning")
		elif state["checked"] and not state["reset"]:
			state["reset"] = true
			set_lcd([Text.m("calls.alarm.lcd.normal"), Text.m("calls.alarm.lcd.reset")])
			Game.notify(Text.m("calls.alarm.reset"), "good")
		elif not state["checked"]:
			Game.tell(player, Text.m("calls.alarm.checkFirst"))
	)
	var waited: = 0.0
	while not CallService.current.overdue(waited) and not state["reset"]:
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		if state["read"] and not state["checked"]:
			for player in Game.players:
				if is_instance_valid(player) and house.room_at(player.root_position()) == room:
					state["checked"] = true
					state["who"][player] = true
					house.show_smoke(room_name, 0.0)
					Game.notify(Text.f("calls.alarm.found", [Text.m("calls.alarm.causes.%d" % randi_range(1, CAUSES))]), "good")
					break
		var done: = int(state["read"]) + int(state["checked"]) + int(state["reset"])
		if done != int(Game.incident.get("done", 0)):
			CallService.current.progress(done)
		if not state["read"]:
			CallService.current.next_step(Text.m("calls.alarm.next.read"))
		elif not state["checked"]:
			CallService.current.next_step(Text.f("calls.alarm.next.check", [rooms.find(room_name) + 1, Text.m("calls.rooms.%s.name" % room_name)]))
		else:
			CallService.current.next_step(Text.m("calls.alarm.next.reset"))
	marker.queue_free()
	house.show_smoke(room_name, 0.0)
	var good: bool = state["reset"]
	if good:
		Alarm.done()
		var reward: = int(Config.Incidents.Alarm.Reward)
		CallKit.pay_helpers(state["who"], reward, "bonus")
		Game.notify(Text.f("calls.alarm.done", [call_name, Alarm.pay(reward)]), "good")
	Game.incident.erase("next")
	await CallService.current.settle()
	CallService.current.clear( not good)
	_drop_panel()
	get_tree().create_timer(10.0, false).timeout.connect( func() -> void : house.ruined = false)





func _net_state() -> Variant:
	if _panel.is_empty():
		return {}
	return {"house": (_panel["house"] as House).net_index, "lcd": _lcd}


func _net_apply(state: Variant) -> void :
	if not Net.is_client():
		return
	if not state is Dictionary or (state as Dictionary).is_empty():
		_drop_panel()
		return
	_mirrored = true
	var index: = int(state["house"])
	if index < 0 or index >= House.all.size():
		return
	if _panel.is_empty() or (_panel["house"] as House).net_index != index:
		put_panel(House.all[index], func(_player: Player, _first: bool) -> void : pass)
	set_lcd(state.get("lcd", []))
