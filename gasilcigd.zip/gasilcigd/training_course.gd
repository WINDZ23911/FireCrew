class_name TrainingCourse
extends Node






const TICK: = 0.1
const SIDE_ROOM: = 1.0
const BACK_ROOM: = 8.0
const TIME_LIMIT: = 120.0
const TARGET_HOLD: = 0.35
const TARGET_DOWN: = 6.0
const TARGET_NAMES: = ["Target", "TargetRing", "TargetBull"]
const BOARD_GREEN: = Color(120 / 255.0, 220 / 255.0, 130 / 255.0)

static var current: TrainingCourse

var zone: Dictionary = {}
var targets: Dictionary = {}
var last: Variant = null
var best: Variant = null
var _runs: Dictionary = {}
var _before: Dictionary = {}
var _showing: Player
var _target_of: Dictionary = {}
var _board_part: = 0
var _own_label: Label3D
var _clock: = 0.0
var _shown_run: Variant = null


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var course: Variant = Game.records.get("station", {}).get("course")
	if not course is Dictionary:
		return
	zone = course["zone"]

	var store: = Game.store
	var label: Dictionary = store.nodes.get(int(course.get("board", 0)), {})
	var gui: Dictionary = store.nodes.get(int(label.get("p", 0)), {})
	_board_part = int(gui.get("p", 0))
	_build_targets()
	Game.water_landed.connect(_on_water)
	Text.language_changed.connect( func(_code: String) -> void : _show_results())

	Net.share("course", _net_state, _net_apply, 5.0)
	Net.stopped.connect( func() -> void : _shown_run = null)
	_show_results.call_deferred()
	_debug.call_deferred()







func _build_targets() -> void :
	var store: = Game.store
	var ids: Array = store.tagged.get("SprayTarget", [])
	for id: int in ids:
		var row: int = store.row_of.get(id, -1)
		if row < 0 or not store.name_at(row) in TARGET_NAMES:
			continue
		var at: = store.position(row)
		var lane: = roundi(at.x)
		if not targets.has(lane):
			var pivot: = Node3D.new()
			pivot.name = "Target%d" % lane
			add_child(pivot)
			targets[lane] = {"pivot": pivot, "pieces": [], "down": false, "sprayed": 0.0, "by": null, "placed": false}
		var target: Dictionary = targets[lane]
		if store.name_at(row) == "Target":

			target["pivot"].global_position = at - Vector3(0, store.size(row).y / 2.0 - 0.1, 0)
			target["placed"] = true
		target["pieces"].append(id)
	for lane: int in targets:
		var target: Dictionary = targets[lane]
		var pieces: Array = []
		for id: int in target["pieces"]:
			var piece: = Game.world.take(id)
			if piece == null:
				continue
			if not target["placed"]:
				target["pivot"].global_position = piece.global_position
				target["placed"] = true
			piece.reparent(target["pivot"])
			_target_of[piece] = target
			pieces.append(piece)
		target["pieces"] = pieces



func _on_water(hit: Dictionary, dt: float, _direction: Vector3, player: Player) -> void :
	if Net.is_client():
		return
	var target: Variant = _target_of.get(hit.get("collider"))
	if target == null:
		return
	target["sprayed"] += dt
	target["by"] = player
	if target["sprayed"] >= TARGET_HOLD and not target["down"]:
		knock_down(target, player)


func knock_down(target: Dictionary, player: Player) -> void :
	_tip(target, true)
	if player != null:
		_target_down(player)
	get_tree().create_timer(TARGET_DOWN, false).timeout.connect( func() -> void :
		target["sprayed"] = 0.0
		_tip(target, false)
	)


func _tip(target: Dictionary, down: bool) -> void :
	target["down"] = down
	if target.has("tween") and is_instance_valid(target["tween"]):
		target["tween"].kill()
	var pivot: Node3D = target["pivot"]

	var tween: = pivot.create_tween().set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BOUNCE if down else Tween.TRANS_QUAD)
	tween.tween_property(pivot, "rotation:x", deg_to_rad(-88.0) if down else 0.0, 0.5 if down else 0.8)
	target["tween"] = tween


func _target_down(player: Player) -> void :
	var run: Variant = _runs.get(player)
	if run != null and not run["target"]:
		run["target"] = true
		Game.notify(Text.m("gear.course.targetDown"), "", player)





static func clock(seconds: float) -> String:
	return Ui.decimal(seconds) + " s"


func _line(title: String, run: Dictionary) -> Dictionary:
	return Text.join([Text.m(title), "  %s  %s%s" % [run["name"], clock(run["time"]), " ★" if run["target"] else ""]])


func _show_results() -> void :
	var parts: Array = [Text.m("gear.course.board.title")]
	if last != null:
		parts.append_array(["\n", _line("gear.course.board.last", last)])
	if best != null:
		parts.append_array(["\n", _line("gear.course.board.best", best)])
	if last == null:
		parts.append_array(["\n", Text.m("gear.course.board.route")])
	_write(Text.join(parts))




func _write(message: Variant) -> void :
	if Dressing.current != null and Dressing.label_on(_board_part) != null:
		if _own_label != null:
			_own_label.queue_free()
			_own_label = null
		Dressing.set_text(_board_part, message)
		return
	var row: int = Game.store.row_of.get(_board_part, -1)
	if row < 0:
		return
	var size: = Game.store.size(row)
	if _own_label == null:
		_own_label = Label3D.new()
		_own_label.font = Ui.world_display_font()
		_own_label.font_size = 64
		_own_label.modulate = BOARD_GREEN
		_own_label.outline_size = 0
		_own_label.shaded = false
		add_child(_own_label)

		_own_label.global_transform = Game.store.transform(row) * Transform3D(Basis.IDENTITY, Vector3(0, 0, size.z / 2.0 + 0.05))
	var text: = Text.say(message)
	_own_label.text = text
	var extent: = _own_label.font.get_multiline_string_size(text, HORIZONTAL_ALIGNMENT_CENTER, -1, 64)
	_own_label.pixel_size = minf(size.x * 0.92 / maxf(extent.x, 1.0), size.y * 0.84 / maxf(extent.y, 1.0))





func _stop(player: Player, reason: Variant = null) -> void :
	_runs.erase(player)
	if _showing == player:
		_showing = null
		_show_results()
	if reason != null and is_instance_valid(player):
		Game.notify(reason, "", player)






func _net_state() -> Variant:
	var down: Array = []
	for lane: int in targets:
		if targets[lane]["down"]:
			down.append(lane)
	var running: Variant = null
	if _showing != null and is_instance_valid(_showing) and _runs.has(_showing):
		running = [_showing.display_name, float(_runs[_showing]["began"]), _runs[_showing]["target"]]
	return [down, last, best, running]


func _net_apply(state: Variant) -> void :
	for lane: int in targets:
		var down: bool = lane in state[0]
		if targets[lane]["down"] != down:
			_tip(targets[lane], down)
	var changed: bool = hash(last) != hash(state[1]) or hash(best) != hash(state[2]) or (_shown_run != null and state[3] == null)
	last = state[1]
	best = state[2]
	_shown_run = state[3]
	if _shown_run == null and changed:
		_show_results()


func _physics_process(delta: float) -> void :
	if zone.is_empty():
		return
	_clock += delta
	if _clock < TICK:
		return
	_clock -= TICK
	if Net.is_client():

		if _shown_run != null:
			_write("%s\n%s%s" % [_shown_run[0], clock(maxf(0.0, HostClock.now() - float(_shown_run[1]))), " ★" if _shown_run[2] else ""])
		return
	var now: = Game.now()
	for player: Player in _runs.keys():
		if not is_instance_valid(player) or not player in Game.players:
			_before.erase(player)
			_stop(player)
	for player in Game.players:
		if player.health <= 0.0:
			_before.erase(player)
			if _runs.has(player):
				_stop(player)
			continue
		var at: = player.root_position()
		var in_lanes: = at.x >= float(zone["x0"]) - SIDE_ROOM and at.x <= float(zone["x1"]) + SIDE_ROOM
		var start_line: float = zone["start"]
		var run: Variant = _runs.get(player)
		if run == null:

			var was: Variant = _before.get(player)
			if in_lanes and was != null and was > start_line and at.z <= start_line and at.z > start_line - 6.0:
				_runs[player] = {"began": now, "target": false}
				_showing = player
				Game.notify(Text.m("gear.course.started"), "", player)
		elif at.z <= float(zone["finish"]):
			var result: = {"name": player.display_name, "time": now - float(run["began"]), "target": run["target"]}
			last = result
			var record: bool = best == null or result["time"] < best["time"]
			if record:
				best = result
			_stop(player, Text.f("gear.course.result", [clock(result["time"]), " ★" if result["target"] else "", Text.m("gear.course.record") if record else ""]))
			_show_results()
		elif not in_lanes:
			_stop(player, Text.m("gear.course.leftLanes"))
		elif at.z > start_line + BACK_ROOM:
			_stop(player, Text.m("gear.course.turnedBack"))
		elif now - float(run["began"]) > TIME_LIMIT:
			_stop(player, Text.m("gear.course.outOfTime"))
		_before[player] = at.z
	if _showing != null and _runs.has(_showing):
		var run: Dictionary = _runs[_showing]
		_write("%s\n%s%s" % [_showing.display_name, clock(now - float(run["began"])), " ★" if run["target"] else ""])










func _debug() -> void :
	var joining: = false
	for arg in OS.get_cmdline_user_args():
		joining = joining or arg.begins_with("--join=")
	for arg in OS.get_cmdline_user_args():
		if arg == "--course-trace":
			_trace()
		if not arg.begins_with("--course="):
			continue
		if joining:
			if arg.begins_with("--course=target"):
				continue
			while not (Net.is_client() and Net.players.size() > 1):
				await get_tree().create_timer(0.2).timeout
			await get_tree().create_timer(2.0).timeout
		if arg == "--course=run":
			var x: = (float(zone["x0"]) + float(zone["x1"])) / 2.0
			Game.local_player.teleport(Vector3(x, 1.0, float(zone["start"]) + 4.0))
			if Game.local_player.camera:
				Game.local_player.camera.yaw = 0.0
		elif arg == "--course=finish":

			var x: = (float(zone["x0"]) + float(zone["x1"])) / 2.0
			Game.local_player.teleport(Vector3(x, 1.0, float(zone["start"]) + 2.0))
			await get_tree().create_timer(0.4 if not joining else 1.0).timeout
			Game.local_player.teleport(Vector3(x, 1.0, float(zone["start"]) - 2.0))
			await get_tree().create_timer(1.2 if not joining else 4.0).timeout
			Game.local_player.teleport(Vector3(x, 1.0, float(zone["finish"]) - 2.0))
		elif arg.begins_with("--course=target"):

			if arg.contains(","):
				while HostClock.now() < float(arg.get_slice(",", 1)):
					await get_tree().create_timer(0.1).timeout
			for lane: int in targets:
				knock_down(targets[lane], null)
				break


func _trace() -> void :
	print("course: zone %s; board at %s; targets at %s" % [zone, Game.store.position(Game.store.row_of.get(_board_part, 0)), targets.values().map( func(target: Dictionary) -> Vector3: return target["pivot"].global_position)])
	while true:
		await get_tree().create_timer(1.0).timeout
		var down: Array = []
		for lane: int in targets:
			if targets[lane]["down"]:
				down.append(lane)
		var label: Variant = Dressing.label_on(_board_part) if Dressing.current != null else _own_label
		var reads: = ""
		if label != null and "text" in label:
			reads = String(label.text).replace("\n", " / ")
		print("course %.0f s: board '%s' | down %s | last %s | best %s" % [HostClock.now(), reads, down, last, best])
