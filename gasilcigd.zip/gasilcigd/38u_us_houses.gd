extends RefCounted










const WALLS: = ["Body", "Gable", "Wing", "Parapet", "StairHead", "Penthouse", "Dormer", "GroundFloor", "Garages", "FarHouse"]
const ROOFS: = ["Roof", "WingRoof", "DormerRoof", "GarageRoof", "PenthouseRoof", "Porch", "FarRoof", "ShedRoof", "CarportRoof"]
const TRIM: = ["DoorFrame", "GlazingBar", "PorchPost", "CarportPost", "Sill"]

const DOWNTOWN: = Vector2(-320, 40)
const DOWNTOWN_REACH: = 330.0

const BRICK: = ["8E3B2E", "9A4434", "7F3A2C", "A0522D", "8B4A3A", "93402F", "7A3428"]
const TAN_BRICK: = ["B5835A", "A86F4E", "C09468", "9E7350"]
const SIDING: = ["F2F0EA", "F2F0EA", "E9E4D4", "DCD6C4", "C9CFD3", "B8C4CC", "D9CF9E", "A9B49A", "8E9AA3", "C2B49A", "EDE7D3"]
const ROOF_SHINGLES: = ["3C3C3E", "4A4A4C", "55524E", "5E5850", "2E3033", "6B6660", "4D4640"]
const SHUTTERS: = ["1E1F22", "1E1F22", "2F4A3A", "5A2522", "2A3550", "3A3F44"]
const DOORS: = ["7A1F1F", "1E2A3A", "1E1F22", "2F4A3A", "6B4A2E", "8C2A22", "F2F0EA"]
const BARN: = ["8B2E25", "7E2A22", "963226"]
const TRIM_WHITE: = Color8(244, 243, 238)


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "us":
		return ""
	var store: = kit.store
	var layout: Array = kit.layout()["buildings"]
	var counts: = {"brick": 0, "siding": 0, "barn": 0, "missions": 0, "boxes": 0, "washing": 0}
	for model in kit.models_under("Map/Buildings"):
		var rows: = store.rows_in(model)
		var body: = -1
		for row in rows:
			if store.name_at(row) == "Body":
				body = row
				break
		if body < 0:
			continue
		var at: = store.position(body)
		var spot: = Vector2(at.x, at.z)
		var building: Dictionary = _nearest(layout, spot)
		var style: = _style(str(building.get("kind", "house")), spot)
		counts[style] += 1
		_dress(store, rows, style, spot)

	for row in store.count:
		var part: = store.name_at(row)
		if part == "FarHouse" or part == "FarRoof":
			var at: = store.position(row)
			var spot: = Vector2(at.x, at.z)
			var style: = "brick" if _roll([int(spot.x), int(spot.y), "far"]) % 3 == 0 else "siding"
			_dress(store, PackedInt32Array([row]), style, spot)
		elif part == "Washing" or part == "Line":
			_hide(store, row)
			counts["washing"] += 1
		elif part == "WindowBox":
			var at: = store.position(row)
			if _roll([int(at.x * 3), int(at.z * 3), "box"]) % 5 != 0:
				_hide(store, row)
				counts["boxes"] += 1

	for house: House in House.all:
		var size: Array = house.data["size"]
		var half: = Vector2(float(size[0]) / 2.0, float(size[2]) / 2.0)
		var spot: = Vector2(house.lot.origin.x, house.lot.origin.z)
		var kind: = "house" if house.data["title"] in ["Bungalow", "Family house", "Town house", "Farmhouse"] else "shop"
		var style: = _style(kind, spot)
		var palette: = _palette(style, spot)
		var outer: = PackedInt32Array()
		for id: int in house.part_ids:
			var row: int = store.row_of.get(id, -1)
			if row < 0:
				continue
			var part: = store.name_at(row)
			var material: = store.material(row)
			if material == "ClayRoofTiles":
				store.set_color(row, palette["roof"])
				store.set_material(row, "Slate")
			elif material == "Plaster" and (part.begins_with("Ground") or part.begins_with("Upper") or part.begins_with("Parapet") or part == "Gable" or part == "Wall"):
				var local: = house.lot.affine_inverse() * store.position(row)
				var edge: = minf(half.x - absf(local.x), half.y - absf(local.z))
				if edge < 1.6 or part == "Gable" or part.begins_with("Parapet"):
					outer.append(row)
		for row in outer:
			store.set_color(row, palette["wall"])
			store.set_material(row, palette["material"])
		counts["missions"] += 1
	return "USA houses: %d brick, %d clapboard, %d barns, %d enterable dressed, %d window boxes and %d washing lines taken in" % [
		counts["brick"], counts["siding"], counts["barn"], counts["missions"], counts["boxes"], counts["washing"]]



static func _style(kind: String, spot: Vector2) -> String:
	var roll: = _roll([int(spot.x), int(spot.y), "style"]) % 100
	var downtown: = spot.distance_to(DOWNTOWN) < DOWNTOWN_REACH
	match kind:
		"shop", "public", "station":
			return "brick" if roll < (85 if downtown else 60) else "siding"
		"apartments", "terrace":
			return "brick"
		"outbuilding":
			return "barn" if roll < 30 else "siding"
	return "brick" if roll < (55 if downtown else 35) else "siding"


static func _palette(style: String, spot: Vector2) -> Dictionary:
	var seed_at: = [int(spot.x), int(spot.y)]
	var wall: Color
	var material: = "Siding"
	match style:
		"brick":
			wall = Color("#" + _pick(BRICK, seed_at + ["brick"]))
			if _roll(seed_at + ["tan"]) % 4 == 0:
				wall = Color("#" + _pick(TAN_BRICK, seed_at + ["tan brick"]))
			material = "Brick"
		"barn":
			wall = Color("#" + _pick(BARN, seed_at + ["barn"]))
			material = "WoodPlanks"
		_:
			wall = Color("#" + _pick(SIDING, seed_at + ["siding"]))
	return {
		"wall": wall, "material": material, 
		"roof": Color("#" + _pick(ROOF_SHINGLES, seed_at + ["roof"])), 
		"shutter": Color("#" + _pick(SHUTTERS, seed_at + ["shutter"])), 
		"door": Color("#" + _pick(DOORS, seed_at + ["door"])), 
	}


static func _dress(store: PartStore, rows: PackedInt32Array, style: String, spot: Vector2) -> void :
	var palette: = _palette(style, spot)
	for row in rows:
		var part: = store.name_at(row)
		var material: = store.material(row)
		if part in WALLS and material in ["Plaster", "Concrete", "Brick", "WoodPlanks", "SmoothPlastic", "Plastic", "Siding"]:
			if part == "GroundFloor" and style == "brick":
				store.set_color(row, palette["wall"].darkened(0.08))
			else:
				store.set_color(row, palette["wall"])
			store.set_material(row, palette["material"])
		elif part in ROOFS and material in ["ClayRoofTiles", "Slate", "Concrete"]:

			if material == "ClayRoofTiles" or part in ["FarRoof", "Porch", "ShedRoof"]:
				store.set_color(row, palette["roof"])
				store.set_material(row, "Slate")
		elif part == "Shutter":
			store.set_color(row, palette["shutter"])
		elif part in TRIM:
			store.set_color(row, TRIM_WHITE)
		elif part == "Door" and material == "Wood":
			store.set_color(row, palette["door"])
			store.set_material(row, "SmoothPlastic")


static func _hide(store: PartStore, row: int) -> void :
	store.set_transparency(row, 1.0)
	store.set_flags(row, 0)


static func _nearest(layout: Array, spot: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building
	return best


static func _roll(key: Array) -> int:
	return rand_from_seed(hash(key))[0]


static func _pick(list: Array, key: Array) -> String:
	return str(list[_roll(key) % list.size()])
