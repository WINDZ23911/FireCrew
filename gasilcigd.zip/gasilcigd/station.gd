class_name Station
extends Node3D




const GREEN: = Color(60 / 255.0, 200 / 255.0, 80 / 255.0)
const RED: = Color(220 / 255.0, 60 / 255.0, 50 / 255.0)
const LAMP_OFF: = Color(90 / 255.0, 20 / 255.0, 20 / 255.0)
const LAMP_ON: = Color(1.0, 40 / 255.0, 30 / 255.0)
const JOIN_QUIET: = 4.0

var record: Dictionary
var doors: Array = []
var door_position: = Vector3.ZERO
var front: = -50.0
var data: Dictionary
var leaves: Dictionary = {}
var _plan_rows: = PackedInt32Array()
var _last_call: Variant = null
var _leaf_clock: = 0.0
var _lamps: Array[int] = []
var _alarm_until: = 0.0
var _gong: AudioStreamPlayer3D
var _model: = 0
var _joined_at: = -100.0
var _bounds: = AABB()


func _ready() -> void :
	record = Game.records["station"]
	door_position = record["doorPosition"]
	front = record["front"]
	var store: = Game.store
	for id: int in store.nodes:
		if store.nodes[id]["c"] == "Model" and store.nodes[id]["n"] == "Fire Station":
			_model = id
	var bays: Array = record["bays"]
	for index in bays.size():
		doors.append({"open": false, "moving": false, "amount": 0.0, "panels": {}, "trims": [], "buttons": [], "bay": bays[index]})
	var panel_pattern: = RegEx.create_from_string("^BayDoor(\\d)_(\\d)$")

	var trim_pattern: = RegEx.create_from_string("^BayDoorTrim(\\d)_(\\d)$")
	var trims: Array = []
	var button_pattern: = RegEx.create_from_string("^BayButton(\\d)_")
	for row in store.rows_in(_model):
		var part_name: = store.name_at(row)
		var found: = panel_pattern.search(part_name)
		if found:
			var panel: = Game.world.take(store.id_at(row))
			doors[int(found.get_string(1)) - 1]["panels"][int(found.get_string(2))] = panel
			continue
		found = trim_pattern.search(part_name)
		if found:
			trims.append([int(found.get_string(1)) - 1, int(found.get_string(2)), Game.world.take(store.id_at(row), false)])
			continue
		found = button_pattern.search(part_name)
		if found:
			var bay: = int(found.get_string(1))
			var holder: = Node3D.new()
			add_child(holder)
			holder.global_position = store.position(row)
			var prompt: = Prompt.make(holder, Text.m("gear.station.doorOpen"), Text.f("gear.station.bay", [str(bay)]), 0.0, 10.0)
			prompt.triggered.connect( func(_player: Player) -> void : toggle_door(bay))
			doors[bay - 1]["buttons"].append({"id": store.id_at(row), "row": row, "prompt": prompt})
		elif part_name == "AlarmLamp":
			_lamps.append(store.id_at(row))
	for trim: Array in trims:
		var panel: PartNode = doors[trim[0]]["panels"].get(trim[1])
		if panel != null:
			var node: PartNode = trim[2]
			doors[trim[0]]["trims"].append([trim[1], node, panel.global_transform.affine_inverse() * node.global_transform])
	for index in doors.size():
		for button: Dictionary in doors[index]["buttons"]:
			_build_box(doors[index], button)
		_show_buttons(index)
	data = Rbx.load_json(Edition.path("modules/StationData.json", "res://data/modules/StationData.json"))

	_plan_rows = store.rows_under.get(_model, PackedInt32Array()).slice(0, data["parts"].size())
	_build_leaves()
	Game.incident_changed.connect(_on_incident)
	Net.started.connect( func() -> void :
		if Net.is_client():
			_joined_at = Game.now()
	)
	if OS.get_cmdline_user_args().has("--station-trace"):
		_trace.call_deferred()
	var gong_at: = Node3D.new()
	add_child(gong_at)
	gong_at.global_position = door_position + Vector3(0, 6, -20)
	_gong = Sounds.emitter(gong_at, Assets.sound(Config.Station.AlarmSoundId), float(Config.Station.AlarmVolume), 60.0, float(Config.Station.AlarmReach) * 2.0)





func _build_box(door: Dictionary, button: Dictionary) -> void :
	var store: = Game.store
	var row: int = button["row"]
	Game.world.set_hidden(button["id"], true)
	var at: = store.position(row)
	var depth: = store.size(row).z

	var out: = Vector3.BACK
	var panel: PartNode = door["panels"].values()[0] if not door["panels"].is_empty() else null
	if panel != null:
		out = panel.global_transform.basis.z.normalized()
		if (at - panel.global_position).dot(out) < 0.0:
			out = - out
	var box: = Node3D.new()
	box.name = "DoorBox"
	add_child(box)
	box.global_transform = Transform3D(Basis(Vector3.UP.cross(out), Vector3.UP, out), at - out * depth / 2.0)
	var block: = CallKit.BLOCK
	var round: = CallKit.CYLINDER
	var facing: = Basis(Vector3.UP, - PI / 2)
	CallKit.piece(box, block, Vector3(0.62, 1.0, 0.16), Transform3D(Basis(), Vector3(0, 0, 0.08)), Color(0.74, 0.75, 0.77))
	CallKit.piece(box, block, Vector3(0.66, 0.06, 0.2), Transform3D(Basis(), Vector3(0, 0.52, 0.1)), Color(0.55, 0.56, 0.58))
	CallKit.piece(box, block, Vector3(0.5, 0.86, 0.02), Transform3D(Basis(), Vector3(0, -0.02, 0.17)), Color(0.13, 0.14, 0.15))
	CallKit.piece(box, block, Vector3(0.5, 0.06, 0.022), Transform3D(Basis(), Vector3(0, 0.22, 0.17)), Color(0.95, 0.75, 0.1))
	var number: = Label3D.new()
	number.font = Ui.label_font()
	number.text = str(doors.find(door) + 1)
	number.font_size = 64
	number.pixel_size = 0.0028
	number.outline_size = 0
	number.modulate = Color(0.95, 0.95, 0.95)
	number.position = Vector3(-0.1, 0.33, 0.182)
	box.add_child(number)
	var lamp: = CallKit.piece(box, CallKit.BALL, Vector3.ONE * 0.09, Transform3D(Basis(), Vector3(0.12, 0.33, 0.18)), Color(0.35, 0.22, 0.05))
	var keys: = {}
	for key: String in ["open", "close"]:
		var y: = 0.05 if key == "open" else -0.25
		CallKit.piece(box, round, Vector3(0.04, 0.26, 0.26), Transform3D(facing, Vector3(0, y, 0.19)), Color(0.32, 0.33, 0.35))
		var cap: = CallKit.piece(box, round, Vector3(0.07, 0.2, 0.2), Transform3D(facing, Vector3(0, y, 0.235)), Color.WHITE)

		var arrow: = Label3D.new()
		arrow.font = Ui.label_font()
		arrow.text = "▲" if key == "open" else "▼"
		arrow.font_size = 32
		arrow.pixel_size = 0.0022
		arrow.outline_size = 0
		arrow.modulate = Color(0.85, 0.85, 0.85)
		arrow.position = Vector3(0.18, y, 0.182)
		box.add_child(arrow)
		keys[key] = cap
	button["lamp"] = lamp
	button["caps"] = keys


func _show_buttons(index: int) -> void :
	var door: Dictionary = doors[index]
	for button: Dictionary in door["buttons"]:
		if button.has("caps"):

			button["caps"]["open"].material_override = CallKit.plain(GREEN.darkened(0.6)) if door["open"] else CallKit.plain(GREEN, 2.5)
			button["caps"]["close"].material_override = CallKit.plain(RED, 2.5) if door["open"] else CallKit.plain(RED.darkened(0.6))
		button["prompt"].action = Text.m("gear.station.doorClose" if door["open"] else "gear.station.doorOpen")



func _press(door: Dictionary, open: bool) -> void :
	for button: Dictionary in door["buttons"]:
		if not button.has("caps"):
			continue
		var cap: MeshInstance3D = button["caps"]["open" if open else "close"]
		var rest: = cap.position
		var push: = create_tween()
		push.tween_property(cap, "position", rest - Vector3(0, 0, 0.04), 0.08)
		push.tween_property(cap, "position", rest, 0.15)



func set_door(bay: int, open: bool) -> void :
	var door: Dictionary = doors[bay - 1]
	if Net.is_client():


		door["wanted"] = open
	if door["moving"] or door["open"] == open:
		return
	door["open"] = open
	door["moving"] = true
	_show_buttons(bay - 1)
	_press(door, open)
	for panel: PartNode in door["panels"].values():
		panel.set_solid(false)
	var from: float = door["amount"]
	var to: = 1.0 if open else 0.0
	var tween: = create_tween()
	tween.tween_method( func(alpha: float) -> void :

		door["amount"] = from + (to - from) * (alpha * alpha * (3.0 - 2.0 * alpha))
		_place(door)
	, 0.0, 1.0, float(Config.Station.DoorTime))
	tween.tween_callback( func() -> void :
		door["moving"] = false
		for panel: PartNode in door["panels"].values():
			panel.set_solid( not open)
		if Net.is_client() and door.get("wanted", open) != open:
			set_door(bay, door["wanted"])
	)


func toggle_door(bay: int) -> void :
	set_door(bay, not doors[bay - 1]["open"])


func door_open(bay: int) -> bool:
	return doors[bay - 1]["open"]



func _place(door: Dictionary) -> void :
	var bay: Dictionary = door["bay"]
	var plane: = front - 0.6
	var height: float = bay["height"]
	var count: int = door["panels"].size()
	var panel_height: = height / count
	for index: int in door["panels"]:
		var panel: PartNode = door["panels"][index]
		var travelled: float = (index - 0.5) * panel_height + door["amount"] * height
		if travelled <= height:
			panel.global_transform = Transform3D(Basis.IDENTITY, Vector3(bay["x"], travelled, plane))
		else:
			panel.global_transform = Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(bay["x"], height + 0.9, plane - (travelled - height)))
	for trim: Array in door["trims"]:
		(trim[1] as PartNode).global_transform = (door["panels"][trim[0]] as PartNode).global_transform * (trim[2] as Transform3D)




func inside(at: Vector3, margin: = 0.0) -> bool:
	if _bounds.size == Vector3.ZERO and not _plan_rows.is_empty():
		_bounds = AABB(Game.store.position(_plan_rows[0]), Vector3.ZERO)
		for row in _plan_rows:
			_bounds = _bounds.expand(Game.store.position(row))
	var box: = _bounds.grow(margin)
	return box.has_point(Vector3(at.x, clampf(at.y, box.position.y, box.end.y), at.z))



func plan_part(index: int) -> int:
	return Game.store.id_at(_plan_rows[index - 1])






func _build_leaves() -> void :
	for door: Dictionary in data["doors"]:
		var part_name: = String((data["parts"][int(door["index"]) - 1] as Array)[1])
		if part_name.begins_with("ApparatusDoor") or part_name.begins_with("ApparatusAlleyDoor"):
			var id: = plan_part(int(door["index"]))
			Game.world.set_hidden(id, true)
			Game.world.set_solid(id, false)
			continue
		var hinge: = Rbx.v3(door["hinge"])
		var key: = "%.1f %.1f %.1f %d" % [hinge.x, hinge.y, hinge.z, int(door["swing"])]
		if not leaves.has(key):
			var pivot: = Node3D.new()
			add_child(pivot)
			pivot.global_position = hinge
			leaves[key] = {"hinge": hinge, "swing": float(door["swing"]), "pivot": pivot, "open": false}
		var part: = Game.world.take(plan_part(int(door["index"])))
		if part:
			part.reparent(leaves[key]["pivot"])


func _swing_leaves() -> void :
	for key: String in leaves:
		var leaf: Dictionary = leaves[key]
		var near: = false
		for player in Game.players:
			if player.root_position().distance_to(leaf["hinge"]) < 9.0:
				near = true
				break
		if near != leaf["open"]:
			leaf["open"] = near
			var pivot: Node3D = leaf["pivot"]
			var tween: = pivot.create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
			tween.tween_property(pivot, "rotation:y", deg_to_rad(leaf["swing"]) if near else 0.0, 0.5)



func _on_incident() -> void :
	var incident: = Game.incident
	var call_name: Variant = incident.get("name")
	if call_name == null:
		_last_call = null
		_show_boards(Text.m("gear.station.noCall"), Color(120 / 255.0, 220 / 255.0, 130 / 255.0))
		return
	if _last_call != null and Text.say(_last_call, "sl") == Text.say(call_name, "sl"):
		return
	_last_call = call_name
	_show_boards(Text.f("gear.station.call", [Text.upper(call_name)]), Color(1.0, 90 / 255.0, 70 / 255.0))
	if Net.is_host():

		set_door(int(Config.Station.PumperBay), true)

		if Game.players.size() >= int(Config.Station.TankerCrew):
			set_door(int(Config.Station.TankerBay), true)

		if incident.get("kind") == "rescue":
			set_door(int(Config.Station.LadderBay), true)
	elif Game.now() - _joined_at < JOIN_QUIET:
		return
	sound_alarm()
	_speak(incident.get("kind", "fire"), call_name)



func _show_boards(text: Variant, color: Color) -> void :
	for row in Game.store.rows_in(_model):
		if Game.store.name_at(row) == "IncidentBoard":
			var id: = Game.store.id_at(row)
			Dressing.set_text(id, text)
			Dressing.set_text_color(id, color)



func _speak(kind: String, call_name: Variant = null) -> void :
	var voice: Dictionary = Config.Voice
	var line: Variant = voice["Lines"].get(kind)
	var spoken: Variant = voice["Spoken"].get(Text.language)
	if spoken is Dictionary and spoken.has(kind):
		line = spoken[kind]

	if line == null or float(voice.get("Volume", 1.0)) <= 0.0:
		return
	await get_tree().create_timer(float(voice["Delay"])).timeout
	Soundtrack.under(Sounds.flat(line, float(voice["Volume"])))


	if float(voice.get("Volume", 1.0)) > 0.0:
		HudCaptions.say(Text.m("ui.captions.dispatcher"), Text.f("ui.captions.callOut", [{"p": [Text.m("hud.dispatch.kinds.%s.tag" % kind)], "w": "lower"}, call_name if call_name != null else ""]))



func sound_alarm() -> void :
	_alarm_until = Game.now() + float(Config.Station.AlarmLampTime)
	if _gong.stream:
		_gong.play()


func _process(delta: float) -> void :
	_leaf_clock += delta
	for door: Dictionary in doors:
		var blink: bool = door["moving"] and fmod(Game.now(), 0.5) < 0.25
		for button: Dictionary in door["buttons"]:
			if button.has("lamp") and blink != button.get("blink", false):
				button["blink"] = blink
				(button["lamp"] as MeshInstance3D).material_override = CallKit.plain(Color(1.0, 0.62, 0.1), 4.0) if blink else CallKit.plain(Color(0.35, 0.22, 0.05))
	if _leaf_clock > 0.25:
		_leaf_clock = 0.0
		_swing_leaves()
	if _lamps.is_empty():
		return
	var now: = Game.now()
	var lit: = now < _alarm_until and fmod(now, 0.8) < 0.4
	if lit != has_meta("lit"):
		if lit:
			set_meta("lit", true)
		else:
			remove_meta("lit")
		for id in _lamps:
			Game.world.set_color(id, LAMP_ON if lit else LAMP_OFF)







func _trace() -> void :
	var at: = -1
	var board: = 0
	for row in Game.store.rows_in(_model):
		if Game.store.name_at(row) == "IncidentBoard":
			board = Game.store.id_at(row)
	for vehicle in Vehicle.all:
		print("station: %s stands at %s" % [vehicle.name, vehicle.global_position])
	print("station: door leaves hinged at %s" % [leaves.keys().slice(0, 4)])
	while true:
		await get_tree().create_timer(0.1).timeout
		if (Net.is_client() and not HostClock.synced) or floori(HostClock.now() / 2.0) == at:
			continue
		at = floori(HostClock.now() / 2.0)
		var open: Array = []
		for door: Dictionary in doors:
			open.append("%s%.1f" % ["open " if door["open"] else "shut ", door["amount"]])
		var swung: Array = []
		for key: String in leaves:
			if leaves[key]["open"]:
				swung.append(key)
		var label: = Dressing.label_on(board) if Dressing.current != null else null
		print("station %d s: doors %s | alarm %s gong %s | board '%s' | leaves open %s" % [
			at * 2, open, Game.now() < _alarm_until, _gong.playing, label.text.replace("\n", " / ") if label != null else "?", swung, 
		])
