class_name VehicleRoles
extends Node









static var current: VehicleRoles

var sized_up: = false
var _for: = -1.0
var _command_first: = false
var _sizing: = 0.0
var _ladder_said: = ""
var _ladder_said_at: = -100.0
var _clock: = 0.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_clock += delta
	if _clock < 0.25:
		return
	var dt: = _clock
	_clock = 0.0
	var incident: = Game.incident
	if not Alarm.active or not incident.has("pos"):
		return
	if _for != Alarm.started_at:
		_for = Alarm.started_at
		sized_up = false
		_command_first = false
		_sizing = 0.0
		_ladder_said = ""
		_dispatch(incident)
	_watch_arrivals(incident, dt)
	_ladder_hint(incident)



func _dispatch(incident: Dictionary) -> void :
	var settings: Dictionary = Config.Roles
	var at: Vector3 = incident["pos"]
	var hydrant: = nearest_hydrant(at)
	if hydrant >= float(settings["HydrantFar"]):
		Game.notify(Text.f("world.roles.tanker", [metres(hydrant)]), "warning")
		_open_bay(int(Config.Station.TankerBay))
	var building: = _building()
	var fire: = FireService.current
	if building != null and fire.incident.get("ladder", false):

		Game.notify(Text.f("world.roles.ladderHigh", [metres(float(fire.incident.get("ladder_height", building.height)))]), "warning")
		_open_bay(int(Config.Station.LadderBay))
	elif building != null and building.height >= float(settings["TallHeight"]):
		Game.notify(Text.f("world.roles.ladder", [metres(building.height)]), "warning")
		_open_bay(int(Config.Station.LadderBay))


func _open_bay(bay: int) -> void :
	if Game.station != null and not Game.station.door_open(bay):
		Game.station.set_door(bay, true)



static func metres(studs: float) -> int:
	return Ui.length(studs * float(Config.Hud.MetresPerStud))



static func nearest_hydrant(at: Vector3) -> float:
	var best: = INF
	for hydrant in HudRadar.hydrants():
		best = minf(best, Vector2(hydrant.x - at.x, hydrant.z - at.z).length())
	return best



func _building() -> Building:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return null
	return fire.incident["group"]["building"]



func _watch_arrivals(incident: Dictionary, dt: float) -> void :
	if sized_up:
		return
	var settings: Dictionary = Config.Roles
	var at: Vector3 = incident["pos"]
	var reach: = float(Config.Fire.ArriveRange)
	var command: = Vehicle.named("Command Vehicle")
	if command == null:
		return
	if not _command_first:
		for vehicle in Vehicle.all:
			if vehicle.global_position.distance_to(at) <= reach:
				if vehicle != command:
					sized_up = true
					return
				_command_first = true
	if not _command_first:
		return

	var walking: = false
	for player in Game.players:
		if is_instance_valid(player) and player.brain == null and player.seat == null and player.root_position().distance_to(at) <= float(settings["SizeUpReach"]):
			walking = true
	if walking:
		_sizing += dt
	if _sizing >= float(settings["SizeUpTime"]):
		sized_up = true
		Game.notify(_size_up_words(incident), "")
		Alarm.check("sizeUp", true)



func _size_up_words(incident: Dictionary) -> Dictionary:
	var inside: = int(incident.get("victims", 0)) - int(incident.get("victims_out", 0)) - int(incident.get("victims_fetched", 0)) - int(incident.get("victims_lost", 0))
	var hazard: = Text.m("world.roles.hazards.none")
	var fire: = FireService.current
	if fire != null and not fire.incident.is_empty():
		var trait_name: = String(fire.incident.get("trait", ""))
		if Text.has("world.roles.hazards." + trait_name):
			hazard = Text.m("world.roles.hazards." + trait_name)
	var people: = Text.f("world.roles.people", [maxi(inside, 0)]) if inside > 0 else Text.m("world.roles.nobody")
	return Text.f("world.roles.sizeUp", [people, hazard, metres(nearest_hydrant(incident["pos"]))])




func _ladder_hint(_incident: Dictionary) -> void :
	var settings: Dictionary = Config.Roles
	var ladder: = Vehicle.named("Ladder Truck")
	var building: = _building()
	if ladder == null or building == null:
		return
	var driver: = ladder.driver()
	if driver == null or driver.brain != null or absf(ladder.forward_speed) > float(settings["LadderHintSpeed"]):
		return
	var gap: = INF
	var at: = ladder.global_position
	for node: Dictionary in building.fuel:
		var spot: Vector3 = node["position"]
		gap = minf(gap, Vector2(spot.x - at.x, spot.z - at.z).length())
	if gap > float(settings["LadderHintRange"]):
		return
	var outreach: = LadderService.current.max_outreach() if LadderService.current else LadderService.MAX_OUTREACH
	var said: = "good"
	if gap < float(settings["LadderClose"]):
		said = "close"
	elif gap > outreach * float(settings["LadderShare"]):
		said = "far"
	if said == _ladder_said or Game.now() - _ladder_said_at < float(settings["LadderHintGap"]):
		return
	_ladder_said = said
	_ladder_said_at = Game.now()
	Game.notify(Text.f("world.roles.ladderSpot.%s" % said, [metres(gap)]), "good" if said == "good" else "warning", driver)
