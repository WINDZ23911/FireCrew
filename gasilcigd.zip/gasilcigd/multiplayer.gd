extends ProofDebug








func _scenario_multiplayer() -> void :
	await _wait(1.5)
	var title: TitleScreen = null
	for node: Node in get_tree().root.find_children("*", "CanvasLayer", true, false):
		if node is TitleScreen:
			title = node
	if title == null:
		title = TitleScreen.new()
		get_tree().current_scene.add_child(title)
		await _wait(1.0)
	_check(title._play.text == TitleScreen.word("play") and title._crew_item.text == TitleScreen.word("crew_menu"), "the column reads %s and %s" % [title._play.text, title._crew_item.text])
	await _snap("title")
	title._open("crew")
	await _wait(3.0)
	print("multiplayer: %d servers on the list: %s" % [title._crews.size(), ", ".join(title._crews.map( func(c: Dictionary) -> String: return c["name"]))])
	_check( not title._crews.is_empty() and title._rows.get_child_count() == title._crews.size(), "the server list shows the crews the list has")
	_check( not title._password.visible, "no server picked: no password field")
	await _snap("list")
	var locked: Array = title._crews.filter( func(c: Dictionary) -> bool: return c.get("locked", false))
	var open: Array = title._crews.filter( func(c: Dictionary) -> bool: return not c.get("locked", false))
	if not locked.is_empty():
		title._chosen = str(locked[0]["id"])
		title._show_rows()
		await _wait(0.3)
		_check(title._password.visible and not title._join.disabled, "a server with a password: the field shows")
		title._join_crew()
		_check(title._status.text == TitleScreen.word("need_password"), "JOIN with no password typed asks for it")
		await _snap("locked")
	if not open.is_empty():
		title._chosen = str(open[0]["id"])
		title._show_rows()
		await _wait(0.3)
		_check( not title._password.visible, "an open server: no password field")
	title._show_create(true)
	await _wait(0.5)
	_check(title._create.visible and not title._browse.visible and not title._server_name.text.is_empty(), "CREATE SERVER opens its form, named '%s'" % title._server_name.text)
	await _snap("create")
	var proof: = Net.password_proof("abc", "ember")
	_check(proof == Net.password_proof("abc", "ember") and proof != Net.password_proof("abc", "embers") and proof != Net.password_proof("abd", "ember"), "the password proof matches only the same password and question")
	_done()
