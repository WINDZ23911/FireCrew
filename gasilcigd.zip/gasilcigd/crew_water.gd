class_name CrewWater
extends RefCounted





static func finders() -> Array[Callable]:
	var list: Array[Callable] = [_find_fire, _find_hydrant, _find_control, _find_window, _find_hatch]
	return list







static func targets() -> Array:
	var found: Array = []
	var fire: = FireService.current
	if fire == null:
		return found
	if not fire.incident.is_empty():

		var outside_only: = Escalation.evacuating()
		var building: Building = fire.incident["group"]["building"]
		for node: Dictionary in fire.incident["group"]["nodes"]:
			if outside_only and node["room"] != null and not building.rooms.get(node["room"], {}).get("open", false):
				continue
			if node["burning"]:
				found.append({"position": node["position"], "room": node["room"], "node": node, "ember": false})
	for spot: Dictionary in fire.spots:
		if spot["burning"]:
			found.append({"position": spot["position"], "room": null, "node": spot, "ember": false})
	if found.is_empty() and not fire.incident.is_empty():
		for ember: Dictionary in fire.incident.get("embers", []):
			found.append({"position": ember["position"], "room": ember["node"]["room"], "node": ember, "ember": true})
	return found



static func still_on(target: Dictionary) -> bool:
	var node: Dictionary = target["node"]
	if target["ember"]:
		var fire: = FireService.current
		return fire != null and not fire.incident.is_empty() and fire.incident.get("embers", []).has(node)
	return node["burning"]



static func nearest_target(from: Vector3, taken: Array = []) -> Dictionary:
	var best: Dictionary = {}
	var best_score: = INF
	for target: Dictionary in targets():
		var score: float = target["position"].distance_to(from) - float(target["node"].get("intensity", 0.5)) * 10.0
		for other: Variant in taken:
			if other is Dictionary and is_same(other, target["node"]):
				score += 60.0
		if score < best_score:
			best_score = score
			best = target
	return best




static func spot_for(mind: Crewman, at: Vector3, from: Vector3, tried: Array = []) -> Vector3:
	var nav: = CrewNav.current
	var best: = Vector3.INF
	var best_score: = INF
	for distance: float in [8.0, 11.0, 15.0, 20.0, 26.0]:
		for step in 16:
			var angle: = TAU * step / 16.0
			var guess: = at + Vector3(cos(angle), 0, sin(angle)) * distance
			var stand: = nav.closest(guess) if nav else guess
			if Vector3(stand.x - guess.x, 0, stand.z - guess.z).length() > 2.0 or absf(stand.y - at.y) > 9.0:
				continue
			if not _clear_shot(stand + Vector3(0, 4, 0), at):
				continue
			var near_tried: = false
			for other: Variant in tried:
				near_tried = near_tried or (other is Vector3 and other.distance_to(stand) < 5.0)
			if near_tried:
				continue
			var smoke: = FireService.current.smoke_at(stand + Vector3(0, 3, 0)) if FireService.current else 0.0

			if smoke > 0.12 and not (AirService.current and AirService.current.sets.has(mind.body)):
				continue
			var score: = absf(distance - 13.0) + stand.distance_to(from) / 12.0 + smoke * 25.0
			if score < best_score:
				best_score = score
				best = stand
	return best





static func _clear_shot(from: Vector3, to: Vector3) -> bool:
	var fire: = FireService.current
	if fire != null and not fire.incident.is_empty():
		var building: Building = fire.incident["group"]["building"]
		var inside: Variant = building.room_at(to)
		var here: Variant = building.room_at(from)
		if inside != null and (here == null or here["name"] != inside["name"]):
			return not building.blocks(from, to, float(Config.Fire.Sight.Slack), true)
	var exclude: Array[RID] = []
	for attempt in 3:
		var hit: = Game.world.raycast(from, to, World.LAYER_SOLID | World.LAYER_QUERY, exclude)
		if hit.is_empty() or hit["position"].distance_to(to) < 1.6:
			return true
		if not _is_pane(hit):
			return false
		exclude.append(hit["rid"])
	return false


static func _is_pane(hit: Dictionary) -> bool:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return false
	var collider: Variant = hit.get("collider")
	var building: Building = fire.incident["group"]["building"]
	for room_name: String in building.rooms:
		for pane: Dictionary in building.rooms[room_name]["panes"]:
			if pane["broken"]:
				continue
			if collider != null and is_same(collider, pane["node"]):
				return true
			if hit["position"].distance_to(pane["position"]) < maxf(pane["size"].x, maxf(pane["size"].y, pane["size"].z)) * 0.6:
				return true
	return false








static func set_line(mind: Crewman, _prefer: Variant = null) -> Array:
	var air: = AirService.current
	if air == null:
		return []
	var worn: Variant = air.sets.get(mind.body)
	var source: String = worn["source"] if worn != null else "truck"
	var vehicle: = air.source_vehicle(source)
	var line: = air.line_for(mind.body, source)
	if vehicle == null or line == null:
		return []
	return [vehicle, line]




static func wear_set(mind: Crewman) -> bool:
	var air: = AirService.current
	if air == null:
		return false

	if air.sets.has(mind.body) and float(air.sets[mind.body]["bar"]) <= float(Config.Air.Capacity) * float(Config.Crew.SetSwapAt):
		air._return_set(mind.body)
	if air.sets.has(mind.body):
		return true
	var found: = set_line(mind, mind.service.home_vehicle(mind.commander()))
	if found.is_empty():
		return false
	if not await CrewKit.from_locker(mind, found[0], found[1]):
		return false
	return air.sets.has(mind.body)



static func breathe(mind: Crewman) -> bool:
	var air: = AirService.current
	if air == null or not air.sets.has(mind.body):
		return true
	var worn: Dictionary = air.sets[mind.body]
	var smoke: = FireService.current.smoke_at(mind.body.root_position()) if FireService.current else 0.0
	if smoke > 0.05 and not worn["mask"] and not worn["moving"]:
		air.move_mask(mind.body)
	elif smoke <= 0.0 and worn["mask"] and not worn["moving"] and float(worn["bar"]) > float(Config.Air.Capacity) * 0.5:
		pass
	return float(worn["bar"]) > float(Config.Air.Capacity) * 0.22



static func return_set(mind: Crewman) -> void :
	var air: = AirService.current
	if air != null and air.sets.has(mind.body):
		air._return_set(mind.body)






static func hydrant_for(vehicle: Vehicle) -> Dictionary:
	var hoses: = HoseService.current
	var best: Dictionary = {}
	var best_distance: = float(Config.Hose.SupplyLength) - 12.0
	if vehicle.intake.is_empty():
		return best
	var intake: Vector3 = vehicle.intake["node"].global_position
	for hydrant: Dictionary in hoses.hydrants:
		if hydrant["rig"] != null or hydrant.has("pump"):
			continue
		var distance: float = intake.distance_to(hydrant["position"])
		if distance < best_distance:
			best_distance = distance
			best = hydrant
	return best


static func rig_of(vehicle: Vehicle) -> Dictionary:
	for rig: Dictionary in HoseService.current.rigs:
		if rig["vehicle"] == vehicle:
			return rig
	return {}





static func _find_fire(view: Dictionary) -> Dictionary:
	var point: Vector3 = view["point"]
	var best: Dictionary = {}
	var best_distance: = 9.0
	for target: Dictionary in targets():
		var distance: float = target["position"].distance_to(point)
		var off: = CrewTargets.off_sight(view, target["position"])
		distance = minf(distance, off * 1.5)
		if distance < best_distance:
			best_distance = distance
			best = target
	if best.is_empty():
		return {}
	var target: = best
	var options: Array = [
		CrewTargets.order(Text.m("crew.orders.attack"), "nozzle", func() -> CrewJob: return JobAttack.new(target)), 
		CrewTargets.order(Text.m("crew.orders.attackAll"), "flame", func() -> CrewJob: return JobAttack.new()), 
	]
	var truck: Variant = CrewService.current.home_vehicle(view["lead"])
	if truck is Vehicle and not rig_of(truck).is_empty() and rig_of(truck)["supply"]["state"] == "stowed":
		options.append(CrewTargets.order(Text.m("crew.orders.supply"), "hydrant", func() -> CrewJob: return JobSupply.new(truck)))
	return {
		"kind": "fire", "position": target["position"] + Vector3(0, 3, 0), "score": best_distance - 6.0, 
		"label": Text.m("crew.targets.ember" if target["ember"] else "crew.targets.fire"), "options": options, 
	}


static func _find_hydrant(view: Dictionary) -> Dictionary:
	if HoseService.current == null:
		return {}
	var point: Vector3 = view["point"]
	var best: Dictionary = {}
	var best_distance: = 5.0
	for hydrant: Dictionary in HoseService.current.hydrants:
		if hydrant.has("pump"):
			continue
		var distance: float = hydrant["position"].distance_to(point)
		if distance < best_distance:
			best_distance = distance
			best = hydrant
	if best.is_empty():
		return {}
	var hydrant: = best
	var truck: Variant = CrewService.current.home_vehicle(view["lead"])
	if not truck is Vehicle or rig_of(truck).is_empty():
		return {}
	var vehicle: Vehicle = truck
	return {
		"kind": "hydrant", "position": hydrant["position"] + Vector3(0, 4, 0), "score": best_distance - 3.0, 
		"label": Text.m("crew.targets.hydrant"), 
		"options": [CrewTargets.order(Text.m("crew.orders.supply"), "hydrant", func() -> CrewJob: return JobSupply.new(vehicle, hydrant))], 
	}



static func _find_control(view: Dictionary) -> Dictionary:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty() or not is_instance_valid(fire.incident.get("control")):
		return {}
	var control: Node3D = fire.incident["control"]
	var prompt: Prompt = control.get_meta("prompt")
	if not prompt.enabled or control.global_position.distance_to(view["point"]) > 5.0:
		return {}
	var gas: = fire.incident.get("fed") != null
	return {
		"kind": "control", "position": control.global_position + Vector3(0, 3, 0), "score": 0.0, 
		"label": Text.m("crew.targets.valve" if gas else "crew.targets.switch"), 
		"options": [CrewTargets.order(Text.m("crew.orders.valve" if gas else "crew.orders.switch"), "warning", func() -> CrewJob: return JobPress.new("valve" if gas else "switch", prompt, "rescue"))], 
	}



static func _find_window(view: Dictionary) -> Dictionary:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return {}
	var building: Building = fire.incident["group"]["building"]
	var point: Vector3 = view["point"]
	var best: Dictionary = {}
	var best_distance: = 3.0
	for room_name: String in building.rooms:
		for pane: Dictionary in building.rooms[room_name]["panes"]:
			if pane["broken"]:
				continue
			var distance: float = pane["position"].distance_to(point)
			if distance < best_distance:
				best_distance = distance
				best = pane
	if best.is_empty():
		return {}
	var pane: = best
	return {
		"kind": "window", "position": pane["position"] + Vector3(0, 2, 0), "score": best_distance - 2.0, 
		"label": Text.m("crew.targets.window"), 
		"options": [CrewTargets.order(Text.m("crew.orders.window"), "axe", func() -> CrewJob: return JobBreakWindow.new(pane))], 
	}



static func _find_hatch(view: Dictionary) -> Dictionary:
	var cellar: = FloodedCellar.current
	if cellar == null or cellar.source.is_empty():
		return {}
	var at: Vector3 = cellar.source["position"]
	if at.distance_to(view["point"]) > 8.0:
		return {}
	return {
		"kind": "hatch", "position": at + Vector3(0, 4, 0), "score": 1.0, "label": Text.m("crew.targets.hatch"), 
		"options": [CrewTargets.order(Text.m("crew.orders.pump"), "pump", func() -> CrewJob: return JobCellar.new())], 
	}
