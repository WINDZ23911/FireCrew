class_name Medic
extends Node3D







const KIT: = "res://assets/models/medic_kit.glb"
const HEAD_HEIGHT: = 4.86
const GLOVES: = Color8(70, 130, 200)

const JOINTS: = {
	"Hips": Vector3(0, -2.47, 0), 
	"Waist": Vector3(0, -2.25, 0), 
	"Neck": Vector3(0, -0.62, 0), 
	"ShoulderL": Vector3(-1.47, -0.82, 0), "ShoulderR": Vector3(1.47, -0.82, 0), 
	"ElbowL": Vector3(-1.47, -1.56, 0), "ElbowR": Vector3(1.47, -1.56, 0), 
	"WristL": Vector3(-1.47, -2.24, 0), "WristR": Vector3(1.47, -2.24, 0), 
	"HipL": Vector3(-0.5, -2.66, 0), "HipR": Vector3(0.5, -2.66, 0), 
	"KneeL": Vector3(-0.5, -3.58, 0), "KneeR": Vector3(0.5, -3.58, 0), 
	"AnkleL": Vector3(-0.5, -4.5, 0), "AnkleR": Vector3(0.5, -4.5, 0), 
}

const TREE: = {
	"Hips": "", "Waist": "Hips", "Neck": "Waist", 
	"ShoulderL": "Waist", "ElbowL": "ShoulderL", "WristL": "ElbowL", 
	"ShoulderR": "Waist", "ElbowR": "ShoulderR", "WristR": "ElbowR", 
	"HipL": "Hips", "KneeL": "HipL", "AnkleL": "KneeL", 
	"HipR": "Hips", "KneeR": "HipR", "AnkleR": "KneeR", 
}

const CARRIED_BY: = {
	"Head": "Neck", "UpperTorso": "Waist", "LowerTorso": "Hips", 
	"LeftUpperArm": "ShoulderL", "LeftLowerArm": "ElbowL", "LeftHand": "WristL", 
	"RightUpperArm": "ShoulderR", "RightLowerArm": "ElbowR", "RightHand": "WristR", 
	"LeftUpperLeg": "HipL", "LeftLowerLeg": "KneeL", "LeftFoot": "AnkleL", 
	"RightUpperLeg": "HipR", "RightLowerLeg": "KneeR", "RightFoot": "AnkleR", 
}
const SKIN: Array[Color] = [Color8(241, 194, 160), Color8(224, 172, 135), Color8(198, 140, 100), Color8(255, 219, 188)]

static var _kit: PackedScene

var joints: Dictionary = {}
var speed: = 0.0
var side: = 0
var _phase: = 0.0


func _init(skin: Color) -> void :
	name = "Medic"
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	if _kit == null:
		_kit = load(KIT)
	var places: Dictionary = JOINTS
	var tree: Dictionary = TREE
	for joint_name: String in places:
		var joint: = Node3D.new()
		joint.name = joint_name
		joints[joint_name] = joint
	for joint_name: String in places:
		var joint: Node3D = joints[joint_name]
		var parent_name: String = tree[joint_name]
		if parent_name.is_empty():
			add_child(joint)
			joint.position = places[joint_name] + Vector3(0, HEAD_HEIGHT, 0)
		else:
			joints[parent_name].add_child(joint)
			joint.position = places[joint_name] - places[parent_name]
	var source: = _kit.instantiate()
	for child in source.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() != 2 or not CARRIED_BY.has(bits[0]):
			continue
		var joint_name: String = CARRIED_BY[bits[0]]
		var at: = mesh.position
		mesh.owner = null
		source.remove_child(mesh)
		joints[joint_name].add_child(mesh)
		mesh.position = at - places[joint_name]
	source.free()



	var neck: Node3D = joints["Neck"]
	var up: Vector3 = - places["Neck"]
	_piece(neck, "Head", Figure.HEAD, Vector3.ONE, up, Figure.material(skin, true))
	var hair: Color = Figure.HAIR[int(skin.r8 + skin.g8) % 3]
	_piece(neck, "Hair", Figure.DOME, Vector3(1.34, 0.78, 1.34), up + Vector3(0, 0.42, 0.04), Figure.material(hair))
	for wrist: String in ["WristL", "WristR"]:
		_piece(joints[wrist], "Hand", Figure.BOX, Vector3(0.9, 0.36, 0.9), Vector3(0, -0.16, 0), Figure.material(GLOVES))


func _piece(parent: Node3D, piece_name: String, shape: int, size: Vector3, at: Vector3, material: Material) -> void :
	var mesh: = MeshInstance3D.new()
	mesh.name = piece_name
	mesh.mesh = Figure.mesh_of(shape)
	mesh.material_override = material
	mesh.position = at
	mesh.scale = size
	parent.add_child(mesh)



func stand(ground: Transform3D) -> void :
	global_transform = ground


func _process(delta: float) -> void :
	_phase += speed * delta * 0.42
	var stride: = clampf(speed / 14.0, 0.0, 1.0)
	var swing: = sin(_phase)
	var ease: = 1.0 - exp( - delta * 14.0)
	var wanted: = {
		"HipL": swing * 0.6 * stride, "HipR": - swing * 0.6 * stride, 
		"KneeL": - maxf(0.0, - cos(_phase)) * 0.8 * stride, "KneeR": - maxf(0.0, cos(_phase)) * 0.8 * stride, 
		"ShoulderL": - swing * 0.5 * stride, "ShoulderR": swing * 0.5 * stride, 
		"ElbowL": 0.12 + 0.3 * stride, "ElbowR": 0.12 + 0.3 * stride, 
	}
	for joint_name: String in wanted:
		var joint: Node3D = joints[joint_name]
		joint.rotation.x = lerpf(joint.rotation.x, wanted[joint_name], ease)
