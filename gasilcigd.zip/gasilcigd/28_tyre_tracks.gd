extends RefCounted



static func start(main: Node) -> void :
	var tracks: = TyreTracks.new()
	tracks.name = "TyreTracks"
	main.add_child(tracks)
