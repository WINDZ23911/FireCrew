extends RefCounted






static func apply(kit: PolishKit) -> String:
	return RoadsOut.build(kit)
