extends ProofDebug












func _cash() -> int:
	return int(player.get_attr("Cash", 0)) + int(player.get_attr("Pending", 0))



func _next_report(had: int, limit: float) -> Dictionary:
	var waited: = 0.0
	while CallLog.recent().size() <= had and waited < limit:
		await _wait(0.25)
		waited += 0.25
	return CallLog.last() if CallLog.recent().size() > had else {}


static func _part(report: Dictionary, id: String) -> Array:
	for part: Array in report.get("parts", []):
		if part[0] == id:
			return part
	return []


static func _named(report: Dictionary) -> Dictionary:
	var found: = {}
	for entry: Array in report.get("checks", []):
		found[entry[0]] = entry[1]
	return found


func _scenario_grading() -> void :
	await _wait(1.0)
	Alarm.forced = 1


	_check(Alarm.multiplier("S") == 1.5 and Alarm.multiplier("A") == 1.25 and Alarm.multiplier("B") == 1.0 and Alarm.multiplier("C") == 0.75, "the grade multiplies the call's pay: S ×1.5, A ×1.25, B ×1, C ×0.75")
	_check(Alarm.points("S") == 3 and Alarm.points("A") == 2 and Alarm.points("B") == 1 and Alarm.points("C", true) == 0, "rank points by grade: S 3, A 2, B 1, failed 0")
	var old_thresholds: = [0, 5, 15, 30, 60, 100, 200]
	var kept: = true
	for index in old_thresholds.size():
		kept = kept and Alarm.rank_of(PlayerData.rank_points({"saved": old_thresholds[index]})) == index
		kept = kept and (index == 0 or Alarm.rank_of(PlayerData.rank_points({"saved": int(old_thresholds[index]) - 1})) == index - 1)
	_check(kept, "an old save's calls become points and keep exactly the rank they had")
	_check(PlayerData.rank_points({"saved": 99, "points": 7}) == 7, "a new save's points are read as they are")


	Alarm.begin()
	Alarm.arrived_at = Alarm.started_at + 60.0
	Alarm.par(100.0)
	Alarm.job_done_at = Alarm.arrived_at + 70.0
	Alarm.check("cones", false)
	Alarm.check("battery", true)
	var made: = Alarm.debrief("crash", {"failed": false})
	Alarm.end()
	print("grading: made up: parts %s, weakest %s, tip %s, grade %s" % [made["parts"], made["weakest"], Text.say(made["tip"], "en"), made["grade"]])
	_check(_part(made, "job").size() == 3 and float(_part(made, "job")[1]) == 1.0, "the job within its par scores full")
	_check(_part(made, "procedure").size() == 3 and is_equal_approx(float(_part(made, "procedure")[1]), 0.5), "one named check of two passed is half the procedure part")
	_check(made["weakest"] == "procedure" and Text.say(made["tip"], "en") == Text.say(Text.m("report.checks.cones.tip"), "en"), "the weakest part is the procedure, and its tip is the failed check's")
	_check(Alarm.against_par(-1.0, 60.0) == 0.0 and Alarm.against_par(120.0, 60.0) == 0.0 and Alarm.against_par(48.0, 60.0) == 1.0, "a time against par: full at 80 %, nothing at twice par or never")


	var fire: = FireService.current
	var house: = _house("Family house")
	VictimService.current.forced = 1
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Alarm["EmberChance"] = [0.0, 0.0, 0.0]
	Config.Fire["Traits"]["Force"] = "none"
	var told: Array[String] = []
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))
	var lives_before: = int(player.get_attr("Lives", 0))
	var points_before: = int(player.get_attr("Saved", 0))
	var had: = CallLog.recent().size()
	CallService.current.run_call("fire", func() -> Variant:
		await fire.run_incident(house)
		return true
	)
	await _wait(1.0)
	var door: Dictionary = house.outside_door()
	_stand_outside(house, door["lock"].global_position, 16.0)
	var waited: = 0.0
	while Alarm.job_par < 0.0 and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	var par: Dictionary = Alarm.settings()["Grade"]["Job"]["fire"]
	var at_arrival: = int(fire.incident.get("arrival_count", 0))
	print("grading: fire at %s, %d flames as the crew came, par %.0f s" % [house.name, at_arrival, Alarm.job_par])
	_check(at_arrival >= 1 and is_equal_approx(Alarm.job_par, float(par["Base"]) + float(par["PerFlame"]) * at_arrival), "the fire's par is from the flames burning as the crew came")


	var node: Dictionary = {}
	for candidate: Dictionary in fire.incident["group"]["nodes"]:
		if candidate["burning"]:
			node = candidate
			break
	fire.incident["contributors"][player] = true
	var before: = _cash()
	fire._extinguish(node, player)
	var first: = _cash() - before
	fire._ignite(node, 0.3)
	before = _cash()
	fire._extinguish(node, player)
	var again: = _cash() - before
	print("grading: a flame out paid %d, the same flame relit and out again paid %d" % [first, again])
	_check(first == Alarm.pay(int(Config.Rewards.PerNode)) and again == 0, "a flame pays the first time it goes out; a relight pays nothing")


	var victims: Array = VictimService.current.victims.duplicate()
	for victim: Victim in victims:
		VictimService.current._hand_over(victim, player)
	waited = 0.0
	while not fire.incident.is_empty() and waited < 30.0:
		fire.incident["contributors"][player] = true
		for each: Dictionary in fire.incident["group"]["nodes"]:
			each["heat"] = 0.0
			if each["burning"]:
				fire._extinguish(each, player)
		await _wait(0.2)
		waited += 0.2
	var report: = await _next_report(had, 30.0)
	if not _check( not report.is_empty(), "the fire came down and was graded"):
		await _done()
		return
	var mine: = CallLog.mine(report)
	print("grading: report: grade %s (%.2f), parts %s, checks %s, stars %d, pay %s" % [report["grade"], float(report["score"]), report["parts"], report["checks"], int(report["stars"]), mine])
	var checks: = _named(report)
	_check(Alarm.job_done_at >= 0.0 and _part(report, "job").size() == 3 and float(report["job"][0]) >= 0.0, "the job's time runs from arrival to the knockdown")
	_check(checks.has("origin") and checks.has("mask") and checks.has("hydrant"), "a house fire's named checks: room of origin, masks in smoke, a hydrant (%s)" % [checks])
	_check(checks.get("hydrant") == false, "no hydrant was used: that check failed")
	_check(_part(report, "building").size() == 3 and int(report["stars"]) >= 1 and int(report["stars"]) <= 3, "the stars are in the building line (%d)" % int(report["stars"]))
	var star_lines: = told.filter( func(line: String) -> bool: return line.begins_with("★"))
	_check(star_lines.is_empty(), "no star message of their own")
	var items: Dictionary = mine.get("items", {})
	_check(int(items.get("containment", 0)) > 0, "holding the fire paid (%d)" % int(items.get("containment", 0)))
	_check(int(items.get("bonus", 0)) > 0, "the save bonus with the stars' share is one reward (%d)" % int(items.get("bonus", 0)))
	var multiplied: = int(round(int(mine.get("earned", 0)) * (float(report["multiplier"]) - 1.0)))
	_check( not mine.is_empty() and int(mine["grade_pay"]) == multiplied, "the grade's share is the call's own pay times (multiplier - 1): %d" % multiplied)
	_check(int(mine.get("flames", 0)) >= 2, "the report counts the flames knocked down (%d)" % int(mine.get("flames", 0)))
	_check(int(mine.get("carried", 0)) == victims.size() and int(player.get_attr("Lives", 0)) == lives_before + victims.size(), "the person handed over is a life saved, kept for good (%d)" % victims.size())
	_check(int(player.get_attr("Saved", 0)) == points_before + Alarm.points(report["grade"], report["failed"]), "rank points by the grade (%d)" % int(report["points"]))
	_check(report["crew"].size() == 1, "one human on the scene, one line")


	_view_player()
	HudDebrief.current.open(report)
	await _wait(5.0)
	var shown: = HudDebrief.current.shown_text()
	print("grading: the end screen: %s" % shown.replace("\n", " / "))
	_check(HudDebrief.current.is_open(), "the end screen is up")
	_check(report["grade"] in shown and "★" in shown, "it shows the grade and the stars")
	_check(Text.say(Text.m("report.pay.total")).to_upper() in shown, "it shows the pay's total")
	_check(report["tip"] == null or Text.say(report["tip"]) in shown, "it shows the weakest part's tip")
	_check(Text.say(Text.f("report.rank.points", [int(report["points"])])) in shown, "it shows the rank points")
	await _snap("endscreen")
	HudDebrief.current.close()
	await _done()


func _scenario_gradingcalls() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Config.Incidents["CloseAfter"] = 6.0
	var grading: Dictionary = Alarm.settings()["Grade"]


	var had: = CallLog.recent().size()
	var held: = await _start_crash("headOn", 1.0)
	if _check( not held.is_empty(), "a crash came"):
		var doors: int = held["doors"].size()
		var expect: = float(grading["Job"]["crash"]["Base"]) + float(grading["Job"]["crash"]["PerJob"]) * doors * CarCrash.JOBS.size()
		print("grading: crash with %d doors, par %.0f s" % [doors, Alarm.job_par])
		_check(is_equal_approx(Alarm.job_par, expect), "a crash's par from its door jobs (%.0f s)" % expect)
		var report: = await _next_report(had, 40.0)
		var checks: = _named(report)
		print("grading: crash report: parts %s, checks %s" % [report.get("parts"), checks])
		_check(checks.get("cones") == false and checks.get("battery") == false, "a crash's checks: cones before work, battery before cutting (both failed)")
		_check(_part(report, "job").size() == 3 and float(_part(report, "job")[1]) == 0.0, "a job not done scores nothing for its time")


	had = CallLog.recent().size()
	Config.Incidents["Tree"]["Variants"] = {"plain": 1}
	var trees: = FallenTree.current
	CallService.current.run_call("tree", trees.run)
	var waited: = 0.0
	while trees.scene.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	if _check( not trees.scene.is_empty(), "a tree came down"):
		var scene: Dictionary = trees.scene
		var rings: int = scene["rings"].size()
		var lengths: int = scene["pieces"].size() - scene["trees"].size()
		var expect: = float(grading["Job"]["tree"]["Base"]) + float(grading["Job"]["tree"]["PerCut"]) * rings + float(grading["Job"]["tree"]["PerPiece"]) * lengths
		print("grading: tree with %d cuts and %d lengths, par %.0f s" % [rings, lengths, Alarm.job_par])
		_check(is_equal_approx(Alarm.job_par, expect), "a tree's par: cuts × 8 s + lengths × 15 s (+ %d s)" % int(grading["Job"]["tree"]["Base"]))
		var middle: Vector3 = scene["middle"]
		var truck: Vehicle = Cordon.current._cone_stock.keys()[0]
		for offset: Vector3 in [Vector3(25, 0, 0), Vector3(-25, 0, 0)]:
			Cordon.current.stand_cone_at(truck, Transform3D(Basis(), _ground(middle + offset + Vector3(0, 5, 0))))
		player.set_attr("Geared", true)
		trees._check_cut(player)
		var report: = await _next_report(had, 40.0)
		var checks: = _named(report)
		print("grading: tree report: parts %s, checks %s" % [report.get("parts"), checks])
		_check(checks.get("cones") == true and checks.get("gear") == true, "a tree's checks: road coned off before the first cut, cut in gear")


	had = CallLog.recent().size()
	CallService.current.run_call("flood", FloodedCellar.current.run)
	waited = 0.0
	while Alarm.job_par < 0.0 and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	var litres: = float(Game.incident.get("total", 0))
	var flood_par: = litres / float(Config.Incidents.Flood.Flow) + float(grading["Job"]["flood"]["Base"])
	print("grading: flood of %d litres, par %.0f s" % [int(litres), Alarm.job_par])
	_check(litres > 0.0 and is_equal_approx(Alarm.job_par, flood_par), "a flood's par: litres / flow + 60 s")
	var report: = await _next_report(had, 40.0)
	var checks: = _named(report)
	print("grading: flood report: parts %s, checks %s, weakest %s, tip %s" % [report.get("parts"), checks, report.get("weakest"), Text.say(report.get("tip"), "en") if report.get("tip") != null else "-"])
	_check(checks.get("hose") == false and checks.get("valve") == false, "a flood's checks: hose in the hatch, discharge opened (both failed)")
	_check(report.get("grade") == "C", "a call nobody came to is a C")
	await _done()
