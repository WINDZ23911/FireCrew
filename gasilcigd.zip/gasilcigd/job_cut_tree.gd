class_name JobCutTree
extends CrewJob




func _init() -> void :
	kind = "cutTree"
	role = "rescue"


func place() -> Vector3:
	return FallenTree.current.position_of_call


func suits(member: Crewman) -> bool:
	return member.body.get_attr("Line") == null


func _next_ring(tree: FallenTree, from: Vector3) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for ring: Dictionary in tree.scene.get("rings", []):
		if ring["done"]:
			continue

		if not ring.has("limb") and ring["tree"]["limbs_left"] > 0:
			continue

		if ring.get("crew_taken") != null and ring["crew_taken"] != who and is_instance_valid(ring["crew_taken"]):
			continue
		var at: = _ring_at(ring)
		var distance: = at.distance_to(from)
		if distance < best_distance:
			best_distance = distance
			best = ring
	return best


static func _ring_at(ring: Dictionary) -> Vector3:
	return ring["part"].global_position if is_instance_valid(ring["part"]) else ring["position"]


func run() -> bool:
	var tree: = FallenTree.current
	if tree == null or tree.scene.is_empty():
		return fail("crew.say.nothingThere")
	if await CrewKit.take_tool(who, ["Chainsaw"], who.service.home_vehicle(who.commander())) == "":
		return fail("crew.say.noTool", [Text.named("tools", "Chainsaw")])
	var held: = who.token()


	if tree.line_live() and not await _wait_for_line(tree, held):
		return false if reason.is_empty() else fail(reason, reason_args)
	while on(held):
		if tree.scene.is_empty():
			return true
		var ring: = _next_ring(tree, who.body.global_position)
		if ring.is_empty():

			return true
		ring["crew_taken"] = who
		var at: = _ring_at(ring)

		var side: = FallenTree.cut_side(ring)
		var spot: = who.service.ground(at + side * 3.2 + Vector3(0, 2, 0)) if not side.is_zero_approx() else CrewKit.stand_off(who, at, 3.2)
		if not await who.go(spot, 1.2, 40.0):
			ring["crew_taken"] = null
			return fail("crew.say.stuck")
		var cut: = await CrewKit.work_until(who, func() -> bool: return ring["done"], 25.0, at)
		ring["crew_taken"] = null
		if not cut and not ring["done"]:
			return fail("crew.say.cannot")
	return false



func _wait_for_line(tree: FallenTree, held: int) -> bool:
	var line: Dictionary = tree.scene.get("line", {})
	if float(line.get("isolate_at", -1.0)) < 0.0:
		var best: Prompt = null
		for prompt: Prompt in line.get("prompts", []):
			if best == null or prompt.global_position.distance_to(who.body.global_position) < best.global_position.distance_to(who.body.global_position):
				best = prompt
		if best == null or not await CrewKit.press_skilled(who, best):
			reason = "crew.say.cannot"
			return false
	var started: = Game.now()
	while on(held) and tree.line_live():
		if Game.now() - started > 90.0:
			reason = "crew.say.cannot"
			return false
		await who.wait(1.0, held)
	return on(held)


func finish(_done: bool) -> void :
	ToolService.current.deactivate(who.body)
	CrewKit.free_hands(who)
