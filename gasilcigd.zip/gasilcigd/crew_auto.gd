class_name CrewAuto
extends RefCounted






























const LEAD: = ["attack", "cutTree", "cutOpen", "carry", "leak"]
const LEAD_NEAR: = 90.0
const RETRY_AFTER: = 15.0



static func arrived(service: CrewService, mind: Crewman) -> void :
	mind.mode = "auto"
	mind._idle_since = Game.now() - _idle_before() + 0.4 + mind.slot * 0.8
	if not service.done_here.has("arrived"):
		service.done_here["arrived"] = true
		service.lead_say("crew.say.arrived")



static func start_all(service: CrewService) -> void :
	for mind in service.members:
		mind._idle_since = Game.now() - _idle_before()



static func tick(service: CrewService) -> void :
	if Game.incident.is_empty():


		var packing: = false
		for mind in service.members:
			if mind.mode == "auto" and mind.job == null:
				mind.mode = "follow"
				if mind.body.seat == null and mind.body.health > 0.0 and CrewPack.has_work(mind):
					var job: = JobPackUp.new()
					job.ordered = false
					mind.give(job)
					packing = true
		if packing and not service.done_here.has("packUp"):
			service.done_here["packUp"] = true
			service.lead_say("crew.say.packUp")
		return
	var at: Vector3 = Game.incident.get("pos", Vector3.ZERO)
	if not service.members.is_empty() and not service.done_here.has("lead_here"):
		var lead: = service.members[0].commander()

		var gate: Variant = Game.incident.get("approach")
		if lead != null and (lead.global_position.distance_to(at) < LEAD_NEAR or (gate is Vector3 and lead.global_position.distance_to(gate) < LEAD_NEAR)):
			service.done_here["lead_here"] = Game.now()
	for mind in service.members:
		if mind.mode != "auto" or mind.job != null or mind.body.seat != null or mind.body.health <= 0.0:
			continue
		if Game.now() - mind._idle_since < _idle_before():
			continue

		if mind.body.global_position.distance_to(at) > 220.0:
			continue
		mind._idle_since = Game.now()

		if mind.body.health < mind.body.max_health * float(Config.Crew.RestBelow):
			var truck: Variant = service.home_vehicle(mind.commander())
			if truck is Vehicle and mind.body.global_position.distance_to((truck as Vehicle).global_position) > 18.0:
				var rest: = JobStandby.new(truck)
				rest.ordered = false
				rest.quiet = true
				mind.give(rest)
			mind.auto_note = Text.m("crew.jobs.recovering")
			continue
		var job: = next_job(service, mind)
		if job == null:

			var note: Variant = _waiting_note(service, mind)
			mind.auto_note = note if note != null else Text.m("crew.jobs.standingBy")
			continue
		if service.level_of(mind) == CrewService.HANDS_ON and not _hands_on_ok(service, mind, job):
			mind.auto_note = Text.m("crew.jobs.handsOn")
			continue

		if Game.now() - float(mind.failed.get(job.kind, -100.0)) < RETRY_AFTER:
			mind.auto_note = Text.f("crew.jobs.retry", [job.title()])
			continue
		mind.auto_note = null
		job.ordered = false
		mind.give(job)

		if job.kind != mind.last_auto_kind or Game.now() - mind.last_auto_at > 30.0:
			var line: = "crew.say.yes." + job.kind
			mind.say(line if Text.has(line) else "crew.say.yes.any", [], "info")
		mind.last_auto_kind = job.kind
		mind.last_auto_at = Game.now()




static func _waiting_note(service: CrewService, mind: Crewman) -> Variant:
	if not CrewWater.targets().is_empty() and not _lead_ok(service, mind, "attack"):
		return Text.m("crew.jobs.leadFirst")
	if not JobCarry.free_victims().is_empty() and not _lead_ok(service, mind, "carry"):
		return Text.m("crew.jobs.leadFirst")
	return null



static func next_job(service: CrewService, mind: Crewman) -> CrewJob:
	var kind: String = Game.incident.get("kind", "")
	var own: CrewJob = null
	match kind:
		"fire":
			own = _fire(service, mind)
		"tree":
			own = _tree(service, mind)
		"crash":
			own = _crash(service, mind)
		"flood":
			own = _flood(service, mind)
		"hazmat":
			own = _hazmat(service, mind)
		"accident":
			own = _accident(service, mind)
		"medical":
			own = _medical(service, mind)
		"alarm":
			own = _alarm(service, mind)
		_:
			own = _anything(service, mind)

	if own == null and kind != "fire" and (mind.role == "safety" or _covers(service, mind, "safety") or mind.role == "pump"):
		own = _scene_job(service, mind)
	return own



static func trained(mind: Crewman, what: String) -> bool:
	return int(mind.member.get("level", 0)) >= int((Config.Crew.Unlocks as Dictionary).get(what, 0))



static func arrival_orders(service: CrewService, mind: Crewman) -> void :
	for kind: String in service.arrival.keys():
		var job: CrewJob = null
		match kind:
			"supply":
				var truck: Variant = service.home_vehicle(mind.commander())
				if truck is Vehicle:
					job = JobSupply.new(truck)
			"attack":
				job = JobAttack.new()
			"search":
				job = JobSearch.new()
			"cones":
				job = JobCones.new(Game.incident.get("pos", mind.body.global_position))
			"backup":
				job = JobBackup.new(mind.commander())
		if job == null or not job.suits(mind):
			continue
		if service.choose(job) != mind:
			continue
		service.arrival.erase(kind)
		job.ordered = true
		mind.give(job)
		mind.say("crew.say.yes." + kind if Text.has("crew.say.yes." + kind) else "crew.say.yes.any", [], "info", true)
		return



static func _hands_on_ok(_service: CrewService, mind: Crewman, job: CrewJob) -> bool:
	if not job.kind in (Config.Crew.Autonomy.HandsOn as Array):
		return false
	if job.kind == "supply":
		var lead: = mind.commander()
		return lead == null or (HoseService.current != null and HoseService.current.line_of(lead) != null)
	return true



static func _idle_before() -> float:
	return float(Config.Crew.get("IdleBefore", 1.5))




static func _lead_ok(service: CrewService, mind: Crewman, kind: String) -> bool:
	var lead: = mind.commander()
	if lead == null:
		return true
	match kind:
		"attack":
			if HoseService.current and HoseService.current.line_of(lead) != null:
				return true
		"cutTree":
			if lead.get_attr("Tool") == "Chainsaw":
				return true
		"cutOpen":
			for stage: Dictionary in CarCrash.JOBS:
				if lead.get_attr("Tool") == stage["tool"]:
					return true
		"carry":
			if lead.holding == "carry":
				return true
	var since: float = service.done_here.get("lead_here", INF)
	if Game.now() - since <= float(Config.Crew.get("LeadWait", 0.0)):
		return false
	if service.done_here.has("granted_" + kind):
		return true
	match service.level_of(mind):
		CrewService.FULL:
			return true
		CrewService.STANDARD:
			service.ask_lead(mind, kind)
	return false




static func _once(service: CrewService, flag: String, job: CrewJob) -> CrewJob:
	service.done_here[flag] = true
	job.done_flag = flag
	return job



static func _doing(service: CrewService, job_kind: String, most: = 1) -> bool:
	var count: = 0
	for other in service.members:
		if other.job != null and other.job.kind == job_kind:
			count += 1
		for waiting in other.queue:
			if waiting.kind == job_kind:
				count += 1
	return count >= most



static func _covers(service: CrewService, mind: Crewman, role: String) -> bool:
	if mind.role == role:
		return true
	for other in service.members:
		if other.role == role and other.body.health > 0.0:
			return false
	return mind.role in Config.Crew.Covers.get(role, [])





static func _fire(service: CrewService, mind: Crewman) -> CrewJob:
	var fire: = FireService.current
	var truck: Variant = service.home_vehicle(mind.commander())
	var burning: = not CrewWater.targets().is_empty()

	if _covers(service, mind, "pump") and truck is Vehicle and not _doing(service, "supply"):
		var rig: = CrewWater.rig_of(truck)
		if not rig.is_empty() and rig["supply"]["state"] == "stowed" and not CrewWater.hydrant_for(truck).is_empty():
			return JobSupply.new(truck)

	if (mind.role == "rescue" or not burning) and not JobCarry.free_victims().is_empty() and not _doing(service, "carry", JobCarry.free_victims().size())\
	and _lead_ok(service, mind, "carry"):
		return JobCarry.new()

	var searching: = CrewSearch.open(service)
	if searching and not _doing(service, "search", int(Config.Crew.Search.Most)) and (_covers(service, mind, "rescue") or (trained(mind, "Search") and mind.role != "pump")):
		return JobSearch.new()


	var utilities: = _covers(service, mind, "rescue") or ((mind.role == "pump" or mind.role == "safety") and searching)
	if utilities and fire != null and not fire.incident.is_empty():
		var control: Variant = fire.incident.get("control")
		if is_instance_valid(control) and (control.get_meta("prompt") as Prompt).enabled and not _doing(service, "valve") and not _doing(service, "switch"):
			var gas: = fire.incident.get("fed") != null
			return JobPress.new("valve" if gas else "switch", control.get_meta("prompt"), "rescue")
		var sealed: Variant = fire.incident.get("sealed")
		if sealed != null and not _doing(service, "window") and _sealed_seen(service, fire):
			var building: Building = fire.incident["group"]["building"]
			for pane: Dictionary in building.rooms[sealed]["panes"]:
				if not pane["broken"] and pane["position"].y - CrewKit.stand_off(mind, pane["position"], 2.5).y < float(Config.Tools.GlassReach) - 1.0:
					return JobBreakWindow.new(pane)

	for other in service.members:
		if not other.blocked_by.is_empty() and other.blocked_by["locked"] and not _doing(service, "forceDoor"):
			var door: Dictionary = other.blocked_by
			other.blocked_by = {}
			for building in fire.buildings:
				if building is House and door in building.doors.values():
					return JobForceDoor.new(building, door)

	if burning and _lead_ok(service, mind, "attack"):
		var lines: = 0
		for other in service.members:
			if other.job is JobAttack:
				lines += 1
		var wanted: = 1 if mind.role != "nozzle" else 2
		if mind.role == "nozzle" or lines < wanted or mind.role == "rescue":
			if mind.role != "safety" or lines == 0:

				var inside: = _alone_inside(service, mind)
				if inside != null and mind.role == "nozzle":
					return JobBackup.new(inside)
				return JobAttack.new()

	if mind.role == "safety" or (_covers(service, mind, "safety") and not burning):
		var scene: = _scene_job(service, mind)
		if scene != null:
			return scene

	if mind.role == "pump" and truck is Vehicle and mind.body.global_position.distance_to(truck.global_position) > 25.0:
		return JobStandby.new(truck)
	if burning and mind.role != "safety" and _lead_ok(service, mind, "attack"):
		return JobAttack.new()
	return null



static func _alone_inside(service: CrewService, mind: Crewman) -> Player:
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return null
	var building: Building = fire.incident["group"]["building"]
	for other in service.members:
		if other == mind or not other.job is JobAttack or building.room_at(other.body.root_position()) == null:
			continue
		var backed: = false
		for third in service.members:
			backed = backed or (third.job is JobBackup and (third.job as JobBackup).partner == other.body)
		if not backed:
			return other.body
	return null




static func _sealed_seen(service: CrewService, fire: FireService) -> bool:
	if service.done_here.has("sealed_seen"):
		return true
	var building: Building = fire.incident["group"]["building"]
	var near: = float(Config.Crew.Search.SealedSeen)
	var lookers: Array = service.members.map( func(m: Crewman) -> Player: return m.body)
	lookers.append(Game.local_player)
	for body: Variant in lookers:
		if body is Player and is_instance_valid(body) and (body as Player).global_position.distance_to(building.position) < near:
			service.done_here["sealed_seen"] = true
			return true
	return false



static func _scene_job(service: CrewService, mind: Crewman) -> CrewJob:
	var at: Vector3 = Game.incident.get("pos", mind.body.global_position)
	if Bystanders.current and not _doing(service, "bystanders") and not service.done_here.has("bystanders"):
		var crowd: = _crowd_middle(at)
		if crowd != Vector3.INF:
			return _once(service, "bystanders", JobBystanders.new(crowd))
	if not service.done_here.has("cones") and not _doing(service, "cones"):
		var road: = CrewKit.road_at(at)
		if not road.is_empty():
			return _once(service, "cones", JobCones.new(at))
	if Game.night and not service.done_here.has("floodlight") and not _doing(service, "floodlight"):
		var truck: Variant = service.home_vehicle(mind.commander())
		var from: Vector3 = truck.global_position if truck is Vehicle else mind.body.global_position
		return _once(service, "floodlight", JobStandTool.new("Floodlight", at + (from - at) * Vector3(1, 0, 1) * 0.5, at))
	return null


static func _crowd_middle(at: Vector3) -> Vector3:
	var crowd: = Bystanders.current
	if crowd == null or crowd.people == null:
		return Vector3.INF
	var sum: = Vector3.ZERO
	var count: = 0
	for person: Pedestrians.Person in crowd.people.people.values():
		if not person.gone and person.position.distance_to(at) < 60.0:
			sum += person.position
			count += 1
	return sum / count if count >= 2 else Vector3.INF





static func _tree(service: CrewService, mind: Crewman) -> CrewJob:
	var tree: = FallenTree.current
	if tree == null or tree.scene.is_empty():
		return null
	var cuts_left: = false
	for ring: Dictionary in tree.scene["rings"]:
		cuts_left = cuts_left or not ring["done"]
	if _covers(service, mind, "rescue") and cuts_left and not _doing(service, "cutTree") and _lead_ok(service, mind, "cutTree"):
		return JobCutTree.new()
	if (mind.role == "safety" or mind.role == "pump") and not service.done_here.has("cones") and not _doing(service, "cones"):
		return _once(service, "cones", JobCones.new(tree.position_of_call))
	return JobDrag.new()


static func _crash(service: CrewService, mind: Crewman) -> CrewJob:
	var crash: = CarCrash.current
	if crash == null or crash.scene.is_empty():
		return null
	var engine: Variant = crash.scene.get("engine")
	if engine is Dictionary and engine["state"] == "smoking" and not _doing(service, "battery"):
		return JobPress.new("battery", engine["prompt"], "rescue")
	if (mind.role == "safety" or mind.role == "pump") and not service.done_here.has("cones") and not _doing(service, "cones"):
		return _once(service, "cones", JobCones.new(crash.position))

	if not CrewWater.targets().is_empty() and not _doing(service, "attack") and _lead_ok(service, mind, "attack"):
		return JobAttack.new()
	if not JobCarry.free_victims().is_empty() and not _doing(service, "carry", JobCarry.free_victims().size()) and _lead_ok(service, mind, "carry"):
		return JobCarry.new()
	var doors_left: = false
	for door: Dictionary in crash.scene.get("doors", []):
		doors_left = doors_left or door["stage"] <= CarCrash.JOBS.size()

	if doors_left and trained(mind, "Extrication") and (mind.role == "rescue" or not _doing(service, "cutOpen")) and _lead_ok(service, mind, "cutOpen"):
		return JobCutOpen.new()
	return null





static func _flood(service: CrewService, mind: Crewman) -> CrewJob:
	var cellar: = FloodedCellar.current
	if cellar == null or cellar.source.is_empty():
		return null
	var hatch: = JobPump.hatch()
	if hatch.is_empty() or hatch["over"]:
		return null
	if hatch["power"]:
		if not _doing(service, "power") and (_covers(service, mind, "rescue") or mind.role == "safety" or mind.role == "pump"):
			return JobPress.new("power", hatch["switch_prompt"], "rescue")
		return null
	if (hatch["boom_prompt"] as Prompt).enabled and not _doing(service, "boom"):
		return JobPress.new("boom", hatch["boom_prompt"], "safety")
	var wanted: = int(Config.Incidents.Flood.Pumps) - (hatch["pumps"] as Array).size()
	if wanted > 0 and CrewKit.kit_left(mind, "Portable pump") and not _doing(service, "portablePump", wanted):
		return JobPump.new()
	if wanted > 0 and (CallGear.current == null or not CallGear.current.kits.has("Portable pump")) and _covers(service, mind, "pump") and not _doing(service, "pump")\
	and (cellar.discharge.is_empty() or not cellar.discharge["open"]) and (hatch["pumps"] as Array).is_empty():
		return JobCellar.new()
	return null






static func _hazmat(service: CrewService, mind: Crewman) -> CrewJob:
	var at: Vector3 = Game.incident.get("pos", mind.body.global_position)
	var hazmat: = HazmatLeak.current
	var leak: Dictionary = hazmat._leak if hazmat != null else {}
	if (mind.role == "safety" or mind.role == "pump") and not service.done_here.has("cones") and not _doing(service, "cones"):
		return _once(service, "cones", JobCones.ring(at))
	if not CrewWater.targets().is_empty() and not _doing(service, "attack") and _lead_ok(service, mind, "attack"):
		return JobAttack.new()
	if leak.is_empty():
		return null
	var prompts: Dictionary = hazmat._prompts
	if prompts.has("drain") and is_instance_valid(prompts["drain"]) and (prompts["drain"] as Prompt).enabled and not _doing(service, "drainCover"):
		return JobPress.new("drainCover", prompts["drain"], "safety")
	if not JobCarry.free_victims().is_empty() and not _doing(service, "carry", JobCarry.free_victims().size()) and _lead_ok(service, mind, "carry"):
		return JobCarry.new()
	var trained_here: = trained(mind, "Hazmat")
	if trained_here and leak["cordon"] and not leak["foamed"] and float(leak["spill"]) > 0.2 and prompts.has("foam") and is_instance_valid(prompts["foam"])\
	and (prompts["foam"] as Prompt).enabled and CrewKit.kit_left(mind, "Foam") and not _doing(service, "foam"):
		return JobKitUse.new("foam", "Foam", prompts["foam"], true)
	if trained_here and leak["leaking"] and leak["cordon"] and not HazmatLeak.SUBSTANCES[leak["substance"]].get("skin", false) and not _doing(service, "leak")\
	and _lead_ok(service, mind, "leak"):
		return JobValve.new()
	if trained_here and float(leak["cloud"]) > float(Config.Crew.Hazmat.CloudDone) and leak["cordon"] and not _doing(service, "fog") and mind.role != "pump":
		return JobFog.new()

	if not leak["leaking"] and (leak["contaminated"] as Dictionary).has(mind.body) and not (leak["cleaned"] as Dictionary).has(mind.body) and is_instance_valid(prompts.get("decon")):
		return JobPress.new("decon", prompts["decon"])
	return null





static func _accident(service: CrewService, mind: Crewman) -> CrewJob:
	var accident: = WorkAccident.current
	if accident == null or accident._call.is_empty():
		return null
	var call: Dictionary = accident._call
	if _covers(service, mind, "rescue") or mind.role == "safety" or mind.role == "pump":
		if call["live"] and not _doing(service, "isolate"):
			var prompt: Variant = accident._isolate_prompt if call["isolate"] != "main" else null
			if call["isolate"] == "main":
				var control: Variant = (call["site"]["house"] as House)._control.get("part")
				prompt = (control as Node).get_meta("prompt") if is_instance_valid(control) else null
			if prompt is Prompt and is_instance_valid(prompt) and (prompt as Prompt).enabled:
				return JobPress.new("isolate", prompt, "rescue")
		if not call["live"] and call.get("air", false) and not call.get("bled", false) and is_instance_valid(accident._air_prompt) and not _doing(service, "bleed"):
			return JobPress.new("bleed", accident._air_prompt, "rescue")
	if not CrewWater.targets().is_empty() and not _doing(service, "attack") and _lead_ok(service, mind, "attack"):
		return JobAttack.new()
	if not JobCarry.free_victims().is_empty() and not _doing(service, "carry", JobCarry.free_victims().size()) and _lead_ok(service, mind, "carry"):
		return JobCarry.new()
	return null




static func _medical(service: CrewService, mind: Crewman) -> CrewJob:
	var call: = LockedIn.current
	if call == null or call.scene.is_empty() or call.house == null:
		return null
	var scene: Dictionary = call.scene
	if not scene["asked"]:
		if not _doing(service, "neighbour") and is_instance_valid(scene["neighbour_prompt"]):
			return JobPress.new("neighbour", scene["neighbour_prompt"], "rescue")
		return null
	var front: Variant = call.house.outside_door()
	if front is Dictionary and front["locked"] and not _doing(service, "forceDoor") and (_covers(service, mind, "rescue") or mind.role == "safety"):
		return JobForceDoor.new(call.house, front)
	if CrewSearch.open(service) and not _doing(service, "search", int(Config.Crew.Search.Most)) and mind.role != "pump":
		return JobSearch.new(call.house)
	var aid: Variant = scene.get("aid_prompt")
	var patient_found: = false
	if VictimService.current != null:
		for victim: Victim in VictimService.current.victims:
			patient_found = patient_found or (victim.found and victim.state == "lying")
	if patient_found and not scene["aided"] and aid is Prompt and is_instance_valid(aid) and (aid as Prompt).enabled and not _doing(service, "firstAid"):
		return JobKitUse.new("firstAid", "First aid kit", aid)
	if not JobCarry.free_victims().is_empty() and not _doing(service, "carry", JobCarry.free_victims().size()) and _lead_ok(service, mind, "carry"):
		return JobCarry.new()
	return null



static func _alarm(service: CrewService, mind: Crewman) -> CrewJob:
	var alarm: = FireAlarm.current
	if alarm == null or alarm._panel.is_empty():
		return null
	if not _doing(service, "alarm") and (_covers(service, mind, "rescue") or mind.role == "nozzle") and not service.done_here.has("alarm"):
		return _once(service, "alarm", JobAlarm.new())
	return null


static func _anything(service: CrewService, mind: Crewman) -> CrewJob:
	if not JobCarry.free_victims().is_empty() and _lead_ok(service, mind, "carry"):
		return JobCarry.new()
	return null
