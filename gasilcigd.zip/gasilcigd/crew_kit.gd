class_name CrewKit
extends RefCounted










static func find_tool(tool_name: String, from: Vector3, prefer: Variant = null) -> Dictionary:
	var best: Dictionary = {}
	var best_score: = INF
	for item: Dictionary in ToolService.current.items:
		if item["name"] != tool_name or item["holder"] != null or item["standing"]:
			continue
		var vehicle: Vehicle = item["vehicle"]
		if absf(vehicle.forward_speed) > 3.0:
			continue
		var score: = vehicle.global_position.distance_to(from) - (1000.0 if vehicle == prefer else 0.0)
		if score < best_score:
			best_score = score
			best = item
	return best



static func carried_tool(mind: Crewman, tool_name: String) -> Dictionary:
	for item: Dictionary in ToolService.current.carried(mind.body):
		if item["name"] == tool_name:
			return item
	return {}




static func take_tool(mind: Crewman, names: Array, prefer: Variant = null) -> String:
	var tools: = ToolService.current
	for tool_name: String in names:
		var have: = carried_tool(mind, tool_name)
		if not have.is_empty():
			if tools.held(mind.body) != tool_name:
				tools.toggle(mind.body, have)
			return tool_name
	for tool_name: String in names:
		var item: = find_tool(tool_name, mind.body.global_position, prefer)
		if item.is_empty():
			continue
		var line: LockerLine = item["line"]
		if not await from_locker(mind, item["vehicle"], line):
			return ""
		if item["holder"] == mind.body:
			if tools.held(mind.body) != tool_name:
				tools.toggle(mind.body, item)
			return tool_name
	return ""



static func from_locker(mind: Crewman, vehicle: Vehicle, line: LockerLine) -> bool:
	var lockers: = Lockers.of(vehicle)
	if lockers == null:
		return false
	var handle: = _handle_for(lockers, line, mind.body.global_position)
	if handle.is_empty():
		return false
	var held: = mind.token()
	var node: Node3D = handle["node"]
	var spot: = mind.stand_by(node.global_position, 3.0)
	if OS.get_cmdline_user_args().has("--crew-trace"):
		print("crew trace: %s to locker: handle %s spot %s vehicle %s" % [mind.display_name(), node.global_position, spot, vehicle.global_position])
	if not await mind.go(spot, 3.0, 60.0):
		return false
	if absf(vehicle.forward_speed) > 3.0:
		return false
	mind.look = node.global_position
	if not lockers.is_open(handle):
		lockers.set_open(handle, true)
		if not await mind.wait(0.9, held):
			return false
	if mind.body.root_position().distance_to(node.global_position) > Lockers.REACH:
		if not await mind.go(node.global_position, 4.0, 15.0):
			return false
	lockers.use(mind.body, handle, line)
	return await mind.wait(0.3, held)


static func _handle_for(lockers: Lockers, line: LockerLine, from: Vector3) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	var nav: = CrewNav.current
	for handle: Dictionary in lockers.handles:
		if not line in lockers.lines_of(handle):
			continue
		var node: Node3D = handle["node"]
		var distance: float = node.global_position.distance_to(from)

		var vehicle: = lockers.vehicle
		var side: = signf((vehicle.global_transform.affine_inverse() * node.global_position).x)
		var spot: = node.global_position + vehicle.global_basis.x * side * 2.5
		if nav != null and nav.ready_at(spot):
			var ground: = nav.closest(Vector3(spot.x, spot.y - 3.0, spot.z))
			var found: = nav.path(from, ground)
			if found.is_empty() or Vector3(found[found.size() - 1].x - ground.x, 0, found[found.size() - 1].z - ground.z).length() > 1.2 or Vector3(ground.x - spot.x, 0, ground.z - spot.z).length() > 2.5:
				distance += 500.0
		if distance < best_distance:
			best_distance = distance
			best = handle
	return best




static func work_until(mind: Crewman, done: Callable, give_up: = 30.0, face: Variant = null) -> bool:
	var tools: = ToolService.current
	var held: = mind.token()
	var skill: = CrewRoster.skill(mind.member)
	var started: = Game.now()
	var ok: = false
	while mind.alive(held):
		if face is Vector3:
			mind.look = face
		if done.call():
			ok = true
			break
		if Game.now() - started > give_up / maxf(skill, 0.1):
			break
		tools.activate(mind.body)
		await mind.wait(skill, held)
		tools.deactivate(mind.body)
		if done.call():
			ok = true
			break
		await mind.wait(1.0 - skill + 0.05, held)
	tools.deactivate(mind.body)
	return ok



static func pull(mind: Crewman) -> void :
	ToolService.current.activate(mind.body)
	ToolService.current.deactivate(mind.body)



static func stow_all(mind: Crewman) -> void :
	if ToolService.current:
		for item: Dictionary in ToolService.current.carried(mind.body).duplicate():
			ToolService.current._put_back(item)
	if Cordon.current:
		for item: Dictionary in Cordon.current.items:
			if item["holder"] == mind.body:
				Cordon.current.put_back(item)
	put_kit_back(mind)
	CrewWater.return_set(mind)



static func free_hands(mind: Crewman) -> void :
	if ToolService.current:
		ToolService.current.clear_hands(mind.body)






static func kit_left(mind: Crewman, kit_name: String) -> bool:
	if CallGear.carried(mind.body) == kit_name:
		return true
	var gear: = CallGear.current
	return gear != null and gear.kits.has(kit_name) and int(gear.kits[kit_name]["pool"]) > 0




static func take_kit(mind: Crewman, kit_name: String) -> bool:
	if CallGear.carried(mind.body) == kit_name:
		return true
	if not kit_left(mind, kit_name):
		return false
	free_hands(mind)
	var best: Array = []
	var best_distance: = INF
	for line: LockerLine in CallGear.current.kits[kit_name]["lines"]:
		for vehicle in Vehicle.all:
			var lockers: = Lockers.of(vehicle)
			if lockers != null and line in lockers.lines and absf(vehicle.forward_speed) < 3.0:
				var distance: = vehicle.global_position.distance_to(mind.body.global_position)
				if distance < best_distance:
					best_distance = distance
					best = [vehicle, line]
	if best.is_empty():
		return false
	if not await from_locker(mind, best[0], best[1]):
		return false
	return CallGear.carried(mind.body) == kit_name



static func put_kit_back(mind: Crewman) -> void :
	var kit: = CallGear.carried(mind.body)
	if kit.is_empty() or CallGear.current == null:
		return
	CallGear.current._on_line(mind.body, kit)






static func take_cordon(mind: Crewman, item_name: String, prefer: Variant = null) -> Dictionary:
	var cordon: = Cordon.current
	if cordon == null:
		return {}
	for item: Dictionary in cordon.items:
		if item["name"] == item_name and item["holder"] == mind.body:
			if cordon.held(mind.body) == null or not is_same(cordon.held(mind.body), item):
				ToolService.current.toggle_slot(mind.body, item["entry"])
			return item
	var best: Dictionary = {}
	var best_score: = INF
	for item: Dictionary in cordon.items:
		if item["name"] != item_name or item["holder"] != null:
			continue
		var truck: Vehicle = item["truck"]
		if item_name == "Cones" and cordon._cone_stock.get(truck, 0) <= 0:
			continue
		var score: = truck.global_position.distance_to(mind.body.global_position) - (1000.0 if truck == prefer else 0.0)
		if score < best_score:
			best_score = score
			best = item
	if best.is_empty():
		return {}
	if not await from_locker(mind, best["truck"], best["line"]):
		return {}
	return best if best["holder"] == mind.body else {}






static func prompt_near(mind: Crewman, at: Vector3, key: = "interact", within: = 6.0) -> Prompt:
	var best: Prompt = null
	var best_distance: = within
	for prompt in Prompt.all:
		if prompt.key != key or not prompt.shown_to(mind.body):
			continue
		var distance: = prompt.global_position.distance_to(at)
		if distance < best_distance:
			best_distance = distance
			best = prompt
	return best



static func press_skilled(mind: Crewman, prompt: Prompt) -> bool:
	if prompt == null:
		return false
	var skill: = CrewRoster.skill(mind.member)
	return await mind.press(prompt, prompt.hold / maxf(skill, 0.1) if prompt.hold > 0.0 else 0.0)






static func stand_off(mind: Crewman, at: Vector3, gap: float) -> Vector3:
	return mind.stand_by(at, gap)



static func road_at(at: Vector3) -> Array:
	var graph: = NavGraph.current
	if graph == null:
		return []
	var found: Array = graph.nearest_lane(at.x, at.z)
	if found[0] < 0 or float(found[2]) > 30.0:
		return []
	var segment: Dictionary = graph.segments[found[0]]
	var sampled: = NavGraph.sample(segment, found[1])
	var along: = Vector3(sampled.z, 0, sampled.w).normalized()
	var lane: = Vector3(sampled.x, at.y, sampled.y)

	var middle: = lane + Vector3(along.z, 0, - along.x) * 0.0
	return [middle, along]
