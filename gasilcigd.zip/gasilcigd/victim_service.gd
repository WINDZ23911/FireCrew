class_name VictimService
extends Node



























const WALL_ROOM: = 2.5
const SPOT_TRIES: = 40
const LYING: = Vector3(2.6, 1.2, 5.6)





const ON_SHOULDERS: = Transform3D(Basis(Vector3.UP, 0.45) * Basis(Vector3.LEFT, Vector3.BACK, Vector3.UP), Vector3(1.75, 1.3, -0.15))

const TORSO_FROM_WAIST: = Vector3(0, 0.83, 0)


const DRAGGED: = Vector3(0, 0.0, 3.4)
const DRAG_TILT: = 0.22



const BOARD_CARRY: = Vector3(0, 2.0, -3.7)
const CHILD_SCALE: = 0.68
const SPOT_KINDS: = ["bed", "window", "door", "furniture", "wardrobe"]
const BED_THINGS: = ["Bed", "Nightstand"]
const WARDROBE_THINGS: = ["Wardrobe", "Dresser", "Toy shelf"]
const FURNITURE_THINGS: = ["Sofa", "Television", "Dining table", "Kitchen cabinets", "Desk", "Coffee table", "Bookshelf", "Table", "Counter", "Seats", "Little table"]

const BAR_SHADER: = "\nshader_type spatial;\nrender_mode unshaded, cull_disabled, depth_draw_never, shadows_disabled;\n// How someone is doing: a bar a fixed number of pixels across, floating over them and facing the view.\nuniform float share = 1.0;\nuniform vec3 fill : source_color = vec3(0.35, 0.82, 0.43);\nuniform vec2 pixels = vec2(70.0, 8.0);\nuniform float lift = 2.2;\n\nvoid vertex() {\n\tvec4 world = MODEL_MATRIX * vec4(0.0, 0.0, 0.0, 1.0);\n\tworld.y += lift;\n\tvec4 centre = VIEW_MATRIX * world;\n\tfloat per_pixel = 2.0 * -centre.z / (abs(PROJECTION_MATRIX[1][1]) * VIEWPORT_SIZE.y);\n\tcentre.xy += VERTEX.xy * pixels * per_pixel;\n\tPOSITION = PROJECTION_MATRIX * centre;\n}\n\nvoid fragment() {\n\tbool full = UV.x <= share;\n\tALBEDO = full ? fill : vec3(0.0036, 0.0045, 0.0065);\n\tALPHA = full ? 1.0 : 0.7;\n}\n"
























const TAG_COLORS: = {
	"red": Color(0.9, 0.12, 0.1), "yellow": Color(1.0, 0.85, 0.1), "green": Color(0.2, 0.8, 0.3), "black": Color(0.08, 0.08, 0.08), 
}

static var current: VictimService
static var _bar_shader: Shader


var forced: = -1
var forced_sick: = 0.0
var forced_report: = ""
var forced_spots: = false

var victims: Array[Victim] = []
var total: = 0
var out: = 0
var fetched: = 0
var lost: = 0
var last_counts: Dictionary = {}


var report: = ""
var searched_all: = false
var cues: = 0
var triage: = false
var triage_ok: = true
var down: DownService
var _rescuers: Dictionary = {}
var _carrying: Dictionary = {}
var _helping: Dictionary = {}
var _assessors: Dictionary = {}
var _house: Variant = null
var _holder: Node3D
var _watched: Dictionary = {}
var _stood: Dictionary = {}
var _made: = 0
var _mirror: Dictionary = {}
var _mirroring: = false
var _search_graded: = false


func _init() -> void :
	current = self


func _ready() -> void :
	_holder = Node3D.new()
	_holder.name = "Victims"
	add_child(_holder)
	Net.share("victims", _net_state, _net_apply, 5.0)
	Net.handle("victims.cue", func(id: int, kind: String) -> void : _play_cue(_mirror.get(id), kind))
	Net.stopped.connect( func() -> void :
		if _mirroring:
			_net_apply([], true)
	)
	down = DownService.new()
	down.name = "DownService"
	add_child(down)


func _exit_tree() -> void :
	if current == self:
		current = null


static func _ambulance() -> AmbulanceService:
	return AmbulanceService.current


static func settings() -> Dictionary:
	return Config.Victims






static func night() -> bool:
	var hour: = Sky3D.current.hour if Sky3D.current else 12.0
	var span: Array = settings()["Spots"]["Night"]
	return hour >= float(span[0]) or hour < float(span[1])



static func room_kind(room_name: String) -> String:
	var low: = room_name.to_lower()
	for word: String in ["bedroom", "child", "nursery"]:
		if word in low:
			return "bed"
	for word: String in ["bath", "washroom"]:
		if word in low:
			return "bath"
	for word: String in ["kitchen", "living", "parlour", "dining", "canteen", "staff", "office", "study", "shop", "tasting", "workshop", "locker", "banking"]:
		if word in low:
			return "day"
	for word: String in ["hall", "landing", "stair", "store", "garage", "loft", "cold", "vault", "boiler", "forecourt", "barn", "pantry", "utility", "laundry", "cellar"]:
		if word in low:
			return "pass"
	return ""





func _floor_spot(house: Building, room: Dictionary, anchor: = Vector3.INF) -> Variant:
	var lot: Transform3D = house.lot if house is House else house.place
	var inverse: = lot.affine_inverse()
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var spots: Dictionary = settings()["Spots"]
	var margin: = WALL_ROOM if anchor == Vector3.INF else float(spots["WallRoom"])
	if high.x - low.x < margin * 2.0 + 1.0 or high.z - low.z < margin * 2.0 + 1.0:
		return null
	var near: Array = spots["Near"]
	var world: = Game.world
	var space: = world.get_world_3d().direct_space_state
	var box: = BoxShape3D.new()
	box.size = LYING
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = box
	query.collision_mask = World.LAYER_SOLID

	for attempt in SPOT_TRIES:
		var x: = randf_range(low.x + margin, high.x - margin)
		var z: = randf_range(low.z + margin, high.z - margin)
		if anchor != Vector3.INF:
			var turn: = randf() * TAU
			var reach: = randf_range(float(near[0]), float(near[1]))
			var p: = inverse * (anchor + Vector3(cos(turn), 0, sin(turn)) * reach)
			if p.x < low.x + margin or p.x > high.x - margin or p.z < low.z + margin or p.z > high.z - margin:
				continue
			x = p.x
			z = p.z
		var above: = lot * Vector3(x, low.y + 3.0, z)
		var hit: = world.raycast(above, above + Vector3(0, -5, 0), World.LAYER_SOLID)

		if hit.is_empty() or above.y - hit["position"].y <= 2.4:
			continue
		var ground: Vector3 = hit["position"]
		var feet: = Basis(Vector3.UP, randf() * TAU) * Vector3.FORWARD


		var right: = feet.cross(Vector3.UP)
		query.transform = Transform3D(Basis(right, Vector3.UP, right.cross(Vector3.UP)), ground + feet * 0.4 + Vector3(0, 0.2 + LYING.y / 2.0, 0))
		if space.intersect_shape(query, 1).is_empty():
			return Figure.lying(ground, feet, 0.05)
	return null




func _anchors(house: Building, room: Dictionary) -> Array:
	var found: Array = []
	if not house is House:
		return found
	var home: House = house
	for node: Dictionary in home.fuel:
		if node.get("room") != room["name"]:
			continue
		var thing: String = node["name"]
		if thing in BED_THINGS:
			found.append(["bed", node["position"]])
		elif thing in WARDROBE_THINGS:
			found.append(["wardrobe", node["position"]])
		elif thing in FURNITURE_THINGS:
			found.append(["furniture", node["position"]])
	for pane: Dictionary in room["panes"]:
		found.append(["window", pane["position"]])
	for opening: Dictionary in home.openings:
		if opening["door"] is Dictionary and (opening["a"] == room["name"] or opening["b"] == room["name"]):
			found.append(["door", (opening["door"]["shut"] as Transform3D).origin])
	for door_name: String in home.doors:
		var door: Dictionary = home.doors[door_name]
		if door["outside"] and door.get("room") == room["name"]:
			found.append(["door", (door["shut"] as Transform3D).origin])
	return found




func _place_in(house: Building, room: Dictionary, child: = false) -> Variant:
	if not forced_spots:
		var weights: Dictionary = settings()["Spots"]["Weights"]["night" if night() else "day"]
		var choices: Array = []
		for anchor: Array in _anchors(house, room):
			var weight: = float(weights.get(anchor[0], 1.0))
			if child and anchor[0] == "wardrobe":
				weight *= float(settings()["Spots"]["ChildWardrobe"])
			if weight > 0.0:
				choices.append({"anchor": anchor, "order": pow(randf(), 1.0 / weight)})
		choices.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["order"] > b["order"])
		for choice: Dictionary in choices.slice(0, 4):
			var placed: Variant = _floor_spot(house, room, choice["anchor"][1])
			if placed != null:
				return [placed, choice["anchor"][0]]
	var open: Variant = _floor_spot(house, room)
	return [open, "floor"] if open != null else null





func _draw_rooms(house: Building, scenario: Variant, allow_origin: = false) -> Array:
	var rooms: Array = []
	var burning: Variant = scenario.get("room") if scenario is Dictionary else null
	var kinds: Dictionary = settings()["Spots"]["Rooms"]["night" if night() else "day"]
	for room_name: String in house.rooms:
		var room: Dictionary = house.rooms[room_name]

		if room.get("open", false) or (burning == room_name and not allow_origin):
			continue
		var weight: float = float(settings()["UpstairsWeight"]) if int(room["floor"]) > 0 else 1.0
		if not forced_spots:
			weight *= float(kinds.get(room_kind(room_name), 1.0))
		var order: = pow(randf(), 1.0 / maxf(weight, 0.01))
		if burning == room_name:
			order = 2.0
		rooms.append({"room": room, "order": order})
	rooms.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["order"] > b["order"])
	return rooms





func _show_condition(victim: Victim) -> void :
	if not is_instance_valid(victim.figure):
		return
	victim.figure.set_meta("Condition", ceili(victim.condition))
	if not is_instance_valid(victim.bar):
		return
	var share: = clampf(victim.condition / 100.0, 0.0, 1.0)
	var material: ShaderMaterial = victim.bar.material_override
	material.set_shader_parameter("share", share)
	material.set_shader_parameter("fill", Color8(90, 210, 110) if share > 0.5 else (Color8(255, 190, 30) if share > 0.25 else Color8(226, 54, 40)))


func _set_prompt(victim: Victim) -> void :
	var carried: = victim.state == "carried"
	var prompt: = victim.prompt
	prompt.object = Text.m("calls.victims.casualty" if victim.casualty else "calls.victims.unconscious")
	prompt.action = Text.m("calls.victims.putDown" if carried else "calls.victims.carry")
	prompt.hold = 0.3 if carried else float(settings()["LiftTime"])
	prompt.enabled = victim.state == "lying" or carried
	if victim.tag_prompt != null:
		victim.tag_prompt.enabled = not victim.tag.is_empty() and not victim.tagged and (victim.state == "lying" or victim.state == "trapped")


func _hang(figure: Figure, parent: Node3D) -> void :
	if figure.get_parent() != parent:
		if figure.get_parent():
			figure.get_parent().remove_child(figure)
		parent.add_child(figure)



func _lay_down(victim: Victim, place: Transform3D) -> void :
	_hang(victim.figure, _holder)
	victim.figure.pose("lying")
	victim.figure.global_transform = place
	_size(victim)
	victim.figure.reset_physics_interpolation()
	victim.state = "lying"
	victim.carrier = null
	_set_prompt(victim)



func _size(victim: Victim) -> void :
	if victim.figure.has_meta("child"):
		victim.figure.scale = Vector3.ONE * CHILD_SCALE


func _let_go(player: Variant) -> void :
	_carrying.erase(player)
	if not is_instance_valid(player):
		return
	if player.rig != null and player.rig.has_meta("board_carry"):
		player.rig.remove_meta("board_carry")
	player.set_attr("Carrying", null)
	if player.holding == "carry":
		player.holding = ""
	StanceService.refresh_speed(player)



func put_down(victim: Victim) -> void :
	var player: = victim.carrier
	if player == null:
		return
	_end_help(victim)

	var stood: Array = _stood.get(player, [])
	var here: = is_instance_valid(player) and player.is_inside_tree() and player.rig.is_inside_tree()

	if here and player.seat != null and not stood.is_empty():
		here = false
	var at: Vector3 = player.root_position() if here else (stood[0] if not stood.is_empty() else victim.figure.global_position - Vector3(0, 1.8, 0))
	var ahead: Vector3 = player.facing() if here else (stood[1] if not stood.is_empty() else Vector3.BACK)
	_let_go(player)
	_stood.erase(player)
	ahead = Vector3(ahead.x, 0, ahead.z)
	ahead = ahead.normalized() if ahead.length() > 0.1 else Vector3.BACK
	var world: = Game.world
	if world == null or not world.is_inside_tree() or not is_inside_tree():
		return
	var mask: = World.LAYER_SOLID | World.LAYER_VEHICLE

	var blocked: = world.raycast(at, at + ahead * 5.5, mask)

	var hit: = {}
	if blocked.is_empty():
		hit = world.raycast(at + ahead * 3.0, at + ahead * 3.0 + Vector3(0, -9, 0), World.LAYER_SOLID)
	if hit.is_empty():
		hit = world.raycast(at, at + Vector3(0, -9, 0), World.LAYER_SOLID)
	var ground: Vector3 = hit["position"] if not hit.is_empty() else at - Vector3(0, 3, 0)

	_lay_down(victim, Figure.lying(ground, ahead.cross(Vector3.UP), 0.36 if victim.on_board else 0.05))




func lift(victim: Victim, player: Player) -> bool:
	if not is_instance_valid(player) or player.health <= 0.0 or victim.state != "lying":
		return false
	if player.seat != null or player.get_attr("Down") != null:
		return false
	if _carrying.has(player):
		Game.notify(Text.m("calls.victims.alreadyCarrying"), "", player)
		return false
	_end_helping(player)
	var shoulders: Node3D = player.rig.joints.get("Waist")
	if shoulders == null:
		return false

	var hoses: = HoseService.current
	if hoses:
		var line: Variant = hoses.line_of(player)
		if line != null:
			hoses.disconnect_line(line)
		var supply: Variant = hoses.supply_of(player)
		if supply != null:
			hoses.stow_supply(supply)

	_find(victim, player)
	victim.state = "carried"
	victim.carrier = player
	victim.mode = "board" if victim.on_board else ("drag" if _smoky(player) else "carry")
	victim.mode_since = Game.now()
	_carrying[player] = victim
	_hang_carried(victim)
	_set_prompt(victim)

	player.holding = "carry"
	player.set_attr("Carrying", true)
	_pace(victim)
	_watch(player)
	if victim.mode == "board":
		Game.notify(Text.f("calls.victims.onBoard", [Controls.key_name("interact")]), "", player)
	elif victim.mode == "drag":
		Game.notify(Text.m("calls.victims.dragging"), "", player)
	elif _ambulance() and _ambulance().called():
		Game.notify(Text.m("calls.victims.toAmbulance"), "", player)
	return true



func _hang_carried(victim: Victim) -> void :
	var player: = victim.carrier
	if not is_instance_valid(player) or not is_instance_valid(victim.figure):
		return
	if player.rig.has_meta("board_carry") and victim.mode != "board":
		player.rig.remove_meta("board_carry")
	if victim.mode == "board":


		victim.figure.pose("lying")
		_hang(victim.figure, player.rig)
		victim.figure.transform = Figure.lying(BOARD_CARRY, Vector3.FORWARD, 0.0)
		player.rig.set_meta("board_carry", true)
	elif victim.mode == "drag":
		victim.figure.pose("lying")
		_hang(victim.figure, player.rig)
		var lying: = Figure.lying(DRAGGED, Vector3.BACK, 0.05)
		victim.figure.transform = Transform3D(Basis(Vector3.RIGHT, DRAG_TILT), Vector3.ZERO) * lying
	else:
		var shoulders: Node3D = player.rig.joints.get("Waist")
		if shoulders == null:
			return
		victim.figure.pose("carried")
		_hang(victim.figure, shoulders)
		victim.figure.transform = Transform3D(Basis.IDENTITY, TORSO_FROM_WAIST) * ON_SHOULDERS
	_size(victim)
	victim.figure.reset_physics_interpolation()



func _smoky(player: Player) -> bool:
	if FireService.current == null:
		return false
	return FireService.current.smoke_at(player.root_position()) >= float(settings()["Drag"]["Smoke"])




func pace_of(victim: Victim) -> float:
	var drag: Dictionary = settings()["Drag"]
	var helped: = _helped(victim)
	var strength: = Training.factor(victim.carrier, "strength") if is_instance_valid(victim.carrier) else 1.0
	if victim.mode == "drag":
		return float(drag["TeamDrag"] if helped else drag["Speed"]) * strength
	if victim.mode == "board":

		return float(drag["TeamCarry"] if helped else drag["Speed"]) * strength
	return (float(drag["TeamCarry"]) if helped else float(settings()["CarrySpeed"])) * strength


func _pace(victim: Victim) -> void :
	var player: = victim.carrier
	if not is_instance_valid(player) or Net.is_client():
		return
	player.walk_speed = minf(pace_of(victim), _free_pace(player))

	var held: Variant = player.get_attr("Dragging")
	if held is float or held is int:
		player.walk_speed = minf(player.walk_speed, float(held))

	if is_instance_valid(victim.helper):
		victim.helper.walk_speed = minf(player.walk_speed + 2.0, _free_pace(victim.helper))



static func _free_pace(player: Player) -> float:
	return float(Config.Air.WalkSpeed) if player.get_attr("Scba", false) else StanceService.WALK



func _helped(victim: Victim) -> bool:
	var helper: = victim.helper
	return is_instance_valid(helper) and is_instance_valid(victim.carrier) and helper.health > 0.0\
	and helper.root_position().distance_to(victim.carrier.root_position()) <= float(settings()["Drag"]["TeamRange"])



func help(victim: Victim, player: Player) -> bool:
	if victim.state != "carried" or victim.carrier == player or is_instance_valid(victim.helper) or _carrying.has(player):
		return false
	if not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
		return false
	_end_helping(player)
	victim.helper = player
	_helping[player] = victim
	player.set_attr("Carrying", true)
	_watch(player)
	_pace(victim)
	Game.notify(Text.f("calls.victims.helping", [player.display_name]), "", victim.carrier)
	Game.notify(Text.m("calls.victims.helpStay"), "", player)
	return true


func _end_help(victim: Victim) -> void :
	var helper: = victim.helper
	victim.helper = null
	if helper != null:
		_helping.erase(helper)
		if is_instance_valid(helper):
			helper.set_attr("Carrying", null)
			StanceService.refresh_speed(helper)


func _end_helping(player: Player) -> void :
	var victim: Victim = _helping.get(player)
	if victim != null:
		_end_help(victim)
		_pace(victim)



func _watch(player: Player) -> void :
	if _watched.has(player):
		return
	_watched[player] = true
	player.died.connect( func() -> void :
		_drop(player)
		_end_helping(player)
	)
	player.tree_exiting.connect( func() -> void :
		_drop(player)
		_end_helping(player)
		_watched.erase(player)
	)


func _drop(player: Player) -> void :
	var victim: Victim = _carrying.get(player)
	if victim:
		put_down(victim)



func let_go_of(player: Player) -> void :
	_drop(player)
	_end_helping(player)


func _remove(victim: Victim) -> void :
	_end_help(victim)
	if victim.carrier:
		_let_go(victim.carrier)
		victim.carrier = null
	victim.prompt.enabled = false
	if victim.tag_prompt != null:
		victim.tag_prompt.enabled = false



func _hand_over(victim: Victim, player: Player) -> void :

	if triage and player != null and victim.tag != "red":
		for other: Victim in victims:
			if other != victim and other.tag == "red" and other.waiting():
				triage_ok = false
	_remove(victim)
	victim.state = "out"
	victim.found = true
	out += 1
	if player == null or not is_instance_valid(player):
		fetched += 1
	if is_instance_valid(victim.bar):
		victim.bar.queue_free()
	if is_instance_valid(victim.tag_label):
		victim.tag_label.queue_free()
	victim.figure.remove_from_group("Victim")
	if _ambulance():
		_ambulance().receive(victim.figure)
	else:
		_discard(victim.figure)
	if triage:
		_grade_triage()
	if player and is_instance_valid(player):
		var reward: = int(floor(float(settings()["Reward"]) * (0.5 + 0.5 * clampf(victim.condition / 100.0, 0.0, 1.0)) + 0.5))
		player.add_cash(reward, "", false, "people")
		_rescuers[player] = true

		Alarm.note(player, "carried")
		Alarm.handed(victim.condition)
		Game.notify(Text.f("calls.victims.broughtOut", [player.display_name, out, total]), "good")
		Game.notify(Text.f("calls.victims.handedOver", [Alarm.pay(reward)]), "good", CallKit.payee(player))


func _lose(victim: Victim) -> void :
	_remove(victim)
	victim.state = "lost"
	victim.found = true
	lost += 1
	_discard(victim.figure)
	if triage:
		_grade_triage()




func _discard(figure: Figure) -> void :
	if not is_instance_valid(figure):
		return
	figure.visible = false
	if not is_inside_tree():
		figure.queue_free()
		return
	var id: = figure.get_instance_id()
	get_tree().create_timer(0.25).timeout.connect( func() -> void :
		var found: = instance_from_id(id)
		if found is Node:
			found.queue_free()
	)


func _create(place: Transform3D, room_name: String, person: int, child: = false) -> Victim:
	var victim: = Victim.new()
	_made += 1
	victim.id = _made
	victim.seed = person
	victim.room = room_name
	_build(victim, child)
	victim.prompt.triggered.connect( func(player: Player) -> void :
		if victim.state == "lying":
			lift(victim, player)
		elif victim.state == "carried" and victim.carrier == player:
			put_down(victim)
		elif victim.state == "carried" and victim.helper == player:
			_end_helping(player)
		elif victim.state == "carried":
			help(victim, player)
	)
	victim.tag_prompt.triggered.connect( func(player: Player) -> void : assess(victim, player))
	_lay_down(victim, place)
	_show_condition(victim)
	victim.figure.add_to_group("Victim")
	return victim




func _build(victim: Victim, child: = false) -> void :
	victim.figure = Figure.build(victim.seed)
	victim.figure.name = "Victim"
	if child:
		victim.figure.set_meta("child", true)
	_holder.add_child(victim.figure)


	var prompt: = Prompt.new()
	prompt.net_id = "victim.%d" % victim.id
	prompt.reach = 9.0
	victim.figure.add_child(prompt)
	victim.prompt = prompt

	victim.prompt.condition = func(player: Player) -> bool:
		if victim.state != "carried":
			return true
		if victim.carrier == player:
			prompt.action = Text.m("calls.victims.putDown")
			prompt.hold = 0.3
			return true
		if victim.helper == player:
			prompt.action = Text.m("calls.victims.letGo")
			prompt.hold = 0.0
			return true
		if victim.helper == null and player.get_attr("Carrying") == null:
			prompt.action = Text.m("calls.victims.help")
			prompt.hold = 0.0
			return true
		return false


	var assess_prompt: = Prompt.new()
	assess_prompt.net_id = "victim.%d.tag" % victim.id
	assess_prompt.key = "item"
	assess_prompt.reach = 8.0
	assess_prompt.hold = float(settings()["Triage"]["Assess"])
	assess_prompt.object = Text.m("calls.victims.casualty")
	assess_prompt.action = Text.m("calls.victims.assess")
	assess_prompt.enabled = false
	victim.figure.add_child(assess_prompt)
	victim.tag_prompt = assess_prompt


	if _bar_shader == null:
		_bar_shader = Shader.new()
		_bar_shader.code = BAR_SHADER
	var bar: = MeshInstance3D.new()
	bar.name = "Condition"
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE
	bar.mesh = quad
	var material: = ShaderMaterial.new()
	material.shader = _bar_shader
	bar.material_override = material
	bar.custom_aabb = AABB(Vector3(-4, -4, -4), Vector3(8, 8, 8))
	bar.visibility_range_end = float(settings()["BarRange"])
	bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	victim.figure.add_child(bar)
	victim.bar = bar






func _find(victim: Victim, player: Variant) -> void :
	if victim.found:
		return
	victim.found = true
	if player != null and is_instance_valid(player):
		Alarm.note(player, "found")
	var inside_key: = "calls.rooms.%s.inside" % victim.room
	var inside: Variant = Text.m(inside_key) if Text.has(inside_key) else victim.room
	Game.notify(Text.f("calls.victims.foundChild" if victim.figure.has_meta("child") else "calls.victims.found", [inside]), "danger")

	if _house is Building and FireService.current != null and not FireService.current.incident.is_empty():
		var smoke: = FireService.current.smoke_at(victim.position() + Vector3(0, 2.5, 0))
		if smoke < float(settings()["Air"]["ShutClear"]) and _house is House and (_house as House).ways_out(victim.room) == 0 and _shut_room(victim.room):
			Game.notify(Text.m("calls.victims.shutSaved"), "good")



func _shut_room(room_name: String) -> bool:
	if not _house is House:
		return false
	var house: House = _house
	var doors: = 0
	for opening: Dictionary in house.openings:
		if opening["a"] == room_name or opening["b"] == room_name:
			if opening["door"] == null or opening["passes"].call():
				return false
			doors += 1
	return doors > 0




func _search(dt: float) -> void :
	var search: Dictionary = settings()["Search"]
	var now: = Game.now()
	for victim: Victim in victims:
		if victim.found or not victim.waiting():
			continue
		var at: = victim.position()
		var room: Variant = _house.room_at(at) if _house is Building else null
		var nearest: = INF
		for player in Game.players:
			if not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
				continue
			var from: = player.root_position()
			var distance: = from.distance_to(at)
			nearest = minf(nearest, distance)
			var same: bool = room != null and _house.room_at(from) == room
			if distance <= float(search["FindNear"]) or (same and distance <= float(search["FindRange"])):
				_find(victim, player)
				break
		if victim.found:
			continue

		if victim.next_cue <= 0.0:
			victim.next_cue = now + randf_range(1.0, float(search["CueEvery"][1]))
		elif now >= victim.next_cue and victim.condition > float(search["CueCondition"]):
			var every: Array = search["CueEvery"]
			victim.next_cue = now + randf_range(float(every[0]), float(every[1]))
			if nearest <= float(search["CueRange"]):
				var kind: = "help" if nearest <= float(search["CallRange"]) else "cough"
				cues += 1
				_play_cue(victim, kind)
				Net.broadcast("victims.cue", [victim.id, kind])
	_check_search()



func _check_search() -> void :
	if searched_all or not _house is House:
		return
	var house: House = _house
	for room_name: String in house.rooms:
		if not house.rooms[room_name].get("open", false) and not house.rooms[room_name].get("searched", false):
			return
	searched_all = true
	var missing: = 0
	for victim: Victim in victims:
		missing += 1 if (victim.waiting() and not victim.found) else 0
	if _search_graded:
		Alarm.check("search", true)
	Game.notify(Text.m("calls.victims.searchDone") if missing == 0 else Text.m("calls.victims.searchDoneMissed"), "good" if missing == 0 else "warning")


func _play_cue(victim: Variant, kind: String) -> void :
	if not victim is Victim or not is_instance_valid(victim.figure) or not victim.figure.is_inside_tree():
		return
	var sound: Dictionary = settings()["Search"]["Sounds"]
	var child: bool = victim.figure.has_meta("child")
	Sounds.once(victim.figure, sound["Help" if kind == "help" else "Cough"], float(sound["Volume"]), 10.0, float(settings()["Search"]["CueRange"]) + 20.0, randf_range(1.25, 1.4) if child else randf_range(0.9, 1.08))






func _draw_tags() -> void :
	var t: Dictionary = settings()["Triage"]
	triage = victims.size() >= int(t["From"])
	triage_ok = true
	if not triage:
		return
	var tags: Dictionary = t["Tags"]
	var has_red: = false
	for victim: Victim in victims:
		var roll: = randf()
		var sum: = 0.0
		var share: = 0.0
		for tag: String in tags:
			sum += float(tags[tag]["Weight"])
		for tag: String in tags:
			share += float(tags[tag]["Weight"]) / sum
			if roll <= share:
				victim.tag = tag
				break
		if victim.tag.is_empty():
			victim.tag = "yellow"
		has_red = has_red or victim.tag == "red"

	if not has_red:
		victims[0].tag = "red"
	for victim: Victim in victims:
		var how: Dictionary = tags[victim.tag]
		victim.drain *= float(how["Drain"])
		victim.sick *= float(how["Drain"])
		victim.condition = minf(victim.condition, float(how["Condition"]))
		_show_condition(victim)
		_set_prompt(victim)
	Alarm.check("triage", false)



func assess(victim: Victim, player: Player) -> bool:
	if victim.tag.is_empty() or victim.tagged:
		return false
	victim.tagged = true
	_assessors[victim.id] = player
	_show_tag(victim)
	_set_prompt(victim)
	Alarm.note(player, "assessed")
	Game.notify(Text.f("calls.victims.tagged", [Text.m("calls.victims.tags.%s" % victim.tag)]), "", player)
	if victim.tag == "green" and victim.state == "lying":
		_walk_off(victim)
	_grade_triage()
	return true



func _walk_off(victim: Victim) -> void :
	victim.state = "walking"
	_hang(victim.figure, _holder)
	victim.figure.pose("stand")
	victim.figure.global_transform = Figure.standing(victim.position() - Vector3(0, 0.5, 0), Vector3.FORWARD)
	_set_prompt(victim)


func _show_tag(victim: Victim) -> void :
	if not victim.tagged or victim.tag.is_empty() or not is_instance_valid(victim.figure) or is_instance_valid(victim.tag_label):
		return
	var label: = Label3D.new()
	label.name = "Tag"
	label.text = Text.say(Text.m("calls.victims.tags.%s" % victim.tag)).to_upper()
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = true
	label.pixel_size = 0.0016
	label.font_size = 26
	label.outline_size = 8
	label.modulate = TAG_COLORS.get(victim.tag, Color.WHITE)
	label.outline_modulate = Color(1, 1, 1) if victim.tag == "black" else Color(0, 0, 0)

	label.top_level = true
	label.visibility_range_end = float(settings()["BarRange"])
	victim.figure.add_child(label)
	label.global_position = victim.position() + Vector3(0, 3.4, 0)
	victim.tag_label = label



func _place_tags() -> void :
	for victim: Victim in victims:
		if is_instance_valid(victim.tag_label) and is_instance_valid(victim.figure):
			victim.tag_label.global_position = victim.position() + Vector3(0, 3.4, 0)



func _grade_triage() -> void :
	var all_tagged: = true
	for victim: Victim in victims:
		all_tagged = all_tagged and (victim.tagged or victim.state == "lost")
	Alarm.check("triage", triage_ok and all_tagged)




func triage_share() -> float:
	if not triage:
		return 1.0
	var tagged: = 0
	for victim: Victim in victims:
		tagged += 1 if victim.tagged else 0
	return (0.5 + 0.5 * float(tagged) / maxf(victims.size(), 1.0)) * (1.0 if triage_ok else 0.6)








func _net_state() -> Variant:
	var list: Array = []
	for victim: Victim in victims:
		if victim.waiting() and is_instance_valid(victim.figure) and victim.figure.is_inside_tree():
			var carrier: = Net.peer_of(victim.carrier) if is_instance_valid(victim.carrier) else 0
			var flags: = (1 if victim.found else 0) + (4 if victim.figure.has_meta("child") else 0) + (8 if victim.tagged else 0)
			var helper: = Net.peer_of(victim.helper) if is_instance_valid(victim.helper) else 0
			list.append([victim.id, victim.seed, victim.state, carrier, victim.figure.global_transform, ceili(victim.condition), victim.casualty, victim.room, 
				flags, victim.mode, helper, victim.tag if victim.tagged else ("?" if not victim.tag.is_empty() else "")])
	return list




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array:
		return
	_mirroring = not leaving
	var told: = {}
	for row: Array in list:
		var id: int = row[0]
		told[id] = true
		var flags: int = row[8] if row.size() > 8 else 1
		var victim: Victim = _mirror.get(id)
		if victim == null or not is_instance_valid(victim.figure):
			victim = Victim.new()
			victim.id = id
			victim.seed = row[1]
			victim.room = row[7]
			victim.state = ""
			_build(victim, flags & 4 != 0)
			victim.figure.add_to_group("Victim")
			_mirror[id] = victim
		var carrier: Player = Net.player_of(row[3]) if row[3] != 0 else null
		var place: Transform3D = row[4]
		victim.casualty = row[6]
		victim.found = flags & 1 != 0
		var mode: String = row[9] if row.size() > 9 else "carry"
		victim.helper = Net.player_of(row[10]) if row.size() > 10 and row[10] != 0 else null
		var moved: bool = row[2] != "carried" and not victim.figure.global_transform.is_equal_approx(place)
		if row[2] != victim.state or carrier != victim.carrier or moved or mode != victim.mode:
			victim.state = row[2]
			victim.carrier = carrier
			victim.mode = mode
			if victim.state == "carried" and is_instance_valid(carrier):
				_hang_carried(victim)
			else:
				_hang(victim.figure, _holder)
				victim.figure.pose("sit" if victim.state == "trapped" else ("stand" if victim.state == "walking" else "lying"))
				victim.figure.global_transform = place
				_size(victim)
			victim.figure.reset_physics_interpolation()
			_set_prompt(victim)
		var tag: String = row[11] if row.size() > 11 else ""
		if tag == "?":

			if victim.tag.is_empty():
				victim.tag = "?"
				_set_prompt(victim)
		elif not tag.is_empty() and not victim.tagged:
			victim.tag = tag
			victim.tagged = true
			_show_tag(victim)
			_set_prompt(victim)
		victim.condition = row[5]
		_show_condition(victim)
	for id: int in _mirror.keys():
		if not told.has(id):
			var gone: Victim = _mirror[id]
			_mirror.erase(id)
			if is_instance_valid(gone.figure):
				gone.prompt.enabled = false
				gone.tag_prompt.enabled = false
				_discard(gone.figure)
	if leaving:
		victims.clear()
		_carrying.clear()
		return

	var ids: = _mirror.keys()
	ids.sort()
	victims.clear()
	_carrying.clear()
	for id: int in ids:
		var victim: Victim = _mirror[id]
		victims.append(victim)
		if victim.state == "carried" and victim.carrier != null:
			_carrying[victim.carrier] = victim


func _clear() -> void :
	for player: Variant in _carrying.keys():
		_let_go(player)
	for player: Variant in _helping.keys():
		if is_instance_valid(player):
			player.set_attr("Carrying", null)
			StanceService.refresh_speed(player)
	_helping.clear()

	for victim: Victim in victims:
		if victim.waiting():
			victim.prompt.enabled = false
			victim.tag_prompt.enabled = false
			_discard(victim.figure)
	victims.clear()
	total = 0
	out = 0
	fetched = 0
	lost = 0
	report = ""
	searched_all = false
	triage = false
	triage_ok = true
	_search_graded = false
	_assessors.clear()











func begin_at(scene: Variant, seats: Array, drain: float) -> Array[Victim]:
	_clear()
	_house = scene
	for seat: Variant in seats:
		var place: Transform3D = seat["lying"] if seat is Dictionary else seat
		var victim: = _create(place, "wreck", randi_range(1, 1000000))
		victim.casualty = true
		if seat is Dictionary:
			victim.sick = drain
			_lay_down(victim, place)
		else:
			victim.drain = drain
			victim.figure.pose("sit")
			victim.figure.global_transform = place
			victim.state = "trapped"
			_set_prompt(victim)
		victims.append(victim)
	total = victims.size()
	report = "sure"
	_draw_tags()
	if total > 0 and _ambulance():
		_ambulance().arrive(scene)
	var made: Array[Victim] = []
	made.assign(victims)
	return made




func release(victim: Victim) -> void :
	if victim.state == "trapped":
		victim.state = "lying"
		_set_prompt(victim)
		if victim.tag == "green" and victim.tagged:
			_walk_off(victim)










func begin(building: Building, scenario: Variant = null, sure: Variant = null) -> int:
	_clear()
	_house = building
	var told_sure: = sure != null
	if sure == null and forced >= 0:
		sure = {"count": forced, "sick": forced_sick}
	var chance: = float(Alarm.pick("VictimChance")) if Alarm.active else float(settings()["Chance"])
	if not building.has_rooms() or (sure == null and randf() >= chance):
		if building.has_rooms() and not told_sure:
			_draw_report()
		return 0

	var most_by: Array = settings()["Most"]
	var most: = int(most_by[clampi(Alarm.crew(), 1, most_by.size()) - 1])
	var wanted: int = int(sure["count"]) if sure != null else randi_range(1, most)

	var origin: Dictionary = settings()["Origin"]
	var in_origin: = not told_sure and not forced_spots and Alarm.level >= int(origin["From"]) and randf() < float(origin["Chance"])
	var homes: = building.has_rooms() and _has_bedroom(building)
	for entry: Dictionary in _draw_rooms(building, scenario, in_origin):
		if victims.size() >= wanted:
			break
		var child: = homes and not told_sure and randf() < float(settings()["Report"]["ChildShare"])
		var placed: Variant = _place_in(building, entry["room"], child)
		if placed != null:
			var victim: = _create(placed[0], entry["room"]["name"], randi_range(1, 1000000), child)
			victim.spot = placed[1]
			victim.sick = float(sure.get("sick", 0.0)) if sure != null else 0.0
			victim.found = false
			victim.reported = told_sure
			victims.append(victim)
	total = victims.size()
	if told_sure:
		report = "sure"
	else:
		_draw_report()
	if total > 0 and _ambulance():
		_ambulance().arrive(building)
	return total


static func _has_bedroom(building: Building) -> bool:
	for room_name: String in building.rooms:
		if room_kind(room_name) == "bed":
			return true
	return false



func _draw_report() -> void :
	var r: Dictionary = settings()["Report"]
	var child: = false
	for victim: Victim in victims:
		child = child or victim.figure.has_meta("child")
	if not forced_report.is_empty():
		report = forced_report
	elif FirstShift.current != null and FirstShift.current.active:

		report = "count" if total > 0 else ""
	elif total == 0:
		report = "maybe" if randf() < float(r["FalseAlarm"]) else ("out" if randf() < float(r["SaysOut"]) else "")
	elif randf() < float(r["Wrong"]):
		report = "out"
	elif child and randf() < float(r["ChildSaid"]):
		report = "child"
	elif randf() < float(r["Count"]):
		report = "count"
	else:
		report = "maybe"
	if report == "count":
		for victim: Victim in victims:
			victim.reported = true
	_search_graded = report in ["maybe", "child", "count"]
	if _search_graded:
		Alarm.check("search", false)



func report_words() -> Variant:
	match report:
		"out":
			return Text.m("calls.victims.report.out")
		"maybe":
			return Text.m("calls.victims.report.maybe")
		"child":
			return Text.m("calls.victims.report.child")
		"count":
			return Text.fill(Text.plural(total, "calls.fire.inside"), [total])
	return null





func add_one(searched: Dictionary) -> bool:
	if not _house is Building or not _house.has_rooms():
		return false
	var building: Building = _house
	var rooms: Array = _draw_rooms(building, null)

	rooms.sort_custom( func(a: Dictionary, b: Dictionary) -> bool:
		return int(searched.has(a["room"]["name"])) < int(searched.has(b["room"]["name"])))
	for entry: Dictionary in rooms:
		var placed: Variant = _place_in(building, entry["room"])
		if placed != null:
			var victim: = _create(placed[0], entry["room"]["name"], randi_range(1, 1000000))
			victim.spot = placed[1]
			victim.found = false
			victim.reported = true
			victims.append(victim)
			total = victims.size()
			if report in ["", "out"]:
				report = "maybe"
			searched_all = false
			if _ambulance() and not _ambulance().called():
				_ambulance().arrive(building)
			return true
	return false






func step(dt: float, smoke_at: Callable, burning: bool) -> void :
	var air: Dictionary = settings()["Air"]
	var ambulance: = _ambulance()
	_search(dt)
	for victim: Victim in victims:
		if not victim.waiting():
			continue
		var position: = victim.figure.global_position

		var met: = (victim.state == "carried" or victim.state == "walking") and ambulance != null and ambulance.at_medic(position)
		if victim.state != "trapped" and ambulance and (ambulance.in_zone(position) or met):
			_hand_over(victim, victim.carrier if victim.state != "walking" else _assessors.get(victim.id))
			continue
		var level: float = float(smoke_at.call(position))
		var room: Variant = _house.room_at(position) if _house is Building else null
		var breathed: = level
		if level > 0.0 and room != null and _house is House:
			var head: = position + Vector3(0, 0.6, 0)
			if (_house as House).below_smoke(room, head):
				breathed *= FireService.UNDER_SMOKE
		var drain: float = float(settings()["SmokeDrain"]) * breathed
		if burning and room != null:
			drain += float(settings()["InsideDrain"]) * clampf(level, float(air["InsideLeast"]), 1.0)
		if victim.state == "trapped":
			drain += victim.drain
		drain += victim.sick
		if drain > 0.0:
			victim.condition -= drain * dt
			_show_condition(victim)
			if victim.condition <= 0.0:
				var carrier: = victim.carrier
				var known: = victim.found
				_lose(victim)
				if carrier:
					Game.notify(Text.m("calls.victims.tooLateCarried"), "warning", carrier)
				var inside_key: = "calls.rooms.%s.inside" % victim.room
				var inside: Variant = Text.m(inside_key) if Text.has(inside_key) else victim.room
				Game.notify(Text.f("calls.victims.notSaved", [inside]) if known else Text.m("calls.victims.notSavedUnfound"), "warning")



func waiting() -> bool:
	for victim: Victim in victims:
		if victim.waiting():
			return true
	return false



func building_lost() -> void :
	if not _house is Building:
		return
	for victim: Victim in victims:
		if victim.state == "lying" and _house.room_at(victim.figure.global_position) != null:
			_lose(victim)





func finish() -> Dictionary:
	for victim: Victim in victims:
		if victim.waiting():
			_hand_over(victim, null)
	var counts: = {"total": total, "out": out, "rescued": out - fetched, "fetched": fetched, "lost": lost, "rescuers": _rescuers, "triage": triage_share()}
	last_counts = counts.duplicate()
	_rescuers = {}
	if total > 0 and _ambulance():
		_ambulance().leave(float(settings()["LeaveAfter"]))
	_clear()
	_house = null
	return counts





func shown() -> Dictionary:
	if total <= 0:
		return {}
	var known: = 0
	for victim: Victim in victims:
		known += 1 if (victim.found or victim.reported) else 0
	if known <= 0:
		return {}
	return card({"total": known, "rescued": out - fetched, "fetched": fetched, "lost": lost})




func next_words() -> Variant:
	var inside: = 0
	var carried: = false
	for victim: Victim in victims:
		if victim.found and (victim.state == "lying" or victim.state == "trapped"):
			inside += 1
		carried = carried or victim.state == "carried"
	if inside > 0:
		return Text.fill(Text.plural(inside, "calls.fire.next.people"), [inside])
	if carried:
		return Text.m("calls.fire.next.carry")
	if _house is House and not searched_all and (report in ["maybe", "child", "count", "sure"]):
		var house: House = _house
		var searched: = 0
		var rooms: = 0
		for room_name: String in house.rooms:
			if house.rooms[room_name].get("open", false):
				continue
			rooms += 1
			searched += 1 if house.rooms[room_name].get("searched", false) else 0
		return Text.f("calls.victims.next.search", [searched, rooms])
	return null



static func card(counts: Dictionary) -> Dictionary:
	if int(counts.get("total", 0)) <= 0:
		return {}
	return {"victims": int(counts["total"]), "victims_out": int(counts["rescued"]), "victims_fetched": int(counts["fetched"]), "victims_lost": int(counts["lost"])}




static func tally(counts: Dictionary) -> void :
	if int(counts.get("total", 0)) <= 0:
		return
	var clean: = int(counts["fetched"]) == 0 and int(counts["lost"]) == 0
	Game.notify(Text.f("calls.victims.tally", [int(counts["rescued"]), int(counts["total"]), int(counts["fetched"]), int(counts["lost"])]), "good" if clean else "warning")



func rescuers() -> Dictionary:
	return _rescuers.duplicate()



func carried_by(player: Player) -> Victim:
	return _carrying.get(player)



func carriers() -> Array[Vector3]:
	var found: Array[Vector3] = []
	for player: Variant in _carrying:
		if is_instance_valid(player):
			found.append(player.root_position())
	for victim: Victim in victims:
		if victim.state == "walking" and is_instance_valid(victim.figure):
			found.append(victim.position())
	return found


func _process(delta: float) -> void :

	if Hud.current != null and not Hud.current.widgets.has("people"):
		Hud.current.add_widget("people", HudPeople.new())
	if triage:
		_place_tags()
	if Net.is_client():
		if not _mirror.is_empty():
			_place_tags()
		return
	for player: Variant in _carrying.keys():
		if not is_instance_valid(player):
			_carrying.erase(player)
			continue
		var victim: Victim = _carrying[player]
		if player.seat != null:

			_drop(player)
			Game.notify(Text.m("calls.victims.putDownToBoard"), "", player)
		elif player.holding != "carry":

			_drop(player)
		else:
			_stood[player] = [player.root_position(), player.facing()]
			_carry_step(victim, player)
	for victim: Victim in victims:
		if victim.state == "walking":
			_walk_step(victim, delta)




func _carry_step(victim: Victim, player: Player) -> void :
	var want: = "board" if victim.on_board else ("drag" if _smoky(player) else "carry")
	var now: = Game.now()
	if want == victim.mode:
		victim.mode_since = now
	elif now - victim.mode_since >= float(settings()["Drag"]["Settle"]):
		victim.mode = want
		victim.mode_since = now
		_hang_carried(victim)
		Game.notify(Text.m("calls.victims.dragging" if want == "drag" else "calls.victims.carrying"), "", player)
	if is_instance_valid(victim.helper) and not _helped(victim):
		var helper: = victim.helper
		_end_help(victim)
		Game.notify(Text.m("calls.victims.helpLost"), "warning", helper)
	_pace(victim)



func _walk_step(victim: Victim, delta: float) -> void :
	var zone: Variant = _ambulance().zone_position() if _ambulance() else null
	if not zone is Vector3 or not is_instance_valid(victim.figure):
		return
	var at: = victim.figure.global_position
	var to: Vector3 = zone - at
	to.y = 0.0
	if to.length() < 0.5:
		return
	var stride: = minf(float(settings()["Triage"]["WalkSpeed"]) * delta, to.length())
	var ahead: = to.normalized()
	var next: = at + ahead * stride
	var ground: = Game.world.raycast(next + Vector3(0, 3, 0), next + Vector3(0, -8, 0), World.LAYER_SOLID)
	if not ground.is_empty():
		next.y = float(ground["position"].y) + Figure.ROOT_HEIGHT
	victim.figure.global_transform = Transform3D(Basis.looking_at(ahead), next)
