class_name FocusRim
extends Node3D








const LOOK_EVERY: = 0.1

const COLORS: = {"use": Ui.YELLOW, "water": Ui.BLUE, "rescue": Ui.GREEN, "hazard": Ui.AMBER, "force": Ui.AMBER}

const FORCE_KEYS: = ["calls.door.force", "world.padlock.cut"]

const FORCE_BEAT: = 2.0

static var current: FocusRim

var _since: = 0.0
var _prompt: Prompt
var _rimmed: Array[GeometryInstance3D] = []
var _ring: MeshInstance3D
var _rim_material: ShaderMaterial
var _ring_material: ShaderMaterial
var code: = ""
var rimmed_count: = 0


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	_rim_material = ShaderMaterial.new()
	_rim_material.shader = load("res://shaders/focus_rim.gdshader")
	_ring_material = ShaderMaterial.new()
	_ring_material.shader = load("res://shaders/focus_ring.gdshader")
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE * float(Config.Art.Focus.Ring)
	_ring = MeshInstance3D.new()
	_ring.mesh = quad
	_ring.material_override = _ring_material
	_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_ring.visible = false
	add_child(_ring)


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var player: = Game.local_player
	var prompt: Prompt = null
	if player != null and bool(Config.Art.Focus.On) and is_instance_valid(player.prompt) and player.prompt.is_inside_tree():
		prompt = player.prompt

	if prompt != _prompt or (prompt != null and code_of(prompt) != code):
		_clear()
		_prompt = prompt
		if prompt != null:
			_light(prompt)
	if _prompt != null and _ring.visible:
		_ring.global_position = _prompt.hand_point()



static func code_of(prompt: Prompt) -> String:
	if prompt.net_id.begins_with("victim."):
		return "rescue"
	if prompt.action is Dictionary and String((prompt.action as Dictionary).get("k", "")) in FORCE_KEYS:
		return "force"
	var words: = ""
	for said: Variant in [prompt.object, prompt.action]:
		if said is Dictionary:
			words += String(said.get("k", "")) + " "
		else:
			words += str(said) + " "
	var codes: Dictionary = Config.Art.Focus.Codes
	for kind: String in codes:
		for bit: String in codes[kind]:
			if words.contains(bit):
				return kind
	return "use"


func _light(prompt: Prompt) -> void :
	var look: Dictionary = Config.Art.Focus
	code = code_of(prompt)
	var tint: Color = COLORS[code]
	var rate: = float(look["Pulse"]) * (FORCE_BEAT if code == "force" else 1.0)
	_rim_material.set_shader_parameter("tint", tint)
	_ring_material.set_shader_parameter("tint", tint)
	_rim_material.set_shader_parameter("pulse_rate", rate)
	_ring_material.set_shader_parameter("pulse_rate", rate)
	var found: = _meshes_of(prompt)
	for mesh in found:
		mesh.material_overlay = _rim_material
		_rimmed.append(mesh)
	rimmed_count = _rimmed.size()
	_ring.visible = _rimmed.is_empty()
	if _ring.visible:
		_ring.global_position = prompt.hand_point()


func _clear() -> void :
	for mesh in _rimmed:
		if is_instance_valid(mesh) and mesh.material_overlay == _rim_material:
			mesh.material_overlay = null
	_rimmed.clear()
	rimmed_count = 0
	_ring.visible = false
	code = ""




func _meshes_of(prompt: Prompt) -> Array[GeometryInstance3D]:
	var look: Dictionary = Config.Art.Focus
	var reach: = float(look["Reach"])
	var biggest: = float(look["Biggest"])
	var most: = int(look["Most"])
	var at: = prompt.hand_point()
	var found: Array[GeometryInstance3D] = []
	var start: Node = prompt.get_parent()
	for step in 2:
		if start == null or not (start is Node3D):
			break
		_search(start, at, reach, biggest, most, found)
		if not found.is_empty():
			break
		start = start.get_parent()
	return found


func _search(start: Node, at: Vector3, reach: float, biggest: float, most: int, found: Array[GeometryInstance3D]) -> void :
	var queue: Array[Node] = [start]
	var looked: = 0
	while not queue.is_empty() and looked < 200 and found.size() < most:
		var node: Node = queue.pop_front()
		looked += 1
		if node is MeshInstance3D and (node as MeshInstance3D).visible and node != _ring:
			var mesh: = node as MeshInstance3D
			if mesh.mesh != null and mesh.material_overlay == null:
				var box: = mesh.global_transform * mesh.get_aabb()
				if box.get_longest_axis_size() <= biggest and box.get_center().distance_to(at) <= reach:
					found.append(mesh)
		for child in node.get_children():
			if child is Node3D and not (child is GPUParticles3D) and not (child is Prompt):
				queue.append(child)
