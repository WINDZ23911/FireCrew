class_name JobBystanders
extends CrewJob




func _init(at: Vector3) -> void :
	kind = "bystanders"
	role = "safety"
	target = at


func place() -> Vector3:
	return target


func run() -> bool:
	var crowd: = Bystanders.current
	if crowd == null:
		return fail("crew.say.nothingThere")
	var held: = who.token()
	var middle: Vector3 = Game.incident.get("pos", target)
	var away: = Vector3(target.x - middle.x, 0, target.z - middle.z)
	away = away.normalized() if away.length() > 1.0 else Vector3(1, 0, 0)
	for step in 3:
		var spot: Vector3 = target - away * (6.0 - step * 3.0) + away.cross(Vector3.UP) * (step - 1) * 6.0
		await who.go(who.service.ground(spot + Vector3(0, 2, 0)), 2.5, 30.0)
		who.look = who.body.global_position + away * 20.0
		if not await who.wait(0.4, held):
			return false
		crowd.command(who.body)
		if not await who.wait(float(Config.Life.MoveBackEvery) + 0.2, held):
			return false
	return true
