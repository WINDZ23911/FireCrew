extends Node
















const QUEUE_MOST: = 10
const TIMEOUT: = 5.0
const END_WAIT: = 1.0

var url: = ""
var beat_seconds: = 60.0
var _run: = ""
var _began: = false
var _playing: = false
var _ended: = false
var _mode: = "menu"
var _since: = 0.0
var _beat: = 0.0
var _check: = 0.0
var _http: HTTPRequest
var _queue: Array[Dictionary] = []
var _busy: = false
var _failed_once: = false


func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	var telemetry: Variant = Config.get("Telemetry")
	var given: = ""
	var off: = false
	if telemetry is Dictionary:
		url = str(telemetry.get("Url", ""))
		beat_seconds = float(telemetry.get("BeatSeconds", beat_seconds))
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--telemetry="):
			given = arg.substr(12)
		elif arg.begins_with("--telemetry-beat="):
			beat_seconds = maxf(1.0, float(arg.substr(17)))
		elif arg == "--no-telemetry":
			off = true
	if not given.is_empty():
		url = given
	elif OS.get_cmdline_user_args().has("--no-save") or OS.has_feature("editor"):
		url = ""
	if off:
		url = ""
	_run = Crypto.new().generate_random_bytes(8).hex_encode()
	_http = HTTPRequest.new()
	_http.timeout = TIMEOUT
	_http.use_threads = true
	_http.request_completed.connect(_on_posted)
	add_child(_http)



func begin(playing: bool) -> void :
	if _began:
		return
	_began = true
	_playing = playing
	_mode = _current_mode()
	_send("start", 0)



func in_play() -> void :
	_playing = true
	_check_mode()



func end() -> void :
	if not _began or _ended:
		return
	_ended = true
	_send("end", roundi(_since))
	var waited: = 0.0
	while (_busy or not _queue.is_empty()) and waited < END_WAIT:
		await get_tree().process_frame
		waited += get_process_delta_time()


func _process(delta: float) -> void :
	if not _began or _ended:
		return
	_since += delta
	_beat += delta
	_check += delta
	if _check >= 1.0:
		_check = 0.0
		_check_mode()
	if _beat >= beat_seconds:
		_beat = 0.0
		_send("beat", roundi(_since))


func _current_mode() -> String:
	if not _playing:
		return "menu"
	if Net.is_client():
		return "client"
	return "host" if Net.active() else "single"


func _check_mode() -> void :
	var now: = _current_mode()
	if now == _mode or not _began or _ended:
		return
	_send("mode", roundi(_since), now)
	_mode = now


func _send(event: String, seconds: int, to: = "") -> void :
	_since = 0.0
	if url.is_empty() or not Settings.usage_stats:
		return
	if Settings.telemetry_id.is_empty():
		Settings.telemetry_id = Crypto.new().generate_random_bytes(16).hex_encode()
		Settings.save()
	var body: = {
		"id": Settings.telemetry_id, "s": _run, "ev": event, "mode": _mode, "sec": seconds, 
		"v": Net.version(), "os": OS.get_name(), "map": Edition.id(), "lang": Text.language, 
		"players": maxi(1, Net.players.size()) if Net.active() else 1, 
	}
	if not to.is_empty():
		body["to"] = to
	if _queue.size() >= QUEUE_MOST:
		_queue.pop_front()
	_queue.append(body)
	_next()


func _next() -> void :
	if _busy or _queue.is_empty():
		return
	var body: Dictionary = _queue.pop_front()
	if _http.request(url, ["Content-Type: application/json"], HTTPClient.METHOD_POST, JSON.stringify(body)) == OK:
		_busy = true
	else:
		_failed()
		_next.call_deferred()


func _on_posted(result: int, code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void :
	_busy = false
	if result != HTTPRequest.RESULT_SUCCESS or code >= 400:
		_failed()
	_next()


func _failed() -> void :
	if not _failed_once:
		_failed_once = true
		print("Telemetry: could not reach %s (the stats are dropped; the game goes on)" % url)
