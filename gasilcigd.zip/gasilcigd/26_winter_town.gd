extends RefCounted



static func start(main: Node) -> void :
	var town: = WinterTown.new()
	town.name = "WinterTown"
	main.add_child(town)
