class_name JobDrive
extends CrewJob







const LOOK_NEAR: = 9.0
const LOOK_FAR: = 26.0
const TOP: = 52.0
const CORNER: = 22.0
const STOP_SHORT: = 28.0
const CONVOY_GAP: = 30.0

var vehicle: Vehicle
var mode: = "call"
var goal: = Vector3.INF
var _path: Array[Vector3] = []
var _along: = 0
const ARRIVED: = 14.0
var _stuck_since: = -1.0
var _backing_until: = 0.0
var _replan_at: = 0.0


func _init(truck: Vehicle, how: = "call", to: = Vector3.INF) -> void :
	kind = "drive"
	role = "pump"
	vehicle = truck
	mode = how
	goal = to


func title() -> Variant:
	return Text.m("crew.jobs.drive." + mode)


func place() -> Vector3:
	return vehicle.global_position


func suits(member: Crewman) -> bool:
	var seated: Variant = member.body.get_attr("Vehicle")
	return seated == null or seated == vehicle


func run() -> bool:
	var held: = who.token()

	if who.body.get_attr("Vehicle") != vehicle or vehicle.driver() != who.body:
		if vehicle.driver() != null and vehicle.driver() != who.body:
			return fail("crew.say.taken")
		if who.body.seat != null:
			var other: Variant = who.body.get_attr("Vehicle")
			if other is Vehicle:
				other.leave(who.body)
			await who.wait(0.3, held)
		CrewKit.stow_all(who)
		if not await who.go(who.service.door_spot(vehicle, "DoorCabLeft"), 2.5, 60.0):
			return fail("crew.say.stuck")
		if vehicle.driver() != null:
			return fail("crew.say.taken")
		vehicle._board(who.body, "DoorCabLeft")
		if vehicle.driver() != who.body:
			return fail("crew.say.cannot")
		await who.wait(0.6, held)

	var waiting: = Game.now()
	while on(held) and Game.now() - waiting < 15.0:
		var coming: = false
		for mind in who.service.members:
			if mind.job is JobBoard and mind.job.target == vehicle:
				coming = true
		if not coming:
			break
		await who.wait(0.5, held)

	if mode == "follow":
		var since: = Game.now()
		while on(held) and Game.now() - since < 600.0:
			var lead: = who.commander()
			if lead == null or lead.get_attr("Vehicle") != null or vehicle.global_position.distance_to(lead.global_position) > 60.0:
				break
			await who.wait(0.5, held)

	_open_bay()
	if mode == "call" or (mode == "follow" and not Game.incident.is_empty()):
		vehicle.blue_on = true
		vehicle.siren = 1
		vehicle.headlights_on = Game.night
	var started: = Game.now()
	while on(held):
		var target: = _target()
		if target == Vector3.INF:
			break
		if _path.is_empty() or Game.now() > _replan_at:
			_plan(target)
		var left: = _left_on_path()
		if mode == "follow":
			var lead: = who.commander()
			var gap: = vehicle.global_position.distance_to(lead.global_position)
			if lead.get_attr("Vehicle") == null and gap < 60.0:
				break
			left = maxf(0.0, gap - CONVOY_GAP)
		elif left < 6.0 and absf(vehicle.forward_speed) < 2.0:
			break
		elif mode == "here" and Vector2(vehicle.global_position.x - target.x, vehicle.global_position.z - target.z).length() < ARRIVED:
			break
		_steer(left)
		if Game.now() - started > 420.0:
			break
		await who.tick()
	who.drive_input = 0.0
	who.steer_input = 0.0

	var settle: = Game.now()
	while absf(vehicle.forward_speed) > 1.0 and Game.now() - settle < 6.0:
		who.drive_input = -0.6
		await who.tick()
	who.drive_input = 0.0
	vehicle.siren = 0
	if not on(held):
		return false
	await who.wait(0.5, held)
	vehicle.leave(who.body)
	who.mode = "auto" if who.service.auto and not Game.incident.is_empty() else "follow"
	return true


func finish(_done: bool) -> void :
	who.drive_input = 0.0
	who.steer_input = 0.0


func _target() -> Vector3:
	match mode:
		"call":
			var at: Variant = Game.incident.get("pos")
			return at if at is Vector3 else (goal if goal != Vector3.INF else Vector3.INF)
		"follow":
			var lead: = who.commander()
			return lead.global_position if lead != null else Vector3.INF
	return goal




func _plan(to: Vector3) -> void :
	_replan_at = Game.now() + (2.0 if mode == "follow" else 20.0)
	_path.clear()
	_along = 0
	var graph: = NavGraph.current
	var here: = vehicle.global_position
	var forward: = - vehicle.global_basis.z
	if graph == null:
		_path.append(to)
		return
	var start: Array = graph.nearest_lane(here.x, here.z, func(segment: Dictionary) -> bool: return _heading_ok(segment, here, forward))
	var finish: Array = graph.nearest_lane(to.x, to.z)
	if start[0] < 0 or finish[0] < 0:
		_path.append(to)
		return
	var route: = graph.drive_route(start[0], finish[0], {}, Guide._cost)
	if route.is_empty():
		_path.append(to)
		return

	if float(start[2]) > 6.0:


		var wheelbase: = float(vehicle.data.get("rearAxle", 7.6)) - float(vehicle.data.get("frontAxle", -8.7))
		var longer: = maxf(0.0, wheelbase - 17.4) + maxf(0.0, float(vehicle.data.get("rear", 14.0)) - 16.0)\
		+ maxf(0.0, - float(vehicle.data.get("frontAxle", -8.7)) - 8.8)
		if longer > 0.0:
			_path.append(here)
		_path.append(here + forward * minf(float(start[2]) + 6.0 + longer, 30.0 + longer))
	var to_along: float = finish[1]
	if mode == "call":
		to_along = maxf(0.0, to_along - STOP_SHORT)
	for index in route.size():
		var segment: Dictionary = graph.segments[route[index]]
		var length: float = segment["length"]
		var first: float = start[1] if index == 0 else 0.0
		var last: float = minf(to_along, length) if index == route.size() - 1 else length
		var along: = first
		while along < last:
			var s: = NavGraph.sample(segment, along)
			_path.append(Vector3(s.x, here.y, s.y))
			along += 6.0
		var end_point: = NavGraph.sample(segment, last)
		_path.append(Vector3(end_point.x, here.y, end_point.y))
	if mode == "here":
		_path.append(to)



func _heading_ok(segment: Dictionary, here: Vector3, forward: Vector3) -> bool:
	if segment["kind"] != "lane":
		return false
	var found: = NavGraph.sample(segment, 0.0)
	var dx: float = found.z
	var dz: float = found.w
	return Vector2(dx, dz).dot(Vector2(forward.x, forward.z)) > -0.2 or Vector2(found.x - here.x, found.y - here.z).length() > 40.0


func _left_on_path() -> float:
	if _path.is_empty():
		return 0.0
	var here: = Vector3(vehicle.global_position.x, 0, vehicle.global_position.z)


	var best: = _along
	var best_distance: = INF
	for index in range(_along, mini(_along + 24, _path.size() - 1)):
		var a: = Vector3(_path[index].x, 0, _path[index].z)
		var b: = Vector3(_path[index + 1].x, 0, _path[index + 1].z)
		var piece: = b - a
		var t: = clampf((here - a).dot(piece) / maxf(piece.length_squared(), 0.0001), 0.0, 1.0)
		var distance: = here.distance_to(a + piece * t)
		if distance < best_distance - 0.5:
			best_distance = distance
			best = index
	_along = best
	var nearest_a: = Vector3(_path[_along].x, 0, _path[_along].z)
	var left: = 0.0
	if _along < _path.size() - 1:
		var next: = Vector3(_path[_along + 1].x, 0, _path[_along + 1].z)
		left = here.distance_to(next)
		for index in range(_along + 1, _path.size() - 1):
			left += Vector3(_path[index + 1].x - _path[index].x, 0, _path[index + 1].z - _path[index].z).length()
	else:
		left = here.distance_to(nearest_a)
	return left



func _ahead(distance: float) -> Vector3:
	var here: = Vector3(vehicle.global_position.x, 0, vehicle.global_position.z)
	if _along >= _path.size() - 1:
		return Vector3(_path[_path.size() - 1].x, 0, _path[_path.size() - 1].z)

	var a: = Vector3(_path[_along].x, 0, _path[_along].z)
	var b: = Vector3(_path[_along + 1].x, 0, _path[_along + 1].z)
	var piece: = b - a
	var t: = clampf((here - a).dot(piece) / maxf(piece.length_squared(), 0.0001), 0.0, 1.0)
	var from: = a + piece * t
	var left: = distance
	for index in range(_along + 1, _path.size()):
		var point: = Vector3(_path[index].x, 0, _path[index].z)
		var span: = from.distance_to(point)
		if span >= left:
			return from + (point - from).normalized() * left
		left -= span
		from = point
	return Vector3(_path[_path.size() - 1].x, 0, _path[_path.size() - 1].z)


func _steer(left: float) -> void :
	var speed: = absf(vehicle.forward_speed)
	var look: = clampf(speed * 0.55, LOOK_NEAR, LOOK_FAR)
	var point: = _ahead(look)
	var local: = vehicle.global_transform.affine_inverse() * Vector3(point.x, vehicle.global_position.y, point.z)
	var angle: = atan2(local.x, - local.z)

	var further: = vehicle.global_transform.affine_inverse() * Vector3(_ahead(look * 2.5).x, vehicle.global_position.y, _ahead(look * 2.5).z)
	var bend: = absf(atan2(further.x, - further.z))
	var wanted: = TOP
	if bend > 0.05:
		var radius: = look * 2.5 / (2.0 * sin(minf(bend, 1.4)))
		wanted = minf(wanted, sqrt(CORNER * radius) + 4.0)
	wanted = minf(wanted, sqrt(2.0 * 18.0 * maxf(left, 0.0)) + 2.0)
	if absf(angle) > 0.9:
		wanted = minf(wanted, 10.0)
	wanted = minf(wanted, _clear_ahead())
	var now: = Game.now()
	if now < _backing_until:
		who.drive_input = -1.0
		who.steer_input = - signf(angle) if absf(angle) > 0.1 else 0.0
		return
	who.steer_input = clampf(angle * 2.2, -1.0, 1.0)
	var difference: = wanted - vehicle.forward_speed
	if wanted < 0.5:
		who.drive_input = -0.8 if vehicle.forward_speed > 0.5 else 0.0
	else:
		who.drive_input = clampf(difference * 0.15, -1.0, 1.0)
		if who.drive_input < 0.0 and vehicle.forward_speed < 1.0:
			who.drive_input = 0.0

	if wanted > 3.0 and speed < 1.0:
		if _stuck_since < 0.0:
			_stuck_since = now
		elif now - _stuck_since > 4.0:
			_stuck_since = -1.0
			if not who.service.seen(vehicle.global_position) and _along < _path.size() - 2:
				_skip()
			else:
				_backing_until = now + 1.6
	else:
		_stuck_since = -1.0



func _clear_ahead() -> float:
	var forward: = - vehicle.global_basis.z
	var nose: = vehicle.global_transform * Vector3(0, 3.0, float(vehicle.data.get("frontAxle", -7.0)) - 3.0)
	var reach: = 8.0 + absf(vehicle.forward_speed) * 1.2
	var nearest: = reach
	for side: float in [-2.2, 0.0, 2.2]:
		var from: = nose + vehicle.global_basis.x * side
		var hit: = Game.world.raycast(from, from + forward * reach, World.LAYER_VEHICLE | World.LAYER_PLAYER | World.LAYER_PROP, [vehicle.get_rid()])
		if not hit.is_empty():
			nearest = minf(nearest, from.distance_to(hit["position"]))
	if nearest >= reach:
		return TOP
	return maxf(0.0, (nearest - 5.0) * 1.2)



func _skip() -> void :
	var index: = mini(_along + 3, _path.size() - 1)
	var at: = _path[index]
	var next: = _path[mini(index + 1, _path.size() - 1)]
	var way: = Vector3(next.x - at.x, 0, next.z - at.z)
	if way.length() < 0.1:
		way = - vehicle.global_basis.z
	var ground: = who.service.ground(at + Vector3(0, 6, 0))
	vehicle.global_transform = Transform3D(Basis.looking_at(way.normalized()), ground + Vector3(0, float(vehicle.spec["spawn"].origin.y), 0))
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.reset_physics_interpolation()
	_along = index




func _open_bay() -> void :
	var station: = Game.station
	var bay: = int(vehicle.spec.get("bay", 0))
	if station == null or bay < 1 or bay > station.doors.size():
		return
	if vehicle.global_position.distance_to(station.door_position) <= float(Config.Truck.DoorRemoteRange) and not station.door_open(bay):
		station.set_door(bay, true)
