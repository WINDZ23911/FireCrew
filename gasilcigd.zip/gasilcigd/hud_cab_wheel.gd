class_name HudCabWheel
extends Control








const ITEM: = Vector2(206, 50)
const TAP: = 0.3

static var current: HudCabWheel

var _open: = false
var _sticky: = false
var _opened_at: = 0.0
var _chosen: = -1
var _pointer: = Vector2.ZERO
var _vehicle: Vehicle
var _options: Array = []
var _wheel: Control
var _middle: Label
var _middle_caps: Label
var _items: Array[Control] = []
var opened_count: = 0


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wheel = Control.new()
	_wheel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wheel.visible = false
	add_child(_wheel)
	var middle: = Ui.plate(Vector2(170, 58))
	middle.position = Vector2(-85, -29)
	_wheel.add_child(middle)
	_middle_caps = Ui.caps("", 11)
	_middle_caps.position = Vector2(0, 6)
	_middle_caps.size = Vector2(170, 14)
	_middle_caps.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_middle_caps.modulate = Ui.DIM
	middle.add_child(_middle_caps)
	_middle = Ui.display("", 20, Ui.YELLOW)
	_middle.position = Vector2(4, 20)
	_middle.size = Vector2(162, 32)
	_middle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_middle.clip_text = true
	middle.add_child(_middle)


func _exit_tree() -> void :
	if current == self:
		current = null


func is_open() -> bool:
	return _open




func _seated() -> Vehicle:
	var me: = Game.local_player
	if me == null or me.seat == null or me.camera == null or me.health <= 0.0:
		return null
	if LadderService.current and LadderService.current.controller == me:
		return null
	if TruckRoof.current and TruckRoof.current.operating(me):
		return null
	var vehicle: Variant = me.get_attr("Vehicle")
	return vehicle if vehicle is Vehicle and is_instance_valid(vehicle) else null


func _process(_delta: float) -> void :
	if not _open:
		if not Settings.simple() or Game.ui_open:
			return
		var vehicle: = _seated()
		if vehicle != null and Game.local_player.camera.captured and Input.is_action_just_pressed("interact"):
			show_for(vehicle)
		return
	if _seated() != _vehicle:
		_close()
		return
	if not _sticky and not Input.is_action_pressed("interact"):
		if Game.now() - _opened_at < TAP and _chosen < 0:
			_sticky = true
		else:
			_do()
			return
	_paint()


func _input(event: InputEvent) -> void :
	if not _open:
		return
	if event is InputEventMouseMotion:
		_pointer = (_pointer + event.relative).limit_length(120.0)
		if _pointer.length() > 30.0:
			var angle: = fposmod(atan2(_pointer.y, _pointer.x / float(Config.Talk.RadioStretch)) + PI / 2.0, TAU)
			_chosen = int(roundf(angle / TAU * _options.size())) % _options.size()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_do()
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			_close()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("pause"):
		_close()
		get_viewport().set_input_as_handled()
	elif _sticky and event.is_action_pressed("interact"):
		_do()
		get_viewport().set_input_as_handled()
	else:
		for index in mini(_options.size(), MenuKit.KEYS.size()):
			if event.is_action_pressed(MenuKit.KEYS[index]):
				_chosen = index
				_do()
				get_viewport().set_input_as_handled()
				return



func options_for(vehicle: Vehicle) -> Array:
	var out: Array = []
	var me: = Game.local_player
	if vehicle.driver() == me:
		out.append({"id": "blue", "text": Text.m("hud.truck.blueLights"), "on": vehicle.blue_on, "key": "veh_blue"})
		if vehicle.siren != 0:
			out.append({"id": "siren_next", "text": Text.f("hud.truck.siren", [vehicle.siren_name()]), "on": true, "key": "veh_siren"})
			out.append({"id": "siren_off", "text": Text.m("hud.cab.sirenOff"), "on": false, "key": "veh_siren"})
		else:
			out.append({"id": "siren_next", "text": Text.m("hud.cab.sirenOn"), "on": false, "key": "veh_siren"})
		out.append({"id": "headlights", "text": Text.m("hud.truck.headlights"), "on": vehicle.headlights_on, "key": "veh_headlights"})
		if vehicle.has_arrows():
			out.append({"id": "arrows", "text": Text.m(["hud.truck.arrows", "hud.truck.arrowsLeft", "hud.truck.arrowsRight"][vehicle.arrows]), "on": vehicle.arrows != 0, "key": "veh_arrows"})
		if vehicle.data.has("mast"):
			var truck: Variant = Hud.current.widgets.get("truck") if Hud.current else null
			var up: bool = truck is HudTruck and (truck as HudTruck)._mast_up(vehicle)
			out.append({"id": "mast", "text": Text.m("hud.truck.mast"), "on": up, "key": "mast"})
		if int(vehicle.spec.get("bay", 0)) > 0:
			out.append({"id": "bay", "text": Text.m("hud.truck.door"), "on": false, "key": "veh_door"})
	out.append({"id": "exit", "text": Text.m("ui.actions.veh_exit"), "on": false, "key": "veh_exit"})
	return out


func show_for(vehicle: Vehicle) -> void :
	_vehicle = vehicle
	_options = options_for(vehicle)
	_open = true
	_sticky = false
	_opened_at = Game.now()
	_chosen = -1
	_pointer = Vector2.ZERO
	opened_count += 1
	for item in _items:
		item.queue_free()
	_items.clear()
	var radius: = float(Config.Talk.RadioRadius)
	for index in _options.size():
		var option: Dictionary = _options[index]
		var item: = Ui.plate(ITEM)
		var angle: = TAU * index / _options.size() - PI / 2.0
		item.position = Vector2(cos(angle) * radius * float(Config.Talk.RadioStretch), sin(angle) * radius) - ITEM / 2.0
		var lamp: = Ui.icon("dot", 14, Ui.YELLOW if option["on"] else Ui.INSET)
		lamp.position = Vector2(12, 18)
		item.add_child(lamp)
		var words: = Ui.display(Text.say(option["text"]).to_upper(), 18)
		words.position = Vector2(34, 3)
		words.size = Vector2(ITEM.x - 42, 28)
		words.clip_text = true
		words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		item.add_child(words)
		var key: = Ui.caps("%d  ·  %s" % [index + 1, Controls.bound_name(option["key"])], 11)
		key.position = Vector2(34, 30)
		key.modulate = Ui.DIM
		item.add_child(key)
		item.set_meta("words", words)
		_wheel.add_child(item)
		_items.append(item)
	_middle_caps.text = Text.say(Text.m("hud.cab.title")).to_upper()
	_middle.text = Text.say(Text.named("vehicles", vehicle.spec["name"])).to_upper()
	_wheel.visible = true
	_paint()
	Sounds.ui("ui_wheel_open")


func _paint() -> void :
	for index in _items.size():
		var lit: = index == _chosen
		_items[index].modulate = Color(1.15, 1.15, 1.0) if lit else Color(1, 1, 1, 0.85)
		var words: Label = _items[index].get_meta("words")
		words.add_theme_color_override("font_color", Ui.YELLOW if lit else Ui.TEXT)



func _do() -> void :
	var vehicle: = _vehicle
	var id: String = _options[_chosen]["id"] if _chosen >= 0 and _chosen < _options.size() else ""
	_close()
	if id == "" or vehicle == null or not is_instance_valid(vehicle):
		return
	Sounds.ui("ui_click")
	if id == "bay":
		HudTruck.bay_door(vehicle)
	else:
		vehicle.cab_command(id)



func choose(id: String) -> bool:
	for index in _options.size():
		if _options[index]["id"] == id:
			_chosen = index
			_do()
			return true
	return false


func _close() -> void :
	if not _open:
		return
	_open = false
	_sticky = false
	_wheel.visible = false
	Sounds.ui("ui_wheel_close")
