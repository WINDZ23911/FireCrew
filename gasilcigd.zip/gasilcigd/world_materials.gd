class_name WorldMaterials
extends RefCounted








const LOOKS: = {
	"Plastic": [0.6, 0.0, 0.0, 8.0], 
	"SmoothPlastic": [0.5, 0.0, 0.0, 8.0], 
	"Concrete": [0.9, 0.0, 0.4, 12.0], 
	"Metal": [0.38, 0.75, 0.3, 10.0], 
	"Glass": [0.08, 0.2, 0.0, 8.0], 
	"LeafyGrass": [0.95, 0.0, 0.5, 9.0], 
	"Wood": [0.75, 0.0, 0.6, 9.0], 
	"WoodPlanks": [0.78, 0.0, 0.8, 10.0], 
	"Siding": [0.7, 0.0, 0.75, 10.0], 
	"Grass": [1.0, 0.0, 0.75, 18.0], 
	"Asphalt": [0.92, 0.0, 0.7, 16.0], 
	"DiamondPlate": [0.45, 0.8, 0.7, 4.0], 
	"Plaster": [0.95, 0.0, 0.38, 12.0], 
	"Rubber": [0.85, 0.0, 0.15, 6.0], 
	"Fabric": [1.0, 0.0, 0.5, 4.0], 
	"Pavement": [0.9, 0.0, 0.8, 12.0], 
	"Cobblestone": [0.85, 0.0, 0.9, 9.0], 
	"Ground": [1.0, 0.0, 0.7, 16.0], 
	"Pebble": [0.9, 0.0, 0.85, 8.0], 
	"ClayRoofTiles": [0.8, 0.0, 0.9, 7.0], 
	"Brick": [0.9, 0.0, 0.9, 8.0], 
	"Sand": [1.0, 0.0, 0.5, 10.0], 
	"Slate": [0.7, 0.0, 0.7, 8.0], 
	"Granite": [0.6, 0.0, 0.6, 8.0], 
	"Marble": [0.3, 0.0, 0.4, 12.0], 
	"Ice": [0.1, 0.0, 0.2, 8.0], 
	"CorrodedMetal": [0.8, 0.5, 0.8, 8.0], 
	"Foil": [0.2, 1.0, 0.1, 8.0], 
	"ForceField": [0.3, 0.0, 0.0, 8.0], 
	"Neon": [1.0, 0.0, 0.0, 8.0], 
}


const WEAR: = {
	"Asphalt": [0.42, 0.0], 
	"Pavement": [0.3, 0.0], 
	"Concrete": [0.28, 0.22], 
	"Cobblestone": [0.3, 0.0], 
	"Plaster": [0.11, 0.34], 
	"Brick": [0.15, 0.25], 
	"ClayRoofTiles": [0.32, 0.0], 
	"Slate": [0.25, 0.0], 
	"Grass": [0.35, 0.0], 
	"LeafyGrass": [0.3, 0.0], 
	"Ground": [0.3, 0.0], 
	"Wood": [0.15, 0.12], 
	"WoodPlanks": [0.2, 0.15], 
	"Siding": [0.14, 0.2], 
	"CorrodedMetal": [0.3, 0.0], 
}



const GROUND: = ["Grass", "LeafyGrass", "Ground", "Asphalt", "Pavement", "Concrete", "Cobblestone", "Sand", "Pebble"]


const EVEN: = ["Asphalt", "Pavement", "Grass", "LeafyGrass", "Ground", "Sand", "Glass", "Neon", "ForceField", "Ice"]

const FADES: = ["Plaster", "Concrete", "Brick", "Wood", "WoodPlanks", "Siding", "ClayRoofTiles", "Slate", "Plastic", "SmoothPlastic", "Fabric"]

const ASPHALT_VALUE: = Vector3(1.35, 1.42, 1.55)


const ASPHALT_DUSK: = Vector3(1.55, 1.45, 1.2)

const SNOWY: = {
	"Asphalt": 0.12, "Pavement": 0.4, "Cobblestone": 0.5, "Concrete": 0.65, "Glass": 0.0, "Metal": 0.7, 
	"DiamondPlate": 0.5, "Foil": 0.0, "ForceField": 0.0, "Ice": 0.0, "Neon": 0.0, "ClayRoofTiles": 1.0, 
	"Slate": 1.0, "Grass": 1.0, "Ground": 1.0, "Sand": 0.95, 
}

static var _cache: Dictionary = {}
static var _macro: NoiseTexture2D
static var _shader: Shader
static var _neon: Shader




static func of(material: String, transparent: = false, baked: = false, sway: = 0.0, rooms: = true) -> Material:
	var key: = "%s|%s|%s|%s|%s" % [material, transparent, baked, sway, rooms and material == "Glass"]
	if _cache.has(key):
		return _cache[key]
	var made: Material
	if material == "Neon":
		made = _make_neon(transparent)
	else:
		made = _make(material, transparent, baked)
		if sway > 0.0 and not transparent:


			made.shader = load("res://shaders/part_leaves.gdshader")
			made.set_shader_parameter("sway", sway)
			made.set_shader_parameter("macro", macro_noise())
			made.set_shader_parameter("crown_cool", float(Config.Art.Crowns))
			made.set_shader_parameter("night_grey", float(Config.Art.Lawn.NightGrey))
			made.set_shader_parameter("weathers", 0.0)
			made.set_shader_parameter("liftable", 0.0)


			made.set_shader_parameter("leafy", 1.0 if is_equal_approx(sway, World.SWAY_STUDS[2]) else 0.0)
			var art: Dictionary = Config.Art.Winter
			made.set_shader_parameter("twigs", Color(float(art["Twigs"][0]), float(art["Twigs"][1]), float(art["Twigs"][2])))
			made.set_shader_parameter("lace_near", lace_reach())
	if material == "Glass" and not rooms and made is ShaderMaterial:
		made.set_shader_parameter("interior", 0.0)
	_cache[key] = made
	return made


static func _make(material: String, transparent: bool, baked: = false) -> Material:
	if _shader == null:
		_shader = load("res://shaders/part.gdshader")
	var look: Array = LOOKS.get(material, LOOKS["Plastic"])
	var made: = ShaderMaterial.new()
	made.shader = _shader if not transparent else load("res://shaders/part_alpha.gdshader")
	made.set_shader_parameter("roughness", look[0])
	made.set_shader_parameter("metallic", look[1])
	var grain_path: = "res://assets/textures/materials/%s.png" % material
	if look[2] > 0.0 and ResourceLoader.exists(grain_path):
		made.set_shader_parameter("grain", load(grain_path))
		made.set_shader_parameter("grain_strength", look[2])
		made.set_shader_parameter("grain_scale", 1.0 / look[3])
	else:
		made.set_shader_parameter("grain_strength", 0.0)

	made.set_shader_parameter("baked", 1.0 if baked else 0.0)
	made.set_shader_parameter("liftable", 1.0 if material in GROUND else 0.0)
	made.set_shader_parameter("vary", 0.0 if material in EVEN else 1.0)
	made.set_shader_parameter("weathers", 1.0 if material in FADES else 0.0)
	if material == "Asphalt":
		made.set_shader_parameter("value", ASPHALT_VALUE)
		made.set_shader_parameter("dusk_value", ASPHALT_DUSK)
	if material == "Glass":
		made.set_shader_parameter("specular", 0.9)
		made.set_shader_parameter("interior", 1.0)
		made.set_shader_parameter("glassy", 1.0)
	if material in ["ClayRoofTiles", "Slate"]:
		made.set_shader_parameter("tiles", 1.0 if material == "ClayRoofTiles" else 0.6)

	made.set_shader_parameter("wettable", {"Glass": 0.0, "Metal": 0.4, "DiamondPlate": 0.5, "Foil": 0.0, "ForceField": 0.0}.get(material, 1.0))


	made.set_shader_parameter("snowy", SNOWY.get(material, 0.9))
	made.set_shader_parameter("grassy", 1.0 if material == "Grass" else 0.0)
	if material == "Grass":

		made.set_shader_parameter("sage", float(Config.Art.Lawn.Sage))
		made.set_shader_parameter("night_grey", float(Config.Art.Lawn.NightGrey))
	if material in ["Asphalt", "Pavement", "Concrete", "Cobblestone"]:
		made.set_shader_parameter("puddles", 1.0)
		made.set_shader_parameter("macro", macro_noise())
	var wear: Array = WEAR.get(material, [0.0, 0.0])
	if wear[0] > 0.0 or wear[1] > 0.0:
		made.set_shader_parameter("macro", macro_noise())
		made.set_shader_parameter("macro_strength", wear[0])
		made.set_shader_parameter("grime", wear[1])
	return made





static func crown(key: String, sway: float, leafy: float, twigs: Color) -> ShaderMaterial:
	if _cache.has(key):
		return _cache[key]
	var made: = _make("LeafyGrass", false) as ShaderMaterial
	made.shader = load("res://shaders/tree_crown.gdshader")
	made.set_shader_parameter("sway", sway)
	made.set_shader_parameter("macro", macro_noise())
	made.set_shader_parameter("crown_cool", float(Config.Art.Crowns))
	made.set_shader_parameter("night_grey", float(Config.Art.Lawn.NightGrey))
	made.set_shader_parameter("weathers", 0.0)
	made.set_shader_parameter("liftable", 0.0)
	made.set_shader_parameter("vary", 0.0)
	made.set_shader_parameter("grain_strength", 0.0)
	made.set_shader_parameter("leafy", leafy)
	made.set_shader_parameter("twigs", twigs)
	made.set_shader_parameter("lace_near", lace_reach())

	made.set_shader_parameter("snowy", 0.9 if leafy == 0.0 else 0.12)
	_cache[key] = made
	return made






static func far(ground: int, baked: bool) -> ShaderMaterial:
	var key: = "far|%s|%s" % [ground, baked]
	var hard: = ground == 1 or ground == 2
	if _cache.has(key):
		return _cache[key]
	if _shader == null:
		_shader = load("res://shaders/part.gdshader")
	var made: = ShaderMaterial.new()
	made.shader = _shader
	made.set_shader_parameter("roughness", 0.9)
	made.set_shader_parameter("grain_strength", 0.0)
	made.set_shader_parameter("vary", 0.0)
	made.set_shader_parameter("baked", 1.0 if baked else 0.0)
	made.set_shader_parameter("liftable", 1.0 if hard else 0.0)
	made.set_shader_parameter("snowy", 0.25 if hard else 0.9)
	made.set_shader_parameter("weathers", 0.0)
	if ground == 2:
		made.set_shader_parameter("value", ASPHALT_VALUE)
		made.set_shader_parameter("dusk_value", ASPHALT_DUSK)
	if ground == 3:
		made.set_shader_parameter("roughness", 0.1)
		made.set_shader_parameter("specular", 0.9)
		made.set_shader_parameter("snowy", 0.0)
		made.set_shader_parameter("wettable", 0.0)
	_cache[key] = made
	return made




static func lace_reach() -> float:
	return 0.0 if Settings.quality <= Graphics.LOW else float(Config.Art.Winter.LaceNear)



static func set_lace() -> void :
	for made: Variant in _cache.values():
		if made is ShaderMaterial and (made as ShaderMaterial).get_shader_parameter("leafy") == 1.0:
			(made as ShaderMaterial).set_shader_parameter("lace_near", lace_reach())



static func macro_noise() -> NoiseTexture2D:
	if _macro == null:
		var noise: = FastNoiseLite.new()
		noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		noise.frequency = 0.012
		noise.fractal_octaves = 4
		noise.seed = 23
		_macro = NoiseTexture2D.new()
		_macro.width = 512
		_macro.height = 512
		_macro.seamless = true
		_macro.generate_mipmaps = true
		_macro.noise = noise
	return _macro


static func _make_neon(transparent: bool) -> Material:
	if _neon == null:
		_neon = load("res://shaders/neon.gdshader")
	var made: = ShaderMaterial.new()
	made.shader = _neon
	return made
