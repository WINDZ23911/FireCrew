class_name IndustryZone
extends RefCounted













const SOUTH: = 1240.0
const OLD_SOUTH: = 1120.0
const ROAD_Z: = 1150.0
const ROAD_WIDTH: = 30.0
const PAVEMENT: = 8.0
const WEST_END: = -660.0
const EAST_END: = 545.0
const MAIN_NORTH: = Vector2(29.5, 1010.0)
const OLD_EXIT: = Vector2(-6.3, 1120.0)
const MAIN_WIDTH: = 40.0
const LOT_Z: = 1076.0
const YARD_BACK: = 1040.0
const YARD_FRONT: = 1127.0
const BYPASS_EDGE: = 1028.0
const SIDING_Z: = 1184.0
const SIDING_FROM: = -640.0
const SIDING_TO: = -175.0
const RAIL_TOP: = 1.0
const WEIGHT: = 9.5

const ASPHALT: = Color8(55, 55, 60)
const YARD_TAR: = Color8(68, 68, 72)
const PAVING: = Color8(176, 172, 164)
const KERB: = Color8(196, 194, 188)
const PAINT: = Color8(236, 236, 230)
const FENCE: = Color8(48, 82, 58)
const CONCRETE: = Color8(150, 150, 146)










const PLOTS: = [
	{"name": "Warehouse", "house": "Warehouse", "x": -570.0, "width": 150.0, "gates": [-40.0, 45.0], "lot": 1072.0, "back": 1036.0}, 
	{"name": "Metalworks", "house": "Metalworks", "x": -420.0, "width": 120.0, "gates": [-30.0], "lot": 1066.0, "back": 1032.0, "front": 1123.0}, 
	{"name": "TankFarm", "x": -300.0, "width": 96.0, "gates": [20.0]}, 
	{"name": "Sawmill", "house": "Sawmill", "x": -160.0, "width": 110.0, "gates": [30.0], "lot": 1068.0, "back": 1034.0}, 
	{"name": "Textile", "house": "TextileFactory", "x": 105.0, "width": 110.0, "gates": [-20.0], "lot": 1082.0, "front": 1122.0}, 
	{"name": "Substation", "x": 205.0, "width": 80.0, "gates": [-25.0]}, 
	{"name": "ColdStore", "house": "ColdStore", "x": 315.0, "width": 100.0, "gates": [32.0]}, 
	{"name": "Depot", "x": 455.0, "width": 140.0, "gates": [-40.0]}, 
]


static var places: Dictionary = {}
static var houses: Dictionary = {}



static func main_x(z: float) -> float:
	return OLD_EXIT.x + (z - OLD_EXIT.y) * (OLD_EXIT.x - MAIN_NORTH.x) / (OLD_EXIT.y - MAIN_NORTH.y)


static func junction() -> Vector2:
	return Vector2(main_x(ROAD_Z), ROAD_Z)



static func lot_z(plot: Dictionary) -> float:
	return float(plot.get("lot", LOT_Z))


static func back_z(plot: Dictionary) -> float:
	return float(plot.get("back", YARD_BACK))


static func front_z(plot: Dictionary) -> float:
	return float(plot.get("front", YARD_FRONT))



static func company(plot_name: String) -> Dictionary:
	var table: Dictionary = Edition.data().get("industry", {})
	return table.get(plot_name, {})






static func extend_layout(layout: Dictionary) -> void :
	if layout.get("industry", false) or Edition.skips("industry"):
		return
	layout["industry"] = true
	layout["bounds"]["maxZ"] = SOUTH
	var nodes: Array = layout["nodes"]
	var roads: Array = layout["roads"]

	var exit_index: = -1
	for index in nodes.size():
		var node: Dictionary = nodes[index]
		if node.get("kind") == "exit" and Vector2(node["x"], node["z"]).distance_to(OLD_EXIT) < 2.0:
			exit_index = index
	if exit_index < 0:
		push_warning("industry: the main road's way out south is not where it was; the zone has no roads")
		return
	var at: = junction()
	nodes[exit_index] = {"arms": 4, "control": "give_way", "kind": "junction", "x": at.x, "z": at.y}
	var number: = exit_index + 1
	for road: Dictionary in roads:
		for end: String in ["from", "to"]:
			if int(road[end]) == number:
				var points: Array = road["points"]
				var which: = 0 if end == "from" else points.size() - 1

				if Vector2(points[0][0], points[0][1]).distance_to(OLD_EXIT) > Vector2(points[-1][0], points[-1][1]).distance_to(OLD_EXIT):
					which = points.size() - 1
				points[which] = [at.x, at.y]
	nodes.append({"arms": 1, "kind": "exit", "x": main_x(SOUTH), "z": SOUTH})
	var out: = nodes.size()
	nodes.append({"arms": 1, "kind": "end", "x": WEST_END, "z": ROAD_Z})
	var west: = nodes.size()
	nodes.append({"arms": 1, "kind": "end", "x": EAST_END, "z": ROAD_Z})
	var east: = nodes.size()
	roads.append({"class": "primary", "from": number, "to": out, "name": "Cesta bratstva in enotnosti", "rank": 3, "width": MAIN_WIDTH, 
		"points": [[at.x, at.y], [main_x(SOUTH), SOUTH]]})
	roads.append({"class": "tertiary", "from": number, "to": west, "name": "Industrijska cesta", "rank": 1, "width": ROAD_WIDTH, 
		"points": [[at.x, at.y], [WEST_END, ROAD_Z]]})
	roads.append({"class": "tertiary", "from": number, "to": east, "name": "Industrijska cesta", "rank": 1, "width": ROAD_WIDTH, 
		"points": [[at.x, at.y], [EAST_END, ROAD_Z]]})
	for spot: Vector2 in hydrant_spots():
		layout["hydrants"].append({"x": spot.x, "z": spot.y})
	for lamp: Array in lamp_spots():
		layout["lamps"].append({"x": lamp[0].x, "z": lamp[0].y, "yaw": lamp[1]})
	var number_on: = 1
	for plot: Dictionary in PLOTS:
		var depth: = front_z(plot) - back_z(plot) - 20.0
		layout["buildings"].append({
			"kind": "industry", "label": plot["name"], "number": str(number_on), "street": "Industrijska cesta", "solid": true, 
			"x": plot["x"], "z": lot_z(plot), "yaw": 180.0, "width": float(plot["width"]) - 16.0, "depth": depth, "floors": 2, 
		})
		number_on += 2



static func hydrant_spots() -> Array[Vector2]:
	var spots: Array[Vector2] = []
	var x: = WEST_END + 40.0
	while x < EAST_END - 20.0:
		if absf(x - junction().x) > 40.0:
			spots.append(Vector2(x, ROAD_Z - ROAD_WIDTH / 2.0 - PAVEMENT + 1.6))
		x += 115.0
	return spots



static func lamp_spots() -> Array:
	var lamps: Array = []
	var x: = WEST_END + 20.0
	var side: = 1.0
	while x < EAST_END:
		if absf(x - junction().x) > 36.0:
			var z: = ROAD_Z + side * (ROAD_WIDTH / 2.0 + PAVEMENT - 1.2)
			lamps.append([Vector2(x, z), 0.0 if side > 0.0 else 180.0])
		x += 64.0
		side = - side
	return lamps






static func build(kit: PolishKit) -> String:
	var store: = kit.store
	places = {}
	houses = {}
	var parent: = kit.own_folder("Industry")
	var cleared: = _clear_country(kit)
	_move_edge(kit)
	_main_road(kit, parent)
	_road(kit, parent)
	var made: = 0
	for plot: Dictionary in PLOTS:
		var back_gate: = INF
		if plot.has("house") and _house(store, plot):
			made += 1
			back_gate = _back_door_x(houses[plot["name"]], plot)
		_plot(kit, parent, plot, back_gate)
	IndustryProps.tank_farm(kit, parent, _plot_named("TankFarm"))
	IndustryProps.substation(kit, parent, _plot_named("Substation"))
	IndustryProps.truck_yard(kit, parent, _plot_named("Depot"))
	IndustryProps.siding(kit, parent)
	_lamps(kit)
	var hydrants: = _hydrants(kit)
	_zone_sign(kit, parent)
	var dressed: = 0 if OS.get_cmdline_user_args().has("--no-dress") else IndustryDress.dress(kit)
	return "industrial zone: %d factories (%d parts of dress), %d hydrants, %d country pieces cleared" % [made, dressed, hydrants, cleared]


static func _plot_named(plot_name: String) -> Dictionary:
	for plot: Dictionary in PLOTS:
		if plot["name"] == plot_name:
			return plot
	return {}




static func _clear_country(kit: PolishKit) -> int:
	var store: = kit.store
	var cleared: = 0
	for row in kit.rows_under("Map/Backdrop"):
		var at: = store.position(row)
		var part_name: = store.name_at(row)
		if part_name == "RoadOut" and absf(at.x - main_x(at.z)) < 60.0 and at.z > OLD_SOUTH:

			var place: = store.transform(row)
			var along: = place.basis.z.normalized()
			if along.z < 0.0:
				along = - along
			var far: = at + along * store.size(row).z / 2.0
			var near: = Vector3(main_x(SOUTH), at.y, SOUTH)
			place.origin = (far + near) / 2.0
			store.set_transform(row, place)
			store.set_size(row, Vector3(store.size(row).x, store.size(row).y, far.distance_to(near)))
			continue
		if not part_name in ["FarHouse", "FarRoof", "FarTree", "FarTrunk", "Woods", "FarChimney"]:
			continue
		if at.x > WEST_END - 60.0 and at.x < EAST_END + 60.0 and at.z > YARD_BACK - 20.0 and at.z < SOUTH + 30.0:

			var place: = store.transform(row)
			place.origin.y -= 400.0
			store.set_transform(row, place)
			store.set_flags(row, 0)
			cleared += 1
	return cleared




static func _move_edge(kit: PolishKit) -> void :
	var store: = kit.store
	var map: = kit.folder("Map")
	for row in store.rows_under.get(map, PackedInt32Array()):
		if store.name_at(row) != "Edge":
			continue
		var place: = store.transform(row)
		var size: = store.size(row)
		if absf(place.origin.z - (OLD_SOUTH + 1.0)) < 2.0 and size.x > size.z:
			place.origin.z = SOUTH + 1.0
		elif size.z > size.x:
			var low: = place.origin.z - size.z / 2.0
			var high: = SOUTH + 2.0
			place.origin.z = (low + high) / 2.0
			size.z = high - low
		store.set_transform(row, place)
		store.set_size(row, size)



static func _main_road(kit: PolishKit, parent: int) -> void :
	var from: = Vector3(OLD_EXIT.x, 0, OLD_EXIT.y - 2.0)
	var to: = Vector3(main_x(SOUTH + 12.0), 0, SOUTH + 12.0)
	var along: = (to - from).normalized()
	var basis: = Basis.looking_at(along, Vector3.UP)
	var length: = from.distance_to(to)
	kit.box(parent, Transform3D(basis, (from + to) / 2.0), Vector3(MAIN_WIDTH, 0.4, length), ASPHALT, "Asphalt", "road", PolishKit.SOLID)
	var across: = basis.x

	for side: float in [-1.0, 1.0]:
		var t: = 0.0
		while t < length:
			var a: = from + along * t
			var b: = from + along * minf(t + 20.0, length)
			if absf((a.z + b.z) / 2.0 - ROAD_Z) > ROAD_WIDTH / 2.0 + 3.0:
				kit.box(parent, Transform3D(basis, (a + b) / 2.0 + across * side * (MAIN_WIDTH / 2.0 - 1.5) + Vector3(0, 0.03, 0)), Vector3(0.4, 0.4, a.distance_to(b)), PAINT, "SmoothPlastic", "paint")
			t += 20.0
	var dash: = 4.5
	while dash < length:
		var at: = from + along * dash
		if absf(at.z - ROAD_Z) > ROAD_WIDTH / 2.0 and absf(at.z - Train.LINE_Z) > 10.0:
			kit.box(parent, Transform3D(basis, at + Vector3(0, 0.03, 0)), Vector3(0.5, 0.4, 9.0), PAINT, "SmoothPlastic", "paint")
		dash += 18.0

	var middle: = Vector3(main_x(Train.LINE_Z), 0, Train.LINE_Z)
	level_crossing(kit, parent, middle, along, MAIN_WIDTH)
	places["crossing"] = middle




static func level_crossing(kit: PolishKit, parent: int, middle: Vector3, along: Vector3, width: float) -> void :
	var span: = width / maxf(absf(along.z), 0.3) + 2.0
	kit.box(parent, Transform3D(Basis(), middle + Vector3(0, RAIL_TOP / 2.0, 0)), Vector3(span, RAIL_TOP, 9.0), Color8(40, 40, 42), "Rubber", "CrossingDeck", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:
		var foot: = middle + Vector3(along.x / along.z * side * 8.5, 0, side * 8.5)
		var ramp: = Basis.looking_at(Vector3(0, 0, - side), Vector3.UP)
		kit.wedge(parent, Transform3D(ramp, foot + Vector3(0, RAIL_TOP / 2.0, 0)), Vector3(span, RAIL_TOP, 8.0), ASPHALT, "Asphalt", "CrossingRamp", PolishKit.SOLID)
		var basis: = Basis.looking_at(along, Vector3.UP)
		var post: = middle + along * side * 16.0 + basis.x * side * (width / 2.0 + 2.0)
		kit.post(parent, post, 9.0, 0.35, Color8(150, 152, 156), "Metal", "SignPost", PolishKit.FIXTURE)
		var face: = Basis.looking_at(along * side, Vector3.UP)
		for tilt: float in [0.55, -0.55]:
			var board: = Transform3D(face * Basis(Vector3.BACK, tilt), post + Vector3(0, 8.0, 0) - along * side * 0.2)
			kit.box(parent, board, Vector3(5.2, 0.7, 0.08), Color8(236, 236, 232), "SmoothPlastic", "RailCross")
			kit.box(parent, board.translated_local(Vector3(0, 0, 0.02)), Vector3(4.4, 0.3, 0.06), Color8(200, 40, 40), "SmoothPlastic", "RailCrossBand")




static func _road(kit: PolishKit, parent: int) -> void :
	var meet: = junction().x
	for span: Array in [[WEST_END, meet - MAIN_WIDTH / 2.0 + 2.0], [meet + MAIN_WIDTH / 2.0 - 2.0, EAST_END]]:
		var a: float = span[0]
		var b: float = span[1]
		kit.box(parent, Transform3D(Basis(), Vector3((a + b) / 2.0, -0.01, ROAD_Z)), Vector3(b - a, 0.4, ROAD_WIDTH), ASPHALT, "Asphalt", "road", PolishKit.SOLID)

	for end_x: float in [WEST_END, EAST_END]:
		var disc: = Transform3D(Basis(Vector3.BACK, PI / 2), Vector3(end_x, -0.02, ROAD_Z))
		kit.store.add(PartStore.Shape.CYLINDER, disc, Vector3(0.4, 46.0, 46.0), ASPHALT, "Asphalt", "road", parent, PolishKit.SOLID)

	var x: = WEST_END + 10.0
	while x < EAST_END - 10.0:
		if absf(x - meet) > MAIN_WIDTH / 2.0 + 6.0:
			kit.box(parent, Transform3D(Basis(), Vector3(x, 0.03, ROAD_Z)), Vector3(9.0, 0.4, 0.5), PAINT, "SmoothPlastic", "paint")
		x += 18.0
	for side: float in [-1.0, 1.0]:
		for span: Array in [[WEST_END + 8.0, meet - MAIN_WIDTH / 2.0 - 4.0], [meet + MAIN_WIDTH / 2.0 + 4.0, EAST_END - 8.0]]:
			var a: float = span[0]
			var b: float = span[1]
			kit.box(parent, Transform3D(Basis(), Vector3((a + b) / 2.0, 0.03, ROAD_Z + side * (ROAD_WIDTH / 2.0 - 1.2))), Vector3(b - a, 0.4, 0.4), PAINT, "SmoothPlastic", "paint")
	for side: float in [-1.0, 1.0]:
		var mouth: = meet + side * (MAIN_WIDTH / 2.0 + 3.0)
		kit.box(parent, Transform3D(Basis(), Vector3(mouth, 0.03, ROAD_Z - side * ROAD_WIDTH / 4.0)), Vector3(0.9, 0.4, ROAD_WIDTH / 2.0 - 1.0), PAINT, "SmoothPlastic", "paint")

	var gates: Array = []
	for plot: Dictionary in PLOTS:
		for offset: float in plot["gates"]:
			gates.append(float(plot["x"]) + offset)
	for side: float in [-1.0, 1.0]:
		var z: = ROAD_Z + side * (ROAD_WIDTH / 2.0 + PAVEMENT / 2.0)
		var kerb_z: = ROAD_Z + side * (ROAD_WIDTH / 2.0 + 0.3)
		for span: Array in [[WEST_END + 22.0, meet - MAIN_WIDTH / 2.0 - 1.0], [meet + MAIN_WIDTH / 2.0 + 1.0, EAST_END - 22.0]]:
			var a: float = span[0]
			var b: float = span[1]
			kit.box(parent, Transform3D(Basis(), Vector3((a + b) / 2.0, 0.14, z)), Vector3(b - a, 0.28, PAVEMENT), PAVING, "Pavement", "pavement", PolishKit.SOLID)

			var cuts: Array = [a]
			if side < 0.0:
				for gate: float in gates:
					if gate > a and gate < b:
						cuts.append(gate - 13.0)
						cuts.append(gate + 13.0)
			cuts.append(b)
			for index in range(0, cuts.size() - 1, 2):
				var k0: float = cuts[index]
				var k1: float = cuts[index + 1]
				if k1 - k0 > 1.0:
					kit.box(parent, Transform3D(Basis(), Vector3((k0 + k1) / 2.0, 0.2, kerb_z)), Vector3(k1 - k0, 0.4, 0.6), KERB, "Concrete", "kerbstone", PolishKit.SOLID)
	for gate: float in gates:

		kit.box(parent, Transform3D(Basis(), Vector3(gate, 0.16, ROAD_Z - ROAD_WIDTH / 2.0 - PAVEMENT / 2.0)), Vector3(24.0, 0.3, PAVEMENT + 0.4), YARD_TAR, "Asphalt", "crossover", PolishKit.SOLID)




static func approach(at: Vector3) -> Vector3:
	for plot: Dictionary in PLOTS:
		if absf(at.x - float(plot["x"])) <= float(plot["width"]) / 2.0 and at.z < YARD_FRONT + 2.0:
			return Vector3(float(plot["x"]) + float(plot["gates"][0]), 0, ROAD_Z - ROAD_WIDTH / 4.0)
	return Vector3(at.x, 0, ROAD_Z + ROAD_WIDTH / 4.0)



static func _back_door_x(house: House, plot: Dictionary) -> float:
	for info: Dictionary in house.data["doors"]:
		if info["name"] == "BackDoor":
			var at: Vector3 = house.lot * Rbx.v3(info["pos"])
			var gap: = clampf(at.x, float(plot["x"]) - float(plot["width"]) / 2.0 + 6.0, float(plot["x"]) + float(plot["width"]) / 2.0 - 6.0)
			return gap
	return float(plot["x"])




static func _plot(kit: PolishKit, parent: int, plot: Dictionary, back_gate: = INF) -> void :
	var x: float = plot["x"]
	var width: float = plot["width"]
	var left: = x - width / 2.0
	var right: = x + width / 2.0
	var back: = back_z(plot)
	var front: = front_z(plot)
	kit.box(parent, Transform3D(Basis(), Vector3(x, 0.12, (back + front) / 2.0)), Vector3(width, 0.24, front - back), YARD_TAR, "Asphalt", "lane", PolishKit.SOLID)
	var fence: = kit.own_folder("IndustryFences")
	_fence(kit, fence, Vector3(left, 0, back), Vector3(right, 0, back), [back_gate] if back_gate != INF else [], 4.0)
	if back_gate != INF:

		kit.box(parent, Transform3D(Basis(), Vector3(back_gate, 0.13, (back + BYPASS_EDGE) / 2.0)), Vector3(6.0, 0.26, back - BYPASS_EDGE + 1.0), PAVING, "Pavement", "path", PolishKit.SOLID)
		for side: float in [-1.0, 1.0]:
			kit.post(fence, Vector3(back_gate + side * 4.2, 0, back), 7.0, 0.4, Color8(70, 74, 78), "Metal", "GatePost", PolishKit.SOLID)
	_fence(kit, fence, Vector3(left, 0, back), Vector3(left, 0, front), [])
	_fence(kit, fence, Vector3(right, 0, back), Vector3(right, 0, front), [])
	var openings: Array = []
	for gate: float in plot["gates"]:
		openings.append(x + gate)
	_fence(kit, fence, Vector3(left, 0, front), Vector3(right, 0, front), openings)
	for gate: float in plot["gates"]:


		var gx: = x + gate
		if front < YARD_FRONT - 0.5:
			kit.box(parent, Transform3D(Basis(), Vector3(gx, 0.12, (front + YARD_FRONT) / 2.0)), Vector3(24.0, 0.24, YARD_FRONT - front + 0.2), YARD_TAR, "Asphalt", "lane", PolishKit.SOLID)
		for side: float in [-1.0, 1.0]:
			kit.post(fence, Vector3(gx + side * 11.5, 0, front), 7.6, 0.7, Color8(70, 74, 78), "Metal", "GatePost", PolishKit.SOLID)
		var slide: = gx + 11.5 + 10.0 if gx + 32.0 < right else gx - 11.5 - 10.0
		kit.box(fence, Transform3D(Basis(), Vector3(slide, 3.6, front - 0.7)), Vector3(20.0, 6.2, 0.15), FENCE, "DiamondPlate", "Gate", PolishKit.FIXTURE)
		kit.box(fence, Transform3D(Basis(), Vector3(slide, 6.6, front - 0.7)), Vector3(20.0, 0.3, 0.3), FENCE, "Metal", "GateRail")
	var first: float = plot["gates"][0]
	var sign_x: = x + first + (19.0 if first < 0.0 else -19.0)
	var sign_words: String = company(plot["name"]).get("sign", "")
	if not sign_words.is_empty():
		var place: = Transform3D(Basis(Vector3.UP, PI), Vector3(sign_x, 0, YARD_FRONT + 3.2))
		for side: float in [-1.0, 1.0]:
			kit.post(parent, place * Vector3(side * 3.4, 0, 0), 6.8, 0.4, Color8(120, 124, 130), "Metal", "SignPost", PolishKit.FIXTURE)
		StreetKit.board(kit, parent, place * Transform3D(Basis(), Vector3(0, 5.6, 0.25)), Vector2(8.4, 2.4), Color8(30, 60, 110), sign_words, Color8(250, 250, 246), "CompanySign")



static func _fence(kit: PolishKit, parent: int, a: Vector3, b: Vector3, gaps: Array, half: = 12.0) -> void :
	var length: = a.distance_to(b)
	var along: = (b - a) / length
	var basis: = Basis.looking_at(Vector3(along.z, 0, - along.x), Vector3.UP)
	var count: = maxi(1, int(ceil(length / 8.0)))
	var step: = length / count
	for index in count:
		var middle: = a + along * (index + 0.5) * step
		var blocked: = false
		for gap: float in gaps:
			if absf(middle.x - gap) < half + step / 2.0 and absf(along.x) > 0.5:
				blocked = true
		if not blocked:

			kit._made(kit.store.add(PartStore.Shape.BLOCK, Transform3D(basis, middle + Vector3(0, 3.3, 0)), Vector3(step - 0.3, 6.2, 0.12), FENCE, "DiamondPlate", "FenceMesh", parent, PolishKit.SOLID, 0.35))
			kit.box(parent, Transform3D(basis, middle + Vector3(0, 6.45, 0)), Vector3(step, 0.12, 0.16), FENCE, "Metal", "FenceRail")
		kit.post(parent, a + along * index * step, 6.8, 0.3, FENCE, "Metal", "FencePost")
	kit.post(parent, b, 6.8, 0.3, FENCE, "Metal", "FencePost")



static func _house(store: PartStore, plot: Dictionary) -> bool:
	var module: String = plot["house"]
	if not House.has_plan(module):
		return false
	var entry: = {"house": module, "lot": Transform3D(Basis(Vector3.UP, PI), Vector3(plot["x"], 0, lot_z(plot))), "weight": WEIGHT, "industry": plot["name"]}
	Game.records["buildings"].append(entry)
	var house: = House.plan(store, entry)
	house.approach = approach(Vector3(plot["x"], 0, lot_z(plot)))
	houses[plot["name"]] = house
	return true




static func _lamps(kit: PolishKit) -> void :
	var store: = kit.store
	var folder: = kit.own_folder("IndustryLamps")
	for lamp: Array in lamp_spots():
		var foot: Vector2 = lamp[0]
		var toward: = Vector3(0, 0, -1.0 if foot.y > ROAD_Z else 1.0)
		var base: = Vector3(foot.x, 0, foot.y)
		kit.post(folder, base, 28.0, 0.5, Color8(120, 124, 130), "Metal", "LampPost", PolishKit.FIXTURE)
		kit.rod(folder, base + Vector3(0, 28.0, 0), base + Vector3(0, 28.0, 0) + toward * 8.0, 0.3, Color8(120, 124, 130), "Metal", "LampArm")
		var head: = kit.box(folder, Transform3D(Basis.looking_at(toward, Vector3.UP), base + Vector3(0, 27.8, 0) + toward * 8.0), Vector3(1.2, 0.4, 2.6), Color8(200, 200, 196), "SmoothPlastic", "LampHead")
		store.meta[head] = {"a": {}, "t": ["StreetLamp"]}
		store._tag("StreetLamp", head)
		store.add_node(head, "SpotLight", "StreetLight", {"Angle": 120.0, "Brightness": 1.2, "Color": Color(1, 0.886, 0.706), "Enabled": false, "Face": "NormalId.Bottom", "Range": 60.0})




static func _hydrants(kit: PolishKit) -> int:
	var store: = kit.store
	var source: Dictionary = Game.records["hydrants"][0] if not Game.records.get("hydrants", []).is_empty() else {}
	var source_row: int = store.row_of.get(int(source.get("part", -1)), -1)
	if source_row < 0:
		return 0
	var model: = int(store.parent(source_row))
	var origin: = store.transform(source_row)
	var frame: = Transform3D(Basis(), Vector3(origin.origin.x, 0, origin.origin.z))
	var made: = 0
	var spots: = hydrant_spots()
	for plot: Dictionary in PLOTS:
		if plot.has("house"):
			spots.append(Vector2(float(plot["x"]) + float(plot["width"]) / 2.0 - 6.0, front_z(plot) - 6.0))
	for spot: Vector2 in spots:

		var place: = Transform3D(Basis(Vector3.UP, PI if spot.y < ROAD_Z else 0.0), Vector3(spot.x, 0, spot.y))
		var moved: = place * frame.affine_inverse()
		var copy: = store.add_node(kit.own_folder("IndustryHydrants"), "Model", "HydrantPost")
		var hydrant: = -1
		for row in store.rows_under.get(model, PackedInt32Array()):
			var id: = store.add(store.shape(row), moved * store.transform(row), store.size(row), store.color(row), store.material(row), store.name_at(row), copy, store.flags(row), store.transparency(row))
			if row == source_row:
				hydrant = id
		Game.records["hydrants"].append({"part": hydrant})
		made += 1
	return made



static func _zone_sign(kit: PolishKit, parent: int) -> void :
	var at: = Vector3(junction().x - MAIN_WIDTH / 2.0 - 14.0, 0, ROAD_Z - ROAD_WIDTH / 2.0 - PAVEMENT - 8.0)
	var place: = Transform3D(Basis(Vector3.UP, PI * 0.75), at)
	kit.box(parent, place * Transform3D(Basis(), Vector3(0, 0.6, 0)), Vector3(12.0, 1.2, 3.0), CONCRETE, "Concrete", "SignBase", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:
		kit.box(parent, place * Transform3D(Basis(), Vector3(side * 5.4, 7.0, 0)), Vector3(0.6, 12.0, 0.6), Color8(60, 64, 70), "Metal", "SignFrame", PolishKit.SOLID)
	StreetKit.board(kit, parent, place * Transform3D(Basis(), Vector3(0, 11.0, -0.3)), Vector2(10.0, 2.6), Color8(30, 60, 110), "INDUSTRIJSKA CONA", Color8(250, 250, 246), "ZoneSign")
	var names: Array = []
	for plot: Dictionary in PLOTS:
		var short: String = company(plot["name"]).get("short", "")
		if not short.is_empty():
			names.append(short)
	for index in names.size():
		StreetKit.board(kit, parent, place * Transform3D(Basis(), Vector3(0, 8.8 - index * 1.25, -0.3)), Vector2(10.0, 1.1), Color8(240, 240, 236), names[index], Color8(30, 40, 60), "ZoneSignRow", "Font.Gotham")
