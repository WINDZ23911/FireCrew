extends RefCounted




const PLATE: = Color8(28, 70, 150)
const EDGE: = Color8(240, 240, 236)
const MATCH: = 14.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("HouseNumbers")
	var buildings: Array = kit.layout()["buildings"]
	var plates: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		var rows: Dictionary = shell["rows"]
		if not rows.has("Door"):
			continue
		var place: Transform3D = shell["place"]
		var number: = ""
		var best: = MATCH
		for building: Dictionary in buildings:
			var away: = Vector2(float(building["x"]) - place.origin.x, float(building["z"]) - place.origin.z).length()
			if away < best and str(building.get("number", "")) != "":
				best = away
				number = str(building["number"])
		if number.is_empty():
			continue
		var door: int = rows["Door"][0]
		var frame: = store.transform(door)
		var size: = store.size(door)

		var thin: = 0
		for axis in [1, 2]:
			if size[axis] < size[thin]:
				thin = axis
		var out: = frame.basis[thin].normalized()
		if out.dot(frame.origin - place.origin) < 0.0:
			out = - out
		out = Vector3(out.x, 0.0, out.z).normalized()
		var side: = Vector3.UP.cross(out).normalized()
		var across: = 0.0
		var tall: = 0.0
		for axis in 3:
			var along: Vector3 = frame.basis[axis].normalized()
			across = maxf(across, absf(along.dot(side)) * size[axis])
			tall = maxf(tall, absf(along.y) * size[axis])
		var foot: = frame.origin.y - tall / 2.0
		var at: = frame.origin + side * (across / 2.0 + 2.6)
		at.y = foot + 7.2
		var basis: = Basis( - side, Vector3.UP, - out)
		kit.box(folder, Transform3D(basis, at - out * 0.04), Vector3(1.5, 1.05, 0.06), EDGE, "SmoothPlastic", "HouseNumberEdge")
		var plate: = kit.box(folder, Transform3D(basis, at), Vector3(1.32, 0.88, 0.08), PLATE, "SmoothPlastic", "HouseNumber")
		var gui: = store.add_node(plate, "SurfaceGui", "Number", {"Face": "NormalId.Front", "PixelsPerStud": 50.0})
		store.add_node(gui, "TextLabel", "Digits", {
			"Text": number, "TextColor3": Color(0.97, 0.97, 0.95), "Font": "Font.GothamBold", "TextScaled": true, 
			"Size": {"X": {"Scale": 0.8, "Offset": 0}, "Y": {"Scale": 0.78, "Offset": 0}}, 
			"Position": {"X": {"Scale": 0.1, "Offset": 0}, "Y": {"Scale": 0.12, "Offset": 0}}, 
		})
		plates += 1
	return "%d house numbers" % plates
