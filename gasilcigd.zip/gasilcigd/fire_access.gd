class_name FireAccess
extends RefCounted
















const CELL: = 1.5
const MARGIN: = 20.0
const HEAD: = 4.5
const STEP: = 2.6
const DROP: = 6.0
const SIGHT_SLACK: = 3.0
const REACH: = 32.0


const ROOM: = 2.8
const LADDER_SPACE: = 9.0
const LADDER_NEAR: = 8.0

const LEAST_NODES: = 3
const WARM_USEC: = 1500

static var _known: Dictionary = {}
static var _jobs: Dictionary = {}
static var _warm_next: = 0



static func of(building: Building) -> Dictionary:
	if not _known.has(building):
		var job: Job = _jobs.get(building, null)
		if job == null:
			job = Job.new(building)
		job.run(-1)
		_jobs.erase(building)
		_known[building] = job.result
	return _known[building]



static func catches(building: Building, index: int) -> bool:
	if building.has_rooms():
		return true
	var nodes: Array = of(building)["nodes"]
	return index < 0 or index >= nodes.size() or nodes[index] != "none"



static func fightable(building: Building) -> bool:
	if building.has_rooms():
		return true
	var count: = 0
	for reach: String in of(building)["nodes"]:
		if reach != "none":
			count += 1
	return count >= mini(LEAST_NODES, building.fuel.size())




static func ladder_only(building: Building, indices: Array) -> bool:
	if building.has_rooms() or indices.is_empty():
		return false
	var nodes: Array = of(building)["nodes"]
	for index: int in indices:
		if index >= nodes.size() or nodes[index] != "ladder":
			return false
	return true



static func warm(buildings: Array[Building]) -> void :
	if _warm_next >= buildings.size() or Game.world == null:
		return
	var deadline: = Time.get_ticks_usec() + WARM_USEC
	while _warm_next < buildings.size() and Time.get_ticks_usec() < deadline:
		var building: = buildings[_warm_next]
		if building.has_rooms() or _known.has(building):
			_warm_next += 1
			continue
		var job: Job = _jobs.get(building, null)
		if job == null:
			job = Job.new(building)
			_jobs[building] = job
		if job.run(deadline):
			_known[building] = job.result
			_jobs.erase(building)
			_warm_next += 1



static func warmed(buildings: Array[Building]) -> bool:
	return _warm_next >= buildings.size()


static func forget() -> void :
	_known.clear()
	_jobs.clear()
	_warm_next = 0



static func _clear(world: World, from: Vector3, to: Vector3) -> bool:
	var hit: = world.raycast(from, to, World.LAYER_QUERY)
	return hit.is_empty() or (hit["position"] as Vector3).distance_to(to) <= SIGHT_SLACK



class Job:
	var building: Building
	var result: = {"nodes": [], "ground_y": 0.0, "cells": 0}
	var _stage: = 0
	var _space: PhysicsDirectSpaceState3D
	var _stand: = PhysicsShapeQueryParameters3D.new()
	var _point: = PhysicsPointQueryParameters3D.new()
	var _centre: = Vector2.ZERO
	var _half: = 0
	var _side: = 0
	var _top: = 0.0
	var _lowest: = INF
	var _heights: = PackedFloat32Array()
	var _seen: = PackedByteArray()
	var _queue: Array[Vector2i] = []
	var _head: = 0
	var _edge_k: = 0
	var _edge: Array[Vector2i] = []
	var _edge_low: = INF
	var _node: = 0
	var _open: Dictionary = {}
	var _gravity: = 0.0
	var _speed: = 0.0
	var _outreach: = LadderService.MAX_OUTREACH
	var _length: = 74.0
	var _pivot: = 12.0

	func _init(of_building: Building) -> void :
		building = of_building
		result["ground_y"] = building.position.y - building.height / 2.0
		if Game.world == null or building.fuel.is_empty():
			for _node in building.fuel:
				result["nodes"].append("ground")
			_stage = 3
			return
		_space = Game.world.get_world_3d().direct_space_state
		_centre = Vector2(building.position.x, building.position.z)
		var extent: = 0.0
		for node: Dictionary in building.fuel:
			var at: Vector3 = node["position"]
			extent = maxf(extent, Vector2(at.x, at.z).distance_to(_centre))
			_lowest = minf(_lowest, at.y)
		_half = int(ceil((extent + MARGIN) / CELL))
		_side = _half * 2 + 1
		_top = building.position.y + building.height / 2.0 + 30.0
		_heights.resize(_side * _side)
		_heights.fill(NAN)
		_seen.resize(_side * _side)
		var capsule: = CapsuleShape3D.new()
		capsule.radius = ROOM / 2.0
		capsule.height = Player.HEIGHT - 0.4
		_stand.shape = capsule
		_stand.collision_mask = World.LAYER_SOLID
		_point.collision_mask = World.LAYER_SOLID
		_gravity = float(Config.Hose.StreamGravity)
		_speed = HoseService.stream_speed(1.0)
		var ladder: = LadderService.current
		if ladder != null and is_instance_valid(ladder.vehicle):
			_outreach = ladder.max_outreach()
			var data: Dictionary = ladder.vehicle.data.get("ladder", {})
			if data.has("sectionLength") and data.has("slide"):
				_length = float(data["sectionLength"]) + float(data["slide"])
			if data.get("pivot") is Array:
				_pivot = float(data["pivot"][1]) - float(ladder.vehicle.data.get("ground", 0.0))


	func run(deadline: int) -> bool:
		while _stage < 3:
			if deadline >= 0 and Time.get_ticks_usec() >= deadline:
				return false
			match _stage:
				0: _edge_step()
				1: _flood_step()
				2: _node_step()
		return true

	func _cell_at(cell: Vector2i) -> Vector2:
		return _centre + Vector2(cell.x - _half, cell.y - _half) * CELL


	func _floor_at(cell: Vector2i, high: float, low: float) -> float:
		var flat: = _cell_at(cell)
		var hit: = Game.world.raycast(Vector3(flat.x, high, flat.y), Vector3(flat.x, low, flat.y), World.LAYER_SOLID)
		if hit.is_empty():
			return NAN
		var y: float = hit["position"].y
		var capsule: = _stand.shape as CapsuleShape3D
		_stand.transform = Transform3D(Basis.IDENTITY, Vector3(flat.x, y + 0.5 + capsule.height / 2.0, flat.y))
		if not _space.intersect_shape(_stand, 1).is_empty():
			return NAN
		return y


	func _edge_step() -> void :
		if _edge_k < _side:
			var k: = _edge_k
			_edge_k += 1
			for cell: Vector2i in [Vector2i(k, 0), Vector2i(k, _side - 1), Vector2i(0, k), Vector2i(_side - 1, k)]:
				var y: = _floor_at(cell, _top, _lowest - 40.0)
				if not is_nan(y):
					_edge.append(cell)
					_heights[cell.y * _side + cell.x] = y
					_edge_low = minf(_edge_low, y)
			return
		for cell: Vector2i in _edge:
			var key: = cell.y * _side + cell.x
			if _heights[key] <= _edge_low + 8.0 and _seen[key] == 0:
				_seen[key] = 1
				_queue.append(cell)
			elif _seen[key] == 0:
				_heights[key] = NAN
		if _edge_low < INF:
			result["ground_y"] = _edge_low
		_stage = 1

	func _flood_step() -> void :
		if _head >= _queue.size():
			result["cells"] = _queue.size()
			for cell in _queue:
				_open[cell] = true
			_stage = 2
			return
		var cell: = _queue[_head]
		_head += 1
		var y: = _heights[cell.y * _side + cell.x]
		for step: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var next: = cell + step
			if next.x < 0 or next.y < 0 or next.x >= _side or next.y >= _side:
				continue
			var key: = next.y * _side + next.x
			if _seen[key] != 0:
				continue
			var found: = _floor_at(next, y + STEP, y - DROP)
			if is_nan(found):
				continue
			_seen[key] = 1
			_heights[key] = found
			_queue.append(next)


	func _node_step() -> void :
		if _node >= building.fuel.size():
			_stage = 3
			return
		var at: Vector3 = building.fuel[_node]["position"]
		_node += 1
		var reach: = "none"
		for cell in _queue:
			var flat: = _cell_at(cell)
			if flat.distance_to(Vector2(at.x, at.z)) > REACH:
				continue
			var nozzle: = Vector3(flat.x, _heights[cell.y * _side + cell.x] + HEAD, flat.y)
			if Ballistics.reachable(nozzle, at, _speed, _gravity) and FireAccess._clear(Game.world, nozzle, at):
				reach = "ground"
				break
		if reach == "none" and _from_ladder(at):
			reach = "ladder"
		result["nodes"].append(reach)



	func _from_ladder(at: Vector3) -> bool:
		var span: = int(ceil(LADDER_SPACE / CELL))
		for cell in _queue:
			var flat: = _cell_at(cell)
			var level: = flat.distance_to(Vector2(at.x, at.z))
			if level < LADDER_NEAR or level > _outreach + 6.0:
				continue
			var ground: = _heights[cell.y * _side + cell.x]

			var toward: = Vector3(flat.x - at.x, 0, flat.y - at.z).normalized()
			var off: = minf(6.0, level - 2.0)
			var basket: = at + toward * off + Vector3(0, 3.0, 0)
			var out: = level - off
			var rise: = basket.y - ground - _pivot
			if out > _outreach or Vector2(out, rise).length() > _length:
				continue
			var room: = true
			for di: int in [ - span, 0, span]:
				for dj: int in [ - span, 0, span]:
					if not _open.has(cell + Vector2i(di, dj)):
						room = false
			if not room:
				continue
			_point.position = basket
			if not _space.intersect_point(_point, 1).is_empty():
				continue
			if FireAccess._clear(Game.world, basket, at):
				return true
		return false
