class_name NetWorld
extends Node








static var last_partial: Dictionary = {}

var _call_on: = false
var _call_earned: = 0
var _call_scene: = 0.0


func _ready() -> void :
	var talk: = NetTalk.new()
	talk.name = "Talk"
	add_child(talk)
	var radio: = TeamRadio.new()
	radio.name = "TeamRadio"
	add_child(radio)

	Game.notified.connect(_on_notified)
	Net.handle("notify", func(text: Variant, kind: String) -> void : Game.notified.emit(text, kind, null))


	Net.share("incident", func() -> Variant: return _plain(Game.incident), func(state: Variant) -> void : Game.set_incident(state), 4.0)


	Game.incident_ending.connect( func(last: Dictionary) -> void :
		if Net.is_host() and Net.active():
			Net.broadcast("incident.final", [_plain(last)])
	)
	Net.handle("incident.final", func(last: Dictionary) -> void : Game.set_incident(last))
	Net.share("clock", func() -> Variant: return snappedf(Sky3D.current.hour, 0.01) if Sky3D.current else 12.0, func(hour: Variant) -> void :
		if Sky3D.current and absf(Sky3D.current.hour - hour) > 0.05:
			Sky3D.current.set_hour(hour)
	, 0.5)

	Net.share("style", func() -> Variant: return Style.kind, func(style: Variant) -> void : Style.choose(int(style)), 0.5)


	Net.share("vehicles.motion", _motions, _apply_motions, 20.0, true)
	Net.share("vehicles.flags", _flags, _apply_flags, 6.0)
	Net.handle("vehicle.motion", func(player: Player, path: String, motion: Array) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null and vehicle.driver() == player:
			vehicle.net_apply_motion(motion)
	)
	Net.handle("vehicle.key", func(player: Player, path: String, what: String) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null:
			vehicle.driver_key(player, what)
	)
	Net.handle("vehicle.horn", func(path: String) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null:
			vehicle.sound_horn()
	)


	Net.share("station.doors", func() -> Variant:
		var open: Array = []
		for door: Dictionary in Game.station.doors:
			open.append(door["open"])
		return open
	, func(open: Variant) -> void :
		for index in open.size():
			Game.station.set_door(index + 1, open[index])
	, 4.0)


	Net.handle("station.door", func(player: Player, path: String) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		var station: = Game.station
		if vehicle == null or station == null or vehicle.driver() != player:
			return
		var bay: = int(vehicle.spec.get("bay", 0))
		if bay >= 1 and bay <= station.doors.size() and vehicle.global_position.distance_to(station.door_position) <= float(Config.Truck.DoorRemoteRange):
			station.toggle_door(bay)
	)

	Net.started.connect(_on_started)
	Net.stopped.connect(_on_stopped)





func _on_stopped() -> void :
	if not _was_client:
		return
	_was_client = false
	if _call_on and not Net.left_by_choice:
		_pay_partial()
	_call_on = false
	Game.set_incident({})
	var me: = Game.local_player
	if me == null or not is_instance_valid(me):
		return
	for key: String in ["Carrying", "Line", "Supply", "Dragging", "HoseLength", "HoseTruck", "CordonCarried", "Tool", "ToolForces"]:
		me.set_attr(key, null)
	me.holding = ""
	me.frozen = false
	StanceService.refresh_speed(me)
	if ToolService.current:
		ToolService.current.carried_changed.emit(me)


var _was_client: = false


func _on_started() -> void :
	_was_client = Net.is_client()

	var me: = Game.local_player
	if not me.attribute_changed.is_connected(_on_my_attribute):
		me.attribute_changed.connect(_on_my_attribute)
	if not me.rewarded.is_connected(_on_my_reward):
		me.rewarded.connect(_on_my_reward)
	if not Game.incident_changed.is_connected(_on_incident):
		Game.incident_changed.connect(_on_incident)
	_on_incident()



func _on_incident() -> void :
	if not Net.is_client():
		return
	var on: = not Game.incident.is_empty()
	if on and not _call_on:
		_call_earned = 0
		_call_scene = 0.0
	_call_on = on


func _on_my_reward(amount: int, _why: String) -> void :
	if _call_on and Net.is_client() and amount > 0:
		_call_earned += amount






func _pay_partial() -> void :
	var me: = Game.local_player
	if me == null or not is_instance_valid(me):
		return
	var settings: Dictionary = Config.Net.HostLeft
	var time_pay: = mini(roundi(_call_scene / 60.0 * float(settings["PerMinute"])), int(settings["Most"]))
	var bonus: = roundi(_call_earned * float(settings["Share"])) + time_pay
	last_partial = {"earned": _call_earned, "scene": _call_scene, "bonus": bonus}
	print("net: the host left mid-call: earned %d on it, %.0f s there, paid %d more" % [_call_earned, _call_scene, bonus])
	if bonus > 0:
		me.add_cash(bonus, "hostLeft", true, "hostLeft")
	Game.notify(Text.f("talk.net.partial", [_call_earned, bonus]) if _call_earned > 0 else Text.f("talk.net.partialTime", [bonus]), "good", me)


func _on_my_attribute(key: String, value: Variant) -> void :
	if key != "Vehicle" or not Net.is_client():
		return
	var me: = Game.local_player
	if value is Vehicle:
		me.camera.subject = value
		me.camera.subject_height = float(value.data["top"]) * 0.75
		me.camera.subject_distance = 16.0
		me.camera.yaw = value.global_rotation.y
	else:
		me.camera.subject = null


func _on_notified(text: Variant, kind: String, player: Player) -> void :
	if not Net.is_host() or not Net.active():
		return
	if player == null:
		Net.broadcast("notify", [text, kind])
	elif player != Game.local_player:
		Net.send_to(player, "notify", [text, kind])



func _plain(incident: Dictionary) -> Dictionary:
	var plain: = {}
	for key: Variant in incident:
		var value: Variant = incident[key]
		if not (value is Object or value is Callable):
			plain[key] = value
	return plain


func _motions() -> Variant:
	var all: = {}
	for vehicle in Vehicle.all:
		all[String(vehicle.get_path())] = vehicle.net_motion()
	return all


func _apply_motions(all: Variant) -> void :
	for path: String in all:
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null:
			vehicle.net_apply_motion(all[path])


func _flags() -> Variant:
	var all: = {}
	for vehicle in Vehicle.all:
		all[String(vehicle.get_path())] = vehicle.net_flags()
	return all


func _apply_flags(all: Variant) -> void :
	for path: String in all:
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null:
			vehicle.net_apply_flags(all[path])


func _physics_process(delta: float) -> void :

	if not Net.is_client():
		return
	if _call_on and Game.local_player.root_position().distance_to(Game.incident.get("pos", Vector3.INF)) <= float(Config.Fire.ArriveRange):
		_call_scene += delta
	var mine: Variant = Game.local_player.get_attr("Vehicle")
	if mine is Vehicle and mine.driver() == Game.local_player:
		Net.push("vehicle.motion", [String(mine.get_path()), mine.net_motion()])
