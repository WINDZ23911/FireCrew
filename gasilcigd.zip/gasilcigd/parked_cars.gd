class_name ParkedCars
extends Node3D










const WATCH_EVERY: = 0.5

static var current: ParkedCars

var cars: Array = []
var _painted: Dictionary = {}
var _watched: = 0.0


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func start() -> void :
	var store: = Game.store
	var world: = Game.world
	if CarKit.shapes().is_empty():
		return
	var by_shape: = {}
	var found: Array = []
	for id: int in store.nodes:
		var node: Dictionary = store.nodes[id]
		if node["n"] != "Car" or node["c"] != "Model":
			continue
		var parent: Dictionary = store.nodes.get(node["p"], {})
		if parent.get("n", "") != "StreetProps":
			continue
		var pivot: Variant = node.get("v", {}).get("WorldPivot")
		var body: = store.find_row(id, "Body")
		if not pivot is Transform3D or body < 0:
			continue
		found.append([id, pivot, body])
	var bays: = _bay_lines(store)
	for entry: Array in found:
		var id: int = entry[0]
		var place: Transform3D = entry[1]
		var body: int = entry[2]


		var seed_at: = floori(place.origin.x * 7.0 + place.origin.z * 13.0)
		var room: = minf(_room(place, found), _bay(place, bays))
		var shape: = CarKit.pick(seed_at, room)
		var work: = CarKit.work_shape()
		if CarKit.shapes().has(work) and _working(place) and CarKit.length_of(work) <= room and int(rand_from_seed(hash([seed_at, "van"]))[0]) % 2 == 0:
			shape = work
		for row in store.rows_under.get(id, PackedInt32Array()):
			world.set_hidden(store.id_at(row), true)
		if not by_shape.has(shape):
			by_shape[shape] = []
		var paint: = CarKit.street_paint(store.color(body), store.color(body), id)
		if shape == "Estate" and _out_of_town(place):
			paint = paint.darkened(0.12)
		var car: = {"model": id, "place": place, "shape": shape, "slot": by_shape[shape].size(), "body": body, "paint": paint, "source": store.color(body)}
		by_shape[shape].append(car)
		cars.append(car)

	if OS.get_cmdline_user_args().has("--cars-trace"):
		print("parked cars: %s" % ", ".join(by_shape.keys().map( func(k: String) -> String: return "%d %s" % [by_shape[k].size(), k])))
	for shape: String in by_shape:
		var list: Array = by_shape[shape]
		var pieces: = CarKit.meshes(shape)
		_painted[shape] = []
		for piece: String in pieces:
			var painted: = CarKit.PAINTED.has(piece)
			var multimesh: = MultiMesh.new()
			multimesh.transform_format = MultiMesh.TRANSFORM_3D
			multimesh.use_colors = painted
			multimesh.mesh = pieces[piece]
			multimesh.instance_count = list.size()
			for car: Dictionary in list:
				multimesh.set_instance_transform(car["slot"], car["place"])
				if painted:
					multimesh.set_instance_color(car["slot"], car["paint"])
			var instance: = MultiMeshInstance3D.new()
			instance.name = shape + "_" + piece
			instance.multimesh = multimesh
			instance.material_override = CarKit.material(piece, Color.WHITE, true)
			if CarKit.LOOKS.has(piece):
				instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(instance)
			if painted:
				_painted[shape].append(multimesh)

		var shadows: = MultiMesh.new()
		shadows.transform_format = MultiMesh.TRANSFORM_3D
		var patch: = VehicleLook.contact_shadow(self, Vector3.ZERO, CarKit.width_of(shape), CarKit.length_of(shape))
		shadows.mesh = patch.mesh
		shadows.instance_count = list.size()
		for car: Dictionary in list:
			shadows.set_instance_transform(car["slot"], car["place"] * patch.transform)
		var under: = MultiMeshInstance3D.new()
		under.name = shape + "_Shadow"
		under.multimesh = shadows
		under.material_override = patch.material_override
		under.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(under)
		patch.free()

		var look: = CarKit.plate_look()
		var plates: = MultiMesh.new()
		plates.transform_format = MultiMesh.TRANSFORM_3D
		plates.use_custom_data = true
		plates.mesh = look[0]
		var ends: = CarKit.plate_ends()
		plates.instance_count = list.size() * ends.size()
		for car: Dictionary in list:
			for e in ends.size():
				var end: int = ends[e]
				var index: int = car["slot"] * ends.size() + e
				plates.set_instance_transform(index, car["place"] * CarKit.plate_place(end, shape))
				var row: int = rand_from_seed(hash(["plate", car["model"]]))[0] %CarKit.PLATE_ROWS
				plates.set_instance_custom_data(index, Color(float(row) / CarKit.PLATE_ROWS, 0, 0, 0))
		var plated: = MultiMeshInstance3D.new()
		plated.name = shape + "_Plates"
		plated.multimesh = plates
		plated.material_override = look[1]
		plated.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(plated)


const MARGIN: = 1.5
const LATERAL: = 5.0



static func _room(place: Transform3D, others: Array) -> float:
	var along: = place.basis.z.normalized()
	var side: = place.basis.x.normalized()
	var room: = INF
	for other: Array in others:
		var at: Transform3D = other[1]
		var away: = at.origin - place.origin
		if away.length_squared() < 0.01:
			continue
		if absf(away.dot(side)) < LATERAL:
			room = minf(room, absf(away.dot(along)) - MARGIN)
	return room



static func _bay_lines(store: PartStore) -> Array:
	var lines: Array = []
	for row in store.rows_named("paint"):
		var size: = store.size(row)
		var long: = maxf(size.x, size.z)
		if long < 16.0 or long > 20.0 or minf(size.x, size.z) > 0.6:
			continue
		var place: = store.transform(row)
		lines.append([place.origin, (place.basis.x if size.x > size.z else place.basis.z).normalized(), long])
	return lines




static func _bay(place: Transform3D, lines: Array) -> float:
	var along: = place.basis.z.normalized()
	for line: Array in lines:
		var middle: Vector3 = line[0]
		var way: Vector3 = line[1]
		var away: = middle - place.origin
		if absf(way.dot(along)) > 0.9 and absf(away.dot(along)) < 4.0 and Vector2(away.x, away.z).length() < 6.0:
			return float(line[2]) - 0.5
	return INF



static func _working(place: Transform3D) -> bool:
	if place.origin.z > IndustryZone.LOT_Z - 60.0:
		return true
	for building: Dictionary in Rbx.module("TownLayout").get("buildings", []):
		if building.get("kind", "") == "shop" and Vector2(float(building["x"]) - place.origin.x, float(building["z"]) - place.origin.z).length() < 70.0:
			return true
	return false



static func _out_of_town(place: Transform3D) -> bool:
	for building: Dictionary in Rbx.module("TownLayout").get("buildings", []):
		if Vector2(float(building["x"]) - place.origin.x, float(building["z"]) - place.origin.z).length() < 90.0:
			return false
	return true



func car_of(model: int) -> Dictionary:
	for car: Dictionary in cars:
		if car["model"] == model:
			return car
	return {}


func _process(delta: float) -> void :
	_watched += delta
	if _watched < WATCH_EVERY:
		return
	_watched = 0.0
	var store: = Game.store
	for car: Dictionary in cars:
		var paint: = CarKit.street_paint(store.color(car["body"]), car["source"], car["model"])
		if paint != car["paint"]:
			car["paint"] = paint
			for multimesh: MultiMesh in _painted[car["shape"]]:
				multimesh.set_instance_color(car["slot"], paint)
