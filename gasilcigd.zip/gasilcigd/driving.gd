extends ProofDebug



var _told: Array[String] = []






func _scenario_driving() -> void :
	await _wait(1.0)
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : _told.append(Text.say(text, "en")))
	var truck: = Vehicle.named("Fire Truck")
	var camera: = player.camera
	var settings: Dictionary = Config.VehicleCamera
	_park(truck, Vector3(-104, 0, 14), - PI / 2.0)
	await _wait(0.5)


	await _to_cab_door(truck)
	var door: Dictionary = truck.doors["DoorCabLeft"]
	var offered: Prompt = player.prompts.get("item")
	print("driving: at the shut door: open %s, F offers %s" % [door["open"], Text.say(offered.action, "en") if offered else "nothing"])
	_check( not door["open"] and offered == door["seat_prompt"], "at the shut cab door F offers to drive")
	await _tap("item")
	await _wait(0.2)
	var opened: bool = door["open"] or float(door["amount"]) > 0.05
	await _wait(1.0)
	print("driving: after one F: seated %s, driver %s, door opened %s and now open %s" % [player.seat != null, truck.driver() == player, opened, door["open"]])
	_check(player.seat != null and truck.driver() == player, "one press of F at a shut door sits the player at the wheel")
	_check(opened and not door["open"], "the door opened for it and is shut again")
	camera.pitch = -0.25
	camera.driver_view = false
	camera._looked_at = -1000.0
	await _wait(0.3)
	_check(_mast_row_shown() == true, "the driver's panel lists J for the pumper's light mast")
	await _snap("boarded")


	await _cruise(2.0, SPEED)
	camera.yaw = _heading(truck) + 1.2
	camera._looked_at = Game.now()
	await _cruise(1.0, SPEED)
	var waiting: = absf(wrapf(camera.yaw - _heading(truck), - PI, PI))
	await _snap("looked_aside")
	await _cruise(float(settings["RecentreAfter"]) + 1.5, SPEED)
	var after: = absf(wrapf(camera.yaw - _heading(truck), - PI, PI))
	var behind: = (camera.global_position - truck.global_position).dot( - truck.global_basis.z) < 0.0
	print("driving: looked 69° aside at %.0f studs/s: after 1 s %.1f° off, after %.1f s %.1f° off, behind the truck %s, fov %.1f" % [truck.forward_speed, rad_to_deg(waiting), float(settings["RecentreAfter"]) + 2.5, rad_to_deg(after), behind, camera.camera.fov])
	_check(truck.forward_speed > float(settings["RecentreSpeed"]), "the truck is on the move (%.1f studs/s)" % truck.forward_speed)
	_check(waiting > 1.0, "a look aside is left alone until the wait is over")
	_check(after < deg_to_rad(6.0) and behind, "after the wait the view is back behind the truck")

	var moved: = PlayerCamera.motion_scale() > 0.0
	if moved:
		_check(camera.camera.fov > camera.base_fov + 0.5, "from behind, the view is wider on the move (fov %.1f)" % camera.camera.fov)
	else:
		_check(absf(camera.camera.fov - camera.base_fov) < 0.05 and camera._rock == Vector3.ZERO, "camera motion off: no widening, no rock (fov %.1f, rock %s)" % [camera.camera.fov, camera._rock])
	await _snap("recentred")


	await _tap("camera_mode")
	await _wait(0.1)
	await _tap("camera_mode")
	await _wait(0.1)
	camera.yaw = _heading(truck) - 0.9
	camera._looked_at = Game.now()
	await _cruise(float(settings["RecentreAfter"]) + 1.5, SPEED)
	var seat_after: = absf(wrapf(camera.yaw - _heading(truck), - PI, PI))
	print("driving: seat view %s: after the wait %.1f° off the road ahead, fov %.1f" % [camera.seated_view(), rad_to_deg(seat_after), camera.camera.fov])
	_check(camera.seated_view() and seat_after < deg_to_rad(6.0), "from the seat the view comes back to the road ahead")
	_check(camera.camera.fov > float(Config.Truck.DriverFov) if moved else absf(camera.camera.fov - float(Config.Truck.DriverFov)) < 0.1, "at the wheel the view is the driver's, wider with speed (fov %.1f)" % camera.camera.fov)
	await _snap("seat")
	await _tap("camera_mode")


	var turned: = 0.0
	var most_aside: = 0.0
	var last: = _heading(truck)
	var snapped: = false
	var deadline: = Game.now() + 20.0
	while _next < 7 and Game.now() < deadline:
		await _cruise(0.1, SPEED)
		turned += wrapf(_heading(truck) - last, - PI, PI)
		last = _heading(truck)
		most_aside = maxf(most_aside, absf(wrapf(camera.yaw - _heading(truck), - PI, PI)))
		if absf(turned) > PI / 2.0 and not snapped:
			snapped = true
			await _snap("turning")
	print("driving: round the loop's end: turned %.0f°, the view at most %.1f° off behind it, at %s" % [rad_to_deg(turned), rad_to_deg(most_aside), truck.global_position.round()])
	_check(absf(turned) > deg_to_rad(150.0), "the truck went round the end of the loop (%.0f°)" % rad_to_deg(absf(turned)))
	_check(most_aside < deg_to_rad(12.0), "the view from behind turned with the truck (at most %.1f° off)" % rad_to_deg(most_aside))


	await _cruise(1.0, SPEED)
	Input.action_press("move_forward")
	var kmh: = absf(truck.forward_speed) * float(Config.Hud.MetresPerStud) * 3.6
	_told.clear()
	await _tap("veh_exit")
	await _wait(0.3)
	print("driving: Space tapped at %.0f km/h: seated %s, told %s" % [kmh, player.seat != null, _told])
	_check(kmh > float(Config.Boarding.ExitSpeed) and player.seat != null, "a tap of Space at %.0f km/h does not get out" % kmh)
	_check(_told.any( func(line: String) -> bool: return line.begins_with("Stop first")), "the driver is told to stop first or hold the key")
	await _snap("refused")


	kmh = absf(truck.forward_speed) * float(Config.Hud.MetresPerStud) * 3.6
	await _hold("veh_exit", float(Config.Boarding.ExitHold) + 0.3)
	Input.action_release("move_forward")
	await _wait(0.3)
	print("driving: Space held at %.0f km/h: seated %s" % [kmh, player.seat != null])
	_check(player.seat == null and truck.driver() == null, "holding Space on the move gets out")


	await _wait(3.0)
	await _to_cab_door(truck)
	await _tap("item")
	await _wait(1.0)
	_check(player.seat != null, "back in with F")
	var standing: = Game.now() + 5.0
	while absf(truck.forward_speed) > 0.3 and Game.now() < standing:
		await get_tree().process_frame
	await _tap("veh_exit")
	await _wait(0.5)
	print("driving: Space tapped standing: seated %s" % [player.seat != null])
	_check(player.seat == null, "a tap of Space at a stop gets out")


	var command: = Vehicle.named("Command Vehicle")
	command._board(player, "DoorCabLeft")
	await _wait(0.5)
	_check(_mast_row_shown() == false, "the command vehicle's panel, with no light mast, has no J")
	await _snap("command_panel")
	command.leave(player)
	await _done()



func _mast_row_shown() -> Variant:
	for node in get_tree().root.find_children("*", "Control", true, false):
		if node is HudTruck:
			var rows: Array = node._rows
			if not node._panel.visible:
				return null
			var mast: = HudTruck.CONTROLS.map( func(control: Array) -> String: return control[0]).find("mast")
			return (rows[mast]["label"] as Control).get_parent().visible
	return null


const SPEED: = 20.0


func _heading(vehicle: Vehicle) -> float:
	return vehicle.global_basis.get_euler().y



func _to_cab_door(vehicle: Vehicle) -> void :
	var doorway: Vector3 = vehicle.doors["DoorCabLeft"]["doorway"]
	var outside: = vehicle.global_transform * (doorway + Vector3(signf(doorway.x) * 3.5, 0, 0))
	player.teleport(_ground(outside) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	_look_at(vehicle.global_transform * doorway)
	await _wait(0.4)




const ROUTE: = [Vector2(-40, 14), Vector2(60, 14), Vector2(100, 17), Vector2(122, 30), Vector2(126, 48), Vector2(114, 66), Vector2(85, 73), Vector2(0, 76), Vector2(-120, 80)]
var _next: = 0



func _cruise(seconds: float, speed: float) -> void :
	var end: = Game.now() + seconds
	var truck: = HudTruck.driven()
	var said: = 0.0
	while Game.now() < end and truck != null:
		_keep_speed(truck, speed)
		_steer(truck)
		await get_tree().process_frame
		if OS.get_cmdline_user_args().has("--trace") and Game.now() > said:
			said = Game.now() + 0.5
			print("   at %s speed %.1f gear %d next %d" % [truck.global_position.round(), truck.forward_speed, truck.drive.gear, _next])
	Input.action_release("move_left")
	Input.action_release("move_right")
	Input.action_release("move_forward")



func _steer(truck: Vehicle) -> void :
	var at: = Vector2(truck.global_position.x, truck.global_position.z)
	while _next < ROUTE.size() - 1 and at.distance_to(ROUTE[_next]) < 12.0:
		_next += 1
	var toward: Vector2 = ROUTE[_next] - at
	var want: = atan2( - toward.x, - toward.y)
	var off: = wrapf(want - _heading(truck), - PI, PI)
	Input.action_release("move_left")
	Input.action_release("move_right")
	if off > 0.04:
		Input.action_press("move_left")
	elif off < -0.04:
		Input.action_press("move_right")



func _keep_speed(truck: Vehicle, speed: float) -> void :
	if truck.forward_speed < speed:
		Input.action_press("move_forward")
	else:
		Input.action_release("move_forward")
