extends CrewAiDebug



















func _until(test: Callable, limit: float, every: = 0.25) -> bool:
	var waited: = 0.0
	while waited < limit:
		if test.call():
			return true
		await _wait(every)
		waited += every
	return test.call()



func _full_auto() -> void :
	var service: = CrewService.current
	service.auto = true
	service.autonomy = CrewService.FULL
	for mind in service.members:
		mind.autonomy = -1
	Config.Crew["LeadWait"] = 0.0
	Config.Crew["IdleBefore"] = 1.0



func _house_fire(count: int, report: = "maybe") -> House:
	var fire: = FireService.current
	var house: = _house("Family house")
	if house == null:
		house = _house("")
	VictimService.current.forced = count
	VictimService.current.forced_report = report
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	CallService.current.run_call("fire", func() -> bool:
		await fire.run_incident(house)
		return true)
	await _until( func() -> bool: return not fire.incident.is_empty(), 10.0)
	return house


func _trace_jobs(stage: String) -> void :
	print("%s: jobs %s" % [stage, _crew().map( func(m: Crewman) -> String: return "%s:%s%s" % [m.display_name(), m.job.kind if m.job != null else "-", ("(" + str((m.job as JobSearch).room) + ")") if m.job is JobSearch else ""])])





func _scenario_crewsearch() -> void :
	await _wait(1.5)
	if not _check(CrewService.current != null and not _crew().is_empty(), "the crew comes along"):
		await _done()
		return
	Config.Victims["SmokeDrain"] = 0.05
	var house: = await _house_fire(1, "maybe")
	var people: = VictimService.current
	var victim: Victim = people.victims[0] if not people.victims.is_empty() else null
	if not _check(victim != null and not victim.found, "somebody is inside, not found yet"):
		await _done()
		return
	print("crewsearch: %s, %d rooms, the person in %s" % [house.name, CrewSearch.rooms(house).size(), victim.room])
	await _arrive(house.approach if house.approach != null else house.position, 30.0)
	_full_auto()
	CrewService.current.all_work()
	var searched: = [false]
	var early: = [false]
	var found_by_crew: = [false]
	var lead_far: = [true]
	var carried: = [false]
	var waited: = 0.0
	while waited < 125.0:
		await _wait(0.25)
		waited += 0.25
		if player.global_position.distance_to(victim.position()) < 30.0:
			lead_far[0] = false
		for mind in _crew():
			if mind.job is JobSearch:
				searched[0] = true
			if mind.job is JobCarry:
				var carry: JobCarry = mind.job
				if carry.victim != null and not carry.victim.found:
					early[0] = true
				if carry.victim == null and not victim.found:
					early[0] = true
		if victim.found and not found_by_crew[0] and lead_far[0]:
			found_by_crew[0] = true
			print("crewsearch: found at %.0f s; the nearest member %.0f studs off" % [waited, _crew().map( func(m: Crewman) -> float: return m.body.global_position.distance_to(victim.position())).min()])
			_view(victim.position() + Vector3(18, 16, 18), victim.position())
			await _snap("found")
		if victim.state in ["carried", "out"]:
			carried[0] = true
		if int(waited * 4.0) % 40 == 0:
			_trace_jobs("crewsearch %.0f s" % waited)
		if carried[0] and victim.state == "out":
			break
	print("crewsearch: searched %s, carry before found %s, found by the crew %s, carried %s (state %s)" % [searched[0], early[0], found_by_crew[0], carried[0], victim.state])
	_check(searched[0], "a member searches the house")
	_check( not early[0], "no carry is started for somebody not found")
	_check(found_by_crew[0], "a member of the crew finds the person")
	_check(carried[0], "the person found is carried out")
	await _done()





func _scenario_crewdoor() -> void :
	await _wait(1.5)
	Config.Victims["SmokeDrain"] = 0.0
	var house: = await _house_fire(1, "maybe")
	var doors: Array = []
	for door_name: String in house.doors:
		var door: Dictionary = house.doors[door_name]
		if door["outside"]:
			door["locked"] = true
			door["open"] = false
			house._place_door(door)
			doors.append(door)
	print("crewdoor: %s, %d outside doors locked" % [house.name, doors.size()])
	await _arrive(house.approach if house.approach != null else house.position, 30.0)
	var service: = CrewService.current
	service.auto = false
	for mind in _crew():
		mind.mode = "hold"
		mind.hold_at = mind.body.global_position
	var searcher: = service.order(JobSearch.new(house))
	if not _check(searcher != null, "a member is sent to search"):
		await _done()
		return
	var forced: = [false]
	var inside: = [false]
	var waited: = 0.0
	while waited < 120.0 and not (forced[0] and inside[0]):
		await _wait(0.5)
		waited += 0.5
		for door: Dictionary in doors:
			if not door["locked"]:
				forced[0] = true
		inside[0] = inside[0] or house.room_at(searcher.body.root_position()) != null
		if int(waited * 2.0) % 20 == 0:
			print("crewdoor: %.0f s, %s job %s at %s, forced %s inside %s" % [waited, searcher.display_name(), searcher.job.kind if searcher.job != null else "-", searcher.body.global_position.snapped(Vector3.ONE), forced[0], inside[0]])
	_view(searcher.body.global_position + Vector3(16, 14, 16), searcher.body.global_position)
	await _snap("inside")
	_check(forced[0], "a locked door met on the way is forced")
	_check(inside[0], "the member gets into the house")
	await _done()





func _scenario_crewpair() -> void :
	await _wait(1.5)
	Config.Victims["SmokeDrain"] = 0.0
	var house: = await _house_fire(0, "")
	var pumper: = await _arrive(house.approach if house.approach != null else house.position, 30.0)
	var service: = CrewService.current
	service.auto = false
	service.order(JobSupply.new(pumper))
	var nozzle: = service.order(JobAttack.new())
	var backup: Crewman = null
	for mind in _crew():
		if mind != nozzle and mind.job == null:
			backup = mind
			break
	if not _check(nozzle != null and backup != null, "a nozzle and a second member"):
		await _done()
		return
	service.order(JobBackup.new(nozzle.body), backup)
	var near: = 0
	var samples: = 0
	var gap_most: = 0.0
	var waited: = 0.0
	while waited < 90.0 and not FireService.current.incident.is_empty():
		await _wait(0.5)
		waited += 0.5
		if HoseService.current.line_of(nozzle.body) == null or not backup.job is JobBackup:
			continue
		var gap: = backup.body.global_position.distance_to(nozzle.body.global_position)
		samples += 1
		near += 1 if gap < float(Config.Crew.Pair.Behind) + 4.0 else 0
		gap_most = maxf(gap_most, gap)
		if samples == 20:
			_view(nozzle.body.global_position + Vector3(14, 12, 14), nozzle.body.global_position)
			await _snap("pair")
	print("crewpair: %d samples on the line, %d within %.1f studs (furthest %.1f)" % [samples, near, float(Config.Crew.Pair.Behind) + 4.0, gap_most])
	_check(samples >= 10, "the nozzle works a line with the backup on")
	_check(samples > 0 and float(near) / float(samples) >= 0.7, "the backup keeps a few studs behind the nozzle")
	await _done()





func _scenario_crewtasks() -> void :
	await _wait(1.5)
	Config.Victims["SmokeDrain"] = 0.0
	var house: = await _house_fire(1, "maybe")
	await _arrive(house.approach if house.approach != null else house.position, 30.0)
	var service: = CrewService.current
	service.auto = false
	var board: HudIncidentBoard = Hud.current.widgets["crew_panel"]
	await _wait(1.0)
	var tasks: = CrewTasks.open_tasks(service)
	print("crewtasks: %s" % [tasks.map( func(t: Dictionary) -> String: return "%s [%s]" % [Text.say(t["text"], "en"), Text.say(HudIncidentBoard.owners(t), "en")])])
	_check(board.visible and board._plate.visible, "the tasks show under the crew panel at a call")
	var search_first: = not tasks.is_empty() and "search" in (tasks[0]["kinds"] as Array)
	_check(search_first, "people first: the search tops the list")
	_check(tasks.size() >= 2, "more than one task is open (the fire, the water)")
	await _snap("short")
	board.open()
	await _wait(0.5)
	await _snap("full")
	_check(board._full.visible and board._full_rows.get_child_count() >= tasks.size(), "the whole board lists every open task")
	var search_task: Dictionary = {}
	for task: Dictionary in board._tasks:
		if "search" in (task["kinds"] as Array):
			search_task = task
	if not search_task.is_empty():
		board._assign(search_task)
	await _wait(1.0)
	board.close()
	tasks = CrewTasks.open_tasks(service)
	var owned: = false
	for task: Dictionary in tasks:
		if "search" in (task["kinds"] as Array):
			owned = not (task["who"] as Array).is_empty()
	print("crewtasks: after assigning: %s" % [tasks.map( func(t: Dictionary) -> String: return "%s [%s]" % [Text.say(t["text"], "en"), Text.say(HudIncidentBoard.owners(t), "en")])])
	_check(owned, "a task assigned from the board is taken up, and the board says who is on it")
	await _wait(1.0)
	await _snap("assigned")

	var mind: = service.members[0]
	var failed: = JobForceDoor.new(house, house.doors.values()[0])
	failed.who = mind
	failed.ordered = false
	failed.fail("crew.say.noTool", [Text.named("tools", "Halligan bar")])
	var told: = [0]
	var listen: = func(text: Variant, _kind: String, _to: Player) -> void :
		if Text.say(text, "en").contains("Orders?"):
			told[0] += 1
	Game.notified.connect(listen)
	service.job_failed(mind, failed)
	service.job_failed(mind, failed)
	await _wait(0.3)
	Game.notified.disconnect(listen)
	_check(told[0] == 1 and not service._markers.is_empty(), "a twice-failed Auto job is told once, with why, and marked where")

	service.arrival = {"search": true}
	var rescuer: Crewman = null
	for each in service.members:
		if each.role == "rescue":
			rescuer = each
	if rescuer != null:
		rescuer.stand_down()
		await _wait(0.5)
		CrewAuto.arrival_orders(service, rescuer)
		await _wait(0.3)
		_check(rescuer.job is JobSearch and service.arrival.is_empty(), "an order from the cab is taken up as the crew gets out")
	await _done()





func _scenario_crewflood() -> void :
	await _wait(1.5)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]
	var flood: = FloodedCellar.current
	CallService.current.run_call("flood", flood.run)
	await _until( func() -> bool: return not flood.source.is_empty(), 10.0)
	var hatch: Dictionary = flood._hatch
	if not _check( not hatch.is_empty(), "a flooded cellar call starts"):
		await _done()
		return
	await _arrive(flood.position, 35.0)
	_full_auto()
	CrewService.current.all_work()
	var power_first: = [true]
	var power_off_by_crew: = [false]
	var crew_pumps: = [0]
	var waited: = 0.0
	var seen_pumps: = 0
	while waited < 125.0 and not Game.incident.is_empty() and Game.incident.get("kind") == "flood":
		await _wait(0.5)
		waited += 0.5
		if hatch["power"] and not (hatch["pumps"] as Array).is_empty():
			power_first[0] = false
		if not hatch["power"] and not power_off_by_crew[0]:
			power_off_by_crew[0] = true
			print("crewflood: power off at %.0f s" % waited)
		var laid: = 0
		for pump: Dictionary in hatch["pumps"]:
			laid += 1 if pump["drain"] else 0
		if laid > seen_pumps:
			seen_pumps = laid
			print("crewflood: %d pumps laid to the drain at %.0f s" % [laid, waited])
			if laid == 1:
				_view(flood.position + Vector3(14, 12, 14), flood.position)
				await _snap("pumping")

			Config.Incidents.Flood["PumpFlow"] = 300.0
		crew_pumps[0] = laid
		if int(waited * 2.0) % 20 == 0:
			_trace_jobs("crewflood %.0f s" % waited)
	print("crewflood: over %s; power first %s, pumps laid %d" % [Game.incident.get("kind") != "flood", power_first[0], crew_pumps[0]])
	_check(power_off_by_crew[0] and power_first[0], "the crew switches the power off before any pump goes in")
	_check(crew_pumps[0] >= 1, "the crew carries a pump from the pumper and lays its hose to the drain")
	_check(Game.incident.is_empty() or Game.incident.get("kind") != "flood", "the cellar is pumped dry by the crew")
	await _done()





func _scenario_crewhazmat() -> void :
	await _wait(1.5)
	var leak: = HazmatLeak.current
	if not _check(leak != null, "the industrial zone has a hazmat leak to call"):
		await _done()
		return
	Alarm.forced = 1
	Alarm.forced_complications = ["drain"]
	leak.forced_source = "tanks"
	CallService.current.run_call("hazmat", leak.run)
	await _until( func() -> bool: return not leak._leak.is_empty(), 10.0)
	if not _check( not leak._leak.is_empty(), "a petrol leak call starts"):
		await _done()
		return
	var at: Vector3 = leak._leak["leak"]
	print("crewhazmat: leak at %s, drain %s" % [at, leak._leak.get("drain")])

	var gate: Vector3 = Game.incident.get("approach", at)
	await _arrive(gate, 12.0)
	for mind in _crew():
		mind.member["level"] = 2
	_full_auto()
	CrewService.current.all_work()
	var done: = {}
	var waited: = 0.0
	while waited < 125.0 and not Game.incident.is_empty() and Game.incident.get("kind") == "hazmat":
		await _wait(0.5)
		waited += 0.5
		var now: = {"cordon": leak._leak.get("cordon", false), "drain": leak._leak.get("drain_covered", false), "foam": leak._leak.get("foamed", false), 
			"valve": not leak._leak.get("leaking", true), "carried": not VictimService.current.waiting(), "cloud": float(leak._leak.get("cloud", 1.0)) <= 0.06}
		for key: String in now:
			if now[key] and not done.has(key):
				done[key] = waited
				print("crewhazmat: %s at %.0f s" % [key, waited])
				if key == "valve":
					_view(at + Vector3(20, 16, 20), at)
					await _snap("shut")
		if int(waited * 2.0) % 20 == 0:
			_trace_jobs("crewhazmat %.0f s (cloud %.2f, decon left %d)" % [waited, float(leak._leak.get("cloud", 0.0)), leak._decon_left()])
	var over: bool = Game.incident.is_empty() or Game.incident.get("kind") != "hazmat"

	if over and done.has("valve") and not done.has("cloud"):
		done["cloud"] = waited
	print("crewhazmat: done %s; over %s" % [done, over])
	_check(done.has("cordon"), "the crew cones the area off")
	_check(done.has("drain"), "the crew covers the drain")
	_check(done.has("carried"), "the crew carries the casualties out")
	_check(done.has("foam"), "a trained member lays foam on the pool")
	_check(done.has("valve"), "a trained member in a set shuts the valve")
	_check(done.has("cloud"), "the vapour is fogged down")
	_check(Game.incident.is_empty() or Game.incident.get("kind") != "hazmat", "the leak is done by the crew, decon and all")
	await _done()





func _scenario_crewmedical() -> void :
	await _wait(1.5)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]
	var medical: = LockedIn.current

	var kept: = medical._houses.duplicate()
	var homes: = medical._houses.filter( func(h: House) -> bool: return h.name.begins_with("Family"))
	if not homes.is_empty():
		medical._houses.assign(homes)
	CallService.current.run_call("medical", medical.run)
	await _until( func() -> bool: return not medical.scene.is_empty(), 10.0)
	if not _check( not medical.scene.is_empty() and medical.house != null, "a medical call starts"):
		await _done()
		return
	medical._houses.assign(kept)
	var house: = medical.house
	var scene: Dictionary = medical.scene
	var patient: Victim = VictimService.current.victims[0]
	print("crewmedical: %s, the patient in %s, neighbour has a key %s" % [house.name, patient.room, scene["has_key"]])
	await _arrive(house.approach if house.approach != null else house.position, 30.0)
	_full_auto()
	CrewService.current.all_work()
	var front: Variant = house.outside_door()
	var asked_first: = [true]
	var found: = [false]
	var waited: = 0.0
	while waited < 125.0 and not Game.incident.is_empty() and Game.incident.get("kind") == "medical":
		await _wait(0.5)
		waited += 0.5
		if front is Dictionary and not front["locked"] and not scene["asked"]:
			asked_first[0] = false
		if patient.found and not found[0]:
			found[0] = true
			print("crewmedical: found at %.0f s" % waited)
		if int(waited * 2.0) % 20 == 0:
			_trace_jobs("crewmedical %.0f s (asked %s, door locked %s, aided %s)" % [waited, scene.get("asked"), front["locked"] if front is Dictionary else "-", scene.get("aided")])
	print("crewmedical: over %s; asked first %s, found %s, aided %s" % [Game.incident.get("kind") != "medical", asked_first[0], found[0], scene.get("aided")])
	_check(asked_first[0] and scene.get("asked", false), "the crew asks the neighbour for a key before any door is forced")
	_check(found[0], "the crew searches the house and finds the patient")
	_check(scene.get("aided", false) == true, "the crew gives first aid with the kit before the lift")
	_check(Game.incident.is_empty() or Game.incident.get("kind") != "medical", "the patient is carried out to the medics")
	await _done()





func _scenario_crewroles() -> void :
	await _wait(2.0)
	var service: = CrewService.current
	var board: = CrewBoard.current
	player.set_attr("Cash", 9000)
	board.open()
	board._hire()
	await _wait(0.4)
	var candidates: = service.roster.draw_candidates()
	print("crewroles: candidates %s" % [candidates])
	await _snap("candidates")
	_check(candidates.size() >= 2, "hiring offers several candidates")
	var different: = false
	for candidate: Dictionary in candidates:
		different = different or str(candidate["trait"]) != str(candidates[0]["trait"]) or str(candidate["role"]) != str(candidates[0]["role"])
	_check(different, "the candidates differ in position or trait")
	var had: = service.roster.members.size()
	var chosen: Dictionary = candidates[1]
	board._hire_candidate(1)
	await _wait(0.5)
	var newest: Dictionary = service.roster.members[service.roster.members.size() - 1]
	_check(service.roster.members.size() == had + 1 and newest["name"] == chosen["name"] and newest["trait"] == chosen["trait"], "the chosen candidate joins with their position and trait")
	board._page_to("roles")
	await _wait(0.3)
	await _snap("roles")
	var mind: = service.members[0]
	var before: = mind.role
	board._swap(mind.member)
	await _wait(0.3)
	_check(mind.role != before and mind.member["role"] == mind.role, "a member's position is changed at the board")
	var stripe_pattern: String = mind._stripes[0].get_meta("pattern", "") if not mind._stripes.is_empty() else ""
	_check( not mind._stripes.is_empty() and stripe_pattern == CrewRoster.role_pattern(mind.role), "the band on the arm takes the new position's pattern")
	board._page_to("main")
	await _wait(0.3)
	await _snap("main")
	board.close()
	_check( not CrewAuto.trained(mind, "Hazmat") and Text.has("crew.board.unlock.2"), "hazmat on Auto waits for training, and the board says what a level unlocks")

	var middle: = player.global_position + player.facing() * 8.0
	var across: = player.facing().cross(Vector3.UP).normalized()
	for each in service.members:
		var spot: = service.ground(middle + across * (each.slot * 2.6 - 4.0) + Vector3(0, 1, 0)) + Vector3(0, 0.2, 0)
		each.mode = "hold"
		each.hold_at = spot
		each.body.teleport(spot)
		each.body.rig.rotation.y = player.rig.rotation.y
	await _wait(0.6)
	for each in service.members:
		each.look = each.body.global_position + player.facing() * 20.0
	_view(middle - player.facing() * 7.0 + Vector3(0, 6, 0), middle + Vector3(0, 4, 0))
	await _snap("stripes_back")
	_view(middle + player.facing() * 7.0 + Vector3(3, 5, 0), middle + Vector3(0, 4, 0))
	await _snap("stripes_front")
	await _done()
