class_name Victims
extends RefCounted




static var service: Node


static func begin(building: Building, scenario: Variant) -> int:
	return service.begin(building, scenario) if service else 0


static func step(dt: float, smoke_at: Callable, burning: bool) -> void :
	if service:
		service.step(dt, smoke_at, burning)


static func waiting() -> bool:
	return service.waiting() if service else false


static func building_lost() -> void :
	if service:
		service.building_lost()



static func finish() -> Dictionary:
	return service.finish() if service else {"total": 0, "out": 0, "lost": 0}



static func shown() -> Dictionary:
	return service.shown() if service else {}



static func report_words() -> Variant:
	return service.report_words() if service else null



static func next_words() -> Variant:
	return service.next_words() if service else null
