class_name HudChecklist
extends Control




const WIDTH: = 400.0
const ROW: = 30.0

static var current: HudChecklist

var _plate: Control
var _title: Label
var _rows: Array = []
var _title_words: Variant = null


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, 60))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 120)
	_title = Ui.caps("", int(Config.Hud.CapsFloor))
	_title.position = Vector2(14, 10)
	_plate.add_child(_title)
	Text.language_changed.connect( func(_code: String) -> void : _say())


func _exit_tree() -> void :
	if current == self:
		current = null



func show_list(title: Variant, steps: Array) -> void :
	for row: Dictionary in _rows:
		row["box"].queue_free()
		row["words"].queue_free()
	_rows.clear()
	_title_words = title
	var y: = 38.0
	for step: Array in steps:
		var box: = Ui.icon("dot", 20, Ui.DIM)
		box.position = Vector2(14, y + 4)
		_plate.add_child(box)
		var words: = Ui.label("", 17)
		words.position = Vector2(44, y)
		words.size = Vector2(WIDTH - 56, ROW)
		words.clip_text = true
		words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		_plate.add_child(words)
		_rows.append({"key": step[0], "box": box, "words": words, "message": step[1], "done": false})
		y += ROW
	_plate.size = Vector2(WIDTH, y + 10)
	_plate.visible = true
	_say()



func tick(key: String) -> bool:
	for row: Dictionary in _rows:
		if row["key"] == key and not row["done"]:
			row["done"] = true
			Sounds.ui(String(Config.Onboarding.FirstShift["TickSound"]))
			_say()
			return true
	return false


func is_done(key: String) -> bool:
	for row: Dictionary in _rows:
		if row["key"] == key:
			return row["done"]
	return false



func current_step() -> String:
	for row: Dictionary in _rows:
		if not row["done"]:
			return row["key"]
	return ""


func close() -> void :
	_plate.visible = false
	_rows.clear()


func showing() -> bool:
	return _plate.visible


func _say() -> void :
	_title.text = Text.say(_title_words).to_upper() if _title_words != null else ""
	var first: = current_step()
	for row: Dictionary in _rows:
		var words: Label = row["words"]
		words.text = Text.say(row["message"])
		var box: TextureRect = row["box"]
		box.texture = Ui.icon_texture("check" if row["done"] else "dot")
		box.modulate = Ui.state(Ui.GREEN) if row["done"] else (Ui.YELLOW if row["key"] == first else Ui.DIM)
		words.add_theme_color_override("font_color", Ui.DIM if row["done"] else (Ui.YELLOW if row["key"] == first else Ui.TEXT))


func _process(_delta: float) -> void :
	if not _plate.visible:
		return

	var top: = 300.0
	if HudDispatch.current:
		top = maxf(top, HudDispatch.current.card_bottom() + 24.0)

	for key: String in ["duty", "debrief"]:
		var widget: Variant = Hud.current.widgets.get(key) if Hud.current else null
		if widget is Control and (widget as Control).is_visible_in_tree():
			var plate: Variant = widget.get("_plate")
			if plate is Control and (plate as Control).visible:

				top = maxf(top, Hud.to_hud((plate as Control).get_global_rect().end).y + 24.0)
	var view: = get_parent_area_size()
	top = minf(top, view.y - _plate.size.y - 150.0)
	_plate.position = Vector2(Ui.MARGIN, top)
