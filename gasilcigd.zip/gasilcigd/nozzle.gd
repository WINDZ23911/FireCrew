class_name Nozzle
extends Node3D











var tip: Node3D
var hose_in: Node3D
var open: = false
var flow_step: = 2
var fog: = false
var flowing: = false

var _body: Node3D
var _bale: Node3D
var _ring: Node3D
var _sleeve: Node3D
var _bale_turn: = 0.0
var _was_open: = false
var _time: = 0.0

static var _looks: Dictionary = {}


static func _look(key: String, color: Color, roughness: float, metallic: = 0.0) -> StandardMaterial3D:
	if not _looks.has(key):
		var material: = StandardMaterial3D.new()
		material.albedo_color = color
		material.roughness = roughness
		material.metallic = metallic
		_looks[key] = material
	return _looks[key]


func _ready() -> void :
	var alloy: = _look("alloy", Color(0.74, 0.75, 0.77), 0.32, 0.85)
	var red: = _look("red", Color(0.72, 0.1, 0.09), 0.38, 0.35)
	var rubber: = _look("rubber", Color(0.07, 0.07, 0.08), 0.85)
	var knurl: = _look("knurl", Color(0.16, 0.16, 0.17), 0.55, 0.5)
	var mark: = _look("mark", Color(0.95, 0.95, 0.9), 0.5)
	var hole: = _look("hole", Color(0.02, 0.02, 0.02), 1.0)
	_body = Node3D.new()
	add_child(_body)
	_bale = _pivot(Vector3(0, 0.3, -0.1))
	_ring = _pivot(Vector3(0, 0, -0.7))
	_sleeve = _pivot(Vector3(0, 0, -1.45))

	_tube(0.28, 0.28, 0.2, 0.4, alloy)
	_tube(0.17, 0.17, 0.02, 0.505, hole)
	for side: float in [-1.0, 1.0]:
		_block(Vector3(0.12, 0.12, 0.14), Vector3(side * 0.3, 0, 0.4), alloy)
	_tube(0.22, 0.22, 0.16, 0.22, knurl)
	_tube(0.25, 0.25, 0.5, -0.1, red)
	_block(Vector3(0.36, 0.16, 0.42), Vector3(0, 0.22, -0.1), red)

	var lean: = Basis(Vector3.RIGHT, deg_to_rad(14.0))
	_block(Vector3(0.24, 0.78, 0.34), Vector3(0, -0.5, 0.02), rubber, lean)
	for ridge in 3:
		_block(Vector3(0.26, 0.06, 0.06), Vector3(0, -0.32 - ridge * 0.2, -0.17 + ridge * 0.05), rubber, lean)

	for side: float in [-1.0, 1.0]:
		_block(Vector3(0.05, 0.08, 0.62), Vector3(side * 0.27, 0.32, -0.38), red, Basis(Vector3.RIGHT, deg_to_rad(20.0)), _bale)
	_rod(0.06, 0.6, Vector3(0, 0.42, -0.66), rubber, _bale)
	_tube(0.23, 0.2, 0.8, -0.75, alloy)
	_tube(0.26, 0.26, 0.16, -0.7, knurl, _ring)
	_block(Vector3(0.05, 0.05, 0.12), Vector3(0, 0.27, -0.7), mark, Basis.IDENTITY, _ring)
	_tube(0.27, 0.3, 0.34, -1.32, red, _sleeve)
	_tube(0.34, 0.34, 0.16, -1.57, rubber, _sleeve)
	for tooth in 10:
		var turn: = TAU * tooth / 10.0
		_block(Vector3(0.07, 0.1, 0.08), Vector3(cos(turn) * 0.26, sin(turn) * 0.26, -1.66), rubber, Basis(Vector3.BACK, turn), _sleeve)
	_tube(0.14, 0.14, 0.02, -1.66, hole, _sleeve)
	tip = Node3D.new()
	tip.position = Vector3(0, 0, -1.7)
	add_child(tip)
	hose_in = Node3D.new()
	hose_in.position = Vector3(0, 0, 0.5)
	add_child(hose_in)



func _pivot(at: Vector3) -> Node3D:
	var holder: = Node3D.new()
	holder.position = at
	_body.add_child(holder)
	var inner: = Node3D.new()
	inner.position = - at
	holder.add_child(inner)
	return inner


func _process(delta: float) -> void :
	_time += delta
	var kick: Dictionary = Config.Water.Kick

	if open != _was_open:
		_was_open = open
		Sounds.once(self, "nozzle_bale", 0.5, 4.0, 40.0, 1.0 if open else 0.85)
	_bale_turn = move_toward(_bale_turn, 1.0 if open else 0.0, delta * 8.0)
	_bale.get_parent().rotation.x = deg_to_rad(float(kick["BaleAngle"])) * _bale_turn

	var ring_goal: = deg_to_rad(float(kick["RingStep"])) * float(flow_step - 2)
	var ring: Node3D = _ring.get_parent()
	ring.rotation.z = lerp_angle(ring.rotation.z, ring_goal, 1.0 - exp( - delta * 12.0))
	var sleeve: Node3D = _sleeve.get_parent()
	sleeve.rotation.z = lerp_angle(sleeve.rotation.z, deg_to_rad(float(kick["SleeveTurn"])) if fog else 0.0, 1.0 - exp( - delta * 10.0))
	sleeve.position.z = lerpf(sleeve.position.z, -1.45 - (float(kick["SleeveSlide"]) if fog else 0.0), 1.0 - exp( - delta * 10.0))

	var push: = float(kick["Recoil"]) if flowing else 0.0
	var shake: = Vector3(sin(_time * 31.0) + sin(_time * 47.0), cos(_time * 37.0) + sin(_time * 23.0), 0.0) * float(kick["Shake"]) * (1.0 if flowing else 0.0)
	_body.position = _body.position.lerp(Vector3(0, 0, push) + shake, 1.0 - exp( - delta * 18.0))




func _tube(back: float, front: float, length: float, z: float, material: Material, into: Node3D = null) -> void :
	var mesh: = CylinderMesh.new()
	mesh.top_radius = front
	mesh.bottom_radius = back
	mesh.height = length
	mesh.radial_segments = 16
	mesh.rings = 1

	_add(mesh, Transform3D(Basis(Vector3.RIGHT, - PI / 2.0), Vector3(0, 0, z)), material, into)


func _rod(radius: float, length: float, at: Vector3, material: Material, into: Node3D = null) -> void :
	var mesh: = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = length
	mesh.radial_segments = 8
	_add(mesh, Transform3D(Basis(Vector3.BACK, PI / 2.0), at), material, into)


func _block(size: Vector3, at: Vector3, material: Material, turn: = Basis.IDENTITY, into: Node3D = null) -> void :
	var mesh: = BoxMesh.new()
	mesh.size = size
	_add(mesh, Transform3D(turn, at), material, into)


func _add(mesh: Mesh, place: Transform3D, material: Material, into: Node3D = null) -> void :
	var piece: = MeshInstance3D.new()
	piece.mesh = mesh
	piece.material_override = material
	(into if into != null else _body).add_child(piece)
	piece.transform = place



func hold_kind() -> String:
	return "nozzle"
