extends ProofDebug






const LINEUP: = [
	["blue", "helmetBlue", false], 
	["sand", "helmetSand", false], 
	["", "helmetWhite", false], 
	["", "helmetRed", true], 
	["gold", "helmetGold", false], 
	["redblue", "helmetOrange", false], 
]
const SPACING: = 4.6

const PULL: = 17.0
const DISTANCE: = 27.0
const SIDE: = 0.0
const HEIGHT: = 3.5
const LOOK: = 1.5
const FOV: = 60.0
const HOUR: = 10.5


func _scenario_splash_crew() -> void :
	DisplayServer.window_set_size(Vector2i(1920, 1080))
	await _wait(3.0)
	var service: = CrewService.current

	var stand_ins: = ["Nina", "Rok", "Ana", "Luka", "Eva"]
	while service and service.members.size() < LINEUP.size() - 1:
		var index: = service.members.size()
		service._make({"name": stand_ins[index], "role": "nozzle", "level": 1, "xp": 0, "colour": index}, index, player)
	var crew: Array = service.members if service else []
	_check(crew.size() >= LINEUP.size() - 1, "there is a crew to stand in a row")
	var bodies: Array[Player] = []
	for index in mini(crew.size(), LINEUP.size() - 1):
		bodies.append((crew[index] as Crewman).body)

	bodies.insert(2, player)
	var station: = Game.station
	var front: = float(station.front) if station else -50.0
	for bay in 4:
		if station:
			station.set_door(bay, true)

	var centre: = Vector3(-27.0, 0.0, front + 22.0)
	var camera_at: = centre + Vector3(0, 3.2, 27.0)
	var gear: = GearService.current
	for index in bodies.size():
		var body: Player = bodies[index]
		var look: Array = LINEUP[index]
		var spot: = _ground(centre + Vector3((index - (bodies.size() - 1) / 2.0) * SPACING, 0, absf(index - 2.5) * 0.9))
		body.teleport(spot + Vector3(0, 0.2, 0))
		var sheets: = gear.suit_sheets(null if String(look[0]).is_empty() else look[0])
		sheets[look[1] if gear.has_sheet(look[1]) else "helmet"] = true
		body.rig.wear(sheets)
		body.set_attr("Geared", true)
		if look[2]:
			body.set_attr("ChemSuit", true)
	for member: Crewman in crew:
		member.mode = "hold"
		member.hold_at = member.body.global_position
		member.look = camera_at
		member._tag.text = ""
	await _wait(1.5)

	for body in bodies:
		var toward: = camera_at.lerp(centre + Vector3(0, 0, 40), 0.5) - body.global_position
		body.rig.rotation.y = atan2( - toward.x, - toward.z)
		if body == player:
			player.camera.yaw = body.rig.rotation.y
			player.camera.pitch = 0.0
	_view(camera_at, centre + Vector3(0, 4.2, 0), 42.0)
	if Hud.current:
		Hud.current.visible = false
	await _wait(1.0)
	_check(ChemSuit.wearing(bodies[3]), "one of them wears the chemical suit")
	await _snap("lineup")
	_done()





func _scenario_splash_fleet() -> void :
	DisplayServer.window_set_size(Vector2i(1920, 1080))
	Style.choose(Style.SUMMER)
	if Sky3D.current:
		Sky3D.current.set_hour(HOUR)
	if Traffic.current:
		Traffic.current.process_mode = Node.PROCESS_MODE_DISABLED
	await _wait(3.0)
	var station: = Game.station
	for bay in 4:
		if station:
			station.set_door(bay, true)
	var ladder: Vehicle = null
	var trucks: Array[Vehicle] = []
	for vehicle: Vehicle in Vehicle.all:
		print("splash: %s at %s facing %s" % [vehicle.spec["name"], vehicle.global_position, - vehicle.global_basis.z])
		vehicle.headlights_on = true
		vehicle.blue_on = true
		trucks.append(vehicle)
		if String(vehicle.spec["name"]).to_lower().contains("ladder"):
			ladder = vehicle
	_check(ladder != null, "the ladder truck is in the fleet")


	var tanker: Vehicle = null
	for vehicle in trucks:
		if String(vehicle.spec["name"]) == "Tanker":
			tanker = vehicle
	var bays: = {}
	for vehicle in trucks:
		bays[vehicle] = vehicle.global_position
	if tanker:
		bays[tanker] = ladder.global_position
		bays[ladder] = tanker.global_position
	var noses: = {}
	for vehicle in trucks:
		var out: = vehicle.global_basis * Vector3(0, 0, signf(float(vehicle.data["front"])))
		out.y = 0.0
		noses[vehicle] = out.normalized()
	for vehicle in trucks:

		vehicle.global_transform = Transform3D(vehicle.global_basis, bays[vehicle] + noses[vehicle] * PULL)
		vehicle.linear_velocity = Vector3.ZERO
		vehicle.angular_velocity = Vector3.ZERO
		vehicle.reset_physics_interpolation()
	player.teleport(Vector3(400, 3, 400))
	if Hud.current:
		Hud.current.visible = false
	await _wait(2.0)

	var pumper: = trucks[0]
	for vehicle in trucks:
		if String(vehicle.spec["name"]) == "Fire Truck":
			pumper = vehicle
	var middle: = ladder.global_position.lerp(pumper.global_position, 0.5 + SIDE)
	var out: Vector3 = noses[ladder]
	var nose: = middle + out * - float(ladder.data["front"])
	_view(nose + out * DISTANCE + Vector3(0, HEIGHT, 0), nose + Vector3(0, LOOK, 0) - out * 4.0, FOV)
	await _wait(1.0)
	await _snap("fleet")
	_done()
