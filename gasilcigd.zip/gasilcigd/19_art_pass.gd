extends RefCounted







static func start(main: Node) -> void :
	var windows: = WindowFire.new()
	windows.name = "WindowFire"
	main.add_child(windows)
	var focus: = FocusRim.new()
	focus.name = "FocusRim"
	main.add_child(focus)
	var couplings: = CouplingMarks.new()
	couplings.name = "CouplingMarks"
	main.add_child(couplings)
	var rings: = CasualtyRings.new()
	rings.name = "CasualtyRings"
	main.add_child(rings)
	var grade: = InteriorGrade.new()
	grade.name = "InteriorGrade"
	main.add_child(grade)
	( func() -> void :
		HydrantCollars.paint()
		if Game.world != null:
			var posters: = StationPosters.new()
			posters.name = "StationPosters"
			Game.world.add_child(posters)
	).call_deferred()
