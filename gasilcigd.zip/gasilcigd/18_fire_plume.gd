extends RefCounted



static func start(main: Node) -> void :
	var plume: = FirePlume.new()
	plume.name = "FirePlume"
	main.add_child(plume)
