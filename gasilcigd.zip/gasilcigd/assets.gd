extends Node







const OWN: = ["res://assets/audio/made", "res://assets/audio/recorded"]
const RECORDED: = "res://assets/audio/recorded"

var _ids: Dictionary = {}
var _names: Dictionary = {}
var _cache: Dictionary = {}
var _recorded: Dictionary = {}


func _init() -> void :
	var listing: Variant = Rbx.load_json("res://data/asset_ids.json")
	if listing:
		_ids = listing["ids"]
		_names = listing["names"]
	var folders: Array = OWN.duplicate()
	if not Edition.is_metlika():
		folders.append("res://assets/editions/%s/audio/made" % Edition.id())
	for folder: String in folders:
		for file in ResourceLoader.list_directory(folder):
			if file.get_extension() in ["wav", "ogg", "mp3"]:
				_names[file.get_basename()] = folder + "/" + file
				if folder == RECORDED:
					_recorded[file.get_basename()] = folder + "/" + file



func path(asset: Variant) -> String:
	var key: = str(asset)
	if key.begins_with("rbxassetid://"):
		key = key.substr(13)
	if key.is_valid_float() and float(key) == floorf(float(key)):
		key = str(int(float(key)))
	if _ids.has(key):
		var found: String = _ids[key]
		return _recorded.get(found.get_file().get_basename(), found)
	return _names.get(key, "")


func load_asset(asset: Variant) -> Resource:
	var where: = path(asset)
	if where.is_empty():
		return null


	if not Edition.is_metlika() and where.begins_with("res://assets/"):
		var own: = "res://assets/editions/%s/%s" % [Edition.id(), where.trim_prefix("res://assets/")]
		if ResourceLoader.exists(own):
			where = own
	if not _cache.has(where):
		_cache[where] = load(where) if ResourceLoader.exists(where) else null
	return _cache[where]


func texture(asset: Variant) -> Texture2D:
	return load_asset(asset) as Texture2D


func sound(asset: Variant) -> AudioStream:
	return load_asset(asset) as AudioStream
