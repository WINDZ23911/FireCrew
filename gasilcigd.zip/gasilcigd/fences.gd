extends ProofDebug




const NAMES: = ["FenceMesh", "FencePost", "FenceRail", "Fence", "FencePanel", "Picket", "Railing", "RailingPost", 
	"MeshFence", "Hedge"]


func _scenario_fences() -> void :
	await _wait(1.0)
	var store: = Game.store
	var roads: Array = Rbx.module("TownLayout")["roads"]
	var checked: = 0
	var on_road: Array[String] = []
	for part_name: String in NAMES:
		for row in store.rows_named(part_name):
			checked += 1
			var place: = store.transform(row)
			var size: = store.size(row)

			var along: = place.basis.x * size.x / 2.0 if size.x >= size.z else place.basis.z * size.z / 2.0
			for at: Vector3 in [place.origin - along, place.origin, place.origin + along]:
				var road: = _road_under(roads, Vector2(at.x, at.z))
				if not road.is_empty():
					on_road.append("%s at (%.1f, %.1f) on %s" % [part_name, at.x, at.z, road])
					break
	for line in on_road.slice(0, 20):
		print("fences: ", line)
	_check(checked > 1000, "the fences are found (%d parts)" % checked)
	_check(on_road.is_empty(), "no fence part stands on a road's carriageway (%d do)" % on_road.size())

	var corner: = Vector3(IndustryZone.PLOTS[4]["x"] - IndustryZone.PLOTS[4]["width"] / 2.0, 0, IndustryZone.YARD_BACK)
	_view(corner + Vector3(-30, 14, -26), corner + Vector3(4, 2, 30))
	await _wait(1.5)
	await _snap("corner")
	_view(corner + Vector3(0, 140, 20), corner + Vector3(0.1, 0, 21))
	await _wait(1.0)
	await _snap("above")
	await _done()



func _road_under(roads: Array, at: Vector2) -> String:
	for road: Dictionary in roads:
		var points: Array = road["points"]
		var half: = float(road["width"]) / 2.0 - 0.3
		for index in points.size() - 1:
			var a: = Vector2(points[index][0], points[index][1])
			var b: = Vector2(points[index + 1][0], points[index + 1][1])
			if Geometry2D.get_closest_point_to_segment(at, a, b).distance_to(at) < half:
				return str(road.get("name", road.get("key", "a road")))
	return ""
