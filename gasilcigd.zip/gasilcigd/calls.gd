extends ProofDebug










func _cash(someone: Player) -> int:
	return int(someone.get_attr("Cash", 0)) + int(someone.get_attr("Pending", 0))



func _crew(count: int) -> Array[Player]:
	var bodies: Array[Player] = []
	var service: = CrewService.current
	if service == null:
		return bodies
	for index in count:
		var entry: = service.roster._member("", "nozzle", 0, 0)
		var mind: = service._make(entry, service.members.size(), player)
		bodies.append(mind.body)
	return bodies


func _scenario_paycrew() -> void :
	await _wait(1.0)
	var bodies: = _crew(3)
	await _wait(0.5)
	if not _check(bodies.size() == 3 and bodies[0].brain != null, "three AI crew members stand by"):
		await _done()
		return


	var before: = _cash(player)
	CallKit.pay_helpers([player], 100, "bonus")
	var alone: = _cash(player) - before
	before = _cash(player)
	var everyone: Array = [player]
	everyone.append_array(bodies)
	CallKit.pay_helpers(everyone, 100, "bonus")
	var with_crew: = _cash(player) - before
	before = _cash(player)
	CallKit.pay_helpers(bodies, 100, "bonus")
	var crew_only: = _cash(player) - before
	print("paycrew: a reward of 100: alone +%d, with three of the crew +%d, by the crew alone +%d" % [alone, with_crew, crew_only])
	_check(alone == 100 and with_crew == alone and crew_only == alone, "a call's reward is paid once, however many of the crew helped")

	before = _cash(player)
	bodies[0].add_cash(10, "flameOut")
	_check(_cash(player) - before == 10, "a crew member's own piece of work pays the commander once")


	var fire: = FireService.current
	var house: = _house("Family house")
	VictimService.current.forced = 0
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	var rewards: Array = []
	player.rewarded.connect( func(amount: int, why: String) -> void : rewards.append([amount, why]))
	fire.run_incident(house)
	await _wait(1.0)
	var door: Dictionary = house.outside_door()
	_stand_outside(house, door["lock"].global_position, 16.0)
	for body in bodies:
		body.teleport(player.global_position + Vector3(randf_range(-4, 4), 0, randf_range(-4, 4)))
	var flames: = 0
	var waited: = 0.0
	while not fire.incident.is_empty() and waited < 20.0:
		fire.incident["contributors"][player] = true
		for body in bodies:
			fire.incident["contributors"][body] = true
		for node: Dictionary in fire.incident["group"]["nodes"]:
			node["heat"] = 0.0
			if node["burning"]:
				fire._extinguish(node, bodies[flames % bodies.size()])
				flames += 1
		await _wait(0.1)
		waited += 0.1
	await _wait(0.5)
	var bonuses: Array = rewards.filter( func(entry: Array) -> bool: return entry[1] == "bonus")
	var flame_pay: Array = rewards.filter( func(entry: Array) -> bool: return entry[1] == "flameOut")
	var crew_cash: = 0
	for body in bodies:
		crew_cash += _cash(body)
	print("paycrew: the fire is %s; %d flames put out by the crew paid %d times; the bonuses paid: %s; the crew's own cash %d" % ["out" if fire.incident.is_empty() else "STILL BURNING", flames, flame_pay.size(), bonuses, crew_cash])
	_check(fire.incident.is_empty(), "the fire is out")
	_check(bonuses.size() >= 1 and bonuses.size() <= 2, "the save bonus and the stars are paid once each, not once per crew member (%d bonus lines)" % bonuses.size())
	_check(flame_pay.size() == flames, "each flame the crew put out pays once")
	_check(crew_cash == 0, "the AI crew keep no cash of their own")
	await _done()


func _scenario_bottles() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var building: Building = null
	for candidate in fire.buildings:
		if candidate is House and not candidate.ruined:
			for entry: Dictionary in candidate.fuel:
				if entry["name"] == FireService.BOTTLES:
					building = candidate
		if building != null:
			break
	if not _check(building != null, "a building with gas bottles"):
		await _done()
		return
	var group: Dictionary = fire._group_of(building)
	var bottles: Dictionary = {}
	for node: Dictionary in group["nodes"]:
		if node["name"] == FireService.BOTTLES:
			bottles = node
	var materials: Dictionary = Config.Fire.Materials
	_check(bottles["kind"] == "cylinder" and bottles["material"] == materials["cylinder"], "the gas bottles are a cylinder, not fat")

	var keep: Array = building.scenarios
	var fat: Array = []
	for scenario: Dictionary in keep:
		for node: Dictionary in group["nodes"]:
			if node["name"] == scenario.get("origin") and node["kind"] == "grease":
				fat.append(scenario)
				break
	if not _check( not fat.is_empty(), "%s has a fire that starts in fat" % building.name):
		await _done()
		return
	building.scenarios = [fat[0]]
	Config.Fire["Traits"]["Force"] = "grease"
	VictimService.current.forced = 0
	fire.run_incident(building)
	await _wait(0.5)
	building.scenarios = keep
	print("bottles: %s at %s; traits %s" % [fat[0]["name"], building.name, fire.incident.get("traits")])
	_check(fire.has_trait("grease"), "the grease trait is drawn")
	if not bottles["burning"]:
		fire._ignite(bottles, 0.6)
	bottles["cooked"] = 30.0
	var at: Vector3 = bottles["position"]
	var away: = (at - building.position) * Vector3(1, 0, 1)
	var from: = at + away.normalized() * 6.0 + Vector3(0, 1.5, 0)
	player.teleport(CallKit.ground_at(from + Vector3(0, 2, 0)) + Vector3(0, 0.3, 0))
	_view(from + away.normalized() * 10.0 + Vector3(0, 6, 0), at)
	await _wait(1.0)
	var started: = Game.now()
	var cooked: = float(bottles["cooked"])
	var sprayed: = 0.0
	while sprayed < 2.0 and bottles["burning"]:
		fire.spray(player, PackedVector3Array([player.head_position(), at]), 0.25)
		await _wait(0.25)
		sprayed += 0.25
	await _snap("jet")
	print("bottles: a jet for %.2f s: burning %s, last wet %.2f s after it began, water damage %.1f, cooked %.1f -> %.1f" % [sprayed, bottles["burning"], float(bottles.get("last_sprayed", 0.0)) - started, float(bottles.get("damage", 0.0)), cooked, float(bottles["cooked"])])
	_check(float(bottles.get("last_sprayed", 0.0)) >= started, "the jet wets the bottles under the grease trait")
	_check( not bottles["burning"] or float(bottles["cooked"]) < cooked, "the water cools the bottles (or puts them out)")
	await _done()



func _gear_up() -> void :
	GearService.current._gear_up(player, null, true)
	AirService.current.take_set(player, "truck")
	await _wait(0.3)
	AirService.current._set_mask(player, true)
	await _wait(0.3)


func _stand_cones(at: Vector3, count: int, by: Variant) -> void :
	var cordon: = Cordon.current
	var item: Dictionary = {}
	for entry: Dictionary in cordon.items:
		if entry["name"] == "Cones" and cordon._cone_stock.get(entry["truck"], 0) >= count:
			item = entry
			break
	for index in count:
		var spot: = at + Vector3((index * 2 - 1) * 30.0, 0, 20.0 + index * 3.0)
		var cone: = cordon.stand_cone_at(item["truck"], Transform3D(Basis(), CallKit.ground_at(spot + Vector3(0, 3, 0))))
		if by != null:
			cone["by"] = by


func _scenario_hazmatcordon() -> void :
	await _wait(1.0)
	var leak: = HazmatLeak.current
	if not _check(leak != null and Cordon.current != null, "the leak's call and the cones are there"):
		await _done()
		return
	leak.forced_source = "tanker"
	var at: = Vector3.ZERO
	for source: Dictionary in leak._sources:
		if source["id"] == "tanker":
			at = source["leak"]

	_stand_cones(at, 2, null)
	CallService.current.run_call("hazmat", leak.run)
	var waited: = 0.0
	while leak._leak.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(1.0)
	var state: Dictionary = leak._leak
	var cordon_line: = Text.say(Text.f("calls.hazmat.next.cordonCount", [0, int(Config.Incidents.Hazmat.CordonNeeded)]), "en")
	print("hazmat: the card: %s; cordon %s" % [Text.say(Game.incident.get("scene_next", Game.incident.get("next", "-")), "en"), state["cordon"]])
	_check( not state["cordon"], "cones put up before the call came in do not close it off")
	_check(Text.say(Game.incident.get("scene_next", Game.incident.get("next", "-")), "en") == cordon_line, "the card asks for the cordon first")
	await _gear_up()
	var prompt: Prompt = Prompt.by_id.get("hazmat.valve")
	player.teleport(prompt.global_position + Vector3(1.5, 0, 1.5))
	await _wait(0.4)
	var tasks: Array = Game.incident.get("tasks", [])
	print("hazmat: %d jobs on the card: %s" % [tasks.size(), ", ".join(tasks.map( func(task: Dictionary) -> String: return Text.say(task["t"], "en")))])
	_check(tasks.size() >= 5 and tasks.filter( func(task: Dictionary) -> bool: return task.get("next", false)).size() == 1, "the card lists every job, one marked next")
	prompt.triggered.emit(player)
	await _wait(0.3)
	_check( not state["leaking"], "the valve shuts before the area is closed off too: no job waits on another")
	var before: = _cash(player)
	_stand_cones(at, 2, player)
	await _wait(1.0)
	print("hazmat: two cones after the call came in: cordon %s, +%d; the card: %s" % [state["cordon"], _cash(player) - before, Text.say(Game.incident.get("next", "-"), "en")])
	_check(state["cordon"], "cones put up after the call came in close the area off")
	_check(_cash(player) - before == Alarm.pay(int(Config.Incidents.Hazmat.CordonReward)), "whoever stood them is paid for the cordon, at the level's rate")
	_check(int(Game.incident.get("done", 0)) >= 1 and int(Game.incident.get("total", 0)) == 4, "the cordon is one of the card's four jobs")
	_view(at + Vector3(30, 20, 30), at)
	await _snap("cordon")
	await _done()


func _scenario_finalcard() -> void :
	await _wait(1.0)
	Config.Incidents["CloseAfter"] = 20.0
	var report: Array = [{}]
	CallService.current.debriefed.connect( func(made: Dictionary) -> void : report[0] = made)
	var told: Array = []
	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void : told.append([Text.say(text, "en"), kind]))
	var held: = await _start_crash("headOn", 1.0)
	if not _check( not held.is_empty(), "a crash came"):
		await _done()
		return
	var total: = VictimService.current.total
	print("finalcard: %d trapped; nobody goes; the card: %s" % [total, HudDispatch.current.shown_text()])
	var waited: = 0.0
	while not Game.incident.is_empty() and waited < 40.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(1.0)
	var card: = HudDispatch.current.shown_text()
	print("finalcard: the final card: %s" % card)
	await _snap("final")
	var people: = Text.say(Text.f("hud.dispatch.peopleFinal", [0, total, total, 0]))
	_check(Game.incident.is_empty(), "the call came down when its time ran out")
	_check( not card.is_empty() and !("→" in card), "the final card shows no next step")
	_check(people in card, "the final card counts the people by the crew, by the medics and lost (%s)" % people)
	_check(Text.say(Text.m("hud.dispatch.kinds.crash.bad")) in card, "the final card says the call was closed")
	var tally: = Text.say(Text.f("calls.victims.tally", [0, total, total, 0]), "en")
	var said: Array = told.filter( func(entry: Array) -> bool: return entry[0] == tally)
	_check( not said.is_empty() and said[0][1] == "warning", "the message says the medics fetched them, as a warning")
	var counted: Array = report[0].get("people", [])
	print("finalcard: debrief %s, people %s" % [report[0].get("grade", "-"), counted])
	_check(counted.size() == 4 and int(counted[0]) == 0 and int(counted[1]) == total and int(counted[2]) == total, "the debrief counts the same")
	await _done()





func _scenario_hazmatdecon() -> void :
	await _wait(1.0)
	var leak: = HazmatLeak.current
	if not _check(leak != null, "the leak's call is there"):
		await _done()
		return
	CallService.current.run_call("hazmat", leak.run)
	var waited: = 0.0
	while leak._leak.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(1.0)
	var before: Vector3 = leak._leak["decon"]
	_check(HazmatLeak._world_ground(before) != null, "the decon point stands on the world's ground")

	var ambulances: = AmbulanceService.current
	var stand: = ambulances.arrive_at(before, 6.0, Vector3.FORWARD)
	print("hazmat decon: point %s, ambulance asked to %s" % [str(before), str(stand)])
	waited = 0.0
	while not ambulances.arrived() and waited < 60.0:
		await _wait(0.5)
		waited += 0.5
	await _wait(1.0)

	var parked: Vector3 = leak._leak["decon"]
	_check( not ambulances.covers(parked, HazmatLeak.DECON_REACH), "the ambulance parked clear of the tent")
	player.teleport(parked + Vector3(0, 0.3, 7.0))
	_view(parked + Vector3(9.0, 7.0, 12.0), parked + Vector3(0, 1.5, 0), 60.0)
	await _wait(0.5)
	await _snap("parked")

	var car: Node3D = ambulances._scene.get("car") if not ambulances._scene.is_empty() else null
	if _check(car != null and is_instance_valid(car), "the ambulance is there to park"):
		car.global_position = Vector3(before.x, car.global_position.y, before.z)
	await _wait(3.0)
	var after: Vector3 = leak._leak["decon"]
	var clear: = HazmatLeak.decon_clear(after) and not ambulances.covers(after, HazmatLeak.DECON_REACH)
	print("hazmat decon: ambulance arrived %s; point now %s (moved %.1f), clear %s" % [str(ambulances.arrived()), str(after), after.distance_to(before), str(clear)])
	_check(clear, "the decon point is clear of the ambulance")
	_check(HazmatLeak._world_ground(after) != null, "and on the world's ground")
	var decon: Node3D = leak._visual.get("decon")
	_check(decon != null and decon.global_position.distance_to(after) < 0.1, "the tray stands at the point")
	var prompt: Prompt = leak._prompts.get("decon")
	_check(prompt != null and (prompt.get_parent() as Node3D).global_position.distance_to(after + Vector3(0, 1.5, 0)) < 0.1, "the prompt is at the point")

	player.teleport(after + Vector3(0, 0.3, 0))
	await _wait(0.5)
	var front: Vector3 = (decon as Node3D).global_basis.z * -1.0
	_view(after + front * 15.0 + front.cross(Vector3.UP) * 6.0 + Vector3(0, 6, 0), after + Vector3(0, 2.8, 0), 55.0)
	await _wait(0.3)
	await _snap("decon")
	_done()





func _scenario_paylate() -> void :
	await _wait(1.0)
	var calls: = CallService.current
	var paid: Array = []
	player.paid.connect( func(amount: int) -> void : paid.append(amount))
	player.set_attr("Cash", 200)
	player.set_attr("Pending", 0)

	var away: = _ground(Game.station.door_position + Vector3(260, 0, 0))
	player.teleport(away + Vector3(0, 0.3, 0))
	calls.hold = false
	calls.scripted = [["tree", func() -> Variant:
		player.add_cash(80, "flameOut")
		player.add_cash(40, "bonus")
		await _wait(0.6)
		return true
	]]
	calls.wait_left = 0.3
	var waited: = 0.0
	while not calls.running and waited < 6.0:
		await _wait(0.1)
		waited += 0.1
	_check(calls.running, "a scripted call runs")
	await _wait(0.3)
	print("paylate: on the call: cash %d, pending %d" % [int(player.get_attr("Cash", 0)), int(player.get_attr("Pending", 0))])
	_check(int(player.get_attr("Cash", 0)) == 200 and int(player.get_attr("Pending", 0)) >= 120, "earned on the call, the pay waits as pending (times the level's share)")

	player.set_attr("Cash", 123136)
	player.set_attr("Pending", 12720)
	await _wait(0.2)
	await _snap("pending")
	player.set_attr("Cash", 200)
	player.set_attr("Pending", 120)
	waited = 0.0
	while calls.running and waited < 6.0:
		await _wait(0.1)
		waited += 0.1
	await _wait(0.5)
	print("paylate: the call over: settling %s, wait_left %.1f, cash %d, pending %d, duty says %s" % [calls.settling, calls.wait_left, int(player.get_attr("Cash", 0)), int(player.get_attr("Pending", 0)), Duty.current.state if Duty.current else {}])
	_check(calls.settling and calls.wait_left <= 0.0, "the clock to the next call does not run while nobody is back")
	_check(int(player.get_attr("Pending", 0)) == 120 and paid.is_empty(), "and the pay still waits")

	var pumper: = Vehicle.named("Fire Truck")
	var bay: Transform3D = pumper.spec["spawn"]
	_park(pumper, _ground(Game.station.door_position + Vector3(0, 0, 40)), bay.basis.get_euler().y)
	player.teleport(_ground(Game.station.door_position + Vector3(6, 0, 6)) + Vector3(0, 0.3, 0))
	await _wait(1.5)
	print("paylate: back, a truck out: settling %s, wait_left %.1f, cash %d, pending %d, paid %s, trucks out %d" % [calls.settling, calls.wait_left, int(player.get_attr("Cash", 0)), int(player.get_attr("Pending", 0)), paid, CallService.trucks_out()])
	_check(int(player.get_attr("Cash", 0)) == 320 and int(player.get_attr("Pending", 0)) == 0 and paid == [120], "at the station the pay lands on the account")
	_check(calls.settling and calls.wait_left <= 0.0, "but the clock waits while a truck is out of its bay")

	pumper.global_transform = bay
	pumper.linear_velocity = Vector3.ZERO
	pumper.reset_physics_interpolation()
	await _wait(1.5)
	print("paylate: all parked: settling %s, wait_left %.1f, trucks out %d" % [calls.settling, calls.wait_left, CallService.trucks_out()])
	_check( not calls.settling and calls.wait_left >= float(Shift.gap()[0]) - 2.0, "every truck in its bay: the clock to the next call runs, at least %d s" % int(Shift.gap()[0]))

	calls.report(player)
	await _wait(0.2)
	var gap: Array = Config.Duty.ReportGap
	print("paylate: reported: wait_left %.1f (ReportGap %s)" % [calls.wait_left, gap])
	_check(calls.wait_left <= float(gap[1]) + 0.5, "reporting available (U) brings the next call within ReportGap")
	_check(Controls.key_name("report_available") != "" and Controls.bindings.has("report_available"), "the report key is in the keys' list (rebindable)")
	calls.hold = true
	await _done()
