class_name HudRewards
extends Control







const WIDTH: = 300.0
const LINE: = 34.0
const INSET: = 284.0
const REASONS: = {"flameOut": "hud.rewards.flameOut", "bonus": "hud.rewards.bonus"}

var _lines: Array = []
var _watched: Player
var _total_row: Control
var _total_words: Label
var _total_sum: Label
var _total: = 0
var _call: = ""
var _total_until: = 0.0


func _ready() -> void :

	anchor_left = 1.0
	anchor_right = 1.0
	anchor_top = 0.62
	anchor_bottom = 0.62
	offset_left = - WIDTH - INSET
	offset_right = - INSET
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_total_row = Control.new()
	_total_row.size = Vector2(WIDTH, 26)
	_total_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_total_row.visible = false
	add_child(_total_row)
	_total_sum = Ui.display("", 22, Ui.AMBER)
	_total_words = Ui.caps("", int(Config.Hud.CapsFloor))
	for label: Label in [_total_sum, _total_words]:
		label.add_theme_constant_override("outline_size", 5)
		label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
		_total_row.add_child(label)
	_total_words.add_theme_color_override("font_color", Ui.TEXT)


func _on_rewarded(amount: int, why: String) -> void :
	if amount > 0:
		push(amount, Text.m(REASONS[why]) if REASONS.has(why) else "", why)



func push(amount: int, what: Variant = "", why: = "") -> void :
	var now: = Game.now()
	_count_toward_call(amount)
	var merge: = float(Config.Hud.RewardMerge)
	var line: Dictionary = {}
	for index in range(_lines.size() - 1, -1, -1):
		var candidate: Dictionary = _lines[index]
		if not candidate["going"] and candidate["why"] == why and Text.say(candidate["message"], "sl") == Text.say(what, "sl") and now - float(candidate["last"]) <= merge:
			line = candidate
			break
	if line.is_empty():
		line = _new_line(what, why)
	line["sum"] = int(line["sum"]) + amount
	line["count"] = int(line["count"]) + 1
	line["last"] = now
	line["leaves"] = now + float(Config.Hud.RewardTime)
	(line["amount"] as Label).text = Ui.money(int(line["sum"]), true)

	var row: Control = line["row"]
	row.pivot_offset = Vector2(WIDTH, LINE / 2)
	row.scale = Vector2(1.12, 1.12)
	create_tween().tween_property(row, "scale", Vector2.ONE, 0.15)

	if not (why == "flameOut" and Game.incident.has("flames")):
		var step: = mini(int(line["count"]) - 1, int(Config.Hud.CoinComboMost))
		Sounds.ui("ui_coin", 1.0 + float(Config.Hud.CoinComboPitch) * step)

	var staying: Array = _lines.filter( func(entry: Dictionary) -> bool: return not entry["going"])
	while staying.size() > int(Config.Hud.RewardRows):
		_go(staying.pop_front())


func _new_line(what: Variant, why: String) -> Dictionary:
	var row: = Control.new()
	row.size = Vector2(WIDTH, LINE)
	row.position = Vector2(0, - LINE + 14)
	row.modulate.a = 0.0
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(row)
	var sum: = Ui.display("", 26, Ui.YELLOW)
	var words: = Ui.label("", int(Config.Hud.TextFloor))
	for label: Label in [sum, words]:
		label.add_theme_constant_override("outline_size", 5)
		label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
		row.add_child(label)
	var line: = {"row": row, "amount": sum, "what": words, "why": why, "sum": 0, "count": 0, "message": what, "last": 0.0, "leaves": 0.0, "going": false}
	_lines.append(line)
	create_tween().tween_property(row, "modulate:a", 1.0, 0.15)
	return line


func _go(line: Dictionary) -> void :
	if line["going"]:
		return
	line["going"] = true
	_lines.erase(line)
	var row: Control = line["row"]
	var fade: = create_tween()
	fade.tween_property(row, "modulate:a", 0.0, 0.3)

	fade.parallel().tween_property(row, "position:x", row.position.x + 40, 0.3)
	fade.tween_callback(row.queue_free)



func _count_toward_call(amount: int) -> void :
	if Game.incident.is_empty():
		if Game.now() > _total_until:
			return
	else:
		_follow_call()
	_total += amount


func _follow_call() -> void :
	var name_now: = Text.say(Game.incident.get("name", ""), "sl")
	if name_now != _call:
		_call = name_now
		_total = 0
	_total_until = Game.now() + float(Config.Hud.RewardTotalAfter)


func _process(_delta: float) -> void :
	var player: = Game.local_player
	if player != _watched and player != null:
		_watched = player
		player.rewarded.connect(_on_rewarded)
	var now: = Game.now()
	if not Game.incident.is_empty():
		_follow_call()
	for line: Dictionary in _lines.duplicate():
		if now > float(line["leaves"]):
			_go(line)

	var y: = - LINE
	for index in range(_lines.size() - 1, -1, -1):
		var line: Dictionary = _lines[index]
		var row: Control = line["row"]
		row.position.y = lerpf(row.position.y, y, 0.3)
		y -= LINE + 2
		var words: Label = line["what"]
		var sum: Label = line["amount"]
		var said: = Text.say(line["message"])
		if int(line["count"]) > 1:
			said = (said + "  " if not said.is_empty() else "") + Text.say(Text.f("hud.rewards.times", [int(line["count"])]))
		words.text = said
		var words_size: = words.get_minimum_size()
		var sum_size: = sum.get_minimum_size()
		words.position = Vector2(WIDTH - words_size.x, LINE - words_size.y - 5)
		sum.position = Vector2(WIDTH - words_size.x - (12 if words_size.x > 0 else 0) - sum_size.x, (LINE - sum_size.y) / 2)

	var lines_sum: = 0
	for line: Dictionary in _lines:
		lines_sum += int(line["sum"])
	_total_row.visible = now < _total_until and _total > 0 and (_total > lines_sum or _lines.size() > 1)
	if _total_row.visible:
		_total_words.text = Text.say(Text.m("hud.rewards.callTotal"))
		_total_sum.text = Ui.money(_total)
		var words_size: = _total_words.get_minimum_size()
		var sum_size: = _total_sum.get_minimum_size()
		_total_words.position = Vector2(WIDTH - words_size.x, 26 - words_size.y - 3)
		_total_sum.position = Vector2(WIDTH - words_size.x - 10 - sum_size.x, (26 - sum_size.y) / 2)
		_total_row.position.y = lerpf(_total_row.position.y, y + LINE - 26.0, 0.3)
