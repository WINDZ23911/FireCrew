extends RefCounted



const SHARE: = 0.07
const PLUMAGE: = [Color8(30, 32, 40), Color8(44, 40, 38), Color8(58, 60, 66)]


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("WireBirds")
	var rng: = kit.rng("wire birds")
	var birds: = 0
	var wires: = store.rows_named("PowerWire")
	for index in wires.size():

		if index % 4 == 0 or index % 4 == 3 or rng.randf() >= SHARE:
			continue
		var row: int = wires[index]
		var frame: = store.transform(row)
		var length: = store.size(row).x
		var along: = frame.basis.x.normalized()
		var count: = rng.randi_range(2, 6)
		var start: = rng.randf_range( - length / 2.0 + 1.0, 0.0)
		var flock: Color = PLUMAGE[rng.randi_range(0, PLUMAGE.size() - 1)]
		for bird in count:
			var at: = frame.origin + along * (start + bird * rng.randf_range(0.9, 1.8))
			if (at - frame.origin).length() > length / 2.0 - 0.3:
				break

			var across: = Vector3( - along.z, 0, along.x).normalized() * (1.0 if rng.randf() < 0.5 else -1.0)
			_bird(kit, folder, at + Vector3(0, 0.08, 0), across, flock.lerp(Color8(80, 76, 72), rng.randf_range(0.0, 0.3)))
			birds += 1
	return "%d birds on the wires" % birds


static func _bird(kit: PolishKit, folder: int, perch: Vector3, ahead: Vector3, plumage: Color) -> void :
	var place: = PolishKit.facing(Vector3.ZERO, ahead)
	place.origin = perch
	kit.ball(folder, place * Vector3(0, 0.3, 0.05), Vector3(0.36, 0.42, 0.62), plumage, "Fabric", "WireBird")
	kit.ball(folder, place * Vector3(0, 0.56, -0.2), Vector3(0.26, 0.26, 0.26), plumage, "Fabric", "WireBirdHead")
	kit.box(folder, place * Transform3D(Basis(Vector3.RIGHT, 0.5), Vector3(0, 0.2, 0.45)), Vector3(0.2, 0.05, 0.5), plumage.darkened(0.2), "Fabric", "WireBirdTail")
