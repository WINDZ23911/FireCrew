class_name Traffic
extends Node3D














signal vehicle_added(car: Car)
signal vehicle_removed(car: Car)

const ROAD: = 0.2
const CLEARANCE: = 0.6
const AHEAD: = 4
const OFF_MAP: = 40.0
const ENTRY_ROOM: = 45.0
const ENTRY_WEIGHTS: Array[float] = [0.5, 2.0, 3.0, 4.0]
const ENGINE_HALF: = 5.0
const STUCK_TIME: = 90.0
const STUCK_CLEAR: = 150.0
const BODY_WAIT: = 15.0
const NET_HZ: = 10.0
const SWING: = 1.8
const WAVE_NEAR: = 14.0
const KINDS: Array[String] = ["car", "bus", "plow"]
const PLOW_SIZE: = Vector3(8.6, 9.0, 30.0)

static var current: Traffic


class Car:
	extends RefCounted
	var id: = 0
	var body: AnimatableBody3D
	var bus: = false
	var size: = Vector3.ONE
	var half: = 7.5
	var half_width: = 3.2
	var route: Array[int] = []
	var stops: Dictionary = {}
	var index: = 0
	var s: = 0.0
	var v: = 0.0
	var still: = 0.0
	var side: = 0.0
	var calm_at: = 0.0
	var holds: Dictionary = {}
	var ahead: Dictionary = {}
	var going: = -1
	var halted_at: = -1
	var alarmed: = false
	var behind: = false
	var deaf: = false
	var deaf_for: = 0.0
	var inside: = false
	var x: = 0.0
	var z: = 0.0
	var dx: = 0.0
	var dz: = -1.0
	var waiting_for: = ""

	var place: = Transform3D.IDENTITY
	var kind: = "car"
	var color: = 1
	var shape: = 1
	var braking: = false
	var standing: = false

	var told_at: = Vector3.ZERO
	var told_time: = 0.0

	var swing: = 1.0
	var swing_from: = Transform3D.IDENTITY


var graph: NavGraph
var segments: Array
var crossings: Array
var junctions: Array
var vehicles: Array[Car] = []
var holders: Dictionary = {}
var bus_stop: Dictionary = {}

var _rng: = RandomNumberGenerator.new()
var _main_island: = -1
var _next_id: = 0
var _next_car: = 0.0
var _next_bus: = 0.0
var _next_plow: = 0.0
var _closure: Dictionary = {}
var _closed: Dictionary = {}
var _barriers: Dictionary = {}
var _cordon_seen: = -1
var _speeds: Array[float] = []
var _running: = false
var _mirroring: = false
var _told: Dictionary = {}
var _mirrored: Dictionary = {}

var _allowed: = 0.0
var _why: = ""
var _comfort: = 1.0


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _between(span: Vector2) -> float:
	return _rng.randf_range(span.x, span.y)


func _segment_of(vehicle: Car) -> Dictionary:
	return segments[vehicle.route[vehicle.index]]






func _point_on_route(vehicle: Car, offset: float) -> Vector2:
	var route: = vehicle.route
	var index: = vehicle.index
	var at: = vehicle.s + offset
	var segment: Dictionary = segments[route[index]]
	while at > segment["length"] and index < route.size() - 1:
		at -= segment["length"]
		index += 1
		segment = segments[route[index]]
	while at < 0.0 and index > 0:
		index -= 1
		segment = segments[route[index]]
		at += segment["length"]
	var found: = NavGraph.sample(segment, at)

	var over: = 0.0
	if at > segment["length"]:
		over = at - segment["length"]
	elif at < 0.0:
		over = at
	return Vector2(found.x + found.z * over, found.y + found.w * over)




func _place(vehicle: Car) -> void :
	var axle: = vehicle.half * 0.6
	var front: = _point_on_route(vehicle, axle)
	var rear: = _point_on_route(vehicle, - axle)
	var d: = front - rear
	var length: = d.length()
	if length > 0.0001:
		vehicle.dx = d.x / length
		vehicle.dz = d.y / length

	vehicle.x = (front.x + rear.x) / 2.0 - vehicle.dz * vehicle.side
	vehicle.z = (front.y + rear.y) / 2.0 + vehicle.dx * vehicle.side
	var middle: = Vector3(vehicle.x, ROAD + CLEARANCE + vehicle.size.y / 2.0, vehicle.z)
	vehicle.place = Rbx.look_at(middle, middle + Vector3(vehicle.dx, 0, vehicle.dz))
	if vehicle.swing < 1.0:
		vehicle.place = _swung(vehicle)
	if vehicle.body and vehicle.body.is_inside_tree():
		vehicle.body.global_transform = vehicle.place



func _distance_to(vehicle: Car, other: Car) -> float:
	var other_id: = other.route[other.index]
	var distance: = - vehicle.s
	for i in range(vehicle.index, mini(vehicle.index + AHEAD, vehicle.route.size() - 1) + 1):
		var id: = vehicle.route[i]
		if id == other_id:
			var gap: = distance + other.s
			return gap if gap > 0.0 else -1.0
		distance += segments[id]["length"]
	return -1.0





func _in_closure(x: float, z: float, margin: = 0.0) -> bool:
	if _closure.is_empty():
		return false
	var reach: float = _closure["radius"] + margin
	return (x - _closure["x"]) ** 2 + (z - _closure["z"]) ** 2 < reach * reach





func _reroute(vehicle: Car, avoid: Variant = null) -> bool:
	var closed: Dictionary = avoid if avoid is Dictionary else _closed
	var route: = vehicle.route
	if avoid != null and closed.has(route[vehicle.index]):
		return false
	var blocked: = false
	for i in range(vehicle.index + 1, route.size()):
		blocked = blocked or closed.has(route[i])
	if not blocked:
		return true
	var here: = route[vehicle.index]
	var way: = graph.drive_route(here, route[route.size() - 1], closed)
	if way.is_empty():
		for id in graph.exits:
			if not closed.has(id) and segments[id]["island"] == _main_island:
				way = graph.drive_route(here, id, closed)
				if not way.is_empty():
					break
	if way.is_empty():


		_give_back(vehicle, segments[here])
		return false


	var has_previous: = vehicle.index > 0
	if has_previous:
		way.push_front(route[vehicle.index - 1])
	vehicle.route = way
	vehicle.index = 1 if has_previous else 0
	vehicle.stops = {}
	if graph.bus.get("id", -1) == vehicle.id:
		graph.bus = {}
	_give_back(vehicle, segments[here])
	return true



func _give_back(vehicle: Car, segment: Dictionary) -> void :
	vehicle.going = -1
	vehicle.ahead = {}
	for node: int in vehicle.holds.keys():
		var inside: bool = (segment["kind"] == "turn" and segment["node"] == node)\
		or (segment["kind"] == "lane" and segment["from"] == node and vehicle.s <= vehicle.half + 1.0)
		if not inside:
			vehicle.holds.erase(node)
			if holders.get(node) == vehicle:
				holders.erase(node)








func wave_off(origin: Vector3, look: Vector3, reach: float) -> int:
	if _mirroring or graph == null:
		return 0
	var here: = Vector2(origin.x, origin.z)
	var avoid: = _closed.duplicate()
	for segment: Dictionary in segments:
		var points: PackedVector2Array = segment["points"]
		for index in range(maxi(points.size() - 1, 1)):
			var b: Vector2 = points[mini(index + 1, points.size() - 1)]
			if Geometry2D.get_closest_point_to_segment(here, points[index], b).distance_squared_to(here) < WAVE_NEAR * WAVE_NEAR:
				avoid[segment["id"]] = true
				break
	var flat: = Vector2(look.x, look.z).normalized()
	var went: = 0
	for vehicle in vehicles:
		var offset: = Vector2(vehicle.x, vehicle.z) - here
		var distance: = offset.length()
		if distance > reach or (distance > 6.0 and offset.normalized().dot(flat) < -0.2):
			continue
		if offset.dot(Vector2(vehicle.dx, vehicle.dz)) > 0.0 and distance > vehicle.half + 4.0:
			continue
		vehicle.deaf = false
		if _reroute(vehicle, avoid) or _turn_round(vehicle, avoid):
			went += 1
	return went




func _turn_round(vehicle: Car, avoid: Dictionary) -> bool:
	var segment: = _segment_of(vehicle)
	if segment["kind"] != "lane" or vehicle.swing < 1.0:
		return false
	var twin: Dictionary = {}
	for other: Dictionary in segments:
		if other["kind"] == "lane" and other["road"] == segment["road"] and other["from"] == segment["to"] and other["to"] == segment["from"]:
			twin = other
			break
	if twin.is_empty():
		return false
	var open: = avoid.duplicate()
	open.erase(twin["id"])
	var route: = vehicle.route
	var way: = graph.drive_route(twin["id"], route[route.size() - 1], open)
	if way.is_empty():
		for id in graph.exits:
			if not open.has(id) and segments[id]["island"] == _main_island:
				way = graph.drive_route(twin["id"], id, open)
				if not way.is_empty():
					break
	if way.is_empty():
		return false

	var turned: = clampf(float(twin["length"]) - vehicle.s, vehicle.half, maxf(float(twin["length"]) - 1.0, vehicle.half))
	for other in vehicles:
		if other != vehicle and other.route[other.index] == twin["id"]\
		and absf(other.s - turned) < other.half + vehicle.half + float(Config.Life.CarGap):
			return false
	vehicle.going = -1
	vehicle.ahead = {}
	for node: int in vehicle.holds.keys():
		vehicle.holds.erase(node)
		if holders.get(node) == vehicle:
			holders.erase(node)
	if graph.bus.get("id", -1) == vehicle.id:
		graph.bus = {}
	vehicle.swing_from = vehicle.place
	vehicle.swing = 0.0
	vehicle.route = way
	vehicle.index = 0
	vehicle.s = turned
	vehicle.v = 0.0
	vehicle.side = 0.0
	vehicle.stops = {}
	vehicle.halted_at = -1
	vehicle.still = 0.0
	_place(vehicle)
	return true




func _swung(vehicle: Car) -> Transform3D:
	var k: = smoothstep(0.0, 1.0, vehicle.swing)
	var from: = vehicle.swing_from
	var to: = vehicle.place
	var from_ahead: = - from.basis.z
	var to_ahead: = - to.basis.z
	var from_yaw: = atan2( - from_ahead.x, - from_ahead.z)
	var turn: = wrapf(atan2( - to_ahead.x, - to_ahead.z) - from_yaw, - PI, PI)
	if absf(turn) > 2.6:
		turn = absf(turn)
	var at: = from.origin.lerp(to.origin, k) + Vector3(from_ahead.x, 0, from_ahead.z).normalized() * sin(k * PI) * 4.0
	return Transform3D(Basis(Vector3.UP, from_yaw + turn * k), at)



static func _crosses_tape(tape: Dictionary, a: Vector2, b: Vector2) -> bool:
	var p: = Vector2(tape["ax"], tape["az"])
	var q: = Vector2(tape["bx"], tape["bz"])
	var side_a: = (q - p).cross(a - p)
	var side_b: = (q - p).cross(b - p)
	var side_c: = (b - a).cross(p - a)
	var side_d: = (b - a).cross(q - a)
	return side_a * side_b <= 0.0 and side_c * side_d <= 0.0 and (side_a != 0.0 or side_b != 0.0)



func _read_closure() -> void :
	var cordon: = graph.cordon
	var version: int = cordon.get("version", -1)
	if graph.closure == _closure and version == _cordon_seen:
		return
	_closure = graph.closure.duplicate()
	_cordon_seen = version
	_closed = {}
	_barriers = {}

	var cones: Array = cordon.get("cones", [])
	var tapes: Array = cordon.get("tapes", [])
	var blocked: = not cones.is_empty() or not tapes.is_empty()
	var room: float = Config.Life.ConeBlocks ** 2
	for segment: Dictionary in segments:
		var id: int = segment["id"]
		var length: float = segment["length"]


		if not _closure.is_empty() and not _closure.get("open", false):
			var steps: = maxi(1, ceili(length / 8.0))
			for i in steps + 1:
				var at: = length * i / steps
				var found: = NavGraph.sample(segment, at)
				if _in_closure(found.x, found.y):
					_closed[id] = at
					break
		if blocked:

			var steps: = maxi(1, ceili(length / 4.0))
			var first: = NavGraph.sample(segment, 0.0)
			var before: = Vector2(first.x, first.y)
			var list: Array[float] = []
			for i in range(1, steps + 1):
				var at: = length * i / steps
				var found: = NavGraph.sample(segment, at)
				var here: = Vector2(found.x, found.y)
				var hit: = false
				for cone: Dictionary in cones:
					hit = hit or (cone["x"] - here.x) ** 2 + (cone["z"] - here.y) ** 2 < room
				for tape: Dictionary in tapes:
					hit = hit or _crosses_tape(tape, before, here)
				if hit and not ( not list.is_empty() and at - list[list.size() - 1] < 8.0):
					list.append(at)
				before = here
			if not list.is_empty():
				_barriers[id] = list
				_closed[id] = minf(_closed.get(id, INF), list[0])
	for vehicle in vehicles:
		_reroute(vehicle)





func _walked(id: int) -> bool:
	return id >= 0 and crossings[id]["walkers"] > 0


func _hold(vehicle: Car, node: int) -> void :
	holders[node] = vehicle
	vehicle.holds[node] = true



func _may_enter(vehicle: Car, lane: Dictionary, turn: Dictionary, front: float, comfort: float) -> bool:
	var node: int = turn["node"]
	var junction: Dictionary = junctions[node]
	if vehicle.alarmed:



		if not vehicle.behind:
			return false
		var green: bool = junction["control"] == "signals" and lane["phase"] != 0 and TrafficLights.phase(lane["phase"]) == "green"
		if not green and float(lane["pull_over"]) >= float(Config.Traffic.PullOverRoom):
			return false
	if not _closure.is_empty() and not vehicle.inside:

		if _closed.has(turn["id"]) or (_closed.has(turn["to_lane"]) and _closed[turn["to_lane"]] < vehicle.half * 2.0 + 6.0):
			return false

	if _barriers.has(turn["id"]) or (_barriers.has(turn["to_lane"]) and _barriers[turn["to_lane"]][0] < vehicle.half * 2.0 + 6.0):
		return false

	if junction["control"] == "signals" and lane["phase"] != 0:
		var light: = TrafficLights.phase(lane["phase"])

		if light == "red" or (light == "amber" and front > vehicle.v * vehicle.v / (2.0 * comfort)):
			return false

	var lesser: bool = lane["rank"] < junction["rank"]
	if lesser and junction["control"] == "stop" and vehicle.halted_at != lane["id"]:
		return false

	var out: Dictionary = segments[turn["to_lane"]]
	if _walked(lane["end_crossing"]) or _walked(out["start_crossing"]):
		return false

	for crossing: Dictionary in out["crossings"]:
		if crossing["at"] < vehicle.half * 2.0 + 8.0 and _walked(crossing["id"]):
			return false

	var gap: float = Config.Life.CarGap
	for other in vehicles:
		if other != vehicle:
			var other_segment: = _segment_of(other)

			if other_segment["id"] == out["id"] and other.v < 2.0 and other.s < other.half + vehicle.half * 2.0 + gap:
				return false

			if lesser and other_segment["kind"] == "lane" and other_segment["to"] == node and other_segment["rank"] > lane["rank"]:
				if other.v > 1.0 and other_segment["length"] - other.s < other.v * 3.0 + 15.0:
					return false
	return true




func _claim(vehicle: Car, id: int, front: float) -> void :
	if id >= 0 and front > - (vehicle.half * 2.0 + 6.0) and (front < 0.0 or (vehicle.v > 1.5 and front < vehicle.v * 2.5 + 6.0)):
		crossings[id]["cars"] += 1


func _claim_crossings(vehicle: Car) -> void :
	var segment: = _segment_of(vehicle)
	var remaining: float = segment["length"] - vehicle.s
	if segment["kind"] == "lane":
		for crossing: Dictionary in segment["crossings"]:
			_claim(vehicle, crossing["id"], crossing["at"] - vehicle.s - vehicle.half)
		_claim(vehicle, segment["start_crossing"], - vehicle.s - vehicle.half)
		_claim(vehicle, segment["end_crossing"], remaining - vehicle.half)
		if vehicle.index + 1 < vehicle.route.size():
			var next_segment: Dictionary = segments[vehicle.route[vehicle.index + 1]]
			var out: Dictionary = segments[next_segment["to_lane"]]
			var beyond: float = remaining + next_segment["length"] - vehicle.half
			_claim(vehicle, out["start_crossing"], beyond)
			for crossing: Dictionary in out["crossings"]:
				_claim(vehicle, crossing["id"], beyond + crossing["at"])
	else:
		var out: Dictionary = segments[segment["to_lane"]]
		_claim(vehicle, segments[segment["from_lane"]]["end_crossing"], - vehicle.s - vehicle.half)
		_claim(vehicle, out["start_crossing"], remaining - vehicle.half)
		for crossing: Dictionary in out["crossings"]:
			_claim(vehicle, crossing["id"], remaining - vehicle.half + crossing["at"])





func _remove(vehicle: Car) -> void :
	for node: int in holders.keys():
		if holders[node] == vehicle:
			holders.erase(node)
	vehicles.erase(vehicle)
	if vehicle.body:
		vehicle.body.queue_free()
		vehicle.body = null
	if graph.bus.get("id", -1) == vehicle.id:
		graph.bus = {}
	if vehicle.kind == "car":
		_next_car = maxf(_next_car, Game.now() + _between(Config.Life.CarEvery))
	vehicle_removed.emit(vehicle)


func _nearest_vehicle(x: float, z: float) -> float:
	var best: = INF
	for other in vehicles:
		best = minf(best, (other.x - x) ** 2 + (other.z - z) ** 2)
	return sqrt(best)


func _entry_is_clear(lane: Dictionary) -> bool:
	for other in vehicles:
		if other.route[other.index] == lane["id"] and other.s < ENTRY_ROOM:
			return false
	return true




func _pick_way_through(least: int) -> Array:
	var total: = 0.0
	var entries: Array = []
	for id in graph.entries:
		var lane: Dictionary = segments[id]
		if lane["island"] == _main_island and lane["rank"] >= least:
			entries.append(lane)
			total += ENTRY_WEIGHTS[lane["rank"]]
	if entries.is_empty():
		return []
	var roll: = _rng.randf_range(0.0, total)
	var entry: Dictionary = {}
	for lane: Dictionary in entries:
		roll -= ENTRY_WEIGHTS[lane["rank"]]
		entry = lane
		if roll <= 0.0:
			break
	var exits: Array = []
	for id in graph.exits:
		var lane: Dictionary = segments[id]
		if lane["island"] == _main_island and lane["rank"] >= least and lane["to"] != entry["from"]:
			exits.append(lane)
	if exits.is_empty():
		return []
	return [entry, exits[_rng.randi() % exits.size()]]




func _route_via(from: int, via: int, to: int) -> Array:
	var first: = graph.drive_route(from, via, _closed)
	var second: = graph.drive_route(via, to, _closed)
	if first.is_empty() or second.is_empty():
		return []
	var at: = first.size() - 1
	for i in range(1, second.size()):
		first.append(second[i])
	return [first, at]




static func sized(shape: int, size: Vector3) -> Vector3:
	var drawn: = CarKit.pick(shape)
	return Vector3(size.x, size.y, CarKit.length_of(drawn)) if drawn != "" else size


func _create(kind: String, size: Vector3, route: Array[int], stops: Dictionary) -> Car:
	_next_id += 1
	var vehicle: = Car.new()
	vehicle.id = _next_id
	vehicle.kind = kind
	vehicle.bus = kind == "bus"
	vehicle.color = _rng.randi_range(1, int(Config.Life.CarColors))
	vehicle.shape = _rng.randi_range(1, 12)
	if kind == "car":
		size = sized(vehicle.shape, size)
	vehicle.size = size
	vehicle.half = size.z / 2.0
	vehicle.half_width = size.x / 2.0
	vehicle.route = route
	vehicle.stops = stops
	vehicle.deaf = _rng.randf() < float(Config.Traffic.DeafShare)
	return vehicle


func _launch(vehicle: Car) -> void :
	_place(vehicle)
	_put_on_road(vehicle)



func _put_on_road(vehicle: Car) -> void :
	var body: = AnimatableBody3D.new()
	body.name = "TownBus" if vehicle.bus else ("TownPlow" if vehicle.kind == "plow" else "TownCar")
	body.sync_to_physics = false
	body.collision_layer = World.LAYER_SOLID | World.LAYER_QUERY
	body.collision_mask = 0
	var collider: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = vehicle.size
	collider.shape = box
	body.add_child(collider)
	body.set_meta("town_vehicle", vehicle.id)
	vehicle.body = body
	body.transform = vehicle.place
	add_child(body)
	vehicles.append(vehicle)
	vehicle_added.emit(vehicle)




func _spawn_car(scattered: bool) -> bool:
	var settings: Dictionary = Config.Life
	var way: = _pick_way_through(0)
	if way.is_empty():
		return false
	var entry: Dictionary = way[0]
	var exit: Dictionary = way[1]
	if ( not scattered and not _entry_is_clear(entry)) or _closed.has(entry["id"]) or _closed.has(exit["id"]):
		return false

	var car_size: Vector3 = settings["CarSize"]
	var half: = car_size.z / 2.0
	var route: Array[int] = []
	var stops: = {}
	if _rng.randf() < settings["VisitShare"] and not graph.dead_ends.is_empty():
		var visit: Dictionary = segments[graph.dead_ends[_rng.randi() % graph.dead_ends.size()]]
		if visit["island"] == _main_island and not _closed.has(visit["id"]):
			var via: = _route_via(entry["id"], visit["id"], exit["id"])
			if not via.is_empty():
				route = via[0]
				stops[via[1]] = {"at": maxf(visit["length"] - half - 1.0, 0.0), "time": _between(settings["VisitTime"])}
	if route.is_empty():
		route = graph.drive_route(entry["id"], exit["id"], _closed)
	if route.is_empty():
		return false

	var vehicle: = _create("car", car_size, route, stops)
	if scattered:
		for attempt in 8:
			var index: = _rng.randi() % route.size()
			var segment: Dictionary = segments[route[index]]
			if segment["kind"] == "lane" and segment["length"] > car_size.z * 2.0:
				vehicle.index = index
				vehicle.s = segment["length"] * _rng.randf_range(0.2, 0.7)
				var at: = _point_on_route(vehicle, 0.0)
				if _nearest_vehicle(at.x, at.y) > 60.0 and not _near_body(at, 40.0):
					vehicle.v = _speeds[segment["rank"]] * 0.6
					_launch(vehicle)
					return true
		return false
	vehicle.s = - OFF_MAP
	vehicle.v = _speeds[entry["rank"]] * 0.7
	_launch(vehicle)
	return true



func _plows_wanted() -> int:
	if not Style.winter():
		return 0
	return int(Config.Drive.Winter.get("RoadSnow", {}).get("Plows", 0))


func _plow_speed() -> float:
	return float(Config.Drive.Winter.get("RoadSnow", {}).get("PlowSpeed", 0.65))




func _spawn_plow() -> bool:
	var way: = _pick_way_through(1)
	if way.is_empty():
		return false
	var entry: Dictionary = way[0]
	var exit: Dictionary = way[1]
	if not _entry_is_clear(entry) or _closed.has(entry["id"]) or _closed.has(exit["id"]):
		return false
	var streets: Array = segments.filter( func(segment: Dictionary) -> bool: return segment["kind"] == "lane" and segment["island"] == _main_island and segment["length"] > 40.0 and not _closed.has(segment["id"]))
	var route: Array[int] = []
	for attempt in 4:
		if streets.is_empty():
			break
		var via: = _route_via(entry["id"], streets[_rng.randi() % streets.size()]["id"], exit["id"])
		if not via.is_empty():
			route.assign(via[0])
			break
	if route.is_empty():
		route = graph.drive_route(entry["id"], exit["id"], _closed)
	if route.is_empty():
		return false
	var vehicle: = _create("plow", PLOW_SIZE, route, {})
	vehicle.color = 1
	vehicle.s = - OFF_MAP
	vehicle.v = _speeds[entry["rank"]] * _plow_speed() * 0.6
	_launch(vehicle)
	return true



func _spawn_bus() -> bool:
	var settings: Dictionary = Config.Life
	var way: = _pick_way_through(2)
	if way.is_empty() or bus_stop.is_empty():
		return false
	var entry: Dictionary = way[0]
	var exit: Dictionary = way[1]
	if not _entry_is_clear(entry) or _closed.has(entry["id"]) or _closed.has(exit["id"]) or _closed.has(bus_stop["lane"]):
		return false
	var via: = _route_via(entry["id"], bus_stop["lane"], exit["id"])
	if via.is_empty():
		return false
	var vehicle: = _create("bus", settings["BusSize"], via[0], {via[1]: {"at": bus_stop["at"], "time": settings["BusStopTime"]}})
	vehicle.s = - OFF_MAP
	vehicle.v = _speeds[entry["rank"]] * 0.5
	_launch(vehicle)
	return true






func _gather_bodies() -> Array[Vector3]:
	var bodies: Array[Vector3] = []
	for player in Game.players:
		if player.seat == null:
			var at: = player.global_position
			bodies.append(Vector3(at.x, at.z, 1.5))
	for engine in Vehicle.all:
		if not is_instance_valid(engine) or not engine.is_inside_tree():
			continue

		var pivot: = engine.global_transform
		var front: float = float(engine.data.get("front", -14.0)) + ENGINE_HALF
		var rear: float = float(engine.data.get("rear", 14.0)) - ENGINE_HALF
		var count: = maxi(2, ceili((rear - front) / ENGINE_HALF) + 1)
		for index in count:
			var point: = pivot * Vector3(0, 0, front + (rear - front) * index / (count - 1))
			bodies.append(Vector3(point.x, point.z, ENGINE_HALF))

	for body: Variant in graph.closure.get("bodies", []):
		bodies.append(body)
	return bodies



func _near_body(at: Vector2, room: float) -> bool:
	for body in _gather_bodies():
		if Vector2(body.x - at.x, body.y - at.y).length() < room + body.z:
			return true
	return false


func _player_near(vehicle: Car) -> bool:
	for player in Game.players:
		var at: = player.global_position
		if (at.x - vehicle.x) ** 2 + (at.z - vehicle.z) ** 2 < STUCK_CLEAR ** 2:
			return true
	return false


func _speed_on(part: Dictionary, pace: float) -> float:
	var settings: Dictionary = Config.Life
	if part["kind"] == "turn":
		return (_speeds[part["rank"]] * 0.8 if part["turn"] == "straight" else float(settings["TurnSpeed"])) * pace
	return _speeds[part["rank"]] * pace



func _within(gap: float, speed: float, reason: String) -> void :
	var limit: = sqrt(speed * speed + 2.0 * _comfort * maxf(gap, 0.0))
	if limit < _allowed:
		_allowed = limit
		_why = reason



func _drive(vehicle: Car, dt: float, now: float, bodies: Array[Vector3], sirens: Array) -> bool:
	var settings: Dictionary = Config.Life
	var braking_power: float = settings["CarBraking"]
	var car_gap: float = settings["CarGap"]
	var comfort: = braking_power * 2.0 / 3.0
	var route: = vehicle.route
	var segment: = _segment_of(vehicle)
	var has_next: = vehicle.index + 1 < route.size()
	var next_segment: Dictionary = segments[route[vehicle.index + 1]] if has_next else {}
	var remaining: float = segment["length"] - vehicle.s
	var pace: float = settings["BusSpeed"] if vehicle.bus else (_plow_speed() if vehicle.kind == "plow" else 1.0)

	_comfort = comfort
	_allowed = _speed_on(segment, pace)
	_why = ""
	if vehicle.swing < 1.0:
		vehicle.swing = minf(1.0, vehicle.swing + dt / SWING)
		_allowed = minf(_allowed, 3.0)

	if not sirens.is_empty() and not _hears(vehicle, sirens).is_empty():
		vehicle.calm_at = now + settings["SirenCalm"]
	vehicle.alarmed = now < vehicle.calm_at

	var yielding: bool = vehicle.alarmed and segment["kind"] == "lane" and (vehicle.s > vehicle.half or vehicle.s < 0.0)
	var kerb: float = segment["pull_over"] if yielding else 0.0



	var going_on: bool = yielding and vehicle.behind and kerb < float(Config.Traffic.PullOverRoom)



	vehicle.inside = _in_closure(vehicle.x, vehicle.z)
	if not _closure.is_empty():
		if _closed.has(segment["id"]) and not vehicle.inside and segment["kind"] == "lane":
			for ahead: float in [10.0, 20.0, 30.0, 40.0]:
				var found: = NavGraph.sample(segment, vehicle.s + ahead)
				if _in_closure(found.x, found.y):
					_within(ahead - vehicle.half - 3.0, 0.0, "closed")
					break
		if _in_closure(vehicle.x, vehicle.z, settings["Rubberneck"]):
			_allowed = minf(_allowed, _speed_on(segment, pace) * settings["RubberneckSpeed"])


	if _barriers.has(segment["id"]):
		for at: float in _barriers[segment["id"]]:
			var gap: = at - vehicle.s - vehicle.half
			if gap > -2.0:
				_within(gap - 3.0, 0.0, "cordon")
				break
	var reach: = remaining
	for i in range(vehicle.index + 1, mini(vehicle.index + 3, route.size())):
		var id: = route[i]
		if _barriers.has(id):
			_within(reach + _barriers[id][0] - vehicle.half - 3.0, 0.0, "cordon")
			break
		reach += segments[id]["length"]

	var standing: = false
	var stop: Dictionary = vehicle.stops.get(vehicle.index, {})
	var stopping: = not stop.is_empty()
	if stopping and not stop.get("done", false):
		var gap: float = stop["at"] - vehicle.s
		_within(gap, 0.0, "stop")
		if gap < 1.5 and vehicle.v < 0.5:
			standing = true
			if not stop.has("leave"):
				stop["leave"] = now + stop["time"]
			stop["done"] = now >= stop["leave"]

	if segment["kind"] == "lane":
		for crossing: Dictionary in segment["crossings"]:
			var front: float = crossing["at"] - vehicle.s - vehicle.half
			if front > -1.0 and _walked(crossing["id"]):
				_within(front - 6.0, 0.0, "walker")


		if _walked(segment["end_crossing"]):
			_within(remaining - vehicle.half - 0.5, 0.0, "walker")

		if has_next:
			_within(remaining, _speed_on(next_segment, pace), "turn")
			var node: int = next_segment["node"]
			if vehicle.going != node:
				var front: = remaining - vehicle.half - 0.5
				var junction: Dictionary = junctions[node]
				if junction["control"] == "stop" and segment["rank"] < junction["rank"] and vehicle.halted_at != segment["id"]:
					if front < 2.0 and vehicle.v < 0.3:
						vehicle.halted_at = segment["id"]
				if front < vehicle.v * 2.0 + 25.0:

					var chain: Array[int] = [node]
					for i in range(vehicle.index + 2, route.size() - 1, 2):
						var out: Dictionary = segments[route[i]]
						if out["length"] >= vehicle.half * 2.0 + car_gap + 2.0:
							break
						chain.append(out["to"])
					var free: = true
					for each in chain:
						free = free and ( not holders.has(each) or holders[each] == vehicle)

					var committed: = free and vehicle.v > 3.0 and front < vehicle.v * vehicle.v / (2.0 * braking_power)
					if committed or (free and _may_enter(vehicle, segment, next_segment, front, comfort)):


						if committed or front < vehicle.v * vehicle.v / (2.0 * comfort) + vehicle.v * 0.3 + 4.0:
							vehicle.going = node
							for each in chain:
								_hold(vehicle, each)
								vehicle.ahead[each] = true
					else:
						_within(front, 0.0, "junction")

	if segment["kind"] == "turn":

		var out: Dictionary = segments[segment["to_lane"]]
		if _walked(out["start_crossing"]):
			_within(remaining - vehicle.half - 2.0, 0.0, "walker")
		for crossing: Dictionary in out["crossings"]:
			var front: float = remaining + crossing["at"] - vehicle.half
			if front > -1.0 and _walked(crossing["id"]):
				_within(front - 6.0, 0.0, "walker")

	for other in vehicles:
		if other != vehicle:
			var distance: = _distance_to(vehicle, other)
			if distance >= 0.0:

				_within(distance - vehicle.half - other.half - car_gap, other.v * 0.7, "vehicle")

	for body in bodies:
		var rx: = body.x - vehicle.x
		var rz: = body.y - vehicle.z
		var forward: = rx * vehicle.dx + rz * vehicle.dz
		var aside: = absf(rx * vehicle.dz - rz * vehicle.dx)
		if forward > 0.0 and forward < vehicle.v * 2.0 + 30.0 and aside < vehicle.half_width + body.z + 0.5:
			var gap: = forward - vehicle.half - body.z
			_within(gap - car_gap, 0.0, "body")


			if gap < 1.0:
				vehicle.v = 0.0

	if yielding and not going_on:

		var eased: = maxf(vehicle.v - comfort * dt, float(settings["PullOverCreep"]) if vehicle.side < kerb - 0.2 else 0.0)
		if eased < _allowed:
			_allowed = eased
			_why = "siren"


	var drift: = maxf(minf(5.0, vehicle.v * 0.45), float(Config.Traffic.YieldDrift) if yielding else 0.0) * dt
	vehicle.side += clampf(kerb - vehicle.side, - drift, drift)

	var allowed: = _allowed
	vehicle.waiting_for = _why


	if _why == "body" and vehicle.kind != "bus" and vehicle.still > BODY_WAIT:
		var avoid: = _closed.duplicate()
		avoid[segment["id"]] = true
		if _turn_round(vehicle, avoid):
			return true
	vehicle.braking = allowed < vehicle.v - 0.5 or vehicle.v < 0.3
	if allowed < vehicle.v:
		vehicle.v = maxf(allowed, vehicle.v - braking_power * dt)
	else:
		vehicle.v = minf(allowed, vehicle.v + settings["CarAcceleration"] * dt)

	if vehicle.bus and stopping and not bus_stop.is_empty() and route[vehicle.index] == bus_stop["lane"]:
		if standing and graph.bus.is_empty():
			var out: = vehicle.half_width + 2.0
			graph.bus = {"id": vehicle.id, "x": vehicle.x - vehicle.dz * out, "z": vehicle.z + vehicle.dx * out}
		elif not standing and graph.bus.get("id", -1) == vehicle.id:
			graph.bus = {}

	vehicle.standing = standing or (yielding and not going_on)

	vehicle.s += vehicle.v * dt
	while vehicle.s >= segment["length"]:
		if not has_next:
			if vehicle.s >= segment["length"] + OFF_MAP:
				return false
			break
		vehicle.s -= segment["length"]
		vehicle.index += 1
		segment = next_segment
		has_next = vehicle.index + 1 < route.size()
		next_segment = segments[route[vehicle.index + 1]] if has_next else {}
		if segment["kind"] == "turn":
			if not holders.has(segment["node"]):
				_hold(vehicle, segment["node"])

			vehicle.going = -1
			vehicle.ahead.erase(segment["node"])

	for node: int in vehicle.holds.keys():
		var through: bool = vehicle.ahead.has(node)\
		or (segment["kind"] == "turn" and segment["node"] == node)\
		or (segment["kind"] == "lane" and segment["to"] == node and vehicle.going == node)\
		or (segment["kind"] == "lane" and segment["from"] == node and vehicle.s <= vehicle.half + 1.0)
		if not through:
			vehicle.holds.erase(node)
			if holders.get(node) == vehicle:
				holders.erase(node)
	_place(vehicle)


	vehicle.still = vehicle.still + dt if (vehicle.v < 0.2 and not standing and not yielding) else 0.0
	if vehicle.still > STUCK_TIME and not _player_near(vehicle):
		return false
	return true


func start(nav_graph: NavGraph) -> void :
	graph = nav_graph
	segments = graph.segments
	crossings = graph.crossings
	junctions = graph.junctions
	var settings: Dictionary = Config.Life
	_rng.randomize()
	var speeds: Dictionary = settings["CarSpeeds"]
	for rank in 4:

		_speeds.append(float(speeds.get(str(rank), speeds.get(rank, 20.0))))


	var sizes: = {}
	for segment: Dictionary in segments:
		if segment["kind"] == "lane":
			sizes[segment["island"]] = sizes.get(segment["island"], 0) + 1
	for island: int in sizes:
		if _main_island < 0 or sizes[island] > sizes[_main_island]:
			_main_island = island


	var middle: = Vector2.ZERO
	var shelters: = 0
	for spot: Dictionary in graph.places:
		if spot["kind"] == "bus_stop":
			middle += Vector2(spot["x"], spot["z"])
			shelters += 1
	if shelters > 0:
		middle /= shelters
		var found: = graph.nearest_lane(middle.x, middle.y, func(segment: Dictionary) -> bool: return segment["key"] == "station_loop")
		if found[0] >= 0:
			bus_stop = {"lane": found[0], "at": found[1]}

	for index in _wanted_cars():
		_spawn_car(true)
	_next_bus = Game.now() + 8.0
	_running = true
	_watch_calls()
	Net.share("life.cars", _net_cars, _net_apply_cars, 4.0)
	Net.share("life.cars.motion", _net_motion, _net_apply_motion, NET_HZ, true)






func _net_cars() -> Variant:
	var list: = PackedInt32Array()
	for vehicle in vehicles:
		list.append_array(PackedInt32Array([vehicle.id, KINDS.find(vehicle.kind), vehicle.color, vehicle.shape]))
	return list




func _net_motion() -> Variant:
	var list: = PackedFloat32Array()
	for vehicle in vehicles:
		list.append_array(PackedFloat32Array([
			vehicle.id, vehicle.x, vehicle.z, atan2( - vehicle.dx, - vehicle.dz), vehicle.v, 
			(1 if vehicle.braking else 0) + (2 if vehicle.standing else 0), 
		]))
	return list


func _net_apply_cars(list: Variant) -> void :
	if not Net.is_client() or not list is PackedInt32Array:
		return
	_set_mirroring(true)
	_told = {}
	for i in range(0, list.size() - 3, 4):
		_told[list[i]] = [KINDS[clampi(list[i + 1], 0, KINDS.size() - 1)], list[i + 2], list[i + 3]]
	for id: int in _mirrored.keys():
		if not _told.has(id):
			_remove(_mirrored[id])
			_mirrored.erase(id)



func _net_apply_motion(list: Variant) -> void :
	if not Net.is_client() or not list is PackedFloat32Array:
		return
	_set_mirroring(true)
	var now: = Game.now()
	for i in range(0, list.size() - 5, 6):
		var id: = int(list[i])
		if not _told.has(id):
			continue
		var vehicle: Car = _mirrored.get(id)
		var fresh: = vehicle == null
		if fresh:
			var looks: Array = _told[id]
			vehicle = Car.new()
			vehicle.id = id
			vehicle.kind = looks[0]
			vehicle.bus = vehicle.kind == "bus"
			vehicle.color = looks[1]
			vehicle.shape = looks[2]
			vehicle.size = Config.Life.BusSize if vehicle.bus else (PLOW_SIZE if vehicle.kind == "plow" else sized(vehicle.shape, Config.Life.CarSize))
			vehicle.half = vehicle.size.z / 2.0
			vehicle.half_width = vehicle.size.x / 2.0
		vehicle.told_at = Vector3(list[i + 1], ROAD + CLEARANCE + vehicle.size.y / 2.0, list[i + 2])
		vehicle.dx = - sin(list[i + 3])
		vehicle.dz = - cos(list[i + 3])
		vehicle.v = list[i + 4]
		vehicle.told_time = now
		var lamps: = int(list[i + 5])
		vehicle.braking = lamps & 1 != 0
		vehicle.standing = lamps & 2 != 0
		if fresh:
			_follow(vehicle, now)
			_mirrored[id] = vehicle
			_put_on_road(vehicle)




func _follow(vehicle: Car, now: float) -> void :
	var on: = vehicle.v * clampf(now - vehicle.told_time, 0.0, 0.3)
	var middle: = vehicle.told_at + Vector3(vehicle.dx, 0, vehicle.dz) * on
	vehicle.x = middle.x
	vehicle.z = middle.z
	vehicle.place = Rbx.look_at(middle, middle + Vector3(vehicle.dx, 0, vehicle.dz))
	if vehicle.body and vehicle.body.is_inside_tree():
		vehicle.body.global_transform = vehicle.place




func _set_mirroring(on: bool) -> void :
	if on == _mirroring:
		return
	for vehicle: Car in vehicles.duplicate():
		_remove(vehicle)
	_mirroring = on
	_told = {}
	_mirrored = {}
	holders = {}
	_closure = {}
	_closed = {}
	_barriers = {}
	_cordon_seen = -1
	for crossing: Dictionary in crossings:
		crossing["cars"] = 0
	if not on and _running:
		graph.bus = {}
		for index in _wanted_cars():
			_spawn_car(true)
		_next_car = Game.now() + 2.0
		_next_bus = Game.now() + 8.0


func _physics_process(delta: float) -> void :
	if not _running:
		return
	if Net.is_client() != _mirroring:
		_set_mirroring(Net.is_client())
	var dt: = minf(delta, 0.1)
	var now: = Game.now()
	if _mirroring:

		for vehicle in vehicles:
			_follow(vehicle, now)
		return
	var settings: Dictionary = Config.Life
	var bodies: = _gather_bodies()
	var sirens: = Emergency.sirens()
	_read_closure()
	_look_for_set_piece(dt)

	for i in range(vehicles.size() - 1, -1, -1):
		var vehicle: = vehicles[i]
		if not _drive(vehicle, dt, now, bodies, sirens):
			_remove(vehicle)

	for crossing: Dictionary in crossings:
		crossing["cars"] = 0
	var cars: = 0
	var buses: = 0
	var plows: = 0
	for vehicle in vehicles:
		_claim_crossings(vehicle)
		cars += 1 if vehicle.kind == "car" else 0
		buses += 1 if vehicle.kind == "bus" else 0
		plows += 1 if vehicle.kind == "plow" else 0

	var wanted: = _wanted_cars()
	if Game.night:
		wanted = floori(wanted * settings["CarNightShare"] + 0.5)
	if cars < wanted and now >= _next_car:
		_spawn_car(false)
		_next_car = now + 2.0
	if plows < _plows_wanted() and now >= _next_plow:

		_next_plow = now + (_between(Vector2(20.0, 50.0)) if _spawn_plow() else 4.0)
	if buses < int(settings["Buses"]) and now >= _next_bus:

		_next_bus = now + (float(settings["BusEvery"]) if _spawn_bus() else 3.0)





var set_pieces: = 0
var horned: = 0
var _set_piece_for: = -1.0
var _set_piece_clock: = 0.0

var _scripted_drive: bool = Array(OS.get_cmdline_user_args()).any( func(arg: String) -> bool: return arg.begins_with("--play="))




func _wanted_cars() -> int:
	var by: Array = Config.Traffic.Cars
	if Settings.quality <= Graphics.VERY_LOW:
		return int(by[0]) / 2
	return int(by[clampi(Settings.quality, 0, by.size() - 1)])








func _hears(vehicle: Car, sirens: Array) -> Dictionary:
	var settings: Dictionary = Config.Life
	var own: Dictionary = Config.Traffic
	var reach: float = settings["SirenRange"]
	var passed: float = settings["SirenPassed"]
	for siren: Dictionary in sirens:
		var rx: float = vehicle.x - siren["x"]
		var rz: float = vehicle.z - siren["z"]
		var far: = rx * rx + rz * rz
		if far >= reach * reach or rx * siren["dx"] + rz * siren["dz"] <= - passed:
			continue
		var distance: = sqrt(far)
		if vehicle.deaf and distance > float(own["DeafNear"]):

			if distance <= float(own["YieldNear"]):
				vehicle.deaf_for += get_physics_process_delta_time()
				if vehicle.deaf_for >= float(own["DeafNotice"]):
					vehicle.deaf = false
			continue
		var aside: = absf(rx * vehicle.dz - rz * vehicle.dx)
		if distance <= float(own["YieldNear"]) or aside <= float(own["YieldAside"]) or absf(rx * siren["dz"] - rz * siren["dx"]) <= float(own["YieldPath"]):
			vehicle.behind = aside <= float(own["YieldAside"]) and rx * vehicle.dx + rz * vehicle.dz > 0.0 and siren["dx"] * vehicle.dx + siren["dz"] * vehicle.dz > 0.3
			return siren
	return {}




func _watch_calls() -> void :
	for engine in Vehicle.all:
		engine.horn.connect( func() -> void : _horn_from(engine))



func _horn_from(engine: Vehicle) -> void :
	if _mirroring or not is_instance_valid(engine):
		return
	var reach: = float(Config.Life.HornRange) * float(Config.Traffic.HornReach)
	var at: = engine.global_position
	var ahead: = - engine.global_basis.z
	for vehicle in vehicles:
		var rx: = vehicle.x - at.x
		var rz: = vehicle.z - at.z
		if vehicle.deaf and rx * rx + rz * rz < reach * reach and rx * ahead.x + rz * ahead.z > 0.0:
			vehicle.deaf = false
			horned += 1





func _look_for_set_piece(delta: float) -> void :
	_set_piece_clock -= delta
	if _set_piece_clock > 0.0:
		return
	_set_piece_clock = 1.0
	var incident: = Game.incident
	if not Alarm.active or not incident.has("pos") or _set_piece_for == Alarm.started_at or Game.station == null:
		return
	if _scripted_drive:
		return
	for engine in Vehicle.all:
		if engine.siren != 0 and absf(engine.forward_speed) > float(Config.Traffic.SetPieceSpeed) and not Game.station.inside(engine.global_position, 20.0):
			_set_piece_for = Alarm.started_at
			set_pieces += put_on_way(engine.global_position, incident.get("approach", incident["pos"]))
			return





func put_on_way(from: Vector3, to: Vector3) -> int:
	var own: Dictionary = Config.Traffic
	var way: = Guide._way_between(graph, from, to)
	if way.is_empty():
		return 0

	var route: Array = []
	for id: int in way["route"]:
		if _closed.has(id):
			break
		route.append(id)
	var count: = int(own["SetPieceCars"])
	var made: = 0
	for index in count:
		var wanted: = lerpf(float(own["SetPieceFrom"]), float(own["SetPieceTo"]), (index + 0.5) / count)
		var run: = - float(way["from_along"])
		for at in route.size():
			var lane: Dictionary = segments[route[at]]
			if lane["kind"] == "lane" and wanted >= run and wanted < run + float(lane["length"]):
				if _put_on_lane(route.slice(at), wanted - run, made == 0):
					made += 1
				break
			run += float(lane["length"])
	return made




func _put_on_lane(route: Array, along: float, deaf: bool) -> bool:
	var settings: Dictionary = Config.Life
	var own: Dictionary = Config.Traffic
	var car_size: Vector3 = settings["CarSize"]
	var lane: Dictionary = segments[route[0]]
	if float(lane["length"]) < car_size.z * 2.0 or lane["island"] != _main_island or _closed.has(lane["id"]):
		return false
	along = clampf(along, car_size.z, float(lane["length"]) - car_size.z)
	var point: = NavGraph.sample(lane, along)
	if _nearest_vehicle(point.x, point.y) < float(own["SetPieceRoom"]):
		return false
	for player in Game.players:
		var at: = player.global_position
		if Vector2(at.x - point.x, at.z - point.y).length() < float(own["SetPieceHidden"]):
			return false
	var exit: Variant = null
	var way_out: = _pick_way_through(0)
	if not way_out.is_empty():
		exit = way_out[1]
	var drive: Array[int] = []
	for id: int in route:
		drive.append(id)
	if exit != null:
		var onward: = graph.drive_route(int(route[route.size() - 1]), int(exit["id"]), _closed)
		for i in range(1, onward.size()):
			drive.append(onward[i])
	var vehicle: = _create("car", car_size, drive, {})
	vehicle.s = along
	vehicle.v = _speeds[lane["rank"]] * float(own["SetPiecePace"])
	vehicle.deaf = deaf
	_launch(vehicle)
	return true
