class_name TownLocals
extends Node3D






















const LOOK_REACH: = 12.0
const CHECK_EVERY: = 0.5
const FADE: = 1.2
const SLOT: = 0.75
const REACH: Array[float] = [130.0, 180.0, 230.0]
const QUIET: = 80.0
const CHILD: = 0.62
const TEEN: = 0.86
const HEAD_TURN: = deg_to_rad(70.0)
const SIREN_RANGE: = 120.0
const SMOKES: = 3
const CLINK_REACH: = 45.0
const CLINK_CHANCE: = 0.12
const BOUNCE_REACH: = 70.0
const STOOD_ON: = ["Ground", "Step", "FrontLanding", "Landing"]

enum {CAFE, GARDEN, CHAT, PORCH, PATCH, VINES, GRILL, BOUNCE, SWING, SEESAW, SAND, CHASE, HOOPS, RIM, KENNEL, SHOP}
const KIND_NAMES: Array[String] = ["cafe", "garden", "chat", "porch", "patch", "vines", "grill", "bounce", "swing", "seesaw", "sand", "chase", "hoops", "rim", "kennel", "shop"]
const KIDS: Array = [[9.5, 12.0, 0.35], [14.0, 20.6, 0.7]]

const HOURS: = {
	CAFE: [[7.0, 10.0, 0.3], [10.0, 16.0, 0.2], [16.0, 18.0, 0.45], [18.0, 23.2, 0.85]], 
	GARDEN: [[12.3, 14.0, 0.3], [17.3, 22.0, 0.75]], 
	CHAT: [[8.0, 11.0, 0.12], [17.0, 21.5, 0.5]], 
	PORCH: [[9.0, 12.0, 0.3], [15.0, 20.8, 0.6]], 
	PATCH: [[6.8, 10.0, 0.35], [17.0, 20.5, 0.5]], 
	VINES: [[7.0, 11.0, 0.35], [16.5, 20.0, 0.45]], 
	GRILL: [[17.3, 22.0, 0.75]], 
	BOUNCE: KIDS, SWING: KIDS, SEESAW: KIDS, SAND: KIDS, CHASE: KIDS, 
	HOOPS: [[15.0, 21.2, 0.65]], 
	RIM: [[10.0, 22.5, 0.45]], 
	KENNEL: [[0.0, 24.0, 1.0]], 
	SHOP: [[7.5, 12.0, 0.6], [12.0, 16.5, 0.4], [16.5, 19.5, 0.7]], 
}



const WINTER_SHARE: = {CHAT: 0.45, SHOP: 1.3, VINES: 0.35, CHASE: 0.5, KENNEL: 1.0}
const ROOFED: = [CAFE, KENNEL, SHOP]


const BEER: = Color8(222, 160, 40)
const WINE: = Color8(150, 30, 50)
const CUP: = Color8(240, 238, 232)
const WOOD: = Color8(120, 84, 52)
const IRON: = Color8(52, 52, 56)
const EMBERS: = Color8(255, 120, 30)
const SAUSAGE: = Color8(160, 70, 50)
const BALL: = Color8(220, 100, 30)
const DOG_COATS: Array[Color] = [Color8(70, 52, 38), Color8(196, 160, 112), Color8(30, 30, 32), Color8(236, 230, 218), Color8(140, 96, 60)]
const CHAIRS: Array[Color] = [Color8(150, 108, 70), Color8(236, 234, 228), Color8(60, 110, 70)]

static var current: TownLocals



class Spot:
	extends RefCounted
	var kind: = 0
	var root: = Transform3D.IDENTITY
	var key: = 0
	var group: = 0
	var share: = 1.0
	var phase: = 0.0
	var size: = 1.0
	var a: = 0.0
	var b: = Vector3.ZERO
	var c: = Vector3.ZERO
	var parts: Array = []
	var nodes: Array = []
	var rests: Array = []

	var seed: = 0
	var shown: = 0
	var alpha: = 0.0
	var pieces: Array = []
	var scale: = 1.0
	var near: = false


var spots: Array = []
var drawn: = 0
var out: = 0

var _boxes: MultiMesh
var _heads: MultiMesh
var _domes: MultiMesh
var _n_boxes: = 0
var _n_heads: = 0
var _n_domes: = 0
var _since: = CHECK_EVERY
var _surfaces: = -1
var _trace: = false
var _trace_at: = 0.0
var _spent: = 0.0
var _frames: = 0
var _look: = -1
var _camera: Camera3D
var _smokes: Array = []
var _smoke_material: ParticleProcessMaterial
var _smoke_draw: Mesh
var _wailing: Array[Vector3] = []
var _eye: = Vector3.ZERO
var _played: = 0
var _bounced: = {}


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func start() -> void :
	var began: = Time.get_ticks_msec()
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	var args: = OS.get_cmdline_user_args()
	_trace = args.has("--locals-trace")
	for arg in args:
		if arg.begins_with("--locals-look="):
			_look = KIND_NAMES.find(arg.get_slice("=", 1))
	_boxes = _multimesh(Figure.BOX, false)
	_heads = _multimesh(Figure.HEAD, true)
	_domes = _multimesh(Figure.DOME, false)
	for id: int in Game.store.nodes:
		if Game.store.nodes[id]["n"] == "Surfaces" and Game.store.nodes[id]["c"] == "Folder":
			_surfaces = id
			break
	_find_spots()

	Style.current.changed.connect( func(_style: int) -> void :
		for spot: Spot in spots:
			if spot.shown != 0:
				_dress(spot)
		_since = CHECK_EVERY
	)
	var kinds: = {}
	for spot: Spot in spots:
		kinds[KIND_NAMES[spot.kind]] = kinds.get(KIND_NAMES[spot.kind], 0) + 1
	print("locals: %d places (%s) in %d ms" % [spots.size(), ", ".join(kinds.keys().map( func(k: String) -> String: return "%d %s" % [kinds[k], k])), Time.get_ticks_msec() - began])
	if _look >= 0:
		_camera = Camera3D.new()
		_camera.far = 4000.0
		add_child(_camera)
		_camera.make_current()


func _multimesh(shape: int, face: bool) -> MultiMesh:
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = true
	multimesh.use_custom_data = shape == Figure.HEAD
	multimesh.mesh = Figure.mesh_of(shape)
	multimesh.custom_aabb = AABB(Vector3(-1200, -20, -1200), Vector3(2600, 80, 2600))
	multimesh.instance_count = 64
	multimesh.visible_instance_count = 0
	var instance: = MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.material_override = Figure.material(Color.WHITE, face)
	add_child(instance)
	return multimesh







static func _roll(a: int, b: int) -> float:
	return float(rand_from_seed(hash([a, b]))[0] %100000) / 100000.0


func _spot(kind: int, root: Transform3D, group: int, share: = 1.0) -> Spot:
	var spot: = Spot.new()
	spot.kind = kind
	spot.root = root
	spot.key = hash([kind, snappedf(root.origin.x, 0.1), snappedf(root.origin.z, 0.1)])
	spot.group = group
	spot.share = share
	spot.phase = _roll(group, 7)
	spots.append(spot)
	return spot




func _ground(x: float, z: float, from: = 6.0) -> Variant:
	var hit: = Game.world.raycast(Vector3(x, from, z), Vector3(x, -4.0, z), World.LAYER_SOLID)
	var row: = Game.world.row_hit(hit)
	if row < 0:
		return null
	if Game.store.parent(row) == _surfaces or Game.store.name_at(row) in STOOD_ON:
		return hit["position"].y
	return null



func _floor(x: float, z: float, from: = 6.0) -> Variant:
	var hit: = Game.world.raycast(Vector3(x, from, z), Vector3(x, -4.0, z), World.LAYER_SOLID)
	return hit["position"].y if not hit.is_empty() else null


static func _facing(at: Vector3, toward: Vector3) -> Transform3D:
	var flat: = Vector3(toward.x - at.x, 0, toward.z - at.z)
	if flat.length_squared() < 1e-06:
		return Transform3D(Basis(), at)
	return Transform3D(Basis.looking_at(flat.normalized(), Vector3.UP), at)


static func _turned(at: Vector3, ahead: Vector3) -> Transform3D:
	return _facing(at, at + ahead)



func _rows_near(part_name: String, at: Vector3, reach: float) -> Array:
	var found: Array = []
	for row in Game.store.rows_named(part_name):
		var gap: = Vector2(Game.store.position(row).x - at.x, Game.store.position(row).z - at.z).length()
		if gap < reach:
			found.append([gap, row])
	found.sort_custom( func(one: Array, two: Array) -> bool: return one[0] < two[0])
	return found.map( func(pair: Array) -> int: return pair[1])


func _folder(path: Array) -> int:
	var id: = 0
	for part_name: String in path:
		var next: = -1
		for child: int in Game.store.nodes_under.get(id, PackedInt32Array()):
			if Game.store.nodes[child]["n"] == part_name:
				next = child
				break
		if next < 0:
			return -1
		id = next
	return id


func _find_spots() -> void :
	var store: = Game.store
	var layout: Dictionary = Rbx.module("TownLayout")
	var features: Array = layout.get("features", [])
	var by_kind: = {}
	for feature: Dictionary in features:
		by_kind[feature["kind"]] = by_kind.get(feature["kind"], []) + [feature]


	var shopfronts: = _folder(["Map", "Polish", "Shopfronts"])
	var gardens: Array = by_kind.get("garden_table", [])
	var tables: = {}
	for row in store.rows_named("ChairSeat"):
		var at: = store.position(row)
		var kind: = -1
		if store.parent(row) == shopfronts:
			kind = CAFE
		else:
			for feature: Dictionary in gardens:
				if Vector2(feature["x"] - at.x, feature["z"] - at.z).length() < 7.0:
					kind = GARDEN
					break
		if kind < 0:
			continue

		var ahead: = - store.basis(row).z
		ahead = Vector3(ahead.x, 0, ahead.z).normalized()
		var table: = at + ahead * 2.4
		var group: = hash([snappedf(table.x, 2.0), snappedf(table.z, 2.0)])
		var first: int = tables.get(group, 0)
		tables[group] = first + 1
		var spot: = _spot(kind, _turned(Vector3(at.x, at.y + store.size(row).y / 2.0, at.z) - ahead * 0.15, ahead), group, 1.0 if first == 0 else 0.75)
		spot.b = Vector3(table.x, at.y + 1.15, table.z)


	var graph: = NavGraph.current
	var buildings: Array = layout.get("buildings", [])
	if graph:
		for place: Dictionary in graph.places:
			if place["kind"] != "door" or not place.get("building_kind", "") in ["house", "terrace"]:
				continue
			var yaw: = deg_to_rad(float(buildings[place["building"]]["yaw"]))
			var outward: = Vector3( - sin(yaw), 0, - cos(yaw))
			var side: = Vector3( - outward.z, 0, outward.x)
			var door: = Vector3(place["x"], 0, place["z"])
			var pick: = hash(["door", place["id"]]) % 100

			var talkers: = 60 if place["building_kind"] == "terrace" else 34
			if pick < talkers:


				for offsets: Array in [[3.4, 0.6, 3.8, 4.0], [-3.4, 0.6, -3.8, 4.0], [2.6, 9.0, -1.4, 10.5], [3.0, 13.0, -1.0, 14.5]]:
					var one: = door + side * float(offsets[0]) + outward * float(offsets[1])
					var two: = door + side * float(offsets[2]) + outward * float(offsets[3])
					var under_one: Variant = _ground(one.x, one.z)
					var under_two: Variant = _ground(two.x, two.z)
					if under_one != null and under_two != null and absf(float(under_one) - float(under_two)) < 1.0:
						one.y = under_one
						two.y = under_two
						var group: = hash(["chat", place["id"]])
						_spot(CHAT, _facing(one, two), group).b = two
						_spot(CHAT, _facing(two, one), group).b = one
						break
			elif pick < talkers + 14:
				var seat: = door - side * 3.4 - outward * 0.2
				var under: Variant = _ground(seat.x, seat.z)
				if under != null and _ground(seat.x + outward.x * 2.0, seat.z + outward.z * 2.0) != null:
					seat.y = under
					var looking: = (outward + side * -0.35).normalized()
					_spot(PORCH, _turned(seat, looking), hash(["porch", place["id"]]))


	for row in store.rows_named("StallTop"):
		if store.parent(row) != shopfronts:
			continue
		var stall: = store.position(row)
		var outward: = - store.basis(row).z
		outward = Vector3(outward.x, 0, outward.z).normalized()
		var along: = Vector3( - outward.z, 0, outward.x)
		var group: = hash(["shop", row])
		for which in 2:
			var at: = stall + outward * 2.9 + along * (1.8 if which == 0 else -2.0)
			var under: Variant = _ground(at.x, at.z)
			if under != null:
				at.y = under
				_spot(SHOP, _facing(at, stall), group, 1.0 if which == 0 else 0.55).b = stall


	for feature: Dictionary in by_kind.get("veg_patch", []):
		if hash(["patch", feature["x"]]) % 100 >= 70:
			continue
		var basis: = Basis(Vector3.UP, deg_to_rad(float(feature.get("yaw", 0.0))))
		var at: = Vector3(feature["x"], 0, feature["z"]) + basis * Vector3(1.5, 0, 1.0)
		var under: Variant = _floor(at.x, at.z, 3.0)
		if under != null and under < 1.5:
			at.y = under
			_spot(PATCH, Transform3D(basis * Basis(Vector3.UP, 0.6), at), hash(["patch", feature["x"], feature["z"]]))


	for beam in store.rows_named("BrajdaBeam"):
		var line: = store.position(beam)
		var along: = store.basis(beam).x
		along = Vector3(along.x, 0, along.z).normalized()
		var across: = Vector3( - along.z, 0, along.x)
		var middle: = Vector3.ZERO
		for other in _rows_near("BrajdaBeam", line, 14.0):
			middle += store.position(other) / 2.0
		var inward: = Vector3(middle.x - line.x, 0, middle.z - line.z)
		inward = across if inward.dot(across) > 0.0 else - across
		var length: = store.size(beam).x
		for which in 2:
			var at: = Vector3(line.x, 0, line.z) + along * (_roll(hash([snappedf(line.x, 1.0), snappedf(line.z, 1.0)]), which) * 0.45 + (0.05 if which == 0 else -0.5)) * (length - 6.0) + inward * 1.6
			var under: Variant = _floor(at.x, at.z, 3.0)
			if under != null and under < 1.5:
				at.y = under
				var spot: = _spot(VINES, _turned(at, - inward), hash(["vines", snappedf(line.x, 1.0), snappedf(line.z, 1.0), which]))
				spot.c = along


	for feature: Dictionary in gardens:
		var middle: = Vector3(feature["x"], 0, feature["z"])
		if hash(["grill", feature["x"]]) % 2 == 1:
			continue
		for turn in 8:
			var way: = Vector3(sin(turn * TAU / 8.0), 0, cos(turn * TAU / 8.0))
			var grill: = middle + way * 7.0
			var stand: = middle + way * 9.2
			if _ground(grill.x, grill.z) == null or _ground(stand.x, stand.z) == null:
				continue
			if not _rows_near("ChairSeat", grill, 3.0).is_empty():
				continue
			var chairs: = _rows_near("ChairSeat", middle, 7.0)
			if chairs.is_empty():
				break
			var chair: int = chairs[0]
			var ahead: = - store.basis(chair).z
			var table: = store.position(chair) + Vector3(ahead.x, 0, ahead.z).normalized() * 2.4
			stand.y = _ground(stand.x, stand.z)
			grill.y = _ground(grill.x, grill.z)
			var spot: = _spot(GRILL, _facing(stand, grill), hash([snappedf(table.x, 2.0), snappedf(table.z, 2.0)]))
			spot.b = grill
			break


	for feature: Dictionary in by_kind.get("trampoline", []):
		var mats: = _rows_near("TrampolineMat", Vector3(feature["x"], 0, feature["z"]), 4.0)
		if not mats.is_empty():
			var mat: = store.position(mats[0])
			var spot: = _spot(BOUNCE, Transform3D(Basis(Vector3.UP, _roll(mats[0], 1) * TAU), Vector3(mat.x, mat.y + 0.15, mat.z)), hash(["bounce", mats[0]]))
			spot.size = CHILD
	for feature: Dictionary in by_kind.get("swing", []):
		var near: = Vector3(feature["x"], 0, feature["z"])
		var bars: = _rows_near("SwingBar", near, 8.0)
		if bars.is_empty():
			continue
		var bar: int = bars[0]
		var bar_at: = store.position(bar)
		var bar_size: = store.size(bar)
		var bar_basis: = store.basis(bar)
		var axis: Vector3 = bar_basis.x if bar_size.x >= maxf(bar_size.y, bar_size.z) else (bar_basis.y if bar_size.y >= bar_size.z else bar_basis.z)
		axis = Vector3(axis.x, 0, axis.z).normalized()
		var group: = hash(["swing", bar])
		var index: = 0
		for seat: int in _rows_near("SwingSeat", bar_at, 8.0):
			var seat_at: = store.position(seat)
			var pivot: = bar_at + axis * axis.dot(seat_at - bar_at)
			pivot.y = bar_at.y
			var ahead: = axis.cross(Vector3.UP).normalized()
			var spot: = _spot(SWING, _turned(seat_at, ahead), group, 1.0 if index == 0 else 0.6)
			spot.size = CHILD
			spot.b = pivot
			spot.c = axis
			spot.a = store.size(seat).y / 2.0
			spot.parts.append(store.id_at(seat))
			for chain: int in _rows_near("SwingChain", seat_at, 2.6):
				spot.parts.append(store.id_at(chain))
			index += 1
	for feature: Dictionary in by_kind.get("seesaw", []):
		var boards: = _rows_near("SeesawBoard", Vector3(feature["x"], 0, feature["z"]), 5.0)
		if boards.is_empty():
			continue
		var board: int = boards[0]
		var size: = store.size(board)
		var basis: = store.basis(board)
		var along: Vector3 = basis.x if size.x >= size.z else basis.z
		along = Vector3(along.x, 0, along.z).normalized()
		var half: = maxf(size.x, size.z) / 2.0 - 1.1
		var middle: = store.position(board)
		var group: = hash(["seesaw", board])
		for end: float in [1.0, -1.0]:
			var seat: = middle + along * half * end
			var spot: = _spot(SEESAW, _facing(Vector3(seat.x, middle.y + size.y / 2.0, seat.z), middle), group)
			spot.size = CHILD
			spot.b = middle
			spot.c = along * end
			spot.a = half
			if end > 0.0:
				spot.parts.append(store.id_at(board))
	for feature: Dictionary in by_kind.get("sandpit", []):
		var sands: = _rows_near("Sand", Vector3(feature["x"], 0, feature["z"]), 5.0)
		if sands.is_empty():
			continue
		var sand: = store.position(sands[0])
		var top: = sand.y + store.size(sands[0]).y / 2.0
		var group: = hash(["sand", sands[0]])
		var turn: = deg_to_rad(float(feature.get("yaw", 0.0)))
		for which in 2:
			var way: = Vector3(sin(turn + which * PI), 0, cos(turn + which * PI))
			var spot: = _spot(SAND, _facing(Vector3(sand.x, top, sand.z) + way * 1.9, Vector3(sand.x, top, sand.z)), group, 1.0 if which == 0 else 0.7)
			spot.size = CHILD
	for kind: String in ["slide", "climber"]:
		for feature: Dictionary in by_kind.get(kind, []):
			var centre: = Vector3(feature["x"], 0, feature["z"])
			var turn: = deg_to_rad(float(feature.get("yaw", 0.0)))
			var middle: = centre + Vector3(sin(turn), 0, cos(turn)) * 9.0
			var clear: = true
			for step in 8:
				var at: = middle + Vector3(sin(step * TAU / 8.0), 0, cos(step * TAU / 8.0)) * 4.5
				if _ground(at.x, at.z, 7.0) == null:
					clear = false
					break
			var under: Variant = _ground(middle.x, middle.z, 7.0)
			if not clear or under == null:
				continue
			middle.y = under
			var group: = hash(["chase", feature["x"]])
			for which in 3:
				var spot: = _spot(CHASE, Transform3D(Basis(), middle), group, [1.0, 0.85, 0.6][which])
				spot.size = CHILD
				spot.a = 4.5
				spot.c = Vector3(which * TAU / 3.0, 0, 0)
	for feature: Dictionary in by_kind.get("hoop", []):
		var near: = Vector3(feature["x"], 0, feature["z"])
		var rings: = _rows_near("Ring", near, 6.0)
		var boards: = _rows_near("Backboard", near, 6.0)
		if rings.is_empty() or boards.is_empty():
			continue
		var ring: = store.position(rings[0])
		var board: = store.position(boards[0])
		var outward: = Vector3(ring.x - board.x, 0, ring.z - board.z).normalized()
		var stand: = ring + outward * 11.0
		var under: Variant = _ground(stand.x, stand.z)
		if under == null:
			continue
		stand.y = under
		var spot: = _spot(HOOPS, _facing(stand, ring), hash(["hoops", rings[0]]))
		spot.size = TEEN
		spot.b = ring
		spot.c = outward


	for feature: Dictionary in by_kind.get("fountain", []):
		var basins: = _rows_near("Basin", Vector3(feature["x"], 0, feature["z"]), 6.0)
		if basins.is_empty():
			continue
		var basin: = store.position(basins[0])
		var size: = store.size(basins[0])
		var dims: = [size.x, size.y, size.z]
		dims.sort()
		var radius: float = dims[2] / 2.0
		var top: float = basin.y + dims[0] / 2.0
		for which in 4:
			var way: = Vector3(sin(which * TAU / 4.0 + 0.4), 0, cos(which * TAU / 4.0 + 0.4))
			var spot: = _spot(RIM, _turned(Vector3(basin.x, top, basin.z) + way * (radius - 0.5), way), hash(["rim", which]))
			spot.b = basin
	for feature: Dictionary in by_kind.get("kennel", []):
		var doors: = _rows_near("KennelDoor", Vector3(feature["x"], 0, feature["z"]), 4.0)
		if doors.is_empty():
			continue
		var door: = store.position(doors[0])
		var kennel: = Vector3(feature["x"], 0, feature["z"])
		var outward: = Vector3(door.x - kennel.x, 0, door.z - kennel.z).normalized()
		var at: = door + outward * 2.2
		var under: Variant = _floor(at.x, at.z, 3.0)
		if under != null:
			at.y = under
			_spot(KENNEL, _turned(at, outward), hash(["kennel", feature["x"]]))






func _who(spot: Spot, hour: float, raining: bool, quiet: Variant) -> int:
	if raining and not spot.kind in ROOFED:
		return 0
	if quiet != null and Vector2(spot.root.origin.x - quiet.x, spot.root.origin.z - quiet.z).length() < QUIET:
		return 0
	var chance: = 0.0
	for window: Array in HOURS[spot.kind]:
		if hour >= window[0] and hour < window[1]:
			chance = window[2]
	if Style.winter():
		chance *= WINTER_SHARE.get(spot.kind, 0.0)
	if chance <= 0.0:
		return 0
	var slot: = floori(hour / SLOT + spot.phase)
	if _roll(spot.group, slot) >= chance or _roll(spot.key, slot) >= spot.share:
		return 0
	return absi(hash([spot.key, slot])) % 1000000 + 1


func _check(eye: Vector3) -> void :
	var hour: = Sky3D.current.hour if Sky3D.current else 12.0
	var raining: = Weather.current != null and Weather.current.rain > 0.3
	var quiet: Variant = Game.incident.get("pos") if not Game.incident.is_empty() else null
	var reach: float = REACH[clampi(Settings.quality, 0, REACH.size() - 1)] * (0.7 if Settings.quality <= Graphics.VERY_LOW else 1.0)
	out = 0
	for spot: Spot in spots:
		spot.seed = _who(spot, hour, raining, quiet)
		if spot.seed != 0:
			out += 1
		spot.near = spot.root.origin.distance_to(eye) < reach or spot.kind == _look





func _dress(spot: Spot) -> void :
	var age: = ""
	if spot.size == CHILD:
		age = Figure.AGE_CHILD
	elif spot.size == TEEN:
		age = Figure.AGE_TEEN
	elif spot.kind == PORCH:
		age = Figure.AGE_OLD


	var type: = ""
	if spot.kind == PORCH:
		type = Figure.TYPE_PENSIONER
	elif spot.kind == PATCH or spot.kind == VINES:
		type = Figure.TYPE_VINEDRESSER
	elif KIND_NAMES[spot.kind] == "shop" and age.is_empty():
		type = Figure.TYPE_SHOP
	var made: = Figure.looks(spot.shown, {}, age, type)
	if (spot.kind == PATCH or spot.kind == VINES) and not Style.winter() and rand_from_seed(hash([spot.shown, "straw"]))[0] %100 < 60:
		made["style"] = Figure.HAT_SUN
	spot.scale = made["scale"] * spot.size
	spot.pieces = Townsfolk.scaled(Figure.pieces(made), spot.scale)





func _process(dt: float) -> void :
	var began: = Time.get_ticks_usec()
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var eye: = camera.global_position
	_eye = eye
	_since += dt
	if _since >= CHECK_EVERY:
		_since = 0.0
		_check(eye)
		_find_sirens()
		_place_smoke(eye)
		_clink(eye)
	var now: = HostClock.now()
	_n_boxes = 0
	_n_heads = 0
	_n_domes = 0
	drawn = 0
	var looked: Spot = null
	for spot: Spot in spots:

		var wanted: = spot.seed != 0 and spot.near and (spot.shown == 0 or spot.shown == spot.seed)
		if wanted and spot.shown == 0:
			spot.shown = spot.seed
			_dress(spot)
		spot.alpha = clampf(spot.alpha + (dt if wanted else - dt) / FADE, 0.0, 1.0)
		if spot.alpha <= 0.0:
			spot.shown = 0
			if not spot.nodes.is_empty():
				_settle(spot)
			continue
		if _n_boxes + 64 > _boxes.instance_count:
			_grow()
		_draw(spot, now)
		drawn += 1
		if _look == spot.kind and looked == null and spot.alpha > 0.5:
			looked = spot
	_boxes.visible_instance_count = _n_boxes
	_heads.visible_instance_count = _n_heads
	_domes.visible_instance_count = _n_domes
	if looked and _camera:
		_look_at(looked)
	if _trace:
		_spent += (Time.get_ticks_usec() - began) / 1000.0
		_frames += 1
		if now - _trace_at > 5.0:
			_trace_at = now
			var by_kind: = {}
			for spot: Spot in spots:
				if spot.seed != 0:
					by_kind[KIND_NAMES[spot.kind]] = by_kind.get(KIND_NAMES[spot.kind], 0) + 1
			print("locals out by kind: ", by_kind)
			print("locals at %.2f h: %d out, %d drawn, %d boxes, %d sounds, %.3f ms a frame" % [Sky3D.current.hour if Sky3D.current else 0.0, out, drawn, _n_boxes, _played, _spent / maxi(_frames, 1)])
			_spent = 0.0
			_frames = 0



func _look_at(spot: Spot) -> void :
	var at: = spot.root.origin + Vector3(0, 2.5, 0)
	if _camera.has_meta("at") and _camera.get_meta("at") == at:
		return
	_camera.set_meta("at", at)
	var ahead: = - spot.root.basis.z
	for step in 16:
		var way: = ahead.rotated(Vector3.UP, step * TAU / 16.0 * (1 if step % 2 == 0 else -1))
		for distance: float in [11.0, 7.0]:
			var from: = at + way * distance + Vector3(0, 3.5, 0)
			var hit: = Game.world.raycast(from, at, World.LAYER_SOLID | World.LAYER_QUERY)
			if hit.is_empty() or hit["position"].distance_to(at) < 2.0:
				_camera.look_at_from_position(from, at)
				return
	_camera.look_at_from_position(at + Vector3(0, 14, 6), at)


func _grow() -> void :
	var size: = _boxes.instance_count * 2
	for multimesh: MultiMesh in [_boxes, _heads, _domes]:
		multimesh.instance_count = size
		multimesh.visible_instance_count = 0

	_n_boxes = 0
	_n_heads = 0
	_n_domes = 0


func _find_sirens() -> void :
	_wailing.clear()
	for vehicle in Vehicle.all:
		if is_instance_valid(vehicle) and vehicle.is_inside_tree() and vehicle.siren > 0 and vehicle.linear_velocity.length() > 3.0:
			_wailing.append(vehicle.global_position)



func _siren_head(spot: Spot, at: Vector3) -> float:
	for siren in _wailing:
		var toward: = siren - at
		if Vector2(toward.x, toward.z).length() < SIREN_RANGE:
			var local: = spot.root.basis.inverse() * toward
			return clampf(atan2( - local.x, - local.z), - HEAD_TURN, HEAD_TURN)
	return 0.0


func _draw(spot: Spot, now: float) -> void :
	var t: = now + spot.phase * 97.0
	var alpha: = spot.alpha
	var s: = spot.scale
	var root: = spot.root
	match spot.kind:
		CAFE, GARDEN:
			var drink: = _every(t, 13.0, 2.4)
			var talking: = fmod(t + spot.key % 7, 10.0) < 5.0
			var hand: = 0.5 + (0.35 * sin(t * 2.3) + 0.45 if talking and drink <= 0.0 else 0.0)
			var head: = sin(t * 0.31) * 0.5 if not talking else 0.0
			head = _siren_head(spot, root.origin) if not _wailing.is_empty() else head
			var hand_at: = _figure(spot.pieces, _seated(root, s), 0.05, hand, 0.45 + 1.95 * drink, 1.5, 1.45, head, alpha)

			var glass: = spot.b + (spot.b - root.origin).cross(Vector3.UP).normalized() * 0.5 * Vector3(1, 0, 1) - (spot.b - root.origin) * Vector3(1, 0, 1) * 0.45
			glass.y = spot.b.y + 0.35
			glass = glass.lerp(hand_at, clampf(drink * 3.0, 0.0, 1.0))
			var morning: = Sky3D.current != null and Sky3D.current.hour < 12.0
			var colour: Color = CUP if morning else (BEER if spot.kind == CAFE and spot.key % 3 != 0 else WINE)
			_box(Transform3D(Basis.from_scale(Vector3(0.3, 0.5, 0.3)), glass), Color(colour, alpha))
		CHAT:
			var speaking: = fmod(t + (spot.key % 2) * 5.0, 10.0) < 5.0
			var sway: = sin(t * 0.7) * 0.05
			var arm_r: = 0.25 + (0.55 + 0.35 * sin(t * 2.7) if speaking else 0.0)
			var arm_l: = 0.25 + (0.3 + 0.2 * sin(t * 1.9 + 1.0) if speaking and fmod(t, 3.0) < 1.6 else 0.0)
			var head: = sin(t * 0.9) * 0.12 + _siren_head(spot, root.origin)
			_figure(spot.pieces, root * Transform3D(Basis(Vector3.UP, sway), Vector3.ZERO), 0.02, arm_l, arm_r, 0.0, 0.0, head, alpha)
		PORCH:
			var paint: Color = CHAIRS[spot.key % CHAIRS.size()]
			_chair(root, Color(paint, alpha))
			var wave: = 0.0
			var player: = Game.nearest_player(root.origin)
			if not player.is_empty() and player[1] < 22.0:
				wave = 1.0 if fmod(t, 9.0) < 2.0 else 0.0
			var arm_r: = 0.6 + (2.3 + 0.25 * sin(t * 9.0)) * wave
			var head: = sin(t * 0.23) * 0.6 + _siren_head(spot, root.origin)
			var sit: = root
			sit.origin.y += 1.8
			_figure(spot.pieces, _seated(sit, s), 0.12, 0.6, arm_r, 1.5, 1.5, head, alpha)
		PATCH:

			var chop: = sin(t * 2.4)
			var arms: = 1.25 + 0.35 * chop
			var lean: = 0.75 + 0.1 * chop
			var hands: = _figure(spot.pieces, root, lean, arms, arms, 0.18, -0.18, 0.0, alpha)
			var blade: = root * Vector3(0, 0.2, -3.6 - 0.6 * chop)
			_stick(hands, blade, 0.14, Color(WOOD, alpha))
			_box(Transform3D(_aim(hands, blade) * Basis.from_scale(Vector3(0.9, 0.12, 0.5)), blade), Color(IRON, alpha))
		VINES:
			var reach_up: = 1.9 + 0.35 * sin(t * 1.7)
			var other: = 1.7 + 0.35 * sin(t * 1.7 + 2.0)
			var drift: = sin(t * 0.02) * 3.0
			var at: = root
			at.origin += spot.c * drift
			_figure(spot.pieces, at, 0.08, other, reach_up, 0.0, 0.0, 0.0, alpha)
			_box(Transform3D(at.basis * Basis.from_scale(Vector3(1.4, 1.0, 1.0)), at * Vector3(-2.2, 0.5, -0.4)), Color(WOOD, alpha))
		GRILL:
			_grill(spot.b, root.basis, alpha)
			var turning: = 1.0 if fmod(t, 7.0) < 1.6 else 0.0
			var arm_r: = 0.95 + turning * (0.3 + 0.3 * sin(t * 11.0))
			var drink: = _every(t, 11.0, 2.0)
			var hand: = _figure(spot.pieces, root, 0.12, 0.45 + 1.95 * drink, arm_r, 0.0, 0.0, _siren_head(spot, root.origin), alpha)
			_box(Transform3D(Basis.from_scale(Vector3(0.3, 0.5, 0.3)), hand + Vector3(0, 0.2, 0)), Color(BEER, alpha))
		BOUNCE:
			var cycle: = fmod(t / 1.05, 1.0)
			var height: = 4.0 * sin(PI * cycle) * (0.8 + 0.2 * sin(t * 0.37))
			var tuck: = maxf(0.0, sin(PI * cycle) - 0.6) * 1.6
			var arms: = 2.6 * sin(PI * cycle)
			var up: = root
			up.origin.y += height
			up.basis = up.basis * Basis(Vector3.UP, t * 0.2)
			_figure(spot.pieces, up, 0.0, arms, arms, tuck, tuck, 0.0, alpha)
		SWING:
			var angle: = 0.6 * sin(TAU * t / 2.8)
			var swing: = Transform3D(Basis(spot.c, angle), Vector3.ZERO)
			_swing_parts(spot, spot.b, swing)
			var seat_top: = spot.b + swing.basis * (root.origin + Vector3(0, spot.a, 0) - spot.b)
			var kick: = 1.3 + 0.4 * cos(TAU * t / 2.8)
			var seated: = Transform3D(swing.basis * root.basis, seat_top)
			_figure(spot.pieces, _seated(seated, s), -0.1 * sin(TAU * t / 2.8), 2.75, 2.75, kick, kick, 0.0, alpha)
		SEESAW:
			var tilt: = 0.24 * sin(TAU * t / 2.6)
			var axis: = Vector3.UP.cross(spot.c).normalized()
			var turn: = Basis(axis, - tilt)
			if not spot.parts.is_empty():
				_swing_parts(spot, spot.b, Transform3D(turn, Vector3.ZERO))
			var seat: = spot.b + turn * (root.origin - spot.b)
			_figure(spot.pieces, _seated(Transform3D(turn * root.basis, seat), s), 0.1, 1.2, 1.2, 1.3, 1.3, 0.0, alpha)
		SAND:
			var dig: = sin(t * 2.2)
			_figure(spot.pieces, _seated(root, s), 0.35, 0.8 + 0.4 * dig, 0.8 - 0.4 * dig, 1.45, 1.35, sin(t * 0.4) * 0.4, alpha)
		CHASE:

			var turned: = sin(t * 0.13) * 30.0 / spot.a
			var speed: = cos(t * 0.13) * 30.0 * 0.13
			var angle: = spot.c.x + turned
			var at: = root.origin + Vector3(sin(angle), 0, cos(angle)) * spot.a
			var ahead: = Vector3(cos(angle), 0, - sin(angle)) * signf(speed)
			var gait: = clampf(absf(speed) / 2.0, 0.0, 1.0)
			var stride: = sin(t * 11.0) * 0.9 * gait
			at.y += absf(cos(t * 11.0)) * 0.25 * gait
			_figure(spot.pieces, _turned(at, ahead), 0.15 * gait, stride, - stride, - stride, stride, 0.0, alpha)
		HOOPS:
			_hoops(spot, t, alpha)
		RIM:
			var head: = sin(t * 0.27) * 0.7 + _siren_head(spot, root.origin)
			_figure(spot.pieces, _seated(root, s), 0.05, 0.25, 0.25 + 0.4 * _every(t, 15.0, 3.0), 1.3, 1.25, head, alpha)
		KENNEL:
			_dog(spot, t, alpha)
		SHOP:

			var reach_out: = _every(t, 6.0, 2.2)
			var head: = sin(t * 0.5) * 0.35 + _siren_head(spot, root.origin)
			_figure(spot.pieces, root, 0.18 + 0.2 * reach_out, 0.35, 0.4 + 0.9 * reach_out, 0.0, 0.0, head, alpha)



static func _seated(seat: Transform3D, scale: float) -> Transform3D:
	return Transform3D(seat.basis, seat.origin + seat.basis * Vector3(0, (0.5 - 2.0) * scale, 0.1))



static func _every(t: float, every: float, time: float) -> float:
	var into: = fmod(t, every)
	return sin(PI * into / time) if into < time else 0.0





func _figure(pieces: Array, root: Transform3D, lean: float, arm_l: float, arm_r: float, leg_l: float, leg_r: float, head: float, alpha: float) -> Vector3:
	var scale: float = pieces[0][5].y / 2.0
	var hip: = Vector3(0, 2.0 * scale, 0)
	var upper: = Basis(Vector3.RIGHT, - lean)
	var hand: = root.origin
	var face: Variant = null
	for piece: Array in pieces:
		var role: int = piece[1]
		var pivot: Vector3 = piece[3]
		var rest: Vector3 = piece[4]
		var size: Vector3 = piece[5]
		var basis: Basis
		var at: Vector3
		if role == Townsfolk.ROLE_LEG:
			basis = Basis(Vector3.RIGHT, leg_l if pivot.x < 0.0 else leg_r)
			at = pivot + basis * rest
		else:
			var own: = Basis.IDENTITY
			if role == Townsfolk.ROLE_ARM or role == Townsfolk.ROLE_HAND:
				own = Basis(Vector3.RIGHT, arm_l if pivot.x < 0.0 else arm_r)
			elif role == Townsfolk.ROLE_HEAD:
				own = Basis(Vector3.UP, head)
			basis = upper * own
			at = hip + upper * (pivot - hip + own * rest)
			if role == Townsfolk.ROLE_HAND and pivot.x > 0.0:
				hand = root * (hip + upper * (pivot - hip + own * Vector3(0, -1.9 * scale, 0)))
		var color: Color = piece[6]
		color.a = alpha
		var place: = Transform3D(root.basis * basis * Basis.from_scale(size), root * at)
		match piece[0]:
			Figure.HEAD:
				_heads.set_instance_transform(_n_heads, place)
				_heads.set_instance_color(_n_heads, color)
				face = Transform3D(root.basis * basis, root * at)

				var gaze: = 0.0
				if _eye.distance_squared_to(face.origin) < LOOK_REACH * LOOK_REACH:
					var seen: Vector3 = (face as Transform3D).affine_inverse() * _eye
					var aside: = atan2( - seen.x, - seen.z)
					if absf(aside) < 1.6:
						gaze = clampf( - aside * 0.9, -1.0, 1.0)
				_heads.set_instance_custom_data(_n_heads, Color(maxi(int(piece[8]), 0) / 255.0, (gaze + 1.0) / 2.0, 0, 0))
				_n_heads += 1
			Figure.DOME:
				_domes.set_instance_transform(_n_domes, place)
				_domes.set_instance_color(_n_domes, color)
				_n_domes += 1
			_:
				_boxes.set_instance_transform(_n_boxes, place)
				_boxes.set_instance_color(_n_boxes, color)
				_n_boxes += 1

	if face != null and alpha > 0.5 and Style.winter() and (face as Transform3D).origin.distance_to(_eye) < Townsfolk.BREATH_REACH:
		var t: = fposmod(HostClock.now() + (pieces[0][6] as Color).r * 7.0, Townsfolk.BREATH_EVERY)
		if t < 1.4:
			var k: = t / 1.4
			var puff: = lerpf(0.3, 1.2, sqrt(k)) * scale
			var at: Vector3 = (face as Transform3D) * (Vector3(0, 0.05 + 0.3 * k, -1.05 - 1.2 * k) * scale)
			_domes.set_instance_transform(_n_domes, Transform3D(Basis.from_scale(Vector3(puff, puff * 0.8, puff)), at))
			_domes.set_instance_color(_n_domes, Color(1.0, 1.0, 1.0, 0.4 * (1.0 - k)))
			_n_domes += 1
	return hand


func _box(place: Transform3D, color: Color) -> void :
	_boxes.set_instance_transform(_n_boxes, place)
	_boxes.set_instance_color(_n_boxes, color)
	_n_boxes += 1


func _ball(at: Vector3, across: float, color: Color) -> void :
	_domes.set_instance_transform(_n_domes, Transform3D(Basis.from_scale(Vector3.ONE * across), at))
	_domes.set_instance_color(_n_domes, color)
	_n_domes += 1


static func _aim(from: Vector3, to: Vector3) -> Basis:
	var way: = (to - from).normalized()
	return Basis.looking_at(way, Vector3.UP if absf(way.y) < 0.98 else Vector3.RIGHT)



func _stick(from: Vector3, to: Vector3, thick: float, color: Color) -> void :
	var span: = to - from
	if span.length() > 0.05:
		_box(Transform3D(_aim(from, to) * Basis.from_scale(Vector3(thick, thick, span.length())), from + span / 2.0), color)



func _chair(root: Transform3D, paint: Color) -> void :
	_box(Transform3D(root.basis * Basis.from_scale(Vector3(1.5, 0.2, 1.5)), root * Vector3(0, 1.7, 0)), paint)
	_box(Transform3D(root.basis * Basis.from_scale(Vector3(1.5, 1.8, 0.15)), root * Vector3(0, 2.6, 0.7)), paint)
	for x: float in [-0.6, 0.6]:
		_box(Transform3D(root.basis * Basis.from_scale(Vector3(0.12, 1.6, 1.3)), root * Vector3(x, 0.8, 0)), paint.darkened(0.2))



func _grill(at: Vector3, facing: Basis, alpha: float) -> void :
	var place: = Transform3D(facing, at)
	for corner: Vector3 in [Vector3(-1.0, 0, -0.5), Vector3(1.0, 0, -0.5), Vector3(-1.0, 0, 0.5), Vector3(1.0, 0, 0.5)]:
		_box(Transform3D(facing * Basis.from_scale(Vector3(0.15, 2.6, 0.15)), place * (corner + Vector3(0, 1.3, 0))), Color(IRON, alpha))
	_box(Transform3D(facing * Basis.from_scale(Vector3(2.6, 0.8, 1.5)), place * Vector3(0, 2.9, 0)), Color(IRON, alpha))
	_box(Transform3D(facing * Basis.from_scale(Vector3(2.3, 0.06, 1.2)), place * Vector3(0, 3.32, 0)), Color(EMBERS, alpha))
	for x: float in [-0.6, 0.0, 0.6]:
		_box(Transform3D(facing * Basis.from_scale(Vector3(0.25, 0.25, 0.9)), place * Vector3(x, 3.48, 0)), Color(SAUSAGE, alpha))




func _swing_parts(spot: Spot, pivot: Vector3, turn: Transform3D) -> void :
	if spot.nodes.is_empty() and not spot.parts.is_empty():
		for id: int in spot.parts:
			var node: = Game.world.take(id, false)
			if node:
				spot.nodes.append(node)
				spot.rests.append(node.global_transform)
	for i in spot.nodes.size():
		var rest: Transform3D = spot.rests[i]
		spot.nodes[i].global_transform = Transform3D(turn.basis * rest.basis, pivot + turn.basis * (rest.origin - pivot))



func _settle(spot: Spot) -> void :
	for i in spot.nodes.size():
		spot.nodes[i].global_transform = spot.rests[i]



func _hoops(spot: Spot, t: float, alpha: float) -> void :
	var cycle: = 5.6
	var into: = fmod(t, cycle)
	var round_number: = floori(t / cycle)

	var angle: = (_roll(spot.key, round_number) - 0.5) * 1.4
	var distance: = 8.0 + _roll(spot.key, round_number + 1) * 5.0
	var ring: = spot.b
	var floor_y: = spot.root.origin.y
	var outward: = spot.c.rotated(Vector3.UP, angle)
	var stand: = Vector3(ring.x, floor_y, ring.z) + outward * distance
	var root: = _facing(stand, Vector3(ring.x, floor_y, ring.z))
	var s: = spot.scale
	if into < 2.6:
		var bounce: = absf(sin(PI * into / 0.5))
		var hand: = _figure(spot.pieces, root, 0.12, 0.3, 0.55 + 0.35 * bounce, 0.15, -0.15, 0.0, alpha)
		var ball: = Vector3(hand.x, floor_y + 0.45 + (hand.y - floor_y - 0.6) * bounce, hand.z)
		_ball(ball, 0.85, Color(BALL, alpha))
		_bounce(spot, ball, round_number * 10 + floori(into / 0.5 + 0.5))
	elif into < 3.1:
		var jump: = sin(PI * (into - 2.6) / 0.5)
		var up: = root
		up.origin.y += 1.6 * jump
		_figure(spot.pieces, up, 0.0, 2.8, 2.9, 0.2 * jump, 0.2 * jump, 0.0, alpha)
		_ball(up * Vector3(0, 6.3 * s, -0.6), 0.85, Color(BALL, alpha))
	else:
		_figure(spot.pieces, root, 0.0, 0.3, 0.3 + 0.6 * _every(into - 3.1, 10.0, 1.0), 0.0, 0.0, 0.0, alpha)
		var release: = root * Vector3(0, 6.3 * s + 1.6, -0.6)
		var ball: Vector3
		if into < 4.2:
			var u: = (into - 3.1) / 1.1
			ball = release.lerp(ring + Vector3(0, 0.6, 0), u)
			ball.y += sin(PI * u) * 5.0
		elif into < 4.7:
			var u: = (into - 4.2) / 0.5
			ball = ring.lerp(Vector3(ring.x, floor_y + 0.45, ring.z), u * u)
			if u > 0.92:
				_bounce(spot, ball, round_number * 10 + 9)
		else:
			var u: = (into - 4.7) / (cycle - 4.7)
			ball = Vector3(ring.x, floor_y + 0.45, ring.z).lerp(Vector3(stand.x, floor_y + 0.45, stand.z), u)
			ball.y += absf(sin(PI * u * 3.0)) * 2.0 * (1.0 - u)
		_ball(ball, 0.85, Color(BALL, alpha))



func _dog(spot: Spot, t: float, alpha: float) -> void :
	var root: = spot.root
	var size: = 0.8 + float(spot.key % 4) * 0.12
	var coat: Color = DOG_COATS[spot.key % DOG_COATS.size()]
	coat.a = alpha
	var dark: = coat.darkened(0.35)
	var middle: = root * Vector3(0, 0.62 * size, 0)
	_box(Transform3D(root.basis * Basis.from_scale(Vector3(0.95, 0.8, 2.1) * size), middle), coat)
	var look: = sin(t * 0.37 + spot.key) * 0.7
	var player: = Game.nearest_player(root.origin)
	if not player.is_empty() and player[1] < 30.0:
		var toward: Vector3 = root.basis.inverse() * (player[0].global_position - root.origin)
		look = clampf(atan2( - toward.x, - toward.z), -1.2, 1.2)
	var nod: = root.basis * Basis(Vector3.UP, look)
	var head: = middle + root.basis * Vector3(0, 0.5 * size, -1.05 * size)
	_box(Transform3D(nod * Basis.from_scale(Vector3(0.78, 0.72, 0.85) * size), head), coat)
	_box(Transform3D(nod * Basis.from_scale(Vector3(0.46, 0.4, 0.55) * size), head + nod * (Vector3(0, -0.12, -0.62) * size)), dark)
	for x: float in [-0.28, 0.28]:
		_box(Transform3D(nod * Basis.from_scale(Vector3(0.18, 0.42, 0.22) * size), head + nod * (Vector3(x, 0.45, 0.1) * size)), dark)
	for corner: Vector3 in [Vector3(-0.32, 0, -1.4), Vector3(0.32, 0, -1.4), Vector3(-0.38, 0, 1.0), Vector3(0.38, 0, 1.0)]:
		_box(Transform3D(root.basis * Basis.from_scale(Vector3(0.28, 0.26, 1.0) * size), root * (corner * size + Vector3(0, 0.14, 0))), coat)
	var wag: = Basis(Vector3.UP, sin(t * 4.0 + spot.key) * 0.6)
	var tail: = root.basis * wag * Basis(Vector3.RIGHT, 0.15)
	_box(Transform3D(tail * Basis.from_scale(Vector3(0.16, 0.16, 0.9) * size), middle + root.basis * Vector3(0, 0.05, 1.05 * size) + tail * Vector3(0, 0, 0.45 * size)), coat)






func _clink(eye: Vector3) -> void :
	if randf() >= CLINK_CHANCE * 3.0:
		return
	var heard: Array = []
	for spot: Spot in spots:
		if (spot.kind == CAFE or spot.kind == GARDEN) and spot.alpha > 0.9 and spot.b.distance_to(eye) < CLINK_REACH:
			heard.append(spot)
	if heard.is_empty():
		return
	var spot: Spot = heard[randi() % heard.size()]
	var morning: = Sky3D.current != null and Sky3D.current.hour < 12.0
	_played += 1
	Sounds.once_at(spot.b, "clink_cup" if morning else "clink_glass", 0.35, 6.0, CLINK_REACH, randf_range(0.9, 1.12))



func _bounce(spot: Spot, at: Vector3, count: int) -> void :
	if _bounced.get(spot, -1) != count:
		_bounced[spot] = count
		if at.distance_to(_eye) < BOUNCE_REACH:
			_played += 1
			Sounds.once_at(at, "ball_bounce", 0.5, 8.0, BOUNCE_REACH, randf_range(0.95, 1.05))






func _place_smoke(eye: Vector3) -> void :
	var lit: Array = []
	for spot: Spot in spots:
		if spot.kind == GRILL and spot.seed != 0 and spot.near and spot.b.distance_to(eye) < 160.0:
			lit.append(spot)
	lit.sort_custom( func(one: Spot, two: Spot) -> bool: return one.b.distance_to(eye) < two.b.distance_to(eye))
	while _smokes.size() < mini(lit.size(), SMOKES):
		_smokes.append(_make_smoke())
	for i in _smokes.size():
		var smoke: GPUParticles3D = _smokes[i]
		smoke.emitting = i < lit.size()
		if i < lit.size():
			smoke.global_position = lit[i].b + Vector3(0, 3.6, 0)


func _make_smoke() -> GPUParticles3D:
	if _smoke_material == null:
		_smoke_material = ParticleProcessMaterial.new()
		_smoke_material.direction = Vector3(0, 1, 0)
		_smoke_material.spread = 12.0
		_smoke_material.initial_velocity_min = 1.2
		_smoke_material.initial_velocity_max = 2.2
		_smoke_material.gravity = Vector3(0.5, 0.35, 0.2)
		_smoke_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
		_smoke_material.emission_sphere_radius = 0.5
		var grow: = Curve.new()
		grow.add_point(Vector2(0, 0.6))
		grow.add_point(Vector2(1, 3.2))
		var grow_texture: = CurveTexture.new()
		grow_texture.curve = grow
		_smoke_material.scale_curve = grow_texture
		var fade: = Gradient.new()
		fade.set_color(0, Color(0.78, 0.78, 0.8, 0.0))
		fade.set_color(1, Color(0.85, 0.85, 0.88, 0.0))
		fade.add_point(0.15, Color(0.7, 0.7, 0.72, 0.42))
		var fade_texture: = GradientTexture1D.new()
		fade_texture.gradient = fade
		_smoke_material.color_ramp = fade_texture
		var puff: = QuadMesh.new()
		puff.size = Vector2(1.6, 1.6)
		var look: = StandardMaterial3D.new()
		look.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		look.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		look.vertex_color_use_as_albedo = true
		look.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
		var soft: = GradientTexture2D.new()
		soft.fill = GradientTexture2D.FILL_RADIAL
		soft.fill_from = Vector2(0.5, 0.5)
		soft.fill_to = Vector2(1.0, 0.5)
		var edge: = Gradient.new()
		edge.set_color(0, Color(1, 1, 1, 1))
		edge.set_color(1, Color(1, 1, 1, 0))
		soft.gradient = edge
		look.albedo_texture = soft
		puff.material = look
		_smoke_draw = puff
	var smoke: = GPUParticles3D.new()
	smoke.amount = 14
	smoke.lifetime = 4.5
	smoke.process_material = _smoke_material
	smoke.draw_pass_1 = _smoke_draw
	smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	smoke.visibility_aabb = AABB(Vector3(-8, -2, -8), Vector3(16, 20, 16))
	add_child(smoke)
	return smoke
