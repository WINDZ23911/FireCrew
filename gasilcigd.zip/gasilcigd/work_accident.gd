class_name WorkAccident
extends Node
















const TICK: = 0.25
const SHOCK: = 30.0
const ISOLATOR_LIFT: = 1.6
const VALVE_LIFT: = 1.5
const SHOCK_AGAIN: = 2.0
const MACHINES: = [
	{"plot": "Metalworks", "machine": "Press", "tool": "Spreader", "title": "press", "isolate": "switch", "air": true}, 
	{"plot": "Sawmill", "machine": "Saw line", "tool": "Cutter", "title": "saw", "isolate": "main", "air": true}, 
	{"plot": "Warehouse", "machine": "Forklift", "tool": "Spreader", "title": "forklift", "isolate": "battery", "air": false}, 
]

static var current: WorkAccident

var kind: = "accident"
var _sites: Array = []
var _call: Dictionary = {}
var forced_site: = ""
var _free_prompt: Prompt
var _isolate_prompt: Prompt
var _air_prompt: Prompt
var _made: Dictionary = {}
var _shocked_at: Dictionary = {}
var _mirrored: = false


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Incidents.Accident


func _ready() -> void :
	Net.share("accident", _net_state, _net_apply, 2.0)

	Net.stopped.connect( func() -> void :
		if _mirrored:
			_mirrored = false
			_call = {}
			_drop())


func start() -> void :
	for entry: Dictionary in MACHINES:
		var house: House = IndustryZone.houses.get(entry["plot"])
		if house == null:
			continue
		for node: Dictionary in house.fuel:
			if node["name"] == entry["machine"]:
				_sites.append({"house": house, "machine": node, "tool": entry["tool"], "title": entry["title"], "isolate": entry["isolate"], "air": entry["air"]})
				break

	if ToolService.current != null:
		var before: Callable = ToolService.current.hydraulic
		ToolService.current.hydraulic = func(player: Player, tool: String, at: Vector3, look: Vector3, dt: float) -> Array:
			var result: = work(player, tool, at, look, dt)
			if result[0] or _call.has("site"):
				return result
			return before.call(player, tool, at, look, dt) if before.is_valid() else [false]


func available() -> bool:
	if _sites.is_empty() or VictimService.current == null or ToolService.current == null:
		return false
	for site: Dictionary in _sites:
		if not (site["house"] as House).ruined:
			return true
	return false


func _level() -> int:
	return clampi(Alarm.level, 1, 3)



func _seat(site: Dictionary) -> Transform3D:
	var house: House = site["house"]
	var machine: Vector3 = site["machine"]["position"]
	var room: Variant = house.rooms.get(site["machine"]["room"])
	var middle: Vector3 = room["smoke_position"] if room != null else house.position
	var toward: = Vector3(middle.x - machine.x, 0, middle.z - machine.z).normalized()
	if toward == Vector3.ZERO:
		toward = Vector3.FORWARD
	var floor_y: float = house.lot.origin.y + 0.6
	if room != null:
		floor_y = (house.lot * Vector3(0, (room["low"] as Vector3).y, 0)).y
	var at: = Vector3(machine.x, floor_y, machine.z) + toward * 4.0
	return Transform3D(Basis.looking_at( - toward, Vector3.UP), at)




func _beside(floor_at: Vector3, seat: Transform3D, side: float, taken: Array) -> Vector3:
	for reach: float in [3.5, 5.0, 2.5, 6.5]:
		for way: float in [side, - side]:
			var at: = floor_at + seat.basis.x * way * reach
			var free: = true
			for other: Vector3 in taken:
				free = free and Vector2(other.x - at.x, other.z - at.z).length() > 2.0
			if free and CallKit.box_clear(Transform3D(Basis.IDENTITY, at + Vector3(0, 1.4, 0)), Vector3(1.6, 2.2, 1.6)):
				return at
	return floor_at + seat.basis.x * side * 3.5



static func _facing(at: Vector3, toward: Vector3) -> Basis:
	var way: = Vector3(toward.x - at.x, 0, toward.z - at.z)
	return Basis.looking_at(way.normalized(), Vector3.UP) if way.length() > 0.1 else Basis.IDENTITY



static func jobs_of(title: String) -> Array:
	var table: Dictionary = settings()["Jobs"]
	return table.get(title, ["Spreader"])


func run() -> bool:
	if Net.is_client():
		return false
	var open: Array = []
	for site: Dictionary in _sites:
		if not (site["house"] as House).ruined:
			open.append(site)
	if open.is_empty():
		return false
	var site: Dictionary = open[randi() % open.size()]
	for candidate: Dictionary in open:
		if candidate["title"] == forced_site:
			site = candidate
	var house: House = site["house"]
	house.ruined = true
	var accident: Dictionary = settings()
	var people: = VictimService.current
	var seat: = _seat(site)
	var seats: Array = [seat]
	if _level() >= 3:
		var aside: = seat.origin + seat.basis.x * 7.0 + seat.basis.z * 3.0
		seats.append({"lying": Figure.lying(aside, seat.basis.x)})
	var victims: = people.begin_at(house, seats, 100.0 / float(accident["TrappedTime"]))
	if victims.is_empty():
		house.ruined = false
		people.finish()
		return false
	var machine: Vector3 = site["machine"]["position"]
	var away: = (machine - seat.origin) * Vector3(1, 0, 1)
	away = away.normalized() if away.length() > 0.1 else Vector3.FORWARD
	var floor_at: = Vector3(machine.x, seat.origin.y, machine.z)
	_call = {
		"site": site, "live": true, "freed": false, "contributors": {}, "machine": machine, "title": site["title"], 
		"isolate": site["isolate"], "air": site["air"] and Alarm.complicated("accident", "air"), "bled": false, 
		"jobs": jobs_of(site["title"]), "stage": 0, "progress": 0.0, 


		"work_at": seat.origin + Vector3(0, 1.2, 0) - away * 0.5, 
		"isolate_at": _beside(floor_at, seat, 1.0, []) + Vector3(0, ISOLATOR_LIFT, 0), 
		"air_at": Vector3.ZERO, 
		"foreman": _foreman_place(house), "told_live": false, 
	}
	_call["air_at"] = _beside(floor_at, seat, -1.0, [_call["isolate_at"]]) + Vector3(0, VALVE_LIFT, 0)
	var call_name: = Text.join([Text.m("calls.accident.titles." + site["title"]), Text.m("calls.separator"), CallKit.building_name(house)])
	var marker: = CallMarker.make(house.position + Vector3(0, house.height / 2.0 + 10.0, 0), Text.m("calls.markers.medical"), Color8(200, 50, 60))
	CallService.current.publish("accident", call_name, house.position, 3)
	Alarm.par(float(Alarm.settings()["Grade"]["Job"]["accident"]["Base"]))
	if house.approach != null:
		Game.incident["approach"] = house.approach
	Game.incident.merge(people.shown(), true)
	Game.notify(Text.f("calls.accident.alarm", [call_name]), "danger")
	Game.notify(Text.m("calls.accident.briefIsolate." + site["isolate"]), "warning")
	if _call["air"]:
		Game.notify(Text.m("calls.accident.air.told"), "warning")
	Escalation.begin_other(["second"])
	var control: = house.fit_control("calls.accident.switch", 2.0, Color8(200, 40, 34), false, func(player: Player) -> void :
		if _call.is_empty():
			return
		_call["contributors"][player] = true
		if _call["isolate"] == "main":
			_isolated(player)
		else:

			Game.notify(Text.m("calls.accident.notMain." + _call["isolate"]), "warning", player)
	)

	var flames: Array = []
	if _level() >= 2:
		for offset: Vector3 in [Vector3(1.5, 0, 1.0), Vector3(-1.5, 0, -1.0)]:
			flames.append(FireService.current.spot(Vector3(machine.x, seat.origin.y + 0.8, machine.z) + offset))
		Game.notify(Text.m("calls.accident.oilFire"), "danger")
	_call["flames"] = flames
	_build()

	var waited: = 0.0
	var searched: = {}
	while not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		people.step(TICK, FireService.current.smoke_at, false)

		if Escalation.due() == "second":
			people.add_one(searched)
		Game.incident.merge(people.shown(), true)

		if _call["live"] and not _call["told_live"]:
			for player in Game.players:
				if is_instance_valid(player) and player.brain == null and player.root_position().distance_to(_call["foreman"].origin) <= float(accident["ForemanReach"]):
					_call["told_live"] = true
					Game.notify(Text.m("calls.accident.foreman." + _call["isolate"]), "danger")
					break
		var done: = int( not _live()) + int(_call["freed"]) + int( not people.waiting())
		if done != int(Game.incident.get("done", 0)):
			CallService.current.progress(done)
		CallService.current.next_step(_next_step(people.waiting()))
		_show()
		if not people.waiting():
			break
	marker.queue_free()
	for made: Dictionary in flames:
		FireService.current.end_spot(made)
	if is_instance_valid(control):
		control.queue_free()
	var late: bool = CallService.current.overdue(waited)
	if not late and not people.waiting():
		Alarm.done()

	Alarm.check("isolated", not _call.get("shocked", false))
	var counts: = people.finish()
	var good: bool = not late and counts["lost"] == 0
	VictimService.tally(counts)
	if good:

		var reward: = int(accident["Reward"])
		var helpers: Dictionary = _call["contributors"].duplicate()
		helpers.merge(counts["rescuers"])
		CallKit.pay_helpers(helpers, reward, "bonus")
		Game.notify(Text.f("calls.accident.done", [call_name, Alarm.pay(reward)]), "good")
	else:
		Game.notify(Text.f("calls.accident.failed", [call_name]), "warning")
	Game.incident.merge(VictimService.card(counts), true)
	Game.incident.erase("next")
	Escalation.reset()
	await CallService.current.settle()
	CallService.current.clear( not good)
	_call = {}
	_drop()
	get_tree().create_timer(20.0, false).timeout.connect( func() -> void :
		house.restore()
		house.ruined = false
	)
	return true



func _live() -> bool:
	return _call.get("live", false) or (_call.get("air", false) and not _call.get("bled", false))



func _isolated(player: Player) -> void :
	if not _call["live"]:
		return
	_call["live"] = false
	_call["contributors"][player] = true
	Game.notify(Text.f("calls.accident.isolated", [player.display_name]), "good")
	if _call["air"] and not _call["bled"]:
		Game.notify(Text.m("calls.accident.air.still"), "warning")



static func _foreman_place(house: House) -> Transform3D:
	var door: Variant = house.outside_door()
	var at: = house.position
	var outward: = Vector3.FORWARD
	if door is Dictionary:
		var shut: Transform3D = door["shut"]
		outward = - shut.basis.z
		if outward.dot(shut.origin - house.position) < 0.0:
			outward = - outward
		outward = (outward * Vector3(1, 0, 1)).normalized()
		at = shut.origin + outward * 5.0 - shut.basis.x * 3.0

		return Figure.standing(CallKit.ground_at(at - Vector3(0, 3.5, 0)), outward)
	return Figure.standing(CallKit.ground_at(at + Vector3(0, 4, 0)), outward)



func _next_step(waiting: bool) -> Variant:
	if _burning():
		return Text.m("calls.accident.next.fire")
	if _call["live"]:
		return Text.m("calls.accident.next.isolate." + _call["isolate"])
	if _call["air"] and not _call["bled"]:
		return Text.m("calls.accident.next.air")
	if not _call["freed"]:
		var job: String = _call["jobs"][_call["stage"]]
		if job == "Crib":
			return Text.m("calls.accident.next.crib")
		return Text.f("calls.accident.next.tool", [Text.named("tools", job)])
	return Text.m("calls.accident.next.carry") if waiting else null


func _burning() -> bool:
	for made: Dictionary in _call.get("flames", []):
		if made["burning"]:
			return true
	return false





func work(player: Player, tool: String, at: Vector3, look: Vector3, dt: float) -> Array:
	if _call.is_empty() or not _call.has("site") or _call["freed"] or Net.is_client():
		return [false]
	var mark: Vector3 = _call["work_at"]
	var offset: = Vector3(mark.x - at.x, 0, mark.z - at.z)
	if offset.length() > float(settings()["Reach"]) or absf(mark.y - at.y) > 6.0 or (offset.length() > 2.5 and offset.normalized().dot(look) < 0.2):
		return [false]
	var now: = Game.now()
	if _burning():
		_hint(player, Text.m("calls.accident.fireFirst"))
		return [false]
	if _live():

		if now - float(_shocked_at.get(player, -100.0)) > SHOCK_AGAIN:
			_shocked_at[player] = now
			_call["shocked"] = true
			player.take_damage(SHOCK)
			Blast.at(_call["machine"] + Vector3(0, 2, 0), 3.0, 0.4, 2.2)
			Game.notify(Text.m("calls.accident.shock" if _call["live"] else "calls.accident.air.shot"), "danger", player)
			ToolService.current.deactivate(player)
		return [false]
	var job: String = _call["jobs"][_call["stage"]]
	if job != tool:
		_hint(player, Text.m("calls.accident.next.crib") if job == "Crib" else Text.f("calls.accident.needTool", [Text.named("tools", job)]))
		return [false]
	_call["progress"] = float(_call["progress"]) + dt
	_call["contributors"][player] = true
	var share: = minf(float(_call["progress"]) / float(settings()["JobTime"]), 1.0)
	if share >= 1.0:
		_job_done(player)
	return [true, share]


var _hinted: Dictionary = {}


func _hint(player: Player, text: Variant) -> void :
	var now: = Game.now()
	if now - float(_hinted.get(player, -100.0)) > 4.0:
		_hinted[player] = now
		Game.notify(text, "", player)



func _job_done(player: Player) -> void :
	_call["stage"] = int(_call["stage"]) + 1
	_call["progress"] = 0.0
	if int(_call["stage"]) < (_call["jobs"] as Array).size():
		Game.notify(Text.m("calls.accident.jobDone"), "", player)
		return
	_call["freed"] = true
	for victim: Victim in VictimService.current.victims:
		if victim.state == "trapped":
			VictimService.current.release(victim)
	Game.notify(Text.f("calls.accident.freed", [player.display_name]), "good")








func _build() -> void :
	_drop()
	var machine: Vector3 = _call["machine"]
	var holder: = Node3D.new()
	add_child(holder)
	_made["holder"] = holder

	var mark: = Node3D.new()
	holder.add_child(mark)
	mark.global_position = _call["work_at"]
	_made["bar"] = CallKit.bar(mark, 1.6, Color8(255, 190, 30), 60.0)
	_made["mark"] = mark
	var prompt: = CallKit.prompt(mark, "accident.free", Text.m("calls.accident.crib.action"), Text.m("calls.accident.free.object"), float(settings()["CribHold"]), 10.0)
	_free_prompt = prompt
	prompt.triggered.connect(_on_crib)

	if _call["isolate"] != "main":
		var box: = Node3D.new()
		holder.add_child(box)
		box.global_transform = Transform3D(_facing(_call["isolate_at"], _call["work_at"]), _call["isolate_at"])
		CallKit.piece(box, CallKit.BLOCK, Vector3(1.2, 1.4, 0.5), Transform3D.IDENTITY, CallFixture.GREY if _call["isolate"] == "switch" else Color8(40, 40, 44))
		CallKit.piece(box, CallKit.BLOCK, Vector3(0.5, 0.5, 0.2), Transform3D(Basis.IDENTITY, Vector3(0, 0, -0.35)), CallFixture.HANDLE)

		var post: = ISOLATOR_LIFT - 0.7
		CallKit.piece(box, CallKit.BLOCK, Vector3(0.24, post, 0.24), Transform3D(Basis.IDENTITY, Vector3(0, -0.7 - post / 2.0, 0.05)), Color8(60, 62, 66))
		CallKit.piece(box, CallKit.BLOCK, Vector3(0.7, 0.06, 0.6), Transform3D(Basis.IDENTITY, Vector3(0, 0.03 - ISOLATOR_LIFT, 0.05)), Color8(60, 62, 66))
		_made["isolate_beacon"] = CallFixture.mark(box, Vector3(0, 0.9, 0), Vector3(0, 0, -1), "switch")
		_made["isolate_box"] = box
		_isolate_prompt = CallKit.prompt(box, "accident.isolate", Text.m("calls.accident.isolate.%s.action" % _call["isolate"]), Text.m("calls.accident.isolate.%s.object" % _call["isolate"]), float(settings()["IsolateHold"]), 9.0)
		_isolate_prompt.triggered.connect( func(player: Player) -> void :
			if not _call.is_empty() and not Net.is_client():
				_isolated(player)
		)
	if _call["air"]:
		var valve: = Node3D.new()
		holder.add_child(valve)
		valve.global_transform = Transform3D(_facing(_call["air_at"], _call["work_at"]), _call["air_at"])
		CallKit.piece(valve, CallKit.CYLINDER, Vector3(1.2, 0.3, 0.3), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3.ZERO), Color8(40, 110, 200))

		CallKit.piece(valve, CallKit.CYLINDER, Vector3(VALVE_LIFT - 0.6, 0.22, 0.22), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(0, -0.3 - VALVE_LIFT / 2.0, 0)), Color8(40, 110, 200))

		CallKit.piece(valve, CallKit.CYLINDER, Vector3(0.12, 0.7, 0.7), Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(0, 0.7, 0)), Color8(40, 110, 200))
		_made["air_beacon"] = CallFixture.mark(valve, Vector3(0, 1.2, 0), Vector3(0, 0, -1), "valve")
		_made["air_valve"] = valve
		_air_prompt = CallKit.prompt(valve, "accident.air", Text.m("calls.accident.air.action"), Text.m("calls.accident.air.object"), float(settings()["IsolateHold"]), 9.0)
		_air_prompt.triggered.connect( func(player: Player) -> void :
			if _call.is_empty() or Net.is_client() or _call["bled"]:
				return
			_call["bled"] = true
			_call["contributors"][player] = true
			Game.notify(Text.m("calls.accident.air.bled"), "good", player)
		)

	var hum: = Node3D.new()
	holder.add_child(hum)
	hum.global_position = machine + Vector3(0, 2, 0)
	var stream: AudioStream = Sounds.loop(Config.Tools.Sounds.Fan)
	if stream != null:
		var sound: = Sounds.emitter(hum, stream, 0.7, 10.0, 90.0, true)
		sound.pitch_scale = 0.55
		_made["hum"] = sound

	var foreman: = Figure.build(absi(hash([_call["title"], "foreman"])) % 1000000 + 1)
	foreman.name = "Foreman"
	holder.add_child(foreman)
	foreman.pose("wave")
	foreman.global_transform = _call["foreman"]
	_show()


func _drop() -> void :
	if _made.has("holder") and is_instance_valid(_made["holder"]):
		_made["holder"].queue_free()
	_made = {}
	_free_prompt = null
	_isolate_prompt = null
	_air_prompt = null



func _show() -> void :
	if _made.is_empty() or _call.is_empty():
		return
	var free_job: bool = not _call["freed"] and not _live() and int(_call["stage"]) < (_call["jobs"] as Array).size()
	if is_instance_valid(_free_prompt):
		_free_prompt.enabled = free_job and _call["jobs"][_call["stage"]] == "Crib"
	if is_instance_valid(_isolate_prompt):
		_isolate_prompt.enabled = _call["live"]
		if not _call["live"]:
			CallFixture.done(_made["isolate_box"])
	if is_instance_valid(_air_prompt):
		_air_prompt.enabled = not _call["bled"]
		if _call["bled"]:
			CallFixture.done(_made["air_valve"])
	if _made.has("hum") and is_instance_valid(_made["hum"]):
		(_made["hum"] as AudioStreamPlayer3D).stream_paused = not _call["live"]
	if _made.has("bar") and is_instance_valid(_made["bar"]):
		var jobs: int = (_call["jobs"] as Array).size()
		CallKit.set_bar(_made["bar"], (float(_call["stage"]) + minf(float(_call["progress"]) / float(settings()["JobTime"]), 1.0)) / float(jobs))
		_made["bar"].visible = not _call["freed"]



func _on_crib(player: Player) -> void :
	if _call.is_empty() or _call["freed"] or Net.is_client():
		return
	if _burning():
		Game.tell(player, Text.m("calls.accident.fireFirst"))
		return
	if _live():
		Game.tell(player, Text.m("calls.accident.liveFirst"))
		return
	if _call["jobs"][_call["stage"]] != "Crib":
		return
	_call["contributors"][player] = true
	_job_done(player)





func _net_state() -> Variant:
	if _call.is_empty():
		return {}
	return {
		"machine": _call["machine"], "freed": _call["freed"], "title": _call["title"], "isolate": _call["isolate"], "air": _call["air"], 
		"bled": _call["bled"], "live": _call["live"], "jobs": _call["jobs"], "stage": _call["stage"], "progress": snappedf(float(_call["progress"]), 0.1), 
		"work_at": _call["work_at"], "isolate_at": _call["isolate_at"], "air_at": _call["air_at"], "foreman": _call["foreman"], 
	}


func _net_apply(state: Variant) -> void :
	if not Net.is_client():
		return
	if not state is Dictionary or (state as Dictionary).is_empty():
		if not _call.is_empty():
			_call = {}
			_drop()
		return
	_mirrored = true
	var fresh: = _call.is_empty() or not (_call["machine"] as Vector3).is_equal_approx(state["machine"])
	_call = (state as Dictionary).duplicate()
	if fresh:
		_build()
	_show()
