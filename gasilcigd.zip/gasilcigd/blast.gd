class_name Blast
extends RefCounted




const FIREBALL: = {
	"Color": [Color(1.0, 0.3, 0.01), Color(0.55, 0.02, 0.003)], "Speed": [10, 30], "Lifetime": [0.45, 0.9], 
	"SpreadAngle": 180, "Drag": 2.5, "Rotation": [0, 360], "Size": [[0.0, 3.0], [0.3, 6.5], [1.0, 0.0]], 
	"Sphere": 1.5, 
}
const SMOKE: = {
	"Color": Color(0.2, 0.19, 0.19), "Transparency": [[0.0, 0.0], [0.3, 1.0], [1.0, 1.0]], "Speed": [6, 18], 
	"Lifetime": [1.8, 3.2], "SpreadAngle": 180, "Rotation": [0, 360], "Drag": 1.5, 
	"Acceleration": Vector3(0, 6, 0), "Size": [[0.0, 2.0], [0.3, 6.0], [1.0, 0.0]], "Sphere": 2.0, 
}




static func at(position: Vector3, radius: float, volume: = 1.0, pitch: = 1.0) -> void :
	show(position, radius, volume, pitch)
	Net.broadcast("fx.blast", [position, radius, volume, pitch])


static func show(position: Vector3, radius: float, volume: = 1.0, pitch: = 1.0) -> void :
	var fireball: = FIREBALL.duplicate()
	fireball["Mesh"] = ToonFire.puff_mesh()
	fireball["Material"] = ToonFire.fireball_material()
	RbxEmitter.burst_at(position, fireball, 22)
	var smoke: = SMOKE.duplicate()
	smoke["Mesh"] = ToonFire.puff_mesh()
	smoke["Material"] = ToonFire.puff_material()
	RbxEmitter.burst_at(position, smoke, 16)
	Sounds.once_at(position, Config.Fire.Bottles.SoundId, volume, 40.0, 900.0, pitch)
	var flash: = OmniLight3D.new()
	flash.light_color = Color(1.0, 0.7, 0.35)
	flash.omni_range = radius * 2.5
	flash.light_energy = 40.0
	Game.world.add_child(flash)
	flash.global_position = position
	var fade: = flash.create_tween()
	fade.tween_property(flash, "light_energy", 0.0, 0.6)
	fade.tween_callback(flash.queue_free)
	for player in Game.players:
		if player.is_local and player.camera:
			var near: = clampf(1.0 - player.global_position.distance_to(position) / (radius * 4.0), 0.0, 1.0)
			player.camera.shake = maxf(player.camera.shake, near * 1.2)
