class_name PoliceOfficer
extends Node3D







const FACES: = ["face0", "face1", "face2", "face3"]

var _body: FirefighterRig
var _waving: = false


func _init(seed_number: int) -> void :
	name = "PoliceOfficer"
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_body = FirefighterRig.new()
	_body.with_kit = false
	_body.springs = false
	_body.outfit = {"police": true, FACES[posmod(seed_number, FACES.size())]: true}
	_body.pose = "looking_around"
	add_child(_body)



func wave(on: bool) -> void :
	if on == _waving:
		return
	_waving = on
	_body.pose = "waving" if on else "looking_around"
