extends ProofDebug





func _scenario_garagedump() -> void :
	await _wait(1.0)
	var station: = Game.station
	print("garagedump: front %.1f, door %s, bays %s" % [station.front, station.door_position, station.record["bays"]])
	for vehicle: Vehicle in Vehicle.all:
		if vehicle.spec.get("spawn") is Transform3D:
			print("garagedump: %s spawns at %s facing %s" % [vehicle.spec["name"], (vehicle.spec["spawn"] as Transform3D).origin, - (vehicle.spec["spawn"] as Transform3D).basis.z])
	var board: = TrainingBoard.current
	print("garagedump: the training board's prompt at %s" % board.board_position())
	for x in [-40.0, -20.0, 0.0, 20.0, 40.0, 60.0]:
		for z in [-98.0, -90.0, -75.0, -60.0]:
			var floor_hit: = Game.world.raycast(Vector3(x, 20, z), Vector3(x, -10, z), World.LAYER_SOLID)
			var wall_hit: = Game.world.raycast(Vector3(x, 5, z + 6.0), Vector3(x, 5, z - 6.0), World.LAYER_SOLID)
			print("garagedump: at x %.0f z %.0f floor %s (%s); wall toward -z %s" % [x, z, floor_hit.get("position", "none"), Game.world.name_hit(floor_hit) if not floor_hit.is_empty() else "-", (str(wall_hit["position"]) + " " + Game.world.name_hit(wall_hit)) if not wall_hit.is_empty() else "none"])

	_view(Vector3(28, 9, -70), Vector3(28, 6, -99))
	await _wait(0.5)
	await _snap("backwall")
	_view(Vector3(10, 7, -72), Vector3(40, 5, -99))
	await _wait(0.5)
	await _snap("backwall_side")
	var at: = board.board_position()
	_view(at + Vector3(0, 1, 8), at)
	await _wait(0.5)
	await _snap("old_board")
	await _done()


func _scenario_trainingtable() -> void :
	await _wait(1.0)
	var board: = TrainingBoard.current
	var at: = board.board_position()
	var station: = Game.station
	print("trainingtable: the table's prompt at %s; the pumper spawns at %s" % [at, Vehicle.named("Fire Truck").spec["spawn"].origin])
	_check(at != Vector3.INF and station.inside(at, 2.0), "the training table stands inside the station")
	_check(at.z < -90.0 and at.x > -56.0 and at.x < 14.0, "in the garage, at the back wall between the bays")
	var solid: = Game.world.raycast(at + Vector3(0, 2.5, 6.0), at + Vector3(0, 2.5, -6.0), World.LAYER_SOLID)
	_check( not solid.is_empty() and solid["position"].z > at.z - 1.0, "the bench is solid")

	_view(Vector3(-16, 6, -82), at + Vector3(0, 4, 0))
	await _wait(0.5)
	await _snap("from_bay")
	_view(at + Vector3(6, 5, 11), at + Vector3(0, 4.5, 0))
	await _wait(0.5)
	await _snap("table")

	player.teleport(at + Vector3(0, 0.3, 7.0))
	await _wait(0.4)
	_look_at(at + Vector3(0, 4, 0))
	await _wait(0.4)
	print("trainingtable: offered %s" % (Text.say(player.prompt.action, "en") + " · " + Text.say(player.prompt.object, "en") if player.prompt != null else "nothing"))
	_check(player.prompt != null and Text.say(player.prompt.action, "en") == Text.say(Text.m("training.action"), "en"), "E at the table offers the training")
	player.set_attr("Cash", 12000)
	board.open()
	await _wait(0.5)
	var cards: = board._rows.get_children().filter( func(node: Node) -> bool: return node is Button).size()
	print("trainingtable: the menu shows %d buttons (7 cards and close)" % cards)
	_check(board.is_open() and cards == Training.skills().size() + 1, "the menu shows a card for every skill, and close")
	_check(get_viewport().get_visible_rect().encloses(board._plate.get_global_rect()), "it fits the screen")
	await _snap("menu")
	board._choose("strength")
	await _wait(0.3)
	await _snap("menu_confirm")
	board.close()
	await _done()


func _scenario_wallscan() -> void :
	await _wait(1.0)
	var space: = get_tree().root.get_world_3d().direct_space_state
	var free: Array = []
	for x in range(-56, 16, 2):
		var query: = PhysicsShapeQueryParameters3D.new()
		var box: = BoxShape3D.new()
		box.size = Vector3(2.0, 9.0, 6.0)
		query.shape = box
		query.transform = Transform3D(Basis.IDENTITY, Vector3(x, 5.0, -95.8))
		query.collision_mask = World.LAYER_SOLID
		query.exclude = [TrainingBoard.current._board.find_children("*", "StaticBody3D", true, false)[0].get_rid()] if TrainingBoard.current._board else []
		var hits: = space.intersect_shape(query, 6)
		var names: Array = []
		for hit: Dictionary in hits:
			names.append(Game.world.name_hit(hit))
		print("wallscan: x %d: %s" % [x, "free" if hits.is_empty() else str(names)])
	await _done()


func _scenario_wallparts() -> void :
	await _wait(1.0)
	var store: = Game.store
	var by_x: Dictionary = {}
	for row in store.count:
		var at: = store.position(row)
		if at.z < -99.5 or at.z > -91.0 or at.y < 0.3 or at.y > 13.0 or at.x < -58.0 or at.x > 16.0:
			continue
		var name: = store.name_at(row)
		if name in ["GarageBack", "GarageFloor", "GarageBackTrim", "Skirting"]:
			continue
		var size: = store.size(row)
		var bucket: = int(floor(at.x / 4.0)) * 4
		if not by_x.has(bucket):
			by_x[bucket] = {}
		by_x[bucket][name] = "%s@y%.0f z%.0f w%.0f" % [name, at.y, at.z, maxf(size.x, size.z)]
	var keys: = by_x.keys()
	keys.sort()
	for key in keys:
		print("wallparts: x %d..%d: %s" % [key, key + 4, by_x[key].values()])
	await _done()
