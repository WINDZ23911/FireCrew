extends RefCounted



static func start(main: Node) -> void :
	var readiness: = Readiness.new()
	readiness.name = "Readiness"
	main.add_child(readiness)
