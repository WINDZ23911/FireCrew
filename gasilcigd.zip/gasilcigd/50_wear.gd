extends RefCounted














const BY_KIND: = {"house": [0.3, 0.7], "terrace": [0.55, 0.75], "apartments": [0.5, 0.7], "shop": [0.25, 0.45], "public": [0.3, 0.5], "outbuilding": [0.6, 0.9], "garages": [0.5, 0.7], "canopy": [0.3, 0.5]}
const BY_DISTRICT: = {"old_town": [0.75, 0.95], "edge": [0.6, 0.9], "renovated": [0.05, 0.15]}
const HANDS: = ["Door", "DoorFrame", "WingDoor", "GarageDoor", "DoorRib"]
const BUS_STOP: = 36.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var districts: Dictionary = kit.get_meta("districts", {})
	var layout: Array = kit.layout()["buildings"]
	var buildings: = 0
	var doors: = 0
	for shell: Dictionary in kit.get_meta("shells", []):
		var model: int = shell["model"]
		var place: Transform3D = shell["place"]
		var kind: = _kind(layout, Vector2(place.origin.x, place.origin.z))
		var span: Array = BY_DISTRICT.get(districts.get(model, ""), BY_KIND.get(kind, [0.3, 0.7]))
		var roll: = float(int(rand_from_seed(hash([int(place.origin.x), int(place.origin.z), "age"]))[0]) % 1000) / 1000.0
		var age: = lerpf(float(span[0]), float(span[1]), roll)
		for row in store.rows_in(model):
			if store.name_at(row) in HANDS:
				store.set_wear(row, PartStore.Wear.HANDS, age)
				doors += 1
			else:
				store.set_wear(row, PartStore.Wear.NONE, age)
		buildings += 1

	var station: = -1
	for id: int in store.nodes:
		if store.nodes[id]["c"] == "Model" and store.nodes[id]["n"] == "Fire Station":
			station = id
	ApronWear.bays.clear()
	if station >= 0:
		var pattern: = RegEx.create_from_string("^BayDoor(\\d)_1$")
		for row in store.rows_in(station):
			var part: = store.name_at(row)
			if part in HANDS:
				store.set_wear(row, PartStore.Wear.HANDS, 0.6)
				doors += 1
			elif pattern.search(part) != null:
				ApronWear.bays.append(store.transform(row))

	var stops: Array[Vector3] = []
	var kerbs: Array = []
	for row in kit.rows_under("Map/Surfaces"):
		match store.name_at(row):
			"paint_yellow":
				stops.append(store.position(row))
			"kerb", "kerbstone":
				kerbs.append(row)
	var scuffed: = 0
	for row: int in kerbs:
		var place: = store.transform(row).orthonormalized()
		var half: = store.size(row) / 2.0
		for stop: Vector3 in stops:

			var local: = place.affine_inverse() * Vector3(stop.x, place.origin.y, stop.z)
			var off: = Vector2(maxf(absf(local.x) - half.x, 0.0), maxf(absf(local.z) - half.z, 0.0))
			if off.length() < BUS_STOP * 0.5:
				store.set_wear(row, PartStore.Wear.KERB_SCUFF, 0.7)
				scuffed += 1
				break
	return "wear: %d buildings aged, %d doors and frames handled, %d kerbs scuffed by bus stops, %d bays' lanes" % [buildings, doors, scuffed, ApronWear.bays.size()]


static func _kind(layout: Array, spot: Vector2) -> String:
	var best: = "house"
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building["kind"]
	return best
