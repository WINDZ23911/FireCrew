extends RefCounted






const STEP: = 8.0
const WIDTH: = 1.1
const GRAVEL: = Color8(146, 138, 122)
const ROADS: = ["road", "lane"]


static func apply(kit: PolishKit) -> String:
	var parent: = kit.own_folder("Shoulders")
	var laid: = 0
	for road: Dictionary in kit.layout()["roads"]:
		var half: = float(road["width"]) / 2.0
		for spot: Array in PolishKit.along_road(road["points"], STEP, STEP / 2.0):
			var middle: Vector3 = spot[0]
			var way: Vector3 = spot[1]
			if not (kit.surface_at(middle) in ROADS):
				continue
			var top: = kit.surface_top(middle)
			var across: = Vector3( - way.z, 0, way.x)
			for side: float in [-1.0, 1.0]:


				if not (kit.surface_at(middle + across * side * (half - 0.6)) in ROADS):
					continue
				if not (kit.surface_at(middle + across * side * (half + 0.9)) in PolishKit.OPEN_GROUND):
					continue
				if kit.surface_at(middle + across * side * (half + 2.5)) == "pavement":
					continue
				var centre: = middle + across * side * (half + WIDTH / 2.0 - 0.08)
				var place: = PolishKit.facing(Vector3(centre.x, top - 0.06, centre.z), way)
				kit.box(parent, place, Vector3(WIDTH, 0.12, STEP + 0.5), GRAVEL, "Concrete", "shoulder")
				laid += 1
	return "shoulders: %d strips of gravel where roads meet open ground" % laid
