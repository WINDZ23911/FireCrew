class_name GearDebug
extends Node


























var _watch_back: = false


func _ready() -> void :
	_run.call_deferred()


static func _value(flag: String) -> Variant:
	for arg in OS.get_cmdline_user_args():
		if arg == flag:
			return ""
		if arg.begins_with(flag + "="):
			return arg.substr(flag.length() + 1)
	return null


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds).timeout


func _run() -> void :
	var player: = Game.local_player
	var gear: = GearService.current
	var air: = AirService.current
	var tools: = ToolService.current
	if player == null:
		return
	if _value("--cash") != null:
		player.set_attr("Cash", int(_value("--cash")))
	if _value("--saved") != null:
		player.set_attr("Saved", int(_value("--saved")))
	if _value("--net-watch") != null:
		_watch_back = _value("--net-watch") == "back"
		_watch_other()
	if _value("--net-gear") != null:
		_net_gear(String(_value("--net-gear")).split(","))
	await _wait(0.2)

	var suit: Variant = _value("--suit")
	var helmet: Variant = _value("--helmet")
	if suit != null or helmet != null:

		var picked: Variant = player.get_attr("Helmet")
		var owned: bool = helmet != null and PlayerData.owns(player, helmet)
		if helmet != null:
			player.attributes["Owns_" + helmet] = true
			player.attributes["Helmet"] = helmet
		if gear.is_geared(player):
			gear._change_back(player, true)
		gear._gear_up(player, suit if (suit != null and not String(suit).is_empty()) else null, true)
		if helmet != null:
			if not owned:
				player.attributes.erase("Owns_" + helmet)
			if picked == null:
				player.attributes.erase("Helmet")
			else:
				player.attributes["Helmet"] = picked
	if _value("--soot") != null:
		gear.add_soot(player, float(_value("--soot")))
	if _value("--lamp") != null:
		gear.toggle_lamp(player)
	if _value("--visor-up") != null:
		gear.toggle_visor(player)
	if _value("--scba") != null or _value("--mask") != null:
		air.take_set(player, "rack")
		if _value("--air") != null and air.sets.has(player):
			air.sets[player]["bar"] = float(_value("--air"))
			player.set_attr("AirBar", ceili(float(_value("--air"))))
		if _value("--mask") != null:
			air.move_mask(player)

	var wanted: Variant = _value("--tool")
	if wanted != null:
		for tool_name: String in String(wanted).split(","):
			for item: Dictionary in tools.items:
				if item["name"] == tool_name and item["tool"] == null:
					tools._on_line(player, item)
					break
	if _value("--turn") != null:
		player.rig.rotation.y = deg_to_rad(float(_value("--turn")))
	if _value("--first") != null:
		player.camera.wanted_distance = 0.0
		player.camera.distance = 0.0

	var late: Variant = _value("--late-tool")
	if late != null:
		await _wait(float(_value("--late-after")) if _value("--late-after") != null else 4.0)
		Input.action_release("fire")
		var line: Variant = HoseService.current.line_of(player)
		if line != null:
			HoseService.current.disconnect_line(line)
		for item: Dictionary in tools.items:
			if item["name"] == late and item["tool"] == null:
				tools._on_line(player, item)
				break

	if _value("--setdown") != null:
		await _wait(0.4)
		tools.activate(player)
	elif _value("--use") != null:
		await _wait(0.6)
		tools.activate(player)

		Input.action_press("fire")

	var locker: Variant = _value("--locker")
	if locker != null:
		var vehicle: = Vehicle.named(locker)
		var lockers: = Lockers.of(vehicle)
		var handle: Dictionary = lockers.handles[0]
		var node: Node3D = handle["node"]
		var out: = (node.global_position - vehicle.global_position)
		out.y = 0
		player.teleport(node.global_position + out.normalized() * 5.0 - Vector3(0, node.global_position.y - vehicle.global_position.y + 2.6, 0))
		player.camera.yaw = atan2(out.x, out.z)
		if _value("--shut") == null:
			lockers.set_open(handle, true)
			await _wait(1.2)
			lockers.menu_wanted.emit(player, handle)

	var wardrobe: Variant = _value("--wardrobe")
	if wardrobe != null:
		var stall: Dictionary = gear.stalls[0]
		player.teleport(stall["position"] + Vector3(5, -4.2, 0))
		player.camera.yaw = - PI / 2
		await _wait(0.3)
		if gear.is_geared(player):
			gear._change_back(player, true)
		gear._choosing[player] = stall
		gear.choosing_began.emit(player, stall)
		if wardrobe == "helmets":
			var menu: WardrobeMenu = Hud.current.widgets["wardrobe"]
			menu._page = "helmets"
			menu._draw_page()


	var pick: Variant = _value("--pick")
	if pick != null:
		await _wait(0.5)
		for key: String in ["wardrobe", "locker"]:
			var menu: Variant = Hud.current.widgets[key]
			if menu.is_open() and int(pick) <= menu._choices.size():
				menu._choices[int(pick) - 1].call()
		print("gear debug: geared ", player.get_attr("Geared"), " tool ", player.get_attr("Tool"), " ui ", Game.ui_open)


	var take: Variant = _value("--take")
	if take != null and locker != null:
		var lockers: = Lockers.of(Vehicle.named(locker))
		var handle: Dictionary = lockers.handles[0]
		Hud.current.widgets["locker"].close()
		for line in lockers.lines:
			if Text.say(line.object, "en") == take:
				lockers.use(player, handle, line)
		print("gear debug: took ", player.get_attr("Tool"), " carried ", tools.carried(player).size(), " forces ", player.get_attr("ToolForces"), " speed ", player.walk_speed)
		if _value("--return-all") != null:
			lockers.use(player, handle, "all")
			print("gear debug: after return ", tools.carried(player).size(), " ", player.get_attr("Tool"), " holding '", player.holding, "'")
	if _value("--die") != null:
		await _wait(0.3)
		player.take_damage(1000.0)
		await _wait(0.3)
		print("gear debug: after death geared ", player.get_attr("Geared"), " scba ", player.get_attr("Scba"), " carried ", tools.carried(player).size(), " health ", player.health)





func _other() -> Player:
	for peer: int in Net.players:
		var other: Player = Net.players[peer]
		if other != Game.local_player and is_instance_valid(other):
			return other
	return null



func _watch_other() -> void :
	var camera: = Camera3D.new()
	camera.fov = 40.0
	camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	add_child(camera)
	while is_inside_tree():
		await get_tree().process_frame
		var other: = _other()
		if other == null:
			continue
		var facing: = other.facing() * (-1.0 if _watch_back else 1.0)
		var side: = facing.cross(Vector3.UP).normalized()
		camera.look_at_from_position(other.global_position + facing * 11.0 + side * 3.0 + Vector3(0, 4.6, 0), other.global_position + Vector3(0, 3.4, 0))
		camera.make_current()



func _use_prompt(prompt: Prompt, stand: Vector3) -> void :
	var player: = Game.local_player
	player.teleport(stand)
	await _wait(0.5)
	player._fire_prompt(prompt, "tap")
	await _wait(0.4)


func _net_gear(steps: PackedStringArray) -> void :
	var player: = Game.local_player
	var gear: = GearService.current
	var air: = AirService.current
	while Net.players.size() < 2:
		await _wait(0.2)
	await _wait(1.5)
	for step: String in steps:
		var what: = step.get_slice("=", 0)
		var value: = step.get_slice("=", 1) if step.contains("=") else ""
		match what:
			"at":
				var n: = value.split_floats(":")
				player.teleport(Vector3(n[0], n[1], n[2]))
			"meet":
				var other: = _other()
				if other != null:
					player.teleport(other.global_position + other.facing() * 7.0)
					player.rig.rotation.y = other.rig.rotation.y + PI
			"home":

				player.teleport(Game.spawn_point() + Vector3(float(value) if not value.is_empty() else 5.0, 0, 0))
				player.rig.rotation.y = PI
			"turn":
				player.rig.rotation.y = deg_to_rad(float(value))
			"rack":
				await _use_prompt(air.rack_prompt, air.rack_prompt.global_transform * Vector3(0, -3.2, 5.2))
			"compressor":
				player.teleport(air._compressor_at + Vector3(0, -2.0, 4.0))
				await _wait(0.5)
				for id: String in Prompt.by_id:
					var prompt: Prompt = Prompt.by_id[id]
					if is_instance_valid(prompt) and prompt.global_position.distance_to(air._compressor_at) < 3.0:
						player._fire_prompt(prompt, "tap")
			"stall":
				var stall: Dictionary = gear.stalls[int(value) if not value.is_empty() else 0]
				var back: Node3D = stall["back"]
				await _use_prompt(stall["prompt"], back.global_transform * Vector3(0, -4.4, 4.0))
			"suit":
				Net.request("gear.suit", [value])
			"helmet":
				Net.request("gear.helmet", [value])
			"mask":
				Net.request("air.mask")
				await _wait(1.6)
			"lamp":
				Net.request("gear.lamp")
			"visor":
				Net.request("gear.visor")
			"hour":
				Sky3D.current.set_hour(float(value))
			"soot":
				gear.add_soot(player, float(value))
			"air":
				if air.sets.has(player):
					air.sets[player]["bar"] = float(value)
					player.set_attr("AirBar", ceili(float(value)))
			"their-air":
				var wearer: = _other()
				if wearer != null and air.sets.has(wearer):
					air.sets[wearer]["bar"] = float(value)
					wearer.set_attr("AirBar", ceili(float(value)))
			"smoke":

				var other: = _other()
				if other != null and not Flame.all.is_empty():
					Net.teleport(other, Flame.all[Flame.all.size() - 1].global_position + Vector3(3, 0, 0))
					await _wait(1.0)
					print("net gear [host] smoke where %s stands: %.2f at %s" % [other.name, FireService.current.smoke_at(other.root_position()), other.root_position()])
			"watch":
				_watch_back = value == "back"
			"until":

				var bits: = value.split(":")
				for attempt in 100:
					var other: = _other()
					if other != null and str(other.get_attr(bits[0])) == bits[1]:
						break
					await _wait(0.2)
			"mine":

				var bits: = value.split(":")
				for attempt in 200:
					if str(player.get_attr(bits[0])) == bits[1]:
						print("net gear [%s] own %s is %s (health %d)" % ["host" if Net.is_host() else "client", bits[0], bits[1], player.health])
						break
					await _wait(0.1)
			"wait":
				await _wait(float(value))
			"shot":
				await RenderingServer.frame_post_draw
				get_viewport().get_texture().get_image().save_png(value)
			"quit":
				Game.quit()
			"print":
				for peer: int in Net.players:
					var one: Player = Net.players[peer]
					if air._looks.has(one):
						var light: StandardMaterial3D = air._looks[one]["light"].material_override
						print("net gear [%s] %s: buddy light %s, breathing %s, whistle %s, alarm %s, lamp beam %s" % ["host" if Net.is_host() else "client", one.name, light.albedo_color.to_html(false), air._looks[one]["breathing"].playing, air._looks[one]["whistle"].playing, air._looks[one]["distress"].playing, gear._looks[one]["lamp"].visible])
					var shown: Array = one.rig.shown_sheets()
					shown.sort()
					print("net gear [%s] %s: health %d speed %s board '%s'" % ["host" if Net.is_host() else "client", one.name, one.health, one.walk_speed, air._board_rows[1].text if air._board_rows.size() > 1 else ""])
					print("net gear [%s] %s: geared %s scba %s mask %s bar %s lamp %s soot %s smoke %s cash %s owns %s sheets %s menu %s pool %s stalls %s" % [
						"host" if Net.is_host() else "client", one.name, one.get_attr("Geared"), one.get_attr("Scba"), one.get_attr("Mask"), 
						one.get_attr("AirBar"), one.get_attr("Lamp"), one.get_attr("Soot"), one.get_attr("Smoke"), one.get_attr("Cash"), 
						one.attributes.keys().filter( func(key: String) -> bool: return key.begins_with("Owns_")), shown, 
						Hud.current.widgets["wardrobe"].is_open(), air.pool, 
						gear.stalls.filter( func(stall: Dictionary) -> bool: return stall["display"] != null and not stall["display"].visible).size(), 
					])
		await _wait(0.5)
