class_name PartStore
extends RefCounted






const COLUMNS: = 26
const ID: = 0
const SHAPE: = 1
const POS: = 2
const ROT: = 5
const SIZE: = 14
const COLOR: = 17
const TRANSPARENCY: = 20
const MATERIAL: = 21
const FLAGS: = 22
const NAME: = 23
const PARENT: = 24
const REFLECTANCE: = 25

enum Shape{BLOCK, WEDGE, CYLINDER, BALL, CORNER_WEDGE, ELLIPSOID}



enum Wear{NONE, HANDS, KERB_SCUFF}
const WEAR: = 10.0
const COLLIDE: = 1
const QUERY: = 2
const SHADOW: = 4
const SPECIAL: = 8

var data: = PackedFloat32Array()
var count: = 0
var names: Array = []
var materials: Array = []
var nodes: Dictionary = {}
var meta: Dictionary = {}
var row_of: Dictionary = {}
var rows_under: Dictionary = {}
var nodes_under: Dictionary = {}
var tagged: Dictionary = {}
var _name_index: Dictionary = {}
var _material_index: Dictionary = {}
var _next_id: = 1
var exported: = 0


func load_world() -> void :
	data = FileAccess.get_file_as_bytes(Edition.path("world/parts.bin", "res://data/world/parts.bin")).to_float32_array()
	count = data.size() / COLUMNS
	exported = count
	var world: Dictionary = Rbx.load_json(Edition.path("world/world.json", "res://data/world/world.json"))
	names = world["names"]
	materials = world["materials"]
	for index in names.size():
		_name_index[names[index]] = index
	for index in materials.size():
		_material_index[materials[index]] = index
	for key in world["part_meta"]:
		var id: = int(key)
		meta[id] = world["part_meta"][key]
		for tag in meta[id]["t"]:
			_tag(tag, id)
	for row in count:
		var id: = int(data[row * COLUMNS + ID])
		row_of[id] = row
		_under(rows_under, int(data[row * COLUMNS + PARENT]), row)
		_next_id = maxi(_next_id, id + 1)
	for node: Dictionary in world["nodes"]:
		var id: = int(node["i"])
		node["i"] = id
		node["p"] = int(node["p"])
		if node.has("v"):
			node["v"] = Rbx.decode(node["v"])
		nodes[id] = node
		_under(nodes_under, node["p"], id)
		for tag in node.get("t", []):
			_tag(tag, id)
		_next_id = maxi(_next_id, id + 1)


func _under(table: Dictionary, parent: int, value: int) -> void :
	if not table.has(parent):
		table[parent] = PackedInt32Array()
	table[parent].append(value)


func _tag(tag: String, id: int) -> void :
	if not tagged.has(tag):
		tagged[tag] = PackedInt32Array()
	tagged[tag].append(id)


func new_id() -> int:
	_next_id += 1
	return _next_id - 1



func add_node(parent: int, node_class: String, node_name: String, props: = {}) -> int:
	var id: = new_id()
	nodes[id] = {"i": id, "p": parent, "c": node_class, "n": node_name, "v": props}
	_under(nodes_under, parent, id)
	return id



func add(shape: int, place: Transform3D, size: Vector3, color: Color, material: String, part_name: String, parent: int, flags: = COLLIDE | QUERY | SHADOW, transparency: = 0.0) -> int:
	var id: = new_id()
	var b: = place.basis
	var o: = place.origin
	if not _material_index.has(material):
		_material_index[material] = materials.size()
		materials.append(material)
	if not _name_index.has(part_name):
		_name_index[part_name] = names.size()
		names.append(part_name)
	data.append_array(PackedFloat32Array([
		id, shape, o.x, o.y, o.z, 
		b.x.x, b.y.x, b.z.x, b.x.y, b.y.y, b.z.y, b.x.z, b.y.z, b.z.z, 
		size.x, size.y, size.z, color.r, color.g, color.b, 
		transparency, _material_index[material], flags, _name_index[part_name], parent, 0.0, 
	]))
	row_of[id] = count
	_under(rows_under, parent, count)
	count += 1
	return id


func id_at(row: int) -> int:
	return int(data[row * COLUMNS + ID])


func shape(row: int) -> int:
	return int(data[row * COLUMNS + SHAPE])


func position(row: int) -> Vector3:
	var at: = row * COLUMNS + POS
	return Vector3(data[at], data[at + 1], data[at + 2])


func basis(row: int) -> Basis:
	var at: = row * COLUMNS + ROT
	return Basis(
		Vector3(data[at], data[at + 3], data[at + 6]), 
		Vector3(data[at + 1], data[at + 4], data[at + 7]), 
		Vector3(data[at + 2], data[at + 5], data[at + 8])
	)


func transform(row: int) -> Transform3D:
	return Transform3D(basis(row), position(row))


func size(row: int) -> Vector3:
	var at: = row * COLUMNS + SIZE
	return Vector3(data[at], data[at + 1], data[at + 2])


func color(row: int) -> Color:
	var at: = row * COLUMNS + COLOR
	return Color(data[at], data[at + 1], data[at + 2])


func transparency(row: int) -> float:
	return data[row * COLUMNS + TRANSPARENCY]


func material(row: int) -> String:
	return materials[int(data[row * COLUMNS + MATERIAL])]



func wear(row: int) -> float:
	var value: = data[row * COLUMNS + REFLECTANCE]
	return value - WEAR if value >= WEAR else 0.0


func set_wear(row: int, kind: int, age: float) -> void :
	data[row * COLUMNS + REFLECTANCE] = WEAR + kind + clampf(age, 0.01, 0.99)


func flags(row: int) -> int:
	return int(data[row * COLUMNS + FLAGS])


func name_at(row: int) -> String:
	return names[int(data[row * COLUMNS + NAME])]


func parent(row: int) -> int:
	return int(data[row * COLUMNS + PARENT])





func set_transform(row: int, place: Transform3D) -> void :
	var at: = row * COLUMNS
	var b: = place.basis
	var o: = place.origin
	var values: = [o.x, o.y, o.z, b.x.x, b.y.x, b.z.x, b.x.y, b.y.y, b.z.y, b.x.z, b.y.z, b.z.z]
	for index in values.size():
		data[at + POS + index] = values[index]


func set_size(row: int, value: Vector3) -> void :
	var at: = row * COLUMNS + SIZE
	data[at] = value.x
	data[at + 1] = value.y
	data[at + 2] = value.z


func set_color(row: int, value: Color) -> void :
	var at: = row * COLUMNS + COLOR
	data[at] = value.r
	data[at + 1] = value.g
	data[at + 2] = value.b


func set_transparency(row: int, value: float) -> void :
	data[row * COLUMNS + TRANSPARENCY] = value


func set_flags(row: int, value: int) -> void :
	data[row * COLUMNS + FLAGS] = value


func set_material(row: int, material_name: String) -> void :
	if not _material_index.has(material_name):
		_material_index[material_name] = materials.size()
		materials.append(material_name)
	data[row * COLUMNS + MATERIAL] = _material_index[material_name]



func rows_named(part_name: String) -> PackedInt32Array:
	var found: = PackedInt32Array()
	var wanted: int = _name_index.get(part_name, -1)
	if wanted < 0:
		return found
	for row in count:
		if int(data[row * COLUMNS + NAME]) == wanted:
			found.append(row)
	return found


func attribute(id: int, key: String, default: Variant = null) -> Variant:
	if meta.has(id):
		return meta[id]["a"].get(key, default)
	if nodes.has(id):
		return nodes[id].get("a", {}).get(key, default)
	return default



func rows_in(id: int, into: = PackedInt32Array()) -> PackedInt32Array:
	for row in rows_under.get(id, PackedInt32Array()):
		into.append(row)
		var part: = int(data[row * COLUMNS + ID])
		if rows_under.has(part) or nodes_under.has(part):
			rows_in(part, into)
	for child in nodes_under.get(id, PackedInt32Array()):
		rows_in(child, into)
	return into



func find_row(parent_id: int, part_name: String) -> int:
	var wanted: int = _name_index.get(part_name, -1)
	for row in rows_under.get(parent_id, PackedInt32Array()):
		if int(data[row * COLUMNS + NAME]) == wanted:
			return row
	return -1



func find_node(parent_id: int, node_class: String, node_name: = "") -> Dictionary:
	for id in nodes_under.get(parent_id, PackedInt32Array()):
		var node: Dictionary = nodes[id]
		if node["c"] == node_class and (node_name.is_empty() or node["n"] == node_name):
			return node
	return {}
