extends RefCounted


static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--play="):
			var play: = CrewPlay.new()
			play.name = "CrewPlay"
			main.add_child(play)
			return
