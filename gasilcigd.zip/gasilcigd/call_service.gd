class_name CallService
extends Node










static var current: CallService



signal debriefed(report: Dictionary)

const TICK: = 0.5
const STALLED: = 4.0
const STALLED_LEAST: = 1800.0

var kinds: Array = []
var _loops: = 0
var _gap: = 12.0
var running: = false
var hold: = false
var settling: = false
var _settled: = true
var _last: Dictionary = {}
var _kind: = ""


var wait_left: = 0.0
var reported: = false
var _recent: Array[String] = []
var _burnt: Array = []

var call_time: = 0.0
var scene_time: = 0.0


var scripted: Array = []


func _init() -> void :
	current = self


func _ready() -> void :
	Net.handle("call.debrief", func(report: Dictionary) -> void : _received(report))

	var radio: = Radio.new()
	radio.name = "Radio"
	add_child(radio)


	_connect_first(Game.incident_changed, func() -> void :
		if not Net.is_client():
			FireAlarm.mask(Game.incident)
	)

	Game.incident_changed.connect( func() -> void :
		if Alarm.active and not Game.incident.is_empty() and not Net.is_client():
			Game.incident["alarm"] = Alarm.level

			if Game.incident.has("pos") and not Game.incident.has("address"):
				Game.incident["address"] = Radio.address_of(Game.incident["pos"])[0]
			Game.incident.merge(Escalation.shown, true)
	)
	Game.incident_ending.connect( func(last: Dictionary) -> void :
		if Alarm.active:
			_last = last.duplicate()
	)



static func _connect_first(changed: Signal, handler: Callable) -> void :
	var others: = changed.get_connections()
	for other: Dictionary in others:
		changed.disconnect(other["callable"])
	changed.connect(handler)
	for other: Dictionary in others:
		changed.connect(other["callable"], other["flags"])



func publish(kind: String, call_name: Variant, at: Vector3, total: int) -> void :
	Game.set_incident({"kind": kind, "name": call_name, "pos": at, "done": 0, "total": total, "health": 100.0})


func progress(done: int) -> void :
	if Game.incident.is_empty():
		return
	Game.incident["done"] = done
	Game.incident_changed.emit()





func next_step(message: Variant) -> void :
	if Game.incident.is_empty():
		return
	var own: Variant = Game.incident["scene_next"] if Game.incident.has("scene_next") else Game.incident.get("next")
	if own == message:
		return
	Game.incident.erase("scene_next")
	if message == null:
		Game.incident.erase("next")
	else:
		Game.incident["next"] = message
	Game.incident_changed.emit()




func settle() -> void :
	await get_tree().process_frame
	await get_tree().process_frame



func clear(failed: = false) -> void :
	if not Game.incident.is_empty():
		Game.incident["failed"] = failed
	Game.set_incident({})


func start(call_kinds: Array) -> void :
	kinds = call_kinds
	_gap = float(Config.Fire.FirstIncident)
	_loop()


func _loop() -> void :
	var mine: = _loops
	while is_inside_tree() and mine == _loops:




		if not _settled:
			var since: = Game.now()
			settling = true
			while not _settled and is_inside_tree() and Game.now() - since < float(Config.Duty.get("SettleWait", 600.0)):
				await get_tree().create_timer(TICK, false).timeout
			settling = false
			_settled = true

		wait_left = _gap if wait_left <= 0.0 else minf(wait_left, _gap)
		while wait_left > 0.0 and is_inside_tree():
			await get_tree().create_timer(minf(TICK, wait_left), false).timeout
			wait_left -= TICK
		wait_left = 0.0
		reported = false
		_gap = float(Config.Fire.FirstIncident)
		if Game.players.is_empty() or hold or Net.is_client():
			continue
		if not scripted.is_empty():
			var call: Array = scripted.pop_front()
			if await run_call(call[0], call[1]) != false:
				note_drawn(call[0])
				_gap = randf_range(float(Shift.gap()[0]), float(Shift.gap()[1]))
			continue
		var chosen: Variant = draw()
		var force: Variant = Config.Incidents.get("Force")
		if forced != "":
			force = forced
		for kind in kinds:
			if force is String and kind.kind == force and kind.available():
				chosen = kind
		if chosen == null:
			continue

		var picked: Variant = chosen
		var body: Callable = picked.run
		if picked.kind == "fire":
			body = func() -> Variant: return await _run_fire(picked)
		var came: Variant = await run_call(picked.kind, body)
		if came != false:
			note_drawn(picked.kind)

			var gap: Array = Shift.gap()
			_gap = randf_range(float(gap[0]), float(gap[1]))




func hurry(seconds: float) -> void :
	_gap = minf(_gap, seconds)
	wait_left = seconds if wait_left <= 0.0 else minf(wait_left, seconds)
	_settled = true



var forced: = ""




func run_call(kind: String, body: Callable) -> Variant:
	var mine: = _loops
	running = true
	_kind = kind
	call_time = 0.0
	scene_time = 0.0
	_last = {}
	Alarm.begin()
	Escalation.reset()
	Game.call_started.emit(kind)
	_watch()
	var came: Variant = await body.call()
	if mine != _loops:
		return false
	running = false
	if came != false:
		_debrief(kind)
		_settled = Game.humans() == 0
	Alarm.end()
	Escalation.reset()
	return came





func _process(_delta: float) -> void :
	if Net.is_client() or running or not Game.incident.is_empty() or Game.station == null:
		return
	var reach: = float(Config.Alarm.EndScreen.StationReach)
	for player: Player in Game.players:
		if not is_instance_valid(player) or player.brain != null or player.health <= 0.0:
			continue
		if player.root_position().distance_to(Game.station.door_position) > reach:
			continue
		if not _settled and trucks_out() == 0:
			_settled = true
		var paid: = player.settle_pay()
		if paid > 0:
			Game.notify(Text.f("calls.debrief.paid", [Ui.money(paid)]), "good", player)








func share(kind_name: String) -> float:
	var settings: Dictionary = Config.Incidents
	var mix: Dictionary = settings.get("Mix", {})
	var shares: Dictionary = settings.get("Shares", {})
	var value: = float(mix.get(kind_name, shares.get(kind_name, 0.0)))
	if kind_name in settings.get("RepeatSkips", []):
		return value
	var repeat: = float(settings.get("RepeatShare", 1.0))
	for index in mini(int(settings.get("RepeatCalls", 0)), _recent.size()):
		if _recent[index] == kind_name:
			value *= repeat
	return value



func draw() -> Variant:
	var ready: Array = []
	var total: = 0.0
	for kind in kinds:
		if kind.available():
			ready.append(kind)
			total += share(kind.kind)
	if ready.is_empty():
		return null
	var drawn: = randf() * total
	for kind in ready:
		drawn -= share(kind.kind)
		if drawn <= 0.0:
			return kind
	return ready[ready.size() - 1]



func note_drawn(kind_name: String) -> void :
	_recent.push_front(kind_name)
	_recent.resize(mini(_recent.size(), 8))




func _run_fire(kind: Variant) -> Variant:
	var kept: Array = []
	for building: Variant in _burnt:
		if is_instance_valid(building) and not building.ruined:
			building.ruined = true
			kept.append(building)
	get_tree().process_frame.connect( func() -> void :
		for building: Variant in kept:
			if is_instance_valid(building):
				building.ruined = false
	, CONNECT_ONE_SHOT)
	return await kind.run()



func burnt_lately(building: Variant) -> bool:
	return _burnt.has(building)






static func trucks_out() -> int:
	var count: = 0
	for vehicle: Vehicle in Vehicle.all:
		if is_instance_valid(vehicle) and vehicle.spec.get("spawn") is Transform3D:
			var home: Transform3D = vehicle.spec["spawn"]
			if vehicle.global_position.distance_to(home.origin) > float(Config.Duty.BayReach):
				count += 1
	return count



func status() -> String:
	if running or not Game.incident.is_empty():
		return "out"
	return "returning" if trucks_out() > 0 else "available"




func report(player: Player) -> void :
	if Net.is_client():
		return
	if status() == "out":
		Game.tell(player, Text.m("calls.duty.onCall"))
		return
	var out: = trucks_out()
	if out > 0:
		Game.tell(player, Text.f("calls.duty.notParked", [out]))
		return
	if reported:
		Game.tell(player, Text.m("calls.duty.already"), "")
		return
	reported = true
	var gap: Array = Config.Duty.ReportGap
	hurry(randf_range(float(gap[0]), float(gap[1])))
	Game.notify(Text.m("calls.duty.reported"), "good")








func overdue(waited: float) -> bool:
	var close_after: = float(Config.Incidents.CloseAfter)
	if not running:
		return waited >= close_after
	if Alarm.arrived_at >= 0.0:
		return scene_time >= close_after
	return call_time >= close_after * float(Config.Incidents.CloseNoShow)




func closes_in() -> float:
	if not running or Alarm.arrived_at < 0.0 or (FireService.current != null and not FireService.current.incident.is_empty()):
		return -1.0
	return maxf(float(Config.Incidents.CloseAfter) - scene_time, 0.0)






func _watch() -> void :
	var told: = false
	var noted: = false
	while running and is_inside_tree():
		if not Game.incident.is_empty() and Game.incident.has("pos"):
			if not told:
				told = true
				if Game.station:
					Alarm.station_distance = Game.station.door_position.distance_to(Game.incident["pos"])
				Game.notify(level_line(_kind, Alarm.level), "" if Alarm.level == 1 else "warning")
			Alarm.watch(Game.incident["pos"], TICK)
			var left: = closes_in()
			if left >= 0.0 and left <= float(Config.Incidents.CloseWarn):
				Game.incident["closes_in"] = ceili(left)
			else:
				Game.incident.erase("closes_in")
		if not noted and FireService.current != null and not FireService.current.incident.is_empty():
			noted = true
			_burnt.push_front(FireService.current.incident["group"]["building"])
			_burnt.resize(mini(_burnt.size(), int(Config.Incidents.BurntKept)))
		await get_tree().create_timer(TICK, false).timeout
		call_time += TICK
		if Alarm.arrived_at >= 0.0:
			scene_time += TICK



		if running and call_time > maxf(float(Config.Incidents.CloseAfter) * STALLED, STALLED_LEAST):
			push_error("CallService: the %s call stopped answering after %d s; taken down" % [_kind, roundi(call_time)])
			_loops += 1
			running = false
			Game.set_incident({})
			Alarm.end()
			Escalation.reset()
			_settled = true
			_gap = float(Config.Fire.FirstIncident)
			_loop()
			return




static func level_line(kind: String, level: int) -> Dictionary:
	var key: = "calls.alarm.levels.%s.%d" % [kind, level]
	if level > 1 and Text.has(key):
		return Text.f(key, [Alarm.numeral(level)])
	return Text.f("calls.alarm.level", [Alarm.numeral(level)])











func _debrief(kind: String) -> void :
	if _last.is_empty():
		return
	Alarm.flush()
	var report: = Alarm.debrief(kind, _last)
	var humans: Array[Player] = []
	for list: Dictionary in [Alarm.on_scene, Alarm.earned]:
		for player: Variant in list:
			if is_instance_valid(player) and player is Player and player.brain == null and not humans.has(player):
				humans.append(player)
	var crew: Array = []
	var call_total: = 0
	for player in humans:
		var items: Dictionary = Alarm.earned.get(player, {}).duplicate()
		var earned: = 0
		for item: String in items:
			earned += int(items[item])
		var grade_pay: = int(round(earned * (float(report["multiplier"]) - 1.0)))
		grade_pay = maxi(grade_pay, - (int(player.get_attr("Cash", 0)) + int(player.get_attr("Pending", 0))))
		if grade_pay != 0:
			player.add_cash(grade_pay, "bonus", true, "grade")
		var points_before: = int(player.get_attr("Saved", 0))
		player.add_points(int(report["points"]))


		var did: Dictionary = Alarm.stats.get(player, {})
		var per_call: = float(Config.Gear.get("WearPerCall", 0.0))
		player.set_attr("Wear", minf(1.0, float(player.get_attr("Wear", 0.0)) + per_call))
		if kind == "fire" or int(did.get("flames", 0)) > 0:
			player.set_attr("HelmetWear", minf(1.0, float(player.get_attr("HelmetWear", 0.0)) + per_call))
		var best: String = player.get_attr("Best_" + kind, "")
		var new_best: = Alarm.better(report["grade"], best)
		if new_best:
			player.set_attr("Best_" + kind, report["grade"])
		crew.append({
			"peer": _peer(player), "name": player.display_name, 
			"flames": int(did.get("flames", 0)), "carried": int(did.get("carried", 0)), "hose": int(did.get("hose", 0.0)), 
			"doors": int(did.get("doors", 0)), "air": int(did.get("air", 0.0)), 
			"items": items, "earned": earned, "grade_pay": grade_pay, "total": earned + grade_pay, 
			"points_before": points_before, "points": int(report["points"]), "best": best, "new_best": new_best, "title": "", 
		})
		call_total += earned + grade_pay
	_entitle(crew)
	report["crew"] = crew
	report["call_total"] = call_total
	report["name"] = _last.get("name", "")
	report["number"] = _reported + 1
	_reported += 1
	Game.notify(Text.f("calls.debrief.line", [report["grade"], Alarm.numeral(report["level"])]), "good" if report["grade"] in ["S", "A"] else "")
	if Net.is_host() and Net.active():
		Net.broadcast("call.debrief", [report])
	_received(report)


var _reported: = 0



static func _peer(player: Player) -> int:
	var peer: = Net.peer_of(player)
	return peer if peer > 0 else (1 if player == Game.local_player else 0)




static func _entitle(crew: Array) -> void :
	if crew.size() < int(Config.Alarm.EndScreen.TitlesFrom):
		return
	for stat: String in ["flames", "carried", "doors", "hose", "air"]:
		var top: Dictionary = {}
		var tied: = false
		for line: Dictionary in crew:
			if int(line[stat]) <= 0:
				continue
			if top.is_empty() or int(line[stat]) > int(top[stat]):
				top = line
				tied = false
			elif int(line[stat]) == int(top[stat]):
				tied = true
		if not top.is_empty() and not tied and String(top["title"]).is_empty():
			top["title"] = stat




func _received(report: Dictionary) -> void :
	CallLog.add(report)
	var me: = Game.local_player
	var line: = CallLog.mine(report)
	if me != null and not line.is_empty():
		if int(line["carried"]) > 0:
			me.set_attr("Lives", int(me.get_attr("Lives", 0)) + int(line["carried"]))
		if line["new_best"]:
			var kind_name: Variant = Text.m("hud.dispatch.kinds.%s.tag" % report["kind"])
			if String(line["best"]).is_empty():
				Game.notify(Text.f("calls.debrief.firstBest", [kind_name, report["grade"]]), "good", me)
			else:
				Game.notify(Text.f("calls.debrief.newBest", [kind_name, report["grade"], line["best"]]), "good", me)
	print("call report #%d: %s grade %s (%.2f), parts %s, crew %s" % [int(report.get("number", 0)), report["kind"], report["grade"], float(report["score"]), _parts_line(report), _crew_line(report)])
	debriefed.emit(report)


static func _parts_line(report: Dictionary) -> String:
	var shown: Array[String] = []
	for part: Array in report.get("parts", []):
		shown.append("%s %d%%" % [part[0], int(round(float(part[1]) * 100.0))])
	return ", ".join(shown)


static func _crew_line(report: Dictionary) -> String:
	var shown: Array[String] = []
	for line: Dictionary in report.get("crew", []):
		shown.append("%s[%d] flames %d carried %d hose %d doors %d air %d $%d %s" % [line["name"], int(line["peer"]), int(line["flames"]), int(line["carried"]), int(line["hose"]), int(line["doors"]), int(line["air"]), int(line["total"]), line["title"]])
	return "; ".join(shown)
