class_name PlayerCamera
extends Node3D



var player: Player
var camera: Camera3D
var yaw: = 0.0
var pitch: = -0.25
var distance: = 16.0
var wanted_distance: = 16.0
var _out_distance: = 16.0
var captured: = true
var shake: = 0.0

var subject: Node3D
var subject_height: = 5.0
var subject_distance: = 0.0
var base_fov: = 70.0


var driver_view: = false
var chase_far: = false
var _aim_until: = 0.0
var _shown: = Vector3.ZERO
var _squeezed: = false
var _free_for: = 0.0
var _seat_yaw: = 0.0
var _seated_in: Node3D
var _from_seat: = false
var _behind: = Vector2.ZERO
const SEAT_PITCH: = -0.06
const SQUEEZE_MARGIN: = 3.0
const SQUEEZE_CLEAR: = 0.5
const SQUEEZE_SLACK: = 2.0




const OWN_LAYER: = 1 << 19



const EYE_LEAD: = 0.62
const EYE_LEAD_DOWN: = 1.6




var _own_view: = false
var _eyes_seated: = false
var _layers: Dictionary = {}
var _arms_shown: = {"R": false, "L": false}
var _over_shoulder: = 1.6
var _mouse_moved: = 0.0
const ARM_ROOM: = 1.0
const SLIM: = 0.62
var _arm_scale: = 1.0





var _looked_at: = -1000.0
var _rock: = Vector3.ZERO
var _fov: = 70.0
var _fov_ours: = false


func _ready() -> void :
	top_level = true

	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	camera = Camera3D.new()
	camera.far = 5000.0
	camera.near = 0.35
	camera.fov = base_fov
	camera.cull_mask &= ~ OWN_LAYER
	add_child(camera)
	camera.make_current()
	yaw = player.rig.rotation.y
	capture(true)


func capture(on: bool) -> void :
	captured = on
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if on else Input.MOUSE_MODE_VISIBLE


func forward() -> Vector3:
	return - (Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch)).z


func first_person() -> bool:
	return distance < 1.5 and subject == null



func seated_view() -> bool:
	return subject is Vehicle and player.seat != null and (driver_view or _squeezed)




func _seat_eye(vehicle: Vehicle) -> Vector3:
	var seat: = player.seat
	var lead: float = vehicle.spec.get("eyeLead", 0.0)
	var over: = vehicle.to_local(seat.global_position - seat.global_basis.z * lead)
	return _drawn(vehicle) * Vector3(over.x, float(vehicle.spec.get("eyeHeight", over.y + 4.0)), over.z)



func _seat_turn(vehicle: Vehicle) -> float:
	return (vehicle.global_basis.inverse() * player.seat.global_basis).get_euler().y





static func _drawn(node: Node3D) -> Transform3D:
	return node.get_global_transform_interpolated()



func aiming() -> bool:
	return first_person() or Game.now() < _aim_until or player.holding == "nozzle"



func face_view(seconds: = 0.6) -> void :
	_aim_until = Game.now() + seconds


func _unhandled_input(event: InputEvent) -> void :
	if event is InputEventMouseMotion and captured:
		if event.relative.length() > 1.0:
			_mouse_moved = 0.4
			_looked_at = Game.now()
		yaw -= event.relative.x * 0.0032 * Settings.sensitivity
		pitch = clampf(pitch - event.relative.y * 0.0032 * Settings.sensitivity * (-1.0 if Settings.invert_y else 1.0), -1.4, 1.35)
	elif event is InputEventMouseButton and event.pressed and captured:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			wanted_distance = maxf(0.0, wanted_distance - 2.0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			wanted_distance = minf(45.0, wanted_distance + 2.0)
	elif event is InputEventMouseButton and event.pressed and not captured and not Game.ui_open:
		capture(true)



func _process(delta: float) -> void :
	if _seated(delta):
		return


	if subject == null and player.seat == null and captured and not Game.ui_open and Input.is_action_just_pressed("camera_mode"):
		if wanted_distance < 1.5:
			wanted_distance = _out_distance if _out_distance >= 1.5 else 16.0
		else:
			_out_distance = wanted_distance
			wanted_distance = 0.0
	_look_at_hands(delta)
	var focus: Vector3
	var reach: = wanted_distance
	var exclude: Array[RID] = [player.get_rid()]
	if subject != null and is_instance_valid(subject):
		focus = _drawn(subject).origin + Vector3(0, subject_height, 0)

		reach = maxf(wanted_distance, 6.0) + subject_distance + (_rock.z + _chase_extra() if _riding() != null else 0.0)
		if _riding() != null and chase_far:
			focus.y += float(Config.VehicleCamera.FarLift)
		if subject is CollisionObject3D:
			exclude.append(subject.get_rid())
	else:
		focus = _drawn(player).origin + (player.head_position() - player.global_position) + Vector3(0, 0.6, 0)
		reach = _indoor_reach(reach, delta)

	if _shown == Vector3.ZERO or _shown.distance_to(focus) > 40.0:
		_shown = focus
	_shown.x = focus.x
	_shown.z = focus.z
	_shown.y = lerpf(_shown.y, focus.y, 1.0 - exp( - delta * 18.0))
	var basis: = Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch)
	var back: = basis.z


	var over: = 1.6
	if player.holding == "nozzle":
		over = float(Config.Hose.Reticle.NozzleShoulder)
	elif not _room.is_empty() and subject == null:
		over = float(Config.IndoorCamera.Shoulder)
	_over_shoulder = lerpf(_over_shoulder, over, 1.0 - exp( - delta * float(Config.Hose.Reticle.ShoulderEase)))
	var shoulder: = basis.x * clampf(reach / 16.0, 0.0, 1.0) * (_over_shoulder if subject == null else 0.0)
	var want: = reach
	if reach > 0.5:
		var query: = PhysicsRayQueryParameters3D.create(_shown, _shown + shoulder + back * reach, World.LAYER_SOLID, exclude)
		var hit: = get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty():
			want = maxf(0.2, _shown.distance_to(hit["position"]) - 0.6)
		_room_behind(want, delta)
	distance = want if want < distance else lerpf(distance, want, 1.0 - exp( - delta * 8.0))
	var place: = _shown + (shoulder + back * reach).normalized() * distance if reach > 0.5 else _shown
	if first_person() and player.seat == null:
		place += _eye_lead()
	place += _shake_offset(delta)
	place = _keep_in_room(place)
	global_transform = Transform3D(basis * _shake_basis(), place)
	if _riding() != null:
		global_transform = global_transform * Rbx.angles(_rock.x, 0.0, _rock.y)
	player.rig.visible = true

	_through_eyes(first_person(), delta, not player.rig.at_controls())




func _look_at_hands(delta: float) -> void :
	if not first_person() or _mouse_moved > 0.0:
		_mouse_moved = maxf(0.0, _mouse_moved - delta)
		return
	var at: = player.acting_at()
	if at == Vector3.INF:
		return
	var eye: = global_position
	var flat: = Vector2(at.x - eye.x, at.z - eye.z).length()
	var wanted: = clampf(atan2(at.y - eye.y, maxf(flat, 0.5)) + 0.12, -1.1, 0.4)
	if wanted < pitch:
		pitch = lerpf(pitch, wanted, 1.0 - exp( - delta * 4.0))







func _through_eyes(on: bool, delta: = 0.0, hung: = true) -> void :
	if on != _own_view:
		_own_view = on
		var tree: = get_tree()
		if on:
			_eyes_seated = player.seat != null
			_hide_from_eyes(player.rig)
			tree.node_added.connect(_on_node_added)
			tree.node_removed.connect(_on_node_removed)
		else:
			player.rig.end_view()
			_show_arms({"R": false, "L": false})
			_arm_scale = 1.0
			tree.node_added.disconnect(_on_node_added)
			tree.node_removed.disconnect(_on_node_removed)
			for node: Variant in _layers:
				if is_instance_valid(node):
					node.layers = _layers[node]
			_layers.clear()
	if on and (player.seat != null) != _eyes_seated:

		_eyes_seated = player.seat != null
		for node: Variant in _layers:
			if is_instance_valid(node):
				node.layers = _layers[node] if _body_piece(node) else OWN_LAYER
	if on and not hung:


		player.rig.end_view()
		var at_controls: = player.rig.at_controls()
		_show_arms({"R": at_controls, "L": at_controls})
	elif on:


		var toward: Vector3 = global_basis * Vector3(0.5, -0.6, -2.4)
		var query: = PhysicsRayQueryParameters3D.create(global_position, global_position + toward * (1.0 + ARM_ROOM / toward.length()), World.LAYER_SOLID, [player.get_rid()])
		var hit: = get_world_3d().direct_space_state.intersect_ray(query)
		var room: = 1.0
		if not hit.is_empty():
			room = clampf((global_position.distance_to(hit["position"]) - ARM_ROOM) / toward.length(), 0.3, 1.0)
		_arm_scale = room if room < _arm_scale else lerpf(_arm_scale, room, 1.0 - exp( - delta * 6.0))


		var eye: = global_transform
		if player.holding == "nozzle":
			eye = eye * Transform3D(Basis.IDENTITY, Config.Hose.Reticle.FirstPersonNozzle)
		player.rig.solve_view(eye, _arm_scale, delta)
		_show_arms(player.rig.view_arms)




func _hide_from_eyes(node: Node) -> void :
	if node == player.rig.hand_right or node == player.rig.hand_left:
		return
	var drawn: = node as GeometryInstance3D
	if drawn != null and not _layers.has(drawn):
		_layers[drawn] = drawn.layers
		if not _body_piece(drawn):
			drawn.layers = OWN_LAYER
	for child in node.get_children():
		_hide_from_eyes(child)






func _body_piece(node: Node) -> bool:
	var joints: Dictionary = player.rig.joints
	var parent: = node.get_parent()
	if _eyes_seated and (parent == joints["ShoulderR"] or parent == joints["ShoulderL"]):
		return false
	return parent != joints["Neck"] and joints.values().has(parent)




func _on_node_added(node: Node) -> void :
	var rig: = player.rig
	if node is GeometryInstance3D and rig.is_ancestor_of(node) and not rig.hand_right.is_ancestor_of(node) and not rig.hand_left.is_ancestor_of(node):
		_hide_from_eyes(node)


func _on_node_removed(node: Node) -> void :
	if _layers.has(node):
		node.layers = _layers[node]
		_layers.erase(node)




func _show_arms(hung: Dictionary) -> void :
	var changed: = false
	for side: String in ["R", "L"]:
		if bool(hung.get(side, false)) != _arms_shown[side]:
			_arms_shown[side] = bool(hung.get(side, false))
			changed = true
	if not changed:
		return
	for side: String in ["R", "L"]:
		for joint: String in ["Shoulder" + side, "Elbow" + side, "Wrist" + side]:
			for piece in player.rig.joints[joint].get_children():
				if _layers.has(piece):
					(piece as Node3D).scale = Vector3(SLIM, 1.0, SLIM) if _arms_shown[side] else Vector3.ONE




func _eye_lead() -> Vector3:
	var ahead: = - player.rig.global_basis.z
	ahead.y = 0.0
	if ahead.length_squared() < 0.0001:
		return Vector3.ZERO
	ahead = ahead.normalized()
	var lead: = lerpf(EYE_LEAD, EYE_LEAD_DOWN, clampf( - pitch / 1.2, 0.0, 1.0))
	var query: = PhysicsRayQueryParameters3D.create(_shown, _shown + ahead * (lead + camera.near + 0.1), World.LAYER_SOLID, [player.get_rid()])
	var hit: = get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		lead = maxf(0.0, _shown.distance_to(hit["position"]) - camera.near - 0.1)
	return ahead * lead





func _room_behind(room: float, delta: float) -> void :
	var vehicle: = subject as Vehicle
	if vehicle == null or player.seat == null:
		_squeezed = false
		return
	var needed: float = float(vehicle.data.get("rear", 10.0)) + SQUEEZE_MARGIN
	if room < needed:
		_squeezed = true
		_free_for = 0.0
	elif _squeezed and room >= needed + SQUEEZE_SLACK:
		_free_for += delta
		if _free_for > SQUEEZE_CLEAR:
			_squeezed = false



func _seated(delta: float) -> bool:
	var vehicle: = _riding()
	if vehicle == null:
		if _from_seat:
			_clear_glass(_seated_in as Vehicle, false)
		_seated_in = null
		_squeezed = false
		_from_seat = false
		_rock = Vector3.ZERO
		_ease_fov(base_fov, delta)
		return false
	var heading: = _drawn(vehicle).basis.get_euler().y
	if _seated_in != vehicle:
		_seated_in = vehicle
		_seat_yaw = heading
	if captured and not Game.ui_open and Input.is_action_just_pressed("camera_mode"):
		next_vehicle_view()
	var turned: = wrapf(heading - _seat_yaw, - PI, PI)
	_seat_yaw = heading
	_rock_with(vehicle, delta)
	if not (driver_view or _squeezed):
		_leave_seat_view(heading)
		_follow(vehicle, heading, turned, false, delta)
		_ease_fov(base_fov + _speed_fov(vehicle, float(Config.VehicleCamera.ChaseSpeedFov)), delta)
		return false
	if _squeezed and not driver_view:



		var behind: = _behind if _from_seat else Vector2(pitch, wrapf(yaw - heading, - PI, PI))
		var back: = (Basis(Vector3.UP, heading + behind.y) * Basis(Vector3.RIGHT, behind.x)).z
		var focus: = _drawn(vehicle).origin + Vector3(0, subject_height, 0)
		if chase_far:
			focus.y += float(Config.VehicleCamera.FarLift)
		var reach: = maxf(wanted_distance, 6.0) + subject_distance + _rock.z + _chase_extra()
		var query: = PhysicsRayQueryParameters3D.create(focus, focus + back * reach, World.LAYER_SOLID, [player.get_rid(), vehicle.get_rid()])
		var hit: = get_world_3d().direct_space_state.intersect_ray(query)
		_room_behind(focus.distance_to(hit["position"]) - 0.6 if not hit.is_empty() else reach, delta)
		if not _squeezed:
			_leave_seat_view(heading)
			_follow(vehicle, heading, turned, false, delta)
			_ease_fov(base_fov + _speed_fov(vehicle, float(Config.VehicleCamera.ChaseSpeedFov)), delta)
			return false
	if not _from_seat:

		_from_seat = true
		_clear_glass(vehicle, true)
		_behind = Vector2(pitch, wrapf(yaw - heading, - PI, PI))
		pitch = SEAT_PITCH
		yaw = heading + _seat_turn(vehicle)

	_follow(vehicle, heading + _seat_turn(vehicle), turned, true, delta)
	distance = 0.0
	_shown = _seat_eye(vehicle)
	global_transform = Transform3D(Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, pitch), _shown)

	global_transform = global_transform * Transform3D(Basis.IDENTITY, Vector3(0, 0, _rock.z * float(Config.VehicleCamera.SeatLag))) * Rbx.angles(_rock.x, 0.0, _rock.y)
	global_position += _shake_offset(delta) * 0.4
	global_transform.basis = global_transform.basis * _shake_basis()

	if vehicle.driver() == player:
		_ease_fov(float(Config.Truck.DriverFov) + _speed_fov(vehicle, float(Config.Truck.SpeedFov)), delta)
	else:
		_ease_fov(base_fov, delta)

	_through_eyes(true, delta, false)
	player.rig.visible = true
	return true



func next_vehicle_view() -> void :
	if driver_view:
		driver_view = false
		chase_far = false
	elif not chase_far:
		chase_far = true
	else:
		driver_view = true
	var said: = "viewInside" if driver_view else ("viewFar" if chase_far else "viewClose")
	Game.notify(Text.m("gear.truck." + said), "", player)



func _chase_extra() -> float:
	return float(Config.VehicleCamera.ChaseFar if chase_far else Config.VehicleCamera.ChaseClose)



func _riding() -> Vehicle:
	var vehicle: = subject as Vehicle
	if vehicle == null or not is_instance_valid(vehicle) or player.seat == null:
		return null
	return vehicle





func _follow(vehicle: Vehicle, heading: float, turned: float, from_seat: bool, delta: float) -> void :
	var settings: Dictionary = Config.VehicleCamera
	yaw += turned
	var aside: = wrapf(yaw - heading, - PI, PI)
	if from_seat:
		var most: = deg_to_rad(float(settings["MaxHeadTurn"]))
		aside = clampf(aside, - most, most)
	var moving: = absf(vehicle.forward_speed) > float(settings["RecentreSpeed"])
	if vehicle.driver() == player and moving and Game.now() - _looked_at > float(settings["RecentreAfter"]):
		aside *= 1.0 - minf(1.0, delta * float(settings["RecentreRate"]))
	yaw = heading + aside




func _rock_with(vehicle: Vehicle, delta: float) -> void :
	var settings: Dictionary = Config.VehicleCamera
	var state: = vehicle.drive
	var gaining: = clampf(state.accel, -60.0, 60.0)
	var motion: = state.motion(vehicle.wheelbase, vehicle.rear_axle)
	var sideways: = motion[0] * motion[2]
	var lean: = float(state.profile.get("lean", 1.0)) * motion_scale()
	var per: = deg_to_rad(1.0) / float(settings["RockPer"])
	var ease: = minf(1.0, delta * 5.0)
	_rock.x += (gaining * float(settings["RockPitch"]) * per * lean - _rock.x) * ease
	_rock.y += ( - sideways * float(settings["RockRoll"]) * per * lean - _rock.y) * ease
	var lag: = clampf(gaining * float(settings["RockLag"]) * lean, float(settings["LagLeast"]), float(settings["LagMost"]))
	_rock.z += (lag - _rock.z) * minf(1.0, delta * 3.0)



static func motion_scale() -> float:
	var shares: Array = Config.VehicleCamera.Motion
	return float(shares[clampi(Settings.motion_level(), 0, shares.size() - 1)])



func _speed_fov(vehicle: Vehicle, most: float) -> float:
	var top: = float(vehicle.drive.profile.get("topSpeed", 60.0))
	return most * motion_scale() * clampf(absf(vehicle.forward_speed) / maxf(top, 1.0), 0.0, 1.0)



func _ease_fov(goal: float, delta: float) -> void :
	if not _fov_ours:
		if goal == base_fov:
			return
		_fov = camera.fov
	_fov += (goal - _fov) * minf(1.0, delta * float(Config.VehicleCamera.FovEase))
	_fov_ours = goal != base_fov or absf(_fov - base_fov) > 0.05
	camera.fov = _fov if _fov_ours else base_fov



func _leave_seat_view(heading: float) -> void :
	if _from_seat:
		_from_seat = false
		_clear_glass(_seated_in as Vehicle, false)
		pitch = _behind.x
		yaw = heading + _behind.y



func _clear_glass(vehicle: Vehicle, clear: bool) -> void :
	if vehicle != null and is_instance_valid(vehicle) and vehicle._kit_glass != null:
		var tint: = Vehicle.GLASS
		tint.a = 0.06 if clear else Vehicle.GLASS.a
		vehicle._kit_glass.set_shader_parameter("tint", tint)







func jolt(amount: float) -> void :
	shake = maxf(shake, amount)









var sway: = 0.0
var _noise: FastNoiseLite
var _noise_time: = 0.0
var _shake_turn: = Vector3.ZERO
var _last_shake: = 0.0
var _push: = Vector3(0.0, 0.0, 0.0)



func push(amount: float, seconds: float) -> void :
	_push = Vector3(amount, maxf(seconds, 0.01), maxf(seconds, 0.01))




func hit_stop() -> void :
	var settings: Dictionary = Config.Shake
	if motion_scale() <= 0.0 or Net.active() or Engine.time_scale != 1.0 or Game.is_paused():
		return
	Engine.time_scale = float(settings["HitStopScale"])
	get_tree().create_timer(float(settings["HitStop"]), true, false, true).timeout.connect( func() -> void :
		if Engine.time_scale == float(settings["HitStopScale"]):
			Engine.time_scale = 1.0
	)


func _wave(channel: float) -> float:
	return _noise.get_noise_2d(_noise_time * float(Config.Shake.Speed), channel * 37.0)




func _shake_offset(delta: float) -> Vector3:
	var settings: Dictionary = Config.Shake
	var share: = motion_scale()
	if _noise == null:
		_noise = FastNoiseLite.new()
		_noise.noise_type = FastNoiseLite.TYPE_PERLIN
		_noise.frequency = 1.0
	_noise_time += delta
	if shake > _last_shake + float(settings["HitStopFrom"]):
		hit_stop()
	var trauma: = clampf(shake / float(settings["Full"]), 0.0, 1.0)
	var weight: = trauma * trauma * share * Settings.shake_share()
	var offset: = Vector3(_wave(1.0), _wave(2.0), _wave(3.0)) * float(settings["Full"]) * float(settings["Move"]) * weight
	_shake_turn = Vector3(_wave(4.0), _wave(5.0), _wave(6.0) * 0.5) * deg_to_rad(float(settings["Turn"])) * weight
	_last_shake = shake
	shake = maxf(0.0, shake - delta * float(settings["Decay"]))

	if _push.z > 0.0:
		_push.z = maxf(0.0, _push.z - delta)
		var left: = _push.z / _push.y
		offset += global_basis.z * _push.x * left * left * share
	if sway > 0.0:
		offset += Vector3(_wave(7.0), _wave(8.0), 0.0) * sway * share
		_shake_turn += Vector3(_wave(9.0), _wave(10.0), 0.0) * sway * 0.02 * share
	return offset



func _shake_basis() -> Basis:
	return Basis.from_euler(_shake_turn) if _shake_turn != Vector3.ZERO else Basis.IDENTITY





var _room: Dictionary = {}
var _room_clock: = 0.0




func _indoor_reach(reach: float, delta: float) -> float:
	_room_clock -= delta
	if _room_clock <= 0.0:
		_room_clock = 0.25
		_room = _find_room()
	if _room.is_empty() or reach < 1.5:
		return reach
	return minf(reach, float(Config.IndoorCamera.Reach))



func _find_room() -> Dictionary:
	if player.seat != null or subject != null:
		return {}
	var head: = player.head_position()
	var near: = float(Config.IndoorCamera.HouseReach)
	for house in House.all:
		if house.position.distance_to(head) > near:
			continue
		var room: Variant = house.room_at(head)
		if room is Dictionary:
			return {"house": house, "low": room["low"], "high": room["high"]}
	return {}





func _keep_in_room(place: Vector3) -> Vector3:
	if _room.is_empty() or subject != null or distance < 1.5:
		return place
	var house: House = _room["house"]
	if house == null:
		return place
	var margin: = float(Config.IndoorCamera.Margin)
	var inside: = house.lot.affine_inverse() * place
	var low: Vector3 = _room["low"]
	var high: Vector3 = _room["high"]
	var kept: = Vector3(
		clampf(inside.x, low.x + margin, maxf(high.x - margin, low.x + margin)), 
		clampf(inside.y, low.y + margin, maxf(high.y - margin, low.y + margin)), 
		clampf(inside.z, low.z + margin, maxf(high.z - margin, low.z + margin)))
	if kept.is_equal_approx(inside):
		return place
	var moved: = house.lot * kept
	distance = moved.distance_to(_shown)
	return moved



func indoors() -> bool:
	return not _room.is_empty()
