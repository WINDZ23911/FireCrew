extends RefCounted





const SPACING: = 1.15
const METAL: = Color(0.24, 0.25, 0.27)


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("Balconies")
	var count: = 0
	var made: = store.count
	for shell: Dictionary in kit.get_meta("shells"):
		if not shell["balconies"]:
			continue
		var rng: = kit.rng("balconies:%d" % shell["model"])

		var look: = rng.randi_range(0, 2)
		var wall: Color = shell["wall"]
		var panel: = wall.lerp(Color.WHITE, 0.45) if rng.randf() < 0.5 else wall.darkened(0.18)
		var rail_color: = METAL if rng.randf() < 0.7 else PolishKit.rgb(236, 236, 230)
		for row: int in shell["rows"]["BalconyRail"]:
			store.set_transparency(row, 1.0)
			var place: = store.transform(row).orthonormalized()
			var width: = store.size(row).x
			var half: = width / 2.0
			var height: = store.size(row).y
			var top: = height / 2.0
			var foot: = - height / 2.0
			var back: = 2.9

			kit.box(folder, place * Transform3D(Basis(), Vector3(0, foot - 0.25, 0.08)), Vector3(width + 0.1, 0.55, 0.14), PolishKit.rgb(196, 194, 188), "Concrete", "BalconyEdge")

			kit.box(folder, place * Transform3D(Basis(), Vector3(0, top - 0.12, 0)), Vector3(width + 0.2, 0.22, 0.3), rail_color, "Metal", "Handrail")
			for side in [-1.0, 1.0]:
				kit.box(folder, place * Transform3D(Basis(), Vector3(side * (half + 0.0), top - 0.12, back / 2.0)), Vector3(0.22, 0.22, back), rail_color, "Metal", "Handrail")
			if look == 0:
				kit.box(folder, place * Transform3D(Basis(), Vector3(0, foot + 0.3, 0)), Vector3(width, 0.16, 0.16), rail_color, "Metal", "BottomRail")
				var n: = maxi(int(width / SPACING), 2)
				for index in range(1, n):
					var x: = - half + index * width / n
					kit.box(folder, place * Transform3D(Basis(), Vector3(x, (foot + 0.3 + top - 0.12) / 2.0, 0)), Vector3(0.12, top - 0.12 - foot - 0.3, 0.12), rail_color, "Metal", "Baluster")
				for side in [-1.0, 1.0]:
					kit.box(folder, place * Transform3D(Basis(), Vector3(side * half, foot + 0.3, back / 2.0)), Vector3(0.16, 0.16, back), rail_color, "Metal", "BottomRail")
					for z in [back * 0.35, back * 0.7]:
						kit.box(folder, place * Transform3D(Basis(), Vector3(side * half, (foot + 0.3 + top - 0.12) / 2.0, z)), Vector3(0.12, top - 0.12 - foot - 0.3, 0.12), rail_color, "Metal", "Baluster")
					kit.box(folder, place * Transform3D(Basis(), Vector3(side * half, 0.0, 0.0)), Vector3(0.2, height, 0.2), rail_color, "Metal", "RailPost")
			else:
				var glass: = look == 2
				var color: = PolishKit.rgb(196, 214, 220) if glass else panel
				var material: = "Glass" if glass else "Plaster"
				var id: = kit.box(folder, place * Transform3D(Basis(), Vector3(0, (foot + top - 0.24) / 2.0, 0.02)), Vector3(width, top - 0.24 - foot, 0.16), color, material, "BalconyPanel")
				if glass:
					store.set_transparency(store.row_of[id], 0.45)
				for side in [-1.0, 1.0]:
					var sid: = kit.box(folder, place * Transform3D(Basis(), Vector3(side * half, (foot + top - 0.24) / 2.0, back / 2.0)), Vector3(0.16, top - 0.24 - foot, back), color, material, "BalconyPanel")
					if glass:
						store.set_transparency(store.row_of[sid], 0.45)

			if rng.randf() < 0.22:
				var corner: = Vector3(rng.randf_range( - half + 0.8, half - 0.8), foot, back * 0.6)
				kit.box(folder, place * Transform3D(Basis(), corner + Vector3(0, 0.6, 0)), Vector3(1.1, 1.2, 1.1), PolishKit.rgb(168, 92, 62), "Concrete", "Pot")
				var green: = PolishKit.rgb(74, 126, 66).lerp(PolishKit.rgb(110, 150, 70), rng.randf())
				kit.ball(folder, place * (corner + Vector3(0, 1.9, 0)), Vector3(1.8, 1.8, 1.8), green, "LeafyGrass", "Plant")
			count += 1
	return "%d balconies railed (%d parts)" % [count, store.count - made]
