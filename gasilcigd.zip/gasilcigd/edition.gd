class_name Edition
extends RefCounted









const DEFAULT: = "metlika"
const PATH: = "res://data/godot/Edition.json"
const ROOT: = "res://data/editions/"
const CHOICE: = "user://edition.cfg"

const ALL: Array[String] = ["metlika", "us", "de"]

const AVAILABLE: Array[String] = ["metlika"]

static var _data: Dictionary = {}
static var _id: = ""



static func id() -> String:
	if _id.is_empty():
		_id = DEFAULT
		var chosen: = ""
		var config: = ConfigFile.new()
		if config.load(CHOICE) == OK:
			chosen = str(config.get_value("game", "edition", ""))
			if not chosen in AVAILABLE:
				chosen = ""
		for arg in OS.get_cmdline_user_args():
			if arg.begins_with("--edition="):
				chosen = arg.substr(10)
		if chosen in ALL:
			_id = chosen
	return _id


static func is_metlika() -> bool:
	return id() == DEFAULT




static func path(relative: String, fallback: String) -> String:
	if not is_metlika():
		var own: = ROOT + id() + "/" + relative
		if FileAccess.file_exists(own) or ResourceLoader.exists(own):
			return own
	return fallback


static func data() -> Dictionary:
	if _data.is_empty():
		var read: Variant = Rbx.load_json(path("Edition.json", PATH))
		if read is Dictionary:
			_data = read
	return _data



static func fleet(key: String) -> Dictionary:
	var vehicles: Dictionary = data().get("fleet", {})
	return vehicles.get(key, {})



static func look(key: String) -> Dictionary:
	var found: Variant = data().get(key, {})
	return found if found is Dictionary else {}



static func color(table: Dictionary, key: String, fallback: Color) -> Color:
	var value: Variant = table.get(key)
	return Color.html(value) if value is String and Color.html_is_valid(value) else fallback




static func skips(what: String) -> bool:
	var skip: Array = data().get("skip", [])
	return what in skip or what.get_basename() in skip



static func choose(edition: String, extra: Array = []) -> void :
	if not edition in ALL:
		return
	var config: = ConfigFile.new()
	config.load(CHOICE)
	config.set_value("game", "edition", edition)
	if not OS.get_cmdline_user_args().has("--no-save"):
		config.save(CHOICE)
	_relaunch(edition, extra)



static func restart() -> void :
	_relaunch(id(), [])


static func _relaunch(edition: String, extra: Array) -> void :

	var args: = Array(OS.get_cmdline_args())
	args.append("--")

	for arg in OS.get_cmdline_user_args():
		if not arg.begins_with("--edition=") and not arg.begins_with("--join=") and not arg.begins_with("--crew-password="):
			args.append(arg)
	args.append("--edition=" + edition)
	args.append_array(extra)
	OS.create_instance(PackedStringArray(args))
	Game.quit()
