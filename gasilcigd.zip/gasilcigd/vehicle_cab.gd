class_name VehicleCab
extends Node3D










const MIRROR_UV: = Vector2(445.0 / 1024.0, 845.0 / 1024.0)


const MIRROR_SIZE: = [Vector2i(72, 168), Vector2i(96, 224), Vector2i(128, 288)]
const MIRROR_EVERY: = [6, 4, 2]
const MIRROR_FOV: = 34.0
const MIRROR_FAR: = 260.0
const SCREEN_SIZE: = Vector2(132, 236)

static var _found: Dictionary = {}
static var _screen: ImageTexture

var vehicle: Vehicle
var _sides: Array = []
var _live: = false
var _frame: = 0
var _level: = -1
var _fill: OmniLight3D


func _ready() -> void :
	vehicle = get_parent() as Vehicle
	var dash: = Vehicle.table(vehicle.data.get("dash"))
	if not dash.is_empty() and vehicle.data.has("steering"):
		_dress(dash)
	_find_mirrors()







func _dress(dash: Dictionary) -> void :
	var at: = Vector3(dash["pos"][0], dash["pos"][1], dash["pos"][2])
	var size: = Vector2(dash["size"][0], dash["size"][1])
	var top: = at.y - size.y / 2.0
	var face: = at.z
	var driver: = at.x
	var middle: = 0.0
	var holder: = Node3D.new()
	holder.name = "CabFittings"
	vehicle.body.add_child(holder)
	var black: = _flat(Color(0.06, 0.06, 0.07), 0.7)
	var grey: = _flat(Color(0.2, 0.21, 0.23), 0.6)


	var tablet_at: = Vector3(lerpf(driver, middle, 0.7), top + 0.4, face - 0.05)
	var tilt: = Basis(Vector3.UP, deg_to_rad(-16.0 * signf(driver))) * Basis(Vector3.RIGHT, deg_to_rad(-18.0))
	_box(holder, Vector3(0.1, 0.36, 0.1), Transform3D(Basis.IDENTITY, tablet_at + Vector3(0, -0.24, 0.08)), black)
	_box(holder, Vector3(0.78, 0.52, 0.07), Transform3D(tilt, tablet_at), black)
	var screen: = StandardMaterial3D.new()
	screen.albedo_texture = _tablet_screen()
	screen.emission_enabled = true
	screen.emission_texture = screen.albedo_texture
	screen.emission_energy_multiplier = 0.9
	screen.roughness = 0.2
	var glass: = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = Vector2(0.7, 0.44)
	glass.mesh = quad
	glass.material_override = screen
	glass.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	holder.add_child(glass)
	glass.transform = Transform3D(tilt, tablet_at) * Transform3D(Basis.IDENTITY, Vector3(0, 0, 0.04))



	var radio_at: = Vector3(middle, top + 0.17, face - 0.25)
	_box(holder, Vector3(0.9, 0.34, 0.5), Transform3D(Basis.IDENTITY, radio_at), black)
	_box(holder, Vector3(0.46, 0.13, 0.02), Transform3D(Basis.IDENTITY, radio_at + Vector3(-0.1, 0.05, 0.26)), _lit(Color(0.4, 0.95, 0.55), 1.4))
	for k in 2:
		_cylinder(holder, 0.07, 0.06, Transform3D(Basis(Vector3.RIGHT, PI / 2.0), radio_at + Vector3(0.24 + k * 0.14, 0.04, 0.27)), grey)
	var hook: = radio_at + Vector3(0.62, 0.0, 0.1)
	_box(holder, Vector3(0.24, 0.5, 0.16), Transform3D(Basis(Vector3.FORWARD, 0.15), hook), black)
	_box(holder, Vector3(0.08, 0.08, 0.08), Transform3D(Basis.IDENTITY, hook + Vector3(0, 0.12, 0.1)), _lit(Color(1.0, 0.2, 0.15), 1.2))
	for k in 6:
		var bit: = hook + Vector3(-0.08 - k * 0.07, -0.3 - sin(k * 1.3) * 0.05, 0.02)
		_box(holder, Vector3(0.05, 0.05, 0.05), Transform3D(Basis.IDENTITY, bit), black)



	var panel_at: = Vector3(lerpf(driver, middle, 0.75) + 0.0, top - 0.32, face + 0.05)
	_box(holder, Vector3(1.1, 0.36, 0.06), Transform3D(Basis.IDENTITY, panel_at), grey)
	var colours: = [Color(0.2, 0.5, 1.0), Color(0.2, 0.5, 1.0), Color(1.0, 0.65, 0.1), Color(0.2, 0.9, 0.3), Color(1.0, 0.2, 0.15), Color(0.9, 0.9, 0.9)]
	for k in colours.size():
		var x: = -0.42 + k * 0.17
		_box(holder, Vector3(0.12, 0.17, 0.05), Transform3D(Basis.IDENTITY, panel_at + Vector3(x, -0.02, 0.04)), black)
		_box(holder, Vector3(0.07, 0.03, 0.02), Transform3D(Basis.IDENTITY, panel_at + Vector3(x, 0.1, 0.04)), _lit(colours[k], 1.6))


	var gear_at: = Vector3(lerpf(driver, middle, 0.55), top - 0.85, face + 0.35)
	_box(holder, Vector3(0.36, 0.5, 0.1), Transform3D(Basis(Vector3.RIGHT, deg_to_rad(-30.0)), gear_at), black)
	for k in 3:
		_box(holder, Vector3(0.2, 0.09, 0.03), Transform3D(Basis(Vector3.RIGHT, deg_to_rad(-30.0)), gear_at + Vector3(0, 0.14 - k * 0.13, 0.06)), _lit(Color(0.95, 0.75, 0.3) if k == 0 else Color(0.5, 0.5, 0.5), 0.9 if k == 0 else 0.3))


	var papers: = Vector3( - driver * 0.75, top + 0.03, face - 0.45)
	_box(holder, Vector3(0.75, 0.04, 1.0), Transform3D(Basis(Vector3.UP, 0.25), papers), _flat(Color(0.35, 0.24, 0.14), 0.8))
	_box(holder, Vector3(0.66, 0.02, 0.86), Transform3D(Basis(Vector3.UP, 0.25), papers + Vector3(0, 0.03, 0.02)), _flat(Color(0.92, 0.92, 0.88), 0.9))
	_box(holder, Vector3(0.9, 0.12, 0.66), Transform3D(Basis(Vector3.UP, -0.12), papers + Vector3( - signf(driver) * 0.75, 0.05, 0.1)), _flat(Color(0.12, 0.32, 0.6), 0.8))


	var lamp_at: = Vector3( - driver - signf(driver) * 1.2, top + 0.12, face - 0.2)
	_box(holder, Vector3(0.3, 0.2, 0.42), Transform3D(Basis.IDENTITY, lamp_at), black)
	_box(holder, Vector3(0.26, 0.26, 0.5), Transform3D(Basis.IDENTITY, lamp_at + Vector3(0, 0.2, 0)), _flat(Color(0.95, 0.75, 0.1), 0.5))
	_box(holder, Vector3(0.05, 0.04, 0.02), Transform3D(Basis.IDENTITY, lamp_at + Vector3(0.08, 0.02, 0.22)), _lit(Color(0.2, 0.95, 0.3), 1.5))





	var top_of: = float(vehicle.data.get("top", 8.0))
	var overhead: = Vehicle.table(vehicle.data.get("overhead"))
	var ceiling: = float(overhead.get("ceiling", top_of - (0.75 if top_of > 7.0 else 0.45)))
	var above: = float(overhead.get("front", face - 0.45))
	var visor: = _flat(Color(0.16, 0.16, 0.17), 0.85)
	for x: float in [driver, - driver]:
		var hinge: = Vector3(x, ceiling - 0.12, above)
		_box(holder, Vector3(absf(driver) * 0.85, 0.06, 0.62), Transform3D(Basis(Vector3.RIGHT, deg_to_rad(18.0)), hinge + Vector3(0, -0.1, 0.28)), visor)
		_box(holder, Vector3(0.06, 0.06, 0.12), Transform3D(Basis.IDENTITY, hinge + Vector3( - signf(x) * absf(driver) * 0.4, 0, 0)), black)
	var console: = Vector3(middle, ceiling - 0.17, above + 1.2)
	_box(holder, Vector3(absf(driver) * 0.9, 0.3, 1.5), Transform3D(Basis.IDENTITY, console), grey)
	_box(holder, Vector3(absf(driver) * 0.75, 0.04, 0.5), Transform3D(Basis.IDENTITY, console + Vector3(0, -0.16, -0.4)), _flat(Color(0.04, 0.04, 0.045), 0.9))
	for x: float in [-0.5, 0.5]:
		_box(holder, Vector3(0.28, 0.04, 0.2), Transform3D(Basis.IDENTITY, console + Vector3(x * absf(driver) * 0.6, -0.16, 0.25)), _lit(Color(1.0, 0.85, 0.6), 0.5))
	for k in 4:
		_box(holder, Vector3(0.14, 0.05, 0.1), Transform3D(Basis.IDENTITY, console + Vector3(-0.33 + k * 0.22, -0.17, 0.55)), _lit(Color(0.2, 0.5, 1.0) if k < 2 else Color(1.0, 0.65, 0.1), 0.8))


	_fill = OmniLight3D.new()
	_fill.name = "CabFill"
	_fill.light_color = Color(1.0, 0.95, 0.88)
	_fill.light_energy = 0.7
	_fill.omni_range = 6.5
	_fill.omni_attenuation = 1.4
	_fill.shadow_enabled = false
	_fill.light_specular = 0.1
	_fill.visible = false
	holder.add_child(_fill)
	_fill.position = Vector3(middle, top + 2.5, face + 1.9)

	for child in holder.get_children():
		var drawn: = child as GeometryInstance3D
		if drawn != null:
			drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			drawn.visibility_range_end = 70.0


func _box(parent: Node3D, size: Vector3, place: Transform3D, material: Material) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	var box: = BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.material_override = material
	parent.add_child(mesh)
	mesh.transform = place
	return mesh


func _cylinder(parent: Node3D, radius: float, height: float, place: Transform3D, material: Material) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	var shape: = CylinderMesh.new()
	shape.top_radius = radius
	shape.bottom_radius = radius
	shape.height = height
	shape.radial_segments = 10
	shape.rings = 1
	mesh.mesh = shape
	mesh.material_override = material
	parent.add_child(mesh)
	mesh.transform = place
	return mesh


static func _flat(colour: Color, roughness: float) -> StandardMaterial3D:
	var made: = StandardMaterial3D.new()
	made.albedo_color = colour
	made.roughness = roughness
	return made



static func _lit(colour: Color, energy: float) -> StandardMaterial3D:
	var made: = _flat(colour, 0.3)
	made.emission_enabled = true
	made.emission = colour
	made.emission_energy_multiplier = energy
	return made



static func _tablet_screen() -> ImageTexture:
	if _screen != null:
		return _screen
	var image: = Image.create(160, 100, false, Image.FORMAT_RGB8)
	image.fill(Color(0.07, 0.09, 0.12))
	var street: = Color(0.32, 0.36, 0.42)
	for y in [18, 47, 80]:
		image.fill_rect(Rect2i(0, y, 160, 3), street)
	for x in [22, 70, 118]:
		image.fill_rect(Rect2i(x, 0, 3, 100), street)
	image.fill_rect(Rect2i(30, 60, 30, 14), Color(0.16, 0.3, 0.18))
	var route: = Color(0.3, 0.95, 0.4)
	image.fill_rect(Rect2i(22, 47, 98, 4), route)
	image.fill_rect(Rect2i(117, 18, 4, 32), route)
	image.fill_rect(Rect2i(112, 12, 14, 12), Color(0.95, 0.25, 0.2))
	for k in 7:
		image.fill_rect(Rect2i(18 + k, 44 + absi(3 - k), 2, 9 - 2 * absi(3 - k)), Color(0.95, 0.95, 1.0))
	image.fill_rect(Rect2i(0, 90, 160, 10), Color(0.12, 0.14, 0.2))
	image.fill_rect(Rect2i(4, 93, 40, 4), Color(0.95, 0.75, 0.2))
	_screen = ImageTexture.create_from_image(image)
	return _screen








func _find_mirrors() -> void :
	var by_side: = {-1.0: [], 1.0: []}
	for mesh: MeshInstance3D in _kit_meshes(vehicle.body):
		for glass: Array in _glass_of(mesh.mesh):
			var side: = signf(vehicle.body.to_local(mesh.global_transform * glass[0]).x)
			if side != 0.0:
				by_side[side].append([mesh, glass])
	for side: float in [-1.0, 1.0]:
		var viewport: = SubViewport.new()
		viewport.name = "Mirror%s" % ("L" if side < 0.0 else "R")
		viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		viewport.positional_shadow_atlas_size = 0
		viewport.msaa_3d = Viewport.MSAA_DISABLED
		viewport.audio_listener_enable_3d = false
		viewport.size = MIRROR_SIZE[0]
		add_child(viewport)
		var camera: = Camera3D.new()
		camera.fov = MIRROR_FOV
		camera.near = 0.3
		camera.far = MIRROR_FAR
		camera.cull_mask &= ~ PlayerCamera.OWN_LAYER
		viewport.add_child(camera)
		var picture: = StandardMaterial3D.new()
		picture.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		picture.albedo_texture = viewport.get_texture()
		picture.uv1_scale = Vector3(-1, 1, 1)
		picture.uv1_offset = Vector3(1, 0, 0)
		var quads: Array = []
		var biggest: = 0.0


		var at: = Vector3(side * (float(vehicle.data.get("halfWidth", 4.0)) + 1.0), float(vehicle.spec.get("eyeHeight", 6.0)), float(vehicle.data.get("front", -12.0)) + 1.5)
		for entry: Array in by_side[side]:
			var mesh: MeshInstance3D = entry[0]
			var glass: Array = entry[1]
			var quad: = MeshInstance3D.new()
			quad.name = "MirrorGlass"
			var plane: = QuadMesh.new()
			plane.size = glass[3]
			quad.mesh = plane
			quad.material_override = picture
			quad.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			quad.visible = false
			mesh.add_child(quad)
			var normal: Vector3 = glass[1]
			var up: Vector3 = glass[2]
			quad.transform = Transform3D(Basis(up.cross(normal), up, normal), glass[0] + normal * 0.012)
			quads.append(quad)
			var area: float = glass[3].x * glass[3].y
			if area > biggest:
				biggest = area
				at = vehicle.body.to_local(quad.global_position) + Vector3(side * 0.3, 0, 0)
		_sides.append({"sign": side, "viewport": viewport, "camera": camera, "quads": quads, "at": at})



static func _kit_meshes(node: Node) -> Array:
	var found: Array = []
	for child in node.get_children():
		if child is MeshInstance3D and String(child.name).ends_with("_interior"):
			found.append(child)
		if child.get_child_count() > 0:
			found.append_array(_kit_meshes(child))
	return found




static func _glass_of(mesh: Mesh) -> Array:
	if mesh == null:
		return []
	if _found.has(mesh):
		return _found[mesh]
	var patches: Array = []
	for surface in mesh.get_surface_count():
		var arrays: = mesh.surface_get_arrays(surface)
		var points: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var uvs: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
		var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
		var order: PackedInt32Array = arrays[Mesh.ARRAY_INDEX] if arrays[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
		if uvs.is_empty() or normals.is_empty():
			continue
		var count: = order.size() if not order.is_empty() else points.size()
		for t in range(0, count - 2, 3):
			var i: int = order[t] if not order.is_empty() else t
			var j: int = order[t + 1] if not order.is_empty() else t + 1
			var k: int = order[t + 2] if not order.is_empty() else t + 2
			if uvs[i].distance_to(MIRROR_UV) > 0.004 or uvs[j].distance_to(MIRROR_UV) > 0.004 or uvs[k].distance_to(MIRROR_UV) > 0.004:
				continue
			var normal: = normals[i] + normals[j] + normals[k]
			if normal.length() < 1e-06:
				continue
			normal = normal.normalized()
			var joined: = false
			for patch: Dictionary in patches:
				if patch["normal"].dot(normal) > 0.95 and _near(patch["points"], points[i], 0.05):
					patch["points"].append_array([points[i], points[j], points[k]])
					joined = true
					break
			if not joined:
				patches.append({"normal": normal, "points": PackedVector3Array([points[i], points[j], points[k]])})
	var glass: Array = []
	for patch: Dictionary in patches:
		var normal: Vector3 = patch["normal"]
		var up: = (Vector3.UP - normal * normal.dot(Vector3.UP))
		if up.length() < 0.2:
			continue
		up = up.normalized()
		var right: = up.cross(normal)
		var low: = Vector2(INF, INF)
		var high: = Vector2( - INF, - INF)
		var centre: = Vector3.ZERO
		for point in patch["points"]:
			var flat: = Vector2(point.dot(right), point.dot(up))
			low = Vector2(minf(low.x, flat.x), minf(low.y, flat.y))
			high = Vector2(maxf(high.x, flat.x), maxf(high.y, flat.y))
			centre += point
		centre /= patch["points"].size()
		var size: = high - low
		if size.x * size.y < 0.05:
			continue

		var middle: = (low + high) / 2.0
		var depth: = centre.dot(normal)
		glass.append([right * middle.x + up * middle.y + normal * depth, normal, up, size])
	_found[mesh] = glass
	return glass


static func _near(points: PackedVector3Array, point: Vector3, reach: float) -> bool:
	for other in points:
		if other.distance_squared_to(point) < reach * reach:
			return true
	return false



func _seen() -> bool:
	var player: = Game.local_player
	return player != null and player.seat != null and player.camera != null and player.camera.subject == vehicle and player.camera.seated_view()


func _process(_delta: float) -> void :
	var live: = _seen()
	if live != _live:
		_live = live
		for side: Dictionary in _sides:
			for quad: MeshInstance3D in side["quads"]:
				quad.visible = live
			if not live:
				side["viewport"].render_target_update_mode = SubViewport.UPDATE_DISABLED
		_show_on_screen(live)
		if _fill != null:
			_fill.visible = live
	if not live:
		return
	var level: = clampi(Settings.quality, Graphics.LOW, Graphics.HIGH)
	if level != _level:
		_level = level
		for side: Dictionary in _sides:
			side["viewport"].size = MIRROR_SIZE[level]
	_frame += 1
	var every: int = MIRROR_EVERY[level]
	var settings: Dictionary = Config.VehicleCamera
	for index in _sides.size():
		var side: Dictionary = _sides[index]

		if (_frame + index * (every / 2)) % every != 0:
			continue

		var turn: = Basis(Vector3.UP, PI + side["sign"] * deg_to_rad(float(settings["MirrorOut"]))) * Basis(Vector3.RIGHT, deg_to_rad( - float(settings["MirrorDown"])))
		var camera: Camera3D = side["camera"]
		camera.global_transform = vehicle.body.get_global_transform_interpolated() * Transform3D(turn, side["at"])
		side["viewport"].render_target_update_mode = SubViewport.UPDATE_ONCE





static var _screen_mirrors: Control
static var _screen_owner: VehicleCab



func _show_on_screen(on: bool) -> void :
	if not on:
		if _screen_owner == self and is_instance_valid(_screen_mirrors):
			_screen_mirrors.visible = false
		return
	if not is_instance_valid(_screen_mirrors):
		if Hud.current == null:
			return
		_screen_mirrors = _make_screen_mirrors()
		Hud.current.add_widget("mirrors", _screen_mirrors)
	_screen_owner = self
	_screen_mirrors.visible = true
	for side: Dictionary in _sides:
		var glass: TextureRect = _screen_mirrors.get_node("Mirror%s/Glass" % ("L" if side["sign"] < 0.0 else "R"))
		glass.texture = side["viewport"].get_texture()



static func _make_screen_mirrors() -> Control:
	var root: = Control.new()
	root.name = "Mirrors"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side: String in ["L", "R"]:
		var head: = Panel.new()
		head.name = "Mirror" + side
		head.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var housing: = StyleBoxFlat.new()
		housing.bg_color = Color(0.05, 0.05, 0.06, 0.95)
		housing.set_corner_radius_all(14)
		housing.set_border_width_all(3)
		housing.border_color = Color(0.16, 0.16, 0.18)
		head.add_theme_stylebox_override("panel", housing)

		var left: = side == "L"
		head.anchor_left = 0.15 if left else 0.85
		head.anchor_right = head.anchor_left
		head.anchor_top = 0.02
		head.anchor_bottom = 0.02
		head.offset_left = 0.0 if left else - SCREEN_SIZE.x
		head.offset_right = SCREEN_SIZE.x if left else 0.0
		head.offset_top = 0.0
		head.offset_bottom = SCREEN_SIZE.y
		root.add_child(head)
		var glass: = TextureRect.new()
		glass.name = "Glass"
		glass.mouse_filter = Control.MOUSE_FILTER_IGNORE
		glass.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		glass.stretch_mode = TextureRect.STRETCH_SCALE
		glass.flip_h = true
		glass.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 7)
		head.add_child(glass)
	return root
