extends RefCounted






const BAY: = 17.0
const DEPTH: = 19.5


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var cut: = 0
	for row in kit.rows_under("Map/Surfaces"):
		if store.name_at(row) != "paint":
			continue
		var size: = store.size(row)
		var long: = maxf(size.x, size.z)
		if absf(long - BAY) > 0.5 or minf(size.x, size.z) > 0.6:
			continue
		var place: = store.transform(row)
		var axis: = (place.basis.x if size.x > size.z else place.basis.z).normalized()
		if not _on_parking(kit, place.origin):
			continue
		var added: = DEPTH - long
		var front_free: = _on_parking(kit, place.origin + axis * (long / 2.0 + added))
		var back_free: = _on_parking(kit, place.origin - axis * (long / 2.0 + added))
		if not front_free and not back_free:
			continue

		var shift: = 0.0 if front_free and back_free else (added / 2.0 if front_free else - added / 2.0)
		place.origin += axis * shift
		store.set_transform(row, place)
		store.set_size(row, Vector3(long + added, size.y, size.z) if size.x > size.z else Vector3(size.x, size.y, long + added))
		cut += 1
	return "bays: %d bay lines re-cut to %.1f studs" % [cut, DEPTH] if cut > 0 else ""



static func _on_parking(kit: PolishKit, at: Vector3) -> bool:
	for row in kit.parts_at(Vector3(at.x, 0, at.z)):
		if kit.store.name_at(row) == "parking":
			return true
	return false
