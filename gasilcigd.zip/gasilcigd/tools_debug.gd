class_name ToolsDebug
extends Node
























var _camera: Camera3D
var _target: = ""


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--net-tools="):
			_run.call_deferred(arg.substr(12).split(","))


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds).timeout


func _side() -> String:
	return "host" if Net.is_host() else "client"


func _other() -> Player:
	for peer: int in Net.players:
		var other: Player = Net.players[peer]
		if other != Game.local_player and is_instance_valid(other):
			return other
	return null


func _tap(action: String) -> void :
	await get_tree().process_frame
	Input.action_press(action)
	await get_tree().process_frame
	await get_tree().process_frame
	Input.action_release(action)
	await get_tree().process_frame


func _house() -> House:
	var best: House = null
	var best_distance: = INF
	for building in FireService.current.buildings:
		if building is House and building.name.begins_with("Family house") and not building.ruined:
			var distance: float = building.position.distance_to(Vector3(120, 0, 40))
			if distance < best_distance:
				best = building
				best_distance = distance
	return best



func _stand_outside(house: Building, point: Vector3, off: float) -> void :
	var player: = Game.local_player
	var out: = Vector3(point.x - house.position.x, 0, point.z - house.position.z)
	var across: Vector3 = house.place.basis.x if house.place != Transform3D.IDENTITY else Vector3.RIGHT
	var deep: Vector3 = house.place.basis.z if house.place != Transform3D.IDENTITY else Vector3.BACK
	var half: = Vector3(out.dot(across), 0, out.dot(deep))
	out = (across * signf(half.x) if absf(half.x) > absf(half.z) else deep * signf(half.z))
	out = Vector3(out.x, 0, out.z).normalized()
	var from: = point + out * off
	var hit: = Game.world.raycast(from + Vector3(0, 40, 0), from - Vector3(0, 80, 0), World.LAYER_SOLID)
	player.teleport((hit["position"] if not hit.is_empty() else from) + Vector3(0, 0.3, 0))
	player.camera.yaw = atan2(out.x, out.z)
	player.camera.pitch = 0.0
	player.rig.rotation.y = player.camera.yaw


func _item(tool_name: String) -> Dictionary:
	for item: Dictionary in ToolService.current.items:
		if item["name"] == tool_name:
			return item
	return {}



func _find_line(object_name: String) -> Array:
	for vehicle in Vehicle.all:
		var lockers: = Lockers.of(vehicle)
		if lockers == null:
			continue
		for line in lockers.lines:
			if Text.say(line.object, "en") == object_name:
				return [lockers, line]
	return []



func _open_menu(lockers: Lockers) -> bool:
	var player: = Game.local_player
	var menu: LockerMenu = Hud.current.widgets["locker"]
	var handle: Dictionary = lockers.handles[0]
	var node: Node3D = handle["node"]
	var vehicle: = lockers.vehicle
	var out: = node.global_position - vehicle.global_position
	out.y = 0
	player.teleport(node.global_position + out.normalized() * 5.0 - Vector3(0, node.global_position.y - vehicle.global_position.y + 2.6, 0))
	player.camera.yaw = atan2(out.x, out.z)
	player.rig.rotation.y = player.camera.yaw
	await _wait(0.6)
	for attempt in 3:
		if menu.is_open():
			return true
		player._fire_prompt(handle["prompt"], "tap")
		for tick in 15:
			await _wait(0.1)
			if menu.is_open():
				return true
	print("net tools [%s] the lockers' menu did not come up" % _side())
	return false


func _choose(lockers: Lockers, choice: Variant) -> void :
	if await _open_menu(lockers):
		var menu: LockerMenu = Hud.current.widgets["locker"]
		menu._choose(choice)
		await _wait(0.7)


func _run(steps: PackedStringArray) -> void :
	var player: = Game.local_player
	var tools: = ToolService.current
	Game.notified.connect( func(text: Variant, kind: String, who: Player) -> void :
		if who == null or who == Game.local_player:
			print("net tools [%s] told%s: %s" % [_side(), "" if kind.is_empty() else " (" + kind + ")", Text.say(text, "en")])
	)
	await _wait(1.0)
	for step: String in steps:
		var what: = step.get_slice("=", 0)
		var value: = step.get_slice("=", 1) if step.contains("=") else ""
		match what:
			"crew":
				while Net.players.size() < 2:
					await _wait(0.2)
				await _wait(1.5)
			"wait":
				await _wait(float(value))
			"at":
				var n: = value.split_floats(":")
				var hit: = Game.world.raycast(Vector3(n[0], n[1] + 40.0, n[2]), Vector3(n[0], n[1] - 80.0, n[2]), World.LAYER_SOLID)
				player.teleport((hit["position"] if not hit.is_empty() else Vector3(n[0], n[1], n[2])) + Vector3(0, 0.3, 0))
			"near":
				var other: = _other()
				var n: = value.split_floats(":")
				if other != null:
					player.teleport(other.global_position + Vector3(n[0], 0.3, n[1]))
					var toward: = other.global_position - player.global_position
					player.camera.yaw = atan2( - toward.x, - toward.z)
					player.rig.rotation.y = player.camera.yaw
			"face":
				player.camera.yaw = deg_to_rad(float(value))
				player.camera.pitch = 0.0
				player.rig.rotation.y = player.camera.yaw
			"grab":
				var found: = _find_line(value)
				if found.is_empty():
					print("net tools [%s] no line for '%s'" % [_side(), value])
				else:
					await _choose(found[0], found[1])
			"menu":
				await _open_menu(Lockers.of(Vehicle.named(value if not value.is_empty() else "Fire Truck")))
			"unmenu":
				Hud.current.widgets["locker"].close()
			"all":
				await _choose(Lockers.of(Vehicle.named("Fire Truck")), "all")
			"shut":
				await _choose(Lockers.of(Vehicle.named("Fire Truck")), null)
			"key":
				await _tap("slot_" + value)
				await _wait(0.4)
			"click":
				await _tap("fire")
				await _wait(0.3)
			"pull":
				await get_tree().process_frame
				Input.action_press("fire")
			"let":
				Input.action_release("fire")
			"pickup":
				var item: = _item(value)
				if item.is_empty() or item["pick_up"] == null:
					print("net tools [%s] no %s standing to pick up" % [_side(), value])
				else:
					var tool: HandTool = item["tool"]
					player.teleport(tool.global_position + tool.global_basis.z * 4.0 + Vector3(0, 0.3, 0))
					await _wait(0.6)
					player._fire_prompt(item["pick_up"], "tap")
					await _wait(0.6)
			"spot":
				var other: = _other()
				if other != null and FireService.current != null:
					var at: = other.global_position + other.facing() * 8.0
					var made: Dictionary = FireService.current.spot(at + Vector3(0, 0.5, 0), func(who: Player) -> void :
						print("net tools [host] the street fire is out, by %s" % (who.name if who != null else "nobody"))
					)
					made["intensity"] = 0.3
					_watch_spot(made)
			"until":

				var bits: = value.split(":")
				for attempt in 300:
					var other: = _other()
					if other != null and str(other.get_attr(bits[0])) == bits[1]:
						break
					await _wait(0.1)
			"untilitem":

				var bits: = value.split(":")
				var swings: = -1
				for attempt in 300:
					var item: = _item(bits[0])
					var tool: Variant = item["tool"] if (item["tool"] != null and is_instance_valid(item["tool"])) else null
					if swings < 0:
						swings = int(tool.get_attr("Swing", 0)) if tool != null else 0
					var so: = false
					match bits[1]:
						"swing":
							so = tool != null and int(tool.get_attr("Swing", 0)) > swings
						"using":
							so = item["using"]
						"standing":
							so = item["standing"]
						"hand":
							so = tool != null and tool.visible and not item["standing"]
						"truck":
							so = tool == null
					if so:
						break
					await _wait(0.05)
			"lock":
				_house().lock_up(true)
			"door":

				var house: = _house()
				var door: Dictionary = house.outside_door()
				_stand_outside(house, door["lock"].global_position, 4.0)
				await _wait(1.0)
				print("net tools [%s] at the door, offered: '%s', hold %.1f s" % [_side(), Text.say(player.prompt.action, "en") if player.prompt != null else "nothing", player.prompt.hold if player.prompt != null else -1.0])
				await get_tree().process_frame
				Input.action_press("interact")
				await _wait(1.2)
				print("net tools [%s] 1.2 s into the hold: held %.1f s of %.1f, prompt %s" % [_side(), player.prompt_held.get("interact", -1.0), player.prompt.hold if player.prompt != null else -1.0, player.prompt.net_id if player.prompt != null else "none"])
				await _wait(float(Config.Tools.ForceTime) - 0.6)
				Input.action_release("interact")
				await _wait(0.8)
			"pane":
				var house: = _house()
				for room_name: String in house.rooms:
					if int(house.rooms[room_name]["floor"]) == 0 and not house.rooms[room_name]["panes"].is_empty():
						_stand_outside(house, house.rooms[room_name]["panes"][0]["position"], 4.5)
						break
				await _wait(1.0)
			"house":
				var house: = _house()
				var door: Dictionary = house.outside_door()
				var broken: = 0
				for room_name: String in house.rooms:
					for pane: Dictionary in house.rooms[room_name]["panes"]:
						if pane["broken"]:
							broken += 1
				print("net tools [%s] %s: front door locked %s, open %s; %d panes broken" % [_side(), house.name, door["locked"], door["open"], broken])
			"night":
				Sky3D.current.set_hour(23.0)
				Sky3D.current.running = false
			"view":
				_target = "" if value == "off" else value
				if _target.is_empty():
					player.camera.camera.make_current()
				elif _camera == null:
					_camera = Camera3D.new()
					_camera.fov = 45.0
					_camera.far = 4000.0
					_camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
					add_child(_camera)
			"shot":
				await get_tree().process_frame
				await RenderingServer.frame_post_draw
				get_viewport().get_texture().get_image().save_png(value)
				print("net tools [%s] shot %s" % [_side(), value])
			"print":
				_print(tools)
			"quit":
				Game.quit()
		if not what.begins_with("until"):
			await _wait(0.3)


func _watch_spot(made: Dictionary) -> void :
	var before: = float(made.get("damage", 0.0))
	for tick in 60:
		await _wait(0.5)
		var now: = float(made.get("damage", 0.0))
		if not is_equal_approx(now, before):
			print("net tools [host] the street fire is being put out: damage %.1f" % now)
			return


func _process(_delta: float) -> void :
	if _camera == null or _target.is_empty():
		return
	var who: Player = Game.local_player if _target == "me" else (_other() if _target == "other" else null)
	if who != null:
		var facing: = who.facing()
		var side: = facing.cross(Vector3.UP).normalized()
		_camera.look_at_from_position(who.global_position + facing * 10.0 + side * 4.0 + Vector3(0, 4.8, 0), who.global_position + Vector3(0, 3.2, 0))
		_camera.make_current()
	elif _target.begins_with("item:"):
		var item: = _item(_target.substr(5))
		if not item.is_empty() and item["tool"] != null and is_instance_valid(item["tool"]):
			var tool: HandTool = item["tool"]
			var ahead: = - tool.global_basis.z
			_camera.look_at_from_position(tool.global_position - ahead * 9.0 + ahead.cross(Vector3.UP) * 9.0 + Vector3(0, 6, 0), tool.global_position + ahead * 7.0)
			_camera.make_current()
	elif _target.begins_with("shelf:"):

		var lockers: = Lockers.of(Vehicle.named(_target.substr(6)))
		var node: Node3D = lockers.handles[0]["node"]
		var out: = node.global_position - lockers.vehicle.global_position
		out.y = 0
		_camera.look_at_from_position(node.global_position + out.normalized() * 22.0 + Vector3(0, 3, 0), node.global_position)
		_camera.make_current()


func _print(tools: ToolService) -> void :
	var side: = _side()
	var everybody: Array = Net.players.values() if Net.active() else [Game.local_player]
	for one: Player in everybody:
		if not is_instance_valid(one):
			continue
		var in_hand: Array = []
		for child in one.rig.hand_right.get_children():
			if child is HandTool and child.visible:
				in_hand.append("%s(Working %s, Swing %s)" % [child.tool_name, child.get_attr("Working"), child.get_attr("Swing")])
		var plates: Array = []
		for slot: Dictionary in tools.slots(one):
			plates.append("%s%s" % [slot["name"], "*" if tools.slot_in_hand(one, slot) else ""])
		print("net tools [%s] %s%s: Tool %s, forces %s, hands '%s', held '%s', trigger %s, working %d, in the hand %s, hotbar %s" % [
			side, one.name, " (me)" if one.is_local else "", one.get_attr("Tool"), one.get_attr("ToolForces"), one.holding, 
			tools.held(one), tools.trigger_held(one), tools.working(one), in_hand, plates, 
		])
	for item: Dictionary in tools.items:
		var tool: Variant = item["tool"]
		var line: LockerLine = item["line"]
		if tool == null and line.holder == null and item["prop"]["node"].visible:
			continue
		var where: = "?"
		if tool == null:
			where = "on the truck"
		elif item["standing"]:
			where = "standing at %s, lamp %s, fan %s, prompt %s" % [tool.global_position.snappedf(0.1), tool.points.has("Lamp"), tool.sounds.has("Fan") and tool.sounds["Fan"].playing, item["pick_up"].net_id if item["pick_up"] != null else "none"]
		else:
			where = "with %s, %s" % [item["holder"].name if item["holder"] != null else "nobody", "in hand" if tool.visible else "on the belt"]
		var noises: Array = []
		if tool != null:
			for sound_name: String in tool.sounds:
				if tool.sounds[sound_name].playing:
					noises.append(sound_name)
			for emitter_name: String in tool.emitters:
				if tool.emitters[emitter_name].emitting:
					noises.append(emitter_name)
		print("net tools [%s]   %s: %s; using %s; running %s; shelf piece shown %s; line '%s · %s' held by %s" % [
			side, item["name"], where, item["using"], noises, item["prop"]["node"].visible, 
			Text.say(line.action, "en"), Text.say(line.object, "en"), line.holder.name if line.holder != null else "nobody", 
		])
	var open: Array = []
	for vehicle in Vehicle.all:
		if vehicle.lockers_open():
			open.append(vehicle.name)
	print("net tools [%s]   lockers open on %s; thermal sees %d flames, %d embers, %d people; menu up %s" % [
		side, open, Flame.all.size(), Ember.all.size(), get_tree().get_nodes_in_group("Victim").size(), Hud.current.widgets["locker"].is_open(), 
	])
