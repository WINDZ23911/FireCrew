class_name House
extends Building








const DOOR_TIME: = 0.5
const BURST_TIME: = 0.28
const BOUNCE_TIME: = 0.3
const BOUNCE: = 0.07
const JOLT_TIME: = 0.4
const JOLT: = deg_to_rad(1.6)
const DOOR_THICKNESS: = 0.3
const SMOKE_DEPTH: = 3.0
const LIGHT_REACH: = 260.0
const MARKS_MOST: = 6
const MARK_SIZE: = 1.4

const OUTSIDE_DOORS: = ["FrontDoor", "BackDoor", "ShopDoor", "BankDoor", "StaffDoor", "BarDoor", "DeliveryDoor", "GardenDoor"]

const SPLINTERS: = {
	"Texture": "water_droplet", "Speed": [6, 16], "Lifetime": [0.4, 0.9], "SpreadAngle": 180, 
	"Acceleration": Vector3(0, -45, 0), "Drag": 1.5, "Rotation": [0, 360], "RotSpeed": [-400, 400], 
	"Size": [0.22, 0.08], 
}
const DUST: = {
	"Texture": "water_mist", "Color": Color(196 / 255.0, 186 / 255.0, 170 / 255.0), "Speed": [2, 6], 
	"Lifetime": [0.7, 1.3], "SpreadAngle": 180, "Rotation": [0, 360], "Size": [0.8, 3.2], "Transparency": [0.6, 1.0], 
}
const SHARDS: = {
	"Texture": "water_droplet", "Color": Color(0.75, 0.88, 0.95), "Speed": [4, 14], "Lifetime": [0.5, 1.1], 
	"SpreadAngle": 70, "Acceleration": Vector3(0, -90, 0), "Rotation": [0, 360], "RotSpeed": [-500, 500], 
	"Size": [0.5, 0.3], "Transparency": [[0.0, 0.3], [1.0, 0.6]], 
}

static var all: Array[House] = []
static var _plans: Dictionary = {}
static var _panes: Dictionary = {}
static var _watching: = false
static var _crack_material: StandardMaterial3D

var data: Dictionary
var lot: Transform3D
var part_ids: PackedInt32Array = []
var lights: Array = []
var holder: Node3D
var _lit: = true
var _near: = false
var _door_fuel: Dictionary = {}
var _leaf_colors: Dictionary = {}
var net_index: = -1
var _pane_list: Array = []
var _control: Dictionary = {}


var _barriers: Dictionary = {}
var _leaves: Dictionary = {}
static var _thermal_view: = false



static func plan_path(module: String) -> String:
	var path: = "res://data/godot/houses/%s.json" % module
	if not FileAccess.file_exists(path):
		path = "res://data/modules/houses/%s.json" % module
	return path


static func has_plan(module: String) -> bool:
	return FileAccess.file_exists(plan_path(module))



static func plan(store: PartStore, entry: Dictionary) -> House:
	var house: = House.new()
	var module: String = entry["house"]
	if not _plans.has(module):
		_plans[module] = Rbx.load_json(plan_path(module))
	house.data = _plans[module]
	house.lot = entry["lot"]
	house.record = entry
	house.name = house.data["title"]
	house.weight = entry.get("weight", 1.0)
	house.scenarios = house.data.get("scenarios", [])
	house.place = house.lot
	house.model = store.add_node(0, "Model", house.name)
	var data: Dictionary = house.data
	var colors: Array = data["colors"]
	var materials: Array = data["materials"]
	for row: Array in data["parts"]:
		var shape: = PartStore.Shape.BLOCK
		match row[0]:
			"w":
				shape = PartStore.Shape.WEDGE
			"c":
				shape = PartStore.Shape.CYLINDER
			"s":
				shape = PartStore.Shape.BALL
		var at: = house.lot * Transform3D(Basis.IDENTITY, Vector3(row[5], row[6], row[7])) * Rbx.orientation(deg_to_rad(row[8]), deg_to_rad(row[9]), deg_to_rad(row[10]))
		var bits: = int(row[14])
		var flags: = (PartStore.COLLIDE if bits % 2 == 0 else 0) | (PartStore.SHADOW if (bits / 2) % 2 == 0 else 0) | (PartStore.QUERY if bits < 4 else 0)
		var color: Array = colors[int(row[11]) - 1]
		house.part_ids.append(store.add(shape, at, Vector3(row[2], row[3], row[4]), Rbx.rgb(color), materials[int(row[12]) - 1], row[1], house.model, flags, row[13]))
	var size: Array = data["size"]
	house.position = house.lot * Vector3(0, size[1] / 2.0, 0)
	house.height = size[1]
	house.net_index = all.size()
	all.append(house)
	return house



func finish(parent: Node) -> void :
	holder = Node3D.new()
	holder.name = name
	parent.add_child(holder)
	if not _watching:
		_watching = true
		Game.water_landed.connect(_on_water)

	for info: Dictionary in data["doors"]:
		doors[info["name"]] = _create_door(info)


	for info: Dictionary in data["rooms"]:
		var low: = Rbx.v3(info["min"])
		var high: = Rbx.v3(info["max"])
		var slab: = Node3D.new()
		holder.add_child(slab)
		slab.global_transform = lot * Transform3D(Basis.IDENTITY, Vector3((low.x + high.x) / 2.0, high.y - SMOKE_DEPTH / 2.0, (low.z + high.z) / 2.0))
		rooms[info["name"]] = {
			"name": info["name"], "floor": int(info["floor"]), "low": low, "high": high, "slab": slab, 
			"smoke_position": slab.global_position, "lights": [], "panes": [], "open": info.get("open", false), 
			"area": (high.x - low.x) * (high.z - low.z), "size": Vector3(high.x - low.x, SMOKE_DEPTH, high.z - low.z), 
		}

	for info: Dictionary in data["lights"]:
		var row: int = Game.store.row_of[part_ids[int(info["part"]) - 1]]
		var lamp: = OmniLight3D.new()
		lamp.omni_range = float(info["range"]) * 1.5
		lamp.light_energy = float(info["brightness"]) * 4.0
		lamp.light_color = Rbx.rgb(info["color"])
		lamp.shadow_enabled = false
		lamp.omni_attenuation = 1.3
		lamp.visible = false
		holder.add_child(lamp)
		lamp.global_position = Game.store.position(row) - Vector3(0, 0.6, 0)
		var entry: = {"light": lamp, "room": info.get("room", "")}
		lights.append(entry)
		if rooms.has(entry["room"]):
			rooms[entry["room"]]["lights"].append(entry)

	for window: Dictionary in data["windows"]:
		var id: = part_ids[int(window["part"]) - 1]
		var pane: = _create_pane(id, window["room"])
		pane["index"] = _pane_list.size()
		_pane_list.append(pane)
		rooms[window["room"]]["panes"].append(pane)

	for opening: Dictionary in data["openings"]:
		var passes: = func() -> bool: return true
		var shut_by: Variant = null
		if opening.has("door") and doors.has(opening["door"]):
			var door: Dictionary = doors[opening["door"]]
			shut_by = door

			passes = func() -> bool: return (door["open"] or door["burnt"]) and not door.get("debris", false)
		openings.append({"a": opening["a"], "b": opening["b"], "passes": passes, "door": shut_by})

	for entry: Dictionary in data["fuel"]:
		var burning: Array = []
		if entry.has("parts"):
			for index in range(int(entry["parts"][0]), int(entry["parts"][1]) + 1):
				burning.append(part_ids[index - 1])
		var node: = {
			"name": entry["name"], "position": lot * Rbx.v3(entry["pos"]), "kind": entry["kind"], 
			"room": entry.get("room"), "parts": burning, 
		}
		if entry.has("door") and doors.has(entry["door"]):
			var door: Dictionary = doors[entry["door"]]
			burning.append(door["pseudo"])
			node["burnt"] = func() -> void : _burn_door(door)
		fuel.append(node)

	for text: Dictionary in data.get("texts", []):
		_create_text(text)

	_find_barriers()
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		_leaves[door["leaf"].get_instance_id()] = door
		door["room"] = _door_room(door) if door["outside"] else null

	var timer: = Timer.new()
	timer.wait_time = 1.0 + randf() * 0.5
	timer.autostart = true
	timer.timeout.connect(_check_near)
	holder.add_child(timer)


func has_rooms() -> bool:
	return true



func room_at(where: Vector3) -> Variant:
	var p: = lot.affine_inverse() * where
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		var low: Vector3 = room["low"]
		var high: Vector3 = room["high"]
		if p.x >= low.x and p.x <= high.x and p.y >= low.y and p.y <= high.y and p.z >= low.z and p.z <= high.z:
			return room
	return null








func _find_barriers() -> void :
	var sight: Dictionary = Config.Fire.Sight
	var burns: = {}
	for node: Dictionary in fuel:
		for id: Variant in node["parts"]:
			burns[int(id)] = true
	var store: = Game.store
	for id in part_ids:
		if burns.has(id):
			continue
		var row: int = store.row_of.get(id, -1)
		if row < 0:
			continue
		var size: = store.size(row)
		var sides: = [size.x, size.y, size.z]
		sides.sort()
		if float(sides[0]) < float(sight["Slab"]) and float(sides[1]) >= float(sight["SlabSide"]):
			_barriers[id] = true
	for pane: Dictionary in _pane_list:
		_barriers[pane["id"]] = true






func blocks(from: Vector3, to: Vector3, slack: float, panes_open: = false) -> bool:
	var at: = from
	var way: = (to - from).normalized()
	for attempt in 8:
		var hit: = Game.world.raycast(at, to, World.LAYER_QUERY)
		if hit.is_empty():
			return false
		var point: Vector3 = hit["position"]
		if point.distance_to(to) <= slack:
			return false
		var row: = Game.world.row_hit(hit)
		if row >= 0 and _barriers.has(Game.store.id_at(row)) and not (panes_open and _panes.has(Game.store.id_at(row))):
			return true
		var collider: Variant = hit.get("collider")
		if row < 0 and collider is Object and _leaves.has((collider as Object).get_instance_id()):
			return true
		at = point + way * 0.05
	return false



func _door_room(door: Dictionary) -> Variant:
	var shut: Transform3D = door["shut"]
	for side: float in [1.5, -1.5, 3.0, -3.0]:
		var room: Variant = room_at(shut.origin + shut.basis.z * side + Vector3(0, -1.0, 0))
		if room != null:
			return room["name"]
	return null




func ways_out(room_name: String) -> int:
	var room: Dictionary = rooms[room_name]
	var ways: = 1 if room.get("open", false) else 0
	for pane: Dictionary in room["panes"]:
		ways += 1 if pane["broken"] else 0
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		if door.get("room") == room_name and (door["open"] or door["burnt"]):
			ways += 1
	return ways



func open_outside_doors() -> Array:
	var found: Array = []
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		if door["outside"] and door.get("room") != null and (door["open"] or door["burnt"]):
			found.append(door)
	return found



static func door_middle(door: Dictionary) -> Vector3:
	var shut: Transform3D = door["shut"]
	return shut.origin






func _check_near() -> void :
	var camera: = holder.get_viewport().get_camera_3d()
	_near = camera != null and camera.global_position.distance_to(position) < LIGHT_REACH
	_show_lights()


func _show_lights() -> void :
	for entry: Dictionary in lights:
		entry["light"].visible = _near and _lit and not entry.get("out", false)


func set_room_lights(room_name: String, on: bool) -> void :
	rooms[room_name]["dark"] = not on
	for entry: Dictionary in rooms[room_name]["lights"]:
		entry["out"] = not on
	_show_lights()






func _create_door(info: Dictionary) -> Dictionary:
	var hinge: = lot * Transform3D(Basis.IDENTITY, Rbx.v3(info["pos"])) * Transform3D(Basis(Vector3.UP, deg_to_rad(info["yaw"])), Vector3.ZERO)
	var width: float = info["width"]
	var tall: float = info["height"]

	var offset: = Transform3D(Basis.IDENTITY, Vector3(width / 2.0, tall / 2.0, 0))
	var color: = Rbx.rgb(info["color"])
	var leaf: = PartNode.create(PartStore.Shape.BLOCK, hinge * offset, Vector3(width, tall, DOOR_THICKNESS), color, info["material"], info["name"])
	holder.add_child(leaf)
	var label: Variant = Text.named("calls.doors", info["label"])
	var prompt: = Prompt.make(leaf, Text.m("calls.door.open"), label, 0.0, 8.0)

	var lock: = Node3D.new()
	leaf.add_child(lock)
	lock.position = Vector3(width / 2.0 - 0.3, minf(3.4, tall / 2.0) - tall / 2.0, 0)
	var pseudo: = - (1000 + _door_fuel.size() + all.size() * 100)
	var door: = {
		"name": info["name"], "leaf": leaf, "prompt": prompt, "lock": lock, "info": info, "hinge": hinge, "offset": offset, 
		"open": bool(info.get("open", false)), "burnt": false, "locked": false, "shut": hinge * offset, "width": width, 
		"outside": info["name"] in OUTSIDE_DOORS, "amount": 0.0, "jolt": 0.0, "moving": false, "color": color, 
		"pseudo": pseudo, "tween": null, "forcing": {}, "padlock": false, "padlock_part": null, 
	}
	door["amount"] = 1.0 if door["open"] else 0.0
	_door_fuel[pseudo] = door
	_place_door(door)
	prompt.triggered.connect( func(player: Player) -> void : _use_door(door, player))


	prompt.condition = func(player: Player) -> bool:
		var time: = _open_time(door, player)
		prompt.hold = maxf(time, 0.0)
		prompt.gesture = "force" if time > 0.0 else ""
		prompt.action = _door_action(door, player)
		return true
	prompt.hands = lock
	prompt.hold_began.connect( func(player: Player) -> void : _force_began(door, player))
	prompt.hold_ended.connect( func(player: Player) -> void : door["forcing"].erase(player))
	return door


func _place_door(door: Dictionary) -> void :
	var info: Dictionary = door["info"]
	var leaf: PartNode = door["leaf"]
	leaf.global_transform = door["hinge"] * Transform3D(Basis(Vector3.UP, deg_to_rad(info["swing"] * door["amount"]) + door["jolt"]), Vector3.ZERO) * door["offset"]
	var prompt: Prompt = door["prompt"]
	prompt.action = _door_action(door, Game.local_player)
	prompt.hold = maxf(_open_time(door, Game.local_player), 0.0)
	_show_padlock(door)



static func _held_forcing_tool(player: Player) -> String:
	if player == null:
		return ""
	var tool: Variant = player.get_attr("Tool")
	if tool is String and player.get_attr("ToolForces", false):
		return tool
	return ""



static func _held_cutters(player: Player) -> bool:
	if player == null:
		return false
	var tool: Variant = player.get_attr("Tool")
	return tool is String and ToolService.BEHAVIOURS.get(tool, {}).get("cuts", false)





static func _open_time(door: Dictionary, player: Player) -> float:
	if not door["locked"]:
		return 0.0
	var padlock: Dictionary = Config.Tools.Padlock
	if door["padlock"] and _held_cutters(player):
		return float(padlock["CutTime"])
	if _held_forcing_tool(player) != "":

		return (float(padlock["ForceTime"]) if door["padlock"] else float(Config.Tools.ForceTime)) * Training.factor(player, "entry")
	return -1.0



static func _door_action(door: Dictionary, player: Player) -> Variant:
	if not door["locked"]:
		return Text.m("calls.door.close" if door["open"] else "calls.door.open")
	if door["padlock"] and _held_cutters(player):
		return Text.m("world.padlock.cut")
	return Text.m("calls.door.force")



func _show_padlock(door: Dictionary) -> void :
	var shown: Variant = door["padlock_part"]
	if not door["padlock"] or not door["locked"] or door["burnt"]:
		if shown is Node and is_instance_valid(shown):
			shown.queue_free()
		door["padlock_part"] = null
		return
	if shown is Node and is_instance_valid(shown):
		return
	var leaf: PartNode = door["leaf"]
	var lock: Node3D = door["lock"]

	var side: = signf(leaf.global_transform.basis.z.dot(lock.global_position - position))
	side = side if side != 0.0 else 1.0
	var face: = (DOOR_THICKNESS / 2.0) * side
	var holder_node: = Node3D.new()
	holder_node.name = "Padlock"
	lock.add_child(holder_node)


	var hasp: = Color(0.25, 0.26, 0.28)
	var steel: = Color(0.72, 0.73, 0.74)
	var brass: = Color(0.86, 0.68, 0.26)
	var out: = 0.2 * side
	var parts: = [
		[Vector3(0.9, 0.35, 0.08), Vector3(-0.2, 0.25, face + 0.04 * side), hasp, "Hasp"], 
		[Vector3(0.62, 0.7, 0.32), Vector3(0.05, -0.25, face + out), brass, "Body"], 
		[Vector3(0.12, 0.6, 0.12), Vector3(-0.15, 0.4, face + out), steel, "Shackle"], 
		[Vector3(0.12, 0.6, 0.12), Vector3(0.25, 0.4, face + out), steel, "Shackle"], 
		[Vector3(0.52, 0.12, 0.12), Vector3(0.05, 0.66, face + out), steel, "Shackle"], 
	]
	for made: Array in parts:
		var part: = PartNode.create(PartStore.Shape.BLOCK, Transform3D(Basis.IDENTITY, made[1]), made[0], made[2], "Metal", made[3], 0)
		holder_node.add_child(part)
	door["padlock_part"] = holder_node




func _knock(door: Dictionary, strength: float, chips: int, hit: = false) -> void :
	_show_knock(door, strength, chips, hit)
	Net.broadcast("house.fx", [net_index, "knock", door["name"], strength, chips, hit])


func _show_knock(door: Dictionary, strength: float, chips: int, hit: bool) -> void :
	var leaf: PartNode = door["leaf"]
	if hit:
		Sounds.once(leaf, Config.Tools.Sounds.DoorHit, 1.3, 12.0, 160.0)
	if chips > 0:
		var props: = SPLINTERS.duplicate()
		props["Color"] = door["color"].lerp(Color(226 / 255.0, 196 / 255.0, 140 / 255.0), 0.6)
		RbxEmitter.burst(door["lock"], props, chips)
	var reach: float = JOLT * strength * signf(door["info"]["swing"])
	var shudder: = leaf.create_tween()
	shudder.tween_method( func(t: float) -> void :
		if door["moving"]:
			return
		door["jolt"] = reach * (1.0 - t) * (1.0 - t) * cos(t * 16.0) if t < 1.0 else 0.0
		_place_door(door)
	, 0.0, 1.0, JOLT_TIME)


func _force_began(door: Dictionary, player: Player) -> void :
	if not door["locked"] or _held_forcing_tool(player) == "" or (door["padlock"] and _held_cutters(player)):
		return


	door["forcing"][player] = true
	var blows: = maxi(1, int(round(_open_time(door, player) / 0.7)))
	for blow in blows:
		var leaf: PartNode = door["leaf"]
		leaf.get_tree().create_timer(0.25 + blow * 0.7).timeout.connect( func() -> void :
			if door["locked"] and door["forcing"].has(player):
				_knock(door, 1.0 + blow, 6 + blow * 4, true)
				if is_instance_valid(player) and player.is_local and player.camera != null:
					player.camera.shake = maxf(player.camera.shake, 0.14)
		)


func _use_door(door: Dictionary, player: Player) -> void :
	if door["moving"] or door["burnt"]:
		return
	var forced: = false
	if door["locked"]:

		if _open_time(door, player) < 0.0:
			_knock(door, 0.4, 0)
			var why: = "calls.door.locked"
			if door["padlock"]:
				why = "world.padlock.locked"
			elif _held_cutters(player):
				why = "world.padlock.notPadlock"
			Game.notify(Text.m(why), "", player)
			return
		forced = true
		Alarm.note(player, "doors")
	_swing(door, not door["open"], forced)
	Net.broadcast("house.fx", [net_index, "swing", door["name"], door["open"], forced])




func _swing(door: Dictionary, open: bool, forced: bool) -> void :
	var leaf: PartNode = door["leaf"]
	if forced and door["padlock"]:

		door["locked"] = false
		door["padlock"] = false
		Sounds.once(leaf, Config.Tools.Sounds.MetalGive, 1.0, 12.0, 120.0)
		_show_padlock(door)
		forced = false
	elif forced:
		door["locked"] = false
		Sounds.once(leaf, Config.Tools.Sounds.Door, 1.4, 12.0, 160.0)
		var props: = SPLINTERS.duplicate()
		props["Color"] = door["color"].lerp(Color(226 / 255.0, 196 / 255.0, 140 / 255.0), 0.6)
		RbxEmitter.burst(door["lock"], props, 40)
		RbxEmitter.burst(door["lock"], DUST, 14)
	if door["tween"] is Tween and door["tween"].is_valid():
		door["tween"].kill()
	door["moving"] = true
	door["jolt"] = 0.0
	door["open"] = open
	var from: float = door["amount"]
	var to: = 1.0 if door["open"] else 0.0
	var swing: = leaf.create_tween()
	door["tween"] = swing
	if forced:

		swing.tween_method( func(elapsed: float) -> void :
			var alpha: = minf(1.0, elapsed / BURST_TIME)
			var back: = clampf((elapsed - BURST_TIME) / BOUNCE_TIME, 0.0, 1.0)
			door["amount"] = from + (to - from) * (1.0 - pow(1.0 - alpha, 3.0) - BOUNCE * sin(back * PI))
			_place_door(door)
		, 0.0, BURST_TIME + BOUNCE_TIME, BURST_TIME + BOUNCE_TIME)
	else:
		swing.tween_method( func(alpha: float) -> void :
			door["amount"] = from + (to - from) * (alpha * alpha * (3.0 - 2.0 * alpha))
			_place_door(door)
		, 0.0, 1.0, DOOR_TIME)
	swing.tween_callback( func() -> void :
		door["moving"] = false
		door["amount"] = to
		_place_door(door)
		if door.get("room") != null and rooms.has(door["room"]):
			_show_vents(rooms[door["room"]])
	)



func _burn_door(door: Dictionary) -> void :
	door["burnt"] = true
	var leaf: PartNode = door["leaf"]
	leaf.set_color(leaf.get_color(), 0.7)
	leaf.visible = false
	leaf.set_solid(false)
	door["prompt"].enabled = false


func _restore_door(door: Dictionary) -> void :
	door["burnt"] = false
	door["locked"] = false
	door["padlock"] = false
	var leaf: PartNode = door["leaf"]
	leaf.visible = true
	leaf.set_color(door["color"])
	leaf.set_solid(true)
	door["prompt"].enabled = true


	if door["tween"] is Tween and door["tween"].is_valid():
		door["tween"].kill()
	door["moving"] = false
	door["jolt"] = 0.0
	door["open"] = bool(door["info"].get("open", false))
	door["amount"] = 1.0 if door["open"] else 0.0
	_place_door(door)






func lock_up(every: = false, padlocks: = -1.0) -> void :
	var chance: float = float(Config.Tools.Padlock.Chance) if padlocks < 0.0 else padlocks
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		if (every or randf() < float(Config.Tools.LockedDoors)) and door["outside"] and not door["open"] and not door["burnt"]:
			door["locked"] = true

			var roll: = float(rand_from_seed(hash([net_index, door_name, Time.get_ticks_usec()]))[0] %10000) / 10000.0
			door["padlock"] = door_name in Config.Tools.Padlock.Doors and roll < chance
			_place_door(door)



func outside_door() -> Variant:
	var found: Variant = null
	for door_name: String in doors:
		if doors[door_name]["outside"] and (found == null or door_name == "FrontDoor"):
			found = doors[door_name]
	return found




func fit_control(words: String, hold: float, color: Color, wheel: bool, done: Callable) -> Node3D:
	var part: = _make_control(words, hold, color, wheel)
	var prompt: Prompt = part.get_meta("prompt")
	var control: = {"words": words, "hold": hold, "color": color, "wheel": wheel, "used": false, "part": part}
	_control = control
	prompt.triggered.connect( func(player: Player) -> void :
		if control["used"]:
			return
		control["used"] = true
		_show_control_used(part)
		done.call(player)
	)
	return part



func _make_control(words: String, hold: float, color: Color, wheel: bool) -> PartNode:
	var door: Dictionary = outside_door()
	var shut: Transform3D = door["shut"]

	var outward: = - shut.basis.z
	if outward.dot(shut.origin - position) < 0.0:
		outward = - outward
	var at: = _control_spot(shut, outward, door["width"], 0.35 if wheel else CallFixture.SWITCH_SIZE.z)
	var facing: = Rbx.look_at(at, at + outward)
	var part: PartNode
	if wheel:

		part = PartNode.create(PartStore.Shape.CYLINDER, facing * Transform3D(Basis(Vector3.UP, PI / 2), Vector3.ZERO), Vector3(0.35, 1.5, 1.5), color, "Metal", "FireControl", PartStore.QUERY)
	else:
		part = PartNode.create(PartStore.Shape.BLOCK, facing, CallFixture.SWITCH_SIZE, color, "Metal", "FireControl", PartStore.QUERY)
	holder.add_child(part)

	if wheel:
		CallFixture.dress_valve(part)
	else:
		CallFixture.dress_switch(part)
	var prompt: = Prompt.new()
	prompt.net_id = "house.%d.control" % net_index
	prompt.action = Text.m(words + ".action")
	prompt.object = Text.m(words + ".object")
	prompt.hold = hold
	prompt.reach = 9.0
	part.add_child(prompt)
	part.set_meta("prompt", prompt)
	return part





func _control_spot(shut: Transform3D, outward: Vector3, width: float, depth: float) -> Vector3:
	var own: = {}
	for row in Game.store.rows_under.get(model, PackedInt32Array()):
		own[row] = true
	var walls: = {}
	var wall_at: = func(point: Vector3) -> float:
		var hit: = Game.world.raycast(point + outward * 2.0, point - outward * 1.5, World.LAYER_SOLID)
		var row: = Game.world.row_hit(hit) if not hit.is_empty() else -1
		if not own.has(row):
			return INF
		walls[row] = true
		return ((hit["position"] as Vector3) - shut.origin).dot(outward)
	var half: = CallFixture.SWITCH_SIZE.x / 2.0
	for reach: float in [width / 2.0 + 1.4, - (width / 2.0 + 1.4), width / 2.0 + 2.6, - (width / 2.0 + 2.6)]:
		walls.clear()
		var middle: = shut.origin + shut.basis.x * reach
		var face: float = wall_at.call(middle)
		if absf(face) > 1.0:
			continue
		var flat: = true
		for edge: float in [ - half - 0.2, half + 0.2]:
			flat = flat and absf(float(wall_at.call(middle + shut.basis.x * edge)) - face) < 0.25
		var at: = middle + outward * (face + depth / 2.0 + 0.05)

		if flat and _clear_on_wall(Rbx.look_at(at, at + outward), CallFixture.SWITCH_SIZE - Vector3(0.1, 0.1, 0.1), walls):
			return at
	return shut.origin + shut.basis.x * (width / 2.0 + 1.4) + outward * 0.5




static func _clear_on_wall(place: Transform3D, size: Vector3, walls: Dictionary) -> bool:
	var box: = BoxShape3D.new()
	box.size = size
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = box
	query.transform = place
	query.collision_mask = World.LAYER_SOLID | World.LAYER_QUERY | World.LAYER_VEHICLE
	for hit: Dictionary in Game.world.get_world_3d().direct_space_state.intersect_shape(query, 24):
		if not walls.has(Game.world.row_hit(hit)):
			return false
	return true


func _show_control_used(part: PartNode) -> void :
	part.get_meta("prompt").enabled = false
	CallFixture.done(part)






func _create_pane(id: int, room_name: String) -> Dictionary:
	var row: int = Game.store.row_of[id]
	var place_at: = Game.store.transform(row)
	var size: = Game.store.size(row)
	var node: = Node3D.new()
	holder.add_child(node)
	node.global_transform = place_at
	var pane: = {
		"id": id, "room": room_name, "cracked": false, "broken": false, "wetted": 0.0, "node": node, 
		"position": place_at.origin, "size": size, "cracks": null, "vent": null, 
	}
	pane["crack"] = func() -> void : _crack(pane)
	pane["shatter"] = func(outward: Vector3) -> void : _shatter(pane, outward)
	_panes[id] = pane
	return pane


func _crack(pane: Dictionary) -> void :
	if pane["cracked"] or pane["broken"]:
		return
	pane["cracked"] = true
	if _crack_material == null:
		_crack_material = StandardMaterial3D.new()
		_crack_material.albedo_texture = Assets.texture("burn_cracked_glass")
		_crack_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_crack_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		_crack_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	var size: Vector3 = pane["size"]
	var quad: = QuadMesh.new()
	var cracks: = MeshInstance3D.new()
	cracks.mesh = quad
	cracks.material_override = _crack_material
	cracks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if size.z <= size.x and size.z <= size.y:
		quad.size = Vector2(size.x, size.y)
	elif size.x <= size.y:
		quad.size = Vector2(size.z, size.y)
		cracks.rotation.y = PI / 2
	else:
		quad.size = Vector2(size.x, size.z)
		cracks.rotation.x = PI / 2
	pane["node"].add_child(cracks)
	pane["cracks"] = cracks




func _shatter(pane: Dictionary, outward: Vector3, quiet: = false) -> void :
	if pane["broken"]:
		return
	pane["broken"] = true
	if not quiet:
		Net.broadcast("house.fx", [net_index, "shatter", pane["index"], outward])
	if is_instance_valid(pane["cracks"]):
		pane["cracks"].queue_free()
	pane["cracks"] = null
	Game.world.set_hidden(pane["id"], true)
	Game.world.set_solid(pane["id"], false)
	var size: Vector3 = pane["size"]
	if not quiet:
		Sounds.once(pane["node"], Config.Tools.Sounds.Glass, 1.0, 12.0, 160.0)
		var props: = SHARDS.duplicate()
		if outward.length() > 0.1:
			props["Direction"] = outward.normalized()
		else:
			props["SpreadAngle"] = 180
		props["Box"] = size
		RbxEmitter.burst(pane["node"], props, 16)
	if pane["vent"] == null:

		pane["vent"] = ToonFire.puffs(pane["node"], {
			"Color": Color(0.22, 0.21, 0.21), "Transparency": [[0.0, 0.0], [0.2, 1.0], [1.0, 1.0]], "Box": size, 
			"Speed": [1, 3], "Lifetime": [2.4, 3.4], "SpreadAngle": 180, "Acceleration": Vector3(0, 7, 0), 
			"Rotation": [0, 360], "Size": [[0.0, 0.8], [0.35, 2.2], [1.0, 0.0]], "Rate": 0, "MaxRate": 6, 
		})


func _restore_pane(pane: Dictionary) -> void :
	if is_instance_valid(pane["cracks"]):
		pane["cracks"].queue_free()
	pane["cracks"] = null
	pane["cracked"] = false
	pane["wetted"] = 0.0
	if pane["broken"]:
		pane["broken"] = false
		Game.world.set_hidden(pane["id"], false)
		Game.world.set_solid(pane["id"], true)
	if pane["vent"] != null:
		pane["vent"].set_rate(0.0)




static func _on_water(hit: Dictionary, dt: float, direction: Vector3, _player: Player) -> void :
	var row: = Game.world.row_hit(hit)
	if row < 0:
		return
	var pane: Variant = _panes.get(Game.store.id_at(row))
	if pane != null and not pane["broken"]:
		pane["wetted"] += dt
		if pane["wetted"] >= float(Config.Fire.GlassWaterTime):
			pane["shatter"].call(direction)




static func strike_glass(from: Vector3, direction: Vector3) -> bool:
	var nearest: Variant = null
	var nearest_distance: = INF
	for id: int in _panes:
		var pane: Dictionary = _panes[id]
		if pane["broken"]:
			continue
		var offset: Vector3 = pane["position"] - from
		var distance: = offset.length()
		if distance <= float(Config.Tools.GlassReach) and offset.normalized().dot(direction) > 0.3 and distance < nearest_distance:
			nearest = pane
			nearest_distance = distance
	if nearest != null:
		nearest["shatter"].call(direction)
	return nearest != null





func _room_smoke(room: Dictionary) -> RbxEmitter:
	if room.get("smoke") == null:


		room["smoke"] = RbxEmitter.make(room["slab"], {
			"Color": Color(0.2, 0.19, 0.19), "Box": room["size"] * Vector3(1, 0.5, 1), "Speed": [0.3, 1.2], 
			"Lifetime": [4.0, 6.0], "SpreadAngle": 180, "Rotation": [0, 360], "Rate": 0, 
			"MaxRate": clampf(room["area"] / 12.0, 6.0, 40.0), "Size": [[0.0, 1.0], [0.4, 3.0], [1.0, 0.0]], 
			"Mesh": ToonFire.puff_mesh(), "Material": ToonFire.room_smoke_material(), 
		})
	return room["smoke"]


func show_smoke(room_name: String, level: float) -> void :
	var room: Dictionary = rooms[room_name]
	room["level"] = level
	if level <= 0.0 and room.get("smoke") == null:
		return
	var smoke: = _room_smoke(room)


	smoke.set_rate(level * clampf(room["area"] / 24.0, 3.0, 20.0) * smoke_share())
	smoke.set_size([[0.0, 1.0 + level], [0.4, 2.5 + 2.5 * level], [1.0, 0.0]])
	smoke.visible = not _thermal_view
	_smoke_layer(room, level)
	_show_vents(room)




static func smoke_share() -> float:
	match Settings.smoke:
		Settings.SMOKE_LESS:
			return float(Config.Fire.Smoke.Reduced)
		Settings.SMOKE_MORE:
			return float(Config.Fire.Smoke.More)
	return 1.0



static func redraw_smoke() -> void :
	for house in all:
		for room_name: String in house.rooms:
			var room: Dictionary = house.rooms[room_name]
			if room.get("smoke") != null or room.get("layer") != null:
				house.show_smoke(room_name, float(room.get("level", 0.0)))



static func set_thermal_view(on: bool) -> void :
	if on == _thermal_view:
		return
	_thermal_view = on
	redraw_smoke()








func _vent_look(room: Dictionary) -> Array:
	var look: Dictionary = Config.Fire.Smoke.Look
	if room.get("water", false):
		return [Rbx.rgb(look["Water"]), float(look["WaterSpeed"])]
	if room.get("rolling", false):
		return [Rbx.rgb(look["Flashover"]), float(look["FlashoverSpeed"])]
	var hot: = clampf(float(room.get("heat", 0.0)) / float(look["HotAt"]), 0.0, 1.0)
	return [Rbx.rgb(look["Young"]).lerp(Rbx.rgb(look["Hot"]), hot), lerpf(1.0, float(look["HotSpeed"]), hot)]


func _style_vent(vent: RbxEmitter, look: Array) -> void :
	if vent.get_meta("look", []) == look:
		return
	vent.set_meta("look", look)
	vent.set_color(look[0], [[0.0, 0.0], [0.2, 1.0], [1.0, 1.0]])
	vent.speed_scale = float(look[1])




func _show_vents(room: Dictionary) -> void :
	var level: float = float(room.get("level", 0.0)) * smoke_share()
	var look: = _vent_look(room)
	for pane: Dictionary in room["panes"]:
		if pane["broken"] and pane["vent"] != null:
			pane["vent"].set_rate(7.0 * level)
			_style_vent(pane["vent"], look)
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		if door.get("room") != room["name"]:
			continue
		var open: bool = door["open"] or door["burnt"]
		if open and level > 0.0 and door.get("vent") == null:

			var mouth: = Node3D.new()
			holder.add_child(mouth)
			var shut: Transform3D = door["shut"]
			mouth.global_position = shut.origin + Vector3(0, float(door["info"]["height"]) * 0.35, 0)
			door["vent"] = ToonFire.puffs(mouth, {
				"Color": Color(0.22, 0.21, 0.21), "Transparency": [[0.0, 0.0], [0.2, 1.0], [1.0, 1.0]], 
				"Box": Vector3(door["width"], 1.5, 1.0), "Speed": [1, 3], "Lifetime": [2.4, 3.4], "SpreadAngle": 180, 
				"Acceleration": Vector3(0, 7, 0), "Rotation": [0, 360], "Size": [[0.0, 0.8], [0.35, 2.2], [1.0, 0.0]], 
				"Rate": 0, "MaxRate": 8, 
			})
		if door.get("vent") != null:
			door["vent"].set_rate(8.0 * level if open else 0.0)
			_style_vent(door["vent"], look)







func set_read(room_name: String, key: String, on: bool) -> void :
	var room: Dictionary = rooms[room_name]
	if bool(room.get(key, false)) == on:
		return
	room[key] = on
	if key == "water":
		_show_vents(room)
	elif key == "breathing":
		_show_breathing(room, on)
	elif key == "weak":
		_show_weak(room, on)
	elif key == "searched" or key == "cleared":
		_show_mark(room)



func _show_weak(room: Dictionary, on: bool) -> void :
	if is_instance_valid(room.get("weak_decal")):
		(room["weak_decal"] as Node).queue_free()
	room.erase("weak_decal")
	if not on:
		return
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var middle: = Vector3((low.x + high.x) / 2.0, low.y + _floor_of(room) + 0.5, (low.z + high.z) / 2.0)
	var decal: = _soot_decal(_soot_texture(), Transform3D(Basis.IDENTITY, middle), Vector3((high.x - low.x) * 0.7, 3.0, (high.z - low.z) * 0.7))
	decal.modulate = Color(0.55, 0.22, 0.08)
	decal.emission_energy = 0.0
	room["weak_decal"] = decal





static var _mark_pictures: Dictionary = {}





func _show_mark(room: Dictionary) -> void :
	var shape: = "" if not room.get("searched", false) else ("x" if room.get("cleared", false) else "slash")
	var mark: Variant = room.get("mark")
	if shape.is_empty():
		if mark is Node and is_instance_valid(mark):
			(mark as Node).queue_free()
		room.erase("mark")
		return
	if not (mark is Decal and is_instance_valid(mark)):
		var shown: = 0
		for other: Dictionary in rooms.values():
			shown += 1 if other.get("mark") is Decal and is_instance_valid(other["mark"]) else 0
		var place: Variant = _mark_place(room["name"])
		if shown >= MARKS_MOST or place == null:
			return
		var decal: = Decal.new()
		decal.name = "SearchMark"
		decal.size = Vector3(MARK_SIZE, 1.2, MARK_SIZE)
		decal.upper_fade = 0.0
		decal.lower_fade = 0.0
		decal.normal_fade = 0.5
		decal.cull_mask = 1
		decal.distance_fade_enabled = true
		decal.distance_fade_begin = 70.0
		decal.distance_fade_length = 20.0
		holder.add_child(decal)
		decal.global_transform = place
		room["mark"] = decal
		mark = decal
	(mark as Decal).texture_albedo = _mark_texture(shape)






func _mark_place(room_name: String) -> Variant:
	var door: Variant = null
	var from: = ""
	for opening: Dictionary in openings:
		if opening["door"] != null and opening["a"] == room_name:
			door = opening["door"]
			from = opening["b"]
			break
	if door == null:
		for door_name: String in doors:
			if doors[door_name].get("room") == room_name:
				door = doors[door_name]
				break
	if door == null:
		return null
	var shut: Transform3D = door["shut"]
	var tall: float = door["info"]["height"]
	var across: = shut.basis.x.normalized()
	var face: = shut.basis.z.normalized()

	var ahead: Variant = room_at(shut.origin + face * 1.5 + Vector3(0, -1.0, 0))
	var toward: bool = (ahead != null and ahead["name"] == from) if not from.is_empty() else ahead == null
	if not toward:
		face = - face
	var at: = shut.origin + across * (float(door["width"]) / 2.0 + 1.0 + MARK_SIZE / 2.0) + Vector3(0, - tall / 6.0, 0)

	return Transform3D(Basis(across, face, across.cross(face)), at)




static func _mark_texture(shape: String) -> ImageTexture:
	if _mark_pictures.has(shape):
		return _mark_pictures[shape]
	var grain: = FastNoiseLite.new()
	grain.noise_type = FastNoiseLite.TYPE_VALUE
	grain.frequency = 0.35
	grain.seed = 1869
	var size: = 64
	var picture: = Image.create(size, size, false, Image.FORMAT_RGBA8)
	for y in size:
		for x in size:
			var u: = (x + 0.5) / size
			var v: = (y + 0.5) / size

			var near: = absf(u - (1.0 - v)) / sqrt(2.0)
			if shape == "x":
				near = minf(near, absf(u - v) / sqrt(2.0))
			var inside: = 1.0 - smoothstep(0.06, 0.09, near + grain.get_noise_2d(x * 3.0, y) * 0.012)

			inside *= 1.0 - smoothstep(0.38, 0.46, maxf(absf(u - 0.5), absf(v - 0.5)))
			var patchy: = 0.55 + 0.45 * (grain.get_noise_2d(x * 7.0, y * 7.0) * 0.5 + 0.5)
			picture.set_pixel(x, y, Color(Ui.YELLOW, clampf(inside * patchy * 1.3, 0.0, 1.0)))
	picture.generate_mipmaps()
	var texture: = ImageTexture.create_from_image(picture)
	_mark_pictures[shape] = texture
	return texture




func block_door(door_name: String, on: bool) -> void :
	if not doors.has(door_name):
		return
	var door: Dictionary = doors[door_name]
	if bool(door.get("debris", false)) == on:
		return
	door["debris"] = on
	if is_instance_valid(door.get("debris_node")):
		(door["debris_node"] as Node).queue_free()
	door.erase("debris_node")
	if not on:
		return
	var frame: Transform3D = door["shut"]
	var width: float = door["width"]
	var tall: float = float(door["info"]["height"])
	var pile: = Node3D.new()
	pile.name = "Debris"
	holder.add_child(pile)
	pile.global_transform = Transform3D(frame.basis.orthonormalized(), frame.origin)
	var charred: = Color(0.12, 0.1, 0.09)
	var plaster: = Color(0.42, 0.4, 0.37)

	var pieces: = [
		[Vector3(width + 1.2, 3.8, 2.6), Vector3(0, - tall / 2.0 + 1.9, 0), Basis.IDENTITY, plaster, "Concrete"], 
		[Vector3(width + 1.8, 0.7, 0.7), Vector3(0, - tall / 2.0 + 4.2, 0.4), Basis(Vector3.BACK, 0.42), charred, "Wood"], 
		[Vector3(width + 1.4, 0.6, 0.6), Vector3(0.3, - tall / 2.0 + 3.4, -0.6), Basis(Vector3.BACK, -0.35) * Basis(Vector3.UP, 0.2), charred, "Wood"], 
		[Vector3(1.6, 1.0, 1.4), Vector3( - width / 2.0 + 0.4, - tall / 2.0 + 4.1, 0.2), Basis(Vector3.UP, 0.6), plaster, "Concrete"], 
	]
	for piece: Array in pieces:
		var part: = PartNode.create(PartStore.Shape.BLOCK, Transform3D(piece[2], piece[1]), piece[0], piece[3], piece[4], "Debris", PartStore.COLLIDE | PartStore.QUERY | PartStore.SHADOW)
		pile.add_child(part)
	var prompt: = Prompt.new()
	prompt.net_id = "house.%d.debris.%s" % [net_index, door_name]
	prompt.object = Text.m("calls.fire.events.debris")
	prompt.action = Text.m("calls.fire.events.clear")
	prompt.hold = float(Config.Fire.Events.Ceiling.Clear)
	prompt.reach = 9.0
	prompt.position = Vector3(0, - tall / 2.0 + 3.0, 0)
	pile.add_child(prompt)
	prompt.triggered.connect( func(player: Player) -> void :
		if Net.is_client():
			return
		block_door(door_name, false)
		Game.notify(Text.f("calls.fire.events.cleared", [player.display_name]), "good")
	)
	door["debris_node"] = pile




func _show_breathing(room: Dictionary, on: bool) -> void :
	var puffs: Array = room.get("breaths", [])
	for made: Variant in puffs:
		if is_instance_valid(made):
			(made as Node).get_parent().queue_free()
	room["breaths"] = []
	if not on:
		return
	var places: Array = []
	for pane: Dictionary in room["panes"]:
		if not pane["broken"]:
			places.append([pane["position"] + Vector3(0, float(pane["size"].y) * 0.5, 0), Vector3(maxf(pane["size"].x, pane["size"].z), 0.4, 0.6)])
	for opening: Dictionary in openings:
		var door: Variant = opening.get("door")
		if door is Dictionary and (opening["a"] == room["name"] or opening["b"] == room["name"]):
			var shut: Transform3D = door["shut"]
			places.append([shut.origin + Vector3(0, float(door["info"]["height"]) * 0.5, 0), Vector3(door["width"], 0.3, 0.8)])
	for place: Array in places:
		var mouth: = Node3D.new()
		holder.add_child(mouth)
		mouth.global_position = place[0]
		puffs.append(ToonFire.puffs(mouth, {
			"Color": Rbx.rgb(Config.Fire.Smoke.Look["Breathing"]), "Transparency": [[0.0, 0.0], [0.3, 1.0], [1.0, 1.0]], 
			"Box": place[1], "Speed": [0.5, 1.5], "Lifetime": [1.4, 2.2], "SpreadAngle": 180, "Acceleration": Vector3(0, 2, 0), 
			"Rotation": [0, 360], "Size": [[0.0, 0.4], [0.4, 1.3], [1.0, 0.0]], "Rate": 0, "MaxRate": 10, 
		}))
	room["breaths"] = puffs
	if _breath_timer == null:
		_breath_timer = Timer.new()
		_breath_timer.wait_time = 0.15
		_breath_timer.autostart = true
		_breath_timer.timeout.connect(_breathe)
		holder.add_child(_breath_timer)


var _breath_timer: Timer



func _breathe() -> void :
	var beat: = float(Config.Fire.Smoke.BreathEvery)
	for room_name: String in rooms:
		var puffs: Array = rooms[room_name].get("breaths", [])
		if puffs.is_empty():
			continue
		var phase: = fmod(Game.now(), beat) / beat
		var out: = maxf(0.0, sin(phase * TAU))
		for made: Variant in puffs:
			if is_instance_valid(made):
				(made as RbxEmitter).set_rate(10.0 * out * out * smoke_share())
				(made as RbxEmitter).speed_scale = 0.6 + 1.2 * out




func _smoke_layer(room: Dictionary, level: float) -> void :
	var layer: MeshInstance3D = room.get("layer")
	if layer == null:
		if level <= 0.0:
			return
		var low: Vector3 = room["low"]
		var high: Vector3 = room["high"]
		layer = MeshInstance3D.new()
		var box: = BoxMesh.new()
		box.size = Vector3.ONE
		layer.mesh = box
		layer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var inset: = Vector3(0.25, 0.1, 0.25)
		var size: = high - low - inset * 2.0
		var material: = ShaderMaterial.new()
		material.shader = _layer_shader()
		material.set_shader_parameter("noise", Ground.noise())
		material.render_priority = -10
		layer.material_override = material
		holder.add_child(layer)
		layer.global_transform = lot * Transform3D(Basis.IDENTITY.scaled(size), (low + high) / 2.0)
		layer.set_meta("height", size.y)
		room["layer"] = layer
		if _layer_timer == null:

			_layer_timer = Timer.new()
			_layer_timer.wait_time = 0.4
			_layer_timer.autostart = true
			_layer_timer.timeout.connect(_refresh_layers)
			holder.add_child(_layer_timer)
	layer.visible = level > 0.0 and not _thermal_view
	if not layer.visible:
		return
	var material: ShaderMaterial = layer.material_override
	material.set_shader_parameter("bottom", layer_bottom(level, float(room["high"].y - room["low"].y), _floor_of(room)))
	material.set_shader_parameter("density", layer_density(level) * smoke_share())
	room["layer_level"] = level
	_light_layer(room)




func show_scorch(room_name: String, level: float) -> void :
	var room: Dictionary = rooms[room_name]
	room["scorch"] = level
	var decals: Array = room.get("soot", [])
	if decals.is_empty():
		if level <= 0.0:
			return
		var low: Vector3 = room["low"]
		var high: Vector3 = room["high"]
		var size: = high - low
		var middle: = (low + high) / 2.0
		var soot: = _soot_texture()
		var wall_soot: = _soot_texture(true)

		decals.append(_soot_decal(soot, Transform3D(Basis(Vector3.RIGHT, PI), Vector3(middle.x, high.y - 0.8, middle.z)), Vector3(size.x, 2.4, size.z)))

		var up_middle: = low.y + size.y * 0.62
		for side: Array in [[Vector3.RIGHT, size.z, size.x], [Vector3.LEFT, size.z, size.x], [Vector3.BACK, size.x, size.z], [Vector3.FORWARD, size.x, size.z]]:
			var out: Vector3 = side[0]


			var y_axis: = - out
			var z_axis: = Vector3.UP
			var x_axis: = y_axis.cross(z_axis).normalized()
			var at: = Vector3(middle.x, up_middle, middle.z) + out * (float(side[2]) / 2.0 - 1.0)
			decals.append(_soot_decal(wall_soot, Transform3D(Basis(x_axis, y_axis, z_axis), at), Vector3(float(side[1]), 2.8, size.y * 0.8)))
		room["soot"] = decals
	for decal: Decal in decals:
		decal.visible = level > 0.0
		decal.modulate = Color(1, 1, 1, clampf(level * 1.1, 0.0, 0.95))


static var _soot_pictures: Array[ImageTexture] = []




static func _soot_texture(fading: = false) -> ImageTexture:
	if _soot_pictures.is_empty():
		var source: = FastNoiseLite.new()
		source.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		source.frequency = 0.03
		source.fractal_octaves = 4
		source.seed = 401
		for fade in 2:
			var picture: = Image.create(128, 128, false, Image.FORMAT_RGBA8)
			for y in 128:


				var down: = 1.0 - float(y) / 127.0
				var keep: = 1.0 if fade == 0 else clampf((1.0 - down) / 0.55, 0.0, 1.0)
				keep = keep * keep * (3.0 - 2.0 * keep)
				for x in 128:
					var n: = source.get_noise_2d(x * 2.0, y * 2.0) * 0.5 + 0.5
					var alpha: = clampf(0.25 + n * 0.95, 0.0, 1.0) * keep
					picture.set_pixel(x, y, Color(0.025, 0.022, 0.02, alpha))
			picture.generate_mipmaps()
			_soot_pictures.append(ImageTexture.create_from_image(picture))
	return _soot_pictures[1 if fading else 0]


func _soot_decal(texture: Texture2D, place: Transform3D, size: Vector3) -> Decal:
	var decal: = Decal.new()
	decal.texture_albedo = texture
	decal.size = size
	decal.upper_fade = 0.15
	decal.lower_fade = 0.15
	decal.normal_fade = 0.4
	decal.cull_mask = 1
	decal.albedo_mix = 1.0
	holder.add_child(decal)
	decal.global_transform = lot * place
	return decal






static func layer_bottom(level: float, tall: = 11.0, floor: = 0.0) -> float:
	var lowest: = clampf((floor + float(Config.Fire.Smoke.LowestStuds)) / maxf(tall, 1.0), 0.0, 0.86)
	return maxf(1.0 - (0.14 + 0.76 * level), lowest)



func _floor_of(room: Dictionary) -> float:
	if room.has("floor_over"):
		return float(room["floor_over"])
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var top: = lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0)
	var hit: = Game.world.raycast(top, top - Vector3(0, 6.0, 0), World.LAYER_SOLID)
	var over: = 0.0
	if not hit.is_empty():
		over = clampf((lot.affine_inverse() * (hit["position"] as Vector3)).y - low.y, 0.0, 3.0)
	room["floor_over"] = over
	return over




static func layer_density(level: float) -> float:
	var smoke: Dictionary = Config.Fire.Smoke
	return 0.04 + 0.26 * level + float(smoke["Blind"]) * smoothstep(float(smoke["BlindFrom"]), 1.0, level)



func below_smoke(room: Dictionary, at: Vector3) -> bool:
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var p: = lot.affine_inverse() * at
	return p.y < low.y + (high.y - low.y) * layer_bottom(float(room.get("level", 0.0)), high.y - low.y, _floor_of(room)) - 0.4



func _light_layer(room: Dictionary) -> void :
	var layer: MeshInstance3D = room.get("layer")
	if layer == null or not layer.visible:
		return
	var material: ShaderMaterial = layer.material_override
	var day: = Sky3D.current.daylight() if Sky3D.current else 1.0
	material.set_shader_parameter("light", lerpf(0.25, 1.0, day))
	var heat: float = room.get("heat", 0.0)
	material.set_shader_parameter("glow", Vector3(0.11, 0.035, 0.008) * clampf(heat, 0.0, 1.5) + room.get("flash_glow", Vector3.ZERO))


var _layer_timer: Timer




func _refresh_layers() -> void :
	var heat: Dictionary = {}
	for flame in Flame.all:
		if not is_instance_valid(flame) or flame.global_position.distance_to(position) > 80.0:
			continue
		var inside: Variant = room_at(flame.global_position)
		if inside != null:
			heat[inside["name"]] = heat.get(inside["name"], 0.0) + 0.25 + 0.75 * flame.intensity
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		if room.get("layer") != null:
			room["heat"] = heat.get(room_name, 0.0)
			_light_layer(room)
			if float(room.get("level", 0.0)) > 0.0:
				_show_vents(room)


static var _layer_shader_cache: Shader


static func _layer_shader() -> Shader:
	if _layer_shader_cache == null:
		_layer_shader_cache = load("res://shaders/smoke_layer.gdshader")
	return _layer_shader_cache



func show_flashover(room_name: String, on: bool) -> void :
	var room: Dictionary = rooms[room_name]
	room["rolling"] = on
	if room.get("rollover") == null:
		if not on:
			return


		var sheet: Vector3 = room["size"] * Vector3(0.9, 0.3, 0.9)
		room["rollover"] = RbxEmitter.make(room["slab"], {
			"Color": [Color(1.0, 0.3, 0.01), Color(0.55, 0.02, 0.003)], "Box": sheet, "Speed": [1, 3], 
			"Lifetime": [0.8, 1.4], "SpreadAngle": 180, "Rotation": [0, 360], "Size": [[0.0, 0.8], [0.4, 2.6], [1.0, 0.0]], 
			"Rate": clampf(room["area"] / 5.0, 16.0, 50.0), "Mesh": ToonFire.puff_mesh(), "Material": ToonFire.fireball_material(), 
		})
		room["rolling_tongues"] = RbxEmitter.make(room["slab"], {
			"Color": [Color(1.0, 0.55, 0.05), Color(1.0, 0.2, 0.01)], "Box": sheet, "Speed": [6, 12], 
			"Lifetime": [0.5, 0.9], "SpreadAngle": 70, "Direction": Vector3(1, -0.25, 0.4).normalized(), 
			"Size": [[0.0, 0.5], [0.5, 1.4], [1.0, 0.0]], "Rate": clampf(room["area"] / 8.0, 10.0, 30.0), 
			"Mesh": ToonFire.puff_mesh(), "Material": ToonFire.fireball_material(), 
		})
	room["rollover"].emitting = on
	if room.get("rolling_tongues") != null:
		room["rolling_tongues"].emitting = on


	if on and room.get("warn_sound") == null:
		room["warn_sound"] = Sounds.emitter(room["slab"], Sounds.loop("flashover_rumble"), 0.0001, 12.0, 160.0, true)
	if on:
		room["warn_since"] = Game.now()
		if _warn_timer == null:
			_warn_timer = Timer.new()
			_warn_timer.wait_time = 0.1
			_warn_timer.autostart = true
			_warn_timer.timeout.connect(_warn_step)
			holder.add_child(_warn_timer)
	else:
		_end_warning(room)


var _warn_timer: Timer


func _warn_step() -> void :
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		if not room.get("rolling", false):
			continue
		var t: = clampf((Game.now() - float(room.get("warn_since", Game.now()))) / float(FireService.current.settings()["FlashoverWarning"]) if FireService.current else 0.5, 0.0, 1.0)
		var sound: AudioStreamPlayer3D = room.get("warn_sound")
		if is_instance_valid(sound):
			sound.volume_db = linear_to_db(0.15 + 0.85 * t)
		var pulse: = 0.75 + 0.25 * sin(Game.now() * (6.0 + 10.0 * t))
		room["flash_glow"] = Vector3(0.35, 0.12, 0.02) * t * pulse
		_light_layer(room)


func _end_warning(room: Dictionary) -> void :
	var sound: AudioStreamPlayer3D = room.get("warn_sound")
	if is_instance_valid(sound):
		sound.queue_free()
	room["warn_sound"] = null
	room["flash_glow"] = Vector3.ZERO
	_light_layer(room)




func show_flash(room_name: String) -> void :
	var room: Dictionary = rooms[room_name]
	_end_warning(room)
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var middle: Vector3 = lot * ((low + high) / 2.0)
	var box: = Vector3(high.x - low.x, high.y - low.y, high.z - low.z)
	var holder_node: = Node3D.new()
	holder.add_child(holder_node)
	holder_node.global_transform = Transform3D(lot.basis, middle)

	RbxEmitter.burst(holder_node, {
		"Color": [Color(1.0, 0.3, 0.01), Color(0.55, 0.02, 0.003)], "Box": box * 0.9, "Speed": [3, 10], 
		"Lifetime": [0.6, 1.3], "SpreadAngle": 180, "Rotation": [0, 360], "Size": [[0.0, 1.5], [0.4, 3.5], [1.0, 0.0]], 
		"Mesh": ToonFire.puff_mesh(), "Material": ToonFire.fireball_material(), 
	}, clampi(int(room["area"] / 3.0), 20, 90))

	for pane: Dictionary in room["panes"]:
		var at: Vector3 = pane["position"]
		var out: = (at - middle) * Vector3(1, 0, 1)
		out = out.normalized() if out.length() > 0.1 else Vector3.FORWARD
		var mouth: = Node3D.new()
		holder_node.add_child(mouth)
		mouth.global_position = at
		var jet: = RbxEmitter.make(mouth, {
			"Color": [Color(1.0, 0.45, 0.02), Color(0.6, 0.03, 0.005)], "Speed": [10, 18], "Lifetime": [0.5, 1.0], 
			"SpreadAngle": 25, "Direction": (out + Vector3(0, 0.6, 0)).normalized(), "Acceleration": Vector3(0, 18, 0), 
			"Size": [[0.0, 1.2], [0.4, 3.2], [1.0, 0.0]], "Rate": 30, "MaxRate": 30, "Box": Vector3(2.5, 2.5, 2.5), 
			"Mesh": ToonFire.puff_mesh(), "Material": ToonFire.fireball_material(), 
		})
		jet.get_tree().create_timer(2.6).timeout.connect( func() -> void : if is_instance_valid(jet): jet.set_rate(0.0))
	var flash: = OmniLight3D.new()
	flash.light_color = Color(1.0, 0.62, 0.3)
	flash.omni_range = 45.0
	flash.light_energy = 30.0
	flash.shadow_enabled = false
	holder_node.add_child(flash)
	var fade: = flash.create_tween()
	fade.tween_property(flash, "light_energy", 0.0, 1.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
	Sounds.once_at(middle, "flashover_boom", 1.0, 16.0, 260.0)
	var player: = Game.local_player
	if player and player.camera:
		var near: = clampf(1.0 - middle.distance_to(player.head_position()) / 35.0, 0.0, 1.0)
		player.camera.shake = maxf(player.camera.shake, 0.8 * near)
	holder_node.get_tree().create_timer(5.0).timeout.connect(holder_node.queue_free)





func shade(id: int, share: float) -> void :
	if _door_fuel.has(id):
		var door: Dictionary = _door_fuel[id]
		door["leaf"].set_color(door["color"].lerp(CHARRED, share))
		return
	super.shade(id, share)


func restore_colors() -> void :
	super.restore_colors()
	for id: int in _door_fuel:
		_door_fuel[id]["leaf"].set_color(_door_fuel[id]["color"])



func set_charred(black: bool) -> void :
	charred = black
	var store: = Game.store
	for id in part_ids:
		var row: int = store.row_of[id]
		if store.material(row) == "Glass" or store.transparency(row) >= 0.99:
			continue
		_remember(id)
		Game.world.set_color(id, _original[id].lerp(CHARRED, 0.85) if black else _original[id])
	for id: int in _door_fuel:
		var door: Dictionary = _door_fuel[id]
		door["leaf"].set_color(door["color"].lerp(CHARRED, 0.85) if black else door["color"])
	_lit = not black
	_show_lights()
	show_collapse(black)


func own_rows() -> PackedInt32Array:
	var rows: = PackedInt32Array()
	for id in part_ids:
		rows.append(Game.store.row_of[id])
	return rows



func restore() -> void :
	for door_name: String in doors:
		block_door(door_name, false)
		_restore_door(doors[door_name])
		if doors[door_name].get("vent") != null:
			doors[door_name]["vent"].set_rate(0.0)
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		for pane: Dictionary in room["panes"]:
			_restore_pane(pane)
		for entry: Dictionary in room["lights"]:
			entry["out"] = false
		room["level"] = 0.0
		room["dark"] = false
		set_read(room_name, "water", false)
		set_read(room_name, "breathing", false)
		set_read(room_name, "searched", false)
		set_read(room_name, "cleared", false)
		set_read(room_name, "weak", false)
		set_read(room_name, "lost", false)
		show_scorch(room_name, 0.0)
		_smoke_layer(room, 0.0)
		if room.get("smoke") != null:
			room["smoke"].set_rate(0.0)


		show_flashover(room_name, false)
	_show_lights()











func net_state() -> Dictionary:
	var state: = super.net_state()
	var changed: = false
	var bits: = PackedByteArray()
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		bits.append((1 if door["open"] else 0) + (2 if door["locked"] else 0) + (4 if door["burnt"] else 0) + (8 if door["padlock"] else 0) + (16 if door.get("debris", false) else 0))
		changed = changed or door["locked"] or door["burnt"] or door["open"] != bool(door["info"].get("open", false)) or door.get("debris", false)
	if changed:
		state["dr"] = bits
	changed = false
	bits = PackedByteArray()
	for pane: Dictionary in _pane_list:
		bits.append(2 if pane["broken"] else (1 if pane["cracked"] else 0))
		changed = changed or pane["broken"] or pane["cracked"]
	if changed:
		state["pn"] = bits
	changed = false
	bits = PackedByteArray()
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		var level: = int(round(float(room.get("level", 0.0)) * 20.0))
		var flags: = (1 if room.get("rolling", false) else 0) + (2 if room.get("dark", false) else 0)\
		+ (4 if room.get("water", false) else 0) + (8 if room.get("breathing", false) else 0)\
		+ (16 if room.get("searched", false) else 0) + (32 if room.get("weak", false) else 0)\
		+ (64 if room.get("lost", false) else 0) + (128 if room.get("cleared", false) else 0)
		bits.append(level)
		bits.append(flags)
		changed = changed or level > 0 or flags > 0
	if changed:
		state["rm"] = bits
	changed = false
	bits = PackedByteArray()
	for room_name: String in rooms:
		var scorch: = int(round(float(rooms[room_name].get("scorch", 0.0)) * 10.0))
		bits.append(scorch)
		changed = changed or scorch > 0
	if changed:
		state["sc"] = bits
	if not _control.is_empty():
		var part: Variant = _control["part"]
		if is_instance_valid(part) and not part.is_queued_for_deletion():
			state["ct"] = [_control["words"], _control["hold"], _control["color"], _control["wheel"], _control["used"]]
		else:
			_control = {}
	return state


func net_apply(state: Dictionary, nodes: Array, quiet: = false) -> void :
	var told: PackedByteArray = state.get("dr", PackedByteArray())
	var at: = 0
	for door_name: String in doors:
		var door: Dictionary = doors[door_name]
		var bits: = int(told[at]) if at < told.size() else (1 if door["info"].get("open", false) else 0)
		at += 1
		var burnt: = bits & 4 != 0
		if burnt != door["burnt"]:
			if burnt:
				_burn_door(door)
			else:
				_restore_door(door)
		if (bits & 2 != 0) != door["locked"] or (bits & 8 != 0) != door["padlock"]:
			door["locked"] = bits & 2 != 0
			door["padlock"] = bits & 8 != 0
			_place_door(door)
		block_door(door_name, bits & 16 != 0)
		var open: = bits & 1 != 0
		if open != door["open"]:
			if quiet:
				door["open"] = open
				door["amount"] = 1.0 if open else 0.0
				_place_door(door)
			else:
				_swing(door, open, false)
	told = state.get("pn", PackedByteArray())
	var glass_went: = false
	for index in _pane_list.size():
		var pane: Dictionary = _pane_list[index]
		var how: = int(told[index]) if index < told.size() else 0
		glass_went = glass_went or (how == 2 and not pane["broken"])
		if how == 2:
			_shatter(pane, Vector3.ZERO, quiet)
		elif how == 1:
			if pane["broken"]:
				_restore_pane(pane)
			_crack(pane)
		elif pane["broken"] or pane["cracked"]:
			_restore_pane(pane)
	told = state.get("rm", PackedByteArray())
	at = 0
	for room_name: String in rooms:
		var room: Dictionary = rooms[room_name]
		var level: = (told[at] / 20.0) if at + 1 < told.size() else 0.0
		var flags: = int(told[at + 1]) if at + 1 < told.size() else 0
		at += 2
		if not is_equal_approx(level, float(room.get("level", 0.0))) or (glass_went and level > 0.0):
			show_smoke(room_name, level)
		if (flags & 1 != 0) != bool(room.get("rolling", false)):
			show_flashover(room_name, flags & 1 != 0)
		if (flags & 2 != 0) != bool(room.get("dark", false)):
			set_room_lights(room_name, flags & 2 == 0)
		set_read(room_name, "water", flags & 4 != 0)
		set_read(room_name, "breathing", flags & 8 != 0)
		set_read(room_name, "searched", flags & 16 != 0)
		set_read(room_name, "cleared", flags & 128 != 0)
		set_read(room_name, "weak", flags & 32 != 0)
		set_read(room_name, "lost", flags & 64 != 0)
	told = state.get("sc", PackedByteArray())
	at = 0
	for room_name: String in rooms:
		var scorch: = (told[at] / 10.0) if at < told.size() else 0.0
		at += 1
		if not is_equal_approx(scorch, float(rooms[room_name].get("scorch", 0.0))):
			show_scorch(room_name, scorch)
	var control: Variant = state.get("ct")
	var shown: Variant = _control.get("part")
	if control == null:
		if is_instance_valid(shown):
			shown.queue_free()
		_control = {}
	else:
		if not is_instance_valid(shown):
			shown = _make_control(control[0], control[1], control[2], control[3])
			_control = {"part": shown, "used": false}
		if control[4] and not _control["used"]:
			_control["used"] = true
			_show_control_used(shown)
	super.net_apply(state, nodes, quiet)



static func net_fx(index: int, what: String, which: Variant, a: Variant = null, b: Variant = null, c: Variant = null) -> void :
	if index < 0 or index >= all.size():
		return
	var house: House = all[index]
	match what:
		"knock":
			if house.doors.has(which):
				house._show_knock(house.doors[which], a, b, c)
		"swing":
			if house.doors.has(which):
				house._swing(house.doors[which], a, b)
		"shatter":
			if int(which) < house._pane_list.size():
				house._shatter(house._pane_list[int(which)], a)






func _create_text(text: Dictionary) -> void :
	var id: = part_ids[int(text["part"]) - 1]
	var row: int = Game.store.row_of[id]
	var size: = Game.store.size(row)
	var face: String = text.get("face", "Front")
	var label: = Label3D.new()
	var words: Variant = Text.sign(TownSigns.planned(text["text"]))
	label.text = Text.say(words)
	label.font = Ui.label_font()
	label.modulate = Rbx.rgb(text["color"])
	label.outline_size = 0
	label.shaded = false
	label.double_sided = false
	holder.add_child(label)
	var wide: = size.x
	var tall: = size.y
	var out: = Transform3D.IDENTITY
	match face:
		"Front":
			out = Transform3D(Basis(Vector3.UP, PI), Vector3(0, 0, - size.z / 2.0 - 0.03))
		"Back":
			out = Transform3D(Basis.IDENTITY, Vector3(0, 0, size.z / 2.0 + 0.03))
		"Left":
			out = Transform3D(Basis(Vector3.UP, - PI / 2), Vector3( - size.x / 2.0 - 0.03, 0, 0))
			wide = size.z
		"Right":
			out = Transform3D(Basis(Vector3.UP, PI / 2), Vector3(size.x / 2.0 + 0.03, 0, 0))
			wide = size.z
		"Top":
			out = Transform3D(Basis(Vector3.RIGHT, - PI / 2), Vector3(0, size.y / 2.0 + 0.03, 0))
			tall = size.z
	label.global_transform = Game.store.transform(row) * out

	label.font_size = 64
	var measured: = label.font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 64)
	label.pixel_size = minf(wide * 0.92 / maxf(measured.x, 1.0), tall * 0.8 / maxf(measured.y, 1.0))
	Text.language_changed.connect( func(_code: String) -> void :
		if is_instance_valid(label):
			label.text = Text.say(words)
	)
