class_name Sounds
extends RefCounted


static var _loops: Dictionary = {}
static var _ui_holder: Node



static func loop(asset: Variant) -> AudioStream:
	var key: = str(asset)
	if _loops.has(key):
		return _loops[key]
	var source: = Assets.sound(asset)
	if source == null:
		return null
	var stream: = source.duplicate() as AudioStream
	if stream is AudioStreamWAV:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = 0
		stream.loop_end = int(stream.get_length() * stream.mix_rate)
	_loops[key] = stream
	return stream




static func emitter(parent: Node3D, stream: AudioStream, volume: = 1.0, near: = 12.0, far: = 160.0, autoplay: = false) -> AudioStreamPlayer3D:
	var player: = AudioStreamPlayer3D.new()
	player.stream = stream
	player.volume_db = linear_to_db(maxf(volume, 0.0001))
	player.unit_size = near
	player.max_distance = far
	player.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	player.max_polyphony = 2
	parent.add_child(player)
	if autoplay and stream != null:
		player.play()
	return player



static func once(parent: Node3D, asset: Variant, volume: = 1.0, near: = 12.0, far: = 160.0, pitch: = 1.0) -> void :
	var stream: = Assets.sound(asset)
	if stream == null or not is_instance_valid(parent):
		return
	var player: = emitter(parent, stream, volume, near, far)
	player.pitch_scale = pitch
	player.finished.connect(player.queue_free)
	player.play()



static func once_at(position: Vector3, asset: Variant, volume: = 1.0, near: = 12.0, far: = 160.0, pitch: = 1.0) -> void :
	var stream: = Assets.sound(asset)
	if stream == null or Game.world == null:
		return
	var holder: = Node3D.new()
	Game.world.add_child(holder)
	holder.global_position = position
	var player: = emitter(holder, stream, volume, near, far)
	player.pitch_scale = pitch
	player.finished.connect(holder.queue_free)
	player.play()



static func flat(asset: Variant, volume: = 1.0) -> AudioStreamPlayer:
	var stream: = Assets.sound(asset)
	if stream == null or Game.world == null:
		return null
	var player: = AudioStreamPlayer.new()
	player.stream = stream
	player.volume_db = linear_to_db(maxf(volume, 0.0001))
	Game.world.add_child(player)
	player.finished.connect(player.queue_free)
	player.play()
	return player



static func ui_bus() -> String:
	var bus_name: = str(Config.UiSounds.Bus)
	if AudioServer.get_bus_index(bus_name) < 0:
		var index: = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, bus_name)
		AudioServer.set_bus_send(index, "Master")
		AudioServer.set_bus_volume_db(index, linear_to_db(float(Config.UiSounds.BusVolume)))
	return bus_name





static func ui(asset: String, pitch: = 1.0, volume: = 1.0) -> AudioStreamPlayer:
	var stream: = Assets.sound(asset)
	var tree: = Engine.get_main_loop() as SceneTree
	if stream == null or tree == null or tree.root == null:
		return null
	if not is_instance_valid(_ui_holder):
		_ui_holder = Node.new()
		_ui_holder.name = "UiSounds"
		_ui_holder.process_mode = Node.PROCESS_MODE_ALWAYS
		tree.root.add_child.call_deferred(_ui_holder)
	var player: = AudioStreamPlayer.new()
	player.stream = stream
	player.bus = ui_bus()
	player.pitch_scale = maxf(pitch, 0.05)
	player.volume_db = linear_to_db(maxf(float(Config.UiSounds.Volumes.get(asset, 1.0)) * volume, 0.0001))
	player.finished.connect(player.queue_free)
	if OS.get_cmdline_user_args().has("--audio-trace"):
		print("ui sound: %s pitch %.2f" % [asset, pitch])
	if _ui_holder.is_inside_tree():
		_ui_holder.add_child(player)
		player.play()
	else:

		_ui_holder.add_child(player)
		player.autoplay = true
	return player
