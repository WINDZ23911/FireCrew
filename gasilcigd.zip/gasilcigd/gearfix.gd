extends ProofDebug









func _crew(count: int) -> Array[Player]:
	var bodies: Array[Player] = []
	var service: = CrewService.current
	if service == null:
		return bodies
	for index in count:
		var entry: = service.roster._member("", "nozzle", 0, 0)
		var mind: = service._make(entry, service.members.size(), player)
		bodies.append(mind.body)
	return bodies


func _scenario_scbaboard() -> void :
	await _wait(1.0)
	var told: Array = []
	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	GearService.current._gear_up(player, null, true)
	AirService.current.take_set(player, "rack")
	await _wait(0.3)
	_check(player.get_attr("Scba", false) == true, "a breathing set on")
	var door: Vector3 = pumper.to_global(pumper.doors["DoorCabLeft"]["doorway"])
	player.teleport(_ground(door + pumper.global_basis.x * -3.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)

	AirService.current.sets[player]["bar"] = 210.0
	AirService.current.move_mask(player)
	await _wait(float(Config.Air.MaskOnTime) + 0.3)
	_check(player.get_attr("Mask", false) == true, "the mask on before boarding")
	pumper._board_at(player, "DoorCabLeft")
	await _wait(1.2)
	var bar_seated: = AirService.current.pressure(player)
	print("scbaboard: with the set on: seated %s, set %s, mask %s, %.1f bar; told %s" % [player.seat != null, player.get_attr("Scba"), player.get_attr("Mask"), bar_seated, told])
	_check(player.seat != null, "a firefighter with a set on gets in")
	_check(player.get_attr("Scba", false) == true, "and keeps the set on")
	_check(player.get_attr("Mask", false) != true, "with the mask off in the seat")
	_check(bar_seated > 205.0, "and the air it had")

	AirService.current.move_mask(player)
	await _wait(4.0)
	print("scbaboard: after 4 s riding: %.1f bar, mask %s" % [AirService.current.pressure(player), player.get_attr("Mask")])
	_check(player.get_attr("Mask", false) != true, "the mask does not go on in a seat")
	_check(is_equal_approx(AirService.current.pressure(player), bar_seated), "nothing is breathed from the set on the way")
	_check( not told.any( func(line: String) -> bool: return line.to_lower().contains("put the breathing set back")), "nobody is told to put it back first")

	pumper.set_door("DoorCabLeft", true)
	await _wait(1.0)
	var out_of: = (door - pumper.global_position)
	out_of = Vector3(out_of.x, 0, out_of.z).normalized()
	_view(door + out_of * 6.0 + pumper.global_basis.z * 2.5 + Vector3(0, 2.5, 0), player.head_position() + Vector3(0, -1.2, 0), 55.0)
	await _wait(0.3)
	await _snap("seated")
	pumper.set_door("DoorCabLeft", false)
	pumper.leave(player)
	await _wait(0.5)
	_check(player.get_attr("Scba", false) == true and is_equal_approx(AirService.current.pressure(player), bar_seated), "out again with the set on and its air")
	AirService.current.return_worn(player)
	await _wait(0.3)


	if not CrewService.enabled():
		print("scbaboard: the AI crew is off; its part needs --crew")
		await _done()
		return
	var bodies: = _crew(1)
	await _wait(0.5)
	if _check(bodies.size() == 1, "a crew member stands by"):
		var body: Player = bodies[0]
		GearService.current._gear_up(body, null, true)
		AirService.current.take_set(body, "truck")
		await _wait(0.3)
		var pool_before: int = AirService.current.pool["truck"]
		body.teleport(_ground(door + pumper.global_basis.x * -3.0) + Vector3(0, 0.3, 0))
		pumper._board_at(body, "DoorCrewLeft")
		await _wait(0.8)
		print("scbaboard: the crew member: seated %s, set %s, the truck's sets %d -> %d" % [body.seat != null, body.get_attr("Scba", false), pool_before, AirService.current.pool["truck"]])
		_check(body.seat != null and body.get_attr("Scba", false) != true and AirService.current.pool["truck"] == pool_before + 1, "an AI crew member's set goes back into the truck as they board")
	await _done()


func _scenario_helmets() -> void :
	await _wait(1.0)
	var gear: = GearService.current
	var ranks: Array = Config.Gear.Ranks
	var sheets: Array = []
	for rank: Dictionary in ranks:
		sheets.append(GearService.rank_helmet_of(rank))
	print("helmets: the ranks' helmets %s" % [sheets])
	var distinct: = {}
	for sheet: String in sheets:
		distinct[sheet] = true
	_check(distinct.size() == ranks.size(), "every rank has a helmet of its own")
	_check(sheets.all( func(sheet: String) -> bool: return gear.has_sheet(sheet)), "and the kit has them all")

	player.set_attr("Saved", int(ranks[3]["saved"]))
	gear._gear_up(player, null, true)
	await _wait(0.3)
	var worn: String = gear.worn[player]["helmet"]
	print("helmets: at %d points the rank is %s, the helmet %s" % [int(ranks[3]["saved"]), gear.rank_of(player)["sheet"], worn])
	_check(worn == sheets[3], "the fourth rank wears its helmet")
	var listed: Array = (Hud.current.widgets.get("wardrobe") as WardrobeMenu)._helmets() if Hud.current.widgets.has("wardrobe") else []
	if listed.is_empty():
		var menu: = WardrobeMenu.new()
		Hud.current.overlay.add_child(menu)
		menu._player = player
		listed = menu._helmets()
		menu.queue_free()
	print("helmets: the wardrobe lists %s" % [listed.map( func(h: Dictionary) -> String: return h["sheet"])])
	_check(listed.size() >= ranks.size() - 1 + Config.Gear.Helmets.size(), "the wardrobe lists the ranks' helmets and the colours for sale")
	_view(player.global_position + player.global_basis.z * -6.0 + Vector3(0, 5, 0), player.head_position())
	await _wait(0.3)
	await _snap("rank_helmet")
	await _done()


func _scenario_wear() -> void :
	await _wait(1.0)
	var gear: = GearService.current
	gear._gear_up(player, null, true)
	await _wait(0.5)
	var look: Dictionary = gear._look_of(player)
	var glow: = FirefighterRig._bands_glow

	player.set_attr("Wear", 0.85)
	await _wait(0.6)
	var early_pass: Variant = null
	for mesh: MeshInstance3D in look["tinted"]:
		for pair: Array in look["tinted"][mesh]:
			if (pair[0] as BaseMaterial3D).next_pass != null:
				early_pass = (pair[0] as BaseMaterial3D).next_pass
	print("wear: the suit at 0.85 and no fire calls: the helmet's scorch pass %s" % early_pass)
	_check(early_pass == null, "calls that were no fire leave the helmet clean")
	player.set_attr("HelmetWear", 0.85)
	await _wait(0.6)
	var band_energy: = -1.0
	var band_albedo: = Color.WHITE
	var helmet_pass: Variant = null
	for mesh: MeshInstance3D in look["tinted"]:
		for pair: Array in look["tinted"][mesh]:
			var copy: BaseMaterial3D = pair[0]
			if copy is StandardMaterial3D and copy.emission_texture != null and FirefighterRig._is_banded(copy):
				band_energy = copy.emission_energy_multiplier
				band_albedo = copy.albedo_color
			elif copy.next_pass != null:
				helmet_pass = copy.next_pass
	print("wear: at 0.85 the bands shine at %.2f of %.2f, the jacket's albedo %s, the helmet's scorch pass %s" % [band_energy, glow, band_albedo, helmet_pass])
	_check(band_energy >= 0.0 and band_energy < glow * 0.5, "worn, the reflective bands have faded")
	_check(band_albedo.r < 0.95 or band_albedo.g < 0.95 or band_albedo.b < 0.95, "and the suit is browned")
	_check(helmet_pass != null, "and the helmet carries scorch marks")
	_view(player.head_position() + player.global_basis.z * -3.2 + player.global_basis.x * 1.6 + Vector3(0, 0.6, 0), player.head_position() - Vector3(0, 0.6, 0))
	await _wait(0.5)
	await _snap("worn")

	player.set_attr("Cash", 1000)
	var stall: Dictionary = gear.stalls[0]
	player.teleport(stall["position"] + Vector3(2, 0.3, 0))
	await _wait(0.3)
	gear._choosing[player] = stall
	print("wear: at the stall: %.1f studs off (reach %s), near %s, wear %.2f (show from %s), cash %d, price %s" % [player.root_position().distance_to(stall["position"]), Config.Gear.StallReach, gear._near_stall(player, stall), float(player.get_attr("Wear", 0.0)), Config.Gear.WearShowFrom, int(player.get_attr("Cash", 0)), Config.Gear.RenewPrice])
	gear.renew_gear(player)
	await _wait(0.6)
	var cash: = int(player.get_attr("Cash", 0))
	var now_energy: = -1.0
	var now_pass: Variant = null
	for mesh: MeshInstance3D in look["tinted"]:
		for pair: Array in look["tinted"][mesh]:
			var copy: BaseMaterial3D = pair[0]
			if copy is StandardMaterial3D and copy.emission_texture != null and FirefighterRig._is_banded(copy):
				now_energy = copy.emission_energy_multiplier
			elif copy.next_pass != null:
				now_pass = copy.next_pass
	print("wear: renewed: wear %.2f, cash %d, bands at %.2f, scorch pass %s" % [float(player.get_attr("Wear", 0.0)), cash, now_energy, now_pass])
	_check(float(player.get_attr("Wear", 0.0)) == 0.0 and float(player.get_attr("HelmetWear", 0.0)) == 0.0 and cash == 1000 - int(Config.Gear.RenewPrice), "new gear costs its price and the wear is gone")
	_check(now_energy >= glow * 0.99 and now_pass == null, "the bands shine again and the helmet is clean")
	await _snap("renewed")
	await _done()
