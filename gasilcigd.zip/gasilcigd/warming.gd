class_name Warming
extends Node3D






var heat: = 0.5
var _wisp: RbxEmitter
var _sparks: RbxEmitter
var _crackle: AudioStreamPlayer3D
var _shown: = -1.0


func _ready() -> void :
	var look: Dictionary = Config.Fire.Warming
	_wisp = ToonFire.puffs(self, {
		"Color": Rbx.rgb(look["Puff"]), "Speed": [2, 3.5], "Lifetime": [1.8, 2.6], "SpreadAngle": 18, 
		"Direction": Vector3.UP, "Acceleration": World.WIND * 1.2, "Rotation": [0, 360], 
		"Size": [[0.0, 0.5], [0.4, 1.5], [1.0, 0.0]], "Rate": 2, "MaxRate": 9, "Sphere": 0.8, 
	}, true)
	_sparks = RbxEmitter.make(self, {
		"Texture": "fire_ember", "LightEmission": 1.0, "LightInfluence": 0.0, "Brightness": 3.0, 
		"Speed": [2, 5], "Lifetime": [0.5, 0.9], "SpreadAngle": 50, "Direction": Vector3.UP, 
		"Size": [0.22, 0.06], "Transparency": [0.0, 1.0], "Rate": 0, "MaxRate": 8, "Sphere": 0.5, 
	})
	_crackle = Sounds.emitter(self, Sounds.loop("fire_crackle"), 0.0001, 6.0, 40.0, true)


func _process(_delta: float) -> void :
	var stepped: = snappedf(heat, 0.05)
	if stepped == _shown:
		return
	_shown = stepped
	var close: = clampf((heat - FireService.WARN_HEAT) / (1.0 - FireService.WARN_HEAT), 0.0, 1.0)
	var look: Dictionary = Config.Fire.Warming
	_wisp.set_rate(2.0 + 7.0 * close)
	_wisp.set_color(Rbx.rgb(look["Puff"]).lerp(Rbx.rgb(look["PuffHot"]), close))
	_wisp.speed_scale = 1.0 + 0.6 * close
	_sparks.set_rate(8.0 * maxf(close - 0.6, 0.0) / 0.4)
	if is_instance_valid(_crackle):
		_crackle.volume_db = linear_to_db(0.08 + 0.3 * close)
