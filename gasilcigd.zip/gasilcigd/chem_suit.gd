class_name ChemSuit
extends Node








const SUIT_COLOR: = Color(0.86, 0.82, 0.16)
const SUIT_SHEETS: = ["jacket", "limbs"]
const WARN_EVERY: = 8.0

static var current: ChemSuit

var pool: = 0
var _lines: Array[LockerLine] = []
var _drawn: Dictionary = {}
var _material: StandardMaterial3D
var _warned: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	pool = _full()
	_material = StandardMaterial3D.new()
	_material.albedo_color = SUIT_COLOR
	_material.roughness = 0.45
	_material.metallic_specular = 0.6
	var truck: Vehicle = AirService.current.truck if AirService.current != null else null
	var lockers: = Lockers.of(truck) if truck != null else null
	if lockers != null:
		var line: = lockers.add_line("L4", Text.m("gear.chem.lockerTake"), "", "air", "warning")
		line.chosen.connect(_on_line)
		_lines.append(line)
	_update_counts()
	GearService.current.on_removed( func(player: Player) -> void :
		if wearing(player):
			_put_back(player)
	)
	Net.share("chem.pool", func() -> Variant: return pool, func(state: Variant) -> void :
		pool = int(state)
		_update_counts()
	, 4.0)
	Text.language_changed.connect( func(_code: String) -> void : _update_counts())


func _full() -> int:
	return int(Config.ChemSuit.Suits)


static func wearing(player: Player) -> bool:
	return player != null and player.get_attr("ChemSuit", false) == true


func _update_counts() -> void :
	for line in _lines:
		line.object = Text.f("gear.chem.count", [pool, _full()])


func _on_line(player: Player) -> void :
	if Net.is_client():
		return
	if wearing(player):
		_put_back(player)
		Game.notify(Text.m("gear.chem.back"), "", player)
		return
	if not GearService.current.is_geared(player):
		Game.notify(Text.m("gear.suitFirst"), "", player)
		return
	if pool <= 0:
		Game.notify(Text.m("gear.chem.none"), "", player)
		return
	pool -= 1
	player.set_attr("ChemSuit", true)
	_update_counts()
	Game.notify(Text.m("gear.chem.on"), "", player)


func _put_back(player: Player) -> void :
	player.set_attr("ChemSuit", null)
	pool = mini(pool + 1, _full())
	_update_counts()




func burn_skin(player: Player, level: float, dt: float) -> void :
	if level <= 0.05 or wearing(player) or player.brain != null or player.health <= 0.0:
		return
	player.take_damage(float(Config.ChemSuit.SkinDamage) * level * dt)
	var now: = Game.now()
	if now - float(_warned.get(player, -100.0)) > WARN_EVERY:
		_warned[player] = now
		Game.notify(Text.m("gear.chem.burns"), "warning", player)



func _process(_delta: float) -> void :
	for known: Variant in _drawn.keys():
		if not is_instance_valid(known):
			_drawn.erase(known)
	for player in Game.players:
		var suited: bool = wearing(player) and player.get_attr("Geared", false) == true
		if bool(_drawn.get(player, false)) == suited:
			continue
		_drawn[player] = suited
		for sheet: String in player.rig.pieces:
			var covered: bool = false
			for start: String in SUIT_SHEETS:
				covered = covered or sheet.begins_with(start)
			if not covered:
				continue
			for mesh: MeshInstance3D in player.rig.pieces[sheet]:
				mesh.material_override = _material if suited else null
