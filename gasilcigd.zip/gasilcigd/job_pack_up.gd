class_name JobPackUp
extends CrewJob









const GIVE_UP: = 300.0

var collected: = 0
var _skipped: Array = []


func _init() -> void :
	kind = "packUp"


func run() -> bool:
	var held: = who.token()
	var started: = Game.now()
	while on(held) and Game.now() - started < GIVE_UP:
		if _lead_leaving():
			return _left_behind()
		var piece: = CrewPack.claim(who, _skipped)
		if piece.is_empty():
			break
		var done: = await _collect(piece, held)
		CrewPack.release(piece)
		if not on(held):
			return false
		if done:
			collected += 1
		else:
			_skipped.append(piece["prompt"])
	if not on(held):
		return false
	if _lead_leaving():
		return _left_behind()
	await _hand_in(held)
	if not on(held):
		return false

	for other in who.service.members:
		if other != who and other.job is JobPackUp:
			quiet = true
	if not quiet:
		await _shut_all(held)
	return on(held)



func _collect(piece: Dictionary, held: int) -> bool:
	var out: Callable = piece["out"]
	if not out.call():
		return true
	var prompt: Prompt = piece["prompt"]
	if not await who.press(prompt):
		return not out.call()
	await who.wait(0.3, held)
	if piece["kind"] == "tool":

		var item: Dictionary = piece["item"]
		if item["holder"] == who.body:
			await _hand_back(held, item["vehicle"], item["line"], func() -> bool: return item["holder"] == who.body)
		return not item["standing"]
	return not out.call()



func _hand_in(held: int) -> void :
	var tools: = ToolService.current
	if tools != null:
		for item: Dictionary in tools.carried(who.body).duplicate():
			await _hand_back(held, item["vehicle"], item["line"], func() -> bool: return item["holder"] == who.body)
	var cordon: = Cordon.current
	if cordon != null:
		for item: Dictionary in cordon.items:
			if item["holder"] == who.body:
				await _hand_back(held, item["truck"], item["line"], func() -> bool: return item["holder"] == who.body)
	var hoses: = HoseService.current
	if hoses != null and hoses.divider["state"] == "carried" and hoses.divider["player"] == who.body:
		await _hand_back(held, hoses.divider["vehicle"], hoses.divider["line"], func() -> bool: return hoses.divider["player"] == who.body)
	var air: = AirService.current
	if air != null and air.sets.has(who.body):
		var found: = CrewWater.set_line(who, who.service.home_vehicle(who.commander()))
		if not found.is_empty():
			await _hand_back(held, found[0], found[1], func() -> bool: return air.sets.has(who.body))




func _hand_back(held: int, vehicle: Vehicle, line: LockerLine, still: Callable) -> void :
	if not CrewPack.at_hand(who, vehicle):
		return
	for attempt in 2:
		if on(held) and still.call():
			await CrewKit.from_locker(who, vehicle, line)
	_shut(vehicle)




func _shut(vehicle: Vehicle) -> void :
	var lockers: = Lockers.of(vehicle)
	if lockers == null or not on(who.token()):
		return
	for handle: Dictionary in lockers.handles:
		var at: Vector3 = handle["node"].global_position
		if not lockers.is_open(handle) or who.body.root_position().distance_to(at) > Lockers.REACH:
			continue
		var others: = who.service.members.any( func(other: Crewman) -> bool:
			return other != who and other.job is JobPackUp and other.body.root_position().distance_to(at) < Lockers.REACH + 6.0)
		if not others:
			lockers.use(who.body, handle, null)



func _shut_all(held: int) -> void :
	for vehicle in Vehicle.all:
		var lockers: = Lockers.of(vehicle)
		if lockers == null or not CrewPack.at_hand(who, vehicle):
			continue
		for handle: Dictionary in lockers.handles:
			if not on(held) or not lockers.is_open(handle):
				continue
			var node: Node3D = handle["node"]
			if await who.go(who.stand_by(node.global_position, 3.0), 3.0, 30.0):
				who.look = node.global_position
				await who.wait(0.3, held)
				lockers.use(who.body, handle, null)



func _lead_leaving() -> bool:
	var lead: = who.commander()
	var vehicle: Variant = lead.get_attr("Vehicle") if lead != null else null
	return vehicle is Vehicle and lead.seat != null and absf(vehicle.forward_speed) > 3.0


func _left_behind() -> bool:
	CrewKit.stow_all(who)
	quiet = true
	return true


func finish(_done: bool) -> void :
	for prompt: Variant in CrewPack._claimed.keys():
		if CrewPack._claimed[prompt] == who:
			CrewPack._claimed.erase(prompt)
