class_name PartNode
extends AnimatableBody3D



var part_id: = 0
var part_name: = ""
var size: = Vector3.ONE
var mesh: MeshInstance3D
var collider: CollisionShape3D
var _material: ShaderMaterial


static func make(store: PartStore, row: int, solid: = true) -> PartNode:
	var node: = create(
		store.shape(row), store.transform(row), store.size(row), store.color(row), store.material(row), 
		store.name_at(row), store.flags(row), store.transparency(row)
	)
	node.part_id = store.id_at(row)
	if not solid:
		node.set_solid(false)
	return node


static func create(shape: int, place: Transform3D, part_size: Vector3, color: Color, material: String, node_name: String, flags: = 7, transparency: = 0.0) -> PartNode:
	var node: = PartNode.new()
	node.name = node_name
	node.part_name = node_name
	node.size = part_size
	node.sync_to_physics = false
	node.transform = place
	node.collision_layer = (World.LAYER_SOLID if flags & PartStore.COLLIDE else 0) | (World.LAYER_QUERY if flags & PartStore.QUERY else 0)
	node.collision_mask = 0

	var drawn: = part_size
	if shape == PartStore.Shape.CYLINDER:
		drawn = Vector3(part_size.x, minf(part_size.y, part_size.z), minf(part_size.y, part_size.z))
	elif shape == PartStore.Shape.BALL:
		drawn = Vector3.ONE * minf(part_size.x, minf(part_size.y, part_size.z))
	node.mesh = MeshInstance3D.new()
	node.mesh.mesh = World.unit_mesh(shape)
	node.mesh.scale = drawn

	node._material = WorldMaterials.of(material, transparency > 0.01, false, 0.0, false).duplicate()
	node._material.shader = load("res://shaders/part_node.gdshader") if transparency <= 0.01 else load("res://shaders/part_node_alpha.gdshader")
	node.mesh.material_override = node._material
	node.mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if flags & PartStore.SHADOW else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	node.add_child(node.mesh)
	node.set_color(color, transparency)

	node.collider = CollisionShape3D.new()
	match shape:
		PartStore.Shape.CYLINDER:
			var cylinder: = CylinderShape3D.new()
			cylinder.radius = drawn.y / 2.0
			cylinder.height = part_size.x
			node.collider.shape = cylinder
			node.collider.transform = Transform3D(Basis(Vector3.BACK, PI / 2), Vector3.ZERO)
		PartStore.Shape.BALL, PartStore.Shape.ELLIPSOID:
			var ball: = SphereShape3D.new()
			ball.radius = drawn.x / 2.0
			node.collider.shape = ball
		PartStore.Shape.WEDGE, PartStore.Shape.CORNER_WEDGE:
			var hull: = ConvexPolygonShape3D.new()
			var points: = PackedVector3Array()
			for corner: Vector3 in World.wedge_corners(shape):
				points.append(corner * part_size)
			hull.points = points
			node.collider.shape = hull
		_:
			var box: = BoxShape3D.new()
			box.size = part_size
			node.collider.shape = box
	node.add_child(node.collider)
	return node


func set_color(color: Color, transparency: = 0.0) -> void :
	color.a = 1.0 - transparency
	_material.set_shader_parameter("tint", color)


func get_color() -> Color:
	return _material.get_shader_parameter("tint")


func set_solid(solid: bool) -> void :
	collider.disabled = not solid
