class_name RbxEmitter
extends GPUParticles3D












static var _materials: Dictionary = {}
static var _curves: Dictionary = {}
static var _ramps: Dictionary = {}

var _rate: = 20.0
var _full_rate: = 20.0
var _process: ParticleProcessMaterial
var _lifetime: = 1.0


static func make(parent: Node3D, props: Dictionary) -> RbxEmitter:
	var emitter: = RbxEmitter.new()
	emitter.setup(props)
	parent.add_child(emitter)
	return emitter


static func _range(value: Variant, default: float) -> Vector2:
	if value == null:
		return Vector2(default, default)
	if value is Vector2:
		return value
	if value is Array:
		return Vector2(value[0], value[1] if value.size() > 1 else value[0])
	return Vector2(float(value), float(value))



static func _keys(value: Variant, default: float) -> Array:
	if value == null:
		return [[0.0, default], [1.0, default]]
	if value is Array:
		if value.size() > 0 and value[0] is Array:
			return value
		if value.size() == 2:
			return [[0.0, float(value[0])], [1.0, float(value[1])]]
		return [[0.0, float(value[0])], [1.0, float(value[0])]]
	return [[0.0, float(value)], [1.0, float(value)]]


func setup(props: Dictionary) -> void :
	var life: = _range(props.get("Lifetime"), 5.0)
	_lifetime = maxf(life.y, 0.05)
	lifetime = _lifetime
	_full_rate = maxf(props.get("MaxRate", props.get("Rate", 20.0)), 0.01)
	_rate = props.get("Rate", 20.0)
	amount = maxi(1, ceili(_full_rate * _lifetime))
	amount_ratio = clampf(_rate / _full_rate, 0.0, 1.0)
	emitting = props.get("Enabled", true) and _rate > 0.0
	local_coords = props.get("LockedToPart", false)
	fixed_fps = 0
	interpolate = true
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	_process = ParticleProcessMaterial.new()
	_process.lifetime_randomness = clampf(1.0 - life.x / _lifetime, 0.0, 1.0)
	var speed: = _range(props.get("Speed"), 5.0)
	_process.initial_velocity_min = speed.x
	_process.initial_velocity_max = speed.y
	_process.direction = props.get("Direction", Vector3.UP)
	var spread: Variant = props.get("SpreadAngle", 0.0)
	if spread is Vector2:
		spread = maxf(spread.x, spread.y)
	_process.spread = clampf(float(spread), 0.0, 180.0)
	_process.gravity = props.get("Acceleration", Vector3.ZERO)
	var drag: float = props.get("Drag", 0.0)
	if drag > 0.0:

		var slowing: = drag * 0.7 * (speed.x + speed.y) / 2.0
		_process.damping_min = slowing
		_process.damping_max = slowing
	var turn: = _range(props.get("Rotation"), 0.0)
	_process.angle_min = turn.x
	_process.angle_max = turn.y
	var spin: = _range(props.get("RotSpeed"), 0.0)
	_process.angular_velocity_min = spin.x
	_process.angular_velocity_max = spin.y
	if props.has("Box"):
		_process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		_process.emission_box_extents = props["Box"] / 2.0
	elif props.has("Sphere"):
		_process.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
		_process.emission_sphere_radius = props["Sphere"]
	set_size(props.get("Size", 1.0))
	_set_color(props)
	var flipbook: bool = props.get("Flipbook", false)
	if flipbook:
		var rate: = _range(props.get("FlipbookFramerate"), 16.0)
		_process.anim_speed_min = rate.x * _lifetime / 16.0
		_process.anim_speed_max = rate.y * _lifetime / 16.0
		_process.anim_offset_min = 0.0
		_process.anim_offset_max = 1.0
	process_material = _process

	if props.has("Mesh"):
		draw_pass_1 = props["Mesh"]
		material_override = props.get("Material")
	else:
		var quad: = QuadMesh.new()
		quad.size = Vector2.ONE
		quad.material = _material(props.get("Texture", ""), flipbook, props.get("LightEmission", 0.0), props.get("Brightness", 1.0), props.get("LightInfluence", 1.0))
		draw_pass_1 = quad

	var reach: = (speed.y + _process.gravity.length() * _lifetime) * _lifetime + 12.0
	visibility_aabb = AABB(Vector3.ONE * - reach, Vector3.ONE * reach * 2.0)


static func _material(texture: Variant, flipbook: bool, emission: float, brightness: float, light_influence: float) -> StandardMaterial3D:
	var key: = [str(texture), flipbook, emission >= 0.4, brightness, light_influence > 0.5]
	if _materials.has(key):
		return _materials[key]
	var material: = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED if light_influence <= 0.5 else BaseMaterial3D.SHADING_MODE_PER_VERTEX
	material.vertex_color_use_as_albedo = true
	material.vertex_color_is_srgb = true
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD if emission >= 0.4 else BaseMaterial3D.BLEND_MODE_MIX
	material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	material.billboard_keep_scale = true
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	material.disable_receive_shadows = true
	material.albedo_color = Color(brightness, brightness, brightness, 1.0)
	if light_influence > 0.5:

		material.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
		material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		material.backlight_enabled = true
		material.backlight = Color(0.5, 0.5, 0.5)
	var picture: = Assets.texture(texture) if str(texture) != "" else null
	if picture:
		material.albedo_texture = picture
	if flipbook:
		material.particles_anim_h_frames = 4
		material.particles_anim_v_frames = 4
		material.particles_anim_loop = true
	_materials[key] = material
	return material



func set_rate(rate: float) -> void :
	_rate = rate
	amount_ratio = clampf(rate / _full_rate, 0.0, 1.0)
	emitting = rate > 0.0



func set_size(value: Variant) -> void :
	var keys: = _keys(value, 1.0)
	var cache_key: = str(keys)
	if _curves.has(cache_key):
		_process.scale_min = 1.0
		_process.scale_max = 1.0
		_process.scale_curve = _curves[cache_key]
		return
	var most: = 0.01
	for key: Array in keys:
		most = maxf(most, key[1])
	var curve: = Curve.new()
	curve.max_value = most
	for key: Array in keys:
		curve.add_point(Vector2(key[0], key[1]), 0, 0, Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
	var texture: = CurveTexture.new()
	texture.curve = curve
	texture.width = 32
	if _curves.size() < 4000:
		_curves[cache_key] = texture
	_process.scale_min = 1.0
	_process.scale_max = 1.0
	_process.scale_curve = texture




func set_color(color: Variant, transparency: Variant = null) -> void :
	var props: = {"Color": color}
	if transparency != null:
		props["Transparency"] = transparency
	_set_color(props)


func _set_color(props: Dictionary) -> void :
	var colors: Variant = props.get("Color", Color.WHITE)
	var cache_key: = str([colors, props.get("Transparency")])
	if _ramps.has(cache_key):
		_process.color_ramp = _ramps[cache_key]
		return
	var first: Color = colors[0] if colors is Array else colors
	var last: Color = colors[colors.size() - 1] if colors is Array else colors
	var gradient: = Gradient.new()
	var offsets: = PackedFloat32Array()
	var values: = PackedColorArray()
	for key: Array in _keys(props.get("Transparency"), 0.0):
		var color: = first.lerp(last, key[0])
		color.a = 1.0 - key[1]
		offsets.append(key[0])
		values.append(color)
	gradient.offsets = offsets
	gradient.colors = values
	var ramp: = GradientTexture1D.new()
	ramp.gradient = gradient
	ramp.width = 32
	if _ramps.size() < 4000:
		_ramps[cache_key] = ramp
	_process.color_ramp = ramp



static func burst(parent: Node3D, props: Dictionary, count: int) -> void :
	if not is_instance_valid(parent):
		return
	var once: = RbxEmitter.new()
	var copy: = props.duplicate()
	var life: = _range(copy.get("Lifetime"), 1.0)
	copy["Rate"] = count / maxf(life.y, 0.05)
	copy["Enabled"] = true
	once.setup(copy)
	once.amount = maxi(1, count)
	once.amount_ratio = 1.0
	once.one_shot = true
	once.explosiveness = 1.0
	parent.add_child(once)
	once.emitting = true
	once.get_tree().create_timer(life.y + 0.5).timeout.connect(once.queue_free)



static func burst_at(position: Vector3, props: Dictionary, count: int) -> void :
	if Game.world == null:
		return
	var holder: = Node3D.new()
	Game.world.add_child(holder)
	holder.global_position = position
	burst(holder, props, count)
	holder.get_tree().create_timer(_range(props.get("Lifetime"), 1.0).y + 1.0).timeout.connect(holder.queue_free)
