class_name HoseLine
extends Node3D





const SEGMENT_LENGTH: = 4.0
const PICKUP_SLACK: = 0.5
const SIDES: = 6
const PULL_OFF: = 30.0

var start: Node3D
var finish: Node3D
var finish_drop: = 2.1
var width: = 0.4
var color: = Color(232 / 255.0, 226 / 255.0, 200 / 255.0)
var points: PackedVector3Array = []
var start_drop: = 3.0


var swell: = 1.0:
	set(value):
		if absf(value - swell) > 0.001:
			swell = value
			_dirty = true
var _mesh: MeshInstance3D
var _built_for: = Vector3.INF
var _built_start: = Vector3.INF
var _dirty: = true
var _exclude: Array[RID] = []


static func make(from: Node3D, hose_width: float, hose_color: Color, ignore: Array[RID] = []) -> HoseLine:
	var line: = HoseLine.new()
	line.start = from
	line.width = hose_width
	line.color = hose_color
	line._exclude = ignore
	Game.world.add_child(line)
	return line


func _ready() -> void :
	top_level = true
	_mesh = MeshInstance3D.new()
	_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var material: = StandardMaterial3D.new()
	material.albedo_color = color
	material.albedo_texture = Assets.texture("hose_weave")
	material.uv1_scale = Vector3(1, 1, 1)
	material.roughness = 0.95
	_mesh.material_override = material
	add_child(_mesh)
	var ground: Variant = _ground_below(start.global_position)
	if ground != null:
		start_drop = maxf(0.5, start.global_position.y - ground.y - width / 2.0)


func _ground_below(at: Vector3) -> Variant:
	var hit: = Game.world.raycast(at + Vector3(0, 0.5, 0), at + Vector3(0, -30, 0), World.LAYER_SOLID, _exclude)
	return hit["position"] if not hit.is_empty() else null


func _start_ground() -> Vector3:
	return start.global_position - Vector3(0, start_drop, 0)



func set_end(node: Node3D, drop: float) -> void :
	finish = node
	finish_drop = drop
	_dirty = true



func follow(at: Vector3) -> void :
	var ground: Variant = _ground_below(at)
	if ground == null:
		return
	var here: Vector3 = ground + Vector3(0, width / 2.0, 0)

	while points.size() > 0:
		var count: = points.size()
		var last: = points[count - 1]
		var previous: = points[count - 2] if count > 1 else _start_ground()
		if here.distance_to(previous) < last.distance_to(previous) - PICKUP_SLACK:
			points.remove_at(count - 1)
			_dirty = true
		else:
			break
	var anchor: = points[points.size() - 1] if points.size() > 0 else _start_ground()
	if here.distance_to(anchor) > SEGMENT_LENGTH:
		points.append(here)
		_dirty = true




func lay_to(at: Vector3) -> void :
	var from: = points[points.size() - 1] if points.size() > 0 else _start_ground()
	var steps: = ceili(Vector2(at.x - from.x, at.z - from.z).length() / SEGMENT_LENGTH)
	for step in range(1, steps + 1):
		follow(from.lerp(at, float(step) / steps))





func stretched() -> bool:
	if not is_instance_valid(start):
		return false
	if points.size() > 0:
		return start.global_position.distance_to(points[0]) > PULL_OFF
	return is_instance_valid(finish) and start.global_position.distance_to(finish.global_position) > PULL_OFF



func laid_length() -> float:
	var total: = 0.0
	var previous: = start.global_position
	for point in points:
		total += point.distance_to(previous)
		previous = point
	return total



func length() -> float:
	var total: = 0.0
	var previous: = start.global_position
	for point in points:
		total += point.distance_to(previous)
		previous = point
	if finish and is_instance_valid(finish):
		total += finish.global_position.distance_to(previous)
	return total


func _process(_delta: float) -> void :
	if finish == null or not is_instance_valid(finish) or not is_instance_valid(start):
		return
	var from: = start.global_position
	var to: = finish.global_position
	if not _dirty and to.distance_squared_to(_built_for) < 0.0025 and from.distance_squared_to(_built_start) < 0.0025:
		return
	_dirty = false
	_built_for = to
	_built_start = from
	_rebuild(from, to)



static func _curve(a: Vector3, b: Vector3, drop_a: float, drop_b: float, into: PackedVector3Array) -> void :
	var c1: = a + Vector3(0, - drop_a, 0)
	var c2: = b + Vector3(0, - drop_b, 0)
	for index in range(1, 9):
		var t: = index / 8.0
		var u: = 1.0 - t
		into.append(a * u * u * u + c1 * 3.0 * u * u * t + c2 * 3.0 * u * t * t + b * t * t * t)


func _rebuild(from: Vector3, to: Vector3) -> void :

	var path: = PackedVector3Array([from])
	if points.is_empty():
		_curve(from, to, start_drop, finish_drop, path)
	else:
		_curve(from, points[0], start_drop, 0.0, path)
		for index in range(1, points.size()):
			path.append(points[index])
		_curve(points[points.size() - 1], to, 0.0, finish_drop, path)
	if swell >= 0.999:
		_mesh.mesh = tube(path, width / 2.0, SIDES)
		return

	var flat: = float(Config.Water.Charge.Flat)
	var count: = path.size()
	var radii: = PackedFloat32Array()
	for index in count:
		var along: = float(index) / maxf(count - 1, 1)
		var full: = clampf((swell * 1.15 - along) / 0.15, 0.0, 1.0)
		radii.append(width / 2.0 * lerpf(flat, 1.0, full))
	_mesh.mesh = tube(path, width / 2.0, SIDES, -1.0, radii)



static func tube(path: PackedVector3Array, radius: float, sides: int, radius_end: = -1.0, radii: = PackedFloat32Array()) -> ArrayMesh:
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var uvs: = PackedVector2Array()
	var indices: = PackedInt32Array()
	var count: = path.size()
	if count < 2:
		return null
	if radius_end < 0.0:
		radius_end = radius
	var along: = 0.0
	var side: = Vector3.RIGHT
	for index in count:
		var forward: Vector3
		if index == 0:
			forward = path[1] - path[0]
		elif index == count - 1:
			forward = path[index] - path[index - 1]
		else:
			forward = path[index + 1] - path[index - 1]
		if forward.length_squared() < 1e-08:
			forward = Vector3.FORWARD
		forward = forward.normalized()

		side = (side - forward * side.dot(forward))
		if side.length_squared() < 1e-06:
			side = forward.cross(Vector3.UP)
			if side.length_squared() < 1e-06:
				side = Vector3.RIGHT
		side = side.normalized()
		var up: = forward.cross(side)
		if index > 0:
			along += path[index].distance_to(path[index - 1])
		var here: = radii[index] if radii.size() == count else lerpf(radius, radius_end, float(index) / (count - 1))
		for corner in sides + 1:
			var angle: = TAU * corner / sides
			var out: = side * cos(angle) + up * sin(angle)
			vertices.append(path[index] + out * here)
			normals.append(out)
			uvs.append(Vector2(float(corner) / sides * 2.0, along / (radius * 6.0)))
	for index in count - 1:
		for corner in sides:
			var a: = index * (sides + 1) + corner
			var b: = a + sides + 1
			indices.append_array([a, b, a + 1, a + 1, b, b + 1])
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh
