extends RefCounted




static func apply(kit: PolishKit) -> String:
	return IndustryZone.build(kit)
