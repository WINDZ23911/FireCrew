extends RefCounted






const FLOWERS: = [Color8(214, 60, 70), Color8(246, 204, 60), Color8(240, 130, 160), Color8(170, 96, 196), Color8(250, 250, 244), Color8(236, 120, 48)]
const LEAVES: = Color8(70, 118, 58)
const BOX: = Color8(110, 78, 54)
const LANTERN: = Color8(40, 40, 42)
const LAMP_GLASS: = Color8(250, 226, 170)
const STOREY: = 13.0
const DOOR_FRAME_HALF: = 3.0
const POST_GAP: = 0.15
const POST_THINNEST: = 0.3


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("Houses")
	var made: = store.count
	var boxes: = 0
	var lamps: = 0
	var posts: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		if not shell["homely"]:
			continue
		var rng: = kit.rng("house:%d" % shell["model"])
		var place: Transform3D = shell["place"]
		var rows: Dictionary = shell["rows"]
		var keeps: = rows.has("WindowBox")

		var bloom: Color = FLOWERS[rng.randi_range(0, FLOWERS.size() - 1)]
		for row: int in rows.get("Flowers", []):
			bloom = store.color(row)
			store.set_transparency(row, 1.0)
			var at: = store.transform(row).orthonormalized()
			_tufts(kit, folder, at, store.size(row).x, -0.35, bloom, rng)

		if keeps or rng.randf() < 0.3:
			var second: Color = bloom if keeps else FLOWERS[rng.randi_range(0, FLOWERS.size() - 1)]
			for row: int in rows.get("Window", []):
				var at: = store.transform(row).orthonormalized()
				var local: = place.affine_inverse() * at
				var size: = store.size(row)

				if (local.basis * Vector3(0, 0, -1)).z > -0.9 or local.origin.y < STOREY or local.origin.y > STOREY * 2.0:
					continue
				var box_at: = at * Transform3D(Basis(), Vector3(0, - size.y / 2.0 + 0.1, -0.78))
				kit.box(folder, box_at, Vector3(size.x, 0.8, 0.9), BOX, "Wood", "WindowBox")
				_tufts(kit, folder, box_at, size.x, 0.35, second, rng)
				boxes += 1

		var doors: Array = rows.get("Door", [])
		if doors.is_empty():
			continue
		var door: Transform3D = store.transform(doors[0]).orthonormalized()
		if rows.has("Porch"):
			posts += _porch_posts(store, rows, door)
			var hang: = door * Vector3(0, 10.4 - 5.7, -2.2)
			kit.rod(folder, hang, hang - Vector3(0, 0.9, 0), 0.1, LANTERN, "Metal", "LampChain")
			kit.box(folder, Transform3D(door.basis, hang - Vector3(0, 1.4, 0)), Vector3(0.7, 0.9, 0.7), LAMP_GLASS, "SmoothPlastic", "PorchLamp")
			kit.box(folder, Transform3D(door.basis, hang - Vector3(0, 0.85, 0)), Vector3(0.95, 0.2, 0.95), LANTERN, "Metal", "PorchLampCap")
		else:

			kit.box(folder, door * Transform3D(Basis(), Vector3(0, 6.2, -0.3)), Vector3(0.15, 0.15, 0.6), LANTERN, "Metal", "LampArm")
			kit.box(folder, door * Transform3D(Basis(), Vector3(0, 6.0, -0.6)), Vector3(0.6, 0.85, 0.6), LAMP_GLASS, "SmoothPlastic", "WallLamp")
			kit.box(folder, door * Transform3D(Basis(), Vector3(0, 6.5, -0.6)), Vector3(0.8, 0.18, 0.8), LANTERN, "Metal", "WallLampCap")
		lamps += 1
	return "%d window boxes, %d door lamps, %d porch posts moved (%d parts)" % [boxes, lamps, posts, store.count - made]






static func _porch_posts(store: PartStore, rows: Dictionary, door: Transform3D) -> int:
	var frame_half: = DOOR_FRAME_HALF
	for row: int in rows.get("DoorFrame", []):
		frame_half = store.size(row).x / 2.0
	var inverse: = door.affine_inverse()
	var changed: = 0
	for row: int in rows.get("PorchPost", []):
		var post: = store.transform(row)
		var local: = inverse * post.origin
		var side: = signf(local.x)

		var clear: = INF
		for part_name: String in ["WindowFrame", "Shutter"]:
			for other: int in rows.get(part_name, []):
				var at: = inverse * store.position(other)
				if absf(at.z) > 1.0 or absf(at.y) > 9.0 or signf(at.x) != side:
					continue
				clear = minf(clear, absf(at.x) - store.size(other).x / 2.0)
		var width: = store.size(row).x
		if absf(local.x) + width / 2.0 + POST_GAP <= clear:
			continue
		var room: = clear - frame_half - POST_GAP * 2.0
		if room >= POST_THINNEST:
			width = minf(width, room)
			local.x = side * (frame_half + POST_GAP + room / 2.0)
			store.set_transform(row, Transform3D(post.basis, door * local))
			store.set_size(row, Vector3(width, store.size(row).y, width))
		else:
			store.set_transparency(row, 1.0)
			store.set_flags(row, 0)
		changed += 1
	return changed




static func _tufts(kit: PolishKit, folder: int, at: Transform3D, width: float, lift: float, bloom: Color, rng: RandomNumberGenerator) -> void :
	kit.box(folder, at * Transform3D(Basis(), Vector3(0, lift + 0.2, 0)), Vector3(width - 0.3, 0.45, 0.7), LEAVES, "LeafyGrass", "FlowerLeaves")
	var count: = maxi(int(width / 1.1), 2)
	for i in count:
		var x: = - width / 2.0 + (i + 0.5) * width / count + rng.randf_range(-0.2, 0.2)
		var tint: = bloom.lerp(Color.WHITE, rng.randf_range(0.0, 0.25))
		var size: = rng.randf_range(0.6, 0.85)
		kit.ball(folder, at * Vector3(x, lift + 0.55 + rng.randf_range(0.0, 0.2), rng.randf_range(-0.12, 0.12)), Vector3(size, size * 0.8, size), tint, "Fabric", "Bloom")
