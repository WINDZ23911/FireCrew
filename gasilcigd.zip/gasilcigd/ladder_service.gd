class_name LadderService
extends Node















const MAX_ELEVATION: = 80.0
const CLEAR_ELEVATION: = 8.0



const MIN_ELEVATION: = -22.0
const LOW_TURN: = 40.0
const FLOOR_ROOM: = 0.25
const MAX_OUTREACH: = 45.0
const OUTREACH_EASE: = 1.15
const TURN_SPEED: = 0.35
const TURN_SIGN: = -1.0
const TURN_PICKUP: = 3.0
const RAISE_SPEED: = 9.0
const SLIDE_SPEED: = 6.0
const STEP_UP: = 0.1
const JACK_TIME: = 2.5
const LEVER_THROW: = 38.0
const STILL: = 1.0
const DRY_EVERY: = 8.0
const AIM_FAR: = 600.0
const AIM_OPEN: = 300.0


const STAND_REACH: = 10.0
const PERCH_REACH: = 12.0
const CLIMB_SPEED: = 12.0
const CLIMB_STEEP: = 40.0
const BASKET_FLOOR: = Vector3(4.6, 0.3, 3.6)
const MONITOR_RED: = Color(170 / 255.0, 30 / 255.0, 26 / 255.0)

static var current: LadderService

var vehicle: Vehicle
var data: Dictionary
var state: = "stowed"
var elevation: = 0.0
var extension: = 0.0
var turned: = 0.0
var blocked: Variant = null
var controller: Player
var pace: = 1.0
var stowing: = false
var from_basket: = false

var turntable: Node3D
var boom: Node3D
var sections: Array[Node3D] = []
var basket: Node3D
var floor_node: Node3D
var nozzle: Node3D
var _monitor_yaw: Node3D
var _monitor_pitch: Node3D
var seat: Node3D
var perch: Node3D
var monitor: Dictionary

var _pivot: Vector3
var _turn_centre: Vector3
var _hinge: Vector3
var _length: = 24.0
var _slide: = 46.0
var _max_outreach: = MAX_OUTREACH
var _input: = {"turn": 0.0, "raise": 0.0, "slide": 0.0}
var _turn_rate: = 0.0
var _want_water: = false
var _aim_at: Variant = null
var _last_dry: = -100.0
var _jacks: Array = []
var _jack_amount: = 0.0
var _jack_goal: = 0.0
var _jack_player: Player
var _lever: Node3D
var _lever_lamp: MeshInstance3D
var _settle_until: = 0.0
var _prompt: Prompt
var _seat_prompt: Prompt
var _perch_prompt: Prompt
var _stand_rider: Player
var _perch_rider: Player
var _lamp: SpotLight3D
var _bodies: Array[RID] = []
var _aboard: Dictionary = {}
var _stow_asked: = false
var _water_on: = false
var _let_go: Dictionary = {}
var _debug_aim: Variant = null


var _solids: Array = []


var _shown_pose: Array = []
var _pose_fresh: = false
var _shown_spraying: = false
var _shown_supplied: = false
var _said: Variant = null
var _said_at: = 0.0
var _aim_said_at: = 0.0
var _my_seat: Node3D
var _debug_keys: Array = []
var _debug_keys_until: = -1.0


func _init(ladder_truck: Vehicle = null) -> void :
	vehicle = ladder_truck
	current = self


func _ready() -> void :
	data = vehicle.data["ladder"]
	_pivot = vehicle.v(data["pivot"])
	_turn_centre = vehicle.v(data["turntable"])
	_hinge = vehicle.v(data["basketHinge"])
	_length = data["sectionLength"]
	_slide = data["slide"]
	_max_outreach = float(data.get("maxOutreach", MAX_OUTREACH)) * OUTREACH_EASE
	_build_ladder()
	_build_basket()
	_build_jacks()
	_build_prompts()
	var settings: Dictionary = Config.Ladder.Monitor
	monitor = {
		"vehicle": vehicle, "node": nozzle, "use": float(settings["Use"]), "power": float(settings["Power"]), 
		"speed": float(settings["Speed"]), "state": monitor_state, "exclude": passes(), 
	}
	if HoseService.current:
		HoseService.current.add_monitor(monitor)
	_place()
	_share()
	_debug.call_deferred()


func _exit_tree() -> void :
	if current == self:
		current = null


	for solid: AnimatableBody3D in _solids:
		if is_instance_valid(solid) and is_instance_valid(vehicle):
			solid.remove_collision_exception_with(vehicle)
			vehicle.remove_collision_exception_with(solid)
	_solids.clear()







func _dress(node: Node3D, object: String, place: Transform3D) -> void :
	var inverse: = place.affine_inverse()
	for mesh: MeshInstance3D in vehicle.objects.get(object, []):
		var was: = mesh.transform
		if mesh.get_parent():
			mesh.get_parent().remove_child(mesh)
		node.add_child(mesh)
		mesh.transform = inverse * was




func _solid(parent: Node3D, size: Vector3, place: Vector3) -> AnimatableBody3D:
	var solid: = AnimatableBody3D.new()
	solid.sync_to_physics = false
	solid.collision_layer = World.LAYER_VEHICLE
	solid.collision_mask = 0
	var shape: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = size
	shape.shape = box
	solid.add_child(shape)
	parent.add_child(solid)
	solid.position = place
	solid.add_collision_exception_with(vehicle)
	vehicle.add_collision_exception_with(solid)
	_bodies.append(solid.get_rid())
	_solids.append(solid)
	return solid


func _build_ladder() -> void :

	turntable = vehicle.hang("Turntable", Transform3D(Basis.IDENTITY, _turn_centre))
	_solid(turntable, Vector3(6, 0.5, 6), Vector3(0, 0.75, 0))
	var seat_place: Array = data["operatorSeat"]
	seat = Node3D.new()
	seat.name = "LadderControlSeat"
	turntable.add_child(seat)

	seat.position = Vector3(seat_place[0], seat_place[1] - 0.5, seat_place[2]) - _turn_centre
	seat.rotation.y = deg_to_rad(seat_place[3])

	seat.set_meta("grips", {
		"R": [Vector3(0.4, 2.05, -1.75), Vector3.UP, Vector3(0.2, -0.4, 1.0)], 
		"L": [Vector3(-0.4, 2.05, -1.75), Vector3.UP, Vector3(-0.2, -0.4, 1.0)], 
	})

	boom = Node3D.new()
	boom.name = "Boom"
	turntable.add_child(boom)
	boom.position = _pivot - _turn_centre

	var names: Array = data["sections"]
	for index in names.size():
		var section: = Node3D.new()
		section.name = names[index]
		boom.add_child(section)
		_dress(section, names[index], Transform3D(Basis.IDENTITY, _pivot))
		_solid(section, Vector3(4, 2, _length), Vector3(0, -1.2 + STEP_UP * index, - _length / 2.0))
		sections.append(section)



func _build_basket() -> void :
	basket = Node3D.new()
	basket.name = "LadderBasket"
	sections[sections.size() - 1].add_child(basket)
	basket.position = _hinge - _pivot
	_dress(basket, "Basket", Transform3D(Basis.IDENTITY, _hinge))
	var middle: = Vector3(0, -1.5, -2.0)
	_solid(basket, BASKET_FLOOR, middle + Vector3(0, -0.15, 0))
	for rail: Array in [[Vector3(4.6, 3.3, 0.2), Vector3(0, 1.8, -1.8)], [Vector3(0.2, 3.3, 3.6), Vector3(-2.3, 1.8, 0)], [Vector3(0.2, 3.3, 3.6), Vector3(2.3, 1.8, 0)]]:
		_solid(basket, rail[0], middle + Vector3(0, -0.15, 0) + rail[1])
	floor_node = Node3D.new()
	floor_node.name = "Floor"
	basket.add_child(floor_node)
	floor_node.position = middle


	perch = Node3D.new()
	perch.name = "LadderBasketSeat"
	basket.add_child(perch)
	perch.position = middle + Vector3(0, 0.2, 0.7)

	perch.set_meta("stand", true)
	perch.set_meta("grips", {
		"R": [Vector3(2.25, 3.25, -0.6), Vector3(0, 0, -1), Vector3(-0.3, 0.9, 0.4)], 
		"L": [Vector3(-2.25, 3.25, -0.6), Vector3(0, 0, -1), Vector3(0.3, 0.9, 0.4)], 
	})



	var gun: = middle + Vector3(0, 3.6, -2.4)
	var upright: = Basis(Vector3.FORWARD, PI / 2.0)
	var along: = Basis(Vector3.UP, PI / 2.0)
	var chrome: = Color(0.78, 0.8, 0.82)
	vehicle.add_part("LadderMonitorFoot", Vector3(0.7, 0.5, 0.9), Transform3D(Basis.IDENTITY, gun + Vector3(0, -0.45, 0.35)), MONITOR_RED.darkened(0.2), PartStore.Shape.BLOCK, "Metal", basket)
	vehicle.add_part("LadderMonitorPost", Vector3(0.55, 0.62, 0.62), Transform3D(upright, gun + Vector3(0, -0.1, 0)), MONITOR_RED, PartStore.Shape.CYLINDER, "Metal", basket)
	_monitor_yaw = Node3D.new()
	_monitor_yaw.name = "LadderMonitor"
	basket.add_child(_monitor_yaw)
	_monitor_yaw.position = gun + Vector3(0, 0.2, 0)
	vehicle.add_part("Swivel", Vector3(0.2, 0.74, 0.74), Transform3D(upright, Vector3.ZERO), chrome, PartStore.Shape.CYLINDER, "Metal", _monitor_yaw)
	_monitor_pitch = Node3D.new()
	_monitor_yaw.add_child(_monitor_pitch)
	_monitor_pitch.position = Vector3(0, 0.3, 0)
	vehicle.add_part("Elbow", Vector3(0.62, 0.62, 0.62), Transform3D.IDENTITY, MONITOR_RED, PartStore.Shape.BALL, "Metal", _monitor_pitch)
	vehicle.add_part("Barrel", Vector3(1.3, 0.44, 0.44), Transform3D(along, Vector3(0, 0, -0.7)), MONITOR_RED, PartStore.Shape.CYLINDER, "Metal", _monitor_pitch)
	vehicle.add_part("Waist", Vector3(0.5, 0.34, 0.34), Transform3D(along, Vector3(0, 0, -1.55)), MONITOR_RED.darkened(0.15), PartStore.Shape.CYLINDER, "Metal", _monitor_pitch)
	vehicle.add_part("Tip", Vector3(0.45, 0.42, 0.42), Transform3D(along, Vector3(0, 0, -2.0)), chrome, PartStore.Shape.CYLINDER, "Metal", _monitor_pitch)
	vehicle.add_part("Bumper", Vector3(0.12, 0.5, 0.5), Transform3D(along, Vector3(0, 0, -2.25)), Color(0.12, 0.12, 0.13), PartStore.Shape.CYLINDER, "Rubber", _monitor_pitch)
	vehicle.add_part("Tiller", Vector3(0.1, 0.1, 0.9), Transform3D(Basis.IDENTITY, Vector3(0, 0.05, 0.6)), chrome, PartStore.Shape.BLOCK, "Metal", _monitor_pitch)
	vehicle.add_part("Grip", Vector3(0.16, 0.16, 0.3), Transform3D(Basis.IDENTITY, Vector3(0, 0.05, 1.1)), Color(0.12, 0.12, 0.13), PartStore.Shape.BLOCK, "Rubber", _monitor_pitch)
	nozzle = Node3D.new()
	nozzle.name = "Nozzle"
	_monitor_pitch.add_child(nozzle)
	nozzle.position = Vector3(0, 0, -2.35)


	_lamp = SpotLight3D.new()
	_lamp.spot_range = 60.0
	_lamp.spot_angle = 50.0
	_lamp.light_energy = 2.5 * 3.0
	_lamp.visible = false
	basket.add_child(_lamp)
	_lamp.transform = Transform3D(Basis.IDENTITY, middle + Vector3(0, -0.5, -1.5)) * Rbx.angles(deg_to_rad(-40), 0, 0)



func _build_jacks() -> void :
	var jacks: Dictionary = data["jacks"]
	for key: String in jacks:
		var info: Dictionary = jacks[key]
		var jack: = {"side": float(info["side"]), "out": float(info["out"]), "down": float(info["down"]), "beams": [], "legs": []}
		if vehicle.objects.has(info["beam"]):
			jack["beams"].append(vehicle.hang(info["beam"], Transform3D.IDENTITY))
		if vehicle.objects.has(info["leg"]):
			jack["legs"].append(vehicle.hang(info["leg"], Transform3D.IDENTITY))
		_jacks.append(jack)
	_build_lever()





func _build_lever() -> void :
	var intake: Variant = vehicle.data.get("intake")
	var x: = 2.2 if intake != null and float(intake[0]) < 0.0 else -2.4
	var face: = Vector3(x, 1.6, float(vehicle.data["rear"]) + 0.12)
	var grey: = Color(0.1, 0.1, 0.11)
	var dark: = Color(0.12, 0.12, 0.13)
	vehicle.add_part("StabiliserBox", Vector3(1.7, 1.5, 0.3), Transform3D(Basis.IDENTITY, face + Vector3(0, 0, 0.15)), grey, PartStore.Shape.BLOCK, "SmoothPlastic")
	vehicle.add_part("StabiliserSlot", Vector3(1.1, 0.16, 0.04), Transform3D(Basis.IDENTITY, face + Vector3(0, -0.2, 0.31)), dark, PartStore.Shape.BLOCK, "Metal")
	vehicle.add_part("StabiliserStripe", Vector3(1.7, 0.18, 0.04), Transform3D(Basis.IDENTITY, face + Vector3(0, 0.62, 0.31)), Color(0.95, 0.72, 0.1), PartStore.Shape.BLOCK, "SmoothPlastic")
	vehicle.add_part("StabiliserLampRim", Vector3(0.08, 0.28, 0.28), Transform3D(Basis(Vector3.UP, PI / 2.0), face + Vector3(0.6, 0.25, 0.33)), dark, PartStore.Shape.CYLINDER, "Metal")
	_lever_lamp = vehicle.add_part("StabiliserLamp", Vector3(0.06, 0.2, 0.2), Transform3D(Basis(Vector3.UP, PI / 2.0), face + Vector3(0.6, 0.25, 0.37)), Color(0.2, 1.0, 0.35), PartStore.Shape.CYLINDER, "Neon")
	_lever_lamp.visible = false
	_lever = Node3D.new()
	_lever.name = "StabiliserLever"
	vehicle.body.add_child(_lever)
	_lever.position = face + Vector3(0, -0.2, 0.36)
	vehicle.add_part("LeverHub", Vector3(0.14, 0.3, 0.3), Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3.ZERO), dark, PartStore.Shape.CYLINDER, "Metal", _lever)
	vehicle.add_part("LeverArm", Vector3(0.12, 1.1, 0.12), Transform3D(Basis.IDENTITY, Vector3(0, 0.55, 0.06)), Color(0.78, 0.8, 0.82), PartStore.Shape.BLOCK, "Metal", _lever)
	vehicle.add_part("LeverKnob", Vector3(0.34, 0.34, 0.34), Transform3D(Basis.IDENTITY, Vector3(0, 1.15, 0.06)), MONITOR_RED, PartStore.Shape.BALL, "SmoothPlastic", _lever)


func _place_jacks(amount: float) -> void :

	var out: = clampf(amount / 0.6, 0.0, 1.0)
	var down: = clampf((amount - 0.6) / 0.4, 0.0, 1.0)
	for jack: Dictionary in _jacks:
		var slide_out: = Vector3(jack["side"] * jack["out"] * out, 0, 0)
		for beam: Node3D in jack["beams"]:
			beam.position = slide_out
		for leg: Node3D in jack["legs"]:
			leg.position = slide_out + Vector3(0, - jack["down"] * down, 0)


	if _lever:
		_lever.rotation.z = deg_to_rad(LEVER_THROW * (1.0 - 2.0 * smoothstep(0.0, 0.25, amount)))
		_lever_lamp.visible = amount >= 0.999


func _build_prompts() -> void :
	var truck_name: Variant = Text.named("vehicles", vehicle.spec["name"])
	var panel: = Node3D.new()
	panel.name = "StabiliserPanel"
	vehicle.add_child(panel)
	panel.position = Vector3(_lever.position.x, 1.5, float(vehicle.data["rear"]) + 0.6)
	_prompt = Prompt.make(panel, Text.m("gear.ladder.jacksSet"), truck_name, 0.5, 10.0)
	_prompt.triggered.connect(use_jacks)

	var at_stand: = Node3D.new()
	seat.add_child(at_stand)
	at_stand.position = Vector3(0, 2.0, 0)
	_seat_prompt = Prompt.make(at_stand, Text.m("gear.ladder.takeControls"), truck_name, 0.3, STAND_REACH)
	_seat_prompt.triggered.connect( func(player: Player) -> void : sit(player, false))

	var at_perch: = Node3D.new()
	perch.add_child(at_perch)
	at_perch.position = Vector3(0, 1.8, 0)
	_perch_prompt = Prompt.make(at_perch, Text.m("gear.ladder.takeControls"), Text.m("gear.ladder.basket"), 0.3, PERCH_REACH)
	_perch_prompt.triggered.connect( func(player: Player) -> void : sit(player, true))





func _set_state(value: String) -> void :
	state = value
	_lamp.visible = value == "ready"



func use_jacks(player: Player) -> void :
	if state == "busy":
		return
	if state == "stowed":
		if _settle_until > 0.0:
			return
		var speed: = _rolling()
		if speed > STILL:

			if speed > float(Config.Ladder.SettleSpeed):
				Game.notify(Text.m("gear.ladder.stopFirst"), "", player)
				return
			_jack_player = player
			_settle_until = Game.now() + float(Config.Ladder.SettleTime)
			_prompt.action = Text.m("gear.ladder.settling")
			return
		_lower_jacks(player)
	else:
		if not lies_stowed():
			Game.notify(Text.m("gear.ladder.stowFirst"), "", player)
			return
		_set_state("busy")
		_turn_rate = 0.0
		_jack_player = player
		_jack_goal = 0.0

		vehicle.freeze = false




func _rolling() -> float:
	var velocity: = vehicle.linear_velocity
	return Vector2(velocity.x, velocity.z).length()


func _lower_jacks(player: Player) -> void :
	_set_state("busy")
	vehicle.locked = true
	_jack_player = player
	_jack_goal = 1.0




func _settle() -> void :
	var player: = _jack_player
	var still: = _rolling() <= STILL
	if still or Game.now() > _settle_until:
		_settle_until = 0.0
		_prompt.action = Text.m("gear.ladder.jacksSet")
		if still:
			_lower_jacks(player)
		else:
			_jack_player = null
			Game.notify(Text.m("gear.ladder.stopFirst"), "", player)


func _move_jacks(dt: float) -> void :
	_jack_amount = move_toward(_jack_amount, _jack_goal, dt / JACK_TIME)
	_place_jacks(_jack_amount)
	if not is_equal_approx(_jack_amount, _jack_goal):
		return
	if _jack_goal > 0.5:
		_jacks_down()
		Game.notify(Text.m("gear.ladder.ready"), "", _jack_player)
	else:
		vehicle.locked = false
		_prompt.action = Text.m("gear.ladder.jacksSet")
		_set_state("stowed")
		Game.notify(Text.m("gear.ladder.stowed"), "", _jack_player)
	_jack_player = null



func _jacks_down() -> void :
	vehicle.locked = true
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.angular_velocity = Vector3.ZERO
	vehicle.freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
	vehicle.freeze = true
	_jack_amount = 1.0
	_jack_goal = 1.0
	_place_jacks(1.0)
	elevation = 0.0
	extension = 0.0
	stowing = false
	_prompt.action = Text.m("gear.ladder.jacksRaise")
	_set_state("ready")



func lies_stowed() -> bool:
	return absf(turned) < 1.5 and elevation < 1.5 and extension < 0.4






func sit(player: Player, in_basket: bool) -> void :
	if player.seat != null or player.health <= 0.0:
		return
	if (_perch_rider if in_basket else _stand_rider) != null:
		return
	if in_basket:
		_perch_rider = player
	else:
		_stand_rider = player
	player.sit(perch if in_basket else seat)
	if player.is_local:
		player.camera.yaw = (perch if in_basket else seat).global_rotation.y
	_refresh_controller()



func leave(player: Player) -> void :
	if player == _perch_rider:
		_perch_rider = null
		player.leave_seat(floor_node.global_position + Vector3(0, 0.2, 0))
	elif player == _stand_rider:
		_stand_rider = null
		player.leave_seat(_beside_stand())
	else:
		return
	if player.is_local and player.camera.subject == floor_node:
		player.camera.subject = null
	_refresh_controller()



func _beside_stand() -> Vector3:
	var out: = seat.global_position - turntable.global_position
	out.y = 0.0
	var beside: = seat.global_position + out.normalized() * 4.5
	var ground: = Game.world.raycast(beside + Vector3(0, 3, 0), beside + Vector3(0, -40, 0), World.LAYER_SOLID)
	return (ground["position"] if not ground.is_empty() else beside) + Vector3(0, 0.1, 0)


func _refresh_controller() -> void :
	if Net.is_client():

		_stand_rider = null
		_perch_rider = null
		for player in Game.players:
			if is_instance_valid(player) and player.seat == seat:
				_stand_rider = player
			elif is_instance_valid(player) and player.seat == perch:
				_perch_rider = player
		controller = _stand_rider if _stand_rider != null else _perch_rider
		pace = 1.0 if _stand_rider != null else float(Config.Ladder.BasketPace)
		return

	if _stand_rider != null and ( not is_instance_valid(_stand_rider) or _stand_rider.seat != seat):
		_stand_rider = null
	if _perch_rider != null and ( not is_instance_valid(_perch_rider) or _perch_rider.seat != perch):
		_perch_rider = null
	_seat_prompt.enabled = _stand_rider == null
	_perch_prompt.enabled = _perch_rider == null
	var who: = _stand_rider if _stand_rider != null else _perch_rider
	if who == controller:
		return
	controller = who
	pace = 1.0 if _stand_rider != null else float(Config.Ladder.BasketPace)
	_input = {"turn": 0.0, "raise": 0.0, "slide": 0.0}
	_want_water = false
	_aim_at = null




func control(player: Player, turn: float, raise: float, slide: float, stow: bool, water: bool, aim: Variant) -> void :
	if player != controller:
		return
	_input["turn"] = clampf(turn, -1.0, 1.0)
	_input["raise"] = clampf(raise, -1.0, 1.0)
	_input["slide"] = clampf(slide, -1.0, 1.0)
	if stow:
		stowing = true
	elif turn != 0.0 or raise != 0.0 or slide != 0.0:
		stowing = false
	_want_water = water and aim is Vector3 and (aim as Vector3).is_finite()
	_aim_at = aim if _want_water else null
	if _want_water and state == "ready" and vehicle.water <= 0.0 and Game.now() - _last_dry > DRY_EVERY:
		_last_dry = Game.now()
		Game.notify(Text.m("gear.ladder.noWater"), "", player)




func monitor_state() -> Variant:
	if Net.is_client():
		return null
	if state != "ready" or controller == null or _aim_at == null:
		return null
	var offset: Vector3 = _aim_at - nozzle.global_position
	if offset.length() < 3.0 or offset.normalized().dot( - basket.global_basis.z) < cos(deg_to_rad(float(Config.Ladder.Monitor.Arc))):
		return null
	return [controller, _aim_at]



func passes() -> Array[RID]:
	var rids: Array[RID] = [vehicle.get_rid()]
	rids.append_array(_bodies)
	return rids



func _aim_point(player: Player) -> Vector3:
	if _debug_aim != null:
		return basket.global_transform * (_debug_aim as Vector3)
	var camera: = get_viewport().get_camera_3d()
	if player.camera != null:
		camera = player.camera.camera
	var from: = camera.global_position
	var along: = - camera.global_basis.z
	var exclude: = passes()
	exclude.append(player.get_rid())
	var hit: = Game.world.raycast(from, from + along * AIM_FAR, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
	return hit["position"] if not hit.is_empty() else from + along * AIM_OPEN


func _process(_delta: float) -> void :
	var player: = Game.local_player
	if player == null:
		return
	var seated: = player == _stand_rider or player == _perch_rider
	if not seated:
		return
	if Game.ui_open:
		_ask(0.0, 0.0, 0.0, false, false, null)
		return
	if Input.is_action_just_pressed("veh_exit"):
		Net.request("ladder.leave")
		return
	var in_control: = state == "ready" and controller == player
	if not in_control:
		_water_on = false
		from_basket = false
		_said = null
	else:
		if Input.is_action_just_pressed("ladder_stow"):
			_stow_asked = true
		if Input.is_action_just_pressed("monitor_water"):
			_water_on = not _water_on
		if Input.is_action_just_pressed("basket_camera"):
			from_basket = not from_basket
		var water: = _water_on or (Input.is_action_pressed("fire") and player.camera != null and player.camera.captured)
		var keys: = [Input.get_axis("move_left", "move_right"), Input.get_axis("move_back", "move_forward"), Input.get_axis("ladder_retract", "ladder_extend")]
		if not _debug_keys.is_empty() and (_debug_keys.size() < 5 or HostClock.now() >= float(_debug_keys[4])):
			if _debug_keys_until < 0.0:
				_debug_keys_until = Game.now() + float(_debug_keys[3])
			if Game.now() < _debug_keys_until:
				keys = _debug_keys.slice(0, 3)
		_ask(keys[0], keys[1], keys[2], _stow_asked, water, _aim_point(player) if water else null)
		_stow_asked = false

	if player.camera != null:
		var watch: = in_control and player == _stand_rider and from_basket
		if watch and player.camera.subject == null:
			player.camera.subject = floor_node
			player.camera.subject_height = 4.0
			player.camera.subject_distance = 0.0
		elif not watch and player.camera.subject == floor_node:
			player.camera.subject = null





func _ask(turn: float, raise: float, slide: float, stow: bool, water: bool, aim: Variant) -> void :
	if not Net.is_client():
		Net.request("ladder.control", [turn, raise, slide, stow, water, aim])
		return
	var saying: = [snappedf(turn, 0.1), snappedf(raise, 0.1), snappedf(slide, 0.1), water]
	var now: = Game.now()
	if stow or _said == null or saying != _said or now - _said_at > 0.5:
		_said = saying
		_said_at = now
		_aim_said_at = now
		Net.request("ladder.control", [saying[0], saying[1], saying[2], stow, water, aim])
	elif water and now - _aim_said_at >= 0.05:
		_aim_said_at = now
		Net.push("ladder.aim", [aim])





func _share() -> void :
	Net.handle("ladder.control", control)
	Net.handle("ladder.aim", func(player: Player, aim: Variant) -> void :
		if player == controller and _want_water and aim is Vector3 and (aim as Vector3).is_finite():
			_aim_at = aim
	)
	Net.handle("ladder.leave", leave)

	Net.share("ladder.pose", func() -> Variant: return [turned, elevation, extension, _jack_amount], _apply_pose, 20.0, true)

	Net.share("ladder.state", func() -> Variant:
		return [state, stowing, blocked, bool(monitor.get("spraying", false)), supplied(), _jack_goal, _settle_until > 0.0]
	, _apply_state, 5.0)
	Net.started.connect( func() -> void :
		_pose_fresh = false
		_said = null
	)
	Game.local_player.seat_changed.connect(_on_my_seat)


func _apply_pose(pose: Variant) -> void :
	_shown_pose = pose
	if not _pose_fresh:
		_pose_fresh = true
		turned = pose[0]
		elevation = pose[1]
		extension = pose[2]
		_jack_amount = pose[3]
		_place_jacks(_jack_amount)
		_place()


func _apply_state(shown: Variant) -> void :
	if state != shown[0]:
		_set_state(shown[0])
	stowing = shown[1]
	blocked = shown[2]
	_shown_spraying = shown[3]
	_shown_supplied = shown[4]
	_jack_goal = shown[5]
	var settling: bool = shown.size() > 6 and shown[6]
	if settling:
		_prompt.action = Text.m("gear.ladder.settling")
	elif state == "stowed":
		_prompt.action = Text.m("gear.ladder.jacksSet")



func _follow(delta: float) -> void :
	if _shown_pose.is_empty():
		return
	var gain: = 1.0 - exp( - delta * 14.0)
	turned = wrapf(rad_to_deg(lerp_angle(deg_to_rad(turned), deg_to_rad(_shown_pose[0]), gain)), -180.0, 180.0)
	elevation = lerpf(elevation, _shown_pose[1], gain)
	extension = lerpf(extension, _shown_pose[2], gain)
	_jack_amount = lerpf(_jack_amount, _shown_pose[3], gain)
	_place_jacks(_jack_amount)



func _on_my_seat(now_in: Node3D) -> void :
	var player: = Game.local_player
	var was: = _my_seat
	_my_seat = now_in
	if now_in == seat or now_in == perch:
		if player.camera != null:
			player.camera.yaw = now_in.global_rotation.y
	elif was == seat or was == perch:
		if player.camera != null and player.camera.subject == floor_node:
			player.camera.subject = null
		from_basket = false
		_water_on = false


		if player.health > 0.0 and player.global_position.distance_to(was.global_position) < 2.0:
			player.teleport(_beside_stand() if was == seat else floor_node.global_position + Vector3(0, 0.2, 0))


func _physics_process(delta: float) -> void :
	_refresh_controller()
	if Net.is_client():
		_follow(delta)
	elif state == "busy":
		_move_jacks(delta)
	elif _settle_until > 0.0:
		_settle()
	elif state == "ready":
		_work(delta)
	_place()
	_climb(delta)
	_aim_monitor(delta)



func reach_of(e: float, x: float) -> float:
	return (_length + x) * cos(deg_to_rad(e))




var _own: Array[RID] = []
func _own_rids() -> Array[RID]:
	if _own.is_empty():
		_own.append_array(_bodies)
		for node: Node in vehicle.find_children("*", "CollisionObject3D", true, false):
			_own.append((node as CollisionObject3D).get_rid())
		_own.append(vehicle.get_rid())
	return _own





func _floor_room(e: float, x: float) -> float:
	var pivot: = boom.global_position
	var along: = - boom.global_basis.z
	var flat: = Vector3(along.x, 0.0, along.z)
	flat = flat.normalized() if flat.length() > 0.01 else - turntable.global_basis.z
	var tip: = pivot + flat * (_length + x) * cos(deg_to_rad(e)) + Vector3(0, (_length + x) * sin(deg_to_rad(e)), 0)
	var tip_now: = pivot + along * length()
	var hang: = tip_now.y - floor_node.global_position.y
	var floor_y: = tip.y - hang


	var ground: = Game.world.raycast(Vector3(tip.x, pivot.y + 2.0, tip.z), Vector3(tip.x, pivot.y - 60.0, tip.z), World.LAYER_SOLID, _own_rids())
	if ground.is_empty():
		return INF
	return floor_y - ground["position"].y


func _work(dt: float) -> void :
	var want_turn: float = _input["turn"]
	var want_raise: float = _input["raise"]
	var want_slide: float = _input["slide"]
	if stowing:

		want_slide = -1.0 if extension > 0.0 else 0.0

		var low: = elevation < CLEAR_ELEVATION and absf(turned) > 4.0
		want_turn = 0.0 if (extension > 0.0 or low) else TURN_SIGN * clampf( - turned / 10.0, -1.0, 1.0)
		if extension > 0.0:
			want_raise = 0.0
		elif low:
			want_raise = 1.0
		elif absf(turned) > 1.0:
			want_raise = 0.0
		else:
			want_raise = -1.0
		if extension <= 0.0 and absf(turned) <= 1.0 and elevation <= 0.0:
			stowing = false

	var stopped: Variant = null



	if elevation < CLEAR_ELEVATION and want_turn != 0.0 and not stowing:
		want_turn = 0.0
		if absf(turned) < LOW_TURN and want_raise <= 0.0:
			want_raise = 1.0
		elif want_raise <= 0.0:
			stopped = Text.m("gear.ladder.raiseBeforeTurn")
	var lowest: = 0.0
	if absf(turned) >= LOW_TURN:
		lowest = MIN_ELEVATION
	elif absf(turned) > 4.0:
		lowest = CLEAR_ELEVATION
	var quick: = 1.0 if stowing else pace
	var new_elevation: = clampf(elevation + want_raise * RAISE_SPEED * quick * dt, minf(lowest, elevation), MAX_ELEVATION)
	var new_extension: = clampf(extension + want_slide * SLIDE_SPEED * quick * dt, 0.0, _slide)

	if (new_elevation < elevation or new_extension > extension) and new_elevation < CLEAR_ELEVATION:
		var room: = _floor_room(new_elevation, new_extension)
		if room < FLOOR_ROOM:
			if new_elevation < elevation:
				new_elevation = elevation
			if new_extension > extension:
				new_extension = extension
			if _floor_room(elevation, extension) < FLOOR_ROOM + 0.5:
				stopped = Text.m("gear.ladder.onGround")



	if reach_of(new_elevation, new_extension) > _max_outreach and reach_of(new_elevation, new_extension) > reach_of(elevation, extension):
		var cap: = _max_outreach / maxf(cos(deg_to_rad(new_elevation)), 0.01) - _length
		var fitted: = clampf(cap, 0.0, new_extension)
		if reach_of(new_elevation, fitted) > _max_outreach + 0.01:
			new_elevation = elevation
			fitted = minf(extension, new_extension)
		if want_slide > 0.0 or new_elevation == elevation:
			stopped = Text.m("gear.ladder.reachLimit")
		new_extension = fitted
	elevation = new_elevation
	extension = new_extension
	blocked = stopped


	_turn_rate = move_toward(_turn_rate, TURN_SIGN * want_turn * TURN_SPEED * quick, TURN_PICKUP * dt)
	turned = wrapf(turned + rad_to_deg(_turn_rate * dt), -180.0, 180.0)



func _place() -> void :
	turntable.rotation.y = deg_to_rad(turned)
	boom.rotation.x = deg_to_rad(elevation)

	var last: = sections.size() - 1
	for index in sections.size():
		sections[index].position = Vector3(0, 0, - extension * index / last)

	basket.rotation.x = - deg_to_rad(elevation)






func length() -> float:
	return _length + extension



func height() -> float:
	return floor_node.global_position.y - (vehicle.global_position.y + float(vehicle.data["ground"]))



func max_outreach() -> float:
	return _max_outreach


func outreach() -> float:
	return reach_of(elevation, extension)



func supplied() -> bool:
	if Net.is_client():
		return _shown_supplied
	if HoseService.current:
		for rig: Dictionary in HoseService.current.rigs:
			if rig["vehicle"] == vehicle and rig["supply"]["state"] == "connected":
				return true
	return false




func _aim_monitor(delta: float) -> void :
	if _monitor_yaw == null:
		return
	var yaw: = 0.0
	var pitch: = 0.0
	var aim: Variant = monitor.get("aim")
	if spraying() and aim is Vector3:
		var local: = _monitor_yaw.get_parent_node_3d().global_transform.affine_inverse() * (aim as Vector3) - _monitor_yaw.position
		var arc: = deg_to_rad(float(Config.Ladder.Monitor.Arc))
		yaw = clampf(atan2( - local.x, - local.z), - arc, arc)
		pitch = clampf(atan2(local.y, Vector2(local.x, local.z).length()), deg_to_rad(-60.0), deg_to_rad(45.0))
	var ease: = 1.0 - exp( - delta * 8.0)
	_monitor_yaw.rotation.y = lerp_angle(_monitor_yaw.rotation.y, yaw, ease)
	_monitor_pitch.rotation.x = lerp_angle(_monitor_pitch.rotation.x, pitch, ease)



func spraying() -> bool:
	return _shown_spraying if Net.is_client() else bool(monitor.get("spraying", false))



func seated(player: Player) -> bool:
	return player != null and (player == _stand_rider or player == _perch_rider)


func at_stand(player: Player) -> bool:
	return player != null and player == _stand_rider






func is_up() -> bool:
	return state == "ready"




func is_stowed() -> bool:
	if state == "stowed":
		return true
	return elevation <= 2.0 and absf(turned) <= 3.0 and length() <= _length + 1.0



func basket_transform() -> Transform3D:
	return floor_node.global_transform


func basket_position() -> Vector3:
	return floor_node.global_position




func take_aboard(who: Node3D, rise: = 0.0) -> void :
	if _aboard.has(who):
		return
	_aboard[who] = who.get_parent()
	if who.get_parent():
		who.reparent(floor_node, false)
	else:
		floor_node.add_child(who)
	who.transform = Transform3D(Basis.IDENTITY, Vector3(0, rise, 0.4))


func is_aboard(who: Node3D) -> bool:
	return _aboard.has(who)



func set_down(who: Node3D, rise: = 0.0) -> Transform3D:
	var chassis: = vehicle.global_transform
	var beside: Vector3 = chassis * Vector3(9, 0, -8)
	var ground: = Game.world.raycast(beside + Vector3(0, 4, 0), beside + Vector3(0, -16, 0), World.LAYER_SOLID)
	var floor_y: float = ground["position"].y if not ground.is_empty() else chassis.origin.y - 3.0
	var stand: = Vector3(beside.x, floor_y + rise, beside.z)
	var place: = Rbx.look_at(stand, Vector3(chassis.origin.x, floor_y + rise, chassis.origin.z))
	var home: Variant = _aboard.get(who)
	_aboard.erase(who)
	if home != null and is_instance_valid(home):
		who.reparent(home, false)
	elif who.get_parent() == floor_node:
		who.reparent(get_parent(), false)
	who.global_transform = place
	return place







func _climb(dt: float) -> void :
	var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
	var frame: = boom.global_transform
	var along: = - frame.basis.z

	var foot: = Transform3D(turntable.global_basis, frame.origin)
	for player in Game.players:

		if not player.is_local or player.seat != null or player.frozen or player.health <= 0.0:
			continue
		if Game.now() < _let_go.get(player, 0.0):
			continue
		var local: = frame.affine_inverse() * player.global_position
		var from_foot: = foot.affine_inverse() * player.global_position
		if absf(local.x) > 2.6:
			continue
		var above: = local.y + 0.2
		var on_rungs: = above > -1.2 and above < 1.6 and local.z < 2.4 and local.z > - length() - 0.5
		var at_foot: = not (on_rungs and above > 0.0) and absf(from_foot.z) < 2.6 and from_foot.y > -7.5 and from_foot.y < 0.5
		if not on_rungs and not at_foot:
			continue
		var push: = 0.0
		if not Game.ui_open:
			push = Input.get_axis("move_back", "move_forward")
			if Input.is_action_just_pressed("jump"):
				_let_go[player] = Game.now() + 0.7
				continue
		var climb: = CLIMB_SPEED * Training.factor(player, "ladder")
		if on_rungs and elevation >= CLIMB_STEEP:

			var settle: = minf(1.0, dt * 8.0)
			player.global_position += along * climb * push * dt + frame.basis.y * clampf(0.1 - above, -2.0, 2.0) * settle - frame.basis.x * local.x * settle
			player.velocity = Vector3.ZERO
			player.hold_rungs(boom.global_rotation.y, absf(push) * climb)
		elif at_foot:

			if push > 0.0:
				player.global_position += (Vector3.UP * climb - foot.basis.z * 3.0) * dt
				player.velocity = Vector3(0, gravity * dt, 0)
			elif not player.is_on_floor():
				player.velocity = Vector3(0, gravity * dt, 0)















func _debug() -> void :
	var args: = OS.get_cmdline_user_args()
	var joining: = false
	for arg in args:
		joining = joining or arg.begins_with("--join=")
	for arg in args:
		if arg.begins_with("--ladder-at=") and not joining:

			var n: = arg.substr(12).split_floats(",")
			var spawn: Transform3D = vehicle.spec["spawn"]
			vehicle.global_transform = Transform3D(Basis(Vector3.UP, deg_to_rad(n[2] if n.size() > 2 else 180.0)), Vector3(n[0], spawn.origin.y, n[1]))
			vehicle.reset_physics_interpolation()
	for arg in args:
		if arg.begins_with("--ladder-keys="):
			_debug_keys = Array(arg.get_slice("=", 1).split_floats(","))
		elif arg == "--ladder-trace":
			_trace()
		elif arg.begins_with("--ladder-cam="):

			var n: = arg.substr(13).split_floats(",")
			var view: = Camera3D.new()
			view.far = 5000.0
			add_child(view)
			_debug_view(view, Vector3(n[0], n[1], n[2]), joining)
		elif arg.begins_with("--ladder-leave="):
			_debug_leave(float(arg.get_slice("=", 1)))
	if joining:
		_debug_joined(args)
		return
	for arg in args:
		if arg.begins_with("--ladder="):
			var n: = arg.substr(9).split_floats(",")
			_jacks_down()
			turned = n[0]
			elevation = n[1]
			extension = n[2]
			_place()
		elif arg.begins_with("--ladder-seat="):
			sit(Game.local_player, arg.substr(14) == "perch")
		elif arg.begins_with("--ladder-water"):
			vehicle.fill_water(vehicle.capacity)
			_water_on = true
			_debug_aim = Vector3(0, -10, -40)
			if arg.contains("="):
				var n: = arg.get_slice("=", 1).split_floats(",")
				_debug_aim = Vector3(n[0], n[1], n[2])
		elif arg == "--ladder-climb":

			var player: = Game.local_player
			player.teleport(vehicle.global_transform * Vector3(0, 3.6, _pivot.z + 1.2))
			if player.camera:
				player.camera.yaw = turntable.global_rotation.y
			_trace_climb()
		elif arg == "--ladder-stow":
			_stow_asked = true
		elif arg == "--ladder-jacks":
			use_jacks(Game.local_player)




func _debug_view(view: Camera3D, from: Vector3, joining: bool) -> void :
	view.make_current.call_deferred()
	await get_tree().process_frame
	if joining:
		while not _pose_fresh:
			await get_tree().create_timer(0.2).timeout
		await get_tree().create_timer(1.5).timeout
	view.look_at_from_position(floor_node.global_transform * from, floor_node.global_position + Vector3(0, 2, 0))


func _debug_leave(after: float) -> void :
	while not seated(Game.local_player):
		await get_tree().create_timer(0.1).timeout
	await get_tree().create_timer(after).timeout
	Net.request("ladder.leave")
	await get_tree().create_timer(1.0).timeout
	var player: = Game.local_player
	print("ladder: left: seat %s, at %s, %.1f studs from the stand, on the floor %s" % [player.seat, player.global_position, player.global_position.distance_to(seat.global_position), player.is_on_floor()])



func _debug_joined(args: PackedStringArray) -> void :
	while not (Net.is_client() and Net.players.size() > 1 and _pose_fresh):
		await get_tree().create_timer(0.2).timeout
	await get_tree().create_timer(1.0).timeout
	var player: = Game.local_player
	for arg in args:
		if arg == "--ladder-jacks":
			player.teleport(_prompt.global_position + vehicle.global_basis.z * 4.0 + Vector3(0, 1, 0))
			await get_tree().create_timer(0.5).timeout
			Net.request("prompt", [_prompt.net_id, "tap"])
			while state != "ready":
				await get_tree().create_timer(0.2).timeout
		elif arg.begins_with("--ladder-seat="):
			var used: = _perch_prompt if arg.substr(14) == "perch" else _seat_prompt
			player.teleport(used.global_position + Vector3(0, 0.5, 0))
			await get_tree().create_timer(0.5).timeout
			Net.request("prompt", [used.net_id, "tap"])
			while not seated(player):
				await get_tree().create_timer(0.1).timeout
		elif arg.begins_with("--ladder-water"):
			while not (state == "ready" and controller == player):
				await get_tree().create_timer(0.1).timeout
			await get_tree().create_timer(0.2).timeout
			_debug_aim = Vector3(0, -10, -40)
			if arg.contains("="):
				var n: = arg.get_slice("=", 1).split_floats(",")
				_debug_aim = Vector3(n[0], n[1], n[2])
			_water_on = true
		elif arg == "--ladder-climb":
			player.teleport(vehicle.global_transform * Vector3(0, 3.6, _pivot.z + 1.2))
			if player.camera:
				player.camera.yaw = turntable.global_rotation.y
			_trace_climb()


func _trace() -> void :
	var at: = -1
	while true:
		await get_tree().create_timer(0.05).timeout
		if Net.is_client() and not HostClock.synced:
			continue
		if floori(HostClock.now() / 2.0) == at:
			continue
		at = floori(HostClock.now() / 2.0)
		var here: = floor_node.global_position
		print("ladder %d s: %s turned %.1f raised %.1f out %.1f jacks %.2f | basket %.1f,%.1f,%.1f | stand %s perch %s controls %s | water %s %.0f L | locked %s frozen %s | truck %.1f,%.1f | lamp %s | blocked %s" % [
			at * 2, state, turned, elevation, extension, _jack_amount, here.x, here.y, here.z, 
			_stand_rider.display_name if _stand_rider else "-", _perch_rider.display_name if _perch_rider else "-", 
			controller.display_name if controller else "-", spraying(), vehicle.water, vehicle.locked, vehicle.freeze, 
			vehicle.global_position.x, vehicle.global_position.z, _lamp.visible, Text.say(blocked, "en") if blocked != null else "-", 
		])
		if OS.get_cmdline_user_args().has("--ladder-trace-players"):
			for player in Game.players:
				var from_floor: = floor_node.global_transform.affine_inverse() * player.global_position
				print("   %s%s: from the basket's floor %.1f,%.1f,%.1f seat %s" % [player.display_name, " (mine)" if player.is_local else "", from_floor.x, from_floor.y, from_floor.z, player.seat.name if player.seat else "-"])


func _trace_climb() -> void :
	for step in 12:
		await get_tree().create_timer(0.5).timeout
		var at: = boom.global_transform.affine_inverse() * Game.local_player.global_position
		print("climb: along %.1f above %.1f x %.1f floor %s wall %s vel %s" % [ - at.z, at.y + 0.2, at.x, Game.local_player.is_on_floor(), Game.local_player.is_on_wall(), Game.local_player.velocity])
