extends RefCounted








const WALKED: = ["pavement", "paving", "forecourt", "Terrace"]
const PARASOLS: = [Color8(196, 40, 44), Color8(236, 232, 220), Color8(40, 96, 60), Color8(230, 170, 40), Color8(30, 70, 140)]
const CHAIRS: = [Color8(44, 46, 50), Color8(150, 108, 70), Color8(200, 200, 196)]


const BOARDS: = [
	"DANES\nGOLAŽ\n7,50 €", "KAVA\nČAJ\nSLADOLED", "AKCIJA\n-20 %", "ODPRTO", "MALICA\nRIČET\n6,90 €", 
	"BELOKRANJSKA\nPOGAČA\ndanes sveža", "SVEŽ\nKRUH", 
]
const FRUIT: = [Color8(200, 40, 40), Color8(240, 150, 30), Color8(250, 214, 60), Color8(90, 150, 50), Color8(120, 50, 110)]
const POST_YELLOW: = Color8(250, 200, 20)
const POST_INK: = Color8(24, 40, 90)
const POST_SIGN: = 12.0
const SIGN_GAP: = 1.0


const SHOP_HOUSES: = {
	"ShopFlat": [["ShopDoor", "cafe"]], 
	"WineShop": [["ShopDoor", "shop"], ["BarDoor", "cafe"]], 
	"Market": [["ShopDoor", "market"]], 
	"Bank": [["BankDoor", "bank"]], 
}


static func apply(kit: PolishKit) -> String:
	var folder: = kit.own_folder("Shopfronts")
	var made: = kit.store.count
	var counts: = {"tables": 0, "boards": 0, "crates": 0, "bikes": 0, "post": 0}
	var post_signs: = _post_signs(kit, folder)
	var canopies: = _canopies(kit)
	var fronts: = _fronts(kit)
	var posted: = false
	for front: Dictionary in fronts:
		var rng: = kit.rng("shopfront:%d,%d" % [roundi(front["door"].x), roundi(front["door"].z)])
		var kind: String = front["kind"]
		if kind == "cafe":
			counts["tables"] += _tables(kit, folder, front, rng)
		if kind != "bank":
			counts["boards"] += _board(kit, folder, front, rng)
		if kind == "market":
			counts["crates"] += _crates(kit, folder, front)
		if kind == "market" and not posted:
			posted = _post_box(kit, folder, front)
			counts["post"] += 1 if posted else 0
		if kind != "bank" and rng.randf() < 0.6:
			counts["bikes"] += _bike(kit, folder, front, rng)
	return "shopfronts: %d fronts, %d café tables, %d boards, %d crate stands, %d bicycles, %d post boxes, %d post office signs, %d door canopies under awnings taken off (%d parts)" % [
		fronts.size(), counts["tables"], counts["boards"], counts["crates"], counts["bikes"], counts["post"], post_signs, canopies, kit.store.count - made]





static func _canopies(kit: PolishKit) -> int:
	var store: = kit.store
	var gone: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		var rows: Dictionary = shell["rows"]
		if not rows.has("Awning"):
			continue
		for row: int in rows.get("Canopy", []):
			store.set_transparency(row, 1.0)
			store.set_flags(row, 0)
			gone += 1
	return gone





static func _post_signs(kit: PolishKit, folder: int) -> int:
	var store: = kit.store
	var made: = 0
	for id: int in store.nodes.keys():
		var node: Dictionary = store.nodes[id]
		var attributes: Variant = node.get("a")
		if node["c"] != "TextLabel" or not attributes is Dictionary or not attributes.has("Text_Text"):
			continue
		if not Text.say(Text.decode(attributes["Text_Text"]), "sl").begins_with("Pošta  ·"):
			continue
		var gui: Dictionary = store.nodes.get(node["p"], {})
		var row: int = store.row_of.get(gui.get("p", -1), -1)
		if row < 0 or store.name_at(row) != "Sign":
			continue

		var place: = store.transform(row)
		var size: = store.size(row)
		store.set_size(row, Vector3(size.x - POST_SIGN - SIGN_GAP, size.y, size.z))
		store.set_transform(row, place * Transform3D(Basis(), Vector3( - (POST_SIGN + SIGN_GAP) / 2.0, 0, 0)))
		var board: = kit.box(folder, place * Transform3D(Basis(), Vector3((size.x - POST_SIGN) / 2.0, 0, 0)), Vector3(POST_SIGN, size.y, size.z), POST_YELLOW, "SmoothPlastic", "PostSign")
		var lettering: = store.add_node(board, "SurfaceGui", "PostSignText", {"Face": "NormalId.Front", "PixelsPerStud": 30.0, "Brightness": 1.0, "LightInfluence": 1.0})
		store.add_node(lettering, "TextLabel", "Words", {
			"Text": "POŠTA", "TextColor3": POST_INK, "Font": "Font.GothamBold", "TextScaled": true, 
			"Size": {"X": {"Scale": 0.8, "Offset": 0}, "Y": {"Scale": 0.74, "Offset": 0}}, 
			"Position": {"X": {"Scale": 0.1, "Offset": 0}, "Y": {"Scale": 0.13, "Offset": 0}}, 
		})
		made += 1
	return made




static func _fronts(kit: PolishKit) -> Array:
	var store: = kit.store
	var fronts: Array = []
	for shell: Dictionary in kit.get_meta("shells"):
		var rows: Dictionary = shell["rows"]
		if not rows.has("Awning") or not rows.has("Door"):
			continue
		var place: Transform3D = shell["place"]
		var door: int = rows["Door"][0]
		var at: = store.position(door)
		var out: = _out_of(store, door, place.origin)


		var awning: float = store.size(rows["Awning"][0]).x
		fronts.append(_front(Vector3(at.x, 0, at.z), out, "market" if awning > 50.0 else ("cafe" if awning < 30.0 else "shop")))
	for entry: Dictionary in Game.records.get("buildings", []):
		var module: String = entry.get("house", "")
		if not SHOP_HOUSES.has(module):
			continue
		var plan: Dictionary = Rbx.load_json("res://data/modules/houses/%s.json" % module)
		var lot: Transform3D = entry["lot"]
		for wanted: Array in SHOP_HOUSES[module]:
			for info: Dictionary in plan["doors"]:
				if info["name"] != wanted[0]:
					continue
				var pos: Array = info["pos"]
				var at: = lot * Vector3(float(pos[0]), 0, float(pos[2]))
				var out: = lot.basis * Vector3(0, 0, -1)
				fronts.append(_front(Vector3(at.x, 0, at.z), Vector3(out.x, 0, out.z).normalized(), wanted[1]))
	return fronts


static func _front(door: Vector3, out: Vector3, kind: String) -> Dictionary:
	return {"door": door, "out": out, "side": Vector3.UP.cross(out).normalized() * -1.0, "kind": kind}



static func _out_of(store: PartStore, door: int, middle: Vector3) -> Vector3:
	var frame: = store.transform(door)
	var size: = store.size(door)
	var thin: = 0
	for axis in [1, 2]:
		if size[axis] < size[thin]:
			thin = axis
	var out: = frame.basis[thin].normalized()
	if out.dot(frame.origin - middle) < 0.0:
		out = - out
	return Vector3(out.x, 0, out.z).normalized()



static func _free(kit: PolishKit, at: Vector3, radius: float) -> bool:
	return WALKED.has(kit.surface_at(at)) and StreetKit.clear_below(kit, at, radius, 7.0, 0.65)



static func _free_by_wall(kit: PolishKit, at: Vector3, radius: float) -> bool:
	return WALKED.has(kit.surface_at(at)) and StreetKit.clear_below(kit, at, radius, 7.0, 0.65, ["Plinth", "Sill", "WindowSill", "ShopWindowSill"])



static func _tables(kit: PolishKit, folder: int, front: Dictionary, rng: RandomNumberGenerator) -> int:
	var door: Vector3 = front["door"]
	var out: Vector3 = front["out"]
	var side: Vector3 = front["side"]
	var parasol: Color = PARASOLS[rng.randi_range(0, PARASOLS.size() - 1)]
	var chairs: Color = CHAIRS[rng.randi_range(0, CHAIRS.size() - 1)]
	var made: = 0
	for along: float in [-7.0, 7.0, -15.0, 15.0]:
		if made >= 4:
			break
		for away: float in [4.2, 6.0, 8.5]:
			var at: = door + side * along + out * away


			if _free(kit, at, 1.8) and _free(kit, at + side * 2.4, 0.9) and _free(kit, at - side * 2.4, 0.9):
				var shade: = parasol if WALKED.has(kit.surface_at(at + out * 3.5)) else Color(0, 0, 0, 0)
				StreetKit.cafe_table(kit, folder, PolishKit.facing(at, - out), chairs, shade)
				made += 1
				break
	return made


static func _board(kit: PolishKit, folder: int, front: Dictionary, rng: RandomNumberGenerator) -> int:
	var door: Vector3 = front["door"]
	var out: Vector3 = front["out"]
	var side: Vector3 = front["side"]
	for along: float in [5.5, -5.5, 7.5, -7.5]:
		var at: = door + side * along + out * 3.0
		if _free(kit, at, 1.4):
			var boards: Array = Edition.data().get("boards", BOARDS)
			StreetKit.a_board(kit, folder, PolishKit.facing(at, out), boards[rng.randi_range(0, boards.size() - 1)])
			return 1
	return 0



static func _crates(kit: PolishKit, folder: int, front: Dictionary) -> int:
	var door: Vector3 = front["door"]
	var out: Vector3 = front["out"]
	var side: Vector3 = front["side"]
	for along: float in [-7.0, 7.0, -10.0, 10.0]:
		var at: = door + side * along + out * 2.2
		if not (_free_by_wall(kit, at, 1.6) and _free_by_wall(kit, at + side * 2.5, 1.0) and _free_by_wall(kit, at - side * 2.5, 1.0)):
			continue
		var place: = PolishKit.facing(at, out)
		kit.box(folder, place * Transform3D(Basis(), Vector3(0, 1.2, 0)), Vector3(7.0, 0.25, 2.6), Color8(150, 112, 74), "Wood", "StallTop")
		for x: float in [-3.2, 3.2]:
			kit.box(folder, place * Transform3D(Basis(), Vector3(x, 0.55, 0)), Vector3(0.25, 1.1, 2.4), Color8(120, 88, 58), "Wood", "StallLeg")
		for index in 3:
			var x: = (index - 1) * 2.3
			var crate: = place * Transform3D(Basis(Vector3.RIGHT, deg_to_rad(-14)), Vector3(x, 1.75, 0.1))
			kit.box(folder, crate, Vector3(2.1, 0.8, 2.2), Color8(196, 160, 112), "WoodPlanks", "Crate")
			kit.box(folder, crate * Transform3D(Basis(), Vector3(0, 0.38, 0)), Vector3(1.85, 0.12, 1.95), FRUIT[(index + int(absf(at.x))) % FRUIT.size()], "Fabric", "Produce")
		return 1
	return 0



static func _post_box(kit: PolishKit, folder: int, front: Dictionary) -> bool:
	var door: Vector3 = front["door"]
	var out: Vector3 = front["out"]
	var side: Vector3 = front["side"]
	for along: float in [-4.6, 4.6, -12.0, 12.0]:
		var foot: = door + side * along + out * 0.7
		if not _free_by_wall(kit, foot, 0.5):
			continue
		var place: = PolishKit.facing(foot, out)

		var paint: = POST_YELLOW if Edition.id() != "us" else Color8(28, 58, 120)
		var low: = 0.0 if Edition.id() != "us" else -2.4
		var tall: = 2.2 if Edition.id() != "us" else 4.0
		kit.box(folder, place * Transform3D(Basis(), Vector3(0, 4.6 + low + (tall - 2.2) / 2.0, 0.15)), Vector3(1.7, tall, 0.95 if Edition.id() != "us" else 1.6), paint, "SmoothPlastic", "PostBox")
		kit.box(folder, place * Transform3D(Basis(), Vector3(0, 5.8 + low + (tall - 2.2), 0.1)), Vector3(1.85, 0.2, 1.1 if Edition.id() != "us" else 1.75), paint.darkened(0.15), "SmoothPlastic", "PostBoxCap")
		kit.box(folder, place * Transform3D(Basis(), Vector3(0, 5.15 + low + (tall - 2.2), -0.36 if Edition.id() != "us" else -0.68)), Vector3(1.1, 0.12, 0.06), Color8(30, 30, 32), "SmoothPlastic", "PostBoxSlot")
		StreetKit.board(kit, folder, place * Transform3D(Basis(), Vector3(0, 4.1 + low + (tall - 2.2) / 2.0, -0.34 if Edition.id() != "us" else -0.66)), Vector2(1.4, 0.5), paint, ("POST" if Edition.id() == "de" else "POŠTA") if Edition.id() != "us" else "U.S. MAIL", Color8(24, 40, 90) if Edition.id() != "us" else Color8(240, 240, 236), "PostBoxSign")
		return true
	return false



static func _bike(kit: PolishKit, folder: int, front: Dictionary, rng: RandomNumberGenerator) -> int:
	var door: Vector3 = front["door"]
	var out: Vector3 = front["out"]
	var side: Vector3 = front["side"]
	for along: float in [9.0, -9.0, 12.0, -12.0]:
		var at: = door + side * along + out * 1.1
		if not (_free_by_wall(kit, at, 0.9) and _free_by_wall(kit, at + side * 2.3, 0.9) and _free_by_wall(kit, at - side * 2.3, 0.9)):
			continue
		var place: = PolishKit.facing(at, side if rng.randf() < 0.5 else - side)

		var lean: = -0.16 if place.basis.x.dot( - out) > 0.0 else 0.16
		StreetKit.bicycle(kit, folder, place, StreetKit.BIKE_PAINTS[rng.randi_range(0, StreetKit.BIKE_PAINTS.size() - 1)], lean)
		return 1
	return 0
