extends ProofDebug








func _scenario_reticle_range() -> void :
	await _wait(1.0)
	var hose: Dictionary = Config.Hose
	var speed: = float(hose["StreamSpeed"])
	var gravity: = float(hose["StreamGravity"])

	var floor_cast: = func(from: Vector3, to: Vector3) -> Variant:
		if to.y > -4.0:
			return null
		return from.lerp(to, (from.y + 4.0) / maxf(from.y - to.y, 1e-06))
	var furthest: = 0.0
	var landed: Array = []
	var steady: = true
	var last: = 0.0
	for away: float in [20.0, 40.0, 55.0, 59.0, 61.0, 64.0, 70.0, 100.0, 200.0, 400.0]:
		var velocity: = Ballistics.launch_toward(Vector3.ZERO, Vector3(0, -4, - away), speed, gravity)
		var traced: = Ballistics.trace(Vector3.ZERO, velocity, gravity, 6.0, 120, floor_cast)
		var path: PackedVector3Array = traced["path"]
		var down: = Vector2(path[path.size() - 1].x, path[path.size() - 1].z).length()
		landed.append("%.0f->%.1f" % [away, down])
		steady = steady and down >= last - 0.3
		last = down
		furthest = maxf(furthest, down)
		if Ballistics.reachable(Vector3.ZERO, Vector3(0, -4, - away), speed, gravity):
			steady = steady and absf(down - away) < 1.0
	print("range: aimed -> landed on level ground: %s" % [landed])
	var flat_most: = speed * speed / gravity
	_check(steady, "aiming further never brings the water down nearer (and in reach it lands where aimed)")
	_check(last > flat_most * 0.98, "aimed far past the reach, it comes down at the reach (%.1f; %.1f on the flat)" % [last, flat_most])


	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	await _take_line(pumper)
	var sight: HudReticle = Hud.current.crosshair
	var way: = _open_way(player.global_position, 110.0)
	var far_point: = _ground(player.global_position + way * 100.0)
	await _aim_view(far_point + Vector3(0, 0.5, 0))
	await _wait(0.6)
	var tip: = hoses.nozzle_tip(player)
	var aim: = hoses.aim_of(player)
	var too_far: = Text.say(Text.m("hud.hose.outOfRange"))
	print("range: way %s, aim %.1f studs off (%s), far %.2f, words '%s'" % [way, Vector2(aim.x - tip.x, aim.z - tip.z).length(), aim, sight._far, sight._words])
	_check(sight._far > 0.9 and sight._words == too_far, "aimed past the reach, the sight says TOO FAR")
	await _snap("too_far")

	var far_flame: = FireService.current.spot(far_point + Vector3(0, 0.5, 0))
	far_flame["intensity"] = 0.6
	await _wait(0.6)
	await _aim_view(far_point + Vector3(0, 1.0, 0))
	await _wait(0.6)
	print("range: on a flame out of reach: aimed %.2f, far %.2f" % [sight._aimed, sight._far])
	_check(sight._aimed < 0.1, "a flame out of the water's reach is not locked on to")
	await _snap("far_flame")
	FireService.current.end_spot(far_flame)

	await _aim_view(far_point + Vector3(0, 0.5, 0))
	Input.action_press("fire")
	await _wait(2.0 + float(Config.Water.Charge.Time))
	var line: Dictionary = hoses.line_of(player)
	var jet: WaterJet = line["jet"]
	tip = hoses.nozzle_tip(player)
	aim = hoses.aim_of(player)
	var out: = Vector2(jet.landing.x - tip.x, jet.landing.z - tip.z)
	var aimed_way: = Vector2(aim.x - tip.x, aim.z - tip.z)
	var off_line: = rad_to_deg(absf(out.angle_to(aimed_way)))

	var expected: = Ballistics.trace(tip, Ballistics.launch(tip, aim, speed, gravity), gravity, float(hose["StreamTime"]), int(hose["StreamSteps"]) * 2, 
		func(from: Vector3, to: Vector3) -> Variant:
			var hit: = Game.world.raycast(from, to, World.LAYER_QUERY | World.LAYER_VEHICLE, [player.get_rid()])
			return null if hit.is_empty() else hit["position"])
	var path: PackedVector3Array = expected["path"]
	var reach_down: = Vector2(path[path.size() - 1].x - tip.x, path[path.size() - 1].z - tip.z).length()
	print("range: jet came down %.1f studs out (%.1f deg off the aim; the reach there %.1f); landed %s, spraying %s" % [out.length(), off_line, reach_down, jet.landed, player.get_attr("Spraying")])
	_check(out.length() > 45.0 and absf(out.length() - reach_down) < 4.0 and off_line < 4.0, "the jet comes down at the reach, in line with the aim (not 22 studs out)")
	print("range: words while flowing out of reach '%s', flowing %.2f" % [sight._words, sight._flowing])
	await _snap("lob")
	Input.action_release("fire")
	await _wait(1.0)


	var near_point: = _ground(player.global_position + way * 26.0)
	var near_flame: = FireService.current.spot(near_point + Vector3(0, 0.5, 0))
	near_flame["intensity"] = 0.6
	await _aim_view(near_point + Vector3(0, 1.0, 0))
	await _wait(0.6)
	print("range: on a flame in reach: aimed %.2f, far %.2f" % [sight._aimed, sight._far])
	_check(sight._aimed > 0.5 and sight._far < 0.1, "a flame in reach is locked on to")
	FireService.current.end_spot(near_flame)
	await _done()




func _scenario_reticle_states() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	await _take_line(pumper)
	var sight: HudReticle = Hud.current.crosshair
	var way: = _open_way(player.global_position, 40.0)
	var ground: = _ground(player.global_position + way * 24.0)
	await _aim_view(ground + Vector3(0, 0.3, 0))
	await _wait(0.6)
	await _snap("rest")


	Input.action_press("fire")
	await _wait(1.2 + float(Config.Water.Charge.Time))
	print("states: flowing: spraying %s, hitting %s, flowing %.2f, words '%s'" % [player.get_attr("Spraying"), player.get_attr("HittingFire"), sight._flowing, sight._words])
	_check(player.get_attr("Spraying") == true and sight._flowing > 0.9 and sight._words == "", "water flowing onto nothing burning: the dashes go round")
	await _snap("flowing")
	Input.action_release("fire")
	await _wait(0.6)


	var had: = pumper.water
	pumper.water = 0.0
	await _wait(0.4)
	Input.action_press("fire")
	await _wait(0.8)
	var no_water: = Text.say(Text.m("hud.hose.noWater"))
	print("states: dry tank: spraying %s, empty %.2f, words '%s'" % [player.get_attr("Spraying"), sight._empty, sight._words])
	_check(player.get_attr("Spraying") != true and sight._empty > 0.9 and sight._words == no_water, "with the tank dry the sight says NO WATER")
	await _snap("no_water")
	Input.action_release("fire")
	pumper.water = had
	await _wait(0.6)
	print("states: refilled: empty %.2f, words '%s'" % [sight._empty, sight._words])
	_check(sight._empty < 0.1 and sight._words == "", "water back in the tank, the warning goes")


	await _gear_up()
	await _wait(0.5)
	var air: Dictionary = Config.Air
	var bar: = float(player.get_attr("AirBar", 0))
	var at_rest: = bar / (float(air["Rest"]) * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"]))
	print("states: masked: bar %.0f, air %.2f, minutes %.1f (at rest %.1f), mask %s" % [bar, sight._air, sight._air_minutes, at_rest, player.get_attr("Mask")])
	_check(sight._air > 0.0 and absf(sight._air_minutes - at_rest) < 0.6, "behind a mask the sight shows the minutes of air left")
	await _snap("air")
	Input.action_press("fire")
	await _wait(1.0)
	var at_work: = float(player.get_attr("AirBar", 0)) / (float(air["Work"]) * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"]))
	print("states: masked, spraying: minutes %.1f (at work %.1f)" % [sight._air_minutes, at_work])
	_check(absf(sight._air_minutes - at_work) < 0.6 and at_work < at_rest, "working the hose, the minutes fall to its pace")
	Input.action_release("fire")

	AirService.current.sets[player]["bar"] = float(air["Capacity"]) * 0.3
	player.set_attr("AirBar", ceili(float(air["Capacity"]) * 0.3))
	await _wait(0.6)
	await _snap("air_low")
	await _done()




func _scenario_reticle_cooling() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = _house("Family house")
	var pumper: = Vehicle.named("Fire Truck")
	var door: Vector3 = house.outside_door()["lock"].global_position
	var out: = Vector3(door.x - house.position.x, 0, door.z - house.position.z).normalized()
	_park(pumper, _open_spot(door, out, pumper))
	fire.run_incident(house)
	await _wait(1.0)

	var spot: = Vector3.INF
	var waited: = 0.0
	while waited < 20.0 and spot == Vector3.INF:
		spot = _lone_node(fire)
		if spot == Vector3.INF:
			await _wait(0.5)
			waited += 0.5
	if spot == Vector3.INF:
		_fail("nothing next to the fire away from its flames")
		return
	await _wait(1.0)
	print("cooling: %d things warming; heat there %.2f" % [fire._warm_shown.size(), _heat_at(fire, spot)])
	print("cooling: something warming at %s after %.1f s" % [spot, waited])
	await _take_line(pumper, false)
	var sight: HudReticle = Hud.current.crosshair

	var stand: = _clear_stand(spot)
	if stand == Vector3.INF:
		_fail("nowhere to stand in sight of it")
		return

	var from: = player.global_position
	var steps: = ceili(from.distance_to(stand) / 2.0)
	for step in steps:
		player.teleport(from.lerp(stand, float(step + 1) / steps))
		await get_tree().physics_frame
		await get_tree().physics_frame
	player.teleport(stand)
	await _wait(0.5)
	var cooled: = false
	var said: = ""
	var cooling_words: = Text.say(Text.m("hud.reticle.cooling"))
	for attempt in 3:
		await _aim_view(spot + Vector3(0, 0.3, 0))
		Input.action_press("fire")
		var held: = 0.0
		while held < 2.0 and not cooled:
			await get_tree().process_frame
			held += get_process_delta_time()
			cooled = player.get_attr("Cooling", false) == true and sight._cooling > 0.5
			said = sight._words
		if cooled:
			await _snap("cooling")
		Input.action_release("fire")
		if cooled:
			break
		await _wait(0.3)
	print("cooling: Cooling %s, shown %.2f, words '%s', hitting %s; heat there now %.2f" % [player.get_attr("Cooling"), sight._cooling, said, player.get_attr("HittingFire"), _heat_at(fire, spot)])
	_check(cooled and said == cooling_words, "water on something warming: the sight says COOLING")
	await _done()





func _scenario_reticle_views() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	await _take_line(pumper)
	var settings: Dictionary = Config.Hose.Reticle
	var shoulder: float = settings["NozzleShoulder"]
	var held: Vector3 = settings["FirstPersonNozzle"]
	var way: = _open_way(player.global_position, 40.0)
	var at: = _ground(player.global_position + way * 20.0)
	var made: = FireService.current.spot(at + Vector3(0, 0.5, 0))
	made["intensity"] = 0.8
	var sight: HudReticle = Hud.current.crosshair
	for look: Array in [["before", 1.6, Vector3.ZERO], ["after", shoulder, held]]:
		settings["NozzleShoulder"] = look[1]
		settings["FirstPersonNozzle"] = look[2]
		player.camera.wanted_distance = 16.0
		await _wait(1.2)
		await _aim_view(at + Vector3(0, 1.0, 0))
		Input.action_press("fire")
		await _wait(1.2)
		await _aim_view(at + Vector3(0, 1.0, 0))
		await _snap("third_%s" % look[0])
		print("views: %s: third person, hitting %s, aimed %.2f" % [look[0], player.get_attr("HittingFire"), sight._aimed])
		Input.action_release("fire")
		player.camera.wanted_distance = 0.0
		await _wait(1.0)
		await _aim_view(at + Vector3(0, 1.0, 0))
		Input.action_press("fire")
		await _wait(1.0)
		await _aim_view(at + Vector3(0, 1.0, 0))
		await _snap("first_%s" % look[0])
		print("views: %s: first person, hitting %s" % [look[0], player.get_attr("HittingFire")])
		Input.action_release("fire")
		made["damage"] = 0.0
	settings["NozzleShoulder"] = shoulder
	settings["FirstPersonNozzle"] = held
	_check(player.holding == "nozzle", "the nozzle stayed in hand")
	await _done()







func _take_line(pumper: Vehicle, park: = true) -> void :
	var hoses: = HoseService.current
	if hoses.line_of(player) != null:
		return
	if park:
		_park(pumper, Vector3(-12, 0, -22))
		await _wait(0.6)
	player.teleport(_ground(pumper.global_transform * Vector3(9, 0, 12)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	var nearest: Variant = null
	for line: Dictionary in hoses.lines:
		if line["kind"] == "outlet" and line["rig"] != null and line["rig"]["vehicle"] == pumper and (nearest == null or line["source"].global_position.distance_to(player.global_position) < nearest["source"].global_position.distance_to(player.global_position)):
			nearest = line
	if nearest != null:
		hoses._on_outlet(nearest, player)
	await _wait(1.1)
	print("reticle: holding '%s'" % player.holding)



func _open_way(from: Vector3, length: float) -> Vector3:
	var best: = Vector3.FORWARD
	var best_clear: = -1.0
	for step in 16:
		var way: = Vector3.FORWARD.rotated(Vector3.UP, step * TAU / 16.0)
		var high: = from + Vector3(0, 4, 0)
		var hit: = Game.world.raycast(high, high + way * length, World.LAYER_QUERY | World.LAYER_VEHICLE, [player.get_rid()])
		var clear: float = length if hit.is_empty() else from.distance_to(hit["position"])

		var behind: = Game.world.raycast(high + Vector3(0, 3, 0), high + Vector3(0, 3, 0) - way * 24.0 + way.cross(Vector3.UP) * -4.0, World.LAYER_QUERY | World.LAYER_VEHICLE, [player.get_rid()])
		if not behind.is_empty():
			clear *= 0.5
		if clear > best_clear:
			best_clear = clear
			best = way
	return best




func _lone_node(fire: FireService) -> Vector3:
	if fire.incident.is_empty():
		return Vector3.INF
	var nodes: Array = fire.incident["group"]["nodes"]
	for node: Dictionary in nodes:
		if node["burning"] or float(node["fuel"]) <= 0.0:
			continue
		var at: Vector3 = node["position"]
		var lone: = true
		for other: Dictionary in nodes:
			if other["burning"] and (other["position"] as Vector3).distance_to(at) < 6.5:
				lone = false
		if lone and _clear_stand(at) != Vector3.INF:
			node["heat"] = 0.8
			return at
	return Vector3.INF


func _heat_at(fire: FireService, at: Vector3) -> float:
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if (node["position"] as Vector3).is_equal_approx(at):
			return float(node["heat"])
	return -1.0



func _clear_stand(at: Vector3) -> Vector3:
	for distance: float in [6.0, 8.0, 10.0]:
		for step in 12:
			var way: = Vector3.FORWARD.rotated(Vector3.UP, step * TAU / 12.0)
			var probe: = at + way * distance + Vector3(0, 2, 0)
			var floor_hit: = Game.world.raycast(probe + Vector3(0, 1, 0), probe - Vector3(0, 6, 0), World.LAYER_SOLID)
			if floor_hit.is_empty():
				continue
			var feet: Vector3 = floor_hit["position"]
			var head: = feet + Vector3(0, 4.5, 0)
			var room: = Game.world.raycast(feet + Vector3(0, 0.5, 0), head + Vector3(0, 1, 0), World.LAYER_SOLID)
			var sight: = Game.world.raycast(head, at + Vector3(0, 0.3, 0), World.LAYER_SOLID)
			if room.is_empty() and (sight.is_empty() or (sight["position"] as Vector3).distance_to(at) < 2.0):
				return feet + Vector3(0, 0.3, 0)
	return Vector3.INF



func _gear_up() -> void :
	GearService.current._gear_up(player, null, true)
	AirService.current.take_set(player, "truck")
	await _wait(0.3)
	AirService.current._set_mask(player, true)
	await _wait(0.3)
