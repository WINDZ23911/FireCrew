class_name AirService
extends Node3D













static var current: AirService

const GREEN: = Color(40 / 255.0, 1.0, 70 / 255.0)
const AMBER: = Color(1.0, 190 / 255.0, 30 / 255.0)
const RED: = Color(1.0, 40 / 255.0, 30 / 255.0)
const BOARD_GREY: = Color(150 / 255.0, 155 / 255.0, 165 / 255.0)
const OWN_BREATHING: = 3.0


const MASK_JOINTS: = {
	"ShoulderR": [78.0, 30.0, 42.0], 
	"ShoulderL": [78.0, -30.0, 10.0], 
	"ElbowR": [104.0, 0.0, 18.0], 
	"ElbowL": [104.0, 0.0, 0.0], 
}

var sets: Dictionary = {}
var rack_prompt: Prompt
var _looks: Dictionary = {}
var _seen_moves: Dictionary = {}
var _quiet_until: = 0.0
var _filling: = false
var _board_shown: Array = []
var _was_client: = false
var pool: Dictionary = {}





var bars: Dictionary = {}
var holders: Dictionary = {}
var _turn_chimed: = false
var spares: = 0
var truck: Vehicle
var tanker: Vehicle
var command: Vehicle
var _rack_label: Label3D

var _set_lines: Dictionary = {}
var _truck_lines: Array[LockerLine] = []
var _spare_lines: Array[LockerLine] = []


var _fill_jobs: Array = []
var _fill_queue: Array = []
var _fill_by: Player
var _fill_look: Array = [[], 0.0, false]
var _station: Dictionary = {}
var _compressor_at: = Vector3.ZERO
var _compressor_hum: AudioStreamPlayer3D
var _board_rows: Array[Label3D] = []
var _smoke_warned: Dictionary = {}
var _moves: Dictionary = {}
var _mask_moves: = 0
var _elapsed: = 0.0
var _since_board: = 0.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :

	var mix: = AudioMix.new()
	mix.name = "AudioMix"
	add_child(mix)
	var air: Dictionary = Config.Air
	for vehicle in Vehicle.all:
		if vehicle.spec.get("pumper", false):
			truck = vehicle
		elif vehicle.spec["name"] == "Tanker":
			tanker = vehicle
		elif int(vehicle.spec.get("airSets", 0)) > 0:
			command = vehicle
	pool = _full_pool()
	spares = int(air["TruckSpares"])
	var places: Dictionary = Game.records["station"]["places"]
	_build_rack(places["rack"])
	_build_compressor(places["compressor"])
	_add_truck_lines()
	if truck:
		_build_board()
	_update_counts()
	Text.language_changed.connect( func(_code: String) -> void :
		_update_counts()
		_draw_board(_board_shown)
	)

	GearService.current.on_removed( func(player: Player) -> void :
		if sets.has(player):
			_return_set(player)
	)



	Net.handle("air.mask", move_mask)
	Net.share("air.pool", _pool_state, _apply_pool, 4.0)
	Net.share("air.board", _board_state, _draw_board, 1.0)
	Net.peer_joined.connect( func(player: Player) -> void :
		if Net.is_host():
			_publish(player)
	)
	Net.started.connect(_on_net_started)
	Net.stopped.connect(_on_net_stopped)



func _on_net_started() -> void :
	if not Net.is_client():
		return
	_was_client = true
	sets.clear()
	_moves.clear()
	_smoke_warned.clear()
	_quiet_until = Game.now() + 3.0
	var me: = Game.local_player
	for key: String in ["Scba", "Mask", "AirBar", "MaskMove", "Distress", "Smoke", "AirTurn", "AirTurned", "AirSwap"]:
		me.set_attr(key, null)



func _on_net_stopped() -> void :
	if not _was_client:
		return
	_was_client = false
	var air: Dictionary = Config.Air
	pool = _full_pool()
	spares = int(air["TruckSpares"])
	_filling = false
	_fill_jobs.clear()
	_fill_queue.clear()
	_fill_look = [[], 0.0, false]
	_show_station()
	_playing(_compressor_hum, false)
	_update_counts()
	_update_board()
	var me: = Game.local_player
	if me != null:
		me.set_attr("Distress", null)
		me.set_attr("Smoke", 0.0)
		_publish(me)





func wearing(player: Player) -> bool:
	return sets.has(player)



func on_air(player: Player) -> bool:
	return sets.has(player) and sets[player]["mask"] and sets[player]["bar"] > 0.0 and not sets[player]["swapping"]




static func minutes_left(player: Player) -> float:
	if player == null or player.get_attr("Scba", false) != true:
		return -1.0
	var air: Dictionary = Config.Air
	var bar_per_minute: = float(air["Walk"]) * Training.factor(player, "breathing") * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"])
	return maxf(0.0, float(player.get_attr("AirBar", 0))) / bar_per_minute




static func turnaround(player: Player) -> float:
	var turn: Variant = player.get_attr("AirTurn") if player != null else null
	return float(turn) if turn != null else -1.0



func pressure(player: Player) -> float:
	return sets[player]["bar"] if sets.has(player) else -1.0





func _publish(player: Player) -> void :
	var set_on: = sets.has(player)
	player.set_attr("Scba", set_on)
	player.set_attr("Mask", set_on and sets[player]["mask"])
	player.set_attr("AirBar", ceili(sets[player]["bar"]) if set_on else null)
	_publish_turn(player)





func _publish_turn(player: Player) -> void :
	var set_worn: Variant = sets.get(player)
	if set_worn == null or not set_worn["mask"] or set_worn["entry"] < 0.0:
		player.set_attr("AirTurn", null)
		player.set_attr("AirTurned", null)
		return
	var turn: = maxf(0.0, 2.0 * float(set_worn["bar"]) - float(set_worn["entry"]))
	player.set_attr("AirTurn", ceili(turn))
	var reserve: = float(Config.Air.TurnReserve)
	if turn <= reserve and not set_worn["turned"] and float(set_worn["entry"]) > reserve:
		set_worn["turned"] = true
		player.set_attr("AirTurned", true)
		Game.notify(Text.f("gear.air.turnaround", [ceili(set_worn["bar"])]), "warning", player)



func _full_pool() -> Dictionary:
	var air: Dictionary = Config.Air
	var counts: = {"rack": int(air["Sets"]), "truck": int(air["TruckSets"]), "tanker": int(air["TankerSets"]), "command": _command_sets()}
	bars = {}
	holders = {}
	for source: String in counts:
		var full: Array[float] = []
		var nobody: Array = []
		for index in int(counts[source]):
			full.append(float(air["Capacity"]))
			nobody.append(null)
		bars[source] = full
		holders[source] = nobody
	return counts


func _command_sets() -> int:
	return int(command.spec.get("airSets", 0)) if command else 0



func held(source: String, slot: int) -> bool:
	var who: Variant = holders.get(source, [])[slot]
	if typeof(who) == TYPE_OBJECT:
		return is_instance_valid(who)
	return who == true



func holder_of(source: String, slot: int) -> Player:
	var who: Variant = holders.get(source, [])[slot]
	return who if typeof(who) == TYPE_OBJECT and is_instance_valid(who) else null



func fullest_free(source: String) -> int:
	var best: = -1
	var waiting: Array = bars.get(source, [])
	for index in waiting.size():
		if not held(source, index) and (best < 0 or float(waiting[index]) > float(waiting[best])):
			best = index
	return best



func slot_bar(source: String, slot: int) -> float:
	var who: = holder_of(source, slot)
	if who != null:
		return float(who.get_attr("AirBar", 0))
	return float(bars[source][slot])



func source_vehicle(source: String) -> Vehicle:
	var vehicle: Variant = {"truck": truck, "tanker": tanker, "command": command}.get(source)
	return vehicle if vehicle is Vehicle and is_instance_valid(vehicle) else null



func line_of_set(source: String, slot: int) -> LockerLine:
	var lines: Array = _set_lines.get(source, [])
	return lines[slot] if slot >= 0 and slot < lines.size() else null




func line_for(player: Player, source: String) -> LockerLine:
	var worn: Variant = sets.get(player)
	if worn != null:
		return line_of_set(source, int(worn["slot"])) if worn["source"] == source else null
	return line_of_set(source, fullest_free(source))



func _recount() -> void :
	for source: String in holders:
		var free: = 0
		for index in (holders[source] as Array).size():
			if not held(source, index):
				free += 1
		pool[source] = free



func _update_counts() -> void :
	var air: Dictionary = Config.Air
	if _rack_label:
		_rack_label.text = Text.say(Text.f("gear.air.rackSign", [pool["rack"], int(air["Sets"])]))
	_update_lines()
	for line in _spare_lines:
		line.object = Text.f("gear.air.sparesCount", [spares, int(air["TruckSpares"])])

	for source: String in ["truck", "tanker", "command"]:
		var vehicle: = source_vehicle(source)
		if vehicle != null:
			for index in (holders.get(source, []) as Array).size():
				_show_prop(vehicle, "Set%d" % (index + 1), not held(source, index))
	if truck:
		for index in range(1, int(air["TruckSpares"]) + 1):
			_show_prop(truck, "Spare%d" % index, index <= spares)




func _update_lines() -> void :
	var air: Dictionary = Config.Air
	for source: String in _set_lines:
		var lines: Array = _set_lines[source]
		for index in lines.size():
			var line: LockerLine = lines[index]
			var bar: = slot_bar(source, index)
			line.action = Text.f("gear.air.setNumber", [index + 1])
			line.object = "%d bar" % ceili(bar)
			line.holder = holder_of(source, index)
			if held(source, index):
				line.tint = ""
			elif bar <= float(air["Whistle"]):
				line.tint = "low"
			elif bar <= float(air["Capacity"]) / 2.0:
				line.tint = "half"
			else:
				line.tint = "full"




func _pool_state() -> Dictionary:
	var slots: = {}
	for source: String in bars:
		var said: Array = []
		for index in (bars[source] as Array).size():
			var who: = holder_of(source, index)
			var peer: = 0
			if who != null:
				peer = Net.peer_of(who)
				peer = peer if peer != 0 else -1
			said.append([ceili(float(bars[source][index])), peer])
		slots[source] = said
	return {"pool": pool.duplicate(), "slots": slots, "spares": spares, "filling": _filling, "look": _fill_look}


func _apply_pool(state: Variant) -> void :
	var slots: Dictionary = state.get("slots", {})
	for source: String in slots:
		if not bars.has(source):
			continue
		var said: Array = slots[source]
		for index in mini(said.size(), (bars[source] as Array).size()):
			bars[source][index] = float(said[index][0])
			var peer: = int(said[index][1])
			var who: Variant = Net.player_of(peer) if peer > 0 else null
			if who == null and peer != 0:
				who = true
			holders[source][index] = who
	_recount()
	spares = int(state["spares"])
	_update_counts()
	_playing(_compressor_hum, state["filling"])
	_fill_look = state.get("look", _fill_look)
	_show_station()


static func _show_prop(vehicle: Vehicle, prop_name: String, shown: bool) -> void :
	if vehicle.props.has(prop_name):
		vehicle.props[prop_name]["node"].visible = shown



static func _sound(parent: Node3D, asset: Variant, volume: float, reach: float) -> AudioStreamPlayer3D:
	return Sounds.emitter(parent, Sounds.loop(asset), volume, 6.0, reach)




static func _own_sound(parent: Node, asset: Variant, volume: float) -> AudioStreamPlayer:
	var player: = AudioStreamPlayer.new()
	player.stream = Sounds.loop(asset)
	player.volume_db = linear_to_db(maxf(volume, 0.0001))
	parent.add_child(player)
	return player


static func _playing(sound: Node, on: bool) -> void :
	if sound.stream == null or sound.playing == on:
		return
	if on:
		sound.play()
	else:
		sound.stop()




func _show_pieces(player: Player, has_set: bool, mask: bool) -> void :
	for mesh: MeshInstance3D in player.rig.pieces.get("scba", []):
		mesh.visible = mask if String(mesh.name).begins_with("Head") else has_set
	for mesh: MeshInstance3D in player.rig.pieces.get("lens", []):
		mesh.visible = mask
		if mask and mesh.material_override == null:

			var glass: = StandardMaterial3D.new()
			glass.albedo_color = Color(0.75, 0.82, 0.86, 1.0 - float(Config.Gear.LensTransparency))
			glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			glass.roughness = 0.08
			glass.metallic = 0.2
			mesh.material_override = glass


func _set_mask(player: Player, on: bool) -> void :
	var set_worn: Dictionary = sets[player]
	if set_worn["mask"] == on:
		return
	set_worn["mask"] = on
	if on:
		set_worn["entry"] = float(set_worn["bar"])
		set_worn["turned"] = false
	GearService.current.set_mask_worn(player, on)
	_publish(player)





func move_mask(player: Player) -> void :
	if not sets.has(player):
		return
	var set_worn: Dictionary = sets[player]
	if set_worn["moving"]:
		return
	var on: bool = not set_worn["mask"]
	if on and player.seat != null:

		Game.notify(Text.m("gear.air.maskSeated"), "", player)
		return
	var air: Dictionary = Config.Air
	set_worn["moving"] = true
	_mask_moves += 1
	player.set_attr("MaskMove", "%s:%d" % ["on" if on else "off", _mask_moves])
	var length: float = air["MaskOnTime"] if on else air["MaskOffTime"]
	_start_hands(player, on)
	get_tree().create_timer(length / 2.0, false).timeout.connect( func() -> void :

		if is_instance_valid(player) and sets.get(player) != null and is_same(sets[player], set_worn):
			set_worn["moving"] = false
			_set_mask(player, on and player.seat == null)
	)




func take_set(player: Player, source: String, slot: = -1) -> void :
	if not GearService.current.is_geared(player):
		Game.notify(Text.m("gear.suitFirst"), "", player)
		return
	if sets.has(player):
		return
	if slot < 0:
		slot = fullest_free(source)
	if slot < 0 or slot >= (holders.get(source, []) as Array).size() or held(source, slot):
		Game.notify(Text.m("gear.air.places.%s.none" % source), "", player)
		return
	var bar: = float(bars[source][slot])
	holders[source][slot] = player
	sets[player] = {
		"slot": slot, 
		"bar": bar, 
		"entry": -1.0, 
		"turned": false, 
		"swapping": false, 
		"mask": false, 
		"source": source, 
		"still_for": 0.0, 
		"still_warned": false, 
		"alarm": false, 
		"warned": false, 
		"refilling": false, 
		"moving": false, 
	}
	_recount()
	_update_counts()
	_publish(player)


	var language: String = "" if player.is_local else String(player.get_attr("Language", ""))
	Game.notify(Text.say(Text.m("gear.air.setOn"), language).replace(" M ", " %s " % Controls.key_name("mask")), "", player)

	if bar < float(Config.Air.Capacity) - 1.0:
		Game.notify(Text.f("gear.air.setLow", [ceili(bar)]), "warning", player)




func seated(player: Player) -> void :
	if Net.is_client() or not sets.has(player):
		return
	var set_worn: Dictionary = sets[player]
	set_worn["refilling"] = false
	if set_worn["mask"] and not set_worn["moving"]:
		move_mask(player)



func return_worn(player: Player) -> void :
	if not Net.is_client() and sets.has(player):
		_return_set(player)



func _return_set(player: Player) -> void :
	var set_worn: Dictionary = sets[player]
	_set_mask(player, false)
	if set_worn["swapping"]:
		spares += 1
	sets.erase(player)
	player.set_attr("Distress", null)
	player.set_attr("AirSwap", null)

	var source: String = set_worn["source"]
	var slot: int = set_worn["slot"]
	if holders.has(source) and slot >= 0 and slot < (holders[source] as Array).size():
		bars[source][slot] = float(set_worn["bar"])
		holders[source][slot] = null
	_recount()
	_update_counts()
	_publish(player)



func _on_set_prompt(player: Player, source: String) -> void :
	if Net.is_client():
		return
	if sets.has(player):
		var back: String = sets[player]["source"]
		_return_set(player)
		Game.notify(Text.m("gear.air.places.%s.back" % back), "", player)
	else:
		take_set(player, source)




func _on_set_line(player: Player, source: String, slot: int) -> void :
	if Net.is_client():
		return
	var who: = holder_of(source, slot)
	if who == player:
		_return_set(player)
		Game.notify(Text.m("gear.air.places.%s.back" % source), "", player)
		return
	if held(source, slot):
		var with_whom: String = who.display_name if who != null else "?"
		Game.notify(Text.f("gear.air.setTaken", [slot + 1, with_whom]), "", player)
		return
	if not GearService.current.is_geared(player):
		Game.notify(Text.m("gear.suitFirst"), "", player)
		return
	if sets.has(player):
		_return_set(player)
	take_set(player, source, slot)





func _fill(player: Player, set_worn: Dictionary) -> void :
	set_worn["bar"] = float(Config.Air.Capacity)
	set_worn["warned"] = false
	set_worn["refilling"] = false
	if set_worn["mask"]:
		set_worn["entry"] = float(set_worn["bar"])
		set_worn["turned"] = false
	player.set_attr("AirBar", ceili(set_worn["bar"]))
	_publish_turn(player)





func _on_spare(player: Player) -> void :
	if Net.is_client():
		return
	if not sets.has(player):
		Game.notify(Text.m("gear.air.notWearing"), "", player)
		return
	var set_worn: Dictionary = sets[player]
	if set_worn["swapping"]:
		return
	if set_worn["bar"] >= float(Config.Air.Capacity):
		Game.notify(Text.m("gear.air.alreadyFull"), "", player)
	elif spares <= 0:
		Game.notify(Text.m("gear.air.noSpares"), "", player)
	else:
		spares -= 1
		_update_counts()
		set_worn["swapping"] = true
		player.set_attr("AirSwap", true)
		var started: = player.root_position()
		var time: = float(Config.Air.SwapTime)
		Game.notify(Text.f("gear.air.swapping", [str(snappedf(time, 0.1)).trim_suffix(".0")]), "", player)
		_hands_at_set(player, false)
		get_tree().create_timer(time, false).timeout.connect( func() -> void :
			if not is_instance_valid(player) or not is_same(sets.get(player), set_worn) or not set_worn["swapping"]:
				return
			set_worn["swapping"] = false
			player.set_attr("AirSwap", null)
			if player.health <= 0.0 or player.root_position().distance_to(started) > float(Config.Air.SwapReach):
				spares += 1
				_update_counts()
				Game.notify(Text.m("gear.air.swapStopped"), "warning", player)
				return
			_fill(player, set_worn)
			_hands_at_set(player, true)
			Game.notify(Text.fill(Text.plural(spares, "gear.air.swapped"), [spares]), "", player)
		)




func _hands_at_set(player: Player, done: bool) -> void :
	_mask_moves += 1
	player.set_attr("MaskMove", "%s:%d" % ["on" if done else "off", _mask_moves])
	_start_hands(player, done)



func _by_compressor(source: String) -> bool:
	if source == "rack":
		return true
	var vehicle: = source_vehicle(source)
	return vehicle != null and vehicle.global_position.distance_to(_compressor_at) <= float(Config.Air.RestockRange)



func _queued(source: String, slot: int) -> bool:
	for job: Dictionary in _fill_jobs + _fill_queue:
		if job["source"] == source and int(job["slot"]) == slot:
			return true
	return false




func _waiting_to_fill() -> Array:
	var capacity: = float(Config.Air.Capacity)
	var found: Array = []
	for source: String in bars:
		if not _by_compressor(source):
			continue
		for index in (bars[source] as Array).size():
			if not held(source, index) and float(bars[source][index]) < capacity - 0.5 and not _queued(source, index):
				found.append({"source": source, "slot": index, "done": 0.0})
	if truck != null and _by_compressor("truck"):
		var spares_out: = int(Config.Air.TruckSpares) - spares
		for job: Dictionary in _fill_jobs + _fill_queue:
			if int(job["slot"]) < 0:
				spares_out -= 1
		for index in maxi(0, spares_out):
			found.append({"source": "truck", "slot": -1, "done": 0.0})
	return found






func _on_compressor(player: Player) -> void :
	var capacity: = float(Config.Air.Capacity)
	var set_worn: Variant = sets.get(player)
	if set_worn != null and set_worn["bar"] < capacity:
		if set_worn["mask"]:
			Game.notify(Text.m("gear.air.maskOffFirst"), "", player)
		elif not set_worn["refilling"]:
			set_worn["refilling"] = true
			Game.notify(Text.m("gear.air.refilling"), "", player)
		return
	var found: = _waiting_to_fill()
	if not found.is_empty():
		_fill_queue.append_array(found)
		_fill_by = player
		Game.notify(Text.f("gear.air.fillStarted", [_fill_jobs.size() + _fill_queue.size(), int(Config.Air.Cradles)]), "", player)
		_run_fill(0.0)
	elif not _fill_jobs.is_empty() or not _fill_queue.is_empty():
		Game.notify(Text.f("gear.air.fillStarted", [_fill_jobs.size() + _fill_queue.size(), int(Config.Air.Cradles)]), "", player)
	elif spares < int(Config.Air.TruckSpares) and not _by_compressor("truck"):
		Game.notify(Text.m("gear.air.bringTruck"), "", player)
	else:
		Game.notify(Text.m("gear.air.alreadyFull" if set_worn != null else "gear.air.nothingToRefill"), "", player)




func _run_fill(dt: float) -> void :
	if _fill_jobs.is_empty() and _fill_queue.is_empty():
		return
	var capacity: = float(Config.Air.Capacity)
	var time: = float(Config.Air.CradleFillTime)
	var changed: = false
	for job: Dictionary in _fill_jobs.duplicate():
		var source: String = job["source"]
		var slot: int = job["slot"]
		if not _by_compressor(source) or (slot >= 0 and held(source, slot)):
			_fill_jobs.erase(job)
			continue
		job["done"] = minf(1.0, float(job["done"]) + dt / time)
		if slot >= 0:
			bars[source][slot] = lerpf(float(job.get("from", bars[source][slot])), capacity, float(job["done"]))
		if float(job["done"]) < 1.0:
			continue
		_fill_jobs.erase(job)
		changed = true
		var told: Variant
		if slot < 0:
			spares = mini(int(Config.Air.TruckSpares), spares + 1)
			told = Text.f("gear.air.filledSpare", [spares, int(Config.Air.TruckSpares)])
		else:
			bars[source][slot] = capacity
			told = Text.f("gear.air.filled.%s" % source, [slot + 1])
		if is_instance_valid(_fill_by) and source != "rack":
			Game.notify(told, "", _fill_by)
	while _fill_jobs.size() < int(Config.Air.Cradles) and not _fill_queue.is_empty():
		var next: Dictionary = _fill_queue.pop_front()
		var next_slot: int = next["slot"]
		if next_slot >= 0:
			if held(next["source"], next_slot):
				continue
			next["from"] = float(bars[next["source"]][next_slot])
		_fill_jobs.append(next)
	if changed:
		_update_counts()
		if _fill_jobs.is_empty() and _fill_queue.is_empty() and is_instance_valid(_fill_by):
			Game.notify(Text.m("gear.air.fillDone"), "good", _fill_by)


func _refill(player: Player, set_worn: Dictionary, dt: float) -> void :
	var capacity: = float(Config.Air.Capacity)
	if set_worn["mask"] or player.root_position().distance_to(_compressor_at) > 14.0:
		set_worn["refilling"] = false
		Game.notify(Text.f("gear.air.refillStopped", [floori(set_worn["bar"])]), "", player)
		return
	set_worn["bar"] = minf(capacity, set_worn["bar"] + capacity / float(Config.Air.RefillTime) * dt)
	player.set_attr("AirBar", ceili(set_worn["bar"]))
	if set_worn["bar"] >= capacity:
		_fill(player, set_worn)
		Game.notify(Text.m("gear.air.full"), "good", player)





static func _set_light(look: Dictionary, color: Color, lit: bool) -> void :
	var material: StandardMaterial3D = look["light"].material_override
	material.albedo_color = color
	material.emission = color
	material.emission_energy_multiplier = 3.0 if lit else 0.15



func _set_alarm(player: Player, set_worn: Dictionary, on: bool) -> void :
	if set_worn["alarm"] != on:
		set_worn["alarm"] = on
		player.set_attr("Distress", true if on else null)
		if on:
			Game.notify(Text.f("gear.air.manDown", [player.display_name]), "danger")


static func _moving(player: Player) -> bool:

	if not player.is_local:
		return player.seat == null and player.rig.speed > 1.0
	return Vector2(player.velocity.x, player.velocity.z).length() > 1.0


func _breathe(player: Player, set_worn: Dictionary, dt: float) -> void :
	var air: Dictionary = Config.Air
	if player.health <= 0.0:

		_set_alarm(player, set_worn, true)
		return
	var moving: = _moving(player)
	var spraying: bool = player.get_attr("Spraying", false) == true




	var armed: bool = set_worn["mask"] or (bool(air.get("PassWithSet", false)) and player.brain == null)
	if armed and player.seat == null and not moving and not spraying:
		set_worn["still_for"] += dt
		if set_worn["still_for"] >= float(air["StillWarning"]) and not set_worn["still_warned"]:
			set_worn["still_warned"] = true
			Game.notify(Text.f("gear.air.moveWarning", [int(air["StillAlarm"]) - int(air["StillWarning"])]), "warning", player)
	else:
		set_worn["still_for"] = 0.0
		set_worn["still_warned"] = false

	_set_alarm(player, set_worn, set_worn["still_for"] >= float(air["StillAlarm"]) or player.get_attr("Mayday") != null)

	if set_worn["swapping"]:
		pass
	elif set_worn["mask"] and set_worn["bar"] > 0.0:
		var rate: float = air["Rest"]
		if spraying:
			rate = air["Work"]
		elif moving:
			rate = air["Walk"]
		rate *= Training.factor(player, "breathing")
		var before: float = set_worn["bar"]
		set_worn["bar"] = maxf(0.0, before - rate / 60.0 * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"]) * dt)
		if set_worn["bar"] <= float(air["Whistle"]) and not set_worn["warned"]:
			set_worn["warned"] = true
			Game.notify(Text.f("gear.air.lowAir", [int(air["Whistle"])]), "warning", player)
		if set_worn["bar"] <= 0.0:
			Game.notify(Text.m("gear.air.empty"), "danger", player)
		if ceili(set_worn["bar"]) != ceili(before):
			player.set_attr("AirBar", ceili(set_worn["bar"]))
			_publish_turn(player)
	elif set_worn["mask"]:

		player.take_damage(float(air["SuffocationDamage"]) * dt)



func lose_air(player: Player, bar: float) -> void :
	var set_worn: Variant = sets.get(player)
	if set_worn == null or Net.is_client():
		return
	set_worn["bar"] = maxf(0.0, float(set_worn["bar"]) - bar)
	player.set_attr("AirBar", ceili(set_worn["bar"]))
	_publish_turn(player)




func _expose_to_smoke(player: Player, dt: float) -> void :
	var level: = 0.0
	if player.health > 0.0 and FireService.current != null:
		level = FireService.current.breathed_at(player.head_position())
		if level > 0.0:
			GearService.current.add_soot(player, level * dt / float(Config.Gear.SootTime))
		if level > 0.0 and not on_air(player):
			player.take_damage(float(Config.Air.SmokeDamage) * level * dt)
			var now: = Game.now()
			if now - _smoke_warned.get(player, -100.0) > 10.0:
				_smoke_warned[player] = now
				Game.notify(Text.m("gear.air.smokeMask" if sets.has(player) else "gear.air.smokeNoSet"), "warning", player)
	level = roundf(level * 10.0) / 10.0
	player.set_attr("Smoke", level)








func _add_truck_lines() -> void :
	var lockers: = Lockers.of(truck)
	if lockers:
		_truck_lines.assign(_add_set_lines(lockers, "L1", "truck"))
		var swap: = lockers.add_line("L2", Text.m("gear.air.lockerSwap"), "", "air", "cylinder")
		swap.chosen.connect(_on_spare)
		_spare_lines.append(swap)

	lockers = Lockers.of(tanker)
	if lockers:
		_add_set_lines(lockers, "L1", "tanker")

	lockers = Lockers.of(command) if command else null
	if lockers:
		_add_set_lines(lockers, "BedL", "command")


func _add_set_lines(lockers: Lockers, locker: String, source: String) -> Array[LockerLine]:
	var made: Array[LockerLine] = []
	for index in (holders.get(source, []) as Array).size():
		var line: = lockers.add_line(locker, Text.f("gear.air.setNumber", [index + 1]), "", "air", "mask")
		line.chosen.connect(_on_set_line.bind(source, index))
		made.append(line)
	_set_lines[source] = made
	return made




func _build_board() -> void :
	var offset: Vector3 = Config.Air.BoardOffset
	var size: = Vector3(0.08, 1.8, 4.6)
	truck.add_part("EntryControlBoard", size, Transform3D(Basis.IDENTITY, offset), Color(20 / 255.0, 22 / 255.0, 26 / 255.0))

	var pixel: = size.z / 690.0
	var face: = Node3D.new()
	truck.body.add_child(face)
	face.transform = Transform3D(Basis(Vector3.UP, PI / 2), offset + Vector3(size.x / 2 + 0.01, size.y / 2, size.z / 2))
	var mono: = SystemFont.new()
	mono.font_names = PackedStringArray(["Menlo", "Consolas", "DejaVu Sans Mono", "Courier New", "monospace"])
	for index in 6:
		var label: = Label3D.new()
		label.pixel_size = pixel
		label.font = Ui.world_label_font() if index == 0 else mono
		label.font_size = 34 if index == 0 else 30
		label.outline_size = 0
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
		label.shaded = false
		label.position = Vector3(16 * pixel, - (4 + index * 44) * pixel, 0)
		face.add_child(label)
		_board_rows.append(label)
	_update_board()



static func _column(text: String, width: int) -> String:
	return text.left(width).rpad(width)


func _update_board() -> void :
	_draw_board(_board_state())



func _board_state() -> Array:
	var air: Dictionary = Config.Air
	var bar_per_minute: = float(air["Walk"]) * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"])
	var rows: Array = []
	for player: Variant in sets:
		if not is_instance_valid(player):
			continue
		var set_worn: Dictionary = sets[player]
		if not set_worn["mask"] or rows.size() >= _board_rows.size() - 1:
			continue
		var minutes: = maxf(0.0, (set_worn["bar"] - float(air["Whistle"])) / bar_per_minute)
		rows.append([player.display_name, ceili(set_worn["bar"]), floori(minutes), set_worn["alarm"]])
	return rows


func _draw_board(rows: Variant) -> void :
	_board_shown = rows
	if _board_rows.is_empty():
		return
	var air: Dictionary = Config.Air
	_board_rows[0].text = Text.say(Text.m("gear.air.boardTitle"))
	_board_rows[0].modulate = Color.WHITE
	var used: = 0
	for row: Array in rows:
		if used >= _board_rows.size() - 1:
			break
		used += 1
		var label: = _board_rows[used]
		var shown: = _column(row[0], 12)
		var bar: = int(row[1])
		if row[3]:
			label.text = Text.say(Text.f("gear.air.boardDown", [shown]))
			label.modulate = RED
		else:
			label.text = Text.say(Text.f("gear.air.boardRow", [shown, bar, int(row[2])]))
			label.modulate = RED if bar <= float(air["Whistle"]) else (AMBER if bar <= float(air["Capacity"]) / 2.0 else GREEN)
	for index in range(used + 1, _board_rows.size()):
		_board_rows[index].text = Text.say(Text.m("gear.air.boardEmpty")) if index == 1 else ""
		_board_rows[index].modulate = BOARD_GREY


func _block(base: Transform3D, part_name: String, size: Vector3, offset: Vector3, color: Color, material: = "Metal", shape: = PartStore.Shape.BLOCK, turn: = Basis.IDENTITY) -> PartNode:
	var part: = PartNode.create(shape, base * Transform3D(turn, offset), size, color, material, part_name)
	add_child(part)
	return part



func _piece(holder: Node3D, shape: int, size: Vector3, offset: Vector3, color: Color, turn: = Basis.IDENTITY, glow: = 0.0) -> MeshInstance3D:
	return CallKit.piece(holder, shape, size, Transform3D(turn, offset), color, glow)








func _build_compressor(base: Transform3D) -> void :
	var yellow: = Color(235 / 255.0, 190 / 255.0, 30 / 255.0)
	var dark: = Color(45 / 255.0, 46 / 255.0, 50 / 255.0)
	var steel: = Color(150 / 255.0, 155 / 255.0, 162 / 255.0)
	var grey: = Color(185 / 255.0, 188 / 255.0, 192 / 255.0)
	var black: = Color(22 / 255.0, 22 / 255.0, 24 / 255.0)
	var upright: = Basis(Vector3.BACK, PI / 2)
	var outward: = Basis(Vector3.UP, - PI / 2)
	var along: = Basis(Vector3.UP, PI / 2)
	var holder: = Node3D.new()
	holder.name = "FillingStation"
	add_child(holder)
	holder.global_transform = base


	var cabinet: = _block(base, "Cabinet", Vector3(2.9, 2.4, 1.3), Vector3(0, 1.2, -0.35), grey)
	_block(base, "Worktop", Vector3(3.0, 0.1, 1.4), Vector3(0, 2.45, -0.35), steel, "DiamondPlate")
	_piece(holder, CallKit.BLOCK, Vector3(1.3, 0.95, 0.04), Vector3(-0.68, 0.62, 0.31), steel)
	_piece(holder, CallKit.BLOCK, Vector3(1.3, 0.95, 0.04), Vector3(0.68, 0.62, 0.31), steel)
	for x: float in [-0.12, 0.12]:
		_piece(holder, CallKit.BLOCK, Vector3(0.05, 0.3, 0.06), Vector3(x, 0.75, 0.35), dark)

	_piece(holder, CallKit.BLOCK, Vector3(2.5, 0.95, 0.05), Vector3(0, 1.72, 0.32), dark)
	_piece(holder, CallKit.CYLINDER, Vector3(0.05, 0.66, 0.66), Vector3(-0.7, 1.74, 0.35), steel, outward)
	_piece(holder, CallKit.CYLINDER, Vector3(0.05, 0.58, 0.58), Vector3(-0.7, 1.74, 0.37), Color(0.94, 0.94, 0.9), outward)
	_piece(holder, CallKit.BLOCK, Vector3(0.12, 0.07, 0.02), Vector3(-0.7 + 0.2, 1.74 + 0.2, 0.39), Color(0.85, 0.15, 0.1), Basis(Vector3.BACK, - PI / 4))
	var needle: = Node3D.new()
	holder.add_child(needle)
	needle.position = Vector3(-0.7, 1.74, 0.405)
	_piece(needle, CallKit.BLOCK, Vector3(0.035, 0.25, 0.015), Vector3(0, 0.1, 0), black)
	_piece(needle, CallKit.CYLINDER, Vector3(0.03, 0.07, 0.07), Vector3.ZERO, black, outward)
	_piece(holder, CallKit.CYLINDER, Vector3(0.06, 0.24, 0.24), Vector3(0.05, 1.78, 0.35), dark, outward)
	var lamp: = _piece(holder, CallKit.BALL, Vector3.ONE * 0.18, Vector3(0.05, 1.78, 0.4), GREEN, Basis.IDENTITY, 2.5)
	for x: float in [0.55, 0.95]:
		_piece(holder, CallKit.CYLINDER, Vector3(0.1, 0.08, 0.08), Vector3(x, 1.78, 0.38), steel, outward)
		_piece(holder, CallKit.BLOCK, Vector3(0.3, 0.07, 0.07), Vector3(x, 1.78, 0.44), Color(0.75, 0.1, 0.08))


	var cylinders: Array = []
	for x: float in [-0.95, 0.0, 0.95]:
		_piece(holder, CallKit.BLOCK, Vector3(0.62, 0.12, 0.62), Vector3(x, 2.56, -0.55), dark)
		_piece(holder, CallKit.BLOCK, Vector3(0.7, 1.5, 0.06), Vector3(x, 3.3, -0.92), dark)
		for side: float in [-0.32, 0.32]:
			_piece(holder, CallKit.BLOCK, Vector3(0.06, 0.12, 0.5), Vector3(x + side, 3.5, -0.65), yellow)
		_piece(holder, CallKit.BLOCK, Vector3(0.7, 0.12, 0.06), Vector3(x, 3.5, -0.38), yellow)
		var cylinder: = Node3D.new()
		holder.add_child(cylinder)
		cylinder.position = Vector3(x, 0, -0.62)
		_piece(cylinder, CallKit.CYLINDER, Vector3(1.6, 0.5, 0.5), Vector3(0, 3.42, 0), Color(0.2, 0.21, 0.23), upright)
		_piece(cylinder, CallKit.CYLINDER, Vector3(0.3, 0.52, 0.52), Vector3(0, 4.08, 0), Color(0.9, 0.9, 0.86), upright)
		_piece(cylinder, CallKit.CYLINDER, Vector3(0.25, 0.18, 0.18), Vector3(0, 4.35, 0), steel, upright)
		_piece(cylinder, CallKit.CYLINDER, Vector3(0.12, 0.26, 0.26), Vector3(0, 4.42, 0), black, along)
		_piece(cylinder, CallKit.CYLINDER, Vector3(0.9, 0.08, 0.08), Vector3(0, 4.85, -0.15), black, upright)
		cylinder.visible = false
		cylinders.append(cylinder)


	var body: = _block(base, "Compressor", Vector3(1.4, 1.4, 1.4), Vector3(-2.25, 0.7, -0.3), yellow)
	_piece(holder, CallKit.BLOCK, Vector3(1.2, 0.5, 0.04), Vector3(-2.25, 0.55, 0.41), dark)
	for y: float in [0.42, 0.55, 0.68]:
		_piece(holder, CallKit.BLOCK, Vector3(1.1, 0.04, 0.05), Vector3(-2.25, y, 0.43), black)
	_piece(holder, CallKit.CYLINDER, Vector3(1.1, 0.62, 0.62), Vector3(-2.6, 1.72, -0.3), Color(0.28, 0.38, 0.3), along)
	_piece(holder, CallKit.CYLINDER, Vector3(0.1, 0.5, 0.5), Vector3(-2.6, 1.72, 0.27), dark, along)
	_piece(holder, CallKit.BLOCK, Vector3(0.18, 0.75, 1.15), Vector3(-2.15, 1.78, -0.3), yellow)
	for z: float in [-0.65, -0.05]:
		_piece(holder, CallKit.CYLINDER, Vector3(0.7, 0.36, 0.36), Vector3(-1.82, 1.75, z), steel, upright)
		for y: float in [1.6, 1.78, 1.96]:
			_piece(holder, CallKit.CYLINDER, Vector3(0.05, 0.48, 0.48), Vector3(-1.82, y, z), dark, upright)

	_piece(holder, CallKit.BLOCK, Vector3(0.12, 3.5, 0.12), Vector3(-1.82, 3.4, -0.92), steel)
	_piece(holder, CallKit.BLOCK, Vector3(4.0, 0.12, 0.12), Vector3(0.1, 5.15, -0.92), steel)

	for x: float in [1.72, 2.08]:
		_piece(holder, CallKit.CYLINDER, Vector3(2.8, 0.32, 0.32), Vector3(x, 1.6, -0.72), Color(70 / 255.0, 98 / 255.0, 140 / 255.0), upright)
		_piece(holder, CallKit.CYLINDER, Vector3(0.2, 0.38, 0.38), Vector3(x, 3.05, -0.72), dark, upright)
		_piece(holder, CallKit.CYLINDER, Vector3(2.0, 0.08, 0.08), Vector3(x, 4.15, -0.85), steel, upright)
		_piece(holder, CallKit.CYLINDER, Vector3(0.1, 0.4, 0.4), Vector3(x, 0.25, -0.72), dark, upright)
	_station = {"cylinders": cylinders, "needle": needle, "lamp": lamp}
	_show_station()


	_compressor_hum = Sounds.emitter(body, Sounds.loop(Config.Truck.EngineSoundId), 0.35, 8.0, 60.0)
	_compressor_hum.pitch_scale = 1.7
	var prompt: = Prompt.make(cabinet, Text.m("gear.air.refillAction"), Text.m("gear.air.compressor"), 1.0, 10.0)
	prompt.triggered.connect(_on_compressor)
	_compressor_at = base * Vector3(0, 2, 0)



func _build_rack(base: Transform3D) -> void :
	var steel: = Color(70 / 255.0, 72 / 255.0, 78 / 255.0)
	var board: = _block(base, "Board", Vector3(4.2, 6.5, 0.2), Vector3(0, 3.25, -1.2), steel)
	_block(base, "Bracket", Vector3(2.6, 0.2, 1.0), Vector3(0, 5.2, -0.7), steel)
	_block(base, "Sign", Vector3(4.2, 1, 0.2), Vector3(0, 7.1, -1.2), GearService.STALL_RED)
	_rack_label = Label3D.new()
	_rack_label.font = Ui.world_label_font()
	_rack_label.font_size = 64
	_rack_label.pixel_size = 0.006
	_rack_label.outline_size = 0
	_rack_label.shaded = false
	add_child(_rack_label)
	_rack_label.global_transform = base * Transform3D(Basis.IDENTITY, Vector3(0, 7.1, -1.08))


	var hung: = Node3D.new()
	add_child(hung)
	GearService.current.display(hung, base * Transform3D(Basis.IDENTITY, Vector3(0, 5.6, -0.2)), func(part: String, sheet: String) -> bool: return sheet == "scba" and part == "UpperTorso")

	var prompt: = Prompt.make(board, Text.m("gear.air.rackTake"), Text.m("gear.air.rack"), float(Config.Gear.DonTime), 10.0)
	prompt.triggered.connect(_on_set_prompt.bind("rack"))
	rack_prompt = prompt





func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_elapsed += delta
	_since_board += delta
	if _since_board >= 1.0:
		_since_board = 0.0
		_update_board()
	if _elapsed < float(Config.Air.Tick):
		return
	var filling: = false
	var needle: = -1.0
	_forget_gone()
	for player in Game.players:
		var set_worn: Variant = sets.get(player)
		if set_worn != null:

			if player.seat != null and set_worn["mask"] and not set_worn["moving"]:
				move_mask(player)
			_breathe(player, set_worn, _elapsed)
			if set_worn["refilling"]:
				_refill(player, set_worn, _elapsed)
				filling = filling or set_worn["refilling"]
				if set_worn["refilling"]:
					needle = float(set_worn["bar"]) / float(Config.Air.Capacity)
		_expose_to_smoke(player, _elapsed)
	_run_fill(_elapsed)
	_update_lines()


	var cradles: Array = []
	for job: Dictionary in _fill_jobs:
		cradles.append(snappedf(float(job["done"]), 0.05))
	if not _fill_jobs.is_empty():
		var first: Dictionary = _fill_jobs[0]
		needle = lerpf(float(first.get("from", 0.0)) / float(Config.Air.Capacity), 1.0, float(first["done"]))
	filling = filling or not _fill_jobs.is_empty()
	_filling = filling
	var look: Array = [cradles, snappedf(maxf(needle, 0.0), 0.02), filling]
	if look != _fill_look:
		_fill_look = look
		_show_station()
	_playing(_compressor_hum, filling)
	_elapsed = 0.0



func _forget_gone() -> void :
	var changed: = false
	for source: String in holders:
		var list: Array = holders[source]
		for index in list.size():
			if typeof(list[index]) == TYPE_OBJECT and not is_instance_valid(list[index]):
				list[index] = null
				changed = true
	for known: Variant in sets.keys():
		if not is_instance_valid(known):
			sets.erase(known)
	if changed:
		_recount()
		_update_counts()



func _show_station() -> void :
	if _station.is_empty():
		return
	var cradles: Array = _fill_look[0]
	var cylinders: Array = _station["cylinders"]
	for index in cylinders.size():
		(cylinders[index] as Node3D).visible = index < cradles.size()
	(_station["needle"] as Node3D).rotation.z = lerpf(deg_to_rad(135.0), deg_to_rad(-135.0), clampf(float(_fill_look[1]), 0.0, 1.0))
	var running: bool = _fill_look[2]
	(_station["lamp"] as MeshInstance3D).material_override = CallKit.plain(RED if running else GREEN, 2.5)


static func _smooth(s: float) -> float:
	s = clampf(s, 0.0, 1.0)
	return s * s * (3.0 - 2.0 * s)




func _start_hands(player: Player, on: bool) -> void :
	var air: Dictionary = Config.Air
	_seen_moves[player] = player.get_attr("MaskMove")
	_moves[player] = {"started": Game.now(), "length": float(air["MaskOnTime"] if on else air["MaskOffTime"]), "on": on}
	if on:
		Sounds.once(player.rig.joints["Waist"], air["MaskSoundId"], float(air["MaskSoundVolume"]), 6.0, 40.0)




func _make_look(player: Player) -> Dictionary:
	var air: Dictionary = Config.Air
	var torso: Node3D = player.rig.joints["Waist"]
	var light: = MeshInstance3D.new()
	var box: = BoxMesh.new()
	box.size = Vector3(0.13, 0.075, 0.02)
	light.mesh = box
	var glow: = StandardMaterial3D.new()
	glow.albedo_color = GREEN
	glow.emission_enabled = true
	glow.emission = GREEN
	glow.emission_energy_multiplier = 3.0
	light.material_override = glow
	torso.add_child(light)
	var torso_centre: Array = Config.Gear.Body["UpperTorso"]


	light.position = Vector3(0, torso_centre[1], 0) - FirefighterRig.JOINTS["Waist"] + air["BuddyLight"] + Vector3(0.015, 0.028, 0.36)
	return {
		"light": light, 
		"whistle": _own_sound(torso, air["WhistleSoundId"], air["WhistleVolume"]) if player.is_local else _sound(torso, air["WhistleSoundId"], air["WhistleVolume"], 90.0), 
		"breathing": _own_sound(torso, air["BreathingSoundId"], float(air["BreathingVolume"]) * OWN_BREATHING) if player.is_local else _sound(torso, air["BreathingSoundId"], air["BreathingVolume"], 30.0), 
		"distress": _sound(torso, air["WhistleSoundId"], 1.0, 160.0), 
	}



func _show(player: Player) -> void :
	var air: Dictionary = Config.Air
	var has_set: bool = player.get_attr("Scba", false) == true
	var mask: bool = has_set and player.get_attr("Mask", false) == true
	_show_pieces(player, has_set, mask)


	var move: Variant = player.get_attr("MaskMove")
	if move != _seen_moves.get(player):
		_seen_moves[player] = move
		if move is String and has_set and Game.now() >= _quiet_until:
			_start_hands(player, move.begins_with("on:"))

	var look: Variant = _looks.get(player)
	if not has_set:
		if look != null:
			_looks.erase(player)
			for key: String in look:
				look[key].queue_free()
		if _moves.has(player):
			_moves.erase(player)
			player.rig.extras.erase("mask")
		return
	if look == null:
		look = _make_look(player)
		_looks[player] = look
	var bar: = float(player.get_attr("AirBar", 0))
	var low: = bar <= float(air["Whistle"])
	var alarm: bool = player.get_attr("Distress", false) == true
	_playing(look["breathing"], mask and bar > 0.0 and player.get_attr("AirSwap") != true)

	if player.is_local:
		var turned: bool = player.get_attr("AirTurned", false) == true
		if turned and not _turn_chimed:
			var chime: Dictionary = air["TurnChime"]

			Sounds.ui(chime["Sound"], float(chime["Pitch"]), float(chime["Volume"]))
			get_tree().create_timer(0.22).timeout.connect( func() -> void :
				Sounds.ui(chime["Sound"], float(chime["Pitch"]) * 1.26, float(chime["Volume"])))
		_turn_chimed = turned
	_playing(look["whistle"], mask and low and bar > 0.0)
	_playing(look["distress"], alarm)

	if alarm:
		look["distress"].pitch_scale = 1.3 if fmod(Game.now(), 0.6) < 0.3 else 1.75
		_set_light(look, RED, fmod(Game.now(), 0.5) < 0.25)
	elif low:
		_set_light(look, RED, fmod(Game.now(), 1.0) < 0.5)
	else:
		_set_light(look, GREEN if bar > float(air["Capacity"]) / 2.0 else AMBER, true)


func _process(_delta: float) -> void :
	var local: = Game.local_player
	if local != null and not Game.ui_open and local.get_attr("Scba", false) == true and Input.is_action_just_pressed("mask"):
		Net.request("air.mask")
	for known: Variant in _looks.keys():
		if not is_instance_valid(known):
			_looks.erase(known)
			_seen_moves.erase(known)
	for player in Game.players:
		_show(player)


	for mover: Variant in _moves.keys():
		if not is_instance_valid(mover):
			_moves.erase(mover)
			continue
		var player: Player = mover
		var move: Dictionary = _moves[player]
		var t: float = (Game.now() - move["started"]) / move["length"]
		if t >= 1.0:
			_moves.erase(player)
			player.rig.extras.erase("mask")
			continue

		var raised: = _smooth(t / 0.33) * (1.0 - _smooth((t - 0.68) / 0.32))

		var from: = 0.5 if move["on"] else 0.2
		var strap: = sin(PI * clampf((t - from) / 0.3, 0.0, 1.0))
		var turns: = {}
		for joint_name: String in MASK_JOINTS:
			var spec: Array = MASK_JOINTS[joint_name]
			turns[joint_name] = Vector3(deg_to_rad(spec[0] * raised + spec[2] * strap * raised), deg_to_rad(spec[1]) * raised, 0)
		player.rig.extras["mask"] = turns
