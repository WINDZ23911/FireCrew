class_name VistaClosers
extends RefCounted













const CONCRETE: = Color8(192, 190, 182)
const CONCRETE_DARK: = Color8(150, 148, 142)
const STEEL: = Color8(132, 136, 142)
const RENDER: = Color8(226, 214, 186)
const TILES: = Color8(150, 72, 52)
const RED: = Color8(196, 36, 32)
const WHITE: = Color8(240, 240, 236)
const SIGN_BLUE: = Color8(30, 70, 140)
const RUBBER: = Color8(40, 40, 42)
const LAMP: = Color8(255, 226, 170)

const SILOS: = Vector2(250.0, -985.0)
const ROAD_FROM: = Vector2(-6.3, 1120.0)
const ROAD_WAY: = Vector2(-0.3096, 0.9509)

static var places: Array = []


static func apply(kit: PolishKit) -> String:
	places.clear()
	var parent: = kit.own_folder("VistaClosers")
	var made: = kit.store.count
	_silos(kit, parent)
	_crossing(kit, parent)
	return "vista closers: silos, a level crossing and a railway halt (%d parts)" % (kit.store.count - made)


static func _silos(kit: PolishKit, parent: int) -> void :
	var at: = Vector3(SILOS.x, 0, SILOS.y)
	var tall: = 62.0
	for index in 3:
		var foot: = at + Vector3((index - 1) * 17.0, 0, 0)
		kit.post(parent, foot, tall, 16.0, CONCRETE, "Concrete", "Silo", PolishKit.SOLID)
		kit.post(parent, foot + Vector3(0, tall, 0), 1.2, 16.6, CONCRETE_DARK, "Concrete", "SiloRim")
		kit.post(parent, foot + Vector3(0, tall + 1.2, 0), 3.0, 9.0, CONCRETE_DARK, "Concrete", "SiloCap")

	var tower: = at + Vector3(-34.0, 0, 0)
	kit.box(parent, Transform3D(Basis(), tower + Vector3(0, 41, 0)), Vector3(12, 82, 12), CONCRETE, "Concrete", "ElevatorTower", PolishKit.SOLID)
	kit.box(parent, Transform3D(Basis(), tower + Vector3(0, 83.5, 0)), Vector3(14, 3, 14), CONCRETE_DARK, "Concrete", "ElevatorHead")
	kit.box(parent, Transform3D(Basis(), at + Vector3(-8.0, tall + 6.0, 0)), Vector3(56, 5, 7), STEEL, "Metal", "SiloGallery")
	for y: float in [18.0, 38.0, 58.0]:
		kit.box(parent, Transform3D(Basis(), tower + Vector3(0, y, 6.05)), Vector3(3.0, 4.0, 0.2), Color8(60, 64, 70), "Glass", "ElevatorWindow")

	kit.rod(parent, tower + Vector3(-6, 30, 0), tower + Vector3(-30, 8, 0), 3.0, STEEL, "Metal", "SiloConveyor")
	kit.box(parent, Transform3D(Basis(), tower + Vector3(-40, 7, 0)), Vector3(24, 14, 20), CONCRETE_DARK, "Concrete", "LoadingShed", PolishKit.SOLID)
	kit.box(parent, Transform3D(Basis(), tower + Vector3(-40, 14.6, 0)), Vector3(26, 1.2, 22), STEEL, "Metal", "LoadingShedRoof")

	OldTown.lit.append({"at": tower + Vector3(0, 76, 0), "size": Vector3(12.6, 12, 12.6), "basis": Basis(), "color": CONCRETE})
	OldTown.lit.append({"at": tower + Vector3(0, 84.2, 0), "size": Vector3(1.0, 1.0, 1.0), "basis": Basis(), "color": Color(1.0, 0.25, 0.2)})
	places.append(["hud.map.silos", SILOS])


static func _crossing(kit: PolishKit, parent: int) -> void :
	var way: = Vector3(ROAD_WAY.x, 0, ROAD_WAY.y)
	var across: = Vector3( - way.z, 0, way.x)
	var from: = Vector3(ROAD_FROM.x, 0, ROAD_FROM.y)
	var line: = Train.LINE_Z

	var s: = (line - from.z) / way.z
	var meet: = from + way * s
	var length: = s + 110.0
	var road: = Transform3D(Basis.looking_at(way, Vector3.UP), from + way * (length / 2.0) + Vector3(0, 0.0, 0))
	kit.box(parent, road, Vector3(30.0, 0.4, length), Color8(55, 55, 60), "Asphalt", "road", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:
		kit.box(parent, road.translated_local(Vector3(side * 13.5, 0.03, 0)), Vector3(0.4, 0.42, length - 4.0), WHITE, "SmoothPlastic", "paint")

	kit.box(parent, Transform3D(Basis(), Vector3(meet.x, 0.85, line)), Vector3(32.0, 0.3, 9.0), RUBBER, "Rubber", "CrossingDeck", PolishKit.SOLID)
	for end: float in [-1.0, 1.0]:


		var post_at: = meet - way * end * 13.0 + across * end * 18.5
		var facing: = PolishKit.facing(post_at, - way * end)
		kit.post(parent, post_at, 9.0, 0.5, WHITE, "Metal", "CrossingPost", PolishKit.FIXTURE)
		kit.box(parent, facing.translated_local(Vector3(0, 7.0, 0.35)), Vector3(3.2, 1.5, 0.3), Color8(28, 28, 30), "Metal", "CrossingLights")
		for x: float in [-0.8, 0.8]:
			kit.box(parent, facing.translated_local(Vector3(x, 7.0, 0.1)), Vector3(0.9, 0.9, 0.15), Color8(120, 24, 20), "Glass", "CrossingLamp")
		for turn: float in [0.6, -0.6]:
			var board: = Transform3D(facing.basis * Basis(Vector3.BACK, turn), post_at + Vector3(0, 10.6, 0) + facing.basis * Vector3(0, 0, -0.3))
			kit.box(parent, board, Vector3(6.0, 0.9, 0.12), WHITE, "SmoothPlastic", "StAndrewsCross")
			kit.box(parent, board.translated_local(Vector3(0, 0, -0.07)), Vector3(6.2, 1.1, 0.04), RED, "SmoothPlastic", "StAndrewsCrossEdge")
		var drive: = post_at + across * end * 1.6
		kit.box(parent, Transform3D(Basis(), drive + Vector3(0, 1.4, 0)), Vector3(1.6, 2.8, 1.6), Color8(60, 62, 66), "Metal", "BarrierDrive", PolishKit.FIXTURE)

		for band in 6:
			kit.box(parent, Transform3D(Basis(), drive + Vector3(0, 3.6 + band * 2.0, 0)), Vector3(0.45, 2.0, 0.45), RED if band % 2 == 0 else WHITE, "SmoothPlastic", "BarrierBoom")
		kit.box(parent, Transform3D(Basis.looking_at(across, Vector3.UP), meet - way * end * 9.0), Vector3(0.5, 0.42, 13.0), WHITE, "SmoothPlastic", "paint")
		OldTown.lit.append({"at": post_at + Vector3(0, 7.0, 0), "size": Vector3(0.6, 0.6, 0.6), "basis": facing.basis, "color": Color(0.9, 0.15, 0.1)})


	var platform: = Vector3(meet.x + 80.0, 0, line + 8.5)
	kit.box(parent, Transform3D(Basis(), platform + Vector3(0, 0.6, 0)), Vector3(110, 1.2, 7), CONCRETE, "Concrete", "Platform", PolishKit.SOLID)
	kit.box(parent, Transform3D(Basis(), platform + Vector3(0, 1.22, -3.2)), Vector3(110, 0.05, 0.4), Color8(236, 206, 60), "SmoothPlastic", "PlatformEdge")
	var house: = platform + Vector3(0, 0, 18.0)
	kit.box(parent, Transform3D(Basis(), house + Vector3(0, 8, 0)), Vector3(26, 16, 14), RENDER, "Plaster", "StationHouse", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:
		var slope: = Transform3D(Basis(Vector3.UP, PI if side > 0.0 else 0.0), house + Vector3(0, 19.0, side * 4.0))
		kit.wedge(parent, slope, Vector3(29, 6, 8), TILES, "ClayRoofTiles", "StationRoof")
	for x: float in [-8.0, 0.0, 8.0]:
		kit.box(parent, Transform3D(Basis(), house + Vector3(x, 10.5, -7.05)), Vector3(3.2, 4.0, 0.2), Color8(78, 100, 122), "Glass", "StationWindow")
		OldTown.lit.append({"at": house + Vector3(x, 10.5, -7.2), "size": Vector3(3.2, 4.0, 0.1), "basis": Basis(), "color": LAMP})
	kit.box(parent, Transform3D(Basis(), house + Vector3(5.0, 4.5, -7.05)), Vector3(4.0, 8.5, 0.25), Color8(96, 70, 52), "Wood", "StationDoor")
	var board: = kit.box(parent, Transform3D(Basis(), house + Vector3(0, 14.6, -7.2)), Vector3(12.0, 2.2, 0.2), SIGN_BLUE, "SmoothPlastic", "StationBoard")
	var store: = kit.store
	var gui: = store.add_node(board, "SurfaceGui", "Name", {"Face": "NormalId.Front", "PixelsPerStud": 40.0})
	store.add_node(gui, "TextLabel", "Words", {
		"Text": str(Edition.data().get("rail", {}).get("station", "")), "TextColor3": WHITE, "Font": "Font.GothamBold", "TextScaled": true, 
		"Size": {"X": {"Scale": 0.9, "Offset": 0}, "Y": {"Scale": 0.8, "Offset": 0}}, 
		"Position": {"X": {"Scale": 0.05, "Offset": 0}, "Y": {"Scale": 0.1, "Offset": 0}}, 
	})
	for x: float in [-40.0, 0.0, 40.0]:
		kit.post(parent, platform + Vector3(x, 1.2, 2.0), 9.0, 0.4, STEEL, "Metal", "PlatformLampPost")
		kit.box(parent, Transform3D(Basis(), platform + Vector3(x, 10.4, 1.4)), Vector3(0.8, 0.4, 1.6), Color8(60, 62, 66), "Metal", "PlatformLamp")
		OldTown.lit.append({"at": platform + Vector3(x, 10.15, 1.4), "size": Vector3(0.7, 0.12, 1.4), "basis": Basis(), "color": LAMP})
	places.append(["hud.map.railStation", Vector2(house.x, house.z)])
