class_name ToolService
extends Node3D






















signal carried_changed(player: Player)

static var current: ToolService

const SWING_TIME: = 0.6
const TICK: = 0.1
const SHARE_HZ: = 10.0
const TIPS: Array[String] = ["Spreader", "Cutter", "Chainsaw", "Floodlight", "Fan", "Thermal camera"]

const BEHAVIOURS: = {
	"Axe": {"forces": true, "use": "swing"}, 
	"Halligan bar": {"forces": true, "use": "swing"}, 
	"Crowbar": {"forces": true, "use": "swing"}, 
	"Bolt cutters": {"cuts": true}, 
	"Spreader": {"forces": true, "use": "hydraulic"}, 
	"Cutter": {"use": "hydraulic"}, 
	"Extinguisher": {"use": "extinguisher"}, 
	"Chainsaw": {"use": "chainsaw", "carry": true}, 
	"Floodlight": {"use": "stand"}, 
	"Fan": {"use": "stand"}, 
	"Thermal camera": {}, 
}

const CATEGORIES: = {
	"Axe": "forcing", 
	"Halligan bar": "forcing", 
	"Crowbar": "forcing", 
	"Bolt cutters": "forcing", 
	"Spreader": "rescue", 
	"Cutter": "rescue", 
	"Chainsaw": "rescue", 
	"Extinguisher": "fire", 
	"Floodlight": "scene", 
	"Fan": "scene", 
	"Thermal camera": "scene", 
}


var saw: = Callable()

var hydraulic: = Callable()

var items: Array = []
var _carried: Dictionary = {}
var _in_hand: Dictionary = {}
var _others: Dictionary = {}
var _watched: Dictionary = {}
var _tick: = 0.0
var _pulled: = false
var _belts: Dictionary = {}
var _told: = false
var _was_client: = false


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null



func _ready() -> void :
	for vehicle in Vehicle.all:
		for prop_name: String in vehicle.props:
			var prop: Dictionary = vehicle.props[prop_name]
			if not String(prop["tool"]).is_empty():
				_stock(vehicle, prop_name, prop)

	Net.handle("tool.trigger", _on_trigger)
	Net.handle("tool.slot", _on_slot)
	Net.share("tools", _state, _apply_state, SHARE_HZ)
	Net.peer_left.connect(_on_left)
	Net.started.connect(_on_net_started)
	Net.stopped.connect(_on_net_stopped)






func held(player: Player) -> String:
	var item: Variant = _in_hand.get(player)
	return item["name"] if item != null else ""



func held_tool(player: Player) -> HandTool:
	var item: Variant = _in_hand.get(player)
	return item["tool"] if item != null else null



func trigger_held(player: Player) -> bool:
	var item: Variant = _in_hand.get(player)
	return item != null and item["using"]



func working(player: Player) -> int:
	var tool: = held_tool(player)
	return int(tool.get_attr("Working", 0)) if tool != null else 0



func carried(player: Player) -> Array:
	return _carried.get(player, [])



func hands_free(player: Player) -> bool:
	return not _in_hand.has(player)



func put_away(player: Player) -> void :
	if _in_hand.has(player):
		_unequip(player)










func carry_other(player: Player, entry: Dictionary) -> void :
	if not _others.has(player):
		_others[player] = []
	_others[player].append(entry)
	carried_changed.emit(player)



func drop_other(player: Player, entry: Dictionary) -> void :
	var list: Array = _others.get(player, [])
	for index in list.size():
		if is_same(list[index], entry):
			list.remove_at(index)
			break
	carried_changed.emit(player)



func slots(player: Player) -> Array:
	if Net.is_client():
		return _belts.get(player, [])
	return carried(player) + _others.get(player, [])


func slot_in_hand(player: Player, slot: Dictionary) -> bool:
	if slot.has("held"):
		return slot["held"]
	if slot.has("in_hand"):
		return slot["in_hand"].call()
	return _in_hand.get(player) != null and is_same(_in_hand[player], slot)



func toggle_slot(player: Player, slot: Dictionary) -> void :
	if not slot.has("set_in_hand"):
		toggle(player, slot)
		return
	if slot["in_hand"].call():
		slot["set_in_hand"].call(false)
	elif not _hands_taken(player):
		clear_hands(player, slot)
		slot["set_in_hand"].call(true)
	carried_changed.emit(player)



func clear_hands(player: Player, keep: Variant = null) -> void :
	put_away(player)
	for other: Dictionary in _others.get(player, []):
		if not (keep != null and is_same(other, keep)) and other["in_hand"].call():
			other["set_in_hand"].call(false)






func _swing(item: Dictionary, player: Player) -> void :
	var now: = Game.now()
	if now < item["next_swing"]:
		return
	item["next_swing"] = now + SWING_TIME
	var tool: HandTool = item["tool"]
	tool.set_attr("Swing", int(tool.get_attr("Swing", 0)) + 1)
	Sounds.once(tool, Config.Tools.Sounds.Swing, 0.8, 10.0, 140.0)
	_face(player)

	get_tree().create_timer(float(Config.Tools.SwingTime) * 0.55, false).timeout.connect( func() -> void :
		if is_instance_valid(tool) and is_instance_valid(player) and player.health > 0.0 and _in_hand.get(player) != null and is_same(_in_hand[player], item):
			House.strike_glass(player.root_position(), player.facing())
			if player.is_local and player.camera != null:
				player.camera.shake = maxf(player.camera.shake, 0.08)
	)



static func _face(player: Player) -> void :
	if player.is_local and player.camera != null:
		player.camera.face_view(0.6)




static func _look(player: Player) -> Vector3:
	if not player.is_local:
		var to: = player.aim_point() - player.root_position()
		to.y = 0.0
		if to.length() > 2.0:
			return to.normalized()
	return player.facing()


func _fit_extinguisher(tool: HandTool) -> void :
	tool.add_sound("Extinguisher", true, 0.7)



func _start_extinguisher(item: Dictionary, player: Player) -> void :
	if item["charge"] <= 0.0:
		Game.notify(Text.m("gear.tools.extinguisherSpent"), "", player)
		return
	_fit_powder(item["tool"])
	item["using"] = true
	item["tool"].set_attr("Working", 1)



func _fit_powder(tool: HandTool) -> void :
	if tool.emitters.has("Cloud"):
		return
	var settings: Dictionary = Config.Tools.Extinguisher
	var nozzle: = Node3D.new()
	nozzle.top_level = true
	tool.add_child(nozzle)
	tool.points["Powder"] = nozzle

	tool.emitters["Cloud"] = RbxEmitter.make(nozzle, {
		"Enabled": false, 
		"Mesh": ToonFire.puff_mesh(), 
		"Material": ToonFire.fog_material(), 
		"Color": Color(0.9, 0.9, 0.88), 
		"Rate": 40, 
		"Speed": [float(settings["Reach"]) * 1.6, float(settings["Reach"]) * 2.2], 
		"Lifetime": [0.45, 0.6], 
		"SpreadAngle": 9, 
		"Rotation": [0, 360], 
		"Size": [[0.0, 0.4], [0.5, 1.8], [1.0, 2.6]], 
		"Transparency": [[0.0, 1.0], [1.0, 1.0]], 
		"Direction": Vector3.FORWARD, 
	})




func _aim_powder(tool: HandTool, player: Player) -> Vector3:
	var look: = player.facing()
	var origin: = player.rig.hand_right.global_position + look
	var nozzle: Node3D = tool.points["Powder"]
	var tip: Node3D = tool.points.get("HornTip")
	if tip != null and tip.is_inside_tree() and ( - tip.global_basis.z).dot(look) > 0.4:
		nozzle.global_transform = Rbx.look_at(tip.global_position, tip.global_position - tip.global_basis.z)
	else:
		nozzle.global_transform = Rbx.look_at(origin, origin + look)
	return origin


func _tick_extinguisher(item: Dictionary, player: Player, dt: float) -> void :
	var settings: Dictionary = Config.Tools.Extinguisher
	var tool: HandTool = item["tool"]
	var look: = player.facing()
	var origin: = _aim_powder(tool, player)
	tool.emit("Cloud", true)
	tool.play("Extinguisher", true)
	item["charge"] -= dt
	if FireService.current != null:

		var cloud: = PackedVector3Array([origin, origin + look * float(settings["Reach"])])
		FireService.current.spray(player, cloud, dt * HoseService.powder_power(cloud, float(settings["Radius"])), float(settings["Radius"]))
	if item["charge"] <= 0.0:
		_stop_using(item)
		Game.notify(Text.m("gear.tools.extinguisherEmpty"), "", player)





func _fit_chainsaw(tool: HandTool) -> void :
	tool.add_sound("ChainsawIdle", true, 0.5)
	tool.add_sound("ChainsawCut", true, 0.8)
	var bar: = tool.add_point("Bar", Vector3(0.4, 0.28, -1.8), false)
	tool.emitters["Chips"] = RbxEmitter.make(bar, {
		"Enabled": false, 
		"Texture": Config.Hose.DropletTexture, 
		"Color": Color(226 / 255.0, 196 / 255.0, 140 / 255.0), 
		"LightInfluence": 1, 
		"Rate": 90, 
		"Speed": [8, 16], 
		"Lifetime": [0.4, 0.8], 
		"SpreadAngle": 35, 
		"Acceleration": Vector3(0, -40, 0), 
		"Rotation": [0, 360], 
		"Size": [0.25, 0.1], 
		"Direction": Vector3.UP, 
	})
	tool.add_chain(bar)
	var exhaust: = tool.add_point("Exhaust", Vector3(-0.1, 0.3, -1.3), false)
	tool.emitters["Fumes"] = RbxEmitter.make(exhaust, {
		"Enabled": false, 
		"Texture": Config.Hose.MistTexture, 
		"Color": Color(150 / 255.0, 152 / 255.0, 158 / 255.0), 
		"LightInfluence": 1, 
		"Rate": 5, 
		"MaxRate": 16, 
		"Speed": [1, 2.5], 
		"Lifetime": [0.5, 0.9], 
		"SpreadAngle": 25, 
		"Acceleration": Vector3(0, 3, 0), 
		"Rotation": [0, 360], 
		"Size": [0.15, 0.9], 
		"Transparency": [0.6, 1], 
		"Direction": Vector3.FORWARD, 
	})


func _start_chainsaw(item: Dictionary, _player: Player) -> void :
	if item["using"]:
		return
	item["using"] = true
	var tool: HandTool = item["tool"]
	tool.play("ChainsawIdle", false)
	tool.play("ChainsawCut", true)
	tool.emitters["Fumes"].set_rate(16)
	tool.set_attr("Working", 1)


func _tick_chainsaw(item: Dictionary, player: Player, dt: float) -> void :
	var tool: HandTool = item["tool"]
	var cutting: bool = saw.is_valid() and saw.call(player, player.root_position(), player.facing(), dt) == true
	tool.emit("Chips", cutting)
	tool.play("ChainsawCut", true, 0.82 if cutting else 1.0)
	tool.set_attr("Working", 2 if cutting else 1)



func _idle_chainsaw(item: Dictionary, running: bool) -> void :
	var tool: HandTool = item["tool"]
	if tool == null:
		return
	tool.play("ChainsawIdle", running)
	if running:
		tool.emitters["Fumes"].set_rate(5)
	else:
		tool.emit("Fumes", false)
		tool.play("ChainsawCut", false)
		tool.emit("Chips", false)






func _fit_hydraulic(tool: HandTool) -> void :
	tool.add_sound("Hydraulic", true, 0.6)
	var jaws: = tool.add_point("Jaws", Vector3(0, -0.48, -1.7), true)
	tool.emitters["Sparks"] = RbxEmitter.make(jaws, {
		"Enabled": false, 
		"Texture": Config.Hose.DropletTexture, 
		"Color": [Color(1.0, 226 / 255.0, 150 / 255.0), Color(1.0, 120 / 255.0, 30 / 255.0)], 
		"LightEmission": 1, 
		"Brightness": 3, 
		"LightInfluence": 0, 
		"Rate": 45, 
		"Speed": [6, 14], 
		"Lifetime": [0.2, 0.5], 
		"SpreadAngle": 70, 
		"Acceleration": Vector3(0, -45, 0), 
		"Drag": 2, 
		"Size": [0.12, 0.03], 
		"Direction": Vector3.UP, 
	})


func _start_hydraulic(item: Dictionary, _player: Player) -> void :
	if item["using"]:
		return
	item["using"] = true
	var tool: HandTool = item["tool"]
	tool.play("Hydraulic", true)
	tool.set_attr("Working", 1)


func _tick_hydraulic(item: Dictionary, player: Player, dt: float) -> void :
	var tool: HandTool = item["tool"]
	var result: Variant = hydraulic.call(player, item["name"], player.root_position(), player.facing(), dt) if hydraulic.is_valid() else null
	var at_work: bool = result is Array and result.size() > 0 and result[0] == true
	tool.play("Hydraulic", true, 0.85 if at_work else 1.1)
	tool.emit("Sparks", at_work)
	if at_work and result.size() > 1:
		tool.set_attr("Progress", float(result[1]))
	tool.set_attr("Working", 2 if at_work else 1)



func _stop_using(item: Dictionary) -> void :
	if not item["using"]:
		return
	item["using"] = false
	var tool: HandTool = item["tool"]
	if tool == null or not is_instance_valid(tool):
		return
	match item["behaviour"].get("use", ""):
		"extinguisher":
			tool.emit("Cloud", false)
			tool.play("Extinguisher", false)
			tool.set_attr("Working", null)
		"chainsaw":
			tool.emitters["Fumes"].set_rate(5)
			tool.set_attr("Working", null)
			tool.emit("Chips", false)
			tool.play("ChainsawCut", false)
			tool.play("ChainsawIdle", item["holder"] != null and _in_hand.get(item["holder"]) != null and is_same(_in_hand[item["holder"]], item))
		"hydraulic":
			tool.play("Hydraulic", false)
			tool.emit("Sparks", false)
			tool.set_attr("Working", null)



func _stand_floodlight(tool: HandTool) -> void :
	var settings: Dictionary = Config.Tools.Floodlight
	var beam: = SpotLight3D.new()
	beam.name = "Lamp"
	beam.spot_range = settings["Range"]
	beam.spot_angle = minf(89.0, float(settings["Angle"]) / 2.0)
	beam.spot_angle_attenuation = 0.5


	beam.light_energy = float(settings["Brightness"]) * 3.0
	beam.rotation_degrees.x = -7.0
	beam.light_color = Color(1.0, 0.97, 0.9)
	Graphics.lamp_shadow(beam)

	for piece: Node in tool.find_children("*", "MeshInstance3D", true, false):
		(piece as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	tool.add_child(beam)
	beam.position = Vector3(0, 0.6, -0.3)
	tool.points["Lamp"] = beam


func _tick_fan(item: Dictionary, dt: float) -> void :
	var fire: = FireService.current
	if fire == null:
		return
	var settings: Dictionary = Config.Tools.Fan
	var tool: HandTool = item["tool"]


	var did: = fire.fan(tool.global_transform, dt)
	item["fan_did"] = did
	if did == "clearing" or fire.incident.is_empty() or not (fire.incident["group"]["building"] as Building).has_rooms():
		return
	var now: = Game.now()
	if now - float(item.get("fan_told", -100.0)) < float(settings["TellEvery"]):
		return
	var nearest: Player = null
	for player in Game.players:
		var away: = player.root_position().distance_to(tool.global_position)
		if away < 30.0 and (nearest == null or away < nearest.root_position().distance_to(tool.global_position)):
			nearest = player
	if nearest != null:
		item["fan_told"] = now
		Game.tell(nearest, Text.m("calls.fire.read.fanNoExhaust" if did == "noexhaust" else "calls.fire.read.fanNoDoor"))






func _stock(vehicle: Vehicle, prop_name: String, prop: Dictionary) -> void :
	var lockers: = Lockers.of(vehicle)
	var node: Node3D = prop["node"]
	if lockers == null or node.get_child_count() == 0:
		return
	var tool_name: String = prop["tool"]

	var clip: = Node3D.new()
	clip.name = "Clip" + prop_name
	vehicle.add_child(clip)
	clip.position = prop["spot"]
	var item: = {
		"name": tool_name, "vehicle": vehicle, "prop_name": prop_name, "prop": prop, "clip": clip, 
		"behaviour": BEHAVIOURS.get(tool_name, {}), "holder": null, "tool": null, "standing": false, 
		"charge": float(Config.Tools.Extinguisher.Charge), "using": false, "next_swing": 0.0, "refill_at": -1.0, 
		"pick_up": null, "since_fan": 0.0, "index": items.size(), 
	}
	HandTool.dress_prop(tool_name, prop)
	var line: = lockers.add_line(prop["locker"], Text.m("gear.tools.take"), Text.named("tools", tool_name), CATEGORIES.get(tool_name, "other"), ToolIcons.of(tool_name))
	item["line"] = line
	line.chosen.connect(_on_line.bind(item))
	items.append(item)


func _create_tool(item: Dictionary) -> HandTool:
	var tool: = HandTool.make(item["name"], item["prop"])
	var behaviour: Dictionary = item["behaviour"]
	if behaviour.get("forces", false):
		tool.set_attr("Forces", true)
	match behaviour.get("use", ""):
		"extinguisher":
			_fit_extinguisher(tool)
		"chainsaw":
			_fit_chainsaw(tool)
		"hydraulic":
			_fit_hydraulic(tool)
	return tool


func _watch(player: Player) -> void :
	if _watched.has(player):
		return
	_watched[player] = true

	player.died.connect( func() -> void :
		for item: Dictionary in carried(player).duplicate():
			_put_back(item)
	)

	player.attribute_changed.connect( func(key: String, value: Variant) -> void :
		if key in ["Line", "Supply", "Carrying"] and value != null and not (value is bool and value == false):
			put_away(player)
	)


static func _hands_taken(player: Player) -> bool:
	return player.get_attr("Line") != null or player.get_attr("Supply") != null or player.get_attr("HoseRoll") != null or player.get_attr("Carrying", false) == true or player.seat != null



func _hold(player: Player, item: Dictionary) -> void :
	var tool: HandTool = item["tool"]
	if tool.get_parent() != null:
		tool.get_parent().remove_child(tool)
	player.rig.hand_right.add_child(tool)
	tool.body.transform = tool.standing.affine_inverse()
	tool.transform = Transform3D.IDENTITY
	tool.visible = true
	tool.holder = player


func _equip(player: Player, item: Dictionary) -> void :
	if _hands_taken(player):
		return
	clear_hands(player)
	_hold(player, item)
	_in_hand[player] = item
	player.holding = "tool"
	player.set_attr("Tool", item["name"])
	player.set_attr("ToolForces", true if item["behaviour"].get("forces", false) else null)
	if item["behaviour"].get("use", "") == "chainsaw":
		_idle_chainsaw(item, true)
	carried_changed.emit(player)


func _unequip(player: Player) -> void :
	var item: Variant = _in_hand.get(player)
	if item == null:
		return
	_stop_using(item)
	_in_hand.erase(player)
	var tool: HandTool = item["tool"]
	if tool != null and is_instance_valid(tool):
		tool.visible = false
		if item["behaviour"].get("use", "") == "chainsaw":
			_idle_chainsaw(item, false)
	if player.holding == "tool" and player.get_attr("Supply") == null:
		player.holding = ""
	player.set_attr("Tool", null)
	player.set_attr("ToolForces", null)
	carried_changed.emit(player)



func toggle(player: Player, item: Dictionary) -> void :
	if item["holder"] != player or item["standing"]:
		return
	if _in_hand.get(player) != null and is_same(_in_hand[player], item):
		_unequip(player)
	else:
		_equip(player, item)


func _give(player: Player, item: Dictionary) -> void :
	_watch(player)
	item["holder"] = player
	item["standing"] = false
	item["line"].holder = player
	if not _carried.has(player):
		_carried[player] = []
	_carried[player].append(item)
	_equip(player, item)
	carried_changed.emit(player)


func _drop_from(player: Player, item: Dictionary) -> void :
	if _in_hand.get(player) != null and is_same(_in_hand[player], item):
		_unequip(player)
	var list: Array = _carried.get(player, [])
	for index in list.size():
		if is_same(list[index], item):
			list.remove_at(index)
			break
	carried_changed.emit(player)



func _put_back(item: Dictionary) -> void :
	var holder: Player = item["holder"]
	if holder != null and is_instance_valid(holder):
		_drop_from(holder, item)
	if item["tool"] != null and is_instance_valid(item["tool"]):
		item["tool"].queue_free()
	var used: bool = item["charge"] < float(Config.Tools.Extinguisher.Charge)
	item["holder"] = null
	item["tool"] = null
	item["standing"] = false
	item["using"] = false
	item["pick_up"] = null
	var line: LockerLine = item["line"]
	line.holder = null
	line.action = Text.m("gear.tools.take")
	item["prop"]["node"].visible = true
	Sounds.once(item["clip"], Config.Tools.Sounds.Clunk)
	if used:
		item["refill_at"] = Game.now() + float(Config.Tools.Extinguisher.Refill)



func _set_down(item: Dictionary, player: Player) -> void :
	if player.seat != null or player.health <= 0.0:
		return
	_face(player)
	var look: = _look(player)
	var flat: = Vector3(look.x, 0, look.z).normalized()
	var ahead: = player.root_position() + flat * 4.0
	var ground: = Game.world.raycast(ahead + Vector3(0, 3, 0), ahead + Vector3(0, -9, 0), World.LAYER_SOLID, [player.get_rid()])
	if ground.is_empty():
		Game.notify(Text.m("gear.tools.nowhere"), "", player)
		return
	var at: Vector3 = ground["position"]
	var place: = Rbx.look_at(at, at + flat)
	if player.brain != null:
		player.set_down_ahead()
	_drop_from(player, item)
	item["holder"] = null
	item["standing"] = true
	item["line"].holder = null
	_stand(item, place)
	Sounds.once(item["tool"], Config.Tools.Sounds.Clunk)



func _stand(item: Dictionary, place: Transform3D) -> void :
	var tool: HandTool = item["tool"]
	tool.holder = null
	if tool.get_parent() != null:
		tool.get_parent().remove_child(tool)
	add_child(tool)

	tool.body.transform = tool.standing.affine_inverse()
	tool.global_transform = place
	tool.visible = true

	var pick_up: = Prompt.new()
	pick_up.net_id = "tool.%d.pickup" % int(item["index"])
	pick_up.action = Text.m("gear.tools.pickUp")
	pick_up.object = Text.named("tools", item["name"])
	pick_up.hold = 0.3
	pick_up.reach = 9.0
	tool.add_child(pick_up)
	pick_up.position = Vector3(0, 1.0, 0)
	pick_up.triggered.connect( func(taker: Player) -> void :
		if Net.is_host() and taker.health > 0.0 and item["standing"] and is_same(item["pick_up"], pick_up):
			_pick_up(item, taker)
	)
	item["pick_up"] = pick_up
	match item["name"]:
		"Floodlight":
			_stand_floodlight(tool)
		"Fan":
			tool.add_sound("Fan", true, 0.9)
			tool.play("Fan", true)



func _lift(item: Dictionary) -> void :
	var tool: HandTool = item["tool"]
	if item["pick_up"] != null and is_instance_valid(item["pick_up"]):

		item["pick_up"].get_parent().remove_child(item["pick_up"])
		item["pick_up"].queue_free()
	item["pick_up"] = null
	if tool.points.has("Lamp"):
		tool.points["Lamp"].queue_free()
		tool.points.erase("Lamp")
	tool.play("Fan", false)
	tool.visible = false


func _pick_up(item: Dictionary, taker: Player) -> void :
	_lift(item)
	_give(taker, item)


func _on_line(player: Player, item: Dictionary) -> void :
	if Net.is_client():
		return
	var shown: Variant = Text.named("tools", item["name"])
	var holder: Player = item["holder"]
	if holder == player:
		_put_back(item)
		Game.notify(Text.f("gear.tools.onTruck", [shown]), "", player)
	elif holder != null:
		Game.notify(Text.f("gear.tools.heldBy", [shown, holder.display_name]), "", player)
	elif item["standing"]:
		Game.notify(Text.f("gear.tools.standing", [shown]), "", player)
	else:
		if player.health <= 0.0:
			return
		item["tool"] = _create_tool(item)
		Sounds.once(item["clip"], Config.Tools.Sounds.Clunk)
		item["prop"]["node"].visible = false
		item["line"].action = Text.m("gear.tools.back")
		_give(player, item)
		if item["name"] in TIPS:
			Game.notify(Text.m("gear.tools.tips." + item["name"]), "", player)



func activate(player: Player) -> void :
	var item: Variant = _in_hand.get(player)
	if item == null:
		return
	match item["behaviour"].get("use", ""):
		"stand":
			_set_down(item, player)
		"swing":
			_swing(item, player)
		"extinguisher":
			_start_extinguisher(item, player)
		"chainsaw":
			_start_chainsaw(item, player)
		"hydraulic":
			_start_hydraulic(item, player)



func deactivate(player: Player) -> void :
	var item: Variant = _in_hand.get(player)
	if item != null:
		_stop_using(item)


func _process(_delta: float) -> void :
	if Net.is_host():

		for holder: Variant in _in_hand.keys():
			if not is_instance_valid(holder):
				_in_hand.erase(holder)
			elif _hands_taken(holder):
				put_away(holder)
	else:
		_show_powder()

	var player: = Game.local_player
	if player == null:
		return
	var free: = player.camera != null and player.camera.captured and not Game.ui_open and player.seat == null and player.health > 0.0
	if _in_hand.has(player):
		if free and Input.is_action_just_pressed("fire"):
			_pulled = true
			_face(player)
			if _in_hand[player]["behaviour"].get("use", "") == "stand":
				player.set_down_ahead()
			Net.request("tool.trigger", [true])
		elif (_pulled or (Net.is_host() and trigger_held(player))) and not (free and Input.is_action_pressed("fire")):
			_pulled = false
			Net.request("tool.trigger", [false])

		if trigger_held(player):
			_face(player)
	else:
		_pulled = false
	if free:
		var list: = slots(player)
		for index in mini(list.size(), MenuKit.KEYS.size()):
			if Input.is_action_just_pressed(MenuKit.KEYS[index]):
				Net.request("tool.slot", [index, String(list[index]["name"])])
				break


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	var now: = Game.now()
	_tick += delta
	var ticked: = _tick >= TICK
	var dt: = _tick
	if ticked:
		_tick = 0.0
	for item: Dictionary in items:
		if item["refill_at"] > 0.0 and now >= item["refill_at"]:
			item["refill_at"] = -1.0
			if item["tool"] == null:
				item["charge"] = float(Config.Tools.Extinguisher.Charge)
		if item["standing"] and item["name"] == "Fan":
			item["since_fan"] += delta
			if item["since_fan"] >= 0.25:
				_tick_fan(item, item["since_fan"])
				item["since_fan"] = 0.0
		if not ticked or not item["using"]:
			continue
		var holder: Player = item["holder"]
		if holder == null or not is_instance_valid(holder) or holder.health <= 0.0:
			_stop_using(item)
			continue
		match item["behaviour"].get("use", ""):
			"extinguisher":
				_tick_extinguisher(item, holder, dt)
			"chainsaw":
				_tick_chainsaw(item, holder, dt)
			"hydraulic":
				_tick_hydraulic(item, holder, dt)






func _on_trigger(player: Player, on: bool) -> void :
	if not on:
		deactivate(player)
	elif player.seat == null and player.health > 0.0 and not _hands_taken(player):
		activate(player)



func _on_slot(player: Player, index: int, wanted: String) -> void :
	if player.seat != null or player.health <= 0.0:
		return
	var list: = slots(player)
	if index >= 0 and index < list.size() and list[index]["name"] == wanted:

		var hoses: = HoseService.current
		var line: Variant = hoses.line_of(player) if hoses != null else null
		if line != null and not is_same(list[index], line.get("entry")):
			hoses._put_down(line, player)
			if hoses.line_of(player) != null:
				return
		toggle_slot(player, list[index])



func _on_left(player: Player) -> void :
	if Net.is_host():

		var had: Array = carried(player).duplicate()
		_carried.erase(player)
		_in_hand.erase(player)
		for item: Dictionary in had:
			item["holder"] = null
			_put_back(item)
		_others.erase(player)
		_watched.erase(player)
	else:

		for item: Dictionary in items:
			if item["holder"] == player:
				_shelve(item)
		_belts.erase(player)
	_carried.erase(player)
	_in_hand.erase(player)



func _on_net_started() -> void :
	if not Net.is_client():
		return
	_was_client = true
	_told = false
	_forget()


func _on_net_stopped() -> void :
	if _was_client:
		_was_client = false
		_forget()



func _forget() -> void :
	for item: Dictionary in items:
		_shelve(item)
		item["line"].holder = null
		item["line"].action = Text.m("gear.tools.take")
		item["charge"] = float(Config.Tools.Extinguisher.Charge)
		item["refill_at"] = -1.0
	_carried.clear()
	_in_hand.clear()
	_belts.clear()
	_pulled = false
	var me: = Game.local_player
	if me != null and is_instance_valid(me):
		if me.get_attr("Tool") != null and BEHAVIOURS.has(me.get_attr("Tool")):
			me.set_attr("Tool", null)
			me.set_attr("ToolForces", null)
			if me.holding == "tool":
				me.holding = ""
		carried_changed.emit(me)





func _state() -> Variant:
	var said: Array = []
	for item: Dictionary in items:
		var tool: HandTool = item["tool"]
		if tool == null or not is_instance_valid(tool):
			said.append(0)
			continue
		var holder: Player = item["holder"]
		var peer: = Net.peer_of(holder) if (holder != null and is_instance_valid(holder)) else 0
		var in_hand: bool = peer != 0 and _in_hand.get(holder) != null and is_same(_in_hand[holder], item)
		said.append([
			2 if item["standing"] else 1, peer, in_hand, tool.global_transform if item["standing"] else Transform3D.IDENTITY, 
			item["using"], int(tool.get_attr("Working", 0)), snappedf(float(tool.get_attr("Progress", 0.0)), 0.01), int(tool.get_attr("Swing", 0)), 
		])
	var belts: = {}
	for peer: int in Net.players:
		var player: Player = Net.players[peer]
		if not is_instance_valid(player):
			continue
		var plates: Array = []
		for slot: Dictionary in slots(player):
			plates.append([slot["name"], slot_in_hand(player, slot), int(slot["index"]) if slot.has("index") else -1])
		if not plates.is_empty():
			belts[peer] = plates
	return [said, belts]



func _apply_state(state: Variant) -> void :
	var quiet: = not _told
	_told = true
	_carried.clear()
	_in_hand.clear()
	var said: Array = state[0]
	for index in mini(said.size(), items.size()):
		_apply_item(items[index], said[index], quiet)
	var before: = _belts
	_belts = {}
	for peer: int in state[1]:
		var player: = Net.player_of(peer)
		if player == null or not is_instance_valid(player):
			continue
		var plates: Array = []
		var tools: Array = []
		for plate: Array in state[1][peer]:
			plates.append({"name": plate[0], "held": plate[1], "index": int(plate[2])})
			if int(plate[2]) >= 0 and int(plate[2]) < items.size():
				tools.append(items[int(plate[2])])
		_belts[player] = plates
		_carried[player] = tools
	for player: Variant in before.keys() + _belts.keys():
		if is_instance_valid(player) and hash(before.get(player, [])) != hash(_belts.get(player, [])):
			carried_changed.emit(player)


func _apply_item(item: Dictionary, said: Variant, quiet: bool) -> void :
	if not (said is Array):
		if item["tool"] != null or not item["prop"]["node"].visible:
			_shelve(item)
			if not quiet:
				Sounds.once(item["clip"], Config.Tools.Sounds.Clunk)
		return
	var tool: HandTool = item["tool"] if (item["tool"] != null and is_instance_valid(item["tool"])) else null
	if tool == null:
		item["standing"] = false
		item["pick_up"] = null
		tool = _create_tool(item)
		tool.attributes["Swing"] = int(said[7])
		tool.visible = false
		item["tool"] = tool
		if not quiet:
			Sounds.once(item["clip"], Config.Tools.Sounds.Clunk)
	item["prop"]["node"].visible = false
	var holder: Player = Net.player_of(int(said[1])) if int(said[1]) != 0 else null
	if holder != null and not is_instance_valid(holder):
		holder = null
	var in_hand: = false
	if int(said[0]) == 2:
		var place: Transform3D = said[3]
		if not item["standing"]:
			_stand(item, place)
			if not quiet:
				Sounds.once(tool, Config.Tools.Sounds.Clunk)
		elif not tool.global_transform.is_equal_approx(place):
			tool.global_transform = place
		item["standing"] = true
	else:
		if item["standing"]:
			_lift(item)
			item["standing"] = false
		in_hand = said[2] == true and holder != null
		if in_hand:
			if tool.get_parent() != holder.rig.hand_right or not tool.visible:
				_hold(holder, item)
			_in_hand[holder] = item
		else:
			tool.visible = false
	item["holder"] = holder
	tool.holder = holder if in_hand else null
	item["using"] = in_hand and said[4] == true
	_show_work(item, in_hand, int(said[5]), float(said[6]), int(said[7]))



func _show_work(item: Dictionary, in_hand: bool, level: int, done: float, swings: int) -> void :
	var tool: HandTool = item["tool"]
	var using: bool = item["using"]
	if done > 0.0:
		tool.set_attr("Progress", done)
	tool.set_attr("Working", level if (level > 0 and in_hand) else null)
	if swings != int(tool.get_attr("Swing", 0)):
		tool.set_attr("Swing", swings)
		Sounds.once(tool, Config.Tools.Sounds.Swing, 0.8, 10.0, 140.0)
	match item["behaviour"].get("use", ""):
		"extinguisher":
			if using:
				_fit_powder(tool)
				_aim_powder(tool, item["holder"])
			tool.emit("Cloud", using)
			tool.play("Extinguisher", using)
		"chainsaw":
			tool.play("ChainsawIdle", in_hand and not using)
			tool.play("ChainsawCut", using, 0.82 if level > 1 else 1.0)
			tool.emit("Chips", using and level > 1)
			if in_hand:
				var fumes: RbxEmitter = tool.emitters["Fumes"]
				var rate: = 16.0 if using else 5.0
				if not fumes.emitting or not is_equal_approx(fumes._rate, rate):
					fumes.set_rate(rate)
			else:
				tool.emit("Fumes", false)
		"hydraulic":
			tool.play("Hydraulic", using, 0.85 if level > 1 else 1.1)
			tool.emit("Sparks", using and level > 1)



func _show_powder() -> void :
	for item: Dictionary in items:
		if item["using"] and item["tool"] != null and is_instance_valid(item["tool"]) and item["tool"].points.has("Powder"):
			var holder: Variant = item["holder"]
			if holder != null and is_instance_valid(holder):
				_aim_powder(item["tool"], holder)



func _shelve(item: Dictionary) -> void :
	if item["tool"] != null and is_instance_valid(item["tool"]):
		if item["tool"].get_parent() != null:
			item["tool"].get_parent().remove_child(item["tool"])
		item["tool"].queue_free()
	item["tool"] = null
	item["holder"] = null
	item["standing"] = false
	item["using"] = false
	item["pick_up"] = null
	item["prop"]["node"].visible = true
