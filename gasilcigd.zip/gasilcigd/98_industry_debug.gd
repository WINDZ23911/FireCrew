extends RefCounted



static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--industry=") or arg.begins_with("--industry-look="):
			var debug: = IndustryDebug.new()
			debug.name = "IndustryDebug"
			main.add_child(debug)
			return
