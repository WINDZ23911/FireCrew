class_name CrewPlay
extends Node























const KEYS: = {"interact": "E", "item": "F", "coupling": "T", "mast": "J"}

var _what: = ""
var _shots: = ""
var _side: = "host"
var _solo: = false
var _host_quit: = ""
var _quit: = ""
var _options: Array = []
var _marks: Dictionary = {}
var _pictures: Array = []
var _taken: Dictionary = {}
var _facts: Dictionary = {}
var _camera: Camera3D
var _was_crew: = false
var _third: = false
var _faults: Array[String] = []
var _checks: = 0
var _part_done: = false
var _verdict_said: = false
var _alone_now: = false
var _alone_started: = false
var _left_myself: = false


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		var bits: = arg.split("=", true, 1)
		var value: = bits[1] if bits.size() > 1 else ""
		match bits[0]:
			"--play":
				_what = value
			"--play-shots":
				_shots = value
			"--play-solo":
				_solo = true
			"--play-host-quit":
				_host_quit = value
			"--play-quit":
				_quit = value
			"--play-as":
				_side = value
			"--play-opt":
				_options = Array(value.split(","))
	var joining: = false
	for arg in OS.get_cmdline_user_args():
		joining = joining or arg.begins_with("--join=")
	if joining and _side == "host":
		_side = "client"
	_third = _side == "client2"
	Game.local_player.display_name = {"host": "Hana", "client": "Cene", "client2": "Tine"}.get(_side, _side)
	Net.share("play.debug", func() -> Variant: return [_marks, _pictures, _facts], func(state: Variant) -> void :
		for moment: String in state[0]:
			if not _marks.has(moment):
				_marks[moment] = state[0][moment]
		_pictures = state[1]
		_facts = state[2]
	, 10.0)
	Net.handle("play.mark", func(_player: Player, moment: String) -> void :
		if not _marks.has(moment):
			_marks[moment] = Game.now()
			print("play [host] moment '%s' at %.1f" % [moment, Game.now()])
			if moment == "done":

				get_tree().create_timer(5.0).timeout.connect(Game.quit)
	)
	Net.handle("play.shot", func(_player: Player, moment: String, at: Vector3, view: Vector3) -> void :
		_pictures.append([moment, Game.now() + 0.9, at, view])
	)
	Game.notified.connect( func(text: Variant, kind: String, who: Player) -> void :
		if who == null or who == Game.local_player:
			print("play [%s] told%s: %s" % [_side, "" if kind.is_empty() else " (" + kind + ")", Text.say(text, "en")])
	)

	var last: = [{}]
	Game.incident_changed.connect( func() -> void :
		if Game.incident.is_empty() and not last[0].is_empty():
			var card: Array = []
			for key: String in ["kind", "done", "total", "victims", "victims_out", "victims_lost", "flames", "flames_out", "failed"]:
				if last[0].has(key):
					card.append("%s %s" % [key, str(last[0][key]) if not last[0][key] is float else str(int(last[0][key]))])
			if last[0].has("health"):
				card.append("health %d" % int(round(float(last[0]["health"]))))
			print("play [%s] the call's card closed on: %s" % [_side, ", ".join(card)])
		last[0] = Game.incident.duplicate()
	)
	Game.local_player.rewarded.connect( func(amount: int, why: String) -> void :
		print("play [%s] rewarded %d %s" % [_side, amount, why])
	)
	Net.stopped.connect( func() -> void :
		print("play [%s] the crew is no more: this is a game alone now" % _side)
		if joining and is_inside_tree() and not get_tree().current_scene.is_queued_for_deletion():

			( func() -> void : print("play alone [%s] at once: %s" % [_side, _alone()])).call_deferred()

			if not _left_myself:
				_alone_now = true
				_alone_after.call_deferred()
	)
	if CallService.current and not joining:
		CallService.current.hold = not _solo

		if Alarm.forced == 0:
			Alarm.forced = 1


		if not _opt("embers"):
			Config.Alarm["EmberChance"] = [0.0, 0.0, 0.0]
	var part: = ("_host_" if not joining else ("_third_" if (_third and has_method("_third_" + _what)) else "_client_")) + _what
	if has_method(part):
		_run_part.call_deferred(part)
	else:
		_fault("no part '%s'" % part)
		_verdict()


func _run_part(part: String) -> void :
	await call(part)
	_part_done = true
	_verdict()






func _fault(why: String) -> void :
	print("play [%s] %s" % [_side, why])
	if not _alone_now:
		_faults.append(why)



func _check(ok: bool, what: String) -> bool:
	_checks += 1
	print("play [%s] %s: %s" % [_side, "check ok" if ok else "CHECK FAILED", what])
	if not ok:
		_faults.append(what)
	return ok


func _verdict() -> void :
	if _verdict_said:
		return
	_verdict_said = true
	if not _part_done:
		_faults.append("the part ended before it was done")
	if _faults.is_empty():
		print("PROOF PASS play-%s %s (%d checks)" % [_what, _side, _checks])
	else:
		print("PROOF FAIL play-%s %s: %s" % [_what, _side, "; ".join(_faults)])


func _exit_tree() -> void :
	_verdict()





func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false).timeout


func _wait_until(test: Callable, limit: = 30.0, what: = "") -> bool:
	var waited: = 0.0
	while not test.call():
		await get_tree().create_timer(0.1, false).timeout
		waited += 0.1
		if waited > limit:
			if not what.is_empty():
				_fault("WAITED IN VAIN (%.0f s) for %s" % [limit, what])
			return false
	return true



func _mark(moment: String) -> void :
	print("play [%s] says '%s'" % [_side, moment])
	Net.request("play.mark", [moment])



func _moment(moment: String, limit: = 90.0) -> bool:
	var came: = await _wait_until( func() -> bool: return _marks.has(moment), limit, "the moment '%s'" % moment)
	if came and moment == _quit and Net.is_client():
		print("play [%s] leaves the game at '%s'" % [_side, moment])
		await _wait(0.3)
		_left_myself = true
		Net.leave()
	return came



func _crew(count: = 2) -> void :
	await _wait_until( func() -> bool: return Net.players.size() >= count and (Net.is_host() or HostClock.synced), 120.0, "a crew of %d" % count)
	_was_crew = true
	await _wait(1.0)




func _shot(moment: String, at: Vector3, view: = Vector3(26, 12, 30)) -> void :
	Net.request("play.shot", [moment, at, view])
	await _wait(1.6)


func _process(_delta: float) -> void :
	if not _host_quit.is_empty() and Net.is_host() and Net.active() and _marks.has(_host_quit):
		_host_quit = ""
		print("play [host] leaves the game")
		_leave_as_host.call_deferred()
	var now: = HostClock.now()
	for picture: Array in _pictures:
		var moment: String = picture[0]
		if _taken.has(moment):
			continue
		if now > picture[1] + 2.0:
			_taken[moment] = true
		elif now >= picture[1] - 0.6 and not _taken.has(moment + "/view"):
			_taken[moment + "/view"] = true
			_look(picture[2], picture[3])
		elif now >= picture[1]:
			_taken[moment] = true
			if not _shots.is_empty():
				get_viewport().get_texture().get_image().save_png("%s_%s_%s.png" % [_shots, moment, _side])
			print("play state [%s] %s: %s" % [_side, moment, _state()])


func _leave_as_host() -> void :
	await _wait(0.2)
	_part_done = true
	_verdict()
	Game.quit()


func _look(at: Vector3, view: Vector3) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 6000.0
		_camera.near = 0.3
		_camera.fov = 60.0
		add_child(_camera)
	var bearing: = deg_to_rad(view.z)
	_camera.look_at_from_position(at + Vector3(sin(bearing) * view.x, view.y, cos(bearing) * view.x), at + Vector3(0, 1.5, 0))
	_camera.make_current()


func _opt(option: String) -> bool:
	return option in _options





func _me() -> Player:
	return Game.local_player


func _host_player() -> Player:
	return Net.players.get(1)



func _walk(to: Vector3, hop: = 4.0, pause: = 0.1) -> void :
	var me: = _me()
	var from: = me.global_position
	var hops: = maxi(1, int(ceil(from.distance_to(to) / hop)))
	for index in range(1, hops + 1):
		me.teleport(from.lerp(to, float(index) / hops))
		await _wait(pause)



func _ground(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(Vector3(at.x, at.y + 6.0, at.z), Vector3(at.x, at.y - 60.0, at.z), World.LAYER_SOLID)
	return (hit["position"] if not hit.is_empty() else at) + Vector3(0, 0.3, 0)



func _stand_by(point: Vector3, off: Vector3, walk: = false) -> void :
	var to: = _ground(point + off)
	if walk:
		await _walk(to)
	else:
		_me().teleport(to)
	_face(point)



func _face(point: Vector3) -> void :
	var me: = _me()
	var toward: = point - me.head_position()
	if toward.length() < 0.05:
		return
	me.camera.yaw = atan2( - toward.x, - toward.z)
	me.camera.pitch = asin(clampf(toward.normalized().y, -1, 1))
	me.rig.rotation.y = me.camera.yaw






func _search_for(house: Building, victim: Victim) -> void :
	if house is House and (house as House).rooms.has(victim.room):
		var room: Dictionary = (house as House).rooms[victim.room]
		var low: Vector3 = room["low"]
		var high: Vector3 = room["high"]
		var middle: Vector3 = (house as House).lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0)
		var hit: = Game.world.raycast(middle, middle - Vector3(0, 30, 0), World.LAYER_SOLID)
		await _walk((hit["position"] if not hit.is_empty() else middle) + Vector3(0, 0.3, 0))
	if not victim.found:
		await _walk(victim.position() + Vector3(2.2, -1.0, 0.4))
	var found: = await _wait_until( func() -> bool: return victim.found and int(Game.incident.get("victims", 0)) >= 1, 5.0, "the person found and on the card")
	_check(found, "searched: found in the %s, and on the card" % victim.room)


func _use(prompt: Variant, what: = "") -> bool:
	var me: = _me()
	if prompt == null or not is_instance_valid(prompt):
		_fault("NO PROMPT for %s" % [what])
		return false
	var offered: = false
	for tick in 25:
		_face(prompt.global_position)
		await get_tree().process_frame
		await get_tree().process_frame
		if me.prompts.get(prompt.key) == prompt:
			offered = true
			break
		await _wait(0.1)
	if not offered:
		var instead: Prompt = me.prompts.get(prompt.key)
		_fault("NOT OFFERED: %s ('%s %s' id %s, enabled %s, shown %s, %.1f studs off, reach %.1f); under %s instead: %s" % [
			what, Text.say(prompt.action, "en"), Text.say(prompt.object, "en"), prompt.net_id, prompt.enabled, prompt.shown_to(me), 
			prompt.global_position.distance_to(me.root_position()), prompt.reach, KEYS.get(prompt.key, prompt.key), 
			("'%s %s'" % [Text.say(instead.action, "en"), Text.say(instead.object, "en")]) if instead != null else "nothing", 
		])
		return false
	var hold: float = prompt.hold
	var key: String = prompt.key
	print("play [%s] %s: '%s %s' under %s%s" % [_side, what, Text.say(prompt.action, "en"), Text.say(prompt.object, "en"), KEYS.get(prompt.key, prompt.key), (", held %.1f s" % hold) if hold > 0.0 else ""])
	Input.action_press(key)
	if hold > 0.0:
		await _wait(hold + 0.3)
	else:
		await get_tree().process_frame
		await get_tree().process_frame
	Input.action_release(key)
	await _wait(0.35)
	return true




func _press(action: String) -> void :
	await get_tree().process_frame
	Input.action_press(action)



func _tap(action: String) -> void :
	await get_tree().process_frame
	Input.action_press(action)
	await get_tree().process_frame
	await get_tree().process_frame
	Input.action_release(action)
	await get_tree().process_frame



func _pull(seconds: float) -> void :
	await get_tree().process_frame
	Input.action_press("fire")
	await _wait(seconds)
	Input.action_release("fire")
	await _wait(0.2)



func _line(object_name: String, vehicle: Vehicle = null) -> Array:

	if object_name == "Breathing sets" and AirService.current != null:
		var air: = AirService.current
		var me: = _me()
		var source: String = "truck"
		var slot: = air.fullest_free("truck")
		if me.get_attr("Scba", false) == true:
			for place: String in air.holders:
				for index in (air.holders[place] as Array).size():
					if air.holder_of(place, index) == me:
						source = place
						slot = index
		var line: = air.line_of_set(source, slot)
		var kept_in: = air.source_vehicle(source)
		return [Lockers.of(kept_in), line] if line != null and kept_in != null and (vehicle == null or vehicle == kept_in) else []
	for one in Vehicle.all:
		if vehicle != null and one != vehicle:
			continue
		var lockers: = Lockers.of(one)
		if lockers == null:
			continue
		for line in lockers.lines:
			if Text.say(line.object, "en").begins_with(object_name):
				return [lockers, line]
	return []




func _locker(object_name: String, vehicle: Vehicle = null) -> bool:
	var found: = _line(object_name, vehicle)
	if found.is_empty():
		_fault("NO LINE for '%s' in any locker" % [object_name])
		return false
	var lockers: Lockers = found[0]
	var me: = _me()
	var menu: LockerMenu = Hud.current.widgets["locker"]

	var handle: Dictionary = lockers.handles[0]
	for other: Dictionary in lockers.handles:
		if other["node"].global_position.distance_to(me.global_position) < handle["node"].global_position.distance_to(me.global_position):
			handle = other
	var node: Node3D = handle["node"]
	var out: = node.global_position - lockers.vehicle.global_position
	out = Vector3(out.x, 0, out.z).normalized()
	me.teleport(_ground(node.global_position + out * 5.0))
	await _wait(0.5)
	for attempt in 3:
		if menu.is_open():
			break
		if not await _use(handle["prompt"], "the lockers of the %s" % lockers.vehicle.name):
			return false
		await _wait_until( func() -> bool: return menu.is_open() or lockers.is_open(handle), 2.0)
		await _wait(0.4)
	if not menu.is_open():
		_fault("THE LOCKER MENU did not come up")
		return false
	print("play [%s] chooses '%s %s' from the menu" % [_side, Text.say(found[1].action, "en"), Text.say(found[1].object, "en")])
	menu._choose(found[1])
	await _wait(0.9)
	return true



func _slot(named: String) -> bool:
	var list: = ToolService.current.slots(_me())
	for index in list.size():
		if list[index]["name"] == named:
			await _tap(MenuKit.KEYS[index])
			await _wait(0.5)
			return true
	_fault("NO PLATE for '%s' on the hotbar: %s" % [named, _plates(_me())])
	return false


func _plates(player: Player) -> Array:
	var plates: Array = []
	if ToolService.current:
		for slot: Dictionary in ToolService.current.slots(player):
			plates.append("%s%s" % [slot["name"], "*" if ToolService.current.slot_in_hand(player, slot) else ""])
	return plates





func _v(at: Vector3) -> String:
	return "%.0f,%.0f,%.0f" % [at.x, at.y, at.z]


func _state() -> String:
	var said: Array = []
	var incident: = Game.incident
	if incident.is_empty():
		said.append("no call")
	else:
		var card: Array = []
		for key: String in ["done", "total", "victims", "victims_out", "victims_lost", "flames", "flames_out"]:
			if incident.has(key):
				card.append("%s %s" % [key, str(int(incident[key]))])
		if incident.has("health"):
			card.append("health %d" % int(round(float(incident["health"]))))
		said.append("call %s [%s]" % [incident.get("kind", "fire"), ", ".join(card)])
	var crew: Array = []
	for player in Game.players:
		if not is_instance_valid(player):
			continue
		var has: Array = []
		for key: String in ["Tool", "Carrying", "Scba", "Mask"]:
			var value: Variant = player.get_attr(key)
			if value != null and not (value is bool and value == false):
				has.append("%s=%s" % [key, str(value)])
		if player.get_attr("Line") != null:
			has.append("line")
		if player.get_attr("Supply") != null:
			has.append("supply")
		var vehicle: Variant = player.get_attr("Vehicle")
		if vehicle is Vehicle:
			has.append("in %s seat %s" % [vehicle.name, str(player.get_attr("Seat"))])
		var in_hand: Array = []
		for child in player.rig.hand_right.get_children():
			if child is Node3D and child.visible and not (child is Prompt):
				in_hand.append(String(child.name) if not String(child.name).begins_with("@") else "Nozzle")
		crew.append("%s at %s hands '%s' %s in hand %s belt %s cash %d saved %d hp %d" % [
			player.display_name, _v(player.global_position.snappedf(2.0)), player.holding, has, in_hand, _plates(player), int(player.get_attr("Cash", 0)), int(player.get_attr("Saved", 0)), int(player.health), 
		])
	crew.sort()
	said.append("crew %s" % [crew])

	var hot: = 0
	for flame in Flame.all:
		hot += 1
	said.append("flames %d embers %d markers %d" % [hot, Ember.all.size(), CallMarker.all.size()])

	var people: = VictimService.current
	if people != null:
		var list: Array = []
		for victim: Victim in people.victims:
			if is_instance_valid(victim.figure):
				list.append("%s%s %d%%" % [victim.state, (" by " + victim.carrier.display_name) if (victim.carrier != null and is_instance_valid(victim.carrier)) else "", ceili(victim.condition)])
		var ambulance: = AmbulanceService.current
		var zone: Variant = ambulance.zone_position() if ambulance else null
		said.append("victims %s ambulance %s%s" % [list, ("box at " + _v(zone)) if zone != null else "none", " arrived" if (ambulance and ambulance.arrived()) else ""])

	var hoses: = HoseService.current
	if hoses != null:
		var held: Array = []
		for index in hoses.lines.size():
			var line: Dictionary = hoses.lines[index]
			if line["player"] != null and is_instance_valid(line["player"]):
				held.append("%d:%s%s" % [index, line["player"].display_name, " spraying" if hoses._shown_spraying(line, line["player"]) else ""])
			elif line["feeding"]:
				held.append("%d:feeds" % index)
		var supplies: Array = []
		for rig: Dictionary in hoses.rigs:
			if rig["supply"]["state"] != "stowed":
				supplies.append("%s %s%s" % [rig["vehicle"].name, rig["supply"]["state"], (" by " + rig["supply"]["player"].display_name) if (rig["supply"]["player"] != null and is_instance_valid(rig["supply"]["player"])) else ""])
		said.append("lines %s supply %s divider %s" % [held, supplies, hoses.divider["state"]])

	var tools: = ToolService.current
	if tools != null:
		var out: Array = []
		for item: Dictionary in tools.items:
			if item["tool"] != null and is_instance_valid(item["tool"]):
				var holder: Variant = item["holder"]
				out.append("%s %s%s" % [item["name"], "standing" if item["standing"] else ("with " + (holder.display_name if (holder != null and is_instance_valid(holder)) else "nobody")), " at work" if item["using"] else ""])
		said.append("tools out %s" % [out])
	var cordon: = Cordon.current
	if cordon != null:
		var carried: Array = []
		for item: Dictionary in cordon.items:
			if item["holder"] != null and is_instance_valid(item["holder"]):
				carried.append("%s with %s" % [item["name"], item["holder"].display_name])
		said.append("cones %d tapes %d %s" % [cordon.cordon["cones"].size(), cordon.cordon["tapes"].size(), carried])
	var more: = "_state_" + _what
	if has_method(more):
		said.append(call(more))
	var trucks: Array = []
	for vehicle in Vehicle.all:
		if vehicle.global_position.distance_to(vehicle.spec["spawn"].origin) > 6.0 or vehicle.driver() != null:
			trucks.append("%s at %s %d L%s" % [vehicle.name, _v(vehicle.global_position.snappedf(2.0)), int(vehicle.water), (" driven by " + vehicle.driver().display_name) if vehicle.driver() != null else ""])
	said.append("vehicles out %s" % [trucks])
	return " | ".join(said)





func _truck() -> Vehicle:
	return Vehicle.named("Fire Truck")



func _building_of_call() -> Building:
	var at: Variant = Game.incident.get("pos")
	var best: Building = null
	if at is Vector3:
		for building in FireService.current.buildings:
			if best == null or building.position.distance_to(at) < best.position.distance_to(at):
				best = building
	return best




func _park(vehicle: Vehicle, near: Vector3, along_by: = 0.0, facing: = 1.0) -> Vector3:
	var layout: Dictionary = NavGraph.current.layout
	var found: = Roads.nearest(layout, near.x, near.z)
	var way: = Roads.at(found[1], found[0]["along"])
	var along: = Vector3(way[2], 0, way[3]) * facing
	var middle: = Vector3(found[0]["x"], 0, found[0]["z"]) + along * along_by
	var toward: = Vector3(near.x, 0, near.z) - Vector3(found[0]["x"], 0, found[0]["z"])
	var kerb: = toward.normalized() * maxf(float(found[1]["width"]) / 2.0 - 5.5, 0.0) if toward.length() > 0.5 else Vector3.ZERO
	var at: = CallKit.ground_at(middle + kerb)
	vehicle.global_transform = Transform3D(Basis.looking_at(along), at + Vector3(0, 3.0, 0))
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.angular_velocity = Vector3.ZERO
	vehicle.reset_physics_interpolation()
	return at



func _beside(vehicle: Vehicle, toward: Vector3, out: = 9.0, along: = 0.0) -> Vector3:
	var side: = signf((vehicle.global_transform.affine_inverse() * toward).x)
	if side == 0.0:
		side = 1.0
	return _ground(vehicle.global_transform * Vector3(side * out, 0, along))





func _house_of_call() -> House:
	return _building_of_call() as House


func _state_medical() -> String:
	var house: = _house_of_call()
	if house == null:
		return "house none"
	var doors: Array = []
	for door_name: String in house.doors:
		var door: Dictionary = house.doors[door_name]
		if door["open"] or door["locked"]:
			doors.append("%s%s%s" % [door_name, " open" if door["open"] else "", " locked" if door["locked"] else ""])
	doors.sort()
	return "house %s doors %s" % [house.name, doors]


func _host_medical() -> void :
	var calls: = CallService.current
	calls.forced = "medical"
	if not _solo:
		await _crew()
		calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "medical", 40.0, "the medical call")
	var house: = LockedIn.current.house
	LockedIn.current.scene["has_key"] = false
	var door: Dictionary = house.outside_door()
	var truck: = _truck()
	_park(truck, door["lock"].global_position)
	print("play [host] call at %s; the pumper is parked at %s" % [house.name, _v(truck.global_position)])
	_me().teleport(_beside(truck, house.position, 10.0, -6.0))
	if _solo:
		await _crew()
	_mark("parked")
	await _shot("start", door["lock"].global_position, Vector3(34, 16, _bearing(house.position, door["lock"].global_position)))

	var lockers: = Lockers.of(truck)
	var handle: Dictionary = lockers.handles[0]
	for other: Dictionary in lockers.handles:
		if other["node"].global_position.distance_to(house.position) < handle["node"].global_position.distance_to(house.position):
			handle = other
	_me().teleport(_ground(handle["node"].global_position + (handle["node"].global_position - truck.global_position).normalized() * 5.0))
	await _wait(0.5)
	if not lockers.is_open(handle):
		await _use(handle["prompt"], "the shutters")
	_mark("shutters")
	await _moment("forced", 60.0)
	await _shot("forced", door["lock"].global_position, Vector3(16, 7, _bearing(house.position, door["lock"].global_position)))
	await _moment("carrying", 40.0)
	var people: = VictimService.current
	var zone: Variant = AmbulanceService.current.zone_position()
	await _shot("carrying", zone if zone != null else house.position, Vector3(30, 14, _bearing(house.position, door["lock"].global_position)))
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 60.0, "the call to close")
	await _wait(1.5)
	await _shot("closed", zone if zone != null else house.position, Vector3(30, 14, _bearing(house.position, door["lock"].global_position)))
	print("play [host] over: %d still waiting" % people.victims.size())
	await _wait(14.0)
	await _shot("after", zone if zone != null else house.position, Vector3(30, 14, _bearing(house.position, door["lock"].global_position)))
	_mark("done")



func _bearing(from: Vector3, at: Vector3) -> float:
	var out: = Vector3(at.x - from.x, 0, at.z - from.z)
	return rad_to_deg(atan2(out.x, out.z)) + 25.0


func _client_medical() -> void :
	var me: = _me()
	await _crew()
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "medical", 60.0, "the medical call")
	await _moment("parked")
	var house: = _house_of_call()
	var door: Dictionary = house.outside_door()
	var people: = VictimService.current
	print("play [client] the call is at %s; its sign hangs here: %s; %d inside; the door is locked here: %s" % [house.name, CallMarker.all.size(), people.victims.size(), door["locked"]])
	var outside: = _outside(house, door, 4.0)

	var scene: Dictionary = LockedIn.current._shown
	if _check( not scene.is_empty(), "the neighbour stands by the door here"):

		var by: Vector3 = (scene["neighbour_prompt"] as Node3D).global_position
		for tries in 3:
			_me().teleport(by + Vector3(0.9, 0.5, 0.9).rotated(Vector3.UP, tries * 2.1))
			_face(by)
			await _wait(0.6)

			if _me().root_position().distance_to(by) < 7.0:
				break
		await _use(scene["neighbour_prompt"], "asking the neighbour for a key")
		await _wait(0.8)
		print("play [client] the neighbour had no key: the door is still locked here %s" % door["locked"])

	me.teleport(outside)
	await _wait(0.6)
	await _use(door["prompt"], "the locked door, with empty hands")
	await _wait(0.8)
	print("play [client] with empty hands the door is still locked: %s, and shut: %s" % [door["locked"], not door["open"]])

	await _moment("shutters", 20.0)
	me.teleport(_beside(_truck(), house.position, 10.0))
	await _locker("Axe")
	print("play [client] in hand: Tool %s, forces %s, belt %s" % [me.get_attr("Tool"), me.get_attr("ToolForces"), _plates(me)])
	await _walk(outside)
	await _wait(0.5)

	_face(door["prompt"].global_position)
	await _wait(0.3)
	await _tap("interact")
	await _wait(0.6)
	print("play [client] after a tap with the axe the door is locked: %s (hold wanted %.1f s)" % [door["locked"], door["prompt"].hold])
	await _use(door["prompt"], "forcing the door")
	await _wait_until( func() -> bool: return door["open"], 4.0, "the door to give")
	print("play [client] forced: locked %s, open %s" % [door["locked"], door["open"]])
	_mark("forced")
	await _wait(2.5)

	if people.victims.is_empty():
		_fault("NOBODY inside here")
		return
	var victim: Victim = people.victims[0]
	await _first_aid(victim, scene, outside)
	await _slot("Axe")
	await _search_for(house, victim)
	await _walk(victim.position() + Vector3(1.6, -1.0, 0))
	await _wait(0.5)
	await _use(victim.prompt, "lifting the casualty")
	await _wait_until( func() -> bool: return people.carried_by(me) != null, 4.0, "the casualty on the shoulders")
	print("play [client] carrying: %s; hands '%s', walking at %.0f" % [people.carried_by(me) != null, me.holding, me.walk_speed])
	await _walk(outside)
	_mark("carrying")
	await _wait(3.0)
	if not Net.active():
		await _alone_after()
		return
	var zone: Variant = AmbulanceService.current.zone_position()
	if zone == null:
		_fault("NO GREEN BOX here")
		return
	await _walk(zone + Vector3(0, 0.5, 0))
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 30.0, "the call to close")
	await _wait(1.0)
	print("play [client] over: cash %d, saved %d, hands '%s', carrying %s" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), me.holding, me.get_attr("Carrying")])

	me.teleport(_beside(_truck(), house.position, 10.0))
	await _locker("Axe")
	print("play [client] the axe is back: Tool %s, belt %s" % [me.get_attr("Tool"), _plates(me)])
	await _moment("done", 40.0)
	await _wait(1.0)
	Game.quit()




func _first_aid(victim: Victim, scene: Dictionary, outside: Vector3) -> void :
	var me: = _me()
	await _walk(outside)
	me.teleport(_beside(_truck(), outside, 10.0))
	await _locker("First aid kit", _truck())
	_check(CallGear.has(me, "First aid kit"), "the first aid kit from the pumper")
	await _walk(outside)
	await _walk(victim.position() + Vector3(1.6, -1.0, 0))
	await _wait(0.5)
	_check( not victim.prompt.enabled, "nobody can lift them before first aid")
	if not scene.is_empty():
		await _use(scene["aid_prompt"], "first aid")
		await _wait_until( func() -> bool: return victim.prompt.enabled, 4.0, "first aid to be given")
	_mark("aided")



func _outside(house: Building, door: Dictionary, out: float, along: = 0.0) -> Vector3:
	var shut: Transform3D = door["shut"]
	var outward: = - shut.basis.z
	if outward.dot(shut.origin - house.position) < 0.0:
		outward = - outward
	var at: = shut.origin + outward * out + shut.basis.x * along
	return Vector3(at.x, shut.origin.y - float(door["info"]["height"]) / 2.0 + 0.4, at.z)




func _alone_after() -> void :
	if _alone_started:
		return
	_alone_started = true
	await _wait(1.0)
	if not _host_quit.is_empty():

		var paid: Dictionary = NetWorld.last_partial
		print("play alone [%s] paid for the call the host left: %s; cash %d" % [_side, paid, int(_me().get_attr("Cash", 0))])
		_check( not paid.is_empty() and int(paid.get("bonus", 0)) > 0, "the host left mid-call: this player is paid for the unfinished call")
	if not _shots.is_empty():
		_look(_me().global_position, Vector3(24, 12, 40))
		await _wait(0.5)
		get_viewport().get_texture().get_image().save_png("%s_alone_%s.png" % [_shots, _side])
	if _camera != null:
		_camera.current = false
		_me().camera.camera.make_current()
	var came: = await _wait_until( func() -> bool: return not Game.incident.is_empty(), 45.0, "a call of this game's own")
	await _wait(2.0)
	print("play alone [%s] a call of its own came: %s; %s" % [_side, came, _alone()])
	_check(came, "alone, this device's own game sends it a call")
	_part_done = true
	_verdict()
	if not _shots.is_empty():
		get_viewport().get_texture().get_image().save_png("%s_alone2_%s.png" % [_shots, _side])
	await _wait(1.0)
	Game.quit()



func _alone() -> String:
	var said: Array = []
	said.append("net %s, players here %d" % ["off" if not Net.active() else "ON", Game.players.size()])
	said.append("call %s" % (str(Game.incident.get("kind", "fire")) + " at " + str(Game.incident.get("pos")) if not Game.incident.is_empty() else "none"))
	said.append("call service holds %s, running %s" % [CallService.current.hold, CallService.current.running])
	var ambulance: = AmbulanceService.current
	var scenes: = 0
	for child in ambulance.get_children():
		scenes += 1
	said.append("ambulance nodes %d, box %s, mirrors %d" % [scenes, ambulance.zone_position(), ambulance._mirrors.size()])
	said.append("victims %d (mirror %d), figures in the world %d" % [VictimService.current.victims.size(), VictimService.current._mirror.size(), get_tree().get_nodes_in_group("Victim").size()])
	said.append("signs %d, flames %d" % [CallMarker.all.size(), Flame.all.size()])
	said.append("tree %s, crash %s, flood %d, rescue %d" % [ not FallenTree.current.scene.is_empty(), not CarCrash.current.scene.is_empty(), FloodedCellar.current._mirrors.size(), HeightRescue.current._mirrors.size()])
	var me: = _me()
	said.append("me: hands '%s', Tool %s, Carrying %s, Line %s, Supply %s, seat %s, walking at %.0f, belt %s" % [me.holding, me.get_attr("Tool"), me.get_attr("Carrying"), me.get_attr("Line") != null, me.get_attr("Supply") != null, me.seat != null, me.walk_speed, _plates(me)])
	said.append(_state())
	return " | ".join(said)





func _state_tree() -> String:
	var held: = FallenTree.current.scene
	if held.is_empty():
		return "tree none"
	var cut: = 0
	for ring: Dictionary in held["rings"]:
		cut += 1 if ring["done"] else 0
	var lengths: Array = []
	for piece: Dictionary in held["pieces"]:
		if piece["butt"] or not is_instance_valid(piece["log"]):
			continue
		var holders: Array = []
		for player: Variant in piece["holders"]:
			if is_instance_valid(player):
				holders.append(player.display_name)
		lengths.append("%s at %s%s" % ["loose" if piece["free"] else "fast", _v(piece["log"].global_position.snappedf(2.0)), (" held by %s" % [holders]) if not holders.is_empty() else ""])
	return "tree rings %d/%d lengths %s" % [cut, held["rings"].size(), lengths]


func _host_tree() -> void :
	var calls: = CallService.current
	calls.forced = "tree"
	Config.Incidents["Tree"]["Variant"] = "plain"
	if not _solo:
		await _crew()
		calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "tree" and not FallenTree.current.scene.is_empty(), 40.0, "the tree call")
	var me: = _me()
	var held: = FallenTree.current.scene
	var at: Vector3 = Game.incident["pos"]
	var candidate: Dictionary = held["trees"][0]["candidate"]
	var toward: Vector3 = candidate["toward"]
	var truck: = _truck()
	_park(truck, at, 46.0)
	me.teleport(_beside(truck, at, 9.0))
	var view: = Vector3(34, 15, rad_to_deg(atan2(toward.x, toward.z)) + 70.0)
	print("play [host] a tree across the road at %s: %d rings, %d lengths; the pumper at %s" % [_v(at), held["rings"].size(), held["pieces"].size(), _v(truck.global_position)])
	if _solo:
		await _crew()
	_mark("parked")
	await _shot("start", at, view)
	await _moment("sawing", 60.0)
	await _wait(1.0)
	await _shot("sawing", at, Vector3(18, 8, view.z))

	var dragged: = 0
	for round in 40:
		if Game.incident.is_empty():
			break
		var piece: Dictionary = {}
		for one: Dictionary in held["pieces"]:
			if not one["butt"] and one["free"] and not one["cleared"] and not one["prompts"].is_empty():
				piece = one
				break
		if piece.is_empty():
			await _wait(0.5)
			continue
		var log_part: PartNode = piece["log"]
		var end: = log_part.global_transform * Vector3( - (piece["length"] / 2.0 - 0.4), 0, 0)
		me.teleport(_ground(end - toward * 2.0 + Vector3(0, 2, 0)))
		await _wait(0.4)
		if not await _use(piece["prompts"][0], "taking hold of a length"):
			break
		await _wait_until( func() -> bool: return piece["holders"].has(me), 3.0, "the strap")
		var from: = log_part.global_position
		var goal: Vector3 = candidate["position"] - toward * 75.0 + toward.cross(Vector3.UP) * (dragged * 6.0 - 6.0)
		print("play [host] has hold of a %s: walking at %.0f; the prompt now says '%s'" % ["crown" if piece["crown"] else ("heavy log" if piece["heavy"] else "log"), me.walk_speed, Text.say(piece["prompts"][0].action, "en")])
		if dragged == 0:
			_drag_shot("dragging", at, Vector3(30, 14, view.z))
		var steps: = 0
		for step in 400:
			var here: = me.global_position
			var way: = Vector3(goal.x - here.x, 0, goal.z - here.z)
			if way.length() < 1.0 or piece["cleared"] or not piece["holders"].has(me):
				print("play [host] stopped after %d steps: %.0f studs short of where they were going, cleared %s, still holding %s, walking at %.1f" % [steps, way.length(), piece["cleared"], piece["holders"].has(me), me.walk_speed])
				break
			steps += 1

			me.teleport(_ground(here + way.normalized() * me.walk_speed / 62.0 * 6.0 + Vector3(0, 1, 0)))
			for frame in 6:
				await get_tree().physics_frame
		await _wait(0.5)
		print("play [host] the length came %.1f studs: cleared %s" % [log_part.global_position.distance_to(from), piece["cleared"]])
		if piece["holders"].has(me):
			await _use(piece["prompts"][0], "letting go")
		dragged += 1
		if not piece["cleared"]:
			break
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 30.0, "the call to close")
	await _wait(1.5)
	await _shot("closed", at, view)
	print("play [host] over: cash %d, saved %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0))])
	_mark("done")


func _drag_shot(moment: String, at: Vector3, view: Vector3) -> void :
	await _wait(0.6)
	Net.request("play.shot", [moment, at, view])


func _client_tree() -> void :
	var me: = _me()
	await _crew()
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "tree" and not FallenTree.current.scene.is_empty(), 60.0, "the tree call")
	await _moment("parked")
	var held: = FallenTree.current.scene
	var at: Vector3 = Game.incident["pos"]
	print("play [client] the tree is here: %d rings, %d lengths" % [held["rings"].size(), held["pieces"].size()])
	me.teleport(_beside(_truck(), at, 10.0))
	await _wait(0.5)
	await _locker("Chainsaw")
	var item: = _tool("Chainsaw")
	print("play [client] in hand: Tool %s; belt %s; the saw ticks over here: %s" % [me.get_attr("Tool"), _plates(me), _sounding(item)])

	var first: = true
	var cash: = int(me.get_attr("Cash", 0))
	for limbs: bool in [true, false]:
		for ring: Dictionary in held["rings"].duplicate():
			if ring.has("limb") != limbs or ring["done"]:
				continue
			var where: Vector3 = ring["part"].global_position if is_instance_valid(ring["part"]) else ring["position"]

			var side: = FallenTree.cut_side(ring)
			await _stand_by(where, (side * 2.4 + Vector3(0, 2.0, 0)) if not side.is_zero_approx() else Vector3(0.5, 2.0, 2.4), not first)
			await _wait(0.3)
			await _press("fire")
			if first:
				await _wait(0.7)
				print("play [client] sawing: trigger held here %s, the saw at work here %s (Working %s), sounds %s" % [ToolService.current.trigger_held(me), item["using"], str(item["tool"].get_attr("Working")) if item["tool"] != null else "-", _sounding(item)])
				_mark("sawing")
				first = false
			var through: = await _wait_until( func() -> bool: return ring["done"], 9.0, "a ring to be cut through")
			Input.action_release("fire")
			await _wait(0.25)
			if not through:
				_fault("THE SAW did not cut the ring at %s" % _v(where))
	var cut: = 0
	for ring: Dictionary in held["rings"]:
		cut += 1 if ring["done"] else 0
	print("play [client] %d of %d rings cut; cash %d -> %d" % [cut, held["rings"].size(), cash, int(me.get_attr("Cash", 0))])
	_mark("sawn")

	me.teleport(_beside(_truck(), at, 10.0))
	await _locker("Chainsaw")
	print("play [client] the saw is back: Tool %s, belt %s" % [me.get_attr("Tool"), _plates(me)])
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 90.0, "the call to close")
	await _wait(1.0)
	print("play [client] over: cash %d, saved %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0))])
	await _moment("done", 30.0)
	await _wait(1.0)
	Game.quit()


func _tool(tool_name: String) -> Dictionary:
	for item: Dictionary in ToolService.current.items:
		if item["name"] == tool_name:
			return item
	return {}



func _sounding(item: Dictionary) -> Array:
	var noises: Array = []
	var tool: Variant = item.get("tool")
	if tool != null and is_instance_valid(tool):
		for sound_name: String in tool.sounds:
			if tool.sounds[sound_name].playing:
				noises.append(sound_name)
		for emitter_name: String in tool.emitters:
			if tool.emitters[emitter_name].emitting:
				noises.append(emitter_name)
	return noises





func _state_crash() -> String:
	var held: = CarCrash.current.scene
	if held.is_empty():
		return "crash none"
	var doors: Array = []
	for door: Dictionary in held["doors"]:
		doors.append(int(door["stage"]))
	var steam: Array = []
	for made: Dictionary in held["wrecks"]:
		steam.append(int(made["car"]["steaming"]))
	var prep: Array = []
	for made: Dictionary in held["wrecks"]:
		prep.append("%s%s" % ["S" if made["car"]["stable"] else "-", "G" if made["car"]["glass"] else "-"] if int(made["car"]["prep"]) >= 0 else "x")
	var engine: Variant = held["engine"]
	return "crash doors at stage %s wrecks %s steam %s engine %s lamps %s" % [doors, prep, steam, engine["state"] if engine != null else "none", held["lit"]]



func _at_door(door: Dictionary) -> void :
	var where: Vector3 = door["mark"].global_position
	var out: Vector3 = door["car"]["node"].global_basis.x * float(door["outward"])
	await _stand_by(where, out * 3.2 + Vector3(0, 2, 0))



func _work_door(door: Dictionary, stage: int, tool_name: String) -> bool:
	var me: = _me()
	await _at_door(door)
	await _wait(0.4)
	await _press("fire")
	await _wait(0.8)
	var item: = _tool(tool_name)
	print("play [%s] the %s at a door: trigger held %s, at work %s (Working %s), sounds %s" % [_side, tool_name.to_lower(), ToolService.current.trigger_held(me), item["using"], str(item["tool"].get_attr("Working")) if item["tool"] != null else "-", _sounding(item)])
	var done: = await _wait_until( func() -> bool: return int(door["stage"]) >= stage, 9.0, "the door to give to the %s" % tool_name.to_lower())
	Input.action_release("fire")
	await _wait(0.3)
	return done




func _ready_wrecks(held: Dictionary, truck: Vehicle, at: Vector3) -> void :
	var cars: Array = []
	for made: Dictionary in held["wrecks"]:
		if int(made["car"]["prep"]) >= 0:
			cars.append(made["car"])
	if cars.is_empty():
		return
	_me().teleport(_beside(truck, at, 10.0))
	await _locker("Step blocks")
	for car: Dictionary in cars:
		var prompt: Prompt = car["prompt"]
		var behind: Vector3 = (car["place"] as Transform3D).basis.z
		await _stand_by(prompt.global_position, behind * 3.0 + Vector3(0, 0.5, 0))
		await _wait(0.4)
		await _use(prompt, "stabilising a wreck")
		await _wait_until( func() -> bool: return car["stable"], 3.0, "the wreck to be stabilised")
		await _use(prompt, "the glass")
		await _wait_until( func() -> bool: return car["glass"], 3.0, "the glass to be out")
	print("play [%s] wrecks made ready: %s" % [_side, _state_crash()])
	_me().teleport(_beside(truck, at, 10.0))
	await _locker("Step blocks")




func _aid_and_board(held: Dictionary, truck: Vehicle, at: Vector3) -> void :
	for kit: Array in [["First aid kit", 3, "first aid"], ["Spinal board", 4, "the spinal board"]]:
		_me().teleport(_beside(truck, at, 10.0))
		await _locker(kit[0])
		for door: Dictionary in held["doors"]:
			await _wait_until( func() -> bool: return int(door["stage"]) >= kit[1], 30.0, "a door to be off")
			if int(door["stage"]) != kit[1]:
				continue
			await _at_door(door)
			await _wait(0.4)
			await _use(door["prompt"], kit[2])
			await _wait_until( func() -> bool: return int(door["stage"]) > kit[1], 3.0, "%s to be done" % kit[2])
		print("play [%s] %s done: %s" % [_side, kit[2], _state_crash()])
		_me().teleport(_beside(truck, at, 10.0))
		await _locker(kit[0])


func _host_crash() -> void :
	var calls: = CallService.current
	calls.forced = "crash"
	Config.Incidents["Crash"]["Layout"] = "headOn"
	Config.Incidents["Crash"]["Casualties"] = [2, 2, 2, 2, 3, 3]
	Config.Incidents["Crash"]["EngineFire"]["Chance"] = 0.0 if _solo else 1.0
	if _opt("burn"):
		Config.Incidents["Crash"]["EngineFire"]["After"] = Vector2(10, 12)
	if not _solo:
		await _crew()
		calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "crash" and not CarCrash.current.scene.is_empty(), 40.0, "the road accident")
	var me: = _me()
	var held: = CarCrash.current.scene
	var at: Vector3 = Game.incident["pos"]
	var along: Vector3 = held["along"]
	_facts["along"] = along
	var truck: = _truck()
	_park(truck, at + along * 44.0)
	me.teleport(_beside(truck, at, 9.0))
	var bearing: = rad_to_deg(atan2(along.x, along.z)) + 62.0
	print("play [host] an accident at %s: %d wrecks, %d doors jammed, engine %s; the pumper at %s" % [_v(at), held["wrecks"].size(), held["doors"].size(), held["engine"]["state"] if held["engine"] != null else "none", _v(truck.global_position)])
	if not _solo:
		_mark("parked")
		await _shot("start", at, Vector3(38, 17, bearing))
	await _ready_wrecks(held, truck, at)

	await _locker("Spreader")
	print("play [host] in hand: Tool %s, belt %s" % [me.get_attr("Tool"), _plates(me)])
	if not _solo:
		await _moment("secured", 80.0)
		await _shot("secured", at, Vector3(48, 24, bearing))
	if _opt("burn"):
		await _moment("alight", 60.0)
		await _shot("alight", at, Vector3(24, 10, bearing))
		await _moment("out", 60.0)
	var first: = true
	for door: Dictionary in held["doors"]:
		var forced: = await _work_door(door, 2, "Spreader")
		print("play [host] a door forced ajar: %s; cash %d" % [forced, int(me.get_attr("Cash", 0))])
		if first:
			_mark("spread")
			first = false
	_mark("spread all")
	if _solo:

		print("play [host] both doors forced, alone; waiting for somebody to join")
		await _crew()
		_mark("parked")
		await _wait(2.0)
		await _shot("joined", at, Vector3(38, 17, bearing))
	await _moment("cutting", 60.0)
	await _wait(1.2)
	await _shot("cutting", at, Vector3(20, 9, bearing))
	await _moment("cut", 60.0)

	me.teleport(_beside(truck, at, 10.0))
	await _locker("Spreader")
	await _moment("carrying", 60.0)
	var people: = VictimService.current
	var zone: Variant = AmbulanceService.current.zone_position()
	await _shot("carrying", at, Vector3(40, 18, bearing))
	for victim: Victim in people.victims.duplicate():
		if victim.state == "lying" and is_instance_valid(victim.figure):
			await _stand_by(victim.position(), Vector3(2.0, 2.0, 0.6))
			await _wait(0.4)
			if await _use(victim.prompt, "lifting a casualty"):
				await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0)
				await _walk(zone + Vector3(0, 0.5, 0))
			break
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 60.0, "the call to close")
	await _wait(1.5)
	await _shot("closed", at, Vector3(40, 18, bearing))
	print("play [host] over: cash %d, saved %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0))])
	await _wait(8.0)
	await _shot("after", at, Vector3(40, 18, bearing))
	_mark("done")


func _client_crash() -> void :
	var me: = _me()
	await _crew()
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "crash" and not CarCrash.current.scene.is_empty(), 60.0, "the road accident")
	await _moment("parked")
	await _wait_until( func() -> bool: return _facts.has("along"), 5.0)
	var held: = CarCrash.current.scene
	var at: Vector3 = Game.incident["pos"]
	var along: Vector3 = _facts["along"]
	var across: = along.cross(Vector3.UP)
	var truck: = _truck()
	var cordon: = Cordon.current
	var engine: Variant = held["engine"]
	print("play [client] the accident is here: %d wrecks, %d doors, engine %s, %d casualties, flames %d" % [held["wrecks"].size(), held["doors"].size(), engine["state"] if engine != null else "none", VictimService.current.victims.size(), Flame.all.size()])
	if _opt("late"):

		var stages: Array = []
		for door: Dictionary in held["doors"]:
			stages.append(int(door["stage"]))
		print("play [client] joined half way: doors at stage %s, the spreader is with %s, shutters up %s, ambulance arrived %s, the card says %s/%s" % [stages, _tool("Spreader")["holder"].display_name if _tool("Spreader")["holder"] != null else "nobody", truck.lockers_open(), AmbulanceService.current.arrived(), str(Game.incident.get("done")), str(Game.incident.get("total"))])
		await _wait(3.5)
		await _late_crash(held, at, truck)
		return

	me.teleport(_beside(truck, at, 10.0))
	await _wait(0.4)
	await _locker("Cones")
	var cones: Variant = cordon.held(me)
	print("play [client] cones: in hand here %s (Tool %s, hands '%s'); in the hand %s; belt %s" % [cones != null, me.get_attr("Tool"), me.holding, _in_hand_names(me), _plates(me)])
	me.teleport(_beside(truck, at, 20.0, 6.0))
	_face(me.global_position + along * 10.0 + Vector3(0, 3, 0))
	await _wait(0.4)
	await _shot("cones", me.global_position + Vector3(0, 2.5, 0), Vector3(8, 3, rad_to_deg(atan2(along.x, along.z)) + 20.0))
	for step in 3:
		me.teleport(_ground(at - along * 26.0 + across * (step * 5.0 - 5.0) + along * 4.0 + Vector3(0, 2, 0)))
		_face(me.global_position - along * 10.0 + Vector3(0, 3, 0))
		await _wait(0.5)
		await _tap("fire")
		await _wait(0.5)
	print("play [client] %d cones standing here" % cordon.cordon["cones"].size())

	await _slot("Cones")
	print("play [client] cones on the belt: in the hand %s, Tool %s, hands '%s', belt %s" % [_in_hand_names(me), me.get_attr("Tool"), me.holding, _plates(me)])
	await _slot("Cones")
	if not cordon.cordon["cones"].is_empty():
		var cone: Dictionary = cordon.cordon["cones"][0]
		await _stand_by(cone["place"].origin, Vector3(2.0, 2.0, 0))
		await _wait(0.4)
		await _use(cone["model"].get_meta("prompt"), "taking a cone up")
		await _wait(0.5)
		print("play [client] one taken up: %d standing" % cordon.cordon["cones"].size())
		_face(me.global_position - along * 10.0 + Vector3(0, 3, 0))
		await _wait(0.3)
		await _tap("fire")
		await _wait(0.5)

	me.teleport(_beside(truck, at, 10.0))
	await _wait(0.4)
	await _locker("Barrier tape")
	print("play [client] tape: in the hand %s; Tool %s; belt %s; the cones are %s" % [_in_hand_names(me), me.get_attr("Tool"), _plates(me), "still carried" if "Cones" in str(_plates(me)) else "not on the belt"])
	for side: float in [-1.0, 1.0]:
		me.teleport(_ground(at + along * 22.0 + across * side * 9.0 - along * 4.0 + Vector3(0, 2, 0)))
		_face(me.global_position + along * 10.0 + Vector3(0, 3, 0))
		await _wait(0.5)
		await _tap("fire")
		await _wait(0.7)
		if side < 0.0:
			print("play [client] the first post is planted: %d lone posts shown here" % cordon._net_firsts.size())
			await _shot("tape", me.global_position + Vector3(0, 2.5, 0), Vector3(9, 4, rad_to_deg(atan2( - along.x, - along.z)) + 25.0))
	print("play [client] %d cones and %d tapes out here" % [cordon.cordon["cones"].size(), cordon.cordon["tapes"].size()])

	me.teleport(_beside(truck, at, 10.0))
	await _wait(0.4)
	await _locker("Barrier tape")
	await _locker("Cones")
	print("play [client] put back: belt %s, Tool %s, hands '%s'" % [_plates(me), me.get_attr("Tool"), me.holding])
	_mark("secured")
	await _wait(1.8)

	if engine != null:
		var bonnet: Vector3 = engine["prompt"].global_position
		if _opt("burn"):
			var lit: = await _wait_until( func() -> bool: return not Flame.all.is_empty(), 40.0, "the engine to catch")
			print("play [client] the engine is alight here: %s (%d flames; state %s; battery prompt on offer %s)" % [lit, Flame.all.size(), engine["state"], engine["prompt"].enabled])
			_mark("alight")
			me.teleport(_beside(truck, at, 10.0))
			await _locker("Extinguisher")
			var side: Vector3 = engine["prompt"].get_parent().global_basis.x
			await _stand_by(bonnet, side.normalized() * 7.0 + Vector3(0, 2, 0))
			_face(bonnet)
			await _wait(0.6)
			await _press("fire")
			await _wait(1.0)
			var bottle: = _tool("Extinguisher")
			print("play [client] the extinguisher: trigger held %s, at work here %s, %s; %.1f studs from the flame" % [ToolService.current.trigger_held(me), bottle["using"], _sounding(bottle), me.root_position().distance_to(Flame.all[0].global_position) if not Flame.all.is_empty() else -1.0])
			var out: = await _wait_until( func() -> bool: return Flame.all.is_empty(), 13.0, "the engine fire to go out")
			Input.action_release("fire")
			await _wait(0.5)
			print("play [client] the engine fire is out: %s (state %s); cash %d" % [out, engine["state"], int(me.get_attr("Cash", 0))])
			me.teleport(_beside(truck, at, 10.0))
			await _locker("Extinguisher")
			_mark("out")
		else:
			await _stand_by(bonnet, (bonnet - at).normalized() * 3.5 + Vector3(0, 2, 0))
			await _wait(0.4)
			await _use(engine["prompt"], "the battery")
			await _wait(0.6)
			print("play [client] battery off: engine %s, the prompt still on offer %s; cash %d" % [engine["state"], engine["prompt"].enabled, int(me.get_attr("Cash", 0))])

	me.teleport(_beside(truck, at, 10.0))
	await _locker("Cutter")
	await _moment("spread", 60.0)
	var first: = true
	for door: Dictionary in held["doors"]:
		await _wait_until( func() -> bool: return int(door["stage"]) >= 2, 30.0, "the spreader to have been at a door")
		if first:
			_cut_mark()
			first = false
		var off: = await _work_door(door, 3, "Cutter")
		print("play [client] a door cut off: %s; cash %d" % [off, int(me.get_attr("Cash", 0))])
	_mark("cut")
	me.teleport(_beside(truck, at, 10.0))
	await _locker("Cutter")
	await _aid_and_board(held, truck, at)

	var people: = VictimService.current
	await _wait_until( func() -> bool:
		for victim: Victim in people.victims:
			if victim.state == "lying":
				return true
		return false
	, 10.0, "a casualty to be free")
	var carried: = false
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying" or not is_instance_valid(victim.figure):
			continue
		await _stand_by(victim.position(), Vector3(-2.0, 2.0, -0.6))
		await _wait(0.4)

		if victim.tag_prompt.enabled:
			await _use(victim.tag_prompt, "assessing a casualty")
			_check( await _wait_until( func() -> bool: return victim.tagged, 4.0, "the tag"), "assessed: the casualty's tag shows (%s)" % victim.tag)
		if victim.state != "lying":
			continue
		if await _use(victim.prompt, "lifting a casualty"):
			await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0, "the casualty on the shoulders")
			if not carried:
				_mark("carrying")
				carried = true
				await _wait(2.2)
			var zone: Variant = AmbulanceService.current.zone_position()
			await _walk(zone + Vector3(0, 0.5, 0))
			await _wait(1.0)
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 60.0, "the call to close")
	await _wait(1.0)
	print("play [client] over: cash %d, saved %d, hands '%s'" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), me.holding])
	await _moment("done", 40.0)
	await _wait(1.0)
	Game.quit()


func _cut_mark() -> void :
	await _wait(1.0)
	_mark("cutting")



func _in_hand_names(player: Player) -> Array:
	var names: Array = []
	for child in player.rig.hand_right.get_children():
		if child is Node3D and child.visible and not (child is Prompt):
			names.append(String(child.name))
	return names






func _hatch() -> Dictionary:
	var flood: = FloodedCellar.current
	if Net.is_host():
		return flood._hatch
	for serial: int in flood._mirrors:
		if not flood._mirrors[serial]["over"]:
			return flood._mirrors[serial]
	return {}


func _state_flood() -> String:
	var hatch: = _hatch()
	if hatch.is_empty():
		return "flood none"

	var pumps: Array = []
	for pump: Variant in (hatch["pumps"] if Net.is_host() else hatch.get("pumps_told", [])):
		pumps.append("laid" if (pump["drain"] if pump is Dictionary else pump[1]) else "in hand")
	var drawn: = 0
	for made: Dictionary in hatch.get("drawn", []):
		drawn += int(is_instance_valid(made["holder"]) and made["holder"].visible)
	return "flood hatch at %s, %s litres left, power %s, pumps %s (%d drawn), drain at %s" % [
		_v(hatch["inlet"].global_position.snappedf(2.0)), str(hatch["litres"]), "on" if hatch["power"] else "off", pumps, drawn, 
		_v((hatch["drain_at"] as Vector3).snappedf(2.0)), 
	]




func _pump_in(hatch: Dictionary, power: bool) -> bool:
	var me: = _me()
	var inlet: Node3D = hatch["inlet"]
	var out: = - inlet.global_basis.z
	if power:
		await _stand_by(hatch["switch"].global_position, out * 3.0 + Vector3(0, -2.0, 0))
		await _use(hatch["switch_prompt"], "the cellar's power switch")
		await _wait_until( func() -> bool: return not hatch["power"], 4.0, "the power to go off")
	me.teleport(_beside(_truck(), inlet.global_position, 10.0))
	await _locker("Portable pump", _truck())
	if not _check(CallGear.carried(me) == "Portable pump", "a portable pump from the pumper's lockers"):
		return false
	await _walk(_ground(hatch["pump_at"].global_position + out * 3.0))
	await _use(hatch["pump_prompt"], "lowering the pump into the hatch")
	await _wait_until( func() -> bool: return me.get_attr("Discharge") != null, 4.0, "the pump's hose in hand")
	await _walk(_ground((hatch["drain_at"] as Vector3) + out * 2.5))
	await _use(hatch["drain_prompt"], "laying the hose into the drain")
	return await _wait_until( func() -> bool: return me.get_attr("Discharge") == null, 4.0, "the hose to be laid")


func _host_flood() -> void :
	var calls: = CallService.current
	calls.forced = "flood"
	Config.Incidents["Flood"]["PumpFlow"] = 150.0
	if not _solo:
		await _crew()
		calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "flood" and not FloodedCellar.current.source.is_empty(), 40.0, "the flooded cellar")
	var flood: = FloodedCellar.current
	var hatch: = flood._hatch
	var inlet: Node3D = flood.source["node"]
	var at: = inlet.global_position
	var out: = - inlet.global_basis.z
	var truck: = _truck()
	truck.global_transform = Transform3D(Basis.looking_at(out.cross(Vector3.UP)), CallKit.ground_at(at + out * 18.0) + Vector3(0, 3.0, 0))
	truck.linear_velocity = Vector3.ZERO
	truck.reset_physics_interpolation()
	_me().teleport(_ground(at + out * 6.0 + out.cross(Vector3.UP) * 8.0 + Vector3(0, 2, 0)))
	var bearing: = rad_to_deg(atan2(out.x, out.z)) + 55.0
	print("play [host] a flooded cellar at %s: %d litres; the pumper at %s; the drain at %s" % [_v(at), int(Game.incident["total"]), _v(truck.global_position), _v(hatch["drain_at"])])
	if _solo:
		await _crew()
	_mark("parked")
	await _shot("start", at + out * 9.0, Vector3(34, 15, bearing))

	await _moment("power off", 60.0)
	if not await _pump_in(hatch, false):
		return
	_mark("second pump")
	await _moment("first pump", 60.0)
	await _wait(1.0)
	await _shot("pumping", at + out * 9.0, Vector3(30, 13, bearing))
	_check(hatch["pumps"].size() == 2, "two pumps in the hatch, their hoses in the drain")
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 80.0, "the cellar to be dry")
	await _wait(1.5)
	await _shot("closed", at + out * 9.0, Vector3(34, 15, bearing))
	print("play [host] over: cash %d, saved %d; pumps back on the truck %d" % [int(_me().get_attr("Cash", 0)), int(_me().get_attr("Saved", 0)), int(CallGear.current.kits["Portable pump"]["pool"])])
	_mark("done")


func _client_flood() -> void :
	var me: = _me()
	await _crew()
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "flood" and not _hatch().is_empty(), 60.0, "the flooded cellar")
	await _moment("parked")
	var hatch: = _hatch()
	var inlet: Node3D = hatch["inlet"]
	print("play [client] the hatch is here at %s, %s litres in it, power %s; the drain here at %s" % [_v(inlet.global_position), str(hatch["litres"]), "on" if hatch["power"] else "off", _v(hatch["drain_at"])])

	me.teleport(_beside(_truck(), inlet.global_position, 10.0))
	await _locker("Portable pump", _truck())
	var health: = me.health
	await _walk(_ground(hatch["pump_at"].global_position - inlet.global_basis.z * 3.0))
	await _use(hatch["pump_prompt"], "lowering the pump into live water")
	await _wait(1.0)
	print("play [client] into live water: health %.0f -> %.0f, still carrying %s" % [health, me.health, CallGear.carried(me)])
	_check(me.health < health and CallGear.carried(me) == "Portable pump", "a pump into live water is a shock, and stays in hand")
	await _locker("Portable pump", _truck())
	if not await _pump_in(hatch, true):
		return
	_mark("power off")
	_mark("first pump")
	await _moment("second pump", 60.0)
	await _wait(1.5)
	print("play [client] pumps here: %s; water left %s" % [hatch.get("pumps_told", []), str(hatch["litres"])])
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 80.0, "the cellar to be dry")
	await _wait(1.0)
	print("play [client] over: cash %d, saved %d; carrying %s" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), CallGear.carried(me)])
	await _moment("done", 30.0)
	await _wait(1.0)
	Game.quit()





func _stranded() -> Dictionary:
	var rescue: = HeightRescue.current
	if Net.is_host():
		return rescue.stranded
	for serial: int in rescue._mirrors:
		if not rescue._mirrors[serial]["over"]:
			return rescue._mirrors[serial]
	return {}


func _state_rescue() -> String:
	var ladder: = LadderService.current
	var held: = _stranded()
	var who: = "nobody stranded"
	if not held.is_empty() and is_instance_valid(held["root"]):
		who = "stranded %s at %s, sign %s" % ["aboard" if held["aboard"] else "waiting", _v(held["root"].global_position.snappedf(2.0)), is_instance_valid(held["marker"]) and held["marker"].visible]
	return "%s | ladder %s turned %.0f raised %.0f out %.0f, basket at %s, at the stand %s, in the basket %s, controls %s" % [
		who, ladder.state, snappedf(ladder.turned, 4.0), snappedf(ladder.elevation, 4.0), snappedf(ladder.extension, 4.0), _v(ladder.basket_position().snappedf(2.0)), 
		ladder._stand_rider.display_name if ladder._stand_rider != null else "nobody", ladder._perch_rider.display_name if ladder._perch_rider != null else "nobody", 
		ladder.controller.display_name if ladder.controller != null else "nobody", 
	]



func _steer(reading: Callable, wanted: float, less: String, more: String, slack: float, limit: = 40.0, turning: = false) -> void :
	var waited: = 0.0
	var held: = ""
	while waited < limit:
		var off: float = wanted - float(reading.call())
		if turning:
			off = wrapf(off, -180.0, 180.0)
		if absf(off) <= slack:
			break
		var key: = more if off > 0.0 else less
		if key != held:
			if not held.is_empty():
				Input.action_release(held)
			Input.action_press(key)
			held = key
		await get_tree().process_frame
		waited += get_process_delta_time()
	if not held.is_empty():
		Input.action_release(held)
	await _wait(0.3)


func _host_rescue() -> void :
	var calls: = CallService.current
	calls.forced = "rescue"
	Config.Incidents["Rescue"]["Who"] = "roof"
	Config.Incidents["Rescue"]["GripTimes"] = [1200, 1200]
	if not _solo:
		await _crew()
		calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "rescue" and not HeightRescue.current.stranded.is_empty(), 40.0, "the rescue call")
	var me: = _me()
	var rescue: = HeightRescue.current
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var root: Node3D = rescue.stranded["root"]
	var feet: = root.global_position - Vector3(0, rescue.stranded["rise"], 0)


	var best: = Vector3.ZERO
	var best_gap: = INF
	var best_place: = Transform3D.IDENTITY
	for facing: float in [1.0, -1.0]:
		for along_by: float in [-24.0, -12.0, 0.0, 12.0, 24.0]:
			_park(truck, feet, along_by, facing)
			truck.force_update_transform()
			for turn in range(-180, 180, 6):
				for raise in range(10, 76, 5):
					for slide in range(0, int(ladder._slide) + 1, 4):
						if ladder.reach_of(raise, slide) > LadderService.MAX_OUTREACH:
							continue
						ladder.turned = turn
						ladder.elevation = raise
						ladder.extension = slide
						ladder._place()
						var gap: = ladder.basket_position().distance_to(feet + Vector3(0, 2, 0))
						if gap < best_gap:
							best_gap = gap
							best = Vector3(turn, raise, slide)
							best_place = truck.global_transform
	ladder.turned = 0.0
	ladder.elevation = 0.0
	ladder.extension = 0.0
	ladder._place()
	truck.global_transform = best_place
	truck.linear_velocity = Vector3.ZERO
	truck.reset_physics_interpolation()
	var at: = truck.global_position
	var view_bearing: = rad_to_deg(atan2(truck.global_basis.x.x, truck.global_basis.x.z)) + (20.0 if (truck.global_transform.affine_inverse() * feet).x > 0.0 else 200.0)
	print("play [host] somebody on a roof at %s, %.0f studs up; the ladder truck at %s; the basket can come within %.1f studs of them (turned %d, raised %d, out %d)" % [_v(root.global_position), root.global_position.y, _v(at), best_gap, best.x, best.y, best.z])
	me.teleport(_ground(truck.global_transform * Vector3(0, 0, float(truck.data["rear"]) + 5.0)))
	if _solo:
		await _crew()
	await _wait(1.5)
	_mark("parked")
	await _shot("start", (at + feet) / 2.0, Vector3(60, 26, view_bearing))



	for attempt in 3:
		await _wait_until( func() -> bool: return truck.linear_velocity.length() < 0.5, 10.0)
		await _use(ladder._prompt, "the stabilisers")
		if await _wait_until( func() -> bool: return ladder.state == "ready", 8.0):
			break
		print("play [host] the stabilisers did not go down (try %d): %s" % [attempt + 1, ladder.state])
	_check(ladder.state == "ready", "the stabilisers go down")
	_mark("jacks")
	await _moment("in basket", 30.0)
	me.teleport(ladder._beside_stand())
	await _wait(0.5)
	await _use(ladder._seat_prompt, "the stand at the turntable")
	await _wait_until( func() -> bool: return ladder._stand_rider == me, 3.0, "a place at the stand")
	print("play [host] at the stand: %s; the controls are %s's; in the basket: %s" % [ladder._stand_rider == me, ladder.controller.display_name if ladder.controller != null else "nobody", ladder._perch_rider.display_name if ladder._perch_rider != null else "nobody"])

	await _steer( func() -> float: return ladder.elevation, maxf(best.y, 30.0), "move_back", "move_forward", 1.0)
	await _steer( func() -> float: return ladder.turned, best.x, "move_right", "move_left", 1.5, 40.0, true)
	if absf(wrapf(best.x - ladder.turned, -180.0, 180.0)) > 3.0:
		await _steer( func() -> float: return ladder.turned, best.x, "move_left", "move_right", 1.5, 40.0, true)
	await _shot("raised", (at + feet) / 2.0, Vector3(60, 26, view_bearing))
	await _steer( func() -> float: return ladder.extension, best.z, "ladder_retract", "ladder_extend", 0.8)
	await _steer( func() -> float: return ladder.elevation, best.y, "move_back", "move_forward", 1.0)
	var gap: = ladder.basket_position().distance_to(feet)
	print("play [host] the ladder lies turned %.0f, raised %.0f, out %.0f%s: the basket %.1f studs from their feet" % [ladder.turned, ladder.elevation, ladder.extension, (" (stopped: %s)" % Text.say(ladder.blocked, "en")) if ladder.blocked != null else "", gap])
	var aboard: = await _wait_until( func() -> bool: return rescue.stranded.get("aboard", false), 8.0, "them to come aboard")
	_mark("aboard")
	await _wait(0.5)
	await _shot("aboard", ladder.basket_position(), Vector3(46, 12, view_bearing))
	if not aboard:
		return

	await _moment("harness", 30.0)
	_check(rescue.stranded.get("harness", false), "the harness is on before the ladder comes down")

	await _tap("ladder_stow")
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 60.0, "the ladder to be stowed and the call to close")
	await _wait(1.5)
	await _shot("down", at, Vector3(34, 14, view_bearing))
	await _tap("veh_exit")
	await _wait(1.0)
	print("play [host] over: cash %d, saved %d; off the stand: %s" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), me.seat == null])
	_mark("done")


func _client_rescue() -> void :
	var me: = _me()
	await _crew()
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "rescue" and not _stranded().is_empty(), 60.0, "the rescue call")
	await _moment("parked")
	var ladder: = LadderService.current
	var held: = _stranded()
	print("play [client] somebody is stranded here at %s; their sign is up: %s; the ladder truck at %s" % [_v(held["root"].global_position), is_instance_valid(held["marker"]) and held["marker"].visible, _v(ladder.vehicle.global_position)])
	await _moment("jacks", 30.0)
	await _wait(0.5)


	me.teleport(ladder.floor_node.global_position + Vector3(0, 0.4, 0))
	await _wait(0.6)
	await _use(ladder._perch_prompt, "the basket")
	var sat: = await _wait_until( func() -> bool: return me.seat == ladder.perch, 4.0, "a place in the basket")
	print("play [client] in the basket: %s; the ladder here is %s" % [sat, ladder.state])
	_mark("in basket")
	await _moment("aboard", 150.0)
	await _wait(0.4)
	held = _stranded()
	print("play [client] up with the basket at %s (me at %s); whoever was stranded is aboard here: %s, %.1f studs from me" % [_v(ladder.basket_position()), _v(me.global_position), held.get("aboard", false), held["root"].global_position.distance_to(me.global_position) if not held.is_empty() else -1.0])

	if not held.is_empty():
		var clipped: = await _wait_until( func() -> bool: return held.get("harness", false), 8.0, "the harness to be on")
		print("play [client] the harness is on here: %s" % clipped)
	_mark("harness")
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 80.0, "the call to close")
	await _wait(0.6)
	await _tap("veh_exit")
	await _wait(1.2)
	print("play [client] over: cash %d, saved %d; out of the basket: %s, at %s" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), me.seat == null, _v(me.global_position)])
	await _moment("done", 30.0)
	await _wait(1.0)
	Game.quit()





func _state_fire() -> String:
	var house: = _building_of_call() if not Game.incident.is_empty() else (_facts_house())
	if house == null:
		return "house none"
	var said: = "house %s%s" % [house.name, " out of use" if house.ruined else ""]
	if house is House:
		var doors: Array = []
		for door_name: String in house.doors:
			var door: Dictionary = house.doors[door_name]
			if door["outside"] or door["locked"] or door["burnt"]:
				doors.append("%s%s%s%s" % [door_name, " open" if door["open"] else " shut", " locked" if door["locked"] else "", " burnt" if door["burnt"] else ""])
		doors.sort()
		var broken: = 0
		for pane: Dictionary in house._pane_list:
			broken += 1 if pane["broken"] else 0
		var smoke: Array = []
		for room_name: String in house.rooms:
			var level: = float(house.rooms[room_name].get("level", 0.0))
			if level > 0.04:
				smoke.append("%s %.1f" % [room_name, level])
		smoke.sort()
		said += " doors %s panes broken %d smoke %s" % [doors, broken, smoke]
	var shaded: = 0
	for id: int in house._original:
		var row: int = Game.store.row_of.get(id, -1)
		if row >= 0 and not Game.store.color(row).is_equal_approx(house._original[id]):
			shaded += 1
	said += " parts blackened %d" % shaded
	var station: = Game.station
	var open: Array = []
	for index in station.doors.size():
		if station.doors[index]["open"]:
			open.append(index + 1)
	said += " | bay doors open %s" % [open]
	var truck: = _truck()
	said += " | pumper blue %s siren %d speed %d riders %s" % [truck.blue_on, truck.siren, int(round(truck.forward_speed / 4.0)) * 4, _riders(truck)]
	return said


func _riders(vehicle: Vehicle) -> Array:
	var names: Array = []
	for rider: Variant in vehicle.riders:
		names.append(rider.display_name if (rider != null and is_instance_valid(rider)) else "-")
	return names



func _facts_house() -> Building:
	var at: Variant = _facts.get("house")
	if not at is Vector3:
		return null
	var best: Building = null
	for building in FireService.current.buildings:
		if best == null or building.position.distance_to(at) < best.position.distance_to(at):
			best = building
	return best



func _board(vehicle: Vehicle, door_name: String) -> bool:
	var me: = _me()
	var door: Dictionary = vehicle.doors[door_name]
	var grip: Vector3 = door["prompt"].global_position
	var out: = vehicle.global_basis.x * signf(float(door["side"]) if float(door["side"]) != 0.0 else (vehicle.global_transform.affine_inverse() * grip).x)
	me.teleport(_ground(grip + out * 3.5 + Vector3(0, 1, 0)))
	await _wait(0.5)
	if not door["open"]:
		await _use(door["prompt"], "the %s of the %s" % [door_name, vehicle.name])
		await _wait_until( func() -> bool: return door["open"], 2.0, "the door to be open")
		await _wait(0.4)
	if not await _use(door["seat_prompt"], "getting in"):
		return false
	return await _wait_until( func() -> bool: return me.seat != null and me.get_attr("Vehicle") == vehicle, 3.0, "a seat in the %s" % vehicle.name)



func _get_out() -> bool:
	var me: = _me()
	await _tap("veh_exit")
	var out: = await _wait_until( func() -> bool: return me.seat == null and me.get_attr("Vehicle") == null, 3.0, "to be out of the vehicle")
	await _wait(0.4)
	return out


func _keys_up() -> void :
	for action: String in ["move_forward", "move_back", "move_left", "move_right"]:
		Input.action_release(action)




func _steer_at(vehicle: Vehicle, point: Vector3, pace: float) -> float:
	var here: = vehicle.global_position
	var ahead: = - vehicle.global_basis.z
	ahead = Vector3(ahead.x, 0, ahead.z).normalized()
	var to: = Vector3(point.x - here.x, 0, point.z - here.z)
	var off: = to.length()
	if off < 0.5:
		return off
	var way: = to / off
	var turn: = atan2(ahead.cross(way).y, ahead.dot(way))
	var right: = clampf( - turn * 2.2, -1.0, 1.0)
	if absf(right) < 0.06:
		Input.action_release("move_left")
		Input.action_release("move_right")
	elif right > 0.0:
		Input.action_release("move_left")
		Input.action_press("move_right", right)
	else:
		Input.action_release("move_right")
		Input.action_press("move_left", - right)
	var wanted: = pace * lerpf(1.0, 0.35, clampf(absf(turn) / 0.6, 0.0, 1.0))
	var speed: = vehicle.forward_speed
	if speed < wanted - 1.5:
		Input.action_release("move_back")
		Input.action_press("move_forward")
	elif speed > wanted + 5.0:
		Input.action_release("move_forward")
		Input.action_press("move_back")
	else:
		Input.action_release("move_forward")
		Input.action_release("move_back")
	return off



func _halt(vehicle: Vehicle) -> void :
	_keys_up()
	var waited: = 0.0
	while vehicle.forward_speed > 1.5 and waited < 6.0:
		Input.action_press("move_back")
		await get_tree().physics_frame
		waited += 1.0 / 60.0
	_keys_up()
	await _wait(0.6)




func _drive(vehicle: Vehicle, goal: Vector3, pace: = 38.0, limit: = 150.0) -> bool:
	var guide: = Guide.current
	var began: = Game.now()
	var still: = 0.0
	var backed: = 0
	var last_points: = PackedVector3Array()
	var empty_for: = 0.0
	while Game.now() - began < limit:
		await get_tree().physics_frame
		var here: = vehicle.global_position
		var points: = guide.points
		if points.size() >= 2:
			last_points = points
			empty_for = 0.0
		else:
			empty_for += 1.0 / 60.0

			if empty_for > 2.5 or last_points.is_empty():
				if Vector3(goal.x - here.x, 0, goal.z - here.z).length() < 110.0 and empty_for > 0.3:
					break
				if empty_for > 6.0:
					_keys_up()
					_fault("NO WAY is laid by the guide, %.0f studs from where the %s is going" % [here.distance_to(goal), vehicle.name])
					return false
			if last_points.is_empty():
				continue
			points = last_points

		var nearest: = 0
		var nearest_off: = INF
		for index in points.size():
			var off: = Vector2(points[index].x - here.x, points[index].z - here.z).length()
			if off < nearest_off:
				nearest_off = off
				nearest = index
		var look: = 20.0 + absf(vehicle.forward_speed) * 0.55
		var run: = 0.0
		var target: = points[points.size() - 1]
		for index in range(nearest, points.size() - 1):
			run += points[index].distance_to(points[index + 1])
			if run >= look:
				target = points[index + 1]
				break
		var end_off: = Vector2(points[points.size() - 1].x - here.x, points[points.size() - 1].z - here.z).length()
		if end_off < 14.0:
			break

		var far: = points[mini(points.size() - 1, nearest + 6)]
		var ahead: = - vehicle.global_basis.z
		var bend: = absf(atan2(ahead.cross((far - here).normalized()).y, ahead.dot((far - here).normalized())))
		var speed: = pace * lerpf(1.0, 0.45, clampf(bend / 0.7, 0.0, 1.0))
		if end_off < 60.0:
			speed = minf(speed, 16.0)
		_steer_at(vehicle, target, speed)

		if absf(vehicle.forward_speed) < 1.0:
			still += 1.0 / 60.0
		else:
			still = 0.0
		if still > 3.5:
			backed += 1
			if backed > 4:
				_keys_up()
				_fault("STUCK at %s" % [_v(here)])
				return false
			print("play [%s] stopped against something at %s: backing off" % [_side, _v(here)])
			_keys_up()
			Input.action_press("move_back")
			await _wait(1.8)
			_keys_up()
			await _wait(0.4)
			still = 0.0
	await _halt(vehicle)
	return Game.now() - began < limit




func _attack_spot(at: Vector3) -> Vector3:
	var me: = _me()
	var best: = Vector3.INF
	var best_off: = INF
	for reach: float in [7.5, 9.5, 6.0, 12.0]:
		for step in 12:
			var angle: = step * TAU / 12.0
			var over: = at + Vector3(sin(angle), 0, cos(angle)) * reach
			var floor_hit: = Game.world.raycast(over + Vector3(0, 2.0, 0), over + Vector3(0, -7.0, 0), World.LAYER_SOLID)
			if floor_hit.is_empty():
				continue
			var feet: Vector3 = floor_hit["position"]
			var eye: = feet + Vector3(0, 4.2, 0)
			var blocked: = Game.world.raycast(eye, at + Vector3(0, 0.8, 0), World.LAYER_QUERY, [me.get_rid()])
			if not blocked.is_empty() and blocked["position"].distance_to(at) > 2.5:
				continue

			if not Game.world.raycast(feet + Vector3(0, 0.6, 0), feet + Vector3(0, 4.6, 0), World.LAYER_SOLID).is_empty():
				continue
			var off: = feet.distance_to(me.global_position)
			if off < best_off:
				best_off = off
				best = feet + Vector3(0, 0.3, 0)
		if best != Vector3.INF:
			return best
	return _ground(at + Vector3(4, 2, 0))




func _fight_fire(until: Callable, limit: = 120.0) -> int:
	var me: = _me()
	var began: = Game.now()
	var out: = 0
	while Game.now() - began < limit and not until.call():
		var targets: Array = []
		for flame in Flame.all:
			if is_instance_valid(flame) and not flame.is_queued_for_deletion():
				targets.append(flame)
		var smouldering: = targets.is_empty()
		if smouldering:
			for ember in Ember.all:
				if is_instance_valid(ember):
					targets.append(ember)
		if targets.is_empty() or HoseService.current.line_of(me) == null:
			Input.action_release("fire")
			await _wait(0.4)
			continue
		var target: Node3D = targets[0]
		for other: Node3D in targets:
			if other.global_position.distance_to(me.global_position) < target.global_position.distance_to(me.global_position):
				target = other
		var at: = target.global_position
		var id: = target.get_instance_id()
		var spot: = _attack_spot(at)
		if spot.distance_to(me.global_position) > 1.5:
			Input.action_release("fire")
			await _walk(spot)
		_face(at + Vector3(0, 0.6, 0))
		await _press("fire")
		var held: = 0.0
		while is_instance_id_valid(id) and held < 9.0 and not until.call():
			_face(at + Vector3(0, 0.6, 0))
			await _wait(0.2)
			held += 0.2
		if not is_instance_id_valid(id) and not smouldering:
			out += 1
		if held >= 9.0:

			Input.action_release("fire")
			me.teleport(_ground(me.global_position + Vector3(randf_range(-2, 2), 1, randf_range(-2, 2))))
			await _wait(0.3)
	Input.action_release("fire")
	await _wait(0.3)
	return out


func _fire_house() -> House:
	var house: House = null
	for building in FireService.current.buildings:
		if building is House and building.name.begins_with("Family house") and not building.ruined:
			if house == null or building.position.distance_to(Game.station.door_position) < house.position.distance_to(Game.station.door_position):
				house = building
	return house



func _hydrant_by(vehicle: Vehicle) -> Dictionary:
	var best: Dictionary = {}
	for hydrant: Dictionary in HoseService.current.hydrants:
		if best.is_empty() or hydrant["position"].distance_to(vehicle.global_position) < best["position"].distance_to(vehicle.global_position):
			best = hydrant
	return best


func _rig_of(vehicle: Vehicle) -> Dictionary:
	for rig: Dictionary in HoseService.current.rigs:
		if rig["vehicle"] == vehicle:
			return rig
	return {}



func _outlet(index: int, what: String) -> bool:
	var me: = _me()
	var line: Dictionary = HoseService.current.lines[index]

	if line["kind"] != "reel" and line["player"] == null and line.get("down") == null and not line.get("feeding", false) and line.get("relay") == null and me.get_attr("HoseRoll") == null and me.get_attr("Supply") == null:
		await _locker("Attack hose", line["rig"]["vehicle"] if line["rig"] != null else _truck())
		await _wait_until( func() -> bool: return me.get_attr("HoseRoll") == "attack", 3.0, "an attack roll in hand")
	var source: Node3D = line["source"]
	var away: = source.global_position - _truck().global_position
	away = Vector3(away.x, 0, away.z).normalized()
	me.teleport(_ground(source.global_position + away * 4.0 + Vector3(0, 2, 0)))
	await _wait(0.6)
	return await _use(line["prompt"], what)



func _supply_roll(rig: Dictionary) -> void :
	var me: = _me()
	if rig["supply"]["state"] != "stowed" or me.get_attr("HoseRoll") == "supply":
		return
	var stood: = me.global_position
	await _locker("Supply hose", rig["vehicle"])
	await _wait_until( func() -> bool: return me.get_attr("HoseRoll") == "supply", 3.0, "the supply roll in hand")
	me.teleport(stood)
	await _wait(0.6)



func _mask_up() -> void :
	var me: = _me()
	await _locker("Breathing sets", _truck())
	await _wait_until( func() -> bool: return me.get_attr("Scba", false) == true, 3.0, "a breathing set on the back")
	await _tap("mask")
	await _wait_until( func() -> bool: return me.get_attr("Mask", false) == true, 4.0, "the mask to be on")
	print("play [%s] breathing set on: %s, mask on: %s, air %s bar" % [_side, me.get_attr("Scba"), me.get_attr("Mask"), str(me.get_attr("AirBar"))])


func _host_fire() -> void :
	var calls: = CallService.current
	var fires: = FireService.current
	var me: = _me()
	var truck: = _truck()
	calls.forced = "fire"
	Config.Fire["Traits"]["Chance"] = 0.0
	VictimService.current.forced = 1
	if not _solo:
		await _crew(3 if _opt("three") else 2)
	var house: = _fire_house()
	_facts["house"] = house.position
	var weights: = {}
	for building in fires.buildings:
		weights[building] = building.weight
		building.weight = 1.0 if building == house else 0.0
	calls.hold = false
	await _wait_until( func() -> bool: return not fires.incident.is_empty() and Game.incident.get("kind", "") == "fire", 40.0, "the fire call")
	for building in fires.buildings:
		building.weight = weights[building]
	calls.forced = ""
	calls.hold = true
	var front: Dictionary = house.outside_door()
	var station: = Game.station
	var bay: = int(truck.spec["bay"])
	print("play [host] fire at %s %s: %d flames, %d inside; front door locked %s; %.0f studs from the station" % [house.name, _v(house.position), Flame.all.size(), VictimService.current.victims.size(), front["locked"], house.position.distance_to(station.door_position)])
	_mark("call")
	await _shot("alarm", truck.global_position, Vector3(30, 14, 200))

	var aboard: = await _board(truck, "DoorCabLeft")
	print("play [host] at the wheel: %s (driver %s)" % [aboard, truck.driver().display_name if truck.driver() != null else "nobody"])
	if not _solo:
		await _moment("riding", 30.0)
	if _opt("three"):
		await _moment("third riding", 30.0)
	if not station.door_open(bay):
		await _tap("veh_door")
	await _tap("veh_blue")
	await _tap("veh_siren")
	await _wait_until( func() -> bool: return station.door_open(bay) and not station.doors[bay - 1]["moving"], 6.0, "the bay door to be up")
	await _wait(0.5)
	print("play [host] bay door open %s, blue %s, siren %d; riders %s" % [station.door_open(bay), truck.blue_on, truck.siren, _riders(truck)])

	var began: = Game.now()
	var out_at: = truck.global_position + ( - truck.global_basis.z) * 60.0
	while truck.global_position.distance_to(out_at) > 22.0 and Game.now() - began < 12.0:
		_steer_at(truck, out_at, 16.0)
		await get_tree().physics_frame
	_mark("rolling")
	await _tap("veh_door")
	_road_shot()
	var got_there: = await _drive(truck, house.position)
	var took: = Game.now() - began
	if not got_there:

		_park(truck, front["lock"].global_position, 30.0)
		_fault("THE DRIVE did not get there: the pumper is stood by the house")
	print("play [host] at the call after %.0f s of driving: %.0f studs from the house; tilt %.2f" % [took, truck.global_position.distance_to(house.position), truck.global_basis.y.angle_to(Vector3.UP)])
	await _tap("veh_siren")
	await _get_out()
	_mark("arrived")
	await _shot("arrived", (truck.global_position + house.position) / 2.0, Vector3(70, 34, _bearing(house.position, truck.global_position) + 30.0))

	await _mask_up()
	if front["locked"]:
		await _locker("Halligan bar", truck)
		me.teleport(_outside(house, front, 4.0))
		await _wait(0.5)
		await _use(front["prompt"], "forcing the front door")
		await _wait_until( func() -> bool: return front["open"], 4.0, "the front door to give")
		me.teleport(_beside(truck, house.position, 10.0))
		await _locker("Halligan bar", truck)
	elif not front["open"]:
		me.teleport(_outside(house, front, 4.0))
		await _wait(0.5)
		await _use(front["prompt"], "the front door")
	print("play [host] front door: open %s, locked %s" % [front["open"], front["locked"]])
	await _outlet(0, "a line at the first outlet")
	await _wait_until( func() -> bool: return HoseService.current.line_of(me) != null, 3.0, "a line in hand")
	await _walk(_outside(house, front, 5.0))
	_mark("host in")
	_attack_shot(house, front)
	if _solo:
		_joined_shot(house, front)
	var mine: = await _fight_fire( func() -> bool: return Game.incident.is_empty() or (Flame.all.is_empty() and Ember.all.is_empty() and (fires.incident.is_empty() or _solo)), 200.0)
	print("play [host] flames out under my water: %d (FlamesOut %s); health %d; air %s bar" % [mine, str(me.get_attr("FlamesOut")), int(me.health), str(me.get_attr("AirBar"))])
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 170.0, "the call to close")
	_mark("out")
	await _wait(1.5)
	await _shot("out", house.position, Vector3(46, 22, _bearing(house.position, front["lock"].global_position)))
	print("play [host] over: cash %d, saved %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0))])

	await _walk(_outside(house, front, 6.0))
	if HoseService.current.line_of(me) != null:
		await _outlet(0, "the line back at its outlet")
	me.teleport(_beside(truck, house.position, 10.0))
	await _tap("mask")
	await _wait(1.2)
	await _locker("Breathing sets", truck)
	print("play [host] packed: line %s, set %s, mask %s" % [HoseService.current.line_of(me) != null, me.get_attr("Scba"), me.get_attr("Mask")])

	await _wait_until( func() -> bool: return not house.ruined, float(Config.Fire.RepairTime) + 6.0, "the house to be put right")
	await _wait(0.8)
	await _shot("repaired", house.position, Vector3(46, 22, _bearing(house.position, front["lock"].global_position)))
	if _solo:
		_mark("done")
		return
	await _moment("packed", 60.0)
	if _opt("three"):
		await _moment("third packed", 60.0)

	var riding: = false
	for door_name: String in truck.doors:
		if door_name != "DoorCabLeft" and not riding:
			riding = await _board(truck, door_name)
	print("play [host] riding back: %s, seat %s" % [riding, str(me.get_attr("Seat"))])
	_mark("host riding")
	await _moment("home", 200.0)
	await _wait(0.5)
	var out: = await _get_out()
	print("play [host] out of the cab as a passenger: %s; standing at %s" % [out, _v(me.global_position)])
	await _wait(1.5)
	await _shot("home", truck.global_position, Vector3(34, 16, 200))
	print("play [host] the pumper is home: %.1f studs from its place in the bay, turned %.0f degrees from square" % [truck.global_position.distance_to(truck.spec["spawn"].origin), rad_to_deg(absf(wrapf(truck.global_rotation.y - truck.spec["spawn"].basis.get_euler().y, - PI / 2, PI / 2)))])
	_mark("done")



func _joined_shot(house: Building, front: Dictionary) -> void :
	await _wait_until( func() -> bool: return Net.players.size() > 1, 200.0, "somebody to join")
	await _wait(4.0)
	Net.request("play.shot", ["joined", front["lock"].global_position, Vector3(34, 16, _bearing(house.position, front["lock"].global_position))])


func _road_shot() -> void :
	await _wait(9.0)
	Net.request("play.shot", ["driving", _truck().global_position + ( - _truck().global_basis.z) * 24.0, Vector3(46, 22, rad_to_deg(_truck().global_rotation.y) + 150.0)])


func _attack_shot(house: Building, front: Dictionary) -> void :
	if _solo:

		if not await _wait_until( func() -> bool: return _marks.has("client attacking"), 60.0):
			return
	else:
		await _moment("client attacking", 60.0)
	await _wait(1.0)
	Net.request("play.shot", ["attack", front["lock"].global_position, Vector3(30, 13, _bearing(house.position, front["lock"].global_position))])


func _client_fire() -> void :
	var me: = _me()
	var hoses: = HoseService.current
	var truck: = _truck()
	await _crew()
	await _moment("call", 80.0)
	await _wait_until( func() -> bool: return _facts.has("house") and Game.incident.get("kind", "") == "fire", 10.0, "the fire's card")
	var house: = _facts_house() as House
	var front: Dictionary = house.outside_door()
	print("play [client] the fire is at %s: %d flames here, %d inside, the sign hangs (%d)" % [house.name, Flame.all.size(), VictimService.current.victims.size(), CallMarker.all.size()])
	if _opt("late"):
		await _late_fire(house, front)
		return

	var riding: = false
	var doors: Array = truck.doors.keys()
	if _third:
		doors.reverse()
	for door_name: String in doors:
		if door_name != "DoorCabLeft" and not riding:
			riding = await _board(truck, door_name)
	print("play [%s] riding: %s, seat %s of the %s" % [_side, riding, str(me.get_attr("Seat")), truck.name])
	_mark("riding" if not _third else "third riding")
	await _moment("rolling", 30.0)
	for look in 4:
		await _wait(4.0)
		print("play [%s] on the road: at %s, moving at %.0f, seated %s; the guide shows a way of %d points; siren heard %d, blue %s" % [_side, _v(me.global_position), truck.forward_speed, me.seat != null, Guide.current.points.size(), truck.siren, truck.blue_on])
	await _moment("arrived", 200.0)
	var out: = await _get_out()
	print("play [%s] out of the cab as a passenger: %s; at %s, %.0f studs from the house" % [_side, out, _v(me.global_position), me.global_position.distance_to(house.position)])
	if _third:
		await _third_at_fire(house, front)
		return

	var rig: = _rig_of(truck)
	var hydrant: = _hydrant_by(truck)
	var intake: Node3D = truck.intake["node"]
	var away: = intake.global_position - truck.global_position
	away = Vector3(away.x, 0, away.z).normalized()
	var water: = truck.water
	print("play [client] the nearest hydrant is %.0f studs from the intake (the hose is %d long)" % [hydrant["position"].distance_to(intake.global_position), int(Config.Hose.SupplyLength)])
	me.teleport(_ground(intake.global_position + away * 4.0 + Vector3(0, 2, 0)))
	await _wait(0.6)
	await _supply_roll(rig)
	await _use(rig["supply"]["prompt"], "the supply hose at the intake")
	await _wait_until( func() -> bool: return hoses.supply_of(me) != null, 3.0, "the supply hose in hand")
	var node: Node3D = hydrant["node"]
	await _walk(_ground(node.global_position + Vector3(2.5, 2, 1.0)))
	await _wait(0.5)
	await _use(hydrant["prompt"], "the hydrant")
	var fed: = await _wait_until( func() -> bool: return hoses.supplied_by(truck) != null, 4.0, "the hydrant to feed the pumper")
	print("play [client] hydrant connected: %s (supply %s); tank %.0f L" % [fed, rig["supply"]["state"], water])
	_mark("hydrant")

	me.teleport(_beside(truck, house.position, 10.0))
	await _mask_up()
	await _outlet(1, "a line at the second outlet")
	await _wait_until( func() -> bool: return hoses.line_of(me) != null, 3.0, "a line in hand")
	print("play [client] line in hand: %s; hands '%s'" % [hoses.line_of(me) != null, me.holding])
	await _moment("host in", 60.0)
	await _walk(_outside(house, front, 7.0, 3.0))
	_mark("client attacking")
	var first: = await _fight_fire( func() -> bool: return Game.incident.is_empty(), 14.0)
	print("play [client] flames out under my water so far: %d; cash %d; health %d" % [first, int(me.get_attr("Cash", 0)), int(me.health)])

	var people: = VictimService.current
	var carried: = false
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying" or not is_instance_valid(victim.figure):
			continue
		await _search_for(house, victim)
		await _walk(victim.position() + Vector3(1.6, -1.0, 0.4))
		await _wait(0.4)
		if await _use(victim.prompt, "lifting the casualty"):
			carried = await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0, "the casualty on the shoulders")
			print("play [client] carrying: %s (%s); line still in hand: %s; hands '%s'; health %d" % [carried, victim.mode, hoses.line_of(me) != null, me.holding, int(me.health)])
			await _walk(_outside(house, front, 6.0))
			_mark("carrying")
			await _shot("carrying", me.global_position, Vector3(22, 10, _bearing(house.position, front["lock"].global_position)))
			var zone: Variant = AmbulanceService.current.zone_position()
			if zone == null:
				_fault("NO GREEN BOX")
				break
			await _walk(zone + Vector3(0, 0.5, 0))
			await _wait_until( func() -> bool: return people.carried_by(me) == null, 4.0, "the handover")
			print("play [client] handed over: cash %d; %s" % [int(me.get_attr("Cash", 0)), str(Game.incident.get("victims_out")) + " out"])
			_mark("handed")
		break

	if not Game.incident.is_empty() and ( not Flame.all.is_empty() or not Ember.all.is_empty()):
		await _outlet(1, "a line at the second outlet again")
		await _wait_until( func() -> bool: return hoses.line_of(me) != null, 3.0, "a line in hand")
		await _walk(_outside(house, front, 7.0, 3.0))
		var more: = await _fight_fire( func() -> bool: return Game.incident.is_empty(), 200.0)
		print("play [client] flames out under my water after that: %d" % more)
	await _moment("out", 240.0)
	await _wait(3.2)
	print("play [client] over: cash %d, saved %d, FlamesOut %s; health %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), str(me.get_attr("FlamesOut")), int(me.health)])

	if hoses.line_of(me) != null:
		await _outlet(1, "the line back at its outlet")
	me.teleport(_ground(node.global_position + Vector3(2.5, 2, 1.0)))
	await _wait(0.5)
	await _use(hydrant["prompt"], "taking the hose off the hydrant")
	await _wait(0.6)
	if rig["supply"]["state"] != "stowed":
		me.teleport(_ground(intake.global_position + away * 4.0 + Vector3(0, 2, 0)))
		await _wait(0.5)
		await _use(rig["supply"]["prompt"], "stowing the supply hose")
	me.teleport(_beside(truck, house.position, 10.0))
	await _tap("mask")
	await _wait(1.2)
	await _locker("Breathing sets", truck)
	print("play [client] packed: line %s, supply hose %s, set %s; tank %.0f L" % [hoses.line_of(me) != null, rig["supply"]["state"], me.get_attr("Scba"), truck.water])
	await _wait_until( func() -> bool: return not house.ruined, float(Config.Fire.RepairTime) + 8.0, "the house to be put right here")
	await _wait(2.5)
	_mark("packed")

	var driving: = await _board(truck, "DoorCabLeft")
	print("play [client] at the wheel: %s (driver here %s)" % [driving, truck.driver().display_name if truck.driver() != null else "nobody"])
	await _moment("host riding", 30.0)
	if _opt("three"):
		await _moment("third riding back", 30.0)
	var station: = Game.station
	var bay: = int(truck.spec["bay"])
	var began: = Game.now()
	var home: = await _drive(truck, station.door_position, 36.0)
	print("play [client] the way home ran out after %.0f s, %.0f studs from the station's doors: %s" % [Game.now() - began, truck.global_position.distance_to(station.door_position), home])

	if not station.door_open(bay):
		await _tap("veh_door")
		var up: = await _wait_until( func() -> bool: return station.door_open(bay), 4.0, "the bay door to answer the key")
		print("play [client] the bay door answered the key at the wheel: %s" % up)
		await _wait(2.8)
	var spawn: Transform3D = truck.spec["spawn"]
	for point: Vector3 in [Vector3(spawn.origin.x, 0, station.front + 52.0), Vector3(spawn.origin.x, 0, station.front + 16.0), Vector3(spawn.origin.x, 0, station.front - 20.0)]:
		var waited: = 0.0
		while waited < 25.0:
			var off: = _steer_at(truck, point, 13.0)
			if off < 7.0:
				break
			await get_tree().physics_frame
			waited += 1.0 / 60.0
	await _halt(truck)
	print("play [client] stopped at %s (the bay is at %s)" % [_v(truck.global_position), _v(spawn.origin)])
	await _get_out()
	_mark("home")
	await _wait(2.0)
	print("play [client] out: seat %s; the pumper is %.1f studs from its place in the bay" % [me.seat != null, truck.global_position.distance_to(spawn.origin)])
	await _moment("done", 40.0)
	await _wait(1.0)
	Game.quit()




func _third_at_fire(house: House, front: Dictionary) -> void :
	var me: = _me()
	var hoses: = HoseService.current
	var truck: = _truck()
	me.teleport(_beside(truck, house.position, 10.0, 4.0))
	await _mask_up()

	var reel: = -1
	for index in hoses.lines.size():
		var each: Dictionary = hoses.lines[index]
		if each["kind"] == "outlet" and each["player"] == null and each["rig"] != null and (reel < 0 or each["rig"]["vehicle"] == truck and hoses.lines[reel]["rig"]["vehicle"] != truck):
			reel = index
	await _outlet(reel, "a free outlet's line")
	await _wait_until( func() -> bool: return hoses.line_of(me) != null, 3.0, "a free outlet's line in hand")
	print("play [%s] a free outlet's line in hand: %s; hands '%s'" % [_side, hoses.line_of(me) != null, me.holding])
	await _moment("host in", 60.0)
	await _walk(_outside(house, front, 8.0, -3.0))
	var mine: = await _fight_fire( func() -> bool: return Game.incident.is_empty(), 200.0)
	await _moment("out", 240.0)
	await _wait(3.5)
	print("play [%s] over: flames out under my water %d; cash %d, saved %d; health %d" % [_side, mine, int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), int(me.health)])
	if hoses.line_of(me) != null:
		await _outlet(reel, "that line back")
	me.teleport(_beside(truck, house.position, 10.0, 4.0))
	await _tap("mask")
	await _wait(1.2)
	await _locker("Breathing sets", truck)
	print("play [%s] packed: line %s, set %s" % [_side, hoses.line_of(me) != null, me.get_attr("Scba")])
	_mark("third packed")
	await _moment("host riding", 80.0)
	var riding: = false
	var doors: Array = truck.doors.keys()
	doors.reverse()
	for door_name: String in doors:
		if door_name != "DoorCabLeft" and not riding:
			riding = await _board(truck, door_name)
	print("play [%s] riding back: %s, seat %s" % [_side, riding, str(me.get_attr("Seat"))])
	_mark("third riding back")
	await _moment("home", 200.0)
	await _wait(0.8)
	var out: = await _get_out()
	print("play [%s] out of the cab: %s, at %s" % [_side, out, _v(me.global_position)])
	await _moment("done", 40.0)
	await _wait(1.0)
	Game.quit()






func _left_behind() -> String:
	var said: Array = []
	var hoses: = HoseService.current
	var tools: = ToolService.current
	var cordon: = Cordon.current
	var air: = AirService.current
	var held: Array = []
	for index in hoses.lines.size():
		var line: Dictionary = hoses.lines[index]
		if line["player"] != null or is_instance_valid(line["hose"]):
			held.append("%d:%s%s" % [index, "held" if line["player"] != null else "free", " hose out" if is_instance_valid(line["hose"]) else ""])
	var supplies: Array = []
	for rig: Dictionary in hoses.rigs:
		supplies.append(rig["supply"]["state"])
	said.append("lines %s, supply hoses %s" % [held, supplies])
	var out: Array = []
	for item: Dictionary in tools.items:
		if item["tool"] != null or item["holder"] != null or item["line"].holder != null or not item["prop"]["node"].visible:
			out.append("%s (holder %s, line held %s, on its shelf %s)" % [item["name"], item["holder"] != null, item["line"].holder != null, item["prop"]["node"].visible])
	said.append("tools off their shelves %s" % [out])
	var carried: Array = []
	for item: Dictionary in cordon.items:
		if item["holder"] != null or item["line"].holder != null or not item["stowed"].visible:
			carried.append("%s (holder %s valid %s, line held %s, stowed shown %s)" % [item["name"], item["holder"] != null, is_instance_valid(item["holder"]), item["line"].holder != null, item["stowed"].visible])
	said.append("cones and tape out %s, plates kept for %d players" % [carried, tools._others.size()])
	said.append("breathing sets on the pumper %d of %d, sets worn %d" % [int(air.pool["truck"]), int(Config.Air.TruckSets), air.sets.size()])
	var seated: Array = []
	for vehicle in Vehicle.all:
		for index in vehicle.riders.size():
			if vehicle.riders[index] != null:
				seated.append("%s seat %d: %s" % [vehicle.name, index, vehicle.riders[index].display_name if is_instance_valid(vehicle.riders[index]) else "SOMEBODY GONE"])
	said.append("seats taken %s" % [seated])
	var people: Array = []
	for victim: Victim in VictimService.current.victims:
		people.append("%s%s at %s" % [victim.state, " (carrier gone)" if (victim.carrier != null and not is_instance_valid(victim.carrier)) else "", _v(victim.position())])
	said.append("victims %s; players here %d (%d in Net)" % [people, Game.players.size(), Net.players.size()])
	return " | ".join(said)


func _host_leave() -> void :
	var calls: = CallService.current
	var me: = _me()
	var truck: = _truck()
	calls.forced = "medical"
	await _crew()
	calls.hold = false
	await _wait_until( func() -> bool: return Game.incident.get("kind", "") == "medical", 40.0, "the medical call")
	var house: = LockedIn.current.house
	var door: Dictionary = house.outside_door()
	_park(truck, door["lock"].global_position)
	me.teleport(_beside(truck, house.position, 12.0, -8.0))
	_mark("parked")
	await _moment("hands full", 90.0)
	await _wait(1.0)
	var client: Player = null
	for peer: int in Net.players:
		if peer != 1:
			client = Net.players[peer]
	await _shot("full", client.global_position if client != null else me.global_position, Vector3(14, 6, 40))
	print("play [host] before they go: %s" % _left_behind())
	_mark("go")
	await _wait_until( func() -> bool: return Net.players.size() < 2, 20.0, "the client to be gone")
	await _wait(1.0)
	print("play [host] after they went: %s" % _left_behind())
	await _shot("gone", me.global_position if client == null else truck.global_position, Vector3(24, 10, 40))

	if _opt("hose"):
		await _outlet(1, "the line they held")
		await _wait(0.5)
		print("play [host] the line they held is in my hand now: %s" % (HoseService.current.line_of(me) != null))
		await _outlet(1, "that line back")
	if _opt("tool"):
		me.teleport(_beside(truck, house.position, 10.0))
		await _locker("Chainsaw", truck)
		await _locker("Cones", truck)
		print("play [host] the saw and the cones they had are mine now: Tool %s, belt %s" % [me.get_attr("Tool"), _plates(me)])
		await _locker("Cones", truck)
		await _locker("Chainsaw", truck)
		var seat_free: = await _board(truck, "DoorCabRight")
		print("play [host] the seat they sat in can be sat in: %s" % seat_free)
		await _get_out()
	if _opt("casualty"):
		var people: = VictimService.current
		if not people.victims.is_empty():
			var victim: Victim = people.victims[0]
			await _stand_by(victim.position(), Vector3(1.8, 1.0, 0.4))
			await _wait(0.5)
			await _use(victim.prompt, "lifting whoever they put down")
			await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0, "the casualty on my shoulders")
			var zone: Variant = AmbulanceService.current.zone_position()
			await _walk(zone + Vector3(0, 0.5, 0))
			await _wait_until( func() -> bool: return Game.incident.is_empty(), 20.0, "the call to close")
			print("play [host] carried the rest of the way: cash %d, saved %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0))])
	await _wait(1.0)
	print("play [host] at the end: %s" % _left_behind())
	Game.quit()


func _client_leave() -> void :
	var me: = _me()
	var truck: = _truck()
	await _crew()
	await _moment("parked", 60.0)
	var house: = _house_of_call()
	var door: Dictionary = house.outside_door()
	me.teleport(_beside(truck, house.position, 10.0))
	await _wait(0.5)
	if _opt("hose"):

		await _mask_up()
		await _outlet(1, "a line at the second outlet")
		await _wait_until( func() -> bool: return HoseService.current.line_of(me) != null, 3.0, "a line in hand")
		await _walk(_beside(truck, house.position, 24.0, 6.0))
		await _press("fire")
		await _wait(1.0)
	if _opt("tool"):
		await _locker("Axe", truck)
		await _locker("Cones", truck)
		await _locker("Chainsaw", truck)
		print("play [client] carrying: Tool %s, belt %s" % [me.get_attr("Tool"), _plates(me)])
		if _opt("seat"):
			await _slot("Chainsaw")
			await _board(truck, "DoorCabRight")
		else:
			await _walk(_beside(truck, house.position, 20.0, 6.0))
			await _press("fire")
			await _wait(0.6)
	if _opt("casualty"):
		await _locker("Halligan bar", truck)
		me.teleport(_outside(house, door, 4.0))
		await _wait(0.5)
		await _use(door["prompt"], "forcing the door")
		await _wait_until( func() -> bool: return door["open"], 4.0, "the door to give")
		var people: = VictimService.current
		var victim: Victim = people.victims[0]
		await _first_aid(victim, LockedIn.current._shown, _outside(house, door, 4.0))
		await _slot("Halligan bar")
		await _walk(victim.position() + Vector3(1.6, -1.0, 0))
		await _wait(0.5)
		await _use(victim.prompt, "lifting the casualty")
		await _wait_until( func() -> bool: return people.carried_by(me) != null, 4.0, "the casualty on the shoulders")
		await _walk(_outside(house, door, 9.0))
	print("play [client] hands full: hands '%s', Tool %s, line %s, carrying %s, set %s, seat %s, belt %s" % [me.holding, me.get_attr("Tool"), HoseService.current.line_of(me) != null, me.get_attr("Carrying"), me.get_attr("Scba"), me.seat != null, _plates(me)])
	_mark("hands full")
	await _moment("go", 30.0)
	await _wait(0.3)
	print("play [client] leaves")
	Game.quit()



func _late_crash(held: Dictionary, at: Vector3, truck: Vehicle) -> void :
	var me: = _me()
	me.teleport(_beside(truck, at, 10.0))
	await _wait(0.5)
	await _locker("Cutter")
	_cut_mark()
	for door: Dictionary in held["doors"]:
		var off: = await _work_door(door, 3, "Cutter")
		print("play [client] a door cut off: %s; cash %d" % [off, int(me.get_attr("Cash", 0))])
	_mark("cut")
	me.teleport(_beside(truck, at, 10.0))
	await _locker("Cutter")
	await _aid_and_board(held, truck, at)
	var people: = VictimService.current
	var carried: = false
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying" or not is_instance_valid(victim.figure):
			continue
		await _stand_by(victim.position(), Vector3(-2.0, 2.0, -0.6))
		await _wait(0.4)

		if victim.tag_prompt.enabled:
			await _use(victim.tag_prompt, "assessing a casualty")
			_check( await _wait_until( func() -> bool: return victim.tagged, 4.0, "the tag"), "assessed: the casualty's tag shows (%s)" % victim.tag)
		if victim.state != "lying":
			continue
		if await _use(victim.prompt, "lifting a casualty"):
			await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0, "the casualty on the shoulders")
			if not carried:
				_mark("carrying")
				carried = true
				await _wait(2.2)
			await _walk(AmbulanceService.current.zone_position() + Vector3(0, 0.5, 0))
			await _wait(1.0)
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 60.0, "the call to close")
	await _wait(1.0)
	print("play [client] over: cash %d, saved %d, hands '%s'" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), me.holding])
	await _moment("done", 40.0)
	await _wait(1.0)
	Game.quit()





func _late_fire(house: House, front: Dictionary) -> void :
	var me: = _me()
	var hoses: = HoseService.current
	var truck: = _truck()
	await _wait(2.0)
	var held: Array = []
	for index in hoses.lines.size():
		if hoses.lines[index]["player"] != null:
			held.append("%d:%s" % [index, hoses.lines[index]["player"].display_name])
	print("play [client] joined half way: the pumper is at %s (%.0f studs from the house), lines %s, hoses drawn here %s, front door open %s, card %s flames %s out, %d flames and %d embers here, victims %d, ambulance arrived %s, the host wears a mask: %s" % [
		_v(truck.global_position), truck.global_position.distance_to(house.position), held, hoses._net_hoses.keys(), front["open"], str(Game.incident.get("flames")), str(Game.incident.get("flames_out")), 
		Flame.all.size(), Ember.all.size(), VictimService.current.victims.size(), AmbulanceService.current.arrived(), _host_player().get_attr("Mask"), 
	])

	var pickup: = Vehicle.named("Command Vehicle")
	var station: = Game.station
	var bay: = int(pickup.spec["bay"])
	var driving: = await _board(pickup, "DoorCabLeft" if pickup.doors.has("DoorCabLeft") else pickup.doors.keys()[0])
	print("play [client] at the wheel of the %s: %s" % [pickup.name, driving])
	if not station.door_open(bay):
		await _tap("veh_door")
	await _tap("veh_blue")
	await _wait_until( func() -> bool: return station.door_open(bay) and not station.doors[bay - 1]["moving"], 6.0, "the bay door to be up")
	await _wait(0.5)
	print("play [client] bay door %d open: %s; blue lights %s" % [bay, station.door_open(bay), pickup.blue_on])
	var began: = Game.now()
	var out_at: = pickup.global_position + ( - pickup.global_basis.z) * 60.0
	while pickup.global_position.distance_to(out_at) > 22.0 and Game.now() - began < 12.0:
		_steer_at(pickup, out_at, 16.0)
		await get_tree().physics_frame
	var got_there: = await _drive(pickup, house.position)
	if not got_there:
		_park(pickup, front["lock"].global_position, -30.0)
		_fault("THE DRIVE did not get there: the vehicle is stood by the house")
	print("play [client] at the call after %.0f s of driving: %.0f studs from the house" % [Game.now() - began, pickup.global_position.distance_to(house.position)])
	await _get_out()
	_mark("late arrived")
	await _shot("late", (pickup.global_position + house.position) / 2.0, Vector3(60, 28, _bearing(house.position, pickup.global_position) + 30.0))
	me.teleport(_beside(truck, house.position, 10.0))
	await _mask_up()
	var people: = VictimService.current
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying" or not is_instance_valid(victim.figure):
			continue
		await _walk(_outside(house, front, 5.0))
		await _walk(victim.position() + Vector3(1.6, -1.0, 0.4))
		await _wait(0.4)
		if await _use(victim.prompt, "lifting the casualty"):
			await _wait_until( func() -> bool: return people.carried_by(me) != null, 3.0, "the casualty on the shoulders")
			await _walk(_outside(house, front, 6.0))
			_mark("carrying")
			await _shot("carrying", me.global_position, Vector3(22, 10, _bearing(house.position, front["lock"].global_position)))
			await _walk(AmbulanceService.current.zone_position() + Vector3(0, 0.5, 0))
			await _wait_until( func() -> bool: return people.carried_by(me) == null, 4.0, "the handover")
		break
	await _wait_until( func() -> bool: return Game.incident.is_empty(), 200.0, "the call to close")
	await _wait(1.5)
	print("play [client] over: cash %d, saved %d; health %d" % [int(me.get_attr("Cash", 0)), int(me.get_attr("Saved", 0)), int(me.health)])
	me.teleport(_beside(truck, house.position, 10.0))
	await _tap("mask")
	await _wait(1.2)
	await _locker("Breathing sets", truck)
	await _moment("done", 80.0)
	await _wait(1.0)
	Game.quit()





func _state_divider() -> String:
	var hoses: = HoseService.current
	var divider: = hoses.divider
	var branches: Array = []
	for branch: Dictionary in divider["lines"]:
		branches.append(branch["player"].display_name if (branch["player"] != null and is_instance_valid(branch["player"])) else "-")
	return "divider %s%s, fed %s, branches %s, %d lines in all, its shelf piece shown %s" % [
		divider["state"], (" at " + _v(divider["place"].origin.snappedf(2.0))) if divider["state"] == "placed" else "", divider["feed"] != null, branches, hoses.lines.size(), 
		divider["vehicle"].props["Divider"]["node"].visible if divider["vehicle"].props.has("Divider") else "-", 
	]


func _host_divider() -> void :
	var me: = _me()
	var truck: = _truck()
	await _crew()

	truck.global_transform = Transform3D(Basis(Vector3.UP, PI / 2), Vector3(-10, 3.0, 20))
	truck.linear_velocity = Vector3.ZERO
	truck.reset_physics_interpolation()
	me.teleport(_ground(Vector3(-10, 2, 34)))
	var burn: = _ground(Vector3(40, 2, 20))
	var made: Dictionary = FireService.current.spot(burn + Vector3(0, 0.3, 0), func(who: Variant) -> void :
		print("play [host] the fire in the yard is out, by %s" % (who.display_name if who != null else "nobody"))
	)
	made["intensity"] = 0.5
	_facts["burn"] = burn
	_mark("parked")
	await _moment("carried", 30.0)
	await _shot("carried", Vector3(-10, 2, 30), Vector3(22, 9, 20))
	await _moment("placed", 30.0)
	await _shot("placed", Vector3(12, 2, 22), Vector3(26, 12, 20))
	await _moment("spraying", 40.0)
	await _wait(1.0)
	await _shot("spraying", Vector3(22, 2, 22), Vector3(32, 14, 20))
	await _moment("stowed", 60.0)
	await _wait(1.0)
	await _shot("stowed", Vector3(0, 2, 26), Vector3(30, 13, 20))
	_mark("done")


func _client_divider() -> void :
	var me: = _me()
	var hoses: = HoseService.current
	var truck: = _truck()
	await _crew()
	await _moment("parked", 40.0)
	await _wait_until( func() -> bool: return _facts.has("burn"), 5.0)
	var burn: Vector3 = _facts["burn"]
	await _wait(1.0)
	me.teleport(_ground(Vector3(-10, 2, 32)))
	await _locker("Divider", truck)
	var divider: = hoses.divider
	print("play [client] the divider from the locker: state %s, mine %s; in the hand %s; Tool %s; hands '%s'; belt %s" % [divider["state"], divider["player"] == me, _in_hand_names(me), me.get_attr("Tool"), me.holding, _plates(me)])
	_mark("carried")
	await _wait(2.2)

	await _slot("Divider")
	print("play [client] on the belt: in the hand %s, belt %s" % [_in_hand_names(me), _plates(me)])
	await _slot("Divider")
	me.teleport(_ground(Vector3(8, 2, 22)))
	_face(burn + Vector3(0, 3, 0))
	await _wait(0.6)
	await _tap("fire")
	var placed: = await _wait_until( func() -> bool: return divider["state"] == "placed", 3.0, "the divider to be set down")
	print("play [client] set down with a click: %s; %d lines in all; belt %s; hands '%s'" % [placed, hoses.lines.size(), _plates(me), me.holding])
	_mark("placed")
	await _wait(2.0)
	if not placed:
		return

	await _outlet(0, "a line at the first outlet")
	await _wait_until( func() -> bool: return hoses.line_of(me) != null, 3.0, "a line in hand")
	var place: Transform3D = divider["place"]
	await _walk(_ground(place.origin + Vector3(-3.5, 2, 1.5)))
	await _wait(0.5)
	await _use(divider["inlet"]["prompt"], "the divider's inlet")
	var fed: = await _wait_until( func() -> bool: return divider["feed"] != null, 3.0, "the divider to be fed")
	print("play [client] fed: %s; hands '%s'" % [fed, me.holding])
	_check(fed, "the line from the pumper's outlet feeds the divider")
	var branch: Dictionary = divider["lines"][1]
	var beside: Vector3 = branch["source"].global_position + (branch["source"].global_position - place.origin).normalized() * 3.0

	await _locker("Attack hose", truck)
	await _wait_until( func() -> bool: return me.get_attr("HoseRoll") == "attack", 3.0, "an attack roll in hand for the divider")
	me.teleport(_ground(beside + Vector3(0, 2, 0)))
	await _wait(0.6)
	await _use(branch["prompt"], "a line from the divider")
	var took: = await _wait_until( func() -> bool: return hoses.line_of(me) != null, 3.0, "a line from the divider in hand")
	await _walk(_ground(burn + Vector3(-12, 2, 0)))
	_face(burn + Vector3(0, 0.8, 0))
	await _wait(0.4)
	await _press("fire")
	await _wait(1.2)
	_mark("spraying")
	var out: = await _wait_until( func() -> bool: return Flame.all.is_empty(), 35.0, "the fire in the yard to go out")
	Input.action_release("fire")
	await _wait(0.5)
	print("play [client] a line from the divider: %s; the fire is out: %s; the pumper has %.0f L" % [took, out, truck.water])
	_check(took and out, "a line from the divider puts the fire in the yard out")

	me.teleport(_ground(beside + Vector3(0, 2, 0)))
	await _wait(0.6)
	await _use(branch["prompt"], "the divider's line back")
	await _wait(0.5)
	await _outlet(0, "the feed off at the pumper's outlet")
	await _wait(0.6)
	me.teleport(_ground(place.origin + Vector3(0, 2, 4.0)))
	await _wait(0.6)
	await _use(divider["pickup"], "the divider back to the truck")
	await _wait_until( func() -> bool: return divider["state"] == "stowed", 3.0, "the divider to be back on the truck")
	print("play [client] back in the locker: state %s; %d lines in all; belt %s; hands '%s'" % [divider["state"], hoses.lines.size(), _plates(me), me.holding])
	_check(divider["state"] == "stowed", "the divider is back on the truck")
	_mark("stowed")
	await _moment("done", 30.0)
	await _wait(0.5)
	Game.quit()








func _state_talk() -> String:
	var said: Array = []
	if NetTalk.current != null:
		for entry: Array in NetTalk.current.heard:
			said.append("%s %s: %s" % entry)
	var colours: Array = []
	for player in Game.players:
		if is_instance_valid(player) and player.brain == null:
			colours.append("%s colour %d" % [player.display_name, int(player.get_attr("Colour", -1))])
	colours.sort()
	return "heard %s | colours %s" % [said, colours]



func _heard(kind: String, who: String, words: = "") -> bool:
	if NetTalk.current == null:
		return false
	for entry: Array in NetTalk.current.heard:
		if entry[0] == kind and entry[1] == who and (words.is_empty() or entry[2] == words):
			return true
	return false




func _aim(point: Vector3) -> void :
	var me: = _me()
	_face(point)
	for attempt in 4:
		await get_tree().process_frame
		await get_tree().process_frame
		var toward: = point - me.camera.camera.global_position
		me.camera.yaw = atan2( - toward.x, - toward.z)
		me.camera.pitch = asin(clampf(toward.normalized().y, -1, 1))
	await _wait(0.3)



func _crew_button() -> void :
	var pause: HudPause = HudPause.current
	pause.show_menu()

	await get_tree().create_timer(0.6, true).timeout
	print("play [%s] the pause menu's crew button says '%s'" % [_side, pause._crew_net.text])
	pause._crew_net.pressed.emit()
	await get_tree().create_timer(0.5, true).timeout


func _host_talk() -> void :
	var me: = _me()
	if _opt("version"):
		var turned: = await _wait_until( func() -> bool: return Net.turned_away > 0, 120.0, "a client of another version")
		await _wait(4.0)
		_check(turned and Net.players.size() == 1, "a client of another version is turned away and never joins (players here %d)" % Net.players.size())
		await _wait(8.0)
		Game.quit()
		return

	await _wait(1.0)
	await _crew_button()
	_check( not Net.active() and Net.left_by_choice, "the host's crew is closed from the pause menu (net %s)" % Net.active())
	await _wait(3.0)
	await _crew_button()
	_check(Net.mode == Net.HOST, "the crew is open again from the pause menu")
	await _crew(2)
	var client: Player = null
	for peer: int in Net.players:
		if peer != 1:
			client = Net.players[peer]
	_check(client != null and int(client.get_attr("Colour", -1)) != int(me.get_attr("Colour", -1)), "the client has a colour of its own (host %s, client %s)" % [me.get_attr("Colour"), client.get_attr("Colour") if client else null])

	var hydrant: Dictionary = {}
	var best: = INF
	for each: Dictionary in HoseService.current.hydrants:
		if not each.has("pump") and each["position"].distance_to(Game.station.door_position) < best:
			best = each["position"].distance_to(Game.station.door_position)
			hydrant = each
	var at: Vector3 = hydrant["position"]
	var stand: = _ground(at + Vector3(9, 2, 4))
	_facts["stand"] = stand
	_facts["hydrant"] = at
	me.teleport(stand)
	_mark("stand")
	await _wait(1.5)

	await _aim(at + Vector3(0, 0.8, 0))
	await _tap("crew_order")
	await _wait(0.6)
	_check(_heard("ping", "Hana", "Hydrant"), "G at the hydrant pings it (heard %s)" % [NetTalk.current.heard])
	await _shot("ping", at, Vector3(30, 12, 150))
	_mark("pinged")
	await _moment("client pinged", 30.0)
	await _wait(0.5)
	_check(_heard("ping", "Cene", "Hana"), "the client's ping at the host comes as one on the host")
	await _moment("radio", 30.0)
	await _wait(0.6)
	_check(_heard("radio", "Cene", "Need water!"), "the client's radio line is heard on the host")
	await _moment("chat", 30.0)
	await _wait(0.6)
	_check(_heard("chat", "Cene", "Hydrant behind the station, Hana"), "the client's typed line is in the host's messages")
	_mark("shout")
	await _tap("shout")
	await _wait(0.8)
	await _shot("talk", stand + Vector3(-4, 0, 2), Vector3(18, 7, 60))
	_check(_heard("shout", "Hana") and _heard("shout", "Cene"), "both shouts are heard on the host")
	_check(_heard("together", "Cene") or _heard("together", "Hana"), "two shouts at once: all together")
	await _moment("leaving", 40.0)
	var gone: = await _wait_until( func() -> bool: return Net.players.size() < 2, 20.0, "the client to have left the crew")
	_check(gone and Net.mode == Net.HOST, "the client left from its pause menu; the host's crew is still open")
	_mark("done")


func _client_talk() -> void :
	var me: = _me()

	_left_myself = true
	if _opt("version"):
		var refused: = await _wait_until( func() -> bool: return Net.refusal != null, 120.0, "the host's refusal")
		await _wait(1.5)
		var words: = Text.say(Net.refusal, "en") if Net.refusal != null else ""
		print("play [client] turned away: '%s'; net %s" % [words, Net.active()])
		_check(refused and words.begins_with("Could not join: the host plays version") and not Net.active(), "a client of another version is told why and plays on alone")
		_mark("done")
		await _wait(2.0)
		Game.quit()
		return

	var port: = Net.PORT
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--port="):
			port = int(arg.substr(7))
	var waited: = 0.0
	while Net.players.size() < 2 and waited < 120.0:
		if not Net.active():
			print("play [client] joining again")
			Net.join("127.0.0.1", port)
		await _wait(5.0)
		waited += 5.0
	await _crew(2)
	_check(Text.say(Net.status, "en") == "In the crew", "the join says where it stands: '%s'" % Text.say(Net.status, "en"))
	await _moment("stand", 40.0)
	await _wait_until( func() -> bool: return _facts.has("stand"), 5.0)
	var stand: Vector3 = _facts["stand"]
	me.teleport(_ground(stand + Vector3(-8, 2, 6)))
	await _moment("pinged", 30.0)
	await _wait(1.0)
	_check(_heard("ping", "Hana", "Hydrant"), "the host's ping at the hydrant comes here (heard %s)" % [NetTalk.current.heard])
	_check(NetTalk.current.pings.has(1), "the host's ping is on show here")

	var host: = _host_player()
	await _aim(host.global_position + Vector3(0, 3, 0))
	await _tap("ping")
	await _wait(0.8)
	_check(_heard("ping", "Cene", "Hana"), "R at the host pings them")
	_mark("client pinged")

	await _press("radio")
	await _wait(0.4)
	var wheel: HudRadioWheel = Hud.current.widgets["radio_wheel"]
	_check(wheel.is_open(), "Z held brings the radio wheel up")
	var motion: = InputEventMouseMotion.new()
	motion.relative = Vector2(0, -80)
	Input.parse_input_event(motion)
	await _wait(0.3)
	await _shot("wheel", me.global_position, Vector3(14, 6, 200))
	Input.action_release("radio")
	await _wait(0.8)
	_check(_heard("radio", "Cene", "Need water!") and not wheel.is_open(), "the line chosen on the wheel goes out as Z is let go")
	_mark("radio")

	var enter: = InputEventAction.new()
	enter.action = "chat"
	enter.pressed = true
	Input.parse_input_event(enter)
	await _wait(0.4)
	var chat: HudChat = Hud.current.widgets["chat"]
	_check(chat.is_open() and InputMap.action_get_events("move_forward").is_empty(), "Enter opens the chat, and the game's keys are off while it is")
	await _shot("chat", me.global_position, Vector3(14, 6, 200))
	chat.say("Hydrant behind the station, Hana")
	await _wait(0.8)
	_check( not chat.is_open() and not InputMap.action_get_events("move_forward").is_empty(), "sent, the field closes and the keys come back")
	_check(_heard("chat", "Cene", "Hydrant behind the station, Hana"), "the typed line comes back from the host")
	_mark("chat")
	await _moment("shout", 30.0)
	await _tap("shout")
	await _wait(3.4)
	_check(_heard("shout", "Hana") and _heard("shout", "Cene"), "both shouts are heard here")
	_check(_heard("together", "Cene") or _heard("together", "Hana"), "all together, here too")

	_mark("leaving")
	await _wait(1.0)
	await _crew_button()
	await _wait(1.0)
	_check( not Net.active() and Net.left_by_choice, "the client left the crew from its pause menu and plays on alone")
	_check(NetWorld.last_partial.is_empty(), "leaving by choice pays nothing for a call")
	await _wait(3.0)
	Game.quit()
