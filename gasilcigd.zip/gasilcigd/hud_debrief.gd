class_name HudDebrief
extends Control














const WIDTH: = 920.0
const LEFT: = 540.0
const RIGHT: = 300.0
const ACTION: = "call_report"
const GRADE_COLORS: = {"S": Color(1.0, 0.82, 0.25), "A": Ui.GREEN, "B": Ui.AMBER, "C": Ui.RED}

static var current: HudDebrief

var _plate: Control
var _report: Dictionary = {}
var _pending: Dictionary = {}
var _until: = 0.0
var _held: = 0.0
var _opened_by_hold: = false
var _grade: Label
var _rows: Array = []
var _tween: Tween
var _freed_mouse: = false


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not InputMap.has_action(ACTION):
		InputMap.add_action(ACTION)
		var event: = InputEventKey.new()
		event.physical_keycode = OS.find_keycode_from_string(String(settings()["Key"]))
		InputMap.action_add_event(ACTION, event)
	CallLog.listen(_on_report)
	Game.call_started.connect( func(_kind: String) -> void :
		_pending = {}
		close()
	)
	Text.language_changed.connect( func(_code: String) -> void :
		if is_open():
			_build(_report, false)
	)


static func settings() -> Dictionary:
	return Config.Alarm.EndScreen


func is_open() -> bool:
	return _plate != null and _plate.visible



func _on_report(report: Dictionary) -> void :

	_pending = {}
	if Game.local_player != null and not CallLog.mine(report).is_empty():
		_pending = report
		Game.notify(Text.f("report.ready", [Controls.key_name(ACTION)]), "", Game.local_player)



func open(report: Dictionary = {}) -> void :
	if report.is_empty():
		report = CallLog.last()
	if report.is_empty():
		return
	if report == _pending:
		_pending = {}
	_until = Game.now() + float(settings()["Time"])
	_build(report, true)


func close() -> void :
	if _tween != null and _tween.is_valid():
		_tween.kill()
	if _plate != null:
		_plate.visible = false
	if _freed_mouse:
		_freed_mouse = false
		var player: = Game.local_player
		if player != null and player.camera != null and not player.camera.captured and not Game.ui_open:
			player.camera.capture(true)



func _free_mouse() -> void :
	var player: = Game.local_player
	if player != null and player.camera != null and player.camera.captured and not Game.ui_open:
		player.camera.capture(false)
		_freed_mouse = true


func _process(delta: float) -> void :
	var player: = Game.local_player

	if InputMap.has_action(ACTION) and not Game.ui_open:
		if Input.is_action_pressed(ACTION):
			_held += delta
			if _held >= float(settings()["Hold"]) and not _opened_by_hold:
				_opened_by_hold = true
				open()
		else:
			if _held > 0.0 and _held < float(settings()["Hold"]) and is_open() and not _opened_by_hold:
				close()
			_held = 0.0
			_opened_by_hold = false

	if not _pending.is_empty() and player != null and Game.station != null and Game.incident.is_empty():
		if player.root_position().distance_to(Game.station.door_position) <= float(settings()["StationReach"]):
			open(_pending)
	if is_open():
		if Game.now() > _until:
			close()
		else:
			_plate.position = ((size - _plate.size) / 2.0).round()





func _build(report: Dictionary, animate: bool) -> void :
	_report = report
	if _plate != null:
		_plate.queue_free()
	_rows.clear()
	_plate = Ui.plate(Vector2(WIDTH, 200))
	add_child(_plate)
	Ui.stripe(_plate, WIDTH - 12)
	var margin: = MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side: String in ["left", "right", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 18)
	margin.add_theme_constant_override("margin_top", 14)
	_plate.add_child(margin)
	var column: = VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	margin.add_child(column)
	var mine: = CallLog.mine(report)


	var top: = HBoxContainer.new()
	column.add_child(top)
	var heading: = VBoxContainer.new()
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(heading)
	var kind_name: Variant = Text.m("hud.dispatch.kinds.%s.tag" % report["kind"])
	heading.add_child(Ui.caps(Text.say(Text.f("report.title", [kind_name, Alarm.numeral(int(report["level"]))])).to_upper(), int(Config.Hud.TextFloor)))
	if not Text.say(report.get("name", "")).is_empty():
		heading.add_child(Ui.label(Text.say(report["name"]), int(Config.Hud.TextFloor) + 4, Ui.TEXT))
	if not mine.is_empty():
		var total: = Ui.display(_money(int(mine["total"])), 40, Ui.AMBER if int(mine["total"]) >= 0 else Ui.RED)
		heading.add_child(total)
	var grade: String = report["grade"]
	_grade = Ui.display(grade, 96, Ui.state(GRADE_COLORS.get(grade, Ui.TEXT)))
	_grade.custom_minimum_size = Vector2(110, 100)
	_grade.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_grade.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_grade.add_theme_constant_override("outline_size", 8)
	_grade.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	top.add_child(_grade)
	var room: = Control.new()
	room.custom_minimum_size = Vector2(22, 0)
	top.add_child(room)
	_rows.append([_grade, "stamp", null])

	var body: = HBoxContainer.new()
	body.add_theme_constant_override("separation", 30)
	column.add_child(body)
	var left: = VBoxContainer.new()
	left.custom_minimum_size = Vector2(LEFT, 0)
	left.add_theme_constant_override("separation", 6)
	body.add_child(left)
	var right: = VBoxContainer.new()
	right.custom_minimum_size = Vector2(RIGHT, 0)
	right.add_theme_constant_override("separation", 4)
	body.add_child(right)


	for part: Array in report.get("parts", []):
		var row: = _part_row(report, part)
		left.add_child(row)
		_rows.append([row, "part", float(part[1])])
		if part[0] == "procedure":
			for entry: Array in report.get("checks", []):
				var check: = _check_row(entry)
				left.add_child(check)
				_rows.append([check, "line", null])
	var tip: Variant = report.get("tip")
	if tip != null:
		var tip_row: = HBoxContainer.new()
		tip_row.add_theme_constant_override("separation", 8)
		tip_row.add_child(Ui.icon("warning", 22, Ui.AMBER))
		var words: = Ui.label(Text.say(tip), int(Config.Hud.TextFloor) + 2, Ui.AMBER)
		words.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		words.custom_minimum_size = Vector2(LEFT - 34, 0)
		tip_row.add_child(words)
		left.add_child(tip_row)
		_rows.append([tip_row, "line", null])


	right.add_child(Ui.caps(Text.say(Text.m("report.pay.heading")).to_upper(), int(Config.Hud.TextFloor)))
	if mine.is_empty() or int(mine["earned"]) <= 0:
		var none: = Ui.label(Text.say(Text.m("report.pay.none")), int(Config.Hud.TextFloor), Ui.DIM)
		right.add_child(none)
		_rows.append([none, "pay", null])
	else:
		var items: Dictionary = mine["items"]
		for item: String in ["flameOut", "people", "bonus", "containment", "work"]:
			if int(items.get(item, 0)) > 0:
				var line: = _pay_row(Text.say(Text.m("report.pay." + item)), int(items[item]), Ui.TEXT)
				right.add_child(line)
				_rows.append([line, "pay", null])
		var multiplier: = String.num(float(report["multiplier"]), 2).trim_suffix("0").trim_suffix(".0")
		var share: = _pay_row(Text.say(Text.f("report.pay.grade", [grade, multiplier])), int(mine["grade_pay"]), Ui.state(GRADE_COLORS.get(grade, Ui.TEXT)))
		right.add_child(share)
		_rows.append([share, "pay", null])
		var sum: = _pay_row(Text.say(Text.m("report.pay.total")).to_upper(), int(mine["total"]), Ui.AMBER, true)
		right.add_child(sum)
		_rows.append([sum, "pay", null])
	if not mine.is_empty():
		var rank: = _rank_block(report, mine)
		right.add_child(rank)
		_rows.append([rank, "rank", _promoted(mine)])
		var training: = _training_block()
		if training != null:
			right.add_child(training)
			_rows.append([training, "line", null])


	var crew: Array = report.get("crew", [])
	if crew.size() >= 2:
		column.add_child(Ui.caps(Text.say(Text.m("report.crew.heading")).to_upper(), int(Config.Hud.TextFloor)))
		for line: Dictionary in crew:
			var row: = _crew_row(line)
			column.add_child(row)
			_rows.append([row, "line", null])

	var key: = Controls.key_name(ACTION)
	column.add_child(Ui.caps(Text.say(Text.f("report.keys", [key + " / " + Controls.key_name("pause"), key])), int(Config.Hud.CapsFloor)))

	for part: Node in _plate.find_children("*", "Control", true, false):
		(part as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_close_button())
	_plate.size = Vector2(WIDTH, margin.get_combined_minimum_size().y)
	margin.size = _plate.size
	_plate.position = ((size - _plate.size) / 2.0).round()
	_plate.visible = true
	if animate:
		_tick_in()
		_free_mouse()



func _close_button() -> Button:
	var button: = Button.new()
	button.name = "Close"
	button.text = "✕"
	button.flat = true
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_filter = Control.MOUSE_FILTER_STOP
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.add_theme_font_override("font", Ui.label_font())
	button.add_theme_font_size_override("font_size", 26)
	for state: String in ["font_color", "font_focus_color"]:
		button.add_theme_color_override(state, Ui.DIM)
	button.add_theme_color_override("font_hover_color", Ui.TEXT)
	button.add_theme_color_override("font_pressed_color", Ui.AMBER)
	button.size = Vector2(40, 40)
	button.position = Vector2(WIDTH - 44, 4)
	button.pressed.connect( func() -> void :
		Sounds.ui("ui_click")
		close()
	)
	return button


func _part_row(report: Dictionary, part: Array) -> Control:
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var weakest: bool = part[0] == report.get("weakest", "")
	var words: = Ui.label(_part_words(report, part[0]), int(Config.Hud.TextFloor) + 2, Ui.AMBER if weakest else Ui.TEXT)
	words.custom_minimum_size = Vector2(260, 0)
	words.clip_text = true
	words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	row.add_child(words)
	var track: = Ui.bar(Vector2(120, 14), _part_color(float(part[1])))
	track.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	Ui.set_bar(track, float(part[1]))
	row.add_child(track)
	row.set_meta("bar", track)
	var percent: = Ui.label("%d%%" % int(round(float(part[1]) * 100.0)), int(Config.Hud.TextFloor), Ui.DIM)
	percent.custom_minimum_size = Vector2(44, 0)
	row.add_child(percent)
	if weakest:
		row.add_child(Ui.caps(Text.say(Text.m("report.weakest")), int(Config.Hud.CapsFloor)))
		(row.get_child(row.get_child_count() - 1) as Label).add_theme_color_override("font_color", Ui.AMBER)
	return row


static func _part_color(share: float) -> Color:
	return Ui.state(Ui.GREEN if share >= 0.75 else (Ui.AMBER if share >= 0.4 else Ui.RED))



static func _part_words(report: Dictionary, id: String) -> String:
	match id:
		"turnout":
			if float(report["turnout"]) < 0.0:
				return Text.say(Text.m("report.parts.turnoutNone"))
			return Text.say(Text.f("report.parts.turnout", [Alarm.clock(report["turnout"]), Alarm.clock(report["expected"])]))
		"people":
			return Text.say(Text.f("report.parts.people", [int(report["people"][0]), int(report["people"][1])]))
		"building":
			var stars: = int(report.get("stars", 0))
			var line: = Text.say(Text.f("report.parts.building", [int(round(float(report["health"])))]))
			return line + ("  " + "★".repeat(stars) + "☆".repeat(3 - stars) if stars > 0 else "")
		"outcome":
			return Text.say(Text.m("report.parts.outcomeFailed" if report["failed"] else "report.parts.outcome"))
		"safety":
			return Text.say(Text.f("report.parts.safety", [int(round(float(report["injuries"])))]))
		"job":
			var job: Array = report["job"]
			if float(job[0]) < 0.0:
				return Text.say(Text.f("report.parts.jobUndone", [Alarm.clock(job[1])]))
			return Text.say(Text.f("report.parts.job", [Alarm.clock(job[0]), Alarm.clock(job[1])]))
		"procedure":
			var checks: Array = report.get("checks", [])
			var passed: = 0
			for entry: Array in checks:
				passed += int(bool(entry[1]))
			return Text.say(Text.f("report.parts.procedure", [passed, checks.size()]))
	return id


func _check_row(entry: Array) -> Control:
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var spacer: = Control.new()
	spacer.custom_minimum_size = Vector2(14, 0)
	row.add_child(spacer)
	row.add_child(Ui.icon("check" if entry[1] else "warning", 18, Ui.state(Ui.GREEN if entry[1] else Ui.RED)))
	row.add_child(Ui.label(Text.say(Text.m("report.checks.%s.name" % entry[0])), int(Config.Hud.TextFloor), Ui.TEXT if entry[1] else Ui.DIM))
	return row


func _pay_row(words: String, amount: int, color: Color, big: = false) -> Control:
	var row: = HBoxContainer.new()
	var name_label: = Ui.label(words, int(Config.Hud.TextFloor) + (4 if big else 0), color)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_label)
	var sum: = Ui.display(_money(amount), 22 if big else 18, color)
	sum.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(sum)
	return row


static func _money(amount: int) -> String:
	return Ui.money(amount, true)



func _rank_block(report: Dictionary, mine: Dictionary) -> Control:
	var block: = VBoxContainer.new()
	block.add_theme_constant_override("separation", 4)
	var spacer: = Control.new()
	spacer.custom_minimum_size = Vector2(0, 6)
	block.add_child(spacer)
	var after: = int(mine["points_before"]) + int(mine["points"])
	var ranks: Array = Config.Gear.Ranks
	var index: = Alarm.rank_of(after)
	var rank_name: = Text.say(Text.named("ranks", ranks[index]["sheet"]))
	block.add_child(Ui.label(Text.say(Text.f("report.rank.points", [int(mine["points"])])), int(Config.Hud.TextFloor) + 2, Ui.YELLOW))
	var from: = int(ranks[index]["saved"])
	var share: = 1.0
	if index + 1 < ranks.size():
		var to: = int(ranks[index + 1]["saved"])
		share = float(after - from) / maxf(float(to - from), 1.0)
		block.add_child(Ui.label(Text.say(Text.f("report.rank.progress", [rank_name, after, to])), int(Config.Hud.TextFloor), Ui.TEXT))
	else:
		block.add_child(Ui.label(Text.say(Text.f("report.rank.top", [rank_name, after])), int(Config.Hud.TextFloor), Ui.TEXT))
	var track: = Ui.bar(Vector2(RIGHT, 10), Ui.RANK_COLORS.get(ranks[index]["sheet"], Ui.YELLOW))
	Ui.set_bar(track, share)
	block.add_child(track)
	if _promoted(mine):
		block.add_child(Ui.label(Text.say(Text.f("report.rank.up", [rank_name])), int(Config.Hud.TextFloor) + 2, Ui.YELLOW))
	if Game.local_player != null:
		block.add_child(Ui.label(Text.say(Text.f("report.rank.lives", [int(Game.local_player.get_attr("Lives", 0))])), int(Config.Hud.TextFloor), Ui.TEXT))
	var best_now: String = report["grade"] if mine["new_best"] else String(mine["best"])
	block.add_child(Ui.label(Text.say(Text.f("report.rank.best", [best_now])), int(Config.Hud.TextFloor), Ui.TEXT))
	if mine["new_best"]:
		block.add_child(Ui.label(Text.say(Text.m("report.rank.newBest")), int(Config.Hud.TextFloor), Ui.GREEN))
	return block




func _training_block() -> Control:
	var player: = Game.local_player
	if player == null:
		return null
	var block: = VBoxContainer.new()
	block.add_theme_constant_override("separation", 4)
	var spacer: = Control.new()
	spacer.custom_minimum_size = Vector2(0, 6)
	block.add_child(spacer)
	block.add_child(Ui.caps(Text.say(Text.m("report.training.heading")).to_upper(), int(Config.Hud.TextFloor)))
	var goal: = Training.next_goal(player)
	if goal.is_empty():
		block.add_child(Ui.label(Text.say(Text.m("report.training.done")), int(Config.Hud.TextFloor), Ui.GREEN))
		return block
	var named: Variant = Text.m("training.skills.%s.name" % goal["id"])
	var cash: = int(player.get_attr("Cash", 0))
	var price: = int(goal["price"])
	if cash >= price:
		var ready: = Ui.label(Text.say(Text.f("report.training.ready", [named, int(goal["level"]), Ui.money(price)])), int(Config.Hud.TextFloor), Ui.GREEN)
		ready.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ready.custom_minimum_size = Vector2(RIGHT, 0)
		block.add_child(ready)
		return block
	block.add_child(Ui.label(Text.say(Text.f("report.training.next", [named, int(goal["level"]), Ui.money(price - cash)])), int(Config.Hud.TextFloor), Ui.TEXT))
	var track: = Ui.bar(Vector2(RIGHT, 10), Ui.AMBER)
	Ui.set_bar(track, float(cash) / float(price))
	block.add_child(track)
	return block


static func _promoted(mine: Dictionary) -> bool:
	var before: = int(mine["points_before"])
	return Alarm.rank_of(before + int(mine["points"])) > Alarm.rank_of(before)


func _crew_row(line: Dictionary) -> Control:
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var who: = Ui.label(String(line["name"]), int(Config.Hud.TextFloor) + 2, Ui.YELLOW if int(line["peer"]) == Net.my_id() else Ui.TEXT)
	who.custom_minimum_size = Vector2(150, 0)
	who.clip_text = true
	who.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	row.add_child(who)
	var metres: = Ui.length(float(line["hose"]) * float(Config.Hud.MetresPerStud))
	row.add_child(Ui.label(Text.say(Text.f("report.crew.line", [int(line["flames"]), int(line["carried"]), metres, int(line["doors"]), Alarm.clock(line["air"]), int(line["total"])])), int(Config.Hud.TextFloor), Ui.TEXT))
	if not String(line["title"]).is_empty():
		row.add_child(Ui.label(Text.say(Text.m("report.titles." + String(line["title"]))).to_upper(), int(Config.Hud.TextFloor), Ui.AMBER))
	return row







func _tick_in() -> void :
	var step: = float(settings()["Step"])
	for entry: Array in _rows:
		(entry[0] as Control).modulate.a = 0.0
	_tween = create_tween()
	var ticks: = 0
	var stamped: = false
	for entry: Array in _rows:
		var row: Control = entry[0]
		var kind: String = entry[1]
		if kind == "stamp":
			continue

		if not stamped and kind in ["pay", "rank"]:
			stamped = true
			_stamp(step)
		_tween.tween_interval(step if kind != "line" else step * 0.4)
		if kind == "part":
			ticks += 1
			var pitch: = 1.0 + 0.08 * ticks
			var share: float = entry[2]
			_tween.tween_callback( func() -> void :
				row.modulate.a = 1.0
				Sounds.ui("ui_tick", pitch)
				var track: Control = row.get_meta("bar")
				create_tween().tween_method( func(value: float) -> void : Ui.set_bar(track, value), 0.0, share, step * 0.9)
			)
		elif kind == "pay":
			_tween.tween_callback( func() -> void :
				row.modulate.a = 1.0
				Sounds.ui("ui_coin", 1.0 + 0.05 * ticks)
			)
		elif kind == "rank":
			var promoted: bool = entry[2]
			_tween.tween_callback( func() -> void :
				row.modulate.a = 1.0
				Sounds.ui("ui_fanfare" if promoted else "ui_tick", 1.0 if promoted else 0.8)
			)
		else:
			_tween.tween_callback( func() -> void : row.modulate.a = 1.0)
	if not stamped:
		_stamp(step)


func _stamp(step: float) -> void :
	var grade: = _grade
	_tween.tween_interval(step)
	_tween.tween_callback( func() -> void :
		grade.pivot_offset = grade.size / 2.0
		grade.scale = Vector2(2.2, 2.2)
		grade.modulate.a = 1.0
	)
	_tween.tween_property(grade, "scale", Vector2.ONE, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_tween.tween_callback( func() -> void : Sounds.ui("ui_stamp"))



func shown_text() -> String:
	if not is_open():
		return ""
	var lines: Array[String] = []
	for label: Label in _plate.find_children("*", "Label", true, false):
		if not label.text.is_empty():
			lines.append(label.text)
	return "\n".join(lines)
