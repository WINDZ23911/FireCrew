class_name CouplingMarks
extends Node







const REACH: = 90.0
const MOST: = 10
const LOOK_EVERY: = 0.25
const RING: = 2.4
const BEAM: = Vector2(1.6, 6.0)

static var current: CouplingMarks

var _marks: Array = []
var _kinds: Dictionary = {}
var _since: = 0.0
var _ring_material: ShaderMaterial
var _beam_material: ShaderMaterial


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	_ring_material = ShaderMaterial.new()
	_ring_material.shader = load("res://shaders/focus_ring.gdshader")
	_ring_material.set_shader_parameter("tint", Ui.BLUE)
	_beam_material = ShaderMaterial.new()
	_beam_material.shader = load("res://shaders/coupling_beam.gdshader")
	_beam_material.set_shader_parameter("tint", Ui.BLUE)



func shown_kinds() -> Array:
	return _kinds.keys()


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var wanted: = _wanted()
	_kinds.clear()
	for index in wanted.size():
		_kinds[wanted[index][1]] = int(_kinds.get(wanted[index][1], 0)) + 1
	while _marks.size() < mini(wanted.size(), MOST):
		_marks.append(_make())
	for index in _marks.size():
		var mark: Array = _marks[index]
		var on: = index < wanted.size()
		(mark[0] as Node3D).visible = on
		(mark[1] as Node3D).visible = on
		if on:
			var at: Vector3 = (wanted[index][0] as Node3D).global_position
			(mark[0] as Node3D).global_position = at
			(mark[1] as Node3D).global_position = at + Vector3(0, BEAM.y / 2.0, 0)



func _wanted() -> Array:
	var player: = Game.local_player
	var hoses: = HoseService.current
	if player == null or hoses == null or player.health <= 0.0 or player.seat != null or player.get_attr("Line") != null:
		return []
	var roll: Variant = player.get_attr("HoseRoll")
	var from_truck: bool = player.get_attr("Supply") != null
	var from_hydrant: bool = player.get_attr("SupplyLoose", false) == true
	var found: Array = []
	var here: = player.global_position
	if roll == "attack":
		for line: Dictionary in hoses.lines:
			if line["kind"] == "outlet" and line["player"] == null and line.get("relay") == null and not is_instance_valid(line.get("hose")):
				_near(found, line["source"], "outlet", here)
		var inlet: Variant = hoses.divider.get("inlet")
		if inlet is Dictionary and inlet.get("node") is Node3D:
			_near(found, inlet["node"], "divider", here)
	if roll == "supply" or from_hydrant:
		for rig: Dictionary in hoses.rigs:
			var vehicle: Vehicle = rig["vehicle"]
			if rig["supply"]["state"] == "stowed" and not vehicle.intake.is_empty():
				_near(found, vehicle.intake["node"], "intake", here)
	if roll == "supply" or from_truck:
		for hydrant: Dictionary in hoses.hydrants:
			if hydrant["rig"] == null and hydrant.get("loose") == null and not hydrant.has("pump"):
				_near(found, hydrant["node"], "hydrant", here)
	found.sort_custom( func(a: Array, b: Array) -> bool: return a[2] < b[2])
	return found


func _near(into: Array, node: Node3D, kind: String, here: Vector3) -> void :
	if node == null or not is_instance_valid(node) or not node.is_inside_tree():
		return
	var distance: = node.global_position.distance_to(here)
	if distance <= REACH:
		into.append([node, kind, distance])


func _make() -> Array:
	var ring: = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE * RING
	ring.mesh = quad
	ring.material_override = _ring_material
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ring.top_level = true
	ring.visible = false
	add_child(ring)
	var beam: = MeshInstance3D.new()
	var column: = QuadMesh.new()
	column.size = BEAM
	beam.mesh = column
	beam.material_override = _beam_material
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam.top_level = true
	beam.visible = false
	add_child(beam)
	return [ring, beam]
