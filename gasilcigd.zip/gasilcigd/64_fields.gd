extends RefCounted




const BALE_GROUPS: = 16
const BALE_SPREAD: = 300.0
const RACKS: = 4
const FENCE_CHANCE: = 0.3
const FENCE_GAP: = 8.0
const ROADS: = ["primary", "secondary", "tertiary", "residential", "track"]

const HAY: = Color8(214, 190, 110)
const OLD_HAY: = Color8(178, 160, 104)
const RACK_WOOD: = Color8(104, 78, 54)
const FENCE_WOOD: = Color8(128, 98, 70)
const WIRE: = Color8(96, 98, 100)


static func apply(kit: PolishKit) -> String:
	var bales: = _bales(kit)
	var racks: = _racks(kit)
	var fences: = _fences(kit)
	return "%d bales, %d hay racks, %d fence posts" % [bales, racks, fences]



static func _fields(kit: PolishKit, seed_name: String) -> Array:
	var rows: Array = []
	for row in kit.rows_under("Map/Surfaces"):
		if kit.store.name_at(row) == "field":
			rows.append(row)
	var rng: = kit.rng(seed_name)
	for index in range(rows.size() - 1, 0, -1):
		var other: = rng.randi_range(0, index)
		var keep: int = rows[index]
		rows[index] = rows[other]
		rows[other] = keep
	return rows


static func _bales(kit: PolishKit) -> int:
	var parent: = kit.own_folder("Bales")
	var rng: = kit.rng("bales")
	var groups: Array = []
	var made: = 0
	for row: int in _fields(kit, "bale fields"):
		if groups.size() >= BALE_GROUPS:
			break
		var place: = kit.store.transform(row)
		var size: = kit.store.size(row)
		if maxf(size.x, size.z) < 50.0:
			continue
		var middle: = place.origin
		var far: = true
		for other: Vector3 in groups:
			if other.distance_to(middle) < BALE_SPREAD:
				far = false
		if not far:
			continue
		var long_way: = place.basis.x.normalized() if size.x > size.z else place.basis.z.normalized()
		var reach: = maxf(size.x, size.z) * 0.4
		var count: = rng.randi_range(3, 7)
		var laid: = 0
		for tries in count * 3:
			if laid >= count:
				break
			var at: = middle + long_way * rng.randf_range( - reach, reach) + long_way.cross(Vector3.UP) * rng.randf_range(-14.0, 14.0)
			at.y = 0.0
			if kit.surface_at(at) != "field" or not kit.open_ground(at, 4.6):
				continue
			var yaw: = rng.randf_range(0.0, TAU)
			var axis: = Vector3(cos(yaw), 0, sin(yaw))
			var color: = HAY.lerp(OLD_HAY, rng.randf())
			kit.rod(parent, at - axis * 2.75 + Vector3(0, 3.1, 0), at + axis * 2.75 + Vector3(0, 3.1, 0), 6.4, color, "Grass", "HayBale", PolishKit.SOLID)
			laid += 1
		if laid > 0:
			groups.append(middle)
			made += laid
	return made



static func _racks(kit: PolishKit) -> int:
	var parent: = kit.own_folder("HayRacks")
	var placed: Array = []
	for feature: Dictionary in kit.layout()["features"]:
		if feature["kind"] == "hayrack":
			placed.append(Vector3(float(feature["x"]), 0, float(feature["z"])))
	var made: = 0
	for row: int in _fields(kit, "hay racks"):
		if made >= RACKS:
			break
		var place: = kit.store.transform(row)
		var size: = kit.store.size(row)
		if maxf(size.x, size.z) < 50.0:
			continue
		var long_way: = place.basis.x.normalized() if size.x > size.z else place.basis.z.normalized()
		var reach: = maxf(size.x, size.z) / 2.0
		for end: float in [-1.0, 1.0]:

			var middle: = place.origin + long_way * end * (reach - 6.0)
			middle.y = 0.0
			var far: = true
			for other: Vector3 in placed:
				if other.distance_to(middle) < 350.0:
					far = false
			if not far or kit.building_distance(middle, 60.0) < 60.0:
				continue
			var across: = long_way.cross(Vector3.UP)
			var room: = true
			for step in range(-4, 5):
				if not kit.open_ground(middle + across * (step * 4.0), 3.0):
					room = false
					break
			if not room:
				continue
			_rack(kit, parent, PolishKit.facing(middle, long_way))
			placed.append(middle)
			made += 1
			break
	return made



static func _rack(kit: PolishKit, parent: int, place: Transform3D) -> void :
	for index in 4:
		kit.box(parent, place.translated_local(Vector3(index * 9 - 13.5, 7.5, 0)), Vector3(0.9, 15, 0.9), RACK_WOOD, "Wood", "RackPost", PolishKit.SOLID)
	for rail in range(1, 7):
		kit.box(parent, place.translated_local(Vector3(0, rail * 2.1, 0)), Vector3(28, 0.4, 0.4), RACK_WOOD, "Wood", "RackRail")
	kit.box(parent, place.translated_local(Vector3(0, 5.6, 0)), Vector3(26, 7.5, 1.6), HAY, "Grass", "Hay")
	for turn: float in [0.0, PI]:
		var roof: = Transform3D(place.basis * Basis(Vector3.UP, turn), place.origin)
		kit.wedge(parent, roof.translated_local(Vector3(0, 16.3, -2)), Vector3(31, 2.6, 4), Color8(150, 70, 52), "ClayRoofTiles", "RackRoof")



static func _fences(kit: PolishKit) -> int:
	var parent: = kit.own_folder("Fences")
	var rng: = kit.rng("fences")
	var posts: = 0
	for road: Dictionary in kit.layout()["roads"]:
		if not ROADS.has(road["class"]):
			continue
		var half: = float(road["width"]) / 2.0
		var side: = 1.0 if rng.randf() < 0.5 else -1.0
		var left: = 0
		var wired: = false
		var last: = Vector3.INF
		for spot: Array in PolishKit.along_road(road["points"], FENCE_GAP):
			var on_road: Vector3 = spot[0]
			var way: Vector3 = spot[1]
			if left <= 0:
				last = Vector3.INF
				if rng.randf() < FENCE_CHANCE / 6.0 and kit.country_road(on_road, way, half, 80.0):
					left = rng.randi_range(14, 40)
					wired = rng.randf() < 0.5
					side = - side
				continue
			var foot: = on_road + way.cross(Vector3.UP) * side * (half + 13.0)
			if not kit.country_road(on_road, way, half, 80.0) or not kit.open_ground(foot, 0.9):
				left = 0
				continue
			kit.box(parent, PolishKit.facing(foot + Vector3(0, 2.2, 0), way), Vector3(0.45, 4.4, 0.45), FENCE_WOOD.darkened(rng.randf() * 0.15), "Wood", "FencePost", PolishKit.FIXTURE)
			posts += 1
			if last != Vector3.INF and last.distance_to(foot) < FENCE_GAP * 1.5:
				for height: float in ([1.6, 3.0] if wired else [1.5, 3.2]):
					var from: = last + Vector3(0, height, 0)
					var to: = foot + Vector3(0, height, 0)
					if wired:
						kit.rod(parent, from, to, 0.07, WIRE, "Metal", "FenceWire")
					else:
						kit.box(parent, PolishKit.facing((from + to) / 2.0, to - from), Vector3(0.22, 0.4, from.distance_to(to) + 0.4), FENCE_WOOD, "Wood", "FenceRail")

			if rng.randf() < 0.08:
				var bush: = foot + way.cross(Vector3.UP) * side * 1.6
				var green: = Color8(66, 112, 58).lerp(Color8(104, 140, 66), rng.randf())
				var size: = rng.randf_range(3.5, 5.5)
				kit.ball(parent, bush + Vector3(0, size * 0.35, 0), Vector3.ONE * size, green, "LeafyGrass", "FenceBush")
				kit.ball(parent, bush + way * 2.0 + Vector3(0, size * 0.25, 0), Vector3.ONE * size * 0.7, green.darkened(0.08), "LeafyGrass", "FenceBush")
			last = foot
			left -= 1
	return posts
