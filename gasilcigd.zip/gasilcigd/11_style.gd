extends RefCounted



static func start(main: Node) -> void :
	Style.from_command_line()
	var style: = Style.new()
	style.name = "Style"
	main.add_child(style)
