extends RefCounted







static func start(main: Node) -> void :
	var steps: = NextSteps.new()
	steps.name = "NextSteps"
	main.add_child(steps)
	var shift: = FirstShift.new()
	shift.name = "FirstShift"
	main.add_child(shift)
	var tutorial: = Tutorial.new()
	tutorial.name = "Tutorial"
	main.add_child(tutorial)
	if Hud.current:

		for widget: Control in [HudChecklist.new(), HudStepBanner.new(), HudRankUp.new()]:
			Hud.current.root.add_child(widget)
	var title: Node = main.get_node_or_null("Title")
	if title is TitleScreen:
		(title as TitleScreen).started.connect( func() -> void :
			if not Tutorial.offered():
				return
			if (title as TitleScreen).tutorial_wanted:
				tutorial.begin.call_deferred()
			else:
				PlayerData.finish_first_shift()
		)
	elif OS.get_cmdline_user_args().has("--tutorial") or OS.get_cmdline_user_args().has("--first-shift"):
		for arg in OS.get_cmdline_user_args():
			if arg.begins_with("--scenario"):
				return
		if OS.get_cmdline_user_args().has("--tutorial"):
			tutorial.begin.call_deferred()
		else:
			shift.begin.call_deferred()
