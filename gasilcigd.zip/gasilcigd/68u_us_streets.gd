extends RefCounted










const YELLOW_LINE: = Color8(232, 184, 30)
const HYDRANT_YELLOW: = Color8(236, 190, 32)
const HYDRANT_STEEL: = Color8(196, 198, 200)
const HYDRANT_BODY: = ["Hydrant", "Head", "Collar", "Cap", "Coupling", "Band"]
const HYDRANT_CAPS: = ["CouplingCap", "Nut"]
const MAILBOX: = Color8(26, 26, 28)
const POST_WHITE: = Color8(240, 238, 232)
const FLAG_RED: = Color8(178, 34, 52)
const FLAG_WHITE: = Color8(244, 244, 240)
const FLAG_BLUE: = Color8(40, 52, 108)
const CELL: = 40.0
const CENTRE_REACH: = 1.1


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "us":
		return ""
	var layout: = kit.layout()
	var grid: = _road_grid(layout["roads"])
	var lines: = _centre_lines(kit, grid)
	var hydrants: = _hydrants(kit)
	var folder: = kit.own_folder("UsStreets")
	var boxes: = _mailboxes(kit, folder, layout, grid)
	var flags: = _porch_flags(kit, folder)
	return "USA streets: %d centre line strips yellow, %d hydrants, %d mailboxes, %d porch flags" % [lines, hydrants, boxes, flags]



static func _road_grid(roads: Array) -> Dictionary:
	var grid: = {}
	for road: Dictionary in roads:
		var points: Array = road["points"]
		for index in points.size() - 1:
			var a: = Vector2(float(points[index][0]), float(points[index][1]))
			var b: = Vector2(float(points[index + 1][0]), float(points[index + 1][1]))
			var steps: = int(a.distance_to(b) / CELL) + 1
			var filed: = {}
			for step in steps + 1:
				var at: = a.lerp(b, float(step) / steps)
				var key: = Vector2i(floori(at.x / CELL), floori(at.y / CELL))
				for dx in [-1, 0, 1]:
					for dz in [-1, 0, 1]:
						var near: = key + Vector2i(dx, dz)
						if filed.has(near):
							continue
						filed[near] = true
						if not grid.has(near):
							grid[near] = []
						grid[near].append([a, b, float(road["width"]), int(road["rank"])])
	return grid



static func _nearest_road(grid: Dictionary, at: Vector2) -> Array:
	var best: = [INF, 0.0, 0]
	for segment: Array in grid.get(Vector2i(floori(at.x / CELL), floori(at.y / CELL)), []):
		var on: = Geometry2D.get_closest_point_to_segment(at, segment[0], segment[1])
		var distance: = on.distance_to(at)
		if distance < best[0]:
			best = [distance, segment[2] / 2.0, segment[3]]
	return best


static func _centre_lines(kit: PolishKit, grid: Dictionary) -> int:
	var store: = kit.store
	var count: = 0
	for row in store.rows_named("paint"):
		var size: = store.size(row)
		if minf(size.x, size.z) > 0.7:
			continue
		var at: = store.position(row)
		var road: = _nearest_road(grid, Vector2(at.x, at.z))
		if road[0] < CENTRE_REACH and road[2] >= 1:
			store.set_color(row, YELLOW_LINE)
			count += 1
	return count


static func _hydrants(kit: PolishKit) -> int:
	var store: = kit.store
	var count: = 0
	for row in store.count:
		var part: = store.name_at(row)
		if not (part in HYDRANT_BODY or part in HYDRANT_CAPS):
			continue
		var parent: Dictionary = store.nodes.get(store.parent(row), {})
		if parent.get("n", "") != "HydrantPost":
			continue
		if part in HYDRANT_CAPS:
			store.set_color(row, HYDRANT_STEEL)
		else:
			store.set_color(row, HYDRANT_YELLOW)
			if part == "Hydrant":
				count += 1
	return count



static func _mailboxes(kit: PolishKit, folder: int, layout: Dictionary, grid: Dictionary) -> int:
	var count: = 0
	for strip: Dictionary in layout["strips"]:
		if strip["kind"] != "path":
			continue
		var middle: = Vector2(float(strip["x"]), float(strip["z"]))
		var yaw: = deg_to_rad(float(strip["yaw"]))
		var along: = Vector2(sin(yaw), cos(yaw))
		var half: = float(strip["length"]) / 2.0
		var ends: = [middle + along * half, middle - along * half]
		var street: Vector2 = ends[0] if _nearest_road(grid, ends[0])[0] < _nearest_road(grid, ends[1])[0] else ends[1]
		var inward: = (middle - street).normalized()
		var side: = Vector2( - inward.y, inward.x) * (float(strip["width"]) / 2.0 + 1.6)
		var foot2: = street + inward * 1.5 + side
		var foot: = Vector3(foot2.x, 0, foot2.y)
		if not StreetKit.clear_below(kit, foot, 0.6, 4.5, 0.65):
			continue
		var facing: = PolishKit.facing(foot, Vector3( - inward.x, 0, - inward.y))
		kit.post(folder, foot, 3.6, 0.32, POST_WHITE, "Wood", "MailboxPost")
		kit.box(folder, facing.translated_local(Vector3(0, 3.95, 0)), Vector3(0.95, 0.75, 1.9), MAILBOX, "Metal", "Mailbox")
		kit.box(folder, facing.translated_local(Vector3(0.5, 4.2, 0.4)), Vector3(0.06, 0.6, 0.14), FLAG_RED, "SmoothPlastic", "MailboxFlag")
		count += 1
	return count



static func _porch_flags(kit: PolishKit, folder: int) -> int:
	var store: = kit.store
	var count: = 0
	var done: = {}
	for row in store.rows_named("PorchPost"):
		var model: = store.parent(row)
		if done.has(model):
			continue
		done[model] = true
		var at: = store.position(row)
		if rand_from_seed(hash([int(at.x), int(at.z), "flag"]))[0] %5 != 0:
			continue
		var size: = store.size(row)
		var top: = at + Vector3(0, size.y * 0.3, 0)

		var house: = store.position(store.rows_in(model)[0]) if store.rows_in(model).size() > 0 else at
		var out: = Vector3(at.x - house.x, 0, at.z - house.z)
		if out.length() < 0.1:
			continue
		out = out.normalized()
		var tip: = top + out * 3.2 + Vector3(0, 1.6, 0)
		kit.rod(folder, top, tip, 0.12, Color8(200, 200, 196), "Metal", "FlagStaff")
		var hang: = PolishKit.facing(tip, out)
		var flag: = hang.translated_local(Vector3(0, -0.9, -1.25))
		kit.box(folder, flag, Vector3(0.05, 1.7, 2.6), FLAG_RED, "Fabric", "Flag")
		for stripe in [-0.5, 0.0, 0.5]:
			kit.box(folder, flag.translated_local(Vector3(0.01, stripe * 1.2 + 0.12, 0)), Vector3(0.05, 0.16, 2.6), FLAG_WHITE, "Fabric", "Flag")
		kit.box(folder, flag.translated_local(Vector3(0.03, 0.42, 0.72)), Vector3(0.05, 0.86, 1.15), FLAG_BLUE, "Fabric", "Flag")
		count += 1
	return count
