class_name LockerMenu
extends Control








const WIDTH: = 400.0
const ROW: = 54.0
const HEADER: = 46.0
const COLUMN: = 400.0
const SMALL_ROW: = 50.0
const HEADING: = 30.0
const EDGE: = 20.0

const CATEGORIES: Array[String] = ["air", "forcing", "rescue", "fire", "scene", "cordon", "other"]

var _plate: Control
var _title: Label
var _cross: Button
var _rows: Control
var _player: Player
var _lockers: Lockers
var _handle: Variant = null
var _choices: Array[Callable] = []
var _written: = ""
var _check: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 80)
	_title = Ui.caps("", 20)
	_title.position = Vector2(16, 12)
	_plate.add_child(_title)
	_cross = MenuKit.cross(close)
	_plate.add_child(_cross)
	_rows = Control.new()
	_rows.position = Vector2(8, HEADER)
	_rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_rows)
	Text.language_changed.connect( func(_code: String) -> void : _written = "")



func watch(lockers: Lockers) -> void :
	lockers.menu_wanted.connect(open.bind(lockers))


func is_open() -> bool:
	return _handle != null


func open(player: Player, handle: Dictionary, lockers: Lockers) -> void :
	if not player.is_local or Game.ui_open:
		return
	_player = player
	_lockers = lockers
	_handle = handle
	_written = ""
	_draw_lines()
	_plate.visible = true
	MenuKit.take_mouse(player, true)


func close() -> void :
	if _handle == null:
		return
	_handle = null
	_written = ""
	_plate.visible = false
	MenuKit.take_mouse(_player, false)


func _choose(choice: Variant) -> void :
	var lockers: = _lockers
	var handle: Dictionary = _handle
	var player: = _player
	close()
	lockers.use(player, handle, choice)


func _fit_plate(size: Vector2) -> void :
	_plate.custom_minimum_size = size
	_plate.size = size

	var view: = get_viewport_rect().size
	var fit: = minf(1.0, minf((view.x - EDGE * 2) / size.x, (view.y - EDGE * 2) / size.y))
	_plate.scale = Vector2(fit, fit)
	_plate.position = ((view - size * fit) / 2.0).round()
	_cross.position = Vector2(size.x - 42, 7)



func _small_row(x: float, y: float, width: float, text: String, color: Color, choice: Variant, icon: = "") -> Button:
	var button: = MenuKit.row(Vector2(width, SMALL_ROW - 4), text, "", color, _choose.bind(choice), "", icon)
	button.position = Vector2(x, y)
	_rows.add_child(button)
	return button




func _out_with(line: LockerLine) -> String:
	if line.holder == null or not is_instance_valid(line.holder):
		return ""
	return "me" if line.holder == _player else "other"


func _line_color(line: LockerLine) -> Color:
	match _out_with(line):
		"me":
			return Ui.GREEN
		"other":
			return Ui.DIM

	match line.tint:
		"full":
			return Ui.GREEN
		"half":
			return Ui.AMBER
		"low":
			return Ui.RED
	return Ui.TEXT



func _mark(button: Button, line: LockerLine) -> void :
	if _out_with(line) != "me":
		return
	for state: String in ["normal", "hover", "pressed"]:
		var box: = (button.get_theme_stylebox(state) as StyleBoxFlat).duplicate() as StyleBoxFlat
		box.bg_color = box.bg_color.lerp(Color(Ui.GREEN, box.bg_color.a), 0.22)
		box.border_color = Ui.GREEN
		box.border_width_left = 5
		button.add_theme_stylebox_override(state, box)
	var tag: = Ui.caps(Text.say(Text.m("hud.locker.withYou")), 12)
	tag.add_theme_color_override("font_color", Ui.GREEN)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	tag.position = Vector2(button.size.x - 168, 3)
	tag.size = Vector2(160, 16)
	button.add_child(tag)


static func _words(line: LockerLine) -> String:

	var action: = Text.say(line.action)
	var object: = Text.say(line.object)
	return (action + " · " + object if not object.is_empty() else action).to_upper()




func _draw_all(lines: Array[LockerLine], holding: bool) -> void :
	var groups: Array = []
	var total: = 0.0
	for key in CATEGORIES:
		var group: Array[LockerLine] = []
		for line in lines:
			if (line.category if line.category in CATEGORIES else "other") == key:
				group.append(line)
		if not group.is_empty():
			groups.append([key, group])
			total += HEADING + group.size() * SMALL_ROW

	var column: = 0
	var y: = 0.0
	var deepest: = 0.0
	for entry: Array in groups:
		var group: Array[LockerLine] = entry[1]
		var tall: = HEADING + group.size() * SMALL_ROW
		if column == 0 and y > 0.0 and y + tall / 2.0 > total / 2.0:
			column = 1
			y = 0.0
		var x: = column * (COLUMN + 8)
		var heading: = Ui.caps(Text.say(Text.m("hud.locker.categories." + entry[0])).to_upper(), 15)
		heading.add_theme_color_override("font_color", Ui.YELLOW)
		heading.position = Vector2(x + 4, y + 6)
		_rows.add_child(heading)
		y += HEADING
		for line in group:
			var words: = _words(line)
			if _out_with(line) == "other":

				words += " · " + Text.say(Text.f("hud.locker.withOther", [line.holder.display_name])).to_upper()
			_mark(_small_row(x, y, COLUMN, words, _line_color(line), line, line.icon), line)
			y += SMALL_ROW
		deepest = maxf(deepest, y)
	if holding:
		_small_row(0, deepest + 8, COLUMN, Text.say(Text.m("hud.locker.returnAll")).to_upper(), Ui.YELLOW, "all")
	var close_x: = COLUMN + 8 if holding else 0.0
	_small_row(close_x, deepest + 8, COLUMN * 2 + 8 - close_x, Text.say(_lockers.close_text(_handle)).to_upper(), Ui.AMBER, null)
	_fit_plate(Vector2(COLUMN * 2 + 8 + 16, HEADER + deepest + 8 + SMALL_ROW + 6))


func _row(index: int, text: String, detail: String, color: Color, choice: Variant, icon: = "") -> Button:
	var choose: = _choose.bind(choice)
	var button: = MenuKit.row(Vector2(WIDTH - 16, ROW - 4), text, detail, color, choose, str(index) if index <= 9 else "", icon)
	button.position = Vector2(0, (index - 1) * ROW)
	_rows.add_child(button)
	_choices.append(choose)
	return button



func _draw_lines() -> void :
	var lines: = _lockers.lines_of(_handle)
	var signature: = Text.language
	var holding: = false
	for line in lines:
		signature += "%s|%s|%s|%s|%s|%s\n" % [Text.say(line.action), Text.say(line.object), line.icon, _out_with(line), line.tint, line.holder.display_name if _out_with(line) == "other" else ""]
		holding = holding or line.holder == _player
	signature += str(holding)
	if signature == _written:
		return
	_written = signature

	for child in _rows.get_children():
		_rows.remove_child(child)
		child.queue_free()
	_choices.clear()
	_title.text = Text.say(Text.m("hud.locker.all" if _handle["all"] else "hud.locker.title"))
	if _handle["all"]:
		_draw_all(lines, holding)
		return
	var count: = 0
	for line in lines:
		count += 1
		var detail: = Text.say(line.object).to_upper()
		if _out_with(line) == "other":
			detail += " · " + Text.say(Text.f("hud.locker.withOther", [line.holder.display_name])).to_upper()
		_mark(_row(count, Text.say(line.action).to_upper(), detail, _line_color(line), line, line.icon), line)
	if holding:
		count += 1
		_row(count, Text.say(Text.m("hud.locker.returnAll")).to_upper(), "", Ui.YELLOW, "all")
	count += 1
	_row(count, Text.say(_lockers.close_text(_handle)).to_upper(), "", Ui.AMBER, null)
	_fit_plate(Vector2(WIDTH, HEADER + count * ROW + 6))


func _input(event: InputEvent) -> void :
	if _handle == null:
		return
	if event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
		return
	var number: = MenuKit.number_key(event)
	if number > 0 and number <= _choices.size():
		get_viewport().set_input_as_handled()
		_choices[number - 1].call()


func _process(delta: float) -> void :
	if _handle == null:
		return

	_check += delta
	if _check < 0.2:
		return
	_check = 0.0
	var node: Node3D = _handle["node"]
	var there: = is_instance_valid(_lockers) and _lockers.is_open(_handle)
	if not there or _player.health <= 0.0 or _player.seat != null or _player.root_position().distance_to(node.global_position) > Lockers.REACH:
		close()
	else:
		_draw_lines()
