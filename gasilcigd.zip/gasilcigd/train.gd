class_name Train
extends Node3D







const LINE_Z: = 1200.0
const FROM_X: = -1060.0
const TO_X: = 1310.0
const GAUGE: = 4.3
const EVERY: = 410.0
const FIRST: = 150.0
const SPEED: = 70.0
const RUN_ON: = 300.0
const CAR_LENGTH: = 59.0
const PACK_LENGTH: = 18.0
const NOSE: = 5.0
const GAP: = 3.0
const LENGTH: = CAR_LENGTH * 3.0 + PACK_LENGTH + GAP * 3.0

static var current: Train

var _body: Node3D
var _windows: Array[MeshInstance3D] = []
var _window_lit: StandardMaterial3D
var _window_dark: StandardMaterial3D
var _rumble: AudioStreamPlayer3D
var _horned: = -1
var _lit: = false
var _shift: = 0.0
var held: = -1.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--train="):
			_shift = FIRST + float(arg.substr(8))
	_body = Node3D.new()
	add_child(_body)
	_window_lit = _material(Color(1.0, 0.86, 0.6), true)
	_window_dark = _material(Color(0.1, 0.13, 0.17), false)
	_window_dark.roughness = 0.15
	_window_dark.metallic_specular = 0.9
	_build()
	_rumble = Sounds.emitter(_body, Sounds.loop("train_rumble"), 1.6, 120.0, 2600.0)
	_rumble.position = Vector3( - LENGTH * 0.4, 2.0, 0)
	_body.visible = false


func _material(color: Color, glowing: bool) -> StandardMaterial3D:
	var made: = StandardMaterial3D.new()
	made.albedo_color = color
	made.roughness = 0.6
	if glowing:
		made.emission_enabled = true
		made.emission = color
		made.emission_energy_multiplier = 2.2
	return made







const WIDTH: = 8.2
const FLOOR: = 1.8
const BODY_TOP: = 8.4
const BLUE: = Color8(30, 70, 140)
const WHITE: = Color8(232, 234, 232)
const BLACK: = Color8(30, 30, 32)
const STEEL: = Color8(120, 124, 130)
const ROOF: = Color8(140, 142, 146)

var _parts: Dictionary = {}
var _materials: Dictionary = {}
var _box_mesh: BoxMesh
var _cylinder_mesh: CylinderMesh


func _build() -> void :
	_box_mesh = BoxMesh.new()
	_cylinder_mesh = CylinderMesh.new()
	_cylinder_mesh.top_radius = 0.5
	_cylinder_mesh.bottom_radius = 0.5
	_cylinder_mesh.height = 1.0
	_cylinder_mesh.radial_segments = 12
	_cylinder_mesh.rings = 1
	for key: String in ["white", "blue", "black", "steel", "roof", "lens", "tail", "yellow"]:
		_materials[key] = _material({"white": WHITE, "blue": BLUE, "black": BLACK, "steel": STEEL, "roof": ROOF, 
			"lens": Color(1.0, 0.97, 0.88), "tail": Color(1.0, 0.1, 0.06), "yellow": Color8(240, 196, 40)}[key], key == "lens" or key == "tail")
	(_materials["steel"] as StandardMaterial3D).metallic = 0.6
	(_materials["steel"] as StandardMaterial3D).roughness = 0.35

	var x: = - CAR_LENGTH / 2.0
	_cab_car(x, 1.0)
	x -= CAR_LENGTH / 2.0 + GAP / 2.0
	_gangway(x)
	x -= GAP / 2.0 + PACK_LENGTH / 2.0
	_power_pack(x)
	x -= PACK_LENGTH / 2.0 + GAP / 2.0
	_gangway(x)
	x -= GAP / 2.0 + CAR_LENGTH / 2.0
	_coach(x)
	x -= CAR_LENGTH / 2.0 + GAP / 2.0
	_gangway(x)
	x -= GAP / 2.0 + CAR_LENGTH / 2.0
	_cab_car(x, -1.0)
	for key: String in _parts:
		var made: = MeshInstance3D.new()
		made.mesh = (_parts[key] as SurfaceTool).commit()
		made.material_override = _window_dark if key == "window" else _materials[key]
		made.visibility_range_end = 2600.0
		_body.add_child(made)
		if key == "window":
			_windows.append(made)


func _add(key: String, mesh: Mesh, place: Transform3D) -> void :
	if not _parts.has(key):
		var tool: = SurfaceTool.new()
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		_parts[key] = tool
	(_parts[key] as SurfaceTool).append_from(mesh, 0, place)


func _box(key: String, at: Vector3, size: Vector3, turn: = Basis()) -> void :
	_add(key, _box_mesh, Transform3D(turn * Basis.from_scale(size), at))



func _rod(key: String, from: Vector3, to: Vector3, width: float) -> void :
	var along: = to - from
	var y: = along.normalized()
	var helper: = Vector3.FORWARD if absf(y.z) < 0.95 else Vector3.RIGHT
	var x: = y.cross(helper).normalized()
	var z: = x.cross(y)
	_add(key, _cylinder_mesh, Transform3D(Basis(x * width, y * along.length(), z * width), (from + to) / 2.0))



func _bogie(x: float) -> void :
	_box("black", Vector3(x, 1.25, 0), Vector3(9.0, 0.8, 5.6))
	for side: float in [-1.0, 1.0]:
		_box("black", Vector3(x, 1.2, side * 2.5), Vector3(9.4, 1.1, 0.5))
		for axle: float in [-2.6, 2.6]:
			_rod("steel", Vector3(x + axle, 0.95, side * 2.05), Vector3(x + axle, 0.95, side * 2.35), 2.0)
			_rod("black", Vector3(x + axle, 0.95, side * 2.36), Vector3(x + axle, 0.95, side * 2.5), 0.8)
			_box("yellow", Vector3(x + axle, 1.3, side * 2.8), Vector3(0.9, 0.7, 0.3))
			_rod("steel", Vector3(x + axle * 0.55, 1.0, side * 2.8), Vector3(x + axle * 0.55, 1.7, side * 2.8), 0.45)
	for axle: float in [-2.6, 2.6]:
		_rod("black", Vector3(x + axle, 0.95, -2.1), Vector3(x + axle, 0.95, 2.1), 0.5)




func _cab_car(x: float, out: float) -> void :
	var tip: = x + out * CAR_LENGTH / 2.0
	var nose_from: = tip - out * NOSE
	var body: = CAR_LENGTH - NOSE
	var middle: = x - out * NOSE / 2.0
	_bogie(x - out * CAR_LENGTH * 0.33)
	_bogie(tip - out * 9.0)
	_box("black", Vector3(x, 1.95, 0), Vector3(CAR_LENGTH - 2.0, 0.5, WIDTH - 0.6))
	for index in 3:
		_box("black", Vector3(middle + (index - 1) * 7.0, 1.4, 0), Vector3(4.0, 1.0, WIDTH - 2.0))
	_box("white", Vector3(middle, 5.1, 0), Vector3(body, 6.6, WIDTH))
	_box("blue", Vector3(middle, 3.1, 0), Vector3(body + 0.02, 1.5, WIDTH + 0.04))
	_add("roof", _cylinder_mesh, Transform3D(Basis(Vector3.BACK, PI / 2.0) * Basis.from_scale(Vector3(1.6, body, WIDTH - 0.1)), Vector3(middle, 8.4, 0)))
	_box("roof", Vector3(middle - out * 6.0, 9.4, 0), Vector3(7.0, 0.7, 3.6))


	_box("white", Vector3(tip - out * NOSE / 2.0, 3.4, 0), Vector3(NOSE, 3.2, WIDTH - 0.2))
	_box("blue", Vector3(tip - out * NOSE / 2.0, 3.1, 0), Vector3(NOSE + 0.02, 1.5, WIDTH - 0.16))
	var slope: = Vector2(NOSE, 3.4).length()
	var lean: = Basis(Vector3.BACK, out * atan2(NOSE, 3.4))
	var normal: = Vector3(out * 3.4, NOSE, 0).normalized()
	var glass_at: = Vector3(tip - out * NOSE / 2.0, 5.0 + 1.7, 0)
	_add("white", _box_mesh, Transform3D(lean * Basis.from_scale(Vector3(1.8, slope, WIDTH - 0.2)), glass_at - normal * 0.95))
	_add("window", _box_mesh, Transform3D(lean * Basis.from_scale(Vector3(0.08, slope - 0.5, WIDTH - 1.0)), glass_at))

	for lamp: float in [-2.8, 2.8]:
		_rod("lens", Vector3(tip, 4.4, lamp), Vector3(tip + out * 0.12, 4.4, lamp), 0.7)
		_rod("tail", Vector3(tip, 4.4, lamp - signf(lamp) * 1.0), Vector3(tip + out * 0.12, 4.4, lamp - signf(lamp) * 1.0), 0.4)
	_rod("lens", Vector3(nose_from + out * 0.2, 8.6, 0), Vector3(nose_from + out * 0.35, 8.6, 0), 0.5)
	_box("black", Vector3(tip + out * 0.3, 2.4, 0), Vector3(0.8, 0.7, 1.2))
	_box("black", Vector3(tip - out * 0.4, 1.2, 0), Vector3(1.0, 1.0, WIDTH - 1.0))
	for side: float in [-1.0, 1.0]:
		var face: = side * (WIDTH / 2.0 + 0.03)

		_box("window", Vector3(nose_from - out * 1.6, 6.3, face + side * 0.02), Vector3(2.0, 1.8, 0.05))
		var door: = x - out * (CAR_LENGTH / 2.0 - 5.0)
		_door(door, face, side)
		var first: = door + out * 5.5
		var last_x: = nose_from - out * 7.5
		for index in 6:
			var along: = first + index * (last_x - first) / 5.0
			_box("window", Vector3(along, 6.0, face + side * 0.02), Vector3(4.0, 2.3, 0.05))
			_box("black", Vector3(along, 6.0, face), Vector3(4.3, 2.6, 0.04))
	if out > 0.0:
		var lamp: = OmniLight3D.new()
		lamp.light_color = Color(1.0, 0.95, 0.8)
		lamp.omni_range = 40.0
		lamp.light_energy = 0.0
		lamp.position = Vector3(tip + 4.0, 3.0, 0)
		lamp.name = "Headlamp"
		_body.add_child(lamp)




func _power_pack(x: float) -> void :
	_bogie(x)
	_box("black", Vector3(x, 1.95, 0), Vector3(PACK_LENGTH - 1.0, 0.5, WIDTH - 0.6))
	_box("white", Vector3(x, 5.1, 0), Vector3(PACK_LENGTH, 6.6, WIDTH))
	_box("blue", Vector3(x, 3.1, 0), Vector3(PACK_LENGTH + 0.02, 1.5, WIDTH + 0.04))
	_add("roof", _cylinder_mesh, Transform3D(Basis(Vector3.BACK, PI / 2.0) * Basis.from_scale(Vector3(1.6, PACK_LENGTH, WIDTH - 0.1)), Vector3(x, 8.4, 0)))
	_box("steel", Vector3(x + 2.5, 9.35, 0), Vector3(6.0, 0.5, 4.4))
	for stack: float in [-1.0, 1.0]:
		_rod("black", Vector3(x - 4.0, 8.9, stack * 1.2), Vector3(x - 4.0, 10.2, stack * 1.2), 0.6)
	for side: float in [-1.0, 1.0]:
		var face: = side * (WIDTH / 2.0 + 0.03)
		for index in 2:
			_box("black", Vector3(x - 4.0 + index * 8.0, 6.0, face), Vector3(5.0, 2.6, 0.05))
			for slat in 6:
				_box("steel", Vector3(x - 4.0 + index * 8.0, 4.95 + slat * 0.42, face + side * 0.03), Vector3(4.8, 0.08, 0.04))
		_box("window", Vector3(x, 6.4, face + side * 0.02), Vector3(1.2, 1.2, 0.05))



func _coach(x: float) -> void :
	_bogie(x + CAR_LENGTH * 0.33)
	_bogie(x - CAR_LENGTH * 0.33)
	_box("black", Vector3(x, 1.95, 0), Vector3(CAR_LENGTH - 1.0, 0.5, WIDTH - 0.6))
	for index in 4:
		_box("black", Vector3(x - 9.0 + index * 6.0, 1.4, 0), Vector3(4.0, 1.0, WIDTH - 2.0))
	_box("white", Vector3(x, 5.1, 0), Vector3(CAR_LENGTH, 6.6, WIDTH))
	_box("blue", Vector3(x, 3.1, 0), Vector3(CAR_LENGTH + 0.02, 1.5, WIDTH + 0.04))
	_add("roof", _cylinder_mesh, Transform3D(Basis(Vector3.BACK, PI / 2.0) * Basis.from_scale(Vector3(1.6, CAR_LENGTH, WIDTH - 0.1)), Vector3(x, 8.4, 0)))
	_box("roof", Vector3(x, 9.4, 0), Vector3(7.0, 0.7, 3.6))
	for side: float in [-1.0, 1.0]:
		var face: = side * (WIDTH / 2.0 + 0.03)
		for door: float in [x - CAR_LENGTH / 2.0 + 5.0, x + CAR_LENGTH / 2.0 - 5.0]:
			_door(door, face, side)
		var first: = x - CAR_LENGTH / 2.0 + 10.5
		var last_x: = x + CAR_LENGTH / 2.0 - 10.5
		for index in 7:
			var along: = first + index * (last_x - first) / 6.0
			_box("window", Vector3(along, 6.0, face + side * 0.02), Vector3(4.0, 2.3, 0.05))
			_box("black", Vector3(along, 6.0, face), Vector3(4.3, 2.6, 0.04))



func _door(x: float, face: float, side: float) -> void :
	_box("black", Vector3(x, 4.7, face), Vector3(4.2, 5.6, 0.05))
	_box("window", Vector3(x - 1.0, 5.6, face + side * 0.03), Vector3(1.6, 3.0, 0.04))
	_box("window", Vector3(x + 1.0, 5.6, face + side * 0.03), Vector3(1.6, 3.0, 0.04))
	_box("yellow", Vector3(x, 1.7, face + side * 0.35), Vector3(4.0, 0.2, 0.8))



func _gangway(x: float) -> void :
	_box("black", Vector3(x, 5.0, 0), Vector3(GAP + 0.4, 6.4, WIDTH - 1.6))



func front() -> Variant:
	var t: = (held if held >= 0.0 else HostClock.now()) - FIRST + _shift
	if t < 0.0:
		return null
	var index: = floori(t / EVERY)
	var into: = t - index * EVERY
	var trip: = (TO_X - FROM_X + RUN_ON * 2.0 + LENGTH) / SPEED
	if into > trip:
		return null
	var eastward: = index % 2 == 0
	var travelled: = into * SPEED
	var x: = (FROM_X - RUN_ON + travelled) if eastward else (TO_X + RUN_ON - travelled)
	return [x, eastward, index]


func _process(_delta: float) -> void :
	var where: Variant = front()
	if where == null:
		if _body.visible:
			_body.visible = false
			_rumble.stop()
		return
	var x: float = where[0]
	var eastward: bool = where[1]
	_body.visible = true
	_body.global_transform = Transform3D(Basis(Vector3.UP, 0.0 if eastward else PI), Vector3(x, 0.98, LINE_Z))
	if not _rumble.playing and _rumble.stream:
		_rumble.play()

	var coming_out: = (x > FROM_X - 60.0) if eastward else (x < TO_X + 60.0)
	if coming_out and _horned != where[2]:
		_horned = where[2]
		var end: = Vector3(FROM_X if eastward else TO_X, 4.0, LINE_Z)
		Sounds.once_at(end, "train_horn", 2.2, 160.0, 2800.0)
		if OS.get_cmdline_user_args().has("--sound-trace"):
			print("sound: train horn at x %.0f" % end.x)
	var dark: = Game.night
	if dark != _lit:
		_lit = dark
		for window in _windows:
			window.material_override = _window_lit if dark else _window_dark
		var lamp: = _body.get_node_or_null("Headlamp") as OmniLight3D
		if lamp:
			lamp.light_energy = 3.0 if dark else 0.0
