class_name HudReticle
extends Control












const WHITE: = Color(1, 1, 1, 0.8)
const BLUE: = Color(0.42, 0.76, 1.0)
const GREEN: = Color(0.4, 0.92, 0.5)
const CYAN: = Color(0.6, 1.0, 0.93)
const AMBER: = Color(1.0, 0.72, 0.16)
const RED: = Color(1.0, 0.27, 0.22)
const RING: = 9.0
const RING_AIMED: = 12.0
const PROGRESS_RING: = 17.0
const AIR_RING: = 23.0
const SUCCESS_TIME: = 0.85
const RIPPLE_EVERY: = 0.42
const RIPPLE_TIME: = 0.7
const NEAR_FLAME: = 3.0
const NEAR_LANDING: = 5.5
const WORDS_SIZE: = 13

var _aimed: = 0.0
var _spraying: = 0.0
var _progress: = 0.0
var _far: = 0.0
var _empty: = 0.0
var _flowing: = 0.0
var _cooling: = 0.0
var _air: = -1.0
var _air_minutes: = -1.0
var _whistle: = 0.0
var _words: = ""
var _words_color: = WHITE
var _spin: = 0.0
var _orbit: = 0.0
var _time: = 0.0
var _success: = -1.0
var _ripple_clock: = 0.0
var _ripples: Array[float] = []
var _flames_out: = -1
var _watching: Player
var _demo: Dictionary = {}
var _outline: = Color(0, 0, 0, 0.6)

var _green: = GREEN
var _amber: = AMBER
var _red: = RED
var _tank: = -1.0
var _charging: = false


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hud-open=reticle"):
			_run_demo.call_deferred()


func _process(delta: float) -> void :
	var swaps: Dictionary = Config.Settings.ColourBlind
	_green = swaps["Good"] if Ui.colour_blind else GREEN
	_amber = swaps["Warn"] if Ui.colour_blind else AMBER
	_red = swaps["Bad"] if Ui.colour_blind else RED
	var player: = Game.local_player
	visible = player != null and player.holding == "nozzle" or not _demo.is_empty()
	if player != _watching:
		_watching = player
		_flames_out = -1
	if not visible:
		_ripples.clear()
		_success = -1.0
		if player != null:
			_flames_out = int(player.get_attr("FlamesOut", 0))
		return

	var settings: Dictionary = Config.Hose.Reticle
	_outline = Color(0, 0, 0, float(settings["OutlineAlpha"]))
	var hitting: bool = _demo.get("hitting", player.get_attr("HittingFire", false) == true if player else false)
	var cooling: bool = _demo.get("cooling", player.get_attr("Cooling", false) == true if player else false)
	var flowing: bool = _demo.get("flowing", player.get_attr("Spraying", false) == true if player else false)
	var empty: bool = _demo.get("empty", _tank_dry(player))
	var reach: = _reach(player) if _demo.is_empty() else {}
	var far: bool = _demo.get("far", not hitting and not empty and not reach.get("reachable", true))
	var aimed: bool = _demo.get("aimed", (hitting and not cooling) or ( not far and _aimed_at_flame(player, reach)))
	var progress: Variant = _demo.get("progress", player.get_attr("FlameProgress") if player else null)
	var out: = int(_demo.get("out", player.get_attr("FlamesOut", 0) if player else 0))
	if _flames_out >= 0 and out > _flames_out:
		_success = 0.0
		_ripples.clear()
	_flames_out = out
	_read_air(player)
	_read_tank(player)
	_far = move_toward(_far, 1.0 if far else 0.0, delta * 6.0)
	_empty = move_toward(_empty, 1.0 if empty else 0.0, delta * 6.0)
	_flowing = move_toward(_flowing, 1.0 if (flowing and not hitting) else 0.0, delta * 4.0)
	_cooling = move_toward(_cooling, 1.0 if (hitting and cooling) else 0.0, delta * 5.0)
	_orbit = fmod(_orbit + delta * 1.6, TAU)
	if empty:
		_words = Text.say(Text.m("hud.hose.noWater"))
		_words_color = _red
	elif far:
		_words = Text.say(Text.m("hud.hose.outOfRange"))
		_words_color = _amber
	elif hitting and cooling:
		_words = Text.say(Text.m("hud.reticle.cooling"))
		_words_color = CYAN
	else:
		_words = ""

	_time += delta
	_aimed = move_toward(_aimed, 1.0 if aimed else 0.0, delta * (7.0 if aimed else 4.0))
	_spraying = move_toward(_spraying, 1.0 if hitting else 0.0, delta * (8.0 if hitting else 3.0))
	if progress != null:
		_progress = lerpf(_progress, clampf(float(progress), 0.0, 1.0), 1.0 - exp( - delta * 10.0))
	elif not hitting:
		_progress = move_toward(_progress, 0.0, delta * 2.0)
	_spin = fmod(_spin + delta * lerpf(0.7, 4.2, _spraying) * _aimed, TAU)
	if _success >= 0.0:
		_success += delta
		if _success > SUCCESS_TIME:
			_success = -1.0


	for index in range(_ripples.size() - 1, -1, -1):
		_ripples[index] += delta
		if _ripples[index] > RIPPLE_TIME:
			_ripples.remove_at(index)
	if hitting and not cooling and _success < 0.0:
		_ripple_clock += delta
		if _ripple_clock >= RIPPLE_EVERY:
			_ripple_clock = 0.0
			_ripples.append(0.0)
	else:
		_ripple_clock = RIPPLE_EVERY
	queue_redraw()





func _reach(player: Player) -> Dictionary:
	if player == null or HoseService.current == null:
		return {}
	var origin: = _nozzle_tip(player)
	var aim: = HoseService.current.aim_of(player)
	var hose: Dictionary = Config.Hose
	var fog: bool = player.get_attr("Pattern") == "Fog"
	var reachable: bool
	if fog:
		reachable = origin.distance_to(aim) <= float(hose["Fog"]["Reach"]) + float(hose["Reticle"]["FogMargin"])
	else:
		reachable = Ballistics.reachable(origin, aim, HoseService.stream_speed_of(player), float(hose["StreamGravity"]))
	return {"origin": origin, "aim": aim, "fog": fog, "reachable": reachable}


func _nozzle_tip(player: Player) -> Vector3:
	if player.rig != null and player.rig.hand_right != null:
		for child in player.rig.hand_right.get_children():
			if child is Nozzle and (child as Nozzle).tip != null:
				return (child as Nozzle).tip.global_position
	return HoseService.current.nozzle_tip(player)



func _path(player: Player, reach: Dictionary) -> PackedVector3Array:
	var hose: Dictionary = Config.Hose
	var origin: Vector3 = reach["origin"]
	var aim: Vector3 = reach["aim"]
	if reach["fog"]:
		var ahead: = (aim - origin).normalized() * float(hose["Fog"]["Reach"])
		var hit: = Game.world.raycast(origin, origin + ahead, World.LAYER_QUERY | World.LAYER_VEHICLE, [player.get_rid()])
		return PackedVector3Array([origin, hit["position"] if not hit.is_empty() else origin + ahead])
	var exclude: Array[RID] = [player.get_rid()]
	var cast: = func(from: Vector3, to: Vector3) -> Variant:
		var hit: = Game.world.raycast(from, to, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
		return null if hit.is_empty() else hit["position"]
	var gravity: = float(hose["StreamGravity"])
	var velocity: = Ballistics.launch_toward(origin, aim, HoseService.stream_speed_of(player), gravity)
	return Ballistics.trace(origin, velocity, gravity, float(hose["StreamTime"]), int(hose["StreamSteps"]), cast)["path"]





func _aimed_at_flame(player: Player, reach: Dictionary) -> bool:
	if player == null or player.camera == null or reach.is_empty() or (Flame.all.is_empty() and Ember.all.is_empty()):
		return false
	var eye: = player.camera.camera
	var from: = eye.global_position
	var along: = - eye.global_basis.z
	var landing: Vector3 = reach["aim"]
	var depth: = (landing - from).dot(along) + NEAR_FLAME
	var sighted: Array[Vector3] = []
	for flame in Flame.all:
		if flame.intensity > 0.05 and _near(flame.global_position, from, along, depth, landing, 1.0 + 2.5 * flame.intensity):
			sighted.append(flame.global_position)
	for ember in Ember.all:
		if _near(ember.global_position, from, along, depth, landing, 0.5):
			sighted.append(ember.global_position)
	if sighted.is_empty():
		return false
	var path: = _path(player, reach)
	var hose: Dictionary = Config.Hose
	var wets: float = (float(hose["Fog"]["Radius"]) if reach["fog"] else float(hose["HitRadius"])) + float(hose["Reticle"]["LockMargin"])
	for at in sighted:
		if FireService.distance_to_path(at, path) <= wets:
			return true
	return false



func _tank_dry(player: Player) -> bool:
	var vehicle: Variant = player.get_attr("HoseTruck") if player else null
	return vehicle is Vehicle and is_instance_valid(vehicle) and (vehicle as Vehicle).water <= 0.0




func _read_tank(player: Player) -> void :
	_tank = -1.0
	_charging = player != null and player.get_attr("Charging") == true
	var vehicle: Variant = player.get_attr("HoseTruck") if player else null
	if vehicle is Vehicle and is_instance_valid(vehicle) and (vehicle as Vehicle).capacity > 0.0:
		var share: float = (vehicle as Vehicle).water / (vehicle as Vehicle).capacity
		if share < float(Config.Water.Tank.ReticleBelow):
			_tank = share




func _read_air(player: Player) -> void :
	var air: Dictionary = Config.Air
	_whistle = float(air["Whistle"]) / float(air["Capacity"])
	var bar: float
	var rate: float
	if _demo.has("air"):
		bar = float(_demo["air"])
		rate = float(air["Work"])
	elif player != null and player.get_attr("Mask", false) == true:
		bar = float(player.get_attr("AirBar", 0))
		rate = float(air["Rest"])
		if player.get_attr("Spraying", false) == true:
			rate = float(air["Work"])
		elif Vector2(player.velocity.x, player.velocity.z).length() > 1.0:
			rate = float(air["Walk"])
	else:
		_air = -1.0
		_air_minutes = -1.0
		return
	_air = clampf(bar / float(air["Capacity"]), 0.0, 1.0)
	var bar_per_minute: = rate * float(air["TimeScale"]) / float(air["Litres"]) * float(air["Capacity"])
	_air_minutes = bar / maxf(bar_per_minute, 0.001)


func _near(base: Vector3, from: Vector3, along: Vector3, depth: float, landing: Vector3, height: float) -> bool:
	var middle: = base + Vector3.UP * height * 0.5
	if middle.distance_to(landing) <= NEAR_LANDING:
		return true
	var ahead: = (middle - from).dot(along)
	if ahead <= 0.0 or ahead > depth:
		return false

	var closest: = from + along * ahead
	var on_flame: = Vector3(base.x, clampf(closest.y, base.y, base.y + height), base.z)
	return on_flame.distance_to(closest) <= NEAR_FLAME


func _draw() -> void :
	var lock: = maxf(_aimed, _spraying)
	var water: = BLUE.lerp(CYAN, _cooling)
	var color: = WHITE.lerp(water, lock)

	color = color.lerp(_amber, _far)
	color = color.lerp(_red, _empty)
	var beat: = lerpf(1.0, 0.35 + 0.65 * (0.5 + 0.5 * sin(_time * 12.0)), _empty)
	var pop: = 0.0
	var green: = 0.0
	if _success >= 0.0:
		var t: = _success / SUCCESS_TIME
		green = clampf(_success / 0.06, 0.0, 1.0) * (1.0 - smoothstep(0.55, 1.0, t))
		pop = sin(PI * clampf(_success / 0.35, 0.0, 1.0)) * (1.0 - t)
		color = color.lerp(_green, green)


	for age in _ripples:
		var k: = age / RIPPLE_TIME
		var radius: = lerpf(RING_AIMED * 0.6, RING_AIMED * 2.4, ease(k, 0.5))
		var alpha: = (1.0 - k) * 0.55 * _spraying
		draw_arc(Vector2.ZERO, radius, 0, TAU, 40, Color(water, alpha), lerpf(2.5, 1.0, k), true)



	var radius: = lerpf(RING, RING_AIMED, lock) + sin(_time * 9.0) * 0.8 * _spraying + pop * 7.0
	var gap: = lerpf(0.0, 0.62, lock) * (1.0 - green)
	var width: = lerpf(1.5, 2.5, lock) + pop * 1.5
	var alpha: = lerpf(0.4, 1.0, maxf(maxf(lock, green), maxf(_far, _empty))) * beat
	var pieces: = 4
	if _far > 0.5:
		pieces = 8
		gap = maxf(gap, 0.32)
	for piece in pieces:
		var start: = _spin + piece * TAU / pieces + gap * 0.5
		var end: = _spin + (piece + 1) * TAU / pieces - gap * 0.5
		_outlined_arc(radius, start, end, Color(color, alpha), width)


	if _flowing > 0.01:
		for index in 3:
			var at: = _orbit + index * TAU / 3.0
			_outlined_arc(radius + 6.0, at, at + 0.45, Color(color.lerp(WHITE, 0.5), 0.8 * _flowing * beat), 2.0)



	var ticks: = lock * (1.0 - green) * (1.0 - _spraying)
	if ticks > 0.01:
		var reach: = lerpf(RING_AIMED + 14.0, RING_AIMED + 4.0, ease(lock, 0.4))
		var tick_color: = Color(color, ticks)
		for quarter in 4:
			var direction: = Vector2.from_angle( - _spin * 0.5 + quarter * TAU / 4.0 + TAU / 8.0)
			var outer: = direction * (reach + 5.0)
			var inner: = direction * reach
			draw_line(outer, inner, Color(_outline, _outline.a * ticks), 4.5, true)
			draw_line(outer, inner, tick_color, 2.5, true)


	if _spraying > 0.01 and _progress > 0.005:
		var progress_alpha: = _spraying * (1.0 - green)
		var end: = - PI / 2.0 + TAU * _progress
		draw_arc(Vector2.ZERO, PROGRESS_RING, 0, TAU, 48, Color(water, 0.22 * progress_alpha), 2.0, true)
		draw_arc(Vector2.ZERO, PROGRESS_RING, - PI / 2.0, end, 48, Color(_outline, _outline.a * progress_alpha), 5.0, true)
		draw_arc(Vector2.ZERO, PROGRESS_RING, - PI / 2.0, end, 48, Color(water.lightened(0.3), progress_alpha), 3.0, true)

		draw_circle(Vector2.from_angle(end) * PROGRESS_RING, 2.4, Color(1, 1, 1, progress_alpha), true, -1.0, true)


	if _success >= 0.0:
		_draw_tick(clampf((_success - 0.03) / 0.18, 0.0, 1.0), Color(_green, green), 1.25 + pop * 0.4)
		_draw_burst(_success)
	var dot: = lerpf(3.0, 3.6, lock) + (0.5 + 0.5 * sin(_time * 14.0)) * 1.2 * _spraying
	var dot_alpha: = 1.0 - (green if _success >= 0.0 else 0.0)
	if dot_alpha > 0.01:
		draw_circle(Vector2.ZERO, dot + 1.2, Color(_outline, _outline.a * dot_alpha), true, -1.0, true)
		draw_circle(Vector2.ZERO, dot, Color(color, dot_alpha * 0.95), true, -1.0, true)
	_draw_air()
	_draw_words()



func _draw_air() -> void :
	if _air < 0.0 or _air >= float(Config.Hose.Reticle.AirArcBelow):
		return
	var color: = _red if _air <= _whistle else _amber
	draw_arc(Vector2.ZERO, AIR_RING, 0, TAU, 56, Color(_outline, _outline.a * 0.6), 3.5, true)
	draw_arc(Vector2.ZERO, AIR_RING, 0, TAU, 56, Color(color, 0.18), 1.5, true)
	if _air > 0.0:
		_outlined_arc(AIR_RING, - PI / 2.0, - PI / 2.0 + TAU * _air, Color(color, 0.9), 1.6)



func _draw_words() -> void :
	var font: = Ui.label_font()
	var lines: Array = []
	if _words != "":
		lines.append([_words, _words_color])
	if _charging:
		lines.append([Text.say(Text.m("water.charging")), Color(0.55, 0.8, 1.0)])
	if _tank >= 0.0:
		lines.append([Text.say(Text.f("water.tankShort", [roundi(_tank * 100.0)])), RED if _tank < float(Config.Water.Tank.Sputter) * 2.0 else AMBER])
	if _air >= 0.0:
		var air_color: = WHITE
		if _air <= _whistle:
			air_color = _red
		elif _air < float(Config.Hose.Reticle.AirArcBelow):
			air_color = _amber
		var minutes: = floori(_air_minutes)
		var said: = Text.say(Text.m("hud.reticle.airShort")) if minutes < 1 else Text.say(Text.f("hud.reticle.air", [minutes]))
		lines.append([said, air_color])
	var y: = AIR_RING + 16.0
	for line: Array in lines:
		var at: = Vector2(-120.0, y)
		draw_string_outline(font, at, line[0], HORIZONTAL_ALIGNMENT_CENTER, 240.0, WORDS_SIZE, 4, Color(0, 0, 0, 0.75))
		draw_string(font, at, line[0], HORIZONTAL_ALIGNMENT_CENTER, 240.0, WORDS_SIZE, Color(line[1], 1.0))
		y += WORDS_SIZE + 3.0


func _outlined_arc(radius: float, start: float, end: float, color: Color, width: float) -> void :
	if end - start < 0.01:
		return
	var points: = maxi(4, int((end - start) / TAU * 40.0))
	draw_arc(Vector2.ZERO, radius, start, end, points, Color(_outline, _outline.a * color.a), width + 2.0, true)
	draw_arc(Vector2.ZERO, radius, start, end, points, color, width, true)



func _draw_tick(share: float, color: Color, scale_by: float) -> void :
	if share <= 0.0 or color.a <= 0.01:
		return
	var a: = Vector2(-5.0, 0.5) * scale_by
	var b: = Vector2(-1.5, 4.0) * scale_by
	var c: = Vector2(5.5, -4.0) * scale_by
	var first: = clampf(share / 0.35, 0.0, 1.0)
	var second: = clampf((share - 0.35) / 0.65, 0.0, 1.0)
	var line: = PackedVector2Array([a, a.lerp(b, first)])
	if second > 0.0:
		line.append(b.lerp(c, second))
	draw_polyline(line, Color(_outline, _outline.a * color.a * 1.6), 5.0, true)
	draw_polyline(line, color, 2.8, true)



func _draw_burst(age: float) -> void :
	var k: = clampf(age / 0.55, 0.0, 1.0)
	if k >= 1.0:
		return
	var wave: = lerpf(RING_AIMED, RING_AIMED * 3.2, ease(k, 0.35))
	draw_arc(Vector2.ZERO, wave, 0, TAU, 48, Color(_green, (1.0 - k) * 0.7), lerpf(3.0, 0.8, k), true)
	for index in 8:
		var direction: = Vector2.from_angle(index * TAU / 8.0 + TAU / 16.0)
		var out: = lerpf(RING_AIMED + 2.0, RING_AIMED + 22.0, ease(k, 0.3))
		var size: = lerpf(2.6, 0.6, k)
		draw_circle(direction * out, size, Color(_green.lightened(0.2), 1.0 - k), true, -1.0, true)





func _run_demo() -> void :
	var prefix: = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			prefix = arg.substr(8)
	var steps: = [
		["idle", {"aimed": false, "hitting": false, "out": 0}, 1.0], 
		["aimed", {"aimed": true, "hitting": false, "out": 0}, 1.0], 
		["spraying", {"aimed": true, "hitting": true, "progress": 0.62, "out": 0}, 1.2], 
		["out_a", {"aimed": true, "hitting": false, "out": 1}, 0.1], 
		["out_b", {"aimed": true, "hitting": false, "out": 1}, 0.2], 
		["after", {"aimed": false, "hitting": false, "out": 1}, 1.2], 
		["far", {"aimed": false, "hitting": false, "far": true, "out": 1}, 1.0], 
		["empty", {"aimed": false, "hitting": false, "empty": true, "out": 1}, 1.0], 
		["flowing", {"aimed": false, "hitting": false, "flowing": true, "out": 1}, 1.0], 
		["cooling", {"aimed": false, "hitting": true, "flowing": true, "cooling": true, "out": 1}, 1.2], 
		["air", {"aimed": false, "hitting": false, "out": 1, "air": 230}, 1.0], 
		["air_low", {"aimed": true, "hitting": false, "out": 1, "air": 120}, 1.0], 
		["air_whistle", {"aimed": false, "hitting": false, "far": true, "out": 1, "air": 45}, 1.0], 
	]
	_demo = steps[0][1]
	await get_tree().create_timer(2.0).timeout
	for step: Array in steps:
		_demo = step[1]
		await get_tree().create_timer(step[2]).timeout
		if prefix != "":
			await RenderingServer.frame_post_draw
			var image: = get_viewport().get_texture().get_image()
			var middle: = Vector2i(image.get_size() / 2)
			image.get_region(Rect2i(middle - Vector2i(90, 70), Vector2i(180, 150))).save_png("%s_%s.png" % [prefix, step[0]])
			print("reticle: shot ", step[0])
	if prefix != "":
		Game.quit()
