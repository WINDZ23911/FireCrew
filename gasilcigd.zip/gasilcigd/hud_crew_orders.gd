class_name HudCrewOrders
extends Control












const HOLD: = 0.25
const RADIUS: = 150.0
const OUTER: = 285.0
const RING_SPLIT: = 80.0
const MOST: = 6
const ITEM: = Vector2(250, 44)
const GROUND_LOOK: = 0.5

const HINT_WIDTH: = 360.0

var _target: Dictionary = {}
var _target_who: Crewman = null
var _next_look: = 0.0
var _down_at: = -1.0
var _open: = false
var _sticky: = false
var _options: Array = []
var _chosen: = 0
var _who: Crewman = null
var _pointer: = Vector2.ZERO
var _hint: Control
var _hint_action: Label
var _hint_who: Label
var _wheel: Control
var _items: Array = []
var _middle: Label
var _middle_who: Label
var _footer: Label
var _ring_of: Array[int] = []
var _mark: MeshInstance3D
var _ground_at: = Vector3.INF
var _ground_since: = 0.0
var _cab: = false


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint = Ui.plate(Vector2(HINT_WIDTH, 52))
	_hint.visible = false
	add_child(_hint)
	var cap: = Ui.action_key("crew_order")
	cap.position = Vector2(10, 12)
	_hint.add_child(cap)
	_hint_action = Ui.display("", 20)
	_hint_action.position = Vector2(20 + cap.size.x, 3)
	_hint_action.size = Vector2(HINT_WIDTH - 30 - cap.size.x, 26)
	_hint_action.clip_text = true
	_hint.add_child(_hint_action)
	_hint_who = Ui.caps("", int(Config.Hud.CapsFloor))
	_hint_who.position = Vector2(20 + cap.size.x, 29)
	_hint_who.size = Vector2(HINT_WIDTH - 30 - cap.size.x, 18)
	_hint_who.clip_text = true
	_hint.add_child(_hint_who)
	_wheel = Control.new()
	_wheel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_wheel.visible = false
	add_child(_wheel)
	var middle: = Ui.plate(Vector2(230, 70))
	middle.position = Vector2(-115, -35)
	_wheel.add_child(middle)
	_middle = Ui.display("", 20)
	_middle.position = Vector2(10, 6)
	_middle.size = Vector2(210, 28)
	_middle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_middle.clip_text = true
	middle.add_child(_middle)
	_middle_who = Ui.caps("", int(Config.Hud.CapsFloor))
	_middle_who.position = Vector2(10, 38)
	_middle_who.size = Vector2(210, 22)
	_middle_who.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(_middle_who)
	_footer = Ui.caps("", int(Config.Hud.CapsFloor))
	_footer.position = Vector2(-260, OUTER + 34.0)
	_footer.size = Vector2(520, 20)
	_footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_wheel.add_child(_footer)


func _exit_tree() -> void :
	if is_instance_valid(_mark):
		_mark.queue_free()



func _show_mark(at: Variant) -> void :
	if not at is Vector3:
		if is_instance_valid(_mark):
			_mark.visible = false
		return
	if not is_instance_valid(_mark):
		_mark = MeshInstance3D.new()
		var ring: = TorusMesh.new()
		ring.inner_radius = float(Config.Crew.Mark.Radius) - 0.25
		ring.outer_radius = float(Config.Crew.Mark.Radius)
		ring.rings = 24
		ring.ring_segments = 6
		_mark.mesh = ring
		var paint: = StandardMaterial3D.new()
		paint.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		paint.albedo_color = Config.Crew.Mark.Colour
		paint.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_mark.material_override = paint
		_mark.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Game.world.add_child(_mark)
	var point: Vector3 = at
	var hit: = Game.world.raycast(point + Vector3(0, 1, 0), point - Vector3(0, 12, 0), World.LAYER_SOLID)
	_mark.global_position = (hit["position"] if not hit.is_empty() else point) + Vector3(0, 0.15, 0)
	_mark.scale = Vector3.ONE * (1.0 + 0.08 * sin(Game.now() * 5.0))
	_mark.visible = true


func _crew() -> CrewService:
	var service: = CrewService.current
	return service if service != null and not service.members.is_empty() else null


func _lead() -> Player:
	return Game.local_player


func _usable() -> bool:
	var lead: = _lead()
	return _crew() != null and lead != null and lead.seat == null and lead.camera != null and lead.health > 0.0



func _in_cab() -> bool:
	var lead: = _lead()
	return _crew() != null and lead != null and lead.seat != null and lead.health > 0.0 and not Game.incident.is_empty()


func _process(_delta: float) -> void :
	if _open and _cab:
		if not _in_cab():
			_close()
		else:
			_update_wheel()
		_show_mark(null)
		return
	if not _usable():
		if _open:
			_close()
		_hint.visible = false
		_down_at = -1.0
		_show_mark(null)
		return
	if not _open and Game.ui_open:
		_hint.visible = false
		return
	if not _open and Game.now() >= _next_look:
		_next_look = Game.now() + 0.1
		_target = CrewTargets.look(_lead())
		_target_who = null

		if _target.get("kind", "") == "ground":
			var at: Vector3 = _target["position"]
			if _ground_at == Vector3.INF or at.distance_to(_ground_at) > 3.0:
				_ground_at = at
				_ground_since = Game.now()
			elif Game.now() - _ground_since >= GROUND_LOOK:
				_target["quiet"] = false
		else:
			_ground_at = Vector3.INF
		if not _target.is_empty() and not (_target["options"] as Array).is_empty() and _target["options"][0].has("make"):
			var job: CrewJob = _target["options"][0]["make"].call()
			_target_who = _target.get("member") if _target.get("kind", "") == "member" else (_crew().choose(job) if job != null else null)
		elif _target.get("kind", "") == "ask":
			_target_who = _target.get("member")
	if Input.is_action_just_pressed("crew_order"):
		if _open and _sticky:
			_close()
		elif not _open:
			_down_at = Game.now()
	if _down_at >= 0.0 and not _open:
		if not Input.is_action_pressed("crew_order"):
			_down_at = -1.0
			_tap()
		elif Game.now() - _down_at >= HOLD:
			_down_at = -1.0
			_show_wheel(false)
	elif _open and not _sticky and not Input.is_action_pressed("crew_order"):
		_give()
	_show_hint()
	if _open:
		_update_wheel()
	var marked: Variant = null
	if not _target.is_empty() and not _target.get("quiet", false) and (_open or _hint.visible) and _target.get("kind", "") != "ask":
		marked = _target["position"]
	_show_mark(marked)


func _input(event: InputEvent) -> void :
	if not _open:
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_MIDDLE and _in_cab() and not Game.ui_open:

			_show_cab_wheel()
			get_viewport().set_input_as_handled()
			return
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_MIDDLE and _usable() and not Game.ui_open:

			_target = CrewTargets.look(_lead())
			_show_wheel(true)
			get_viewport().set_input_as_handled()
		return
	if event is InputEventMouseMotion:
		_pointer = (_pointer + event.relative).limit_length(160.0)
		if _pointer.length() > 35.0:
			_chosen = _pick_at(_pointer)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		match event.button_index:
			MOUSE_BUTTON_WHEEL_UP:
				_chosen = (_chosen - 1 + _options.size()) % _options.size()
				_pointer = Vector2.ZERO
			MOUSE_BUTTON_WHEEL_DOWN:
				_chosen = (_chosen + 1) % _options.size()
				_pointer = Vector2.ZERO
			MOUSE_BUTTON_LEFT, MOUSE_BUTTON_MIDDLE:
				_give()
			MOUSE_BUTTON_RIGHT:
				_close()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("pause"):
		_close()
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.pressed and not event.echo:
		for index in MenuKit.KEYS.size():
			if event.is_action_pressed(MenuKit.KEYS[index]):
				var members: = _crew().members
				_who = members[index] if index < members.size() and _who != members[index] else null
				get_viewport().set_input_as_handled()



func _pick_at(pointer: Vector2) -> int:
	var ring: = 0 if pointer.length() < RING_SPLIT else 1
	var on_ring: Array[int] = []
	for index in _options.size():
		if _ring_of[index] == ring:
			on_ring.append(index)
	if on_ring.is_empty():
		ring = 1 - ring
		for index in _options.size():
			if _ring_of[index] == ring:
				on_ring.append(index)
	var angle: = fposmod(atan2(pointer.y, pointer.x) + PI / 2.0, TAU)
	return on_ring[int(roundf(angle / TAU * on_ring.size())) % on_ring.size()]


func _tap() -> void :
	if _target.is_empty() or (_target["options"] as Array).is_empty():
		_show_wheel(true)
		return
	_options = _target["options"]
	_chosen = 0
	_who = _target.get("member") if _target.get("kind", "") == "member" else null
	_give()


func _show_wheel(sticky: bool) -> void :
	_cab = false
	var inner: Array = []
	var outer: Array = []
	var offered: Array = []
	if not _target.is_empty():
		for option: Dictionary in _target["options"]:
			var said: = Text.say(option["text"], "en")
			if said in offered:
				continue
			offered.append(said)

			(outer if option.get("all", false) and inner.size() > 0 else inner).append(option)
	if _target.get("kind", "") != "member":

		for option: Dictionary in CrewTargets.general(_lead()):
			var said: = Text.say(option["text"], "en")
			if not said in offered:
				offered.append(said)
				outer.append(option)

	if NetTalk.current != null:
		outer = outer.slice(0, MOST - 1)
		outer.append({"text": Text.m("crew.orders.ping"), "icon": "pin", "act": func(_service: CrewService) -> void : NetTalk.current.ping()})
	_build_wheel(inner.slice(0, MOST), outer.slice(0, MOST), sticky)



func _show_cab_wheel() -> void :
	var options: Array = []
	for kind: String in ["supply", "attack", "search", "cones", "backup"]:
		var set_now: bool = _crew().arrival.has(kind)
		var which: = kind
		options.append({"text": Text.join([Text.m("crew.orders.cab." + kind), "  ✓" if set_now else ""]), "icon": "check" if set_now else "dot", "all": true, 
			"act": func(service: CrewService) -> void : _toggle_arrival(service, which)})
	_target = {}
	_build_wheel(options, [], true)
	_cab = true


func _toggle_arrival(service: CrewService, kind: String) -> void :
	if service.arrival.has(kind):
		service.arrival.erase(kind)
	else:
		service.arrival[kind] = true
	var set_words: Array = []
	for each: String in service.arrival:
		if not set_words.is_empty():
			set_words.append(", ")
		set_words.append(Text.m("crew.orders.cab." + each))
	Game.notify(Text.f("crew.orders.cab.set", [Text.join(set_words) if not set_words.is_empty() else Text.m("crew.orders.cab.none")]), "", _lead())


func _build_wheel(inner: Array, outer: Array, sticky: bool) -> void :
	_options = inner + outer
	_ring_of.clear()
	for index in _options.size():
		_ring_of.append(0 if index < inner.size() else 1)
	if _options.is_empty():
		return
	_open = true
	_sticky = sticky
	_chosen = 0
	_who = _target.get("member") if _target.get("kind", "") == "member" else null
	_pointer = Vector2.ZERO
	Game.ui_open = true
	for item: Control in _items:
		item.queue_free()
	_items.clear()
	var count: = _options.size()
	for index in count:
		var option: Dictionary = _options[index]
		var item: = Ui.plate(ITEM)
		var ring: = _ring_of[index]
		var on_ring: = inner.size() if ring == 0 else outer.size()
		var place: = index if ring == 0 else index - inner.size()
		var angle: = TAU * place / on_ring - PI / 2.0
		var radius: = RADIUS if ring == 0 else OUTER
		item.position = Vector2(cos(angle) * (radius + 40.0), sin(angle) * radius) - ITEM / 2.0
		if ring == 1:
			item.modulate = Color(1, 1, 1, 0.92)
		var picture: = Ui.icon(option.get("icon", "dot"), 26)
		picture.position = Vector2(10, 9)
		item.add_child(picture)
		var words: = Ui.display(Text.say(option["text"]), 18)
		words.position = Vector2(44, 0)
		words.size = Vector2(ITEM.x - 52, ITEM.y)
		words.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		words.clip_text = true
		words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		item.add_child(words)
		if option.get("all", false):
			var all: = Ui.caps(Text.say(Text.m("crew.orders.everyone")), int(Config.Hud.CapsFloor) - 2)
			all.position = Vector2(44, ITEM.y - 17)
			all.modulate = Ui.DIM
			item.add_child(all)
		_wheel.add_child(item)
		_items.append(item)
	_wheel.visible = true
	Sounds.ui("ui_wheel_open")


func _update_wheel() -> void :
	for index in _items.size():
		var item: Control = _items[index]
		var lit: = index == _chosen
		item.modulate = Color(1, 1, 1) if lit else Color(0.72, 0.72, 0.72, 0.85)
		item.scale = Vector2.ONE * (1.08 if lit else 1.0)
		item.pivot_offset = ITEM / 2.0
	_middle.text = Text.say(_target["label"]) if not _target.is_empty() else Text.say(Text.m("crew.orders.cab.title" if _cab else "crew.targets.crew"))
	_footer.text = Text.say(Text.f("crew.orders.footer", [Controls.key_name("sprint")])) if not _cab else Text.say(Text.m("crew.orders.cab.footer"))
	var option: Dictionary = _options[_chosen] if _chosen < _options.size() else {}
	if option.get("all", false):
		_middle_who.text = Text.say(Text.m("crew.orders.everyone"))
	elif _who != null:
		_middle_who.text = "%s · %s" % [_who.display_name(), Text.say(CrewRoster.position_name(_who.role))]
	else:
		_middle_who.text = Text.say(Text.m("crew.orders.best"))


func _give() -> void :
	var service: = _crew()
	if service == null or _options.is_empty():
		_close()
		return
	var option: Dictionary = _options[clampi(_chosen, 0, _options.size() - 1)]
	var after: = Input.is_action_pressed("sprint")
	var who: = _who
	_close()
	Sounds.ui("ui_squelch")
	if option.has("act"):
		option["act"].call(service)
		return
	var job: CrewJob = option["make"].call()
	if job == null:
		return
	if service.order(job, who, after) == null:
		Game.notify(Text.m("crew.say.nobody"), "warning", _lead())


func _close() -> void :
	if _open:
		Game.ui_open = false
		Sounds.ui("ui_wheel_close")
	_open = false
	_sticky = false
	_cab = false
	_wheel.visible = false



func _show_hint() -> void :
	if _open or _target.is_empty() or _target.get("quiet", false) or (_target["options"] as Array).is_empty():
		_hint.visible = false
		return
	var camera: = get_viewport().get_camera_3d()
	var at: Vector3 = _target["position"]
	if camera == null or camera.is_position_behind(at):
		_hint.visible = false
		return
	var option: Dictionary = _target["options"][0]
	_hint_action.text = Text.say(option["text"])
	var who: Crewman = _target_who
	_hint_who.text = "%s  ·  %s" % [Text.say(_target["label"]), who.display_name() if is_instance_valid(who) else Text.say(Text.m("crew.orders.everyone"))]

	if (_target["options"] as Array).size() > 1:
		_hint_who.text += "  ·  " + Text.say(Text.m("crew.orders.holdMore"))


	var bounds: = get_parent_area_size()
	var y: = bounds.y - 250.0
	var prompts: = HudPrompts.top()
	if prompts != INF:
		y = minf(y, Hud.to_hud(Vector2(0, prompts)).y - 52.0 - 12.0)
	var middle: = HudPrompts.middle_x()
	_hint.position = Vector2((Hud.to_hud(Vector2(middle, 0)).x if middle != INF else bounds.x / 2.0) - HINT_WIDTH / 2.0, y)
	_hint.visible = true
