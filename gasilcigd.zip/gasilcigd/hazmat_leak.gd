class_name HazmatLeak
extends Node






























const TICK: = 0.25
const VALVE_HOLD: = 4.0



const SPILL_GROW: = 0.025
const CLOUD_GROW: = 0.05
const CLOUD_FADE: = 0.004
const FOG_POWER: = 0.035



const DECON_HALF: = 4.5
const DECON_EAVES: = 7.6
const DECON_REACH: = DECON_HALF + 2.2
const SUBSTANCES: = {
	"petrol": {"un": "33 / 1203", "cloud": Color(0.93, 0.91, 0.8), "pool": Color(0.35, 0.3, 0.22), "spill": 12.0, "radius": 26.0, "burns": true}, 
	"ammonia": {"un": "268 / 1005", "cloud": Color(0.88, 0.9, 0.84), "pool": Color(0.6, 0.62, 0.6), "spill": 5.0, "radius": 46.0, "burns": false, "skin": true}, 
}

static var current: HazmatLeak

var kind: = "hazmat"
var _sources: Array = []
var _leak: Dictionary = {}
var _visual: Dictionary = {}
var _hazard: Dictionary = {}
var _mirrored: = false
var _valve_prompt: Prompt
var forced_source: = ""
var _prompts: Dictionary = {}
var _decon_checked: = 0.0
var _beep_at: = 0.0
var _hurt_told: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
	if AmbulanceService.current != null:
		AmbulanceService.current.keep_clear.erase("decon")


func _ready() -> void :
	Net.share("hazmat", _net_state, _net_apply, 4.0)

	Net.stopped.connect( func() -> void :
		if _mirrored:
			_mirrored = false
			_leak = {}
			_show_state())
	Game.water_landed.connect(_on_water)



func start() -> void :
	CallGear.ensure(get_parent())
	var places: = IndustryZone.places
	if places.has("valve.tanks"):
		var valve: Vector3 = places["valve.tanks"]
		_sources.append({"id": "tanks", "at": valve, "leak": Vector3(valve.x - 2.0, 0.3, valve.z + 2.0), "substance": "petrol"})
	for index in places.get("wagons", []).size():
		var middle: Vector3 = places["wagons"][index]

		_sources.append({"id": "wagon%d" % index, "at": Vector3(middle.x + 2.0, 3.6, middle.z - 4.6), "leak": Vector3(middle.x + 2.0, 0.3, middle.z - 6.0), "substance": "petrol"})
	if places.has("tanker"):
		var tanker: Vector3 = places["tanker"]
		_sources.append({"id": "tanker", "at": tanker + Vector3(-5.0, -2.4, 0), "leak": Vector3(tanker.x - 6.0, 0.3, tanker.z), "substance": "petrol"})
	var cold: House = IndustryZone.houses.get("ColdStore")
	if cold != null:
		var valve: Variant = null
		var plant: Variant = null
		for id in cold.part_ids:
			var row: int = Game.store.row_of.get(id, -1)
			if row >= 0 and Game.store.name_at(row) == "AmmoniaValve":
				valve = Game.store.position(row)
		for node: Dictionary in cold.fuel:
			if node["name"] == "Ammonia compressor":
				plant = node["position"]
		if plant != null:
			var plant_at: Vector3 = plant
			_sources.append({"id": "ammonia", "at": valve if valve != null else plant_at, "leak": Vector3(plant_at.x, cold.lot.origin.y + 1.0, plant_at.z), "substance": "ammonia", "house": cold, "own_valve": valve != null})


func available() -> bool:
	return not _sources.is_empty() and VictimService.current != null and _leak.is_empty()


func _level() -> int:
	return clampi(Alarm.level, 1, 3)


func run() -> bool:
	if Net.is_client():
		return false
	var source: Dictionary = _sources[randi() % _sources.size()]
	for candidate: Dictionary in _sources:
		if candidate["id"] == forced_source:
			source = candidate
	var house: Variant = source.get("house")
	if house != null and (house as House).ruined:
		return false
	var substance: Dictionary = SUBSTANCES[source["substance"]]
	var settings: Dictionary = Config.Incidents.Hazmat
	var leak_at: Vector3 = source["leak"]
	_leak = {
		"id": source["id"], "substance": source["substance"], "at": source["at"], "leak": leak_at, 
		"leaking": true, "spill": 0.0, "cloud": 0.15, "burning": false, "cordon": false, 

		"cordon_from": Cordon.current.made() if Cordon.current != null else 0, 

		"wind": World.WIND.normalized().rotated(Vector3.UP, randf_range( - PI, PI)), 
		"foamed": false, "drain": null, "drain_covered": false, "drained": false, 
		"decon": source["leak"] - World.WIND.normalized() * 34.0, "contaminated": {}, "cleaned": {}, 
	}
	_leak["first_wind"] = _leak["wind"]
	_leak["decon"] = _decon_spot(leak_at, _leak["wind"])
	_hold_decon_ground()
	if Alarm.complicated("hazmat", "drain"):
		var side: = (_leak["wind"] as Vector3).rotated(Vector3.UP, PI / 2.0)
		_leak["drain"] = _floor_at((source["leak"] as Vector3) + side * float(Config.Incidents.Hazmat.DrainOut))
	if house != null:
		(house as House).ruined = true
	var where: Dictionary = Text.m("calls.hazmat.places." + (source["id"] if not String(source["id"]).begins_with("wagon") else "wagon"))
	var call_name: = Text.join([Text.m("calls.hazmat.title"), Text.m("calls.separator"), where])
	var people: = VictimService.current

	var seats: Array = []
	var down: = _wind()
	for index in (1 if _level() < 3 else 2):
		var side: = down.rotated(Vector3.UP, 0.7 * (index * 2 - 1) if index > 0 else 0.35)
		var lying_at: = leak_at + side * (8.0 + index * 4.0)
		lying_at.y = leak_at.y
		seats.append({"lying": Figure.lying(lying_at, - side)})
	var scene: Variant = {"lot": Transform3D(Basis(), leak_at), "size": Vector3(30, 8, 30), "name": "the leak"}
	if house != null:
		scene = house
	var victims: = people.begin_at(scene, seats, 100.0 / float(settings["CasualtyTime"]))
	var marker: = CallMarker.make(leak_at + Vector3(0, 30, 0), Text.m("calls.markers.hazmat"), Color8(230, 150, 20))
	CallService.current.publish("hazmat", call_name, leak_at, 4)
	Alarm.par(float(Alarm.settings()["Grade"]["Job"]["hazmat"]["Base"]))
	Game.incident["approach"] = IndustryZone.approach(leak_at)
	Game.incident.merge(people.shown(), true)
	Game.notify(Text.f("calls.hazmat.alarm", [call_name, substance["un"]]), "danger")
	Game.notify(Text.m("calls.hazmat.brief." + source["substance"]), "warning")
	Game.notify(Text.f("calls.hazmat.windTold", [Text.m("calls.hazmat.compass." + compass(_wind()))]), "warning")
	if _leak["drain"] != null:
		Game.notify(Text.m("calls.hazmat.drain.told"), "warning")
	_build_valve()
	_build_prompts()
	Escalation.begin_other(["wind"])

	var contributors: Dictionary = {}
	_leak["contributors"] = contributors
	var ignite_after: = float((settings["Ignite"] as Array)[_level() - 1])
	var clock: = 0.0
	var arrived: = false
	var reach: = float(Config.Fire.ArriveRange)

	var vapour_drain: = float(settings["VapourDrain"]) / maxf(float(Config.Victims.SmokeDrain), 0.001)
	var flames: Array = []
	var waited: = 0.0
	var done_valve: = false
	var done_cloud: = false
	while not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		var leaking: bool = _leak["leaking"]
		arrived = arrived or CallKit.player_near(leak_at, reach)
		if leaking:
			if arrived:
				_leak["spill"] = minf(1.0, _leak["spill"] + SPILL_GROW * TICK)
			_leak["cloud"] = minf(1.0, _leak["cloud"] + CLOUD_GROW * TICK)
		else:
			_leak["cloud"] = maxf(0.0, _leak["cloud"] - CLOUD_FADE * TICK)

		var fogged: bool = Game.now() - float(_leak.get("fogged_at", -100.0)) < float(settings["FogPause"])
		if arrived and leaking and not fogged and not _leak["foamed"]:
			clock += TICK
		if substance["burns"] and leaking and not _leak["burning"]:
			Game.incident["ignite_in"] = ceili(maxf(ignite_after - clock, 0.0))
			Game.incident["ignite_state"] = "held" if fogged else ("run" if arrived else "wait")
		else:
			Game.incident.erase("ignite_in")
			Game.incident.erase("ignite_state")

		if Escalation.due() == "wind":
			_leak["wind"] = (_leak["wind"] as Vector3).rotated(Vector3.UP, deg_to_rad(float(Config.Alarm.Escalations.hazmat.Turn)) * (1.0 if randf() < 0.5 else -1.0))
		_pool_step(substance, flames)
		if substance["burns"] and leaking and not _leak["burning"] and not _leak["foamed"] and clock > ignite_after and _leak["cloud"] > 0.25:
			_leak["burning"] = true
			Blast.at(leak_at + Vector3(0, 2, 0), 10.0, 0.8, 1.0)
			var count: = 2 + _level()
			var pool: float = substance["spill"] * _leak["spill"]
			for index in count:
				var a: = TAU * index / count
				flames.append(FireService.current.spot(leak_at + Vector3(cos(a), 0, sin(a)) * pool * 0.6 + Vector3(0, 1, 0)))
			Game.notify(Text.m("calls.hazmat.ignited"), "danger")
		if not _leak["cordon"] and _cordoned(leak_at):
			_leak["cordon"] = true
			_leak["cordon_at"] = Game.now()
			Game.notify(Text.f("calls.hazmat.cordoned", [Alarm.pay(int(settings["CordonReward"]))]), "good")
			var placers: = _cordon_placers(leak_at)
			for player: Variant in placers:
				contributors[player] = true
			CallKit.pay_helpers(placers, int(settings["CordonReward"]), "bonus", "", false)
		_show_state()
		if substance.get("skin", false) and ChemSuit.current != null:
			for player in Game.players:
				if is_instance_valid(player):
					ChemSuit.current.burn_skin(player, _vapour_at(player.head_position()), TICK)
		people.step(TICK, func(at: Vector3) -> float: return _vapour_at(at) * vapour_drain, false)
		Game.incident.merge(people.shown(), true)
		var burning: = 0
		for made: Dictionary in flames:
			burning += 1 if made["burning"] else 0
		if not done_valve and not leaking:
			done_valve = true
		if not done_cloud and not leaking and _leak["cloud"] <= 0.06:
			done_cloud = true
			Game.notify(Text.m("calls.hazmat.clear"), "good")
		var done: = int(_leak["cordon"]) + int(done_valve) + int(done_cloud) + int( not people.waiting())
		if done != int(Game.incident.get("done", 0)):
			CallService.current.progress(done)
		_show_tasks(burning, people.waiting(), people.total > 0)
		CallService.current.next_step(_next_step(burning, people.waiting()))
		if done_valve and done_cloud and burning == 0 and not people.waiting() and _decon_left() == 0:
			break
	marker.queue_free()
	var late: bool = CallService.current.overdue(waited)
	if done_valve and done_cloud and not people.waiting() and not late:
		Alarm.done()


	var rules: Dictionary = Alarm.settings()["Grade"]["Procedure"]
	var cordon_at: = float(_leak.get("cordon_at", -1.0))
	Alarm.check("cordon", cordon_at >= 0.0 and Alarm.arrived_at >= 0.0 and cordon_at - Alarm.arrived_at <= float(rules["HazmatCordon"]))
	if Alarm.first_at != Vector3.INF:
		var from: Vector3 = Alarm.first_at - leak_at
		from.y = 0.0
		Alarm.check("upwind", from.normalized().dot((_leak["first_wind"] as Vector3).normalized()) <= float(rules["Upwind"]))
	if substance["burns"]:
		Alarm.check("ignition", not _leak["burning"])

	if _leak["drain"] != null:
		Alarm.check("drains", not _leak["drained"])
	if not _leak["contaminated"].is_empty():
		Alarm.check("decon", _decon_left() == 0)
	for made: Dictionary in flames:
		FireService.current.end_spot(made)
	var counts: = people.finish()
	var good: bool = not late and counts["lost"] == 0
	VictimService.tally(counts)
	if good:

		var reward: = int(settings["Reward"])
		var helpers: Dictionary = contributors.duplicate()
		helpers.merge(counts["rescuers"])
		CallKit.pay_helpers(helpers, reward, "bonus")
		Game.notify(Text.f("calls.hazmat.done", [call_name, Alarm.pay(reward)]), "good")
	else:
		Game.notify(Text.f("calls.hazmat.failed", [call_name]), "warning")
	Game.incident.merge(VictimService.card(counts), true)
	Game.incident.erase("next")
	await CallService.current.settle()
	CallService.current.clear( not good)
	Escalation.reset()
	_leak = {}
	if AmbulanceService.current != null:
		AmbulanceService.current.keep_clear.erase("decon")
	_show_state()
	if house != null:
		get_tree().create_timer(20.0, false).timeout.connect( func() -> void : (house as House).ruined = false)
	return true




func _next_step(burning: int, waiting: bool) -> Variant:
	var step: Variant = _next_job(burning, waiting)
	if step == null or not _leak["cordon"]:
		return step

	return Text.join([step, Text.m("calls.separator"), Text.f("calls.hazmat.windCard", [Text.m("calls.hazmat.compass." + compass(_wind()))])])


func _next_job(burning: int, waiting: bool) -> Variant:
	if burning > 0:
		return Text.m("calls.hazmat.next.foamFire" if SUBSTANCES[_leak["substance"]]["burns"] and not _leak["foamed"] else "calls.hazmat.next.fire")
	if not _leak["cordon"]:
		return Text.f("calls.hazmat.next.cordonCount", [_cordon_count(_leak["leak"]), int(Config.Incidents.Hazmat.CordonNeeded)])
	if _leak["drain"] != null and not _leak["drain_covered"] and not _leak["drained"]:
		return Text.m("calls.hazmat.next.drain")
	if waiting:
		return Text.m("calls.hazmat.next.carry")
	if not _leak["foamed"]:
		return Text.m("calls.hazmat.next.foam")
	if _leak["leaking"]:
		var suit: bool = SUBSTANCES[_leak["substance"]].get("skin", false)
		return Text.m("calls.hazmat.next.valveSuit" if suit else "calls.hazmat.next.valve")
	if float(_leak["cloud"]) > 0.06:
		return Text.f("calls.hazmat.next.cloud", [Controls.key_name("pattern"), ceili(float(_leak["cloud"]) * 100.0)])
	if _decon_left() > 0:
		return Text.f("calls.hazmat.next.decon", [_decon_left()])
	return null




func _show_tasks(burning: int, waiting: bool, anyone: bool) -> void :
	var tasks: Array = []
	var add: = func(done: bool, todo: Variant, done_text: Variant) -> void :
		tasks.append({"t": done_text if done else todo, "done": done})
	if burning > 0:
		add.call(false, Text.m("calls.hazmat.task.foamFire" if SUBSTANCES[_leak["substance"]]["burns"] and not _leak["foamed"] else "calls.hazmat.task.fire"), "")
	add.call(_leak["cordon"], Text.f("calls.hazmat.task.cordon", [_cordon_count(_leak["leak"]), int(Config.Incidents.Hazmat.CordonNeeded)]), Text.m("calls.hazmat.task.cordonDone"))
	if _leak["drain"] != null:
		add.call(_leak["drain_covered"] or _leak["drained"], Text.m("calls.hazmat.task.drain"), Text.m("calls.hazmat.task.drainLost" if _leak["drained"] else "calls.hazmat.task.drainDone"))
		if _leak["drained"]:
			tasks[-1]["failed"] = true
	if anyone:
		add.call( not waiting, Text.m("calls.hazmat.task.carry"), Text.m("calls.hazmat.task.carryDone"))
	add.call(_leak["foamed"], Text.m("calls.hazmat.task.foam"), Text.m("calls.hazmat.task.foamDone"))
	var suit: bool = SUBSTANCES[_leak["substance"]].get("skin", false)
	add.call( not _leak["leaking"], Text.m("calls.hazmat.task.valveSuit" if suit else "calls.hazmat.task.valve"), Text.m("calls.hazmat.task.valveDone"))
	var cleared: bool = not _leak["leaking"] and float(_leak["cloud"]) <= 0.06
	add.call(cleared, Text.f("calls.hazmat.task.cloud", [ceili(float(_leak["cloud"]) * 100.0)]), Text.m("calls.hazmat.task.cloudDone"))
	if not _leak["contaminated"].is_empty():
		add.call(_decon_left() == 0, Text.f("calls.hazmat.task.decon", [Controls.key_name("interact"), _decon_left()]), Text.m("calls.hazmat.task.deconDone"))
	for task: Dictionary in tasks:
		if not task["done"]:
			task["next"] = true
			break
	if Game.incident.get("tasks") != tasks:
		Game.incident["tasks"] = tasks
		Game.incident_changed.emit()



func _vapour_at(at: Vector3) -> float:
	if _hazard.is_empty():
		return 0.0
	var distance: float = (_hazard["position"] as Vector3).distance_to(at)
	return float(_hazard["level"]) * clampf((float(_hazard["radius"]) - distance) / (float(_hazard["radius"]) * 0.5), 0.0, 1.0)




func _cordon_parts(at: Vector3) -> Array:
	var found: Array = []
	var cordon: Variant = Cordon.current.cordon if Cordon.current != null else {}
	if not cordon is Dictionary:
		return found
	var reach: = float(Config.Incidents.Hazmat.CordonReach)
	var since: = int(_leak.get("cordon_from", 0))
	for cone: Dictionary in cordon.get("cones", []):
		if int(cone.get("id", 0)) > since and Vector2(cone["x"] - at.x, cone["z"] - at.z).length() < reach:
			found.append(cone)
	for tape: Dictionary in cordon.get("tapes", []):
		if int(tape.get("id", 0)) > since and Vector2((tape["ax"] + tape["bx"]) / 2.0 - at.x, (tape["az"] + tape["bz"]) / 2.0 - at.z).length() < reach:
			found.append(tape)
	return found



func _cordon_count(at: Vector3) -> int:
	var count: = 0
	for part: Dictionary in _cordon_parts(at):
		count += 2 if part.has("ax") else 1
	return count



func _cordoned(at: Vector3) -> bool:
	return _cordon_count(at) >= int(Config.Incidents.Hazmat.CordonNeeded)



func _cordon_placers(at: Vector3) -> Array:
	var found: Array = []
	for part: Dictionary in _cordon_parts(at):
		var by: Variant = part.get("by")
		if is_instance_valid(by) and not found.has(by):
			found.append(by)
	return found



func _on_water(hit: Dictionary, dt: float, _direction: Vector3, player: Player) -> void :
	if _leak.is_empty() or Net.is_client():
		return
	var middle: = _cloud_middle()
	var radius: = _cloud_radius()
	var landed: Vector3 = hit["position"]
	if landed.distance_to(middle) > radius + 4.0 and landed.distance_to(_leak["leak"]) > 14.0:
		return
	var fog: bool = player != null and player.get_attr("Pattern") == "Fog"
	if fog:
		_leak["fogged_at"] = Game.now()
	_leak["cloud"] = maxf(0.0, _leak["cloud"] - FOG_POWER * dt * (1.0 if fog else 0.33) * (0.4 if _leak["leaking"] else 1.0))
	if player != null:
		_leak["contributors"][player] = true







func _has_own_valve() -> bool:
	if _leak["id"] == "tanks":
		return true
	if _leak["id"] == "ammonia":
		for source: Dictionary in _sources:
			if source["id"] == "ammonia":
				return source.get("own_valve", false)
	return false




func _dress_valve(holder: Node3D, out: Vector3) -> void :
	var model: = Node3D.new()
	model.name = "Valve"
	holder.add_child(model)
	model.basis = Basis.looking_at( - out, Vector3.UP)
	var steel: = Color8(150, 154, 158)
	var dark: = Color8(52, 54, 58)
	var red: = Color8(200, 34, 28)
	var along: = Basis(Vector3.UP, PI / 2.0)
	CallKit.piece(model, CallKit.CYLINDER, Vector3(2.2, 0.55, 0.55), Transform3D(along, Vector3(0, 0, -0.4)), steel)
	for z: float in [-1.4, -0.45, 0.45]:
		CallKit.piece(model, CallKit.CYLINDER, Vector3(0.14, 0.95, 0.95), Transform3D(along, Vector3(0, 0, z)), steel)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.8, 0.9, 0.8), Transform3D(Basis.IDENTITY, Vector3.ZERO), dark)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.5, 0.7, 0.5), Transform3D(Basis.IDENTITY, Vector3(0, 0.75, 0)), dark)
	CallKit.piece(model, CallKit.CYLINDER, Vector3(0.9, 0.14, 0.14), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(0, 1.35, 0)), Color8(196, 200, 204))
	var wheel: = Node3D.new()
	wheel.name = "Wheel"
	wheel.position = Vector3(0, 1.7, 0)
	model.add_child(wheel)
	CallKit.piece(wheel, CallKit.CYLINDER, Vector3(0.12, 1.3, 1.3), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3.ZERO), red)
	CallKit.piece(wheel, CallKit.CYLINDER, Vector3(0.14, 1.0, 1.0), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3.ZERO), dark)
	for turn in 2:
		CallKit.piece(wheel, CallKit.BLOCK, Vector3(1.1, 0.08, 0.12), Transform3D(Basis(Vector3.UP, turn * PI / 2.0), Vector3(0, 0.02, 0)), red)
	CallKit.piece(wheel, CallKit.CYLINDER, Vector3(0.2, 0.25, 0.25), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(0, 0.06, 0)), dark)
	CallKit.piece(model, CallKit.CYLINDER, Vector3(0.6, 0.45, 0.45), Transform3D(along, Vector3(0, 0, 0.8)), steel)
	CallKit.piece(model, CallKit.CYLINDER, Vector3(0.1, 0.7, 0.7), Transform3D(along, Vector3(0, 0, 1.12)), red)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.5, 0.35, 0.04), Transform3D(Basis.IDENTITY, Vector3(0.0, -0.75, 0.42)), CallFixture.PLATE)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.03, 0.4, 0.03), Transform3D(Basis.IDENTITY, Vector3(0.0, -0.45, 0.42)), dark)



func _valve_shut() -> void :
	if not is_instance_valid(_valve_prompt):
		return
	var holder: = _valve_prompt.get_parent()
	CallFixture.done(holder)
	var wheel: = holder.get_node_or_null("Valve/Wheel") as Node3D
	if wheel != null and not wheel.has_meta("shut"):
		wheel.set_meta("shut", true)
		wheel.create_tween().tween_property(wheel, "rotation:y", wheel.rotation.y + TAU * 2.0, VALVE_HOLD * 0.6)
		wheel.create_tween().tween_property(wheel, "position:y", wheel.position.y - 0.3, VALVE_HOLD * 0.6)






func _build_valve() -> void :
	if is_instance_valid(_valve_prompt):
		_valve_prompt.get_parent().queue_free()
	var holder: = Node3D.new()
	add_child(holder)
	holder.global_position = _leak["at"]
	var flat: = Vector3((_leak["leak"] as Vector3).x - (_leak["at"] as Vector3).x, 0, (_leak["leak"] as Vector3).z - (_leak["at"] as Vector3).z)
	var out: = flat.normalized() if flat.length() > 0.3 else Vector3.RIGHT
	if not _has_own_valve():
		_dress_valve(holder, out)
	CallFixture.mark(holder, Vector3(0, 2.4, 0), out, "valve")
	var prompt: = Prompt.new()
	prompt.net_id = "hazmat.valve"
	prompt.action = Text.m("calls.hazmat.valve.action")
	prompt.object = Text.m("calls.hazmat.valve.object")
	prompt.hold = VALVE_HOLD
	prompt.reach = 9.0
	holder.add_child(prompt)
	_valve_prompt = prompt
	prompt.triggered.connect( func(player: Player) -> void :
		if _leak.is_empty() or not _leak["leaking"]:
			return
		if not (player.get_attr("Scba", false) == true and player.get_attr("Mask", false) == true):
			Game.tell(player, Text.m("calls.hazmat.needMask"))
			return
		if SUBSTANCES[_leak["substance"]].get("skin", false) and not ChemSuit.wearing(player):
			Game.tell(player, Text.m("calls.hazmat.needSuit"))
			return
		_leak["leaking"] = false
		_leak["contributors"][player] = true
		Game.notify(Text.f("calls.hazmat.shut", [player.display_name]), "good")
		if not _leak.get("cordon", false):

			Game.notify(Text.m("calls.hazmat.task.noCordon"), "warning")
	)




func _build_prompts() -> void :
	for key: String in _prompts:
		if is_instance_valid(_prompts[key]):
			_prompts[key].get_parent().queue_free()
	_prompts = {}
	var settings: Dictionary = Config.Incidents.Hazmat
	var places: = {"foam": (_leak["leak"] as Vector3) + Vector3(0, 1.2, 0), "decon": (_leak["decon"] as Vector3) + Vector3(0, 1.5, 0)}
	if _leak.get("drain") != null:
		places["drain"] = (_leak["drain"] as Vector3) + Vector3(0, 1.0, 0)
	for key: String in places:
		var holder: = Node3D.new()
		add_child(holder)
		holder.global_position = places[key]
		var prompt: = Prompt.new()
		prompt.net_id = "hazmat." + key
		prompt.action = Text.m("calls.hazmat.%s.action" % key)
		prompt.object = Text.m("calls.hazmat.%s.object" % key)
		prompt.hold = float(settings["%sHold" % key.capitalize()])
		prompt.reach = 16.0 if key == "foam" else 9.0
		holder.add_child(prompt)
		_prompts[key] = prompt

	_prompts["foam"].condition = func(player: Player) -> bool:
		return CallGear.carried(player) == "Foam" or not is_instance_valid(_valve_prompt) or not _valve_prompt.shown_to(player)\
		or player.root_position().distance_to(_valve_prompt.global_position) > 7.0
	_prompts["foam"].triggered.connect( func(player: Player) -> void :
		if _leak.is_empty() or _leak["foamed"]:
			return
		if CallGear.current == null or not CallGear.current.use(player, "Foam"):
			Game.tell(player, Text.m("calls.hazmat.foam.need"))
			return
		_leak["foamed"] = true
		_leak["contributors"][player] = true
		Game.notify(Text.f("calls.hazmat.foam.done", [player.display_name]), "good")
	)
	if _prompts.has("drain"):
		_prompts["drain"].triggered.connect( func(player: Player) -> void :
			if _leak.is_empty() or _leak["drain_covered"] or _leak["drained"]:
				return
			_leak["drain_covered"] = true
			_leak["contributors"][player] = true
			Game.notify(Text.m("calls.hazmat.drain.done"), "good", player)
		)
	_prompts["decon"].triggered.connect( func(player: Player) -> void :
		if _leak.is_empty():
			return
		_leak["cleaned"][player] = true
		Game.notify(Text.m("calls.hazmat.decon.done"), "good", player)
	)





func _cloud_middle() -> Vector3:
	var leak: Vector3 = _leak["leak"]
	return leak + _wind() * _cloud_radius() * 0.35 + Vector3(0, 2.0, 0)



func _wind() -> Vector3:
	var wind: Variant = _leak.get("wind")
	return (wind as Vector3).normalized() if wind is Vector3 else World.WIND.normalized()



static func compass(wind: Vector3) -> String:
	var from: = - wind
	var bearing: = fposmod(rad_to_deg(atan2(from.x, - from.z)), 360.0)
	return ["n", "ne", "e", "se", "s", "sw", "w", "nw"][int(round(bearing / 45.0)) % 8]



func _pool_radius() -> float:
	return 1.5 + float(SUBSTANCES[_leak["substance"]]["spill"]) * float(_leak["spill"])





func _pool_step(substance: Dictionary, flames: Array) -> void :
	var leak: Vector3 = _leak["leak"]
	var radius: = _pool_radius()
	var settings: Dictionary = Config.Incidents.Hazmat
	for player in Game.players:
		if not is_instance_valid(player) or player.health <= 0.0:
			continue
		var feet: = player.root_position()
		var in_pool: = Vector2(feet.x - leak.x, feet.z - leak.z).length() <= radius * 0.9 and absf(feet.y - 3.0 - leak.y) < 4.0
		if player.brain == null and (in_pool or _vapour_at(player.head_position()) >= float(settings["DeconLine"])) and not _leak["cleaned"].has(player):
			_leak["contaminated"][player] = true
		if in_pool and not _leak["foamed"] and not ChemSuit.wearing(player) and player.brain == null:
			player.take_damage(float(settings["PoolDamage"]) * TICK)
			var now: = Game.now()
			if now - float(_hurt_told.get(player, -100.0)) > 8.0:
				_hurt_told[player] = now
				Game.notify(Text.m("calls.hazmat.pool.hurts"), "warning", player)
	var drain: Variant = _leak["drain"]
	if drain != null and not _leak["drain_covered"] and not _leak["drained"]:
		if Vector2((drain as Vector3).x - leak.x, (drain as Vector3).z - leak.z).length() <= radius:
			_leak["drained"] = true
			Game.notify(Text.m("calls.hazmat.drain.reached"), "danger")
	if _leak["foamed"] and _leak["burning"]:
		for made: Dictionary in flames:
			if made["burning"]:
				FireService.current.end_spot(made)




func _decon_spot(leak: Vector3, wind: Vector3) -> Vector3:
	var road: = IndustryZone.approach(leak)
	road.y = _floor_at(Vector3(road.x, leak.y, road.z)).y
	var out: = float(Config.Incidents.Hazmat.DeconOut)
	for turn: float in [0.0, 0.5, -0.5, 1.0, -1.0, 1.5, -1.5]:
		for reach: float in [out, out * 0.75, out * 1.3]:
			var ground: Variant = _world_ground(leak - wind.rotated(Vector3.UP, turn) * reach)
			if ground == null:
				continue
			var spot: Vector3 = ground

			if absf(spot.y - leak.y) > 4.0 or _on_railway(spot) or not decon_clear(spot, 0.5):
				continue
			for from: Vector3 in [leak, road]:
				if Game.world.raycast(spot + Vector3(0, 3, 0), from + Vector3(0, 3, 0), World.LAYER_SOLID).is_empty():
					return spot
	var along: = Vector3( - wind.x, 0, 0).normalized() if absf(wind.x) > 0.01 else Vector3.RIGHT
	return _floor_at(road + along * 20.0)




static func _on_railway(spot: Vector3) -> bool:
	for dx: float in [ - DECON_HALF - 0.5, 0.0, DECON_HALF + 0.5]:
		for dz: float in [ - DECON_HALF - 0.5, 0.0, DECON_HALF + 0.5]:
			var at: = spot + Vector3(dx, 0, dz)
			var hit: = Game.world.raycast(at + Vector3(0, 3, 0), at + Vector3(0, -2, 0), World.LAYER_SOLID | World.LAYER_QUERY)
			if not hit.is_empty() and Game.world.name_hit(hit) in ["Rail", "Sleeper", "RailBed", "RailBank", "Tracks"]:
				return true
	return false




static func _sock_spot(leak: Vector3, side: Vector3) -> Vector3:
	for reach: float in [9.0, 14.0, 20.0, 28.0]:
		for way: Vector3 in [side, - side, side.rotated(Vector3.UP, PI / 4.0), - side.rotated(Vector3.UP, - PI / 4.0)]:
			var ground: Variant = _world_ground(leak + way * reach)
			if ground == null:
				continue
			var at: Vector3 = ground
			if not Game.world.raycast(at + Vector3(0, 1, 0), at + Vector3(0, 40, 0), World.LAYER_SOLID).is_empty():
				continue
			if CallKit.box_clear(Transform3D(Basis.IDENTITY, at + Vector3(0, 3.5, 0)), Vector3(1.5, 6.0, 1.5)):
				return at
	return _floor_at(leak + side * 9.0)




static func _floor_at(at: Vector3) -> Vector3:
	var ground: Variant = _world_ground(at)
	return ground if ground != null else at




static func _world_ground(at: Vector3) -> Variant:
	var hit: = Game.world.raycast(at + Vector3(0, 6, 0), at + Vector3(0, -4, 0), World.LAYER_SOLID)
	if hit.is_empty() or Game.world.row_hit(hit) < 0:
		return null
	return hit["position"]




static func decon_clear(at: Vector3, margin: = 0.3) -> bool:
	var size: = Vector3((DECON_HALF + margin) * 2.0, DECON_EAVES + 0.8, (DECON_HALF + margin) * 2.0)
	return CallKit.box_clear(Transform3D(Basis(), at + Vector3(0, 0.15 + size.y / 2.0, 0)), size)



func _hold_decon_ground() -> void :
	if AmbulanceService.current != null and not Net.is_client():
		AmbulanceService.current.keep_clear["decon"] = {"at": _leak["decon"], "radius": DECON_REACH}





func _keep_decon_clear() -> void :
	var at: Vector3 = _leak["decon"]
	var ambulance: = AmbulanceService.current
	if decon_clear(at) and _world_ground(at) != null and not (ambulance != null and ambulance.covers(at, DECON_REACH)):
		return
	for reach: float in [9.0, 12.0, 16.0, 20.0, 26.0]:
		for turn in 8:
			var out: = Vector3(cos(turn * TAU / 8.0), 0, sin(turn * TAU / 8.0)) * reach
			var ground: Variant = _world_ground(at + out)
			if ground == null or absf((ground as Vector3).y - at.y) > 3.0:
				continue
			if decon_clear(ground) and not (ambulance != null and ambulance.covers(ground, DECON_REACH)):
				_leak["decon"] = ground
				_hold_decon_ground()
				_place_decon()
				return








func _dress_decon(decon: Node3D) -> void :
	var basin: = Color8(236, 118, 30)
	var frame: = Color8(200, 204, 208)
	var blue: = Color8(36, 96, 186)
	var white: = Color8(236, 238, 240)
	var dark: = Color8(46, 48, 52)
	var half: = DECON_HALF
	var eaves: = DECON_EAVES
	var pitch: = 0.32
	var rise: = tan(pitch) * half
	var ring: = half - 1.0
	CallKit.piece(decon, CallKit.BLOCK, Vector3(half * 2.0, 0.12, half * 2.0), Transform3D(Basis.IDENTITY, Vector3(0, 0.06, 0)), basin)

	for side: float in [-1.0, 1.0]:
		CallKit.piece(decon, CallKit.CYLINDER, Vector3(half * 2.0 + 0.6, 0.62, 0.62), Transform3D(Basis.IDENTITY, Vector3(0, 0.31, side * half)), basin)
		CallKit.piece(decon, CallKit.CYLINDER, Vector3(half * 2.0 + 0.6, 0.62, 0.62), Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(side * half, 0.31, 0)), basin)

	var slats: = 13
	for i in slats:
		CallKit.piece(decon, CallKit.BLOCK, Vector3(half * 2.0 - 1.0, 0.08, 0.42), Transform3D(Basis.IDENTITY, Vector3(0, 0.16, (half - 0.75) * (i * 2.0 / (slats - 1) - 1.0))), Color8(70, 74, 80))

	for x: float in [ - half, half]:
		for z: float in [ - half, half]:
			CallKit.piece(decon, CallKit.BLOCK, Vector3(0.16, eaves - 0.15, 0.16), Transform3D(Basis.IDENTITY, Vector3(x, (eaves + 0.15) / 2.0, z)), frame)
			CallKit.piece(decon, CallKit.BLOCK, Vector3(0.45, 0.12, 0.45), Transform3D(Basis.IDENTITY, Vector3(x, 0.2, z)), dark)
	for side: float in [-1.0, 1.0]:
		CallKit.piece(decon, CallKit.BLOCK, Vector3(half * 2.0, 0.16, 0.16), Transform3D(Basis.IDENTITY, Vector3(0, eaves, side * half)), frame)
		CallKit.piece(decon, CallKit.BLOCK, Vector3(0.16, 0.16, half * 2.0), Transform3D(Basis.IDENTITY, Vector3(side * half, eaves, 0)), frame)

		CallKit.piece(decon, CallKit.BLOCK, Vector3(half / cos(pitch) + 0.3, 0.1, half * 2.0 + 0.3), Transform3D(Basis(Vector3.BACK, side * - pitch), Vector3(side * half * 0.5, eaves + rise * 0.5 + 0.1, 0)), blue)
		CallKit.piece(decon, CallKit.BLOCK, Vector3(0.06, 0.45, half * 2.0 + 0.3), Transform3D(Basis.IDENTITY, Vector3(side * (half + 0.14), eaves - 0.05, 0)), white)

		CallKit.piece(decon, CallKit.BLOCK, Vector3(0.06, eaves - 0.85, half * 2.0 - 0.1), Transform3D(Basis.IDENTITY, Vector3(side * (half + 0.05), (eaves + 0.65) / 2.0, 0)), blue)
		CallKit.piece(decon, CallKit.BLOCK, Vector3(0.07, 0.3, half * 2.0 - 0.1), Transform3D(Basis.IDENTITY, Vector3(side * (half + 0.06), 0.9, 0)), white)
	CallKit.piece(decon, CallKit.BLOCK, Vector3(0.14, 0.14, half * 2.0 + 0.3), Transform3D(Basis.IDENTITY, Vector3(0, eaves + rise + 0.1, 0)), frame)

	var shower: = eaves - 0.4
	for side: float in [-1.0, 1.0]:
		CallKit.piece(decon, CallKit.CYLINDER, Vector3(ring * 2.0 + 0.4, 0.12, 0.12), Transform3D(Basis.IDENTITY, Vector3(0, shower, side * ring)), frame)
		CallKit.piece(decon, CallKit.CYLINDER, Vector3(ring * 2.0, 0.12, 0.12), Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(side * (ring + 0.2), shower, 0)), frame)
		for along: float in [ - ring * 0.75, - ring * 0.25, ring * 0.25, ring * 0.75]:
			CallKit.piece(decon, CallKit.CYLINDER, Vector3(0.22, 0.2, 0.2), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(along, shower - 0.13, side * ring)), dark)
	var head: = Node3D.new()
	head.position = Vector3(0, shower - 0.15, 0)
	decon.add_child(head)
	RbxEmitter.make(head, {
		"Texture": Config.Hose.MistTexture, 
		"Color": Color(0.75, 0.88, 1.0), 
		"LightInfluence": 1, 
		"Rate": 80, 
		"Speed": [2, 4], 
		"Lifetime": [0.8, 1.1], 
		"SpreadAngle": 50, 
		"Acceleration": Vector3(0, -24, 0), 
		"Size": [[0, 0.25], [1, 0.5]], 
		"Transparency": [[0, 0.45], [1, 1]], 
		"Direction": Vector3.DOWN, 
	})

	var board: = eaves + 0.5
	CallKit.piece(decon, CallKit.BLOCK, Vector3(5.6, 1.1, 0.08), Transform3D(Basis.IDENTITY, Vector3(0, board, - half - 0.12)), Color8(200, 30, 26))
	CallKit.piece(decon, CallKit.BLOCK, Vector3(5.3, 0.86, 0.1), Transform3D(Basis.IDENTITY, Vector3(0, board, - half - 0.13)), CallFixture.PLATE)
	for i in 5:
		CallKit.piece(decon, CallKit.BLOCK, Vector3(0.6, 0.18, 0.11), Transform3D(Basis.IDENTITY, Vector3(-2.0 + i * 1.0, board, - half - 0.14)), dark)

	CallKit.piece(decon, CallKit.BLOCK, Vector3(half * 2.0 - 1.0, 0.05, 1.4), Transform3D(Basis.IDENTITY, Vector3(0, 0.03, - half - 1.15)), Color8(186, 40, 34))
	CallKit.piece(decon, CallKit.BLOCK, Vector3(half * 2.0 - 1.0, 0.05, 1.4), Transform3D(Basis.IDENTITY, Vector3(0, 0.03, half + 1.15)), Color8(52, 150, 70))

	CallKit.piece(decon, CallKit.CYLINDER, Vector3(shower - 0.1, 0.22, 0.22), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(half - 0.2, shower / 2.0, half - 0.2)), blue)
	CallKit.piece(decon, CallKit.CYLINDER, Vector3(5.0, 0.22, 0.22), Transform3D(Basis(Vector3.UP, - PI / 2.0), Vector3(half - 0.2, 0.12, half + 2.4)), blue)

	CallKit.piece(decon, CallKit.CYLINDER, Vector3(1.2, 0.95, 0.95), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3( - half - 0.55, 0.6, - half - 0.7)), CallFixture.PLATE)
	CallKit.piece(decon, CallKit.CYLINDER, Vector3(0.08, 1.0, 1.0), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3( - half - 0.55, 1.22, - half - 0.7)), dark)
	CallKit.piece(decon, CallKit.BLOCK, Vector3(0.45, 0.45, 0.04), Transform3D(Basis(Vector3.BACK, PI / 4.0), Vector3( - half - 0.55, 0.7, - half - 1.18)), Color8(236, 118, 30))



func _place_decon() -> void :
	var at: Vector3 = _leak["decon"]
	var decon: Node3D = _visual.get("decon")
	if decon != null and is_instance_valid(decon) and decon.global_position.distance_to(at) > 0.05:
		decon.global_position = at
	var prompt: Prompt = _prompts.get("decon")
	if prompt != null and is_instance_valid(prompt):
		var holder: = prompt.get_parent() as Node3D
		if holder != null and holder.global_position.distance_to(at + Vector3(0, 1.5, 0)) > 0.05:
			holder.global_position = at + Vector3(0, 1.5, 0)



func _decon_left() -> int:
	if _leak.is_empty():
		return 0
	var left: = 0
	for player: Variant in _leak["contaminated"]:
		if is_instance_valid(player) and not _leak["cleaned"].has(player):
			left += 1
	return left


func _cloud_radius() -> float:
	var substance: Dictionary = SUBSTANCES[_leak["substance"]]
	return 6.0 + (float(substance["radius"]) - 6.0) * float(_leak["cloud"])



func _show_state() -> void :
	if _leak.is_empty():
		for key: String in _visual:
			if is_instance_valid(_visual[key]) and _visual[key] is Node:
				_visual[key].queue_free()
		_visual = {}
		if FireService.current != null:
			FireService.current.hazards.erase(_hazard)
		_hazard = {}
		if is_instance_valid(_valve_prompt):
			_valve_prompt.get_parent().queue_free()
		_valve_prompt = null
		for key: String in _prompts:
			if is_instance_valid(_prompts[key]):
				_prompts[key].get_parent().queue_free()
		_prompts = {}
		return
	var substance: Dictionary = SUBSTANCES[_leak["substance"]]
	var leak: Vector3 = _leak["leak"]
	if _visual.is_empty():
		var root: = Node3D.new()
		add_child(root)
		root.global_position = leak
		var pool: = MeshInstance3D.new()
		var disc: = CylinderMesh.new()
		disc.top_radius = 1.0
		disc.bottom_radius = 1.0
		disc.height = 0.04
		disc.radial_segments = 24
		pool.mesh = disc
		var shine: = StandardMaterial3D.new()
		shine.albedo_color = substance["pool"]
		shine.albedo_color.a = 0.82
		shine.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		shine.roughness = 0.05
		shine.metallic_specular = 1.0
		pool.material_override = shine
		pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(pool)
		pool.position = Vector3(0, 0.05, 0)
		var cloud_holder: = Node3D.new()
		root.add_child(cloud_holder)
		var cloud: = RbxEmitter.make(cloud_holder, {
			"Texture": "fire_smoke_flipbook", "Flipbook": true, "Color": substance["cloud"], 
			"Box": Vector3(16, 3, 16), "Speed": [0.4, 1.6], "Lifetime": [6.0, 9.0], "SpreadAngle": 180, 
			"Acceleration": _wind() * 0.85 + Vector3(0, 0.03, 0), "Rotation": [0, 360], "RotSpeed": [-8, 8], 
			"Rate": 10, "Size": [8.0, 14.0], "Transparency": [[0.0, 1.0], [0.2, 0.42], [0.7, 0.6], [1.0, 1.0]], 
		})
		_visual = {"root": root, "pool": pool, "cloud": cloud, "cloud_holder": cloud_holder, "shine": shine, "wind": _wind()}
		_build_marks(root, substance)
		var stream: AudioStream = Assets.sound("steam_hiss")
		if stream != null:
			_visual["hiss"] = Sounds.emitter(root, stream, 0.5, 8.0, 60.0, true)
		if FireService.current != null:
			_hazard = {"position": leak, "radius": 6.0, "level": 0.0}
			FireService.current.hazards.append(_hazard)
	var spill: = _pool_radius()
	(_visual["pool"] as MeshInstance3D).scale = Vector3(spill, 1, spill)

	var shine: StandardMaterial3D = _visual["shine"]
	shine.albedo_color = Color(0.74, 0.7, 0.62, 0.97) if _leak.get("foamed", false) else Color(substance["pool"], 0.82)
	shine.roughness = 0.9 if _leak.get("foamed", false) else 0.05
	_show_marks(substance)
	var radius: = _cloud_radius()
	var level: float = _leak["cloud"]
	(_visual["cloud_holder"] as Node3D).global_position = _cloud_middle()
	var cloud: RbxEmitter = _visual["cloud"]
	cloud.set_rate(4.0 + 60.0 * level)
	cloud.set_size([radius * 0.45, radius * 0.8])
	if _visual.has("hiss") and is_instance_valid(_visual["hiss"]):
		(_visual["hiss"] as AudioStreamPlayer3D).volume_db = linear_to_db(0.5 if _leak["leaking"] else 0.0001)
	_hazard["position"] = _cloud_middle()
	_hazard["radius"] = radius
	_hazard["level"] = clampf(level * 1.3, 0.0, 1.0)
	if is_instance_valid(_valve_prompt):
		_valve_prompt.enabled = _leak["leaking"]
		if not _leak["leaking"]:
			_valve_shut()
	if _prompts.has("foam") and is_instance_valid(_prompts["foam"]):
		_prompts["foam"].enabled = not _leak.get("foamed", false)
	if _prompts.has("drain") and is_instance_valid(_prompts["drain"]):
		_prompts["drain"].enabled = not _leak.get("drain_covered", false) and not _leak.get("drained", false)



func _build_marks(_root: Node3D, substance: Dictionary) -> void :
	var leak: Vector3 = _leak["leak"]

	var sock: = Node3D.new()
	sock.name = "Windsock"
	add_child(sock)
	var side: = _wind().rotated(Vector3.UP, PI / 2.0)
	sock.global_position = _sock_spot(leak, side)
	CallKit.piece(sock, CallKit.CYLINDER, Vector3(6.0, 0.18, 0.18), Transform3D(Basis(Vector3.BACK, PI / 2.0), Vector3(0, 3.0, 0)), Color8(200, 200, 204))
	var cone: = Node3D.new()
	cone.name = "Sock"
	sock.add_child(cone)
	cone.position = Vector3(0, 5.8, 0)
	for band in 4:
		var radius: = 0.55 - band * 0.09
		CallKit.piece(cone, CallKit.CYLINDER, Vector3(0.7, radius * 2.0, radius * 2.0), Transform3D(Basis.IDENTITY, Vector3(0.35 + band * 0.7, 0, 0)), Color8(240, 110, 20) if band % 2 == 0 else Color8(245, 245, 240))
	_visual["sock"] = sock
	_visual["sock_cone"] = cone

	var plume: = MeshInstance3D.new()
	var sheet: = PlaneMesh.new()
	sheet.size = Vector2(2, 2)
	plume.mesh = sheet
	var haze: = StandardMaterial3D.new()
	var white: bool = substance.get("skin", false)
	haze.albedo_color = Color(0.96, 0.97, 0.95, 0.42) if white else Color(0.85, 0.84, 0.66, 0.26)

	var fade: = GradientTexture2D.new()
	fade.fill = GradientTexture2D.FILL_RADIAL
	fade.fill_from = Vector2(0.5, 0.5)
	fade.fill_to = Vector2(0.5, 0.0)
	fade.width = 128
	fade.height = 128
	var ramp: = Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 1))
	ramp.set_color(1, Color(1, 1, 1, 0))
	ramp.add_point(0.45, Color(1, 1, 1, 0.75))
	fade.gradient = ramp
	haze.albedo_texture = fade
	haze.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	haze.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	haze.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	haze.cull_mode = BaseMaterial3D.CULL_DISABLED
	plume.material_override = haze
	plume.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(plume)
	_visual["plume"] = plume

	var decon: = Node3D.new()
	decon.name = "Decon"
	add_child(decon)
	decon.global_position = _leak["decon"]
	var toward: = Vector3(leak.x - decon.global_position.x, 0, leak.z - decon.global_position.z)
	if toward.length() > 0.5:
		decon.basis = Basis.looking_at(toward.normalized(), Vector3.UP)
	_dress_decon(decon)
	_visual["decon_words"] = CallKit.words(decon, Text.m("calls.hazmat.decon.mark"), Color8(120, 200, 255), DECON_EAVES + tan(0.32) * DECON_HALF + 1.4, 70.0)
	_visual["decon"] = decon

	if _leak.get("drain") != null:
		var drain: = Node3D.new()
		drain.name = "Drain"
		add_child(drain)
		drain.global_position = _leak["drain"]
		CallKit.piece(drain, CallKit.BLOCK, Vector3(2.4, 0.08, 1.4), Transform3D(Basis.IDENTITY, Vector3(0, 0.05, 0)), Color8(24, 24, 26))
		for bar in 6:
			CallKit.piece(drain, CallKit.BLOCK, Vector3(0.14, 0.1, 1.3), Transform3D(Basis.IDENTITY, Vector3(-1.0 + bar * 0.4, 0.1, 0)), Color8(70, 70, 74))
		var cover: = CallKit.piece(drain, CallKit.BLOCK, Vector3(3.0, 0.12, 2.0), Transform3D(Basis.IDENTITY, Vector3(0, 0.14, 0)), Color8(230, 120, 20))
		_visual["drain"] = drain
		_visual["drain_cover"] = cover
		_visual["drain_words"] = CallKit.words(drain, Text.m("calls.hazmat.drain.mark"), Color8(255, 190, 60), 2.0, 60.0)



func _show_marks(substance: Dictionary) -> void :
	var wind: = _wind()
	if _visual.has("sock_cone") and is_instance_valid(_visual["sock_cone"]):
		(_visual["sock_cone"] as Node3D).global_basis = Basis(Vector3.UP, atan2( - wind.z, wind.x))
	if _visual.has("plume") and is_instance_valid(_visual["plume"]):
		var plume: MeshInstance3D = _visual["plume"]
		var radius: = _cloud_radius()
		var middle: = _cloud_middle()
		var ground: = CallKit.ground_at(middle + Vector3(0, 4, 0))
		var along: = Basis(Vector3.UP, atan2(wind.x, wind.z))
		plume.global_transform = Transform3D(along * Basis.from_scale(Vector3(radius * 0.8, 1, radius * 1.15)), ground + Vector3(0, 0.12, 0))
		var thick: float = clampf(float(_leak["cloud"]) * 1.4, 0.15, 1.0)
		var haze: StandardMaterial3D = plume.material_override
		haze.albedo_color.a = (0.42 if substance.get("skin", false) else 0.26) * thick
	if _visual.has("drain_cover") and is_instance_valid(_visual["drain_cover"]):
		_visual["drain_cover"].visible = _leak.get("drain_covered", false)
		_visual["drain_words"].visible = not _leak.get("drain_covered", false)

	if _visual.has("wind") and (_visual["wind"] as Vector3).distance_to(wind) > 0.05:
		_visual["wind"] = wind
		var holder: Node3D = _visual["cloud_holder"]
		if is_instance_valid(_visual["cloud"]):
			_visual["cloud"].queue_free()
		_visual["cloud"] = RbxEmitter.make(holder, {
			"Texture": "fire_smoke_flipbook", "Flipbook": true, "Color": substance["cloud"], 
			"Box": Vector3(16, 3, 16), "Speed": [0.4, 1.6], "Lifetime": [6.0, 9.0], "SpreadAngle": 180, 
			"Acceleration": wind * 0.85 + Vector3(0, 0.03, 0), "Rotation": [0, 360], "RotSpeed": [-8, 8], 
			"Rate": 10, "Size": [8.0, 14.0], "Transparency": [[0.0, 1.0], [0.2, 0.42], [0.7, 0.6], [1.0, 1.0]], 
		})



func _process(_delta: float) -> void :
	if _leak.is_empty() or _hazard.is_empty():
		return
	_place_decon()
	if not Net.is_client() and Game.now() - _decon_checked > 1.0:
		_decon_checked = Game.now()
		_keep_decon_clear()
	var me: = Game.local_player
	if me == null:
		return
	var level: = _vapour_at(me.head_position())
	if level < float(Config.Incidents.Hazmat.BeepFrom):
		return
	var now: = Game.now()
	if now - _beep_at >= lerpf(0.9, 0.22, clampf(level, 0.0, 1.0)):
		_beep_at = now
		Sounds.ui("ui_tick", 2.2, 0.8)





func _net_state() -> Variant:
	if _leak.is_empty():
		return {}
	return {
		"id": _leak["id"], "substance": _leak["substance"], "at": _leak["at"], "leak": _leak["leak"], 
		"leaking": _leak["leaking"], "spill": snappedf(_leak["spill"], 0.01), "cloud": snappedf(_leak["cloud"], 0.01), 
		"cordon": _leak["cordon"], "wind": _leak["wind"], "decon": _leak["decon"], "drain": _leak["drain"], 
		"foamed": _leak["foamed"], "drain_covered": _leak["drain_covered"], "drained": _leak["drained"], 
	}


func _net_apply(state: Variant) -> void :
	if not Net.is_client():
		return
	if not state is Dictionary or (state as Dictionary).is_empty():
		if not _leak.is_empty():
			_leak = {}
			_show_state()
		return
	_mirrored = true
	var fresh: bool = _leak.is_empty() or _leak.get("id") != state["id"]
	if fresh and not _leak.is_empty():
		_leak = {}
		_show_state()
	_leak = (state as Dictionary).duplicate()
	if fresh:
		_build_valve()
		_build_prompts()
	_show_state()
