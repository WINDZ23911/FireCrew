extends RefCounted










const WALLS: = ["Body", "Gable", "Wing", "Parapet", "StairHead", "Penthouse", "Dormer", "GroundFloor", "FarHouse"]
const ROOFS: = ["Roof", "WingRoof", "DormerRoof", "FarRoof"]
const OLD_RENDER: = ["D9A441", "E0B45C", "D98F6A", "C9705A", "9E3B30", "B5BC8E", "9FB3A8", "A9BFD0", "EFE3C6", "E8D2A6", "F0E6D2", "C98B4E"]
const NEW_RENDER: = ["F1ECE2", "EDE4D2", "E6DDCB", "F3EEE6", "DED8CC", "E9E1C9", "D8D2C2"]
const OLD_TILES: = ["8E3E2C", "9A4630", "7E3828", "A04C34", "86402E"]
const OAK: = Color8(74, 50, 36)
const INFILL: = Color8(240, 234, 220)
const FLOOR: = 10.0
const TIMBERED: = 40


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "de":
		return ""
	var data: Variant = Rbx.load_json(Edition.path("OldTown.json", ""))
	var outline: Array = data.get("outline", []) if data is Dictionary else []
	var store: = kit.store
	var layout: Array = kit.layout()["buildings"]
	var folder: = kit.own_folder("HalfTimber")
	var counts: = {"old": 0, "new": 0, "timbered": 0, "washing": 0}
	for model in kit.models_under("Map/Buildings"):
		var rows: = store.rows_in(model)
		var body: = -1
		for row in rows:
			if store.name_at(row) == "Body":
				body = row
				break
		if body < 0:
			continue
		var at: = store.position(body)
		var spot: = Vector2(at.x, at.z)
		var old: = _inside(outline, spot)
		var key: = [int(spot.x), int(spot.y)]
		var wall: = Color("#" + _pick(OLD_RENDER if old else NEW_RENDER, key + ["render"]))
		var timbered: = old and store.size(body).y >= FLOOR * 1.8 and _roll(key + ["timber"]) % 100 < TIMBERED
		if timbered:
			wall = INFILL
		for row in rows:
			var part: = store.name_at(row)
			var material: = store.material(row)
			if part in WALLS and material in ["Plaster", "Concrete", "SmoothPlastic", "Plastic"]:
				store.set_color(row, wall.darkened(0.06) if part == "GroundFloor" else wall)
			elif old and part in ROOFS and material == "ClayRoofTiles":
				store.set_color(row, Color("#" + _pick(OLD_TILES, key + ["tiles"])))
		counts["old" if old else "new"] += 1
		if timbered:
			_timber(kit, folder, store, body, _nearest(layout, spot))
			counts["timbered"] += 1
	for row in store.count:
		var part: = store.name_at(row)
		if part == "Washing" or part == "Line":
			store.set_transparency(row, 1.0)
			store.set_flags(row, 0)
			counts["washing"] += 1
	return "German houses: %d in the old town (%d half-timbered), %d outside, %d washing lines taken in" % [
		counts["old"], counts["timbered"], counts["new"], counts["washing"]]




static func _timber(kit: PolishKit, folder: int, store: PartStore, body: int, building: Dictionary) -> void :
	var place: = store.transform(body)
	var size: = store.size(body)
	var yaw: = deg_to_rad(float(building.get("yaw", 0.0)))
	var front: = Vector3( - sin(yaw), 0, - cos(yaw))

	var x_axis: = place.basis.x.normalized()
	var z_axis: = place.basis.z.normalized()
	var normal: = x_axis if absf(x_axis.dot(front)) > absf(z_axis.dot(front)) else z_axis
	var reach: = size.x / 2.0 if normal == x_axis else size.z / 2.0
	var width: = size.z if normal == x_axis else size.x
	if normal.dot(front) < 0.0:
		normal = - normal
	var across: = Vector3.UP.cross(normal).normalized()
	var bottom: = place.origin.y - size.y / 2.0
	var top: = place.origin.y + size.y / 2.0
	var face: = place.origin + normal * (reach + 0.12)
	var first: = bottom + FLOOR
	if top - first < 6.0:
		return
	var frame: = Transform3D(Basis(across, Vector3.UP, normal), Vector3.ZERO)
	var y: = first
	while y < top - 0.5:
		kit.box(folder, frame.translated(Vector3(face.x, y, face.z)), Vector3(width, 0.7, 0.25), OAK, "Wood", "Timber")
		y += FLOOR
	kit.box(folder, frame.translated(Vector3(face.x, top - 0.4, face.z)), Vector3(width, 0.8, 0.25), OAK, "Wood", "Timber")
	for side: float in [-1.0, 1.0]:
		var edge: = face + across * side * (width / 2.0 - 0.4)
		kit.box(folder, frame.translated(Vector3(edge.x, (first + top) / 2.0, edge.z)), Vector3(0.7, top - first, 0.25), OAK, "Wood", "Timber")
		var storey: = first
		while storey + FLOOR <= top + 0.5:
			var low: = face + across * side * (width / 2.0 - 0.6)
			var high: = face + across * side * (width / 2.0 - 3.6)
			kit.rod(folder, Vector3(low.x, storey + 0.3, low.z), Vector3(high.x, storey + FLOOR - 0.6, high.z), 0.5, OAK, "Wood", "Timber")
			storey += FLOOR


static func _inside(outline: Array, p: Vector2) -> bool:
	if outline.size() < 3:
		return false
	for i in outline.size():
		var a: Array = outline[i - 1]
		var b: Array = outline[i]
		if (float(b[0]) - float(a[0])) * (p.y - float(a[1])) - (float(b[1]) - float(a[1])) * (p.x - float(a[0])) < 0.0:
			return false
	return true


static func _nearest(layout: Array, spot: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building
	return best


static func _roll(key: Array) -> int:
	return rand_from_seed(hash(key))[0]


static func _pick(list: Array, key: Array) -> String:
	return str(list[_roll(key) % list.size()])
