extends Node




var data: Dictionary = {}


func _init() -> void :
	data = Rbx.module("Config")
	var own: Variant = Rbx.decode(Rbx.load_json("res://data/godot/Config.json"))
	if own is Dictionary:
		_merge(data, own)

	var edition: = Edition.path("Config.json", "")
	if not edition.is_empty():
		var theirs: Variant = Rbx.decode(Rbx.load_json(edition))
		if theirs is Dictionary:
			_merge(data, theirs)



static func _merge(into: Dictionary, own: Dictionary) -> void :
	for key: Variant in own:
		if into.get(key) is Dictionary and own[key] is Dictionary:
			_merge(into[key], own[key])
		else:
			into[key] = own[key]


func _get(property: StringName) -> Variant:
	return data.get(String(property))
