class_name Alarm
extends RefCounted









static var level: = 1
static var active: = false
static var forced: = 0
static var escalation: = ""
static var forced_escalation: = ""
static var forced_complications: Array = []

static var started_at: = 0.0
static var arrived_at: = -1.0
static var injuries: = 0.0
static var on_scene: Dictionary = {}
static var time_on_scene: Dictionary = {}
static var station_distance: = 0.0

static var job_par: = -1.0
static var job_done_at: = -1.0
static var checks: Dictionary = {}
static var cordon_from: = 0
static var first_at: = Vector3.INF


static var stats: Dictionary = {}


static var earned: Dictionary = {}
static var smoke_hp: = 0.0
static var stars: = 0
static var handed_worst: = 101.0
static var _health: Dictionary = {}
static var _hose: Dictionary = {}


static func settings() -> Dictionary:
	return Config.Alarm


static func _args() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--alarm="):
			forced = clampi(int(arg.substr(8)), 1, 3)
		elif arg.begins_with("--escalate="):
			forced_escalation = arg.substr(11)
		elif arg.begins_with("--complicate="):
			forced_complications = Array(arg.substr(13).split(","))




static func crew_rank() -> int:
	var saved: Array = []
	for player in Game.players:
		if is_instance_valid(player) and player.brain == null:
			saved.append(int(player.get_attr("Saved", 0)))
	return median_rank(saved)



static func median_rank(saved: Array) -> int:
	var ranks: Array[int] = []
	for count: Variant in saved:
		ranks.append(rank_of(int(count)))
	if ranks.is_empty():
		return 0
	ranks.sort()
	return ranks[floori((ranks.size() - 1) / 2.0)]



static func rank_of(saved: int) -> int:
	var rank: = 0
	var ranks: Array = Config.Gear.Ranks
	for index in ranks.size():
		if saved >= int(ranks[index]["saved"]):
			rank = index
	return rank



static func ai_crew() -> int:
	var count: = 0
	for player in Game.players:
		if is_instance_valid(player) and player.brain != null:
			count += 1
	return count




static func level_weights() -> Array:
	var row: Array = Shift.weights()
	if row.is_empty():
		var weights: Array = settings()["Weights"]
		row = (weights[clampi(crew_rank(), 0, weights.size() - 1)] as Array).duplicate()
		var moved: = minf(float(row[0]), crowd() * float(settings()["Crowd"]["Shift"]))
		row[0] = float(row[0]) - moved
		row[1] = float(row[1]) + moved * 0.6
		row[2] = float(row[2]) + moved * 0.4
	return row





static func crowd() -> int:
	return maxi(0, Game.humans() - int(settings()["Crowd"]["From"]) + 1)



static func begin() -> int:
	_args()
	if forced > 0:
		level = forced
	else:
		var row: Array = level_weights()
		var drawn: = randf() * (float(row[0]) + float(row[1]) + float(row[2]))
		level = 3
		for index in 3:
			drawn -= float(row[index])
			if drawn <= 0.0 and float(row[index]) > 0.0:
				level = index + 1
				break

		if Game.humans() <= 1 and ai_crew() == 0:
			level = mini(level, int(settings()["AloneMost"]))
	active = true
	escalation = ""
	started_at = Game.now()
	arrived_at = -1.0
	injuries = 0.0
	on_scene = {}
	time_on_scene = {}
	station_distance = 0.0
	job_par = -1.0
	job_done_at = -1.0
	checks = {}
	cordon_from = Cordon.current.made() if Cordon.current != null else 0
	first_at = Vector3.INF
	stats = {}
	earned = {}
	smoke_hp = 0.0
	stars = 0
	handed_worst = 101.0
	_health = {}
	_hose = {}
	return level


static func end() -> void :
	active = false
	escalation = ""



static func pick(key: String) -> Variant:
	var table: Array = settings()[key]
	return table[clampi(level, 1, table.size()) - 1]





static func crew() -> int:
	var bump: = int(pick("CrewBump")) if active else 0
	return Game.humans() + int(round(ai_crew() * float(settings()["AICrew"]))) + bump



static func pay(amount: int) -> int:
	if not active or amount <= 0:
		return amount
	return int(round(amount * float(pick("Pay")) * Shift.pay()))



static func numeral(value: = level) -> String:
	return ["I", "II", "III"][clampi(value, 1, 3) - 1]




static func draw_escalation(possible: Array) -> String:
	if possible.is_empty():
		return ""
	if not forced_escalation.is_empty():
		escalation = forced_escalation if forced_escalation in possible else ""
		return escalation
	if randf() < float(pick("Escalate")) + crowd() * float(settings()["Crowd"]["Escalate"]):
		escalation = possible[randi() % possible.size()]
	return escalation



static func watch(at: Vector3, dt: = 0.5) -> void :
	var reach: = float(Config.Fire.ArriveRange)
	for player in Game.players:
		if is_instance_valid(player) and player.root_position().distance_to(at) <= reach:
			on_scene[player] = true
			time_on_scene[player] = float(time_on_scene.get(player, 0.0)) + dt
			if arrived_at < 0.0:
				arrived_at = Game.now()
				first_at = player.root_position()
	_look_at_crew(dt)




static func _look_at_crew(dt: float) -> void :
	var fire: = FireService.current
	var line: = float(settings()["Grade"]["SmokeLine"])
	for player in Game.players:
		if not is_instance_valid(player):
			continue
		var masked: bool = player.get_attr("Mask", false) == true
		var before: = float(_health.get(player, player.health))
		_health[player] = player.health
		if not masked and player.health < before and fire != null and fire.smoke_at(player.head_position()) >= line:
			smoke_hp += before - player.health
		if player.brain != null:
			continue
		if masked:
			note(player, "air", dt)
		var laying: Variant = player.get_attr("HoseLength")
		if laying != null:
			_hose[player] = maxf(float(_hose.get(player, 0.0)), float(laying))
		elif _hose.has(player):
			note(player, "hose", float(_hose[player]))
			_hose.erase(player)






static func flush() -> void :
	for player: Variant in _hose:
		note(player, "hose", float(_hose[player]))
	_hose = {}



static func par(seconds: float) -> void :
	if active:
		job_par = maxf(seconds, 1.0)



static func done() -> void :
	if active and job_done_at < 0.0:
		job_done_at = Game.now()



static func check(id: String, passed: bool) -> void :
	if active:
		checks[id] = passed



static func note(player: Variant, stat: String, amount: = 1.0) -> void :
	if not active:
		return
	var who: = CallKit.payee(player)
	if who == null:
		return
	if not stats.has(who):
		stats[who] = {}
	stats[who][stat] = float(stats[who].get(stat, 0.0)) + amount



static func earn(player: Player, amount: int, item: String) -> void :
	if not active or amount <= 0 or player == null:
		return
	if not earned.has(player):
		earned[player] = {}
	earned[player][item] = int(earned[player].get(item, 0)) + amount



static func handed(condition: float) -> void :
	if active:
		handed_worst = minf(handed_worst, condition)



static func cones_near(at: Vector3, reach: float) -> int:
	var count: = 0
	var cordon: Variant = Cordon.current.cordon if Cordon.current != null else {}
	if not cordon is Dictionary:
		return 0
	for cone: Dictionary in cordon.get("cones", []):
		if int(cone.get("id", 0)) > cordon_from and Vector2(cone["x"] - at.x, cone["z"] - at.z).length() < reach:
			count += 1
	for tape: Dictionary in cordon.get("tapes", []):
		if int(tape.get("id", 0)) > cordon_from and Vector2((tape["ax"] + tape["bx"]) / 2.0 - at.x, (tape["az"] + tape["bz"]) / 2.0 - at.z).length() < reach:
			count += 2
	return count




static func stayed() -> Array:
	var found: Array = []
	if not active or arrived_at < 0.0:
		return found
	var since: = maxf(Game.now() - arrived_at, 1.0)
	for player: Variant in time_on_scene:
		if is_instance_valid(player) and float(time_on_scene[player]) >= since * float(settings()["HelperStay"]):
			found.append(player)
	return found



static func hurt(amount: float) -> void :
	if active:
		injuries += amount












static func debrief(kind: String, last: Dictionary) -> Dictionary:
	var g: Dictionary = settings()["Grade"]
	var weights: Dictionary = g["Weights"]
	var failed: bool = last.get("failed", false) or float(last.get("health", 100.0)) <= 0.0
	var parts: Array = []


	var came: = arrived_at
	if kind == "fire" and Duty.water_at >= 0.0 and arrived_at >= 0.0:
		came = maxf(arrived_at, Duty.water_at)
	var turnout: = came - started_at if came >= 0.0 else -1.0
	var expected: = float(g["TurnoutBase"]) + station_distance / float(g["TurnoutSpeed"])
	parts.append(["turnout", against_par(turnout, expected), float(weights["turnout"])])



	var total: = int(last.get("victims", 0))
	var out: = int(last.get("victims_out", 0))
	var fetched: = int(last.get("victims_fetched", 0))
	var lost: = int(last.get("victims_lost", 0))
	if total > 0:
		parts.append(["people", clampf((out + fetched * float(g["MedicsCredit"])) / total, 0.0, 1.0), float(weights["people"])])


	var health: = -1.0
	if last.has("flames"):
		health = maxf(float(last.get("health", 0.0)), 0.0)
		parts.append(["building", clampf(health / float(g["GoodHealth"]), 0.0, 1.0), float(weights["building"])])
	else:
		parts.append(["outcome", 0.0 if failed else 1.0, float(weights["building"])])

	var safe: Array = g["Injuries"]
	parts.append(["safety", clampf(1.0 - (injuries - float(safe[0])) / (float(safe[1]) - float(safe[0])), 0.0, 1.0), float(weights["safety"])])


	var job_time: = job_done_at - arrived_at if job_done_at >= 0.0 and arrived_at >= 0.0 else -1.0
	if job_par > 0.0:
		parts.append(["job", against_par(job_time, job_par), float(weights["job"])])
	var listed: Array = []
	var passed: = 0
	for id: String in checks:
		listed.append([id, bool(checks[id])])
		passed += int(bool(checks[id]))
	if not listed.is_empty():
		parts.append(["procedure", float(passed) / listed.size(), float(weights["procedure"])])

	var sum: = 0.0
	var weight: = 0.0
	var weakest: = ""
	var lowest: = 0.999
	for part: Array in parts:
		sum += float(part[1]) * float(part[2])
		weight += float(part[2])
		if float(part[1]) < lowest:
			lowest = float(part[1])
			weakest = part[0]
	var score: = sum / maxf(weight, 0.001)
	var grade: = "C"
	for candidate: String in ["S", "A", "B"]:
		if score >= float(g["Bands"][candidate]):
			grade = candidate
			break
	if failed:
		grade = "C"
	var report: = {
		"kind": kind, "level": level, "turnout": turnout, "expected": expected, "people": [out, total, fetched, lost], 
		"health": health, "stars": stars if health >= 0.0 else 0, "injuries": injuries, "smoke": smoke_hp, 
		"failed": failed, "job": [job_time, job_par], "checks": listed, "parts": parts, "weakest": weakest, 
		"score": score, "grade": grade, "multiplier": multiplier(grade), "points": points(grade, failed), 
	}
	report["tip"] = tip(report)
	return report




static func against_par(seconds: float, expected: float) -> float:
	if seconds < 0.0 or expected <= 0.0:
		return 0.0
	return clampf((2.0 - seconds / expected) / 1.2, 0.0, 1.0)



static func multiplier(grade: String) -> float:
	return float(settings()["Grade"]["Multiplier"].get(grade, 1.0))



static func points(grade: String, failed: = false) -> int:
	var table: Dictionary = settings()["Grade"]["Points"]
	return int(table["Failed"]) if failed else int(table.get(grade, 0))



static func tip(report: Dictionary) -> Variant:
	var part: String = report["weakest"]
	if part == "turnout":
		if float(report["turnout"]) < 0.0:
			return Text.m("report.tips.nobody")
		return Text.f("report.tips.turnout", [clock(report["turnout"]), clock(report["expected"])])
	if part == "people":
		return Text.f("report.tips.people", [int(report["people"][0]), int(report["people"][1])])
	if part == "building":
		return Text.f("report.tips.building", [int(round(float(report["health"])))])
	if part == "outcome":
		return Text.m("report.tips.outcome")
	if part == "safety":
		if float(report["smoke"]) >= maxf(1.0, float(report["injuries"]) * 0.5):
			return Text.f("report.tips.smoke", [int(round(float(report["smoke"])))])
		return Text.f("report.tips.safety", [int(round(float(report["injuries"])))])
	if part == "job":
		var job: Array = report["job"]
		if float(job[0]) < 0.0:
			return Text.m("report.tips.jobUndone")
		return Text.f("report.tips.job", [clock(job[0]), clock(job[1])])
	if part == "procedure":
		for entry: Array in report["checks"]:
			if not entry[1]:
				if entry[0] == "mask":
					return Text.f("report.tips.smoke", [int(round(float(report["smoke"])))])
				return Text.m("report.checks.%s.tip" % entry[0])
	return null



static func clock(seconds: Variant) -> String:
	var whole: = maxi(int(seconds), 0)
	return "%d:%02d" % [whole / 60, whole % 60]



static func better(a: String, b: String) -> bool:
	return "SABC".find(a) < "SABC".find(b) if not b.is_empty() else true







static func complications(kind: String) -> Array:
	if not forced_complications.is_empty():
		return forced_complications
	var table: Dictionary = settings().get("Complications", {})
	if not table.has(kind):
		return []
	var rows: Array = table[kind]
	return rows[clampi(level, 1, rows.size()) - 1]


static func complicated(kind: String, complication: String) -> bool:
	return complication in complications(kind)
