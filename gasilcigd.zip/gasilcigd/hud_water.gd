class_name HudWater
extends Control








const HEIGHT: = 138.0

var _plate: Control
var _title: Label
var _litres: Label
var _bar: Control
var _supply: Label
var _hose: Label
var _setting: Label
var _empty: Label
var _pressure: Label
var _gauge: Control


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(300, HEIGHT))
	_plate.position = Vector2(-300 - Ui.MARGIN, - HEIGHT - Ui.MARGIN)
	add_child(_plate)
	Ui.stripe(_plate, 90)
	var drop: = Ui.icon("drop", 34, Ui.BLUE)
	drop.position = Vector2(10, 12)
	_plate.add_child(drop)
	_title = Ui.caps("", int(Config.Hud.CapsFloor))
	_title.position = Vector2(52, 8)
	_plate.add_child(_title)
	_litres = Ui.display("", 28)
	_litres.position = Vector2(52, 20)
	_plate.add_child(_litres)
	_empty = Ui.display("", 20, Ui.RED)
	_empty.position = Vector2(190, 26)
	_plate.add_child(_empty)
	_bar = Ui.bar(Vector2(280, 14), Ui.BLUE, 10)
	_bar.position = Vector2(10, 58)
	_plate.add_child(_bar)
	_supply = Ui.caps("", int(Config.Hud.CapsFloor))
	_supply.position = Vector2(10, 76)
	_plate.add_child(_supply)
	_pressure = Ui.caps("", int(Config.Hud.CapsFloor))
	_pressure.position = Vector2(10, 94)
	_plate.add_child(_pressure)
	_gauge = Ui.bar(Vector2(66, 8), Ui.GREEN, 4)
	_gauge.position = Vector2(224, 99)
	_plate.add_child(_gauge)
	_hose = Ui.caps("", int(Config.Hud.CapsFloor))
	_hose.position = Vector2(10, 114)
	_plate.add_child(_hose)
	_setting = Ui.label("", int(Config.Hud.TextFloor), Ui.YELLOW)
	_setting.position = Vector2(150, 112)
	_setting.size = Vector2(140, 20)
	_setting.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_setting)



func showing() -> bool:
	return _plate.visible


func _process(_delta: float) -> void :
	var player: = Game.local_player
	if player == null:
		return

	var vehicle: Vehicle = player.get_attr("HoseTruck")
	if vehicle == null:
		var reach: float = Config.Hud.WaterRange
		for candidate in Vehicle.all:
			var distance: = candidate.global_position.distance_to(player.global_position)
			if candidate.capacity > 0.0 and distance < reach:
				vehicle = candidate
				reach = distance
	_plate.visible = vehicle != null
	if vehicle == null:
		return
	_title.text = "%s  ·  %s" % [Text.say(Text.m("gear.truck.tank")), Text.say(Text.named("vehicles", vehicle.spec["name"])).to_upper()]
	_litres.text = "%s L" % Ui.thousands(vehicle.water)
	var share: = vehicle.water / vehicle.capacity
	var marks: Array = Config.Water.Tank.Warn
	Ui.set_bar(_bar, share, Ui.BLUE if share > float(marks[0]) else (Ui.state(Ui.AMBER) if share > float(marks[marks.size() - 1]) else Ui.state(Ui.RED)))
	_empty.text = Text.say(Text.m("hud.water.empty")) if vehicle.water <= 0.0 else ""


	var source: Variant = HoseService.current.supplied_by(vehicle) if HoseService.current else null
	var fed: = source != null
	if source is Vehicle:
		_supply.text = Text.say(Text.f("gear.truck.supply", [Text.upper(Text.named("vehicles", source.spec["name"]))]))
	else:
		_supply.text = Text.say(Text.f("gear.truck.supply", [Text.m("gear.truck.sources." + str(source))])) if fed else Text.say(Text.m("gear.truck.supplyNone"))
	var filling: Vehicle = HoseService.current.feeding(vehicle) if HoseService.current else null
	if filling != null:
		_title.text += "  ▸ " + Text.say(Text.upper(Text.named("vehicles", filling.spec["name"])))
	_supply.add_theme_color_override("font_color", Ui.state(Ui.GREEN) if fed else Ui.DIM)

	if not fed and Game.incident.is_empty() and share < float(Config.Readiness.TankFull):
		_supply.text = Text.say(Text.m("water.refill"))
		_supply.add_theme_color_override("font_color", Ui.state(Ui.AMBER))
	_show_pressure(player)
	var paid: Variant = player.get_attr("HoseLength")
	if paid != null:




		var line: Variant = player.get_attr("Line")
		var most: = float(Config.Hose.SupplyLength)
		if line is Dictionary:
			most = float(HoseService.current.kind_of(String(line["kind"]))["length"])
		elif line != null:
			most = float(Config.Hose.AttackLength)
		var warn: = float(paid) >= most
		_hose.text = Text.say(Text.f("hud.water.hoseOut", [int(paid)]))
		_hose.add_theme_color_override("font_color", Ui.state(Ui.AMBER) if warn else Ui.DIM)
		_hose.add_theme_font_size_override("font_size", int(Config.Hud.CapsFloor))
		if player.get_attr("Line") != null:
			var flow: Dictionary = HoseService.current.flow_of(player)
			var pattern: = "hud.hose.fog" if player.get_attr("Pattern") == "Fog" else "hud.hose.jet"
			_setting.text = Text.say(Text.f("hud.hose.setting", [Text.named("flows", flow["name"]), Text.m(pattern)]))
		else:
			_setting.text = ""
	else:
		_hose.text = ""
		_setting.text = ""




func _show_pressure(player: Player) -> void :
	if player.get_attr("Line") == null:
		_pressure.text = ""
		_gauge.visible = false
		return
	var settings: Dictionary = Config.Water.Pressure
	if player.get_attr("Charging") == true:
		_pressure.text = Text.say(Text.m("water.charging"))
		_pressure.add_theme_color_override("font_color", Ui.BLUE)
		_gauge.visible = false
		return
	var nozzle: = float(player.get_attr("Pressure", 1.0))
	var pump: = float(player.get_attr("PumpShare", 1.0))
	_pressure.text = Text.say(Text.f("water.pressure", [snappedf(pump * float(settings["PumpBar"]), 0.1), snappedf(nozzle * float(settings["NozzleBar"]), 0.1)]))
	var low: = nozzle < float(settings["LowFrom"])
	_pressure.add_theme_color_override("font_color", Ui.AMBER if low else Ui.DIM)
	_gauge.visible = true
	Ui.set_bar(_gauge, nozzle, Ui.AMBER if low else Ui.GREEN)
