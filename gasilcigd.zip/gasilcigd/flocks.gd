class_name Flocks
extends Node3D





const SLOT: = 45.0
const CHANCE: = 0.75
const MIDDLE: = Vector3(200, 0, 120)
const START_RADIUS: = 1250.0
const MOST: = 18
const LIVE: = 2
const WING: = Vector3(1.5, 0.07, 0.7)
const BODY: = Vector3(0.5, 0.45, 1.3)
const COLOR: = Color(0.13, 0.13, 0.15)

var _mesh: MultiMesh
var _flocks: Dictionary = {}


func _ready() -> void :
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_mesh = MultiMesh.new()
	_mesh.transform_format = MultiMesh.TRANSFORM_3D
	_mesh.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	_mesh.instance_count = MOST * LIVE * 3
	var hidden: = Transform3D(Basis.from_scale(Vector3.ZERO), Vector3.ZERO)
	for index in _mesh.instance_count:
		_mesh.set_instance_transform(index, hidden)
	var material: = StandardMaterial3D.new()
	material.albedo_color = COLOR
	material.roughness = 0.9
	var drawn: = MultiMeshInstance3D.new()
	drawn.name = "Birds"
	drawn.multimesh = _mesh
	drawn.material_override = material
	drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	drawn.custom_aabb = AABB(MIDDLE - Vector3(1500, 0, 1500), Vector3(3000, 400, 3000))
	add_child(drawn)
	visible = not Game.night
	Game.night_changed.connect( func(night: bool) -> void : visible = not night)



func _plan(slot: int) -> Dictionary:
	if _flocks.has(slot):
		return _flocks[slot]
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash("flock:%d" % slot)
	var plan: = {}
	if rng.randf() < CHANCE:
		var angle: = rng.randf_range(0.0, TAU)
		var from: = MIDDLE + Vector3(cos(angle), 0, sin(angle)) * START_RADIUS
		var over: = MIDDLE + Vector3(rng.randf_range(-450, 450), 0, rng.randf_range(-450, 450))
		var way: = (over - from).normalized()
		var birds: Array = []
		for index in rng.randi_range(8, MOST):
			birds.append({
				"offset": Vector3(rng.randf_range(-14, 14), rng.randf_range(-5, 5), rng.randf_range(-18, 18)), 
				"phase": rng.randf_range(0.0, TAU), "beat": rng.randf_range(10.0, 14.0), 
			})
		plan = {
			"from": from + Vector3(0, rng.randf_range(70.0, 130.0), 0), "way": way, 
			"speed": rng.randf_range(28.0, 40.0), "birds": birds, "sway": rng.randf_range(0.0, TAU), 
		}
	_flocks[slot] = plan
	_flocks.erase(slot - LIVE - 1)
	return plan


func _process(_delta: float) -> void :
	if not visible:
		return
	if Style.winter():
		_mesh.visible_instance_count = 0
		return
	_mesh.visible_instance_count = -1
	var now: = HostClock.now()
	var slot: = floori(now / SLOT)
	var used: = 0
	for back in LIVE:
		var plan: = _plan(slot - back)
		if plan.is_empty():
			continue
		var flown: float = (now - (slot - back) * SLOT) * float(plan["speed"])
		if flown > START_RADIUS * 2.4:
			continue
		var way: Vector3 = plan["way"]
		var side: = Vector3( - way.z, 0, way.x)

		var sway: float = plan["sway"] + flown * 0.01
		var middle: Vector3 = plan["from"] + way * flown + side * sin(sway) * 20.0 + Vector3(0, sin(sway * 1.7) * 8.0, 0)
		var facing: = Basis.looking_at(way, Vector3.UP)
		for bird: Dictionary in plan["birds"]:
			var offset: Vector3 = bird["offset"]
			var phase: float = bird["phase"]
			var at: = middle + facing * (offset + Vector3(sin(now * 0.7 + phase) * 2.0, sin(now * 1.1 + phase) * 1.5, 0))
			var body: = Transform3D(facing, at)

			var beat: = 0.1 if sin(now * 0.9 + phase) > 0.55 else sin(now * float(bird["beat"]) + phase) * 0.7
			_mesh.set_instance_transform(used, body * Transform3D(Basis.from_scale(BODY), Vector3.ZERO))
			_mesh.set_instance_transform(used + 1, body * Rbx.angles(0, 0, - beat) * Transform3D(Basis.from_scale(WING), Vector3( - WING.x / 2.0, 0, 0)))
			_mesh.set_instance_transform(used + 2, body * Rbx.angles(0, 0, beat) * Transform3D(Basis.from_scale(WING), Vector3(WING.x / 2.0, 0, 0)))
			used += 3
	var hidden: = Transform3D(Basis.from_scale(Vector3.ZERO), Vector3.ZERO)
	for index in range(used, _mesh.instance_count):
		_mesh.set_instance_transform(index, hidden)
