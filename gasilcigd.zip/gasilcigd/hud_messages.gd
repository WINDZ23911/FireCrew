class_name HudMessages
extends Control








const KINDS: = {
	"info": ["dot", Ui.DIM, 4.0], 
	"good": ["check", Ui.GREEN, 4.0], 
	"warning": ["warning", Ui.AMBER, 5.0], 
	"danger": ["warning", Ui.RED, 7.0], 
}
const WIDTH: = 480.0

var _shown: Array = []
var _waiting: Array = []
var _money: = RegEx.create_from_string("\\s*[:·,–-]?\\s*\\+(?:[€$][0-9][0-9.,]*|[0-9][0-9.,]*\\s?[€$])(\\s+bonus\\b)?")


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Game.notified.connect(_on_notified)


func _on_notified(text: Variant, kind: String, player: Player) -> void :
	if player != null and player != Game.local_player:
		return


	show_message.call_deferred(text, kind)


func show_message(text: Variant, kind: = "info") -> void :
	if not KINDS.has(kind):
		kind = "info"
	if HudFireOut.holding():
		_waiting.append([text, kind])
		return
	var look: Array = KINDS[kind].duplicate()
	look[1] = Ui.state(look[1])
	var words: = _money.sub(Text.say(text), "", true).strip_edges()
	if words.is_empty():
		return

	for entry: Array in _shown:
		if not entry[3] and entry[2] == words:
			entry[1] = Game.now() + look[2]
			return
	if kind == "danger":
		Sounds.ui("ui_alert")
	var line: = Ui.label(words, 18)
	line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	line.custom_minimum_size = Vector2(WIDTH - 62, 0)
	line.size = Vector2(WIDTH - 62, 0)
	var height: = maxf(40.0, line.get_minimum_size().y + 18.0)

	var lines: = maxi(1, ceili(Ui.label_font().get_string_size(words, HORIZONTAL_ALIGNMENT_LEFT, -1, 18).x / (WIDTH - 62)))
	height = maxf(40.0, lines * 23.0 + 18.0)
	var plate: = Ui.plate(Vector2(WIDTH, height))
	var edge: = ColorRect.new()
	edge.color = look[1]
	edge.position = Vector2(0, 6)
	edge.size = Vector2(4, height - 12)
	plate.add_child(edge)
	var picture: = Ui.icon(look[0], 24, look[1])
	picture.position = Vector2(14, height / 2 - 12)
	plate.add_child(picture)
	line.position = Vector2(48, 8)
	line.size = Vector2(WIDTH - 62, height - 16)
	line.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	plate.add_child(line)
	plate.modulate.a = 0.0
	add_child(plate)

	plate.position = Vector2( - WIDTH / 2, _bottom())
	_shown.append([plate, Game.now() + look[2], words, false])
	var staying: = 0
	for index in range(_shown.size() - 1, -1, -1):
		if not _shown[index][3]:
			staying += 1
			if staying > int(Config.Hud.MaxMessages):
				_go(_shown[index])
	create_tween().tween_property(plate, "modulate:a", 1.0, 0.25)



func _go(entry: Array) -> void :
	if entry[3]:
		return
	entry[3] = true
	var plate: Control = entry[0]
	var fade: = create_tween()
	fade.tween_property(plate, "modulate:a", 0.0, float(Config.Hud.ToastFade))
	fade.tween_callback( func() -> void :
		_shown.erase(entry)
		plate.queue_free()
	)



func _top() -> float:
	var under: = HudDispatch.current.banner_bottom() if HudDispatch.current else -1.0
	return 20.0 if under < 0.0 else under + float(Config.Hud.BannerGap)


func _bottom() -> float:
	var y: = _top()
	for entry: Array in _shown:
		y += (entry[0] as Control).size.y + 8.0
	return y


func _process(_delta: float) -> void :
	var now: = Game.now()
	if not _waiting.is_empty() and not HudFireOut.holding():
		var held: = _waiting.duplicate()
		_waiting.clear()
		for entry: Array in held:
			show_message(entry[0], entry[1])
	for entry: Array in _shown.duplicate():
		if now > entry[1]:
			_go(entry)
	var y: = _top()
	for entry: Array in _shown:
		var plate: Control = entry[0]
		plate.position = plate.position.lerp(Vector2( - WIDTH / 2, y), 0.3)
		y += plate.size.y + 8.0
