extends ProofDebug







func _pixels_high(node: Node3D) -> float:
	var camera: = get_viewport().get_camera_3d()
	var top: = - INF
	var bottom: = INF
	for mesh: Node in node.find_children("*", "GeometryInstance3D", true, false):
		var box: AABB = (mesh as GeometryInstance3D).global_transform * (mesh as GeometryInstance3D).get_aabb()
		for corner in 8:
			var y: = camera.unproject_position(box.get_endpoint(corner)).y
			top = maxf(top, y)
			bottom = minf(bottom, y)
	return top - bottom if top > bottom else 0.0


func _scenario_marks() -> void :
	await _wait(1.0)
	var house: = _house("Family house")
	house.lock_up(true, 1.0)


	var door: Dictionary = house.doors["FrontDoor"]
	var lock_at: Vector3 = door["lock"].global_position
	var out: = _stand_outside(house, lock_at, 4.0)
	await _wait(0.6)
	var rim: = FocusRim.current
	print("marks: front door locked %s; prompt '%s'; rim code '%s'" % [door["locked"], Text.say(player.prompt.action, "en") if player.prompt != null else "nothing", rim.code])
	_check(rim.code == "force", "a locked door's rim is the force code (%s)" % rim.code)
	_check(FocusRim.COLORS["force"] == Ui.AMBER, "the force code is the HUD's amber")
	_view(lock_at + out * 7.0 - out.cross(Vector3.UP) * 6.0 + Vector3(0, 2, 0), lock_at)
	await _snap("locked_force")


	var back: Dictionary = {}
	for door_name: String in house.doors:
		if house.doors[door_name]["padlock"]:
			back = house.doors[door_name]
	if _check( not back.is_empty() and back["padlock_part"] is Node3D, "a back door is padlocked and the padlock is seen"):
		var padlock_at: Vector3 = back["lock"].global_position
		var away: = _stand_outside(house, padlock_at, 4.0)

		player.teleport(_ground(padlock_at + away * 6.0 + away.cross(Vector3.UP) * 9.0) + Vector3(0, 0.3, 0))
		var five_metres: = 5.0 / float(Config.Hud.MetresPerStud)
		_view(padlock_at + away * five_metres + Vector3(0, 1.5, 0), padlock_at)
		await _wait(0.4)
		await _snap("padlock_5m")
		var high: = _pixels_high(back["padlock_part"])
		print("marks: the padlock from %.0f studs is %.0f px high of %d" % [five_metres, high, get_viewport().get_visible_rect().size.y])
		_check(high >= 0.035 * get_viewport().get_visible_rect().size.y, "the padlock reads from 5 m (%.0f px)" % high)


	_stand_outside(house, lock_at, 4.0)
	_take_tool("Axe")
	await _wait(0.4)
	await get_tree().process_frame
	Input.action_press("interact")
	await _wait(float(Config.Tools.ForceTime) + 0.5)
	Input.action_release("interact")
	await _wait(0.8)
	print("marks: after forcing: locked %s, open %s, rim code '%s'" % [door["locked"], door["open"], rim.code])
	_check( not door["locked"] and rim.code != "force", "a forced door is no longer the force code (%s)" % rim.code)


	var fire: = FireService.current
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	CallService.current.run_call("fire", func() -> bool:
		await fire.run_incident(house)
		return true)
	var waited: = 0.0
	while fire.incident.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	if not _check( not fire.incident.is_empty(), "a fire in the house"):
		await _done()
		return
	var room_name: = "Living room"
	var room: Dictionary = house.rooms[room_name]
	var middle: Vector3 = house.lot * Vector3((room["low"].x + room["high"].x) / 2.0, room["low"].y + 1.0, (room["low"].z + room["high"].z) / 2.0)
	player.teleport(middle)
	await _wait(1.5)
	var mark: Variant = room.get("mark")
	print("marks: in the %s: searched %s, cleared %s, mark %s" % [room_name, room.get("searched"), room.get("cleared"), mark])
	_check(room.get("searched", false) and not room.get("cleared", false), "a room with a firefighter in it is searched, not cleared")
	_check(mark is Decal and (mark as Decal).texture_albedo == House._mark_texture("slash"), "its door frame has a slash")
	if not mark is Decal:
		await _done()
		return
	var place: Transform3D = (mark as Decal).global_transform
	var front: = place.basis.y.normalized()
	_check(house.room_at(place.origin + front * 2.0) != null and house.room_at(place.origin + front * 2.0)["name"] == "Hall", "the mark faces the hall it was entered from")
	var leaf_bottom: float = (house.doors["LivingDoor"]["shut"] as Transform3D).origin.y - float(house.doors["LivingDoor"]["info"]["height"]) / 2.0
	var share: = (place.origin.y - leaf_bottom) / float(house.doors["LivingDoor"]["info"]["height"])
	_check(share > 0.2 and share < 0.45, "the mark is at the lower third of the door (%.2f)" % share)
	var hall: Dictionary = house.rooms["Hall"]
	var in_hall: Vector3 = house.lot * Vector3((hall["low"].x + hall["high"].x) / 2.0, hall["low"].y + 1.0, (hall["low"].z + hall["high"].z) / 2.0)
	var across: = place.basis.x.normalized()

	for layer in get_tree().root.find_children("*", "CanvasLayer", true, false):
		(layer as CanvasLayer).visible = false
	_view(place.origin + front * 8.0 - across * 2.5 + Vector3(0, 3.0, 0), place.origin + Vector3(0, 0.5, 0))
	await _snap("searched_slash")


	player.teleport(in_hall)
	await _wait(1.5)
	print("marks: out in the hall: searched %s, cleared %s" % [room.get("searched"), room.get("cleared")])
	_check(room.get("cleared", false), "a searched room everyone has left is cleared")
	_check(room.get("mark") == mark and (mark as Decal).texture_albedo == House._mark_texture("x"), "the slash is crossed into an X")
	await _snap("cleared_x")


	for other: String in house.rooms:
		house.set_read(other, "searched", true)
	var marks: = 0
	for other: Dictionary in house.rooms.values():
		marks += 1 if other.get("mark") is Decal and is_instance_valid(other["mark"]) else 0
	print("marks: every room searched: %d marks" % marks)
	_check(marks > 1 and marks <= House.MARKS_MOST, "at most %d marks at a house (%d)" % [House.MARKS_MOST, marks])

	_stand_outside(house, lock_at, 30.0)
	await _wait(0.3)
	for other: String in house.rooms:
		house.set_read(other, "searched", false)
		house.set_read(other, "cleared", false)
	await _wait(0.2)
	_check(house.holder.find_children("SearchMark", "Decal", true, false).is_empty(), "the marks go when the rooms are put right")
	await _done()
