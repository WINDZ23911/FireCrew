class_name JobGoto
extends CrewJob



func _init(place_at: Vector3) -> void :
	kind = "goto"
	target = place_at


func place() -> Vector3:
	return target


func run() -> bool:
	if not await who.go(target, 2.5, 90.0):
		return fail("crew.say.stuck")
	if ordered:
		who.mode = "hold"
	who.hold_at = who.body.global_position
	return true
