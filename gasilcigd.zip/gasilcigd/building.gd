class_name Building
extends RefCounted





const CHARRED: = Color(34 / 255.0, 30 / 255.0, 27 / 255.0)
const BURNT_OUT: = Color(24 / 255.0, 20 / 255.0, 18 / 255.0)
const GLASS: = Color(150 / 255.0, 190 / 255.0, 215 / 255.0)
const LAMPLIT: = Color(1.0, 214 / 255.0, 150 / 255.0)

var name: = ""
var shown_name: Variant = null
var position: = Vector3.ZERO
var height: = 20.0
var fuel: Array = []
var spots: Array = []
var rooms: Dictionary = {}
var openings: Array = []
var doors: Dictionary = {}
var scenarios: Array = []
var reach: = -1.0
var weight: = 1.0
var start_nodes: = -1
var reward_share: = 1.0
var counts_as_save: = true
var lost_text: Variant = null
var ruined: = false
var model: = 0
var roof: = ""
var place: = Transform3D.IDENTITY
var pitch: Dictionary = {}
var record: Dictionary = {}
var approach: Variant = null
var _original: Dictionary = {}
var _burning_panes: Dictionary = {}
var _lamp_panes: Array[int] = []


var node_shades: = PackedByteArray()
var charred: = false
var _net_shades: = PackedByteArray()


static func from_record(entry: Dictionary) -> Building:
	var building: = Building.new()
	building.record = entry
	if entry.get("name") is Dictionary:
		building.shown_name = entry["name"]
		building.name = Text.say(entry["name"], "en")
	else:
		building.name = entry.get("name", "")
	building.model = int(entry.get("model", 0))
	building.weight = entry.get("weight", 1.0)
	building.reach = entry.get("reach", -1.0)
	building.start_nodes = int(entry.get("startNodes", -1))
	building.reward_share = entry.get("rewardShare", 1.0)
	building.counts_as_save = entry.get("countsAsSave", true)
	building.lost_text = entry.get("lostText")
	building.scenarios = entry.get("scenarios", []) if entry.get("scenarios") is Array else []
	building.roof = entry.get("roof", "") if entry.get("roof") is String else ""
	if entry.get("place") is Transform3D:
		building.place = entry["place"]
	if entry.get("pitch") is Dictionary:
		building.pitch = entry["pitch"]
	var store: = Game.store
	var body_row: int = store.row_of.get(int(entry.get("body", 0)), -1)
	if body_row >= 0:
		building.position = store.position(body_row)
		building.height = store.size(body_row).y
	if entry.get("height") is float:
		building.height = entry["height"]
	if entry.get("fuel") is Array:
		for item: Dictionary in entry["fuel"]:
			var node: = {
				"name": item["name"], "position": item["position"], "kind": item["kind"], 
				"room": item.get("room"), "parts": item.get("parts", []) if item.get("parts") is Array else [], 
			}
			if item["name"] == "Window" and building.model != 0 and not entry.has("scenarios"):
				node["position"] = building._window_now(node)
				node["lit"] = building._window_lit.bind(node)
			building.fuel.append(node)
	if entry.get("spots") is Array:
		building.spots = entry["spots"]
	return building


func has_rooms() -> bool:
	return not rooms.is_empty()


func room_at(_where: Vector3) -> Variant:
	return null


func lock_up(_all: = false) -> void :
	pass



func blocks(_from: Vector3, _to: Vector3, _slack: float, _panes_open: = false) -> bool:
	return false



func ways_out(_room: String) -> int:
	return 0


func open_outside_doors() -> Array:
	return []


func set_read(_room: String, _key: String, _on: bool) -> void :
	pass



func outside_door() -> Variant:
	return null


func fit_control(_words: String, _hold: float, _color: Color, _wheel: bool, _done: Callable) -> Node3D:
	return null


func set_room_lights(_room: String, _on: bool) -> void :
	pass


func show_smoke(_room: String, _level: float) -> void :
	pass


func show_flashover(_room: String, _on: bool) -> void :
	pass


func show_scorch(_room: String, _level: float) -> void :
	pass






func _window_now(node: Dictionary) -> Vector3:
	var store: = Game.store
	var was: Vector3 = node["position"]
	for id: Variant in node["parts"]:
		var row: int = store.row_of.get(int(id), -1)
		if row >= 0 and store.name_at(row) == "Window" and store.transparency(row) < 0.99:

			return was if store.position(row).distance_to(was) < 1.0 else store.position(row)
	var best: = was
	var best_distance: = INF
	for row in store.rows_under.get(model, PackedInt32Array()):
		if store.name_at(row) == "Window" and store.transparency(row) < 0.99:
			var distance: = store.position(row).distance_to(was)
			if distance < best_distance:
				best = store.position(row)
				best_distance = distance
	return best



func _window_lit(node: Dictionary) -> void :
	var store: = Game.store
	var best: = -1
	var best_distance: = 2.5
	for row in store.rows_under.get(model, PackedInt32Array()):
		if store.name_at(row) == "Window" and store.transparency(row) < 0.99:
			var distance: = store.position(row).distance_to(node["position"])
			if distance < best_distance:
				best = row
				best_distance = distance
	if best >= 0:
		_burn_pane(store.id_at(best))


func _burn_pane(id: int) -> void :
	var store: = Game.store
	var row: int = store.row_of.get(id, -1)
	if row < 0 or _burning_panes.has(id):
		return
	_remember(id)
	Game.world.set_color(id, BURNT_OUT)
	var size: = store.size(row)
	var soot: = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = Vector2(size.x + 3.0, 7.0)
	soot.mesh = quad
	soot.material_override = _soot_material()
	Game.world.add_child(soot)

	soot.global_transform = store.transform(row) * Transform3D(Basis(Vector3.UP, PI), Vector3(0, size.y / 2.0 + 3.2, -0.08))
	_burning_panes[id] = soot


static var _soot: StandardMaterial3D


static func _soot_material() -> StandardMaterial3D:
	if _soot == null:
		_soot = StandardMaterial3D.new()
		_soot.albedo_texture = Assets.texture("burn_soot")
		_soot.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_soot.roughness = 1.0
		_soot.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _soot


func _remember(id: int) -> void :
	if not _original.has(id):
		var row: int = Game.store.row_of.get(id, -1)
		if row >= 0:
			_original[id] = Game.store.color(row)



func set_charred(black: bool) -> void :
	charred = black
	var store: = Game.store
	if model == 0:
		return
	show_collapse(black)
	for row in store.rows_in(model):
		if store.material(row) == "Glass" or store.transparency(row) >= 0.99:
			continue
		var id: = store.id_at(row)
		if _burning_panes.has(id):
			continue
		_remember(id)
		Game.world.set_color(id, _original[id].lerp(CHARRED, 0.85) if black else _original[id])



func restore() -> void :
	_clear_panes()









const ROOF_NAMES: = ["Roof", "Gable", "Ridge", "Chimney", "ChimneyCap", "Dormer", "DormerRoof", "DormerWindow", 
	"RoofVent", "WingRoof", "PenthouseRoof", "Penthouse", "Eave", "Fascia", "Flat roof"]

var _fallen: Node3D
var _fallen_ids: PackedInt32Array = []



func own_rows() -> PackedInt32Array:
	return Game.store.rows_in(model) if model != 0 else PackedInt32Array()


func show_collapse(on: bool) -> void :
	if on == (_fallen != null):
		return
	var world: = Game.world
	if not on:
		for id in _fallen_ids:
			world.set_hidden(id, false)
			world.set_solid(id, true)
		_fallen_ids = PackedInt32Array()
		_fallen.queue_free()
		_fallen = null
		return
	var store: = Game.store
	var rows: = own_rows()
	var roof: = PackedInt32Array()
	var low: = Vector3.INF
	var high: = - Vector3.INF
	var eaves: = 0.0
	for row in rows:
		var at: = store.position(row)
		low = low.min(at)
		high = high.max(at)
		if store.name_at(row) in ROOF_NAMES or store.name_at(row).begins_with("Roof"):
			roof.append(row)
		elif store.name_at(row) in ["Body", "Wall"] or store.size(row).y > 6.0:
			eaves = maxf(eaves, at.y + store.size(row).y / 2.0)
	if roof.is_empty():
		return

	for row in store.rows_in(_polish_folder()):
		var at: = store.position(row)
		if at.x > low.x - 2.0 and at.x < high.x + 2.0 and at.z > low.z - 2.0 and at.z < high.z + 2.0 and at.y > eaves - 1.5:
			roof.append(row)
	_fallen = Node3D.new()
	_fallen.name = "Fallen"
	world.add_child(_fallen)
	var middle: = (low + high) / 2.0
	var drop: = maxf(eaves * 0.55, 4.0)
	var rng: = RandomNumberGenerator.new()
	rng.seed = model * 31 + roof.size()
	for row in roof:
		var id: = store.id_at(row)
		_fallen_ids.append(id)
		var piece: = PartNode.make(store, row, false)
		piece.collision_layer = 0
		_fallen.add_child(piece)
		var color: = store.color(row)
		piece.set_color(color.lerp(CHARRED, 0.8))
		world.set_hidden(id, true)
		world.set_solid(id, false)

		var from: = piece.transform
		var toward: = (middle - from.origin) * Vector3(1, 0, 1)
		var tip: = toward.normalized().cross(Vector3.UP) if toward.length() > 0.5 else Vector3.RIGHT
		var to_basis: = from.basis.rotated(tip, rng.randf_range(0.25, 0.7)).rotated(Vector3.UP, rng.randf_range(-0.2, 0.2))
		var to: = Transform3D(to_basis, from.origin + toward * 0.2 + Vector3(0, - drop * rng.randf_range(0.8, 1.1), 0))
		var fall: = piece.create_tween()
		fall.tween_interval(rng.randf_range(0.0, 0.7))
		fall.tween_property(piece, "transform", to, rng.randf_range(0.7, 1.1)).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

	var top: = Vector3(middle.x, eaves, middle.z)
	Sounds.once_at(top, "collapse", 1.0, 20.0, 320.0)
	var spread: = Vector3(high.x - low.x, 2.0, high.z - low.z)
	_fallen.get_tree().create_timer(0.6).timeout.connect( func() -> void :
		if _fallen == null:
			return
		RbxEmitter.burst_at(top, {
			"Texture": "fire_smoke_flipbook", "Flipbook": true, "Color": Color(0.32, 0.3, 0.28), "Speed": [6, 16], 
			"Lifetime": [3.0, 6.0], "SpreadAngle": 70, "Direction": Vector3.UP, "Acceleration": Vector3(0, 2, 0) + World.WIND * 2.0, 
			"Drag": 0.8, "Rotation": [0, 360], "Size": [[0.0, 6.0], [1.0, 20.0]], "Box": spread, 
			"Transparency": [[0.0, 0.3], [1.0, 1.0]], 
		}, 40)
		RbxEmitter.burst_at(top, {
			"Texture": "fire_ember", "LightEmission": 1.0, "LightInfluence": 0.0, "Brightness": 3.0, "Speed": [15, 35], 
			"Lifetime": [1.0, 2.5], "SpreadAngle": 60, "Direction": Vector3.UP, "Acceleration": Vector3(0, -15, 0), 
			"Drag": 0.6, "Size": [0.35, 0.08], "Transparency": [0.0, 1.0], "Box": spread, 
		}, 120)
		RbxEmitter.burst_at(top, {
			"Texture": "fire_flame_flipbook_a", "Flipbook": true, "LightEmission": 0.5, "LightInfluence": 0.0, 
			"Brightness": 0.9, "Speed": [8, 16], "Lifetime": [0.6, 1.2], "SpreadAngle": 30, "Direction": Vector3.UP, 
			"Size": [[0.0, 6.0], [0.5, 12.0], [1.0, 6.0]], "Box": spread * 0.7, "Transparency": [[0.0, 0.8], [0.2, 0.1], [1.0, 1.0]], 
		}, 30)
	)

	var wisp: = RbxEmitter.make(_fallen, {
		"Texture": "fire_smoke_flipbook", "Flipbook": true, "Color": Color(0.38, 0.37, 0.36), "Speed": [3, 6], 
		"Lifetime": [5.0, 8.0], "SpreadAngle": 20, "Direction": Vector3.UP, "Acceleration": World.WIND * 1.8, 
		"Rotation": [0, 360], "Size": [[0.0, 4.0], [1.0, 16.0]], "Box": spread * 0.6, 
		"Transparency": [[0.0, 1.0], [0.2, 0.55], [1.0, 1.0]], "Rate": 3, "MaxRate": 3, 
	})
	wisp.position = top + Vector3(0, - drop * 0.5, 0)
	wisp.get_tree().create_timer(90.0).timeout.connect( func() -> void : if is_instance_valid(wisp): wisp.set_rate(0.0))


static var _polish_id: = -2


static func _polish_folder() -> int:
	if _polish_id == -2:
		_polish_id = -1
		var store: = Game.store
		for id: int in store.nodes:
			var node: Dictionary = store.nodes[id]
			if node["n"] == "Polish" and node["c"] == "Folder":
				_polish_id = id
				break
	return _polish_id


func _clear_panes() -> void :
	for id: int in _burning_panes:
		if is_instance_valid(_burning_panes[id]):
			_burning_panes[id].queue_free()
		Game.world.set_color(id, _original.get(id, GLASS))
	_burning_panes.clear()



func shade(id: int, share: float) -> void :
	_remember(id)
	if _original.has(id):
		Game.world.set_color(id, _original[id].lerp(CHARRED, share))


func restore_colors() -> void :
	node_shades = PackedByteArray()
	for id: int in _original:
		if not _burning_panes.has(id):
			Game.world.set_color(id, _original[id])











func net_state() -> Dictionary:
	var state: = {}
	if not node_shades.is_empty():
		state["sh"] = node_shades.duplicate()
	if charred:
		state["ch"] = true
	if not _burning_panes.is_empty():
		state["wp"] = PackedInt32Array(_burning_panes.keys())
	if ruined:
		state["ru"] = true
	return state




func net_apply(state: Dictionary, nodes: Array, _quiet: = false) -> void :
	ruined = state.get("ru", false)
	var shades: PackedByteArray = state.get("sh", PackedByteArray())
	if shades.is_empty():
		if not _net_shades.is_empty():
			_net_shades = PackedByteArray()
			if not state.get("ch", false):
				restore_colors()
	else:
		if _net_shades.size() != shades.size():
			_net_shades = PackedByteArray()
			_net_shades.resize(shades.size())
		for index in mini(shades.size(), nodes.size()):
			if shades[index] != _net_shades[index]:
				_net_shades[index] = shades[index]
				for part: Variant in nodes[index]["parts"]:
					shade(int(part), 0.9 * shades[index] / FireService.CHAR_STEPS)
	var panes: PackedInt32Array = state.get("wp", PackedInt32Array())
	if panes.is_empty():
		if not _burning_panes.is_empty():
			_clear_panes()
	else:
		for id in panes:
			_burn_pane(id)
	if bool(state.get("ch", false)) != charred:
		var black: bool = state.get("ch", false)
		if not black:
			restore_colors()
		set_charred(black)
