class_name HudVoice
extends Control





const WIDTH: = 250.0
const ROW: = 38.0
const GAP: = 6.0

var _rows: Array = []


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for place in int(Net.MAX_CREW):
		var plate: = Ui.plate(Vector2(WIDTH, ROW))
		plate.visible = false
		add_child(plate)
		var icon: = Handheld.new()
		icon.position = Vector2(8, 4)
		icon.size = Vector2(30, ROW - 8)
		plate.add_child(icon)
		var shown_name: = Ui.label("", int(Config.Hud.TextFloor) + 1)
		shown_name.position = Vector2(44, 2)
		shown_name.size = Vector2(WIDTH - 52, 20)
		shown_name.clip_text = true
		plate.add_child(shown_name)
		var what: = Ui.caps("", int(Config.Hud.CapsFloor) - 2)
		what.position = Vector2(44, 20)
		what.modulate = Ui.DIM
		plate.add_child(what)
		_rows.append({"plate": plate, "icon": icon, "name": shown_name, "what": what})


func _process(_delta: float) -> void :
	var radio: = TeamRadio.current
	var talkers: Array[Player] = []
	if radio != null and Net.active():
		if radio.talking and Game.local_player != null:
			talkers.append(Game.local_player)
		for peer: int in radio.on_air:
			var player: = NetTalk.player_of(peer)
			if player != null and player != Game.local_player and not player in talkers:
				talkers.append(player)
	var bottom: = size.y - 400.0
	for index in _rows.size():
		var row: Dictionary = _rows[index]
		var plate: Control = row["plate"]
		plate.visible = index < talkers.size()
		if not plate.visible:
			continue
		var player: = talkers[index]
		var mine: = player == Game.local_player
		plate.position = Vector2(Ui.MARGIN, bottom - index * (ROW + GAP))
		(row["name"] as Label).text = player.display_name
		(row["name"] as Label).modulate = NetTalk.colour_of(player)
		var what: Label = row["what"]
		what.text = Text.say(Text.m("talk.voice.transmitting" if mine else "talk.voice.onAir"))
		what.modulate = Ui.RED if mine else Ui.DIM
		var icon: Handheld = row["icon"]
		icon.colour = Ui.RED if mine else NetTalk.colour_of(player)
		icon.level = radio.level if mine else 0.6
		icon.queue_redraw()



class Handheld:
	extends Control

	var colour: = Ui.TEXT
	var level: = 0.0

	func _draw() -> void :
		var body: = Rect2(Vector2(4, 9), Vector2(11, size.y - 9))
		draw_rect(body, colour, true)
		draw_rect(Rect2(body.position + Vector2(2, 3), Vector2(7, 5)), Ui.PANEL, true)
		draw_line(Vector2(7, 9), Vector2(7, 0), colour, 2.0)
		var waves: = clampi(ceili(level * 4.0 - 0.2), 0, 3)
		var beat: = fmod(Time.get_ticks_msec() / 1000.0 * 2.5, 1.0)
		for wave in waves:
			var radius: = 5.0 + wave * 4.0
			var fade: = 1.0 - fmod(beat + wave / 3.0, 1.0) * 0.6
			draw_arc(Vector2(7, 3), radius, - PI * 0.42, PI * 0.18, 8, Color(colour, fade), 1.6)
