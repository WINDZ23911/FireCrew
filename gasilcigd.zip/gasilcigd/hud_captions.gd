class_name HudCaptions
extends Control




static var current: HudCaptions

var _strip: PanelContainer
var _words: Label
var _until: = 0.0
var _said: Array = []

var shown_text: = ""



static func say(who: Variant, words: Variant) -> void :
	if current == null or not Settings.subtitles:
		return
	current._show(who, words)


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_strip = PanelContainer.new()
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(0, 0, 0, 0.72)
	box.set_corner_radius_all(6)
	box.content_margin_left = 16
	box.content_margin_right = 16
	box.content_margin_top = 8
	box.content_margin_bottom = 8
	_strip.add_theme_stylebox_override("panel", box)
	_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_strip)
	_words = Ui.label("", int(Config.Hud.TextFloor) + 4)
	_words.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_words.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_strip.add_child(_words)
	_strip.visible = false
	Text.language_changed.connect( func(_code: String) -> void :
		if _strip.visible:
			_put(_said[0], _said[1]))


func _show(who: Variant, words: Variant) -> void :
	_put(who, words)
	_until = Game.now() + float(Config.Settings.CaptionTime) + shown_text.length() * float(Config.Settings.CaptionMore)
	_strip.visible = true


func _put(who: Variant, words: Variant) -> void :
	_said = [who, words]
	var name: = Text.say(who)
	var line: = Text.say(words)
	shown_text = "%s: %s" % [name, line]
	_words.text = shown_text

	var font_size: = _words.get_theme_font_size("font_size")
	var width: = minf(_words.get_theme_font("font").get_string_size(shown_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x + 4.0, float(Config.Settings.CaptionWidth))
	_words.custom_minimum_size = Vector2(width, font_size + 8)
	_strip.size = Vector2(width + 32, font_size + 24)
	_strip.position = Vector2( - _strip.size.x / 2.0, - _strip.size.y - 190.0)


func _process(_delta: float) -> void :
	if _strip.visible and (Game.now() > _until or not Settings.subtitles):
		_strip.visible = false
