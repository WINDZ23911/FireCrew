extends RefCounted


const SKIP: = ["--shot", "--scenario", "--crewai", "--seat", "--cam", "--call", "--industry", "--join", "--play=", 
	"--firebench", "--peoplebench", "--handlook", "--hose-test", "--lawn-survey", "--scene-life", "--hud-open"]



static func start(main: Node) -> void :

	Updater.booted()
	for arg in OS.get_cmdline_user_args():
		var looking: = arg == "--host" or arg == "--host-online" or arg == "--no-title" or arg == "--fly"
		for flag in SKIP:
			looking = looking or arg.begins_with(flag)
		if looking and not OS.get_cmdline_user_args().has("--title"):
			Telemetry.begin(true)
			return
	var title: = TitleScreen.new()
	title.name = "Title"
	main.add_child(title)
	Telemetry.begin(false)
	title.started.connect(Telemetry.in_play)

	if CallService.current:
		CallService.current.hold = true
		title.started.connect( func() -> void : CallService.current.hold = false)
