class_name Rbx







static func cf(a: Array) -> Transform3D:
	return Transform3D(
		Basis(Vector3(a[3], a[6], a[9]), Vector3(a[4], a[7], a[10]), Vector3(a[5], a[8], a[11])), 
		Vector3(a[0], a[1], a[2])
	)


static func v3(a: Array) -> Vector3:
	return Vector3(a[0], a[1], a[2])


static func rgb(a: Array) -> Color:
	return Color(a[0] / 255.0, a[1] / 255.0, a[2] / 255.0)



static func decode(value: Variant) -> Variant:
	if value is Dictionary:
		if value.size() == 1:
			if value.has("$v3"):
				return v3(value["$v3"])
			if value.has("$cf"):
				return cf(value["$cf"])
			if value.has("$c3"):
				var c: Array = value["$c3"]
				return Color(c[0], c[1], c[2])
			if value.has("$v2"):
				return Vector2(value["$v2"][0], value["$v2"][1])
			if value.has("$nr"):
				return Vector2(value["$nr"][0], value["$nr"][1])
			if value.has("$e"):
				return value["$e"]
			if value.has("$i"):
				return int(value["$i"])
		for key in value:
			value[key] = decode(value[key])
		return value
	if value is Array:
		for index in value.size():
			value[index] = decode(value[index])
		return value
	return value


static func load_json(path: String) -> Variant:
	var text: = FileAccess.get_file_as_string(path)
	if text.is_empty():
		push_error("Rbx: nothing at " + path)
		return null
	return JSON.parse_string(text)



static func module(name: String) -> Variant:
	var file: = "res://data/modules/%s.json" % name
	if name == "TownLayout" or name == "StationData":
		file = Edition.path("modules/%s.json" % name, file)
	var read: Variant = decode(load_json(file))
	if name == "TownLayout" and read is Dictionary:
		IndustryZone.extend_layout(read)
		RoadsOut.extend_layout(read)
	return read



static func angles(rx: float, ry: float, rz: float) -> Transform3D:
	return Transform3D(Basis(Vector3.RIGHT, rx) * Basis(Vector3.UP, ry) * Basis(Vector3.BACK, rz), Vector3.ZERO)



static func orientation(rx: float, ry: float, rz: float) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, ry) * Basis(Vector3.RIGHT, rx) * Basis(Vector3.BACK, rz), Vector3.ZERO)


static func at(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))



static func look_at(from: Vector3, to: Vector3, up: = Vector3.UP) -> Transform3D:
	if from.is_equal_approx(to):
		return Transform3D(Basis.IDENTITY, from)
	var forward: = (to - from).normalized()
	if absf(forward.dot(up)) > 0.9999:
		up = Vector3.RIGHT if absf(forward.x) < 0.9 else Vector3.BACK
	return Transform3D(Basis.looking_at(forward, up), from)



static func look(t: Transform3D) -> Vector3:
	return - t.basis.z
