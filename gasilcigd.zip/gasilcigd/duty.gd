class_name Duty
extends Node






const ACTION: = "report_available"
const KEY: = KEY_U

static var current: Duty



var state: Dictionary = {"status": "available", "next": -1, "shift": "normal", "reported": false}



static var water_at: = -1.0
var _turnout_for: = -1.0
var _road_set: = false
var _warned_at: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	if not InputMap.has_action(ACTION):
		InputMap.add_action(ACTION)
		var event: = InputEventKey.new()
		event.physical_keycode = KEY
		InputMap.action_add_event(ACTION, event)
	Net.handle("duty.report", func(player: Player) -> void : report(player))
	Net.share("duty", func() -> Variant: return state, _apply, 2.0)
	if Hud.current != null:
		Hud.current.add_widget("duty", HudDuty.new())

	if OS.get_cmdline_user_args().has("--duty-trace"):
		var timer: = Timer.new()
		timer.wait_time = 2.0
		timer.autostart = true
		timer.timeout.connect( func() -> void :
			var widget: Variant = Hud.current.widgets.get("duty") if Hud.current != null else null
			print("duty trace (%s): %s; shift %s; hud: %s" % ["client" if Net.is_client() else "host", state, Shift.current(), widget.shown_text() if widget != null else "-"])
		)
		add_child(timer)

	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--duty-report="):
			get_tree().create_timer(float(arg.substr(14))).timeout.connect( func() -> void :
				print("duty: reporting available from the %s" % ("client" if Net.is_client() else "host"))
				report(Game.local_player)
			)


func _apply(shared: Variant) -> void :
	if Net.is_client() and shared is Dictionary:
		state = shared
		Shift.apply(String(state.get("shift", "normal")))






func _turnout() -> void :
	if not Alarm.active or not Game.incident.has("pos"):
		return
	if _turnout_for != Alarm.started_at:
		_turnout_for = Alarm.started_at
		_road_set = false
		water_at = -1.0
	var at: Vector3 = Game.incident["pos"]
	if not _road_set and Alarm.station_distance > 0.0 and Game.station != null:
		_road_set = true
		var goal: Variant = Game.incident.get("approach", at)
		var road: = Guide.road_length(Game.station.door_position, goal)
		if road > 0.0:
			if OS.get_cmdline_user_args().has("--duty-trace"):
				print("duty: turnout par from %.0f studs of road (%.0f as the crow flies)" % [road, Alarm.station_distance])
			Alarm.station_distance = maxf(road, Alarm.station_distance)
	if water_at < 0.0:
		var reach: = float(Config.Fire.ArriveRange)
		for vehicle in Vehicle.all:
			if vehicle.capacity > 0.0 and vehicle.water > 0.0 and vehicle.global_position.distance_to(at) <= reach:
				water_at = Game.now()
				break



func report(player: Player) -> void :
	if Net.is_client():
		Net.request("duty.report")
	elif CallService.current != null:
		if OS.get_cmdline_user_args().has("--duty-trace"):
			print("duty: %s reports the unit available (status %s, %d trucks out)" % [player.display_name if player != null else "-", CallService.current.status(), CallService.trucks_out()])
		if _readiness_allows(player):
			CallService.current.report(player)




func _readiness_allows(player: Player) -> bool:
	var readiness: = Readiness.current
	if readiness == null or readiness.ready() or CallService.current.status() == "out":
		return true
	var now: = Game.now()
	if now - float(_warned_at.get(player, -100.0)) <= float(Config.Readiness.ReportAgain):
		_warned_at.erase(player)
		return true
	_warned_at[player] = now
	Game.tell(player, Text.f("calls.duty.notReady", [readiness.missing(), Controls.key_name(ACTION)]))
	return false


func _process(_delta: float) -> void :
	if Input.is_action_just_pressed(ACTION) and not Game.ui_open and Game.local_player != null:
		report(Game.local_player)
	if Net.is_client():
		return
	var calls: = CallService.current
	if calls == null:
		return
	_turnout()
	var status: = calls.status()
	var fresh: = {
		"status": status, 
		"next": ceili(calls.wait_left) if status != "out" and not calls.hold and not calls.settling else -1, 
		"settling": calls.settling and status != "out", 
		"shift": Shift.current(), 
		"reported": calls.reported, 
	}
	if fresh != state:
		state = fresh
