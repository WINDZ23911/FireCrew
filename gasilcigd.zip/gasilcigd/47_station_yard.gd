extends RefCounted






const CARS: = [[Vector3(45, 0, -26.4), Color8(176, 180, 186)], [Vector3(61, 0, -26.4), Color8(38, 58, 104)]]
const BIKES: = [Vector3(62.45, 0, -45.0), Vector3(66.85, 0, -45.0)]
const AED: = Vector3(58.0, 6.2, -49.75)
const BINS: = Vector3(70.6, 0, -76.0)
const DUMMY: = Vector3(51.0, 0, -144.5)


static func apply(kit: PolishKit) -> String:
	var folder: = kit.own_folder("StationYard")
	var made: = kit.store.count
	var cars: = _cars(kit)
	var bikes: = 0
	for index in BIKES.size():
		var at: Vector3 = BIKES[index]

		StreetKit.bicycle(kit, folder, Transform3D(Basis(), at), StreetKit.BIKE_PAINTS[index * 3 % StreetKit.BIKE_PAINTS.size()], -0.05)
		bikes += 1
	_aed(kit, folder)
	var bins: = 0
	if kit.clear(BINS, 1.0) and kit.clear(BINS + Vector3(0, 0, 3.3), 1.0) and kit.clear(BINS - Vector3(0, 0, 3.3), 1.0):

		StreetKit.wheelie_bins(kit, folder, PolishKit.facing(BINS, Vector3.RIGHT), [StreetKit.BIN_LIDS[0], StreetKit.BIN_LIDS[2], StreetKit.BIN_LIDS[3], StreetKit.BIN_LIDS[4]])
		bins = 4
	var dummy: = 0
	if kit.open_ground(DUMMY, 2.0) or kit.clear(DUMMY, 2.0):
		_dummy(kit, folder, DUMMY)
		dummy = 1
	return "station yard: %d crew cars, %d bicycles, %d bins, %d dummy (%d parts)" % [cars, bikes, bins, dummy, kit.store.count - made]





static func _cars(kit: PolishKit) -> int:
	var folder: = kit.own_folder("StreetProps")
	var made: = 0
	for entry: Array in CARS:
		var at: Vector3 = entry[0]
		var paint: Color = entry[1]
		var place: = Transform3D(Basis(), at)
		var model: = kit.store.add_node(folder, "Model", "Car", {"WorldPivot": place})
		kit.box(model, place * Transform3D(Basis(), Vector3(0, 2.4, 0)), Vector3(6.2, 2.6, 14.6), paint, "SmoothPlastic", "Body")
		kit._made(kit.store.add(PartStore.Shape.BLOCK, place * Transform3D(Basis(), Vector3(0, 2.05, 0)), Vector3(6.4, 2.2, 15), Color.BLACK, "SmoothPlastic", "CarSolid", model, PolishKit.SOLID, 1.0))
		kit._made(kit.store.add(PartStore.Shape.BLOCK, place * Transform3D(Basis(), Vector3(0, 4.2, 1.2)), Vector3(5.6, 2.2, 7.5), Color.BLACK, "SmoothPlastic", "CarSolid", model, PolishKit.SOLID, 1.0))
		made += 1
	return made



static func _aed(kit: PolishKit, folder: int) -> void :
	var out: = Basis(Vector3.UP, PI)
	var green: = Color8(0, 138, 72)
	kit.box(folder, Transform3D(out, AED), Vector3(1.7, 2.1, 0.45), green, "SmoothPlastic", "AedCabinet")
	kit.box(folder, Transform3D(out, AED + Vector3(0, -0.15, 0.24)), Vector3(1.3, 1.3, 0.04), Color8(200, 226, 214), "Glass", "AedWindow")
	StreetKit.board(kit, folder, Transform3D(out, AED + Vector3(0, 0.78, 0.25)), Vector2(1.5, 0.42), Color8(250, 250, 248), "AED", green, "AedSign")



static func _dummy(kit: PolishKit, folder: int, at: Vector3) -> void :
	var suit: = Color8(222, 104, 34)
	var skin: = Color8(196, 170, 146)
	var place: = PolishKit.facing(at, Vector3(-1, 0, 0))
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0.55, 0.6)), Vector3(1.9, 1.0, 2.6), suit, "Fabric", "DummyBody")
	kit.ball(folder, place * Vector3(0, 0.6, 2.45), Vector3(1.0, 1.0, 1.1), skin, "Fabric", "DummyHead")
	for side: float in [-1.0, 1.0]:
		kit.rod(folder, place * Vector3(side * 0.5, 0.4, -0.7), place * Vector3(side * 0.7, 0.35, -3.6), 0.75, suit.darkened(0.08), "Fabric", "DummyLeg")
		kit.rod(folder, place * Vector3(side * 1.1, 0.5, 1.6), place * Vector3(side * 2.6, 0.35, 0.4), 0.55, suit, "Fabric", "DummyArm")
		kit.box(folder, place * Transform3D(Basis(), Vector3(side * 0.72, 0.3, -3.9)), Vector3(0.7, 0.6, 0.8), Color8(40, 40, 42), "Rubber", "DummyBoot")
