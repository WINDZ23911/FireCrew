class_name Hud
extends CanvasLayer











const SCALED: = ["danger", "water", "radar", "crew", "truck", "cab_wheel", "rewards", "debrief", "hints", "hotbar", "crew_panel", "crew_orders", "fire_out", "gear", "readiness", "captions", "mirrors"]

static var current: Hud


var root: Control

var overlay: Control
var messages: HudMessages
var prompts: HudPrompts
var vitals: HudVitals
var dispatch: HudDispatch
var crosshair: HudReticle
var widgets: Dictionary = {}


func _ready() -> void :
	current = self
	layer = 10


	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.name = "Root"
	root.process_mode = Node.PROCESS_MODE_PAUSABLE
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	overlay = Control.new()
	overlay.name = "Overlay"
	overlay.process_mode = Node.PROCESS_MODE_PAUSABLE
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(overlay)

	Settings.load_all()

	add_widget("danger", HudDanger.new())

	messages = HudMessages.new()
	root.add_child(messages)
	prompts = HudPrompts.new()
	root.add_child(prompts)
	vitals = HudVitals.new()
	root.add_child(vitals)
	dispatch = HudDispatch.new()
	root.add_child(dispatch)

	add_widget("water", HudWater.new())
	add_widget("radar", HudRadar.new())
	add_widget("crew", HudCrew.new())
	add_widget("truck", HudTruck.new())
	add_widget("cab_wheel", HudCabWheel.new())
	add_widget("rewards", HudRewards.new())
	add_widget("debrief", HudDebrief.new())
	add_widget("hints", HudHints.new())
	add_widget("fire_out", HudFireOut.new())
	add_widget("captions", HudCaptions.new())
	add_child(HudSettingsLive.new())

	crosshair = HudReticle.new()
	overlay.add_child(crosshair)


	add_widget("map", HudMap.new())
	add_widget("pause", HudPause.new())
	if OS.get_cmdline_user_args().has("--hud-open=demo"):
		_demo()




func _demo() -> void :
	await get_tree().create_timer(1.0).timeout
	var player: = Game.local_player
	player.rewarded.emit(25, "flameOut")
	player.rewarded.emit(400, "bonus")
	player.health = 18.0
	var at: = player.global_position
	HudRadar.set_route(PackedVector3Array([at, at + Vector3(0, 0, 80), at + Vector3(150, 0, 120), at + Vector3(260, 0, 400)]))



func add_widget(key: String, widget: Control) -> void :
	widgets[key] = widget
	(root if key in SCALED else overlay).add_child(widget)

	for top: String in ["map", "pause"]:
		if widgets.has(top) and widgets[top].get_parent() == overlay:
			overlay.move_child(widgets[top], -1)


func _process(_delta: float) -> void :
	_fit_scale()



func _fit_scale() -> void :
	var view: = get_viewport().get_visible_rect().size
	var factor: = Settings.hud_scale
	if not is_equal_approx(root.scale.x, factor) or not root.size.is_equal_approx(view / factor):
		root.set_anchors_preset(Control.PRESET_TOP_LEFT)
		root.position = Vector2.ZERO
		root.scale = Vector2(factor, factor)
		root.size = view / factor




static func to_hud(screen_point: Vector2) -> Vector2:
	if current == null:
		return screen_point
	return screen_point / current.root.scale.x


func _debug_dump() -> void :
	print("hud root ", root.size, " ", root.get_global_rect(), " vis ", root.is_visible_in_tree())
	for child in root.get_children():
		print("  ", child.get_class(), " ", child.get_global_rect(), " ", child.get_script().resource_path if child.get_script() else "")
		for sub in child.get_children():
			if sub is Control:
				print("     ", sub.name, " ", sub.get_global_rect(), " vis ", sub.visible, " mod ", sub.modulate)
