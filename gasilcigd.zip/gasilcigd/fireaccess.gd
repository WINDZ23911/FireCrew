extends ProofDebug






func _scenario_fireaccess() -> void :
	await _wait(2.0)
	var fire: = FireService.current
	if not _check(fire != null and not fire.buildings.is_empty(), "the town has buildings that burn"):
		await _done()
		return
	var slowest: = 0.0
	var shut: Array[String] = []
	var thin: = 0
	var high: = 0
	var gapped: Array[Building] = []
	var started: = Time.get_ticks_usec()
	for building in fire.buildings:
		var begun: = Time.get_ticks_usec()
		var access: = FireAccess.of(building)
		var took: = (Time.get_ticks_usec() - begun) / 1000.0
		slowest = maxf(slowest, took)
		var counts: = {"ground": 0, "ladder": 0, "none": 0}
		var top: = 0.0
		var low_none: = 0
		for index in building.fuel.size():
			counts[access["nodes"][index]] += 1
			var up: = (building.fuel[index]["position"] as Vector3).y - float(access["ground_y"])
			top = maxf(top, up)
			if access["nodes"][index] == "none" and up < 12.0:
				low_none += 1
		if low_none > 0 and not building.has_rooms():
			gapped.append(building)
			print("fireaccess: gap: %s at (%.0f, %.0f): %d spots low down out of reach" % [building.name, building.position.x, building.position.z, low_none])
		var fightable: = FireAccess.fightable(building)
		if not fightable:
			shut.append(building.name)
		if counts["none"] > 0:
			thin += 1
		if counts["ladder"] > 0:
			high += 1
		if counts["none"] > 0 or counts["ladder"] > 0 or took > 40.0:
			print("fireaccess: %-34s %s at (%.0f, %.0f) rooms %s: %d ground, %d ladder, %d none; top %.0f up; %d cells, %.0f ms%s" % [
				building.name.substr(0, 34), "house" if building is House else "box", building.position.x, building.position.z, 
				building.has_rooms(), counts["ground"], counts["ladder"], counts["none"], top, access["cells"], took, 
				"" if fightable else "  NOT SET ALIGHT"])
	var total: = (Time.get_ticks_usec() - started) / 1000.0
	print("fireaccess: %d buildings in %.0f ms (slowest %.0f ms); %d with spots out of reach, %d with spots only the ladder reaches, %d never set alight: %s" % [
		fire.buildings.size(), total, slowest, thin, high, shut.size(), ", ".join(shut)])
	_check(slowest < 250.0, "a building is worked out in under a quarter of a second (%.0f ms)" % slowest)
	_check(shut.size() < fire.buildings.size() / 4, "most buildings can still burn")
	print("fireaccess: %d plain buildings with spots low down in a gap" % gapped.size())


	if not gapped.is_empty():
		var building: Building = gapped[0]
		var access: = FireAccess.of(building)
		var gap_at: = building.position
		for index in building.fuel.size():
			if access["nodes"][index] == "none":
				gap_at = building.fuel[index]["position"]
				break
		print("fireaccess: a fire on %s at (%.0f, %.0f), a spot in its gap at %s" % [building.name, building.position.x, building.position.z, gap_at])
		fire.run_incident(building)
		player.teleport(_ground(building.position + Vector3(0, 0, 30)) + Vector3(0, 0.5, 0))
		_view(gap_at + Vector3(0, 70, 8), gap_at)
		var lit_in_gap: = 0
		var most: = 0
		for second in 45:
			await _wait(1.0)
			var burning: = 0
			for node: Dictionary in fire.incident.get("group", {}).get("nodes", []):
				if node["burning"]:
					burning += 1
					if access["nodes"][node["index"]] == "none":
						lit_in_gap += 1
			most = maxi(most, burning)
		await _snap("gap")
		print("fireaccess: %d flames at most; %d flame-seconds where nobody can reach" % [most, lit_in_gap])
		_check(most > 0, "the fire burns")
		_check(lit_in_gap == 0, "it never catches where nobody can reach")
	await _done()


func _scenario_fireladder() -> void :
	await _wait(2.0)
	var fire: = FireService.current
	var ladder: = LadderService.current
	if not _check(fire != null and ladder != null, "the town has a fire service and a ladder truck"):
		await _done()
		return
	var told: Array[String] = []
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))

	var station: = Game.station.door_position if Game.station else Vector3.ZERO
	var building: Building = null
	for other in fire.buildings:
		if other.has_rooms() or other.ruined:
			continue
		if building != null and other.position.distance_to(station) >= building.position.distance_to(station):
			continue
		if (FireAccess.of(other)["nodes"] as Array).count("ladder") >= 3:
			building = other
	if not _check(building != null, "a building has flames only the ladder reaches"):
		await _done()
		return

	var access: = FireAccess.of(building)
	var kept: Array = access["nodes"].duplicate()
	for index in kept.size():
		if kept[index] == "ground":
			access["nodes"][index] = "none"
	CallService.current.run_call("fire", func() -> Variant:
		await fire.run_incident(building)
		return null)
	await _wait(1.5)
	access["nodes"] = kept
	var origin: Vector3 = building.position
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"]:
			origin = node["position"]
	print("fireladder: %s at (%.0f, %.0f), the fire %.0f studs up; told: %s" % [building.name, building.position.x, building.position.z, float(fire.incident.get("ladder_height", 0.0)), " / ".join(told)])
	_check(fire.incident.get("ladder", false), "the call is marked as one for the ladder")
	var said: = false
	for line in told:
		said = said or line.contains("Take the ladder truck")
	_check(said, "the dispatch says to take the ladder truck")
	_check(Game.station.door_open(int(Config.Station.LadderBay)), "the ladder's bay door goes up")
	await _snap("banner")
	await _wait(4.0)
	var card: = HudDispatch.current.shown_text()
	print("fireladder: card: %s" % card)
	var needed: = Text.say(Text.m("hud.dispatch.ladder"))
	var bring: = Text.say(Text.m("calls.fire.next.ladder"))
	_check(card.contains(needed), "the call's card says the ladder truck is needed")
	_check(card.contains(bring), "and its next step is to bring it")
	await _snap("card")

	var away: = Vector3(origin.x - building.position.x, 0, origin.z - building.position.z).normalized()
	_park(ladder.vehicle, _open_spot(origin + away * 20.0, away, ladder.vehicle), atan2(away.x, away.z))
	await _wait(3.0)
	card = HudDispatch.current.shown_text()
	var truck_at: = ladder.vehicle.global_position
	print("fireladder: with the truck %.0f studs from the building: %s" % [Vector2(truck_at.x - building.position.x, truck_at.z - building.position.z).length(), card])
	_check( not card.contains(bring), "with the truck there the next step is the flames")
	await _done()
