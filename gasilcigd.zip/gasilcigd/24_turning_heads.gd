extends RefCounted







const PAVINGS: = ["paving", "forecourt", "plaza", "court", "path"]
const PAVED: = 0.12
const MIN_RADIUS: = 6.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var matched: = 0
	for row in kit.rows_under("Map/Surfaces"):
		if store.shape(row) != PartStore.Shape.CYLINDER or store.name_at(row) != "lane":
			continue
		var at: = store.position(row)
		var radius: = minf(store.size(row).y, store.size(row).z) / 2.0
		if radius < MIN_RADIUS:
			continue

		var over: = 0
		var samples: = 0
		var under: Dictionary = {}
		for ring: float in [0.3, 0.65, 0.95]:
			for k in 10:
				var spot: = at + Vector3(cos(k * TAU / 10.0), 0, sin(k * TAU / 10.0)) * radius * ring
				samples += 1
				for other in kit.parts_at(Vector3(spot.x, 0, spot.z)):
					if other != row and store.name_at(other) in PAVINGS:
						over += 1
						under[other] = int(under.get(other, 0)) + 1
						break
		if float(over) / float(samples) < PAVED:
			continue
		var paving: int = -1
		for other: int in under:
			if paving < 0 or int(under[other]) > int(under[paving]):
				paving = other
		store.set_color(row, store.color(paving))
		store.set_material(row, store.material(paving))
		matched += 1
	return "turning heads: %d on paved forecourts paved over" % matched if matched > 0 else ""
