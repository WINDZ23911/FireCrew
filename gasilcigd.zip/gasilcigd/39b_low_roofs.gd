extends RefCounted











const STREETS: = ["Cesta XV. brigade", "Breg revolucije"]
const LOW: = 0.45
const SHARE: = 55
const TILES: = [Color8(107, 74, 60), Color8(90, 64, 52), Color8(62, 63, 68)]


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var layout: Array = kit.layout()["buildings"]
	var lowered: = 0
	var looked: = 0
	for model in kit.models_under("Map/Buildings"):
		var rows: = store.rows_in(model)
		var body: = -1
		var slopes: Array = []
		var gables: Array = []
		var chimneys: Array = []
		var dormers: = false
		for row in rows:
			match store.name_at(row):
				"Body":
					body = row
				"Roof":
					if store.shape(row) == PartStore.Shape.WEDGE:
						slopes.append(row)
					elif store.shape(row) == PartStore.Shape.CORNER_WEDGE:
						dormers = true
				"Gable":
					gables.append(row)
				"Chimney", "ChimneyCap":
					chimneys.append(row)
				"Dormer", "DormerRoof":
					dormers = true
		if body < 0 or slopes.size() != 2 or dormers:
			continue
		var at: = store.position(body)
		var building: = _nearest(layout, Vector2(at.x, at.z))
		if building.get("kind", "") != "house" or not STREETS.has(building.get("street", "")):
			continue
		looked += 1
		if int(rand_from_seed(hash([int(at.x), int(at.z), "low roof"]))[0]) % 100 >= SHARE:
			continue
		var rise: = store.size(slopes[0]).y
		var low: = store.size(slopes[0]).z * LOW
		if low >= rise:
			continue
		var tiles: Color = TILES[int(rand_from_seed(hash([int(at.x), int(at.z), "tiles"]))[0]) % TILES.size()]
		for row: int in slopes + gables:
			var size: = store.size(row)
			var scale: = low / rise
			var place: = store.transform(row)

			place.origin.y -= size.y * (1.0 - scale) / 2.0
			store.set_transform(row, place)
			store.set_size(row, Vector3(size.x, size.y * scale, size.z))
			if store.name_at(row) == "Roof":
				store.set_color(row, tiles)

		for row: int in chimneys:
			var place: = store.transform(row)
			place.origin.y -= (rise - low) * 0.85
			store.set_transform(row, place)
		lowered += 1
		if OS.get_cmdline_user_args().has("--roof-trace"):
			print("low roof at ", at)
	return "low roofs: %d of %d houses on %s" % [lowered, looked, " and ".join(STREETS)] if looked > 0 else ""


static func _nearest(layout: Array, spot: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building
	return best
