class_name CrewNav
extends Node3D











const TILE: = 96.0
const MARGIN: = 6.0
const LOW: = -60.0
const HIGH: = 260.0

static var current: CrewNav

var _rows_of: Dictionary = {}
var _regions: Dictionary = {}
var _faces_of: Dictionary = {}
var _queue: Array[Vector2i] = []
var _baking: = false
var _template: NavigationMesh
var _clockwise: = true
var _bake_started: = 0
var _baking_tile: = Vector2i.ZERO
var _parked: Dictionary = {}
var _still_since: Dictionary = {}
var _last_at: Dictionary = {}
var _next_watch: = 0.0


func _ready() -> void :
	current = self
	_template = NavigationMesh.new()
	_template.cell_size = 0.5
	_template.cell_height = 0.25
	_template.agent_height = 5.0
	_template.agent_radius = 1.0
	_template.agent_max_climb = 1.75
	_template.agent_max_slope = 50.0
	_template.region_min_size = 4.0
	_template.edge_max_error = 1.0
	_template.border_size = 2.0
	var map: = get_world_3d().navigation_map
	NavigationServer3D.map_set_cell_size(map, _template.cell_size)
	NavigationServer3D.map_set_cell_height(map, _template.cell_height)
	NavigationServer3D.map_set_edge_connection_margin(map, 1.5)

	var top: = BoxMesh.new().get_faces()
	for index in range(0, top.size(), 3):
		var normal: = (top[index + 1] - top[index]).cross(top[index + 2] - top[index])
		if absf(normal.normalized().y) > 0.9:
			_clockwise = (normal.y > 0.0) == (top[index].y > 0.0)
			break
	_sort_rows()


func _exit_tree() -> void :
	if current == self:
		current = null


static func tile_of(at: Vector3) -> Vector2i:
	return Vector2i(floori(at.x / TILE), floori(at.z / TILE))



func ensure(at: Vector3, around: = 0.35) -> void :
	var reach: = TILE * around
	for offset: Vector2 in [Vector2.ZERO, Vector2(reach, 0), Vector2( - reach, 0), Vector2(0, reach), Vector2(0, - reach), Vector2(reach, reach), Vector2( - reach, - reach), Vector2(reach, - reach), Vector2( - reach, reach)]:
		var tile: = tile_of(at + Vector3(offset.x, 0, offset.y))
		if not _regions.has(tile) and not tile in _queue:
			_queue.append(tile)
	_next()



func rebake(tile: Vector2i) -> void :
	if _regions.has(tile) and not tile in _queue:
		_queue.append(tile)
		_next()



static func tiles_near(at: Vector3, reach: float) -> Array[Vector2i]:
	var found: Array[Vector2i] = []
	var low: = tile_of(at - Vector3(reach, 0, reach))
	var high: = tile_of(at + Vector3(reach, 0, reach))
	for x in range(low.x, high.x + 1):
		for z in range(low.y, high.y + 1):
			found.append(Vector2i(x, z))
	return found




func _process(_delta: float) -> void :
	if Game.now() < _next_watch:
		return
	_next_watch = Game.now() + 0.25
	var movers: Array[Node3D] = []
	var stills: Dictionary = {}
	for vehicle in Vehicle.all:
		movers.append(vehicle)

		stills[vehicle] = absf(vehicle.forward_speed) < 0.4 and Vector2(vehicle.linear_velocity.x, vehicle.linear_velocity.z).length() < 0.6
	if Traffic.current:
		for car in Traffic.current.vehicles:
			var body: Node3D = car.body
			if body == null or not body.is_inside_tree():
				continue
			var at: = body.global_position

			if not _parked.has(body) and not _regions.has(tile_of(at)):
				continue
			var before: Vector3 = _last_at.get(body, Vector3.INF)
			_last_at[body] = at
			movers.append(body)
			stills[body] = before != Vector3.INF and Vector2(at.x - before.x, at.z - before.z).length() < 0.15
	for table: Dictionary in [_parked, _still_since, _last_at]:
		for gone: Variant in table.keys():
			if not is_instance_valid(gone):
				table.erase(gone)
	for vehicle in movers:
		var baked_at: Vector3 = _parked.get(vehicle, Vector3.INF)
		var here: = vehicle.global_position
		var still: bool = stills[vehicle]
		if not still:
			_still_since.erase(vehicle)
			if baked_at != Vector3.INF and here.distance_to(baked_at) > 4.0:
				_parked[vehicle] = Vector3.INF
				for tile in tiles_near(baked_at, 14.0):
					rebake(tile)
			continue
		if not _still_since.has(vehicle):
			_still_since[vehicle] = Game.now()

		if Game.now() - _still_since[vehicle] < (0.6 if vehicle is Vehicle else 2.5):
			continue
		if baked_at == Vector3.INF or here.distance_to(baked_at) > 3.0:
			var any_baked: = false
			for tile in tiles_near(here, 14.0):
				any_baked = any_baked or _regions.has(tile)
			if not any_baked:
				continue
			if baked_at != Vector3.INF:
				for tile in tiles_near(baked_at, 14.0):
					rebake(tile)
			_parked[vehicle] = here
			for tile in tiles_near(here, 14.0):
				rebake(tile)



func ready_at(at: Vector3) -> bool:
	return _regions.get(tile_of(at)) != null




func path(from: Vector3, to: Vector3) -> PackedVector3Array:
	if not ready_at(from) or not ready_at(to):
		return PackedVector3Array()
	var map: = get_world_3d().navigation_map
	var start: = NavigationServer3D.map_get_closest_point(map, from)
	var end: = NavigationServer3D.map_get_closest_point(map, to)
	if start.distance_to(from) > 8.0:
		return PackedVector3Array()
	var found: = NavigationServer3D.map_get_path(map, start, end, true)
	if found.is_empty() or found[found.size() - 1].distance_to(end) > 2.0:
		return PackedVector3Array()
	return found



func closest(at: Vector3) -> Vector3:
	if not ready_at(at):
		return at
	var found: = NavigationServer3D.map_get_closest_point(get_world_3d().navigation_map, at)
	return found if found.distance_to(at) < 12.0 else at





func _sort_rows() -> void :
	var store: = Game.store
	for row in store.count:
		if not store.flags(row) & PartStore.COLLIDE:
			continue
		var place: = store.position(row)
		var size: = store.size(row)
		var half: = maxf(size.x, maxf(size.y, size.z)) * 0.75 + MARGIN
		var low: = tile_of(place - Vector3(half, 0, half))
		var high: = tile_of(place + Vector3(half, 0, half))
		for x in range(low.x, high.x + 1):
			for z in range(low.y, high.y + 1):
				var tile: = Vector2i(x, z)
				if not _rows_of.has(tile):
					_rows_of[tile] = PackedInt32Array()
				_rows_of[tile].append(row)


func _next() -> void :
	if _baking or _queue.is_empty():
		return
	var tile: Vector2i = _queue.pop_front()
	if not _regions.has(tile):
		_regions[tile] = null
	_baking = true
	_baking_tile = tile
	_bake_started = Time.get_ticks_msec()
	var mesh: NavigationMesh = _template.duplicate()
	var box: = AABB(Vector3(tile.x * TILE, LOW, tile.y * TILE), Vector3(TILE, HIGH - LOW, TILE))

	var border: = mesh.border_size
	mesh.filter_baking_aabb = AABB(box.position - Vector3(border, 0, border), box.size + Vector3(border * 2.0, 0, border * 2.0))
	var source: = NavigationMeshSourceGeometryData3D.new()
	var faces: = PackedVector3Array()
	var world: = Game.world
	for row: int in _rows_of.get(tile, PackedInt32Array()):
		if not world.is_solid_row(row):
			continue
		var local: = _faces(Game.store.shape(row), Game.store.size(row))
		var place: = Game.store.transform(row)
		for corner in local:
			faces.append(place * corner)

	var reach: = AABB(box.position - Vector3(MARGIN, 0, MARGIN), box.size + Vector3(MARGIN * 2.0, 0, MARGIN * 2.0))
	for vehicle: Variant in _parked:
		if not is_instance_valid(vehicle) or _parked[vehicle] == Vector3.INF:
			continue
		var here: Vector3 = vehicle.global_position
		if not reach.grow(14.0).has_point(Vector3(here.x, box.position.y + 1.0, here.z)):
			continue
		for child in (vehicle as Node).get_children():
			if child is CollisionShape3D and child.shape is BoxShape3D:
				var cube: = BoxMesh.new()
				cube.size = child.shape.size
				var place: Transform3D = vehicle.global_transform * child.transform
				for corner in cube.get_faces():
					faces.append(place * corner)
	if not faces.is_empty():
		source.add_faces(faces, Transform3D.IDENTITY)
	NavigationServer3D.bake_from_source_geometry_data_async(mesh, source, func() -> void :
		_baked.call_deferred(tile, mesh)
	)


func _baked(tile: Vector2i, mesh: NavigationMesh) -> void :
	_baking = false
	if not is_inside_tree():
		return
	var region: NavigationRegion3D = _regions.get(tile)
	if region == null:
		region = NavigationRegion3D.new()
		region.name = "Tile_%d_%d" % [tile.x, tile.y]
		add_child(region)
		_regions[tile] = region
	region.navigation_mesh = mesh
	if OS.get_cmdline_user_args().has("--nav-times"):
		print("nav: tile %s baked in %d ms, %d polygons" % [tile, Time.get_ticks_msec() - _bake_started, mesh.get_polygon_count()])
	_next()



func _faces(shape: int, size: Vector3) -> PackedVector3Array:
	var key: = [shape, size]
	if _faces_of.has(key):
		return _faces_of[key]
	var faces: = PackedVector3Array()
	if shape == PartStore.Shape.WEDGE or shape == PartStore.Shape.CORNER_WEDGE:
		var corners: Array = World.wedge_corners(shape)
		var middle: = Vector3.ZERO
		for corner: Vector3 in corners:
			middle += corner * size / corners.size()
		for face: Array in World.wedge_faces(shape):
			var a: Vector3 = corners[face[0]] * size
			var b: Vector3 = corners[face[1]] * size
			var c: Vector3 = corners[face[2]] * size
			var outward: = (a + b + c) / 3.0 - middle
			var turned: = (b - a).cross(c - a).dot(outward) > 0.0
			if turned == _clockwise:
				faces.append_array([a, b, c])
			else:
				faces.append_array([a, c, b])
	else:
		var box: = BoxMesh.new()
		box.size = size if shape == PartStore.Shape.BLOCK else (Vector3.ONE * minf(size.x, minf(size.y, size.z)) if shape == PartStore.Shape.BALL else size)
		faces = box.get_faces()
	_faces_of[key] = faces
	return faces
