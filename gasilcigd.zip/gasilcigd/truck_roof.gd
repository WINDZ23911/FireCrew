class_name TruckRoof
extends Node













const CLIMB_SPEED: = 9.0
const HOLD_WIDE: = 1.6
const HOLD_OUT: = 3.0
const STAND_OFF: = 1.15
const TOP_REACH: = 1.9
const LET_GO: = 0.6
const GRAB_EASE: = 18.0
const AIM_FAR: = 600.0
const AIM_OPEN: = 300.0
const PITCH_LOW: = -25.0
const PITCH_HIGH: = 70.0
const OPEN_ARC: = 35.0
const TURN_RATE: = 1.6
const DRY_EVERY: = 8.0

static var current: TruckRoof

var ladders: Array = []
var monitors: Array = []
var _climbing: Dictionary = {}
var _let_go: Dictionary = {}
var _water_on: = false
var _said: Array = []
var _said_at: = 0.0
var _last_dry: = -100.0
var _debug_aim: Variant = null
var _hinted: = false


func _init() -> void :
	current = self

	process_physics_priority = 10


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	for vehicle in Vehicle.all:


		var given: Variant = vehicle.data.get("rearLadder")
		for entry: Variant in (given if given is Array else [given]):
			var ladder: Dictionary = Vehicle.table(entry)
			if ladder.is_empty():
				continue
			var yaw: = float(ladder.get("side", 0.0)) * PI / 2.0
			ladders.append({
				"vehicle": vehicle, "x": float(ladder["x"]), "z": float(ladder["z"]), 
				"bottom": float(ladder["bottom"]), "top": float(ladder["top"]), 
				"yaw": yaw, "turn": Basis(Vector3.UP, - yaw), 


				"off": vehicle.v(ladder["off"]) if ladder.has("off") else null, 
			})
		var monitor: Dictionary = Vehicle.table(vehicle.data.get("monitor"))
		if not monitor.is_empty() and vehicle.objects.has("MonitorHead"):
			_build_monitor(vehicle, monitor)
	Net.handle("roof.control", control)
	Net.handle("roof.leave", func(player: Player, index: int) -> void :
		if index >= 0 and index < monitors.size():
			leave(monitors[index], player)
	)
	Net.share("roof.monitors", func() -> Variant:
		var list: Array = []
		for monitor: Dictionary in monitors:
			list.append([snappedf(monitor["yaw"], 0.001), snappedf(monitor["pitch"], 0.001)])
		return list
	, func(list: Variant) -> void :
		for index in mini(monitors.size(), (list as Array).size()):
			monitors[index]["told"] = list[index]
	, 10.0)
	_debug.call_deferred()







func _build_monitor(vehicle: Vehicle, info: Dictionary) -> void :
	var pivot: = vehicle.v(info["pivot"])
	var head: = vehicle.hang("MonitorHead", Transform3D(Basis.IDENTITY, pivot))
	var barrel: = vehicle.hang("MonitorBarrel", Transform3D(Basis.IDENTITY, vehicle.v(info["elbow"])))
	barrel.reparent(head)
	var tip: = Node3D.new()
	tip.name = "MonitorTip"
	barrel.add_child(tip)
	tip.position = vehicle.v(info["tip"]) - vehicle.v(info["elbow"])

	var seat: = Node3D.new()
	seat.name = "MonitorStand"
	head.add_child(seat)
	var stand: = vehicle.v(info["stand"])
	seat.position = stand - pivot
	seat.set_meta("stand", true)
	var grips: = {}
	for index in 2:
		var grip: Vector3 = vehicle.v(info["grips"][index]) - stand
		grips["L" if index == 0 else "R"] = [grip, Vector3(0, 0, -1), Vector3(-0.3 if index == 0 else 0.3, -0.9, 0.5)]
	seat.set_meta("grips", grips)
	var handle: = Node3D.new()
	seat.add_child(handle)
	handle.position = Vector3(0, 2.6, 0)
	var monitor: = {
		"vehicle": vehicle, "head": head, "barrel": barrel, "tip": tip, "seat": seat, "operator": null, 
		"water": false, "aim": null, "yaw": 0.0, "pitch": 0.0, "told": [], 
	}
	var prompt: = Prompt.make(handle, Text.m("gear.truck.monitorTake"), Text.m("gear.truck.monitor"), 0.0, 7.0)
	prompt.triggered.connect( func(player: Player) -> void : take(monitor, player))

	prompt.condition = func(player: Player) -> bool:
		return monitor["operator"] == null and player.seat == null and (vehicle.global_transform.affine_inverse() * player.global_position).y > float(vehicle.data["top"]) - 0.5
	monitor["prompt"] = prompt
	var settings: Dictionary = Config.Ladder.Monitor
	var hose: = {
		"vehicle": vehicle, "node": tip, "use": float(settings["Use"]), "power": float(settings["Power"]), 
		"speed": float(settings["Speed"]), "state": func() -> Variant: return _monitor_state(monitor), 
		"exclude": [vehicle.get_rid()] as Array[RID], 
	}
	monitor["hose"] = hose
	if HoseService.current:
		HoseService.current.add_monitor(hose)
	monitors.append(monitor)



func take(monitor: Dictionary, player: Player) -> void :
	if monitor["operator"] != null or player.seat != null or player.health <= 0.0:
		return
	monitor["operator"] = player
	monitor["water"] = false
	monitor["aim"] = null
	player.sit(monitor["seat"])
	if player.is_local:
		player.camera.yaw = (monitor["seat"] as Node3D).global_rotation.y
	Game.notify(Text.m("gear.truck.monitorHelp"), "", player)



func leave(monitor: Dictionary, player: Player) -> void :
	if monitor["operator"] != player:
		return
	monitor["operator"] = null
	monitor["water"] = false
	monitor["aim"] = null
	var seat: Node3D = monitor["seat"]
	var behind: = seat.global_position + seat.global_basis.z * 1.2 + Vector3(0, 0.2, 0)
	player.leave_seat(behind)



func control(player: Player, index: int, water: bool, aim: Variant) -> void :
	if index < 0 or index >= monitors.size():
		return
	var monitor: Dictionary = monitors[index]
	if monitor["operator"] != player:
		return
	monitor["aim"] = aim if aim is Vector3 and (aim as Vector3).is_finite() else null
	monitor["water"] = water and monitor["aim"] != null
	var vehicle: Vehicle = monitor["vehicle"]
	if monitor["water"] and vehicle.water <= 0.0 and Game.now() - _last_dry > DRY_EVERY:
		_last_dry = Game.now()
		Game.notify(Text.m("gear.ladder.noWater"), "", player)



func _monitor_state(monitor: Dictionary) -> Variant:
	if Net.is_client() or monitor["operator"] == null or not monitor["water"] or monitor["aim"] == null:
		return null
	var tip: Node3D = monitor["tip"]
	var offset: Vector3 = monitor["aim"] - tip.global_position
	if offset.length() < 3.0 or offset.normalized().dot( - tip.global_basis.z) < cos(deg_to_rad(OPEN_ARC)):
		return null
	return [monitor["operator"], monitor["aim"]]



func operating(player: Player) -> bool:
	for monitor: Dictionary in monitors:
		if monitor["operator"] == player or (player != null and player.seat == monitor["seat"]):
			return true
	return false



func _turn_monitors(delta: float) -> void :
	for monitor: Dictionary in monitors:
		var head: Node3D = monitor["head"]
		var barrel: Node3D = monitor["barrel"]
		if Net.is_client():
			var told: Array = monitor["told"]
			if told.size() == 2:
				var ease: = 1.0 - exp( - delta * 14.0)
				monitor["yaw"] = lerp_angle(monitor["yaw"], float(told[0]), ease)
				monitor["pitch"] = lerpf(monitor["pitch"], float(told[1]), ease)
		else:
			var operator: Variant = monitor["operator"]
			if operator != null and ( not is_instance_valid(operator) or operator.seat != monitor["seat"] or operator.health <= 0.0):
				monitor["operator"] = null
				monitor["water"] = false
				monitor["aim"] = null
			var vehicle: Vehicle = monitor["vehicle"]
			if monitor["operator"] != null and absf(vehicle.forward_speed) > TruckService.SECURE_SPEED:
				leave(monitor, monitor["operator"])
			var aim: Variant = monitor["aim"]
			if aim is Vector3:
				var local: Vector3 = head.get_parent_node_3d().global_transform.affine_inverse() * (aim as Vector3) - head.position
				var yaw: = atan2( - local.x, - local.z)
				var from_elbow: Vector3 = local - barrel.position.rotated(Vector3.UP, yaw)
				var pitch: = clampf(atan2(from_elbow.y, Vector2(from_elbow.x, from_elbow.z).length()), deg_to_rad(PITCH_LOW), deg_to_rad(PITCH_HIGH))
				var step: = TURN_RATE * delta
				monitor["yaw"] = monitor["yaw"] + clampf(wrapf(yaw - monitor["yaw"], - PI, PI), - step, step)
				monitor["pitch"] = move_toward(monitor["pitch"], pitch, step)
		head.rotation.y = monitor["yaw"]
		barrel.rotation.x = monitor["pitch"]



func _work_monitor() -> void :
	var player: = Game.local_player
	if player == null:
		return
	for index in monitors.size():
		var monitor: Dictionary = monitors[index]
		if player.seat != monitor["seat"]:
			continue
		if Game.ui_open:
			_ask(index, false, null)
			return
		if Input.is_action_just_pressed("veh_exit"):
			_water_on = false
			Net.request("roof.leave", [index])
			return
		if Input.is_action_just_pressed("monitor_water"):
			_water_on = not _water_on
		var water: = _water_on or (Input.is_action_pressed("fire") and player.camera != null and player.camera.captured)
		if _debug_aim != null:
			_ask(index, true, _debug_aim)
			return
		_ask(index, water, _aim_point(player, monitor))
		return
	_water_on = false



func _aim_point(player: Player, monitor: Dictionary) -> Vector3:
	var camera: = get_viewport().get_camera_3d()
	if player.camera != null:
		camera = player.camera.camera
	var from: = camera.global_position
	var along: = - camera.global_basis.z
	var vehicle: Vehicle = monitor["vehicle"]
	var hit: = Game.world.raycast(from, from + along * AIM_FAR, World.LAYER_QUERY | World.LAYER_VEHICLE, [vehicle.get_rid(), player.get_rid()])
	return hit["position"] if not hit.is_empty() else from + along * AIM_OPEN




func _ask(index: int, water: bool, aim: Variant) -> void :
	if not Net.is_client():
		Net.request("roof.control", [index, water, aim])
		return
	var now: = Game.now()
	var saying: = [index, water]
	if saying != _said or now - _said_at >= 0.08:
		_said = saying
		_said_at = now
		Net.request("roof.control", [index, water, aim])







func _climb(dt: float) -> void :
	for player in Game.players:
		if not player.is_local or player.brain != null:
			continue
		if player.seat != null or player.frozen or player.health <= 0.0 or player.lying():
			_climbing.erase(player)
			continue
		var push: = 0.0
		var jumped: = false
		if not Game.ui_open:
			push = Input.get_axis("move_back", "move_forward")
			jumped = Input.is_action_just_pressed("jump")
		var hold: Variant = _climbing.get(player)
		if hold == null and not _hinted and _at_foot(player):
			_hinted = true
			Game.notify(Text.m("gear.truck.ladderHint"), "", player)
		if hold == null:
			if Game.now() < _let_go.get(player, 0.0):
				continue
			hold = _take_hold(player, push)
			if hold == null:
				continue
			_climbing[player] = hold
		if jumped:
			_climbing.erase(player)
			_let_go[player] = Game.now() + LET_GO
			continue
		_on_rungs(player, hold, push, dt)



func _from(ladder: Dictionary, local: Vector3) -> Vector3:
	return (ladder["turn"] as Basis) * (local - Vector3(float(ladder["x"]), 0, float(ladder["z"])))



func _to(ladder: Dictionary, at: Vector3) -> Vector3:
	return (ladder["turn"] as Basis).inverse() * at + Vector3(float(ladder["x"]), 0, float(ladder["z"]))



func _at_foot(player: Player) -> bool:
	for ladder: Dictionary in ladders:
		var local: = _from(ladder, (ladder["vehicle"] as Vehicle).global_transform.affine_inverse() * player.global_position)
		if absf(local.x) < HOLD_WIDE and local.z > 0.0 and local.z < HOLD_OUT and local.y < float(ladder["bottom"]):
			return true
	return false



func _facing_truck(player: Player, ladder: Dictionary) -> bool:
	var vehicle: Vehicle = ladder["vehicle"]
	var ahead: = Basis(Vector3.UP, player.camera.yaw if player.camera != null else player.rig.global_rotation.y) * Vector3.FORWARD
	return ahead.dot(vehicle.global_basis * _to(ladder, Vector3.FORWARD) - vehicle.global_basis * _to(ladder, Vector3.ZERO)) > -0.1




func _take_hold(player: Player, push: float) -> Variant:
	if absf(push) < 0.5:
		return null
	for ladder: Dictionary in ladders:
		var vehicle: Vehicle = ladder["vehicle"]
		var local: = _from(ladder, vehicle.global_transform.affine_inverse() * player.global_position)
		if absf(local.x) > HOLD_WIDE:
			continue
		var facing: = _facing_truck(player, ladder)
		var top: float = ladder["top"]
		var up: = push if facing else - push

		if up > 0.0 and local.z > -0.3 and local.z < HOLD_OUT and local.y < top - 0.5 and local.y > float(ladder["bottom"]) - 5.0:
			return {"ladder": ladder, "y": local.y}

		if up < 0.0 and local.y > top - 0.4 and local.y < top + 1.6 and local.z > - TOP_REACH - 0.3:
			return {"ladder": ladder, "y": top - 0.6}
	return null


func _on_rungs(player: Player, hold: Dictionary, push: float, dt: float) -> void :
	var ladder: Dictionary = hold["ladder"]
	var vehicle: Vehicle = ladder["vehicle"]
	var frame: = vehicle.global_transform
	var top: float = ladder["top"]
	var up: = push if _facing_truck(player, ladder) else - push
	var y: float = hold["y"] + up * CLIMB_SPEED * dt
	if up > 0.0 and y >= top - 0.25:

		_climbing.erase(player)
		_let_go[player] = Game.now() + LET_GO
		var off: Variant = ladder["off"]
		if off != null:
			player.climb_off(frame * (off as Vector3), 0.6)
		else:
			player.climb_off(frame * _to(ladder, Vector3(-0.9, top + 0.9, -2.3)))
		return
	var at: = frame * _to(ladder, Vector3(0, y, STAND_OFF))
	if up < 0.0:

		var ground: = Game.world.raycast(at + Vector3(0, 0.3, 0), at + Vector3(0, -0.4, 0), World.LAYER_SOLID | World.LAYER_VEHICLE, [player.get_rid()])
		if not ground.is_empty():
			_climbing.erase(player)
			_let_go[player] = Game.now() + LET_GO
			player.teleport(ground["position"] + Vector3(0, 0.05, 0))
			return
	hold["y"] = y

	var flat: = player.global_position.lerp(at, 1.0 - exp( - dt * GRAB_EASE))
	player.global_position = Vector3(flat.x, at.y, flat.z)
	player.velocity = Vector3.ZERO

	player.hold_rungs(vehicle.global_rotation.y + float(ladder["yaw"]), absf(up) * CLIMB_SPEED)



func climbing(player: Player) -> bool:
	return _climbing.has(player)


func _physics_process(delta: float) -> void :
	_climb(delta)
	_turn_monitors(delta)


func _process(_delta: float) -> void :
	_work_monitor()










func _debug() -> void :
	var args: = OS.get_cmdline_user_args()
	for arg in args:
		if arg.begins_with("--roof=climb"):
			var wanted: = arg.get_slice(":", 1) if arg.contains(":") else "Tanker"
			for ladder: Dictionary in ladders:
				if (ladder["vehicle"] as Vehicle).spec["name"] == wanted:
					_debug_climb(ladder)
		elif arg == "--roof=monitor":
			_debug_monitor(args)
		elif arg == "--roof-trace":
			_debug_trace()


func _debug_climb(ladder: Dictionary) -> void :
	await get_tree().create_timer(2.0).timeout
	var player: = Game.local_player
	var vehicle: Vehicle = ladder["vehicle"]
	player.teleport(vehicle.global_transform * _to(ladder, Vector3(0, -2.6, 2.0)))
	if player.camera != null:
		player.camera.yaw = vehicle.global_rotation.y + float(ladder["yaw"])

	for leg: Array in [[0.0, 3.0], [-1.0, 0.0], [PI, 6.0]]:
		if leg[0] != -1.0:
			if player.camera != null:
				player.camera.yaw = vehicle.global_rotation.y + float(leg[0])
			Input.action_press("move_forward")
		else:
			Input.action_release("move_forward")
			await get_tree().create_timer(1.0).timeout
			continue
		for step in int(float(leg[1]) * 2.0):
			await get_tree().create_timer(0.5).timeout
			var local: = vehicle.global_transform.affine_inverse() * player.global_position
			print("roof climb: at %.1f,%.1f,%.1f (truck space) on the rungs %s floor %s" % [local.x, local.y, local.z, climbing(player), player.is_on_floor()])
		Input.action_release("move_forward")


func _debug_monitor(args: PackedStringArray) -> void :
	await get_tree().create_timer(2.0).timeout
	if monitors.is_empty():
		print("roof monitor: none")
		return
	var monitor: Dictionary = monitors[0]
	var vehicle: Vehicle = monitor["vehicle"]
	var aim: = Vector3(0, 0, -60)
	for arg in args:
		if arg.begins_with("--roof-aim="):
			var n: = arg.substr(11).split_floats(",")
			aim = Vector3(n[0], n[1], n[2])

	vehicle.global_transform = Transform3D(Basis.IDENTITY, Vector3(-21, 3.0 + float(vehicle.data["axleY"]), -14))
	vehicle.reset_physics_interpolation()
	await get_tree().create_timer(1.0).timeout
	var player: = Game.local_player
	player.teleport(vehicle.global_transform * Vector3(0, float(vehicle.data["top"]) + 0.5, -1.5))
	await get_tree().create_timer(0.5).timeout
	take(monitor, player)
	_debug_aim = vehicle.global_transform * aim
	for step in 12:
		await get_tree().create_timer(0.5).timeout
		print("roof monitor: yaw %.0f pitch %.0f spraying %s water %.0f L operator %s" % [rad_to_deg(monitor["yaw"]), rad_to_deg(monitor["pitch"]), monitor["hose"].get("spraying", false), vehicle.water, monitor["operator"] != null])


func _debug_trace() -> void :
	while true:
		await get_tree().create_timer(1.0).timeout
		for monitor: Dictionary in monitors:
			var operator: Variant = monitor["operator"]
			print("roof trace: %s yaw %.0f pitch %.0f water %s spraying %s operator %s" % [(monitor["vehicle"] as Vehicle).name, rad_to_deg(monitor["yaw"]), rad_to_deg(monitor["pitch"]), monitor["water"], monitor["hose"].get("spraying", false), (operator as Player).display_name if operator != null else "-"])
