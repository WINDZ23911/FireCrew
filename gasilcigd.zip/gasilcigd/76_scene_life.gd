extends RefCounted





static func start(main: Node) -> void :
	var police: = ScenePolice.new()
	police.name = "ScenePolice"
	main.add_child(police)
	var crowd: = SceneCrowd.new()
	crowd.name = "SceneCrowd"
	main.add_child(crowd)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--scene-life="):
			var look: = SceneLifeDebug.new()
			look.name = "SceneLifeDebug"
			main.add_child(look)
