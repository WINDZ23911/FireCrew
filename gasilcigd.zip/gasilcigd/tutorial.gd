class_name Tutorial
extends Node

















static var current: Tutorial

var active: = false

var place: Dictionary = {}

var flames: Array = []

var ticked: Array[String] = []
var _seen_first: = false
var _told: = ""
var _clock: = 0.0
var _held: = false
var _success_at: = -1.0

var success: Control
var _start_button: Button


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Onboarding.Tutorial




static func offered() -> bool:
	if Net.active() or FireService.current == null:
		return false
	if OS.get_cmdline_user_args().has("--no-save"):
		return OS.get_cmdline_user_args().has("--tutorial")
	return not PlayerData.first_shift_done




func begin(again: = false) -> void :
	if Net.active() or FireService.current == null or HoseService.current == null:
		return
	var pumper: = Vehicle.named("Fire Truck")
	var player: = Game.local_player
	if pumper == null or player == null:
		return
	if active:
		stop()
	place = _pick_place()
	if place.is_empty():
		push_warning("tutorial: no hydrant and no small fire near the station")
		return
	if FirstShift.current and FirstShift.current.active:
		FirstShift.current.stop()
	active = true
	ticked.clear()
	_seen_first = false
	_told = ""
	_success_at = -1.0
	if CallService.current and not CallService.current.running:
		CallService.current.hold = true
		_held = true
	var riding: Variant = player.get_attr("Vehicle")
	if riding is Vehicle and player.seat != null:
		(riding as Vehicle).leave(player)
	_park(pumper, place["truck"], place["yaw"])
	pumper.set_lockers(false)

	var to_fire: Vector3 = (place["fire"] - place["truck"]) * Vector3(1, 0, 1)
	var stand: Vector3 = place["truck"] - to_fire.normalized() * float(settings()["StandOff"])
	player.teleport(_ground(stand) + Vector3(0, 3, 0))

	player.rig.rotation.y = atan2( - to_fire.x, - to_fire.z)
	if player.camera != null:
		player.camera.yaw = player.rig.rotation.y
	_light()
	var steps: Array = []
	for key: String in settings()["Steps"]:
		steps.append([key, _words(key)])
	if HudChecklist.current:
		HudChecklist.current.show_list(Text.m("onboarding.tutorial.title"), steps)
	Game.notify(Text.m("onboarding.tutorial.welcome"), "good", player)
	print("tutorial: begun%s, the pumper at %s, the fire at %s" % [" again" if again else "", place["truck"], place["fire"]])



func stop() -> void :
	for made: Dictionary in flames:
		FireService.current.end_spot(made)
	flames.clear()
	_release()
	active = false
	if HudChecklist.current:
		HudChecklist.current.close()



static func _words(key: String) -> Dictionary:
	return Text.m("onboarding.tutorial.steps." + key)


static func _hint(key: String) -> Dictionary:
	return Text.m("onboarding.tutorial.hints." + key)


func _process(delta: float) -> void :
	if _success_at > 0.0 and Game.now() >= _success_at:
		_success_at = -1.0
		_show_success()
	if not active:
		return
	_clock += delta
	if _clock < float(settings()["Every"]):
		return
	_clock = 0.0
	var player: = Game.local_player
	if Net.active():
		stop()
		return
	if player == null or HudChecklist.current == null:
		return
	var step: = HudChecklist.current.current_step()
	if step.is_empty():
		_finish()
		return
	if step != _told:
		_told = step
		Game.notify(_hint(step), "", player)
	if _step_done(step, player):
		if HudChecklist.current.tick(step):
			ticked.append(step)
			print("tutorial: ticked %s" % step)



func _step_done(step: String, player: Player) -> bool:
	var pumper: = Vehicle.named("Fire Truck")
	match step:
		"view":
			var first: = player.camera != null and player.camera.wanted_distance < 1.5
			if first:
				_seen_first = true
			return _seen_first and not first
		"shutters":
			return pumper != null and pumper.lockers_open()
		"hydrant":
			return pumper != null and HoseService.current.supplied_by(pumper) == "hydrant"
		"scba":
			return player.get_attr("Scba", false) == true
		"mask":
			return player.get_attr("Mask", false) == true
		"attack":
			return player.get_attr("Line") != null or player.holding == "nozzle"
		"fire":
			for made: Dictionary in flames:
				if made["burning"]:
					return false
			return true
	return false


func _finish() -> void :
	active = false
	flames.clear()
	Sounds.ui("ui_fanfare")
	PlayerData.finish_first_shift()

	_success_at = Game.now() + float(settings()["SuccessDelay"])
	print("tutorial: done")


func _release() -> void :
	if _held and CallService.current:
		CallService.current.hold = false
	_held = false







func _show_success() -> void :
	if Hud.current == null:
		_start_shift()
		return
	success = ColorRect.new()
	(success as ColorRect).color = Color(0, 0, 0, 0.55)
	success.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	success.z_index = 50
	Hud.current.root.add_child(success)
	var centre: = CenterContainer.new()
	centre.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	success.add_child(centre)
	var box: = PanelContainer.new()
	box.custom_minimum_size = Vector2(640, 0)
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(Ui.PANEL.r, Ui.PANEL.g, Ui.PANEL.b, 0.97)
	style.border_color = Ui.GREEN
	style.border_width_top = 5
	style.set_corner_radius_all(6)
	style.corner_radius_top_left = 0
	style.corner_radius_top_right = 0
	style.content_margin_left = 44
	style.content_margin_right = 44
	style.content_margin_top = 36
	style.content_margin_bottom = 36
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.shadow_size = 28
	box.add_theme_stylebox_override("panel", style)
	centre.add_child(box)
	var column: = VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	box.add_child(column)
	var head: = HBoxContainer.new()
	head.add_theme_constant_override("separation", 16)
	column.add_child(head)
	var check: = Ui.icon("check", 52, Ui.state(Ui.GREEN))
	check.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	head.add_child(check)
	head.add_child(Ui.display(Text.say(Text.m("onboarding.tutorial.success.title")), 44))
	var line: = Ui.label(Text.say(Text.m("onboarding.tutorial.success.line")), 19, Ui.DIM)
	line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	line.custom_minimum_size = Vector2(552, 0)
	column.add_child(line)
	var gap: = Control.new()
	gap.custom_minimum_size = Vector2(0, 10)
	column.add_child(gap)
	_start_button = Button.new()
	_start_button.text = Text.say(Text.m("onboarding.tutorial.success.start"))
	_start_button.custom_minimum_size = Vector2(300, 64)
	_start_button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_start_button.add_theme_font_override("font", Ui.display_font())
	_start_button.add_theme_font_size_override("font_size", 28)
	for state: String in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		_start_button.add_theme_color_override(state, Ui.DARK)
	for state: String in ["normal", "hover", "pressed", "focus"]:
		var fill: = StyleBoxFlat.new()
		fill.bg_color = Ui.YELLOW.lightened(0.25) if state in ["hover", "focus"] else Ui.YELLOW
		fill.set_corner_radius_all(6)
		fill.content_margin_left = 18
		fill.content_margin_right = 18
		_start_button.add_theme_stylebox_override(state, fill)
	_start_button.pressed.connect(_start_shift)
	column.add_child(_start_button)
	success.modulate.a = 0.0
	create_tween().tween_property(success, "modulate:a", 1.0, 0.25)
	Game.ui_open = true
	var player: = Game.local_player
	if player != null and player.camera != null:
		player.camera.capture(false)
	_start_button.grab_focus()
	print("tutorial: success shown")




func _start_shift() -> void :
	if success != null and is_instance_valid(success):
		_start_button.disabled = true
		Sounds.ui("ui_click")
	var veil: = ColorRect.new()
	veil.color = Color.BLACK
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	veil.modulate.a = 0.0
	veil.z_index = 60
	var layer: Node = Hud.current.root if Hud.current else self
	layer.add_child(veil)
	var fade: = create_tween()
	fade.tween_property(veil, "modulate:a", 1.0, float(settings()["Fade"]))
	await fade.finished
	if success != null and is_instance_valid(success):
		success.queue_free()
	success = null
	if HudChecklist.current:
		HudChecklist.current.close()
	_back_to_station()
	Game.ui_open = false
	var player: = Game.local_player
	if player != null and player.camera != null:
		player.camera.capture(true)
	_release()
	await get_tree().create_timer(0.3).timeout
	var back: = create_tween()
	back.tween_property(veil, "modulate:a", 0.0, float(settings()["Fade"]) * 1.5)
	await back.finished
	veil.queue_free()
	Game.notify(Text.m("onboarding.tutorial.shift"), "good", Game.local_player)
	print("tutorial: shift started at the station")




func _back_to_station() -> void :
	var player: = Game.local_player
	var pumper: = Vehicle.named("Fire Truck")
	var hoses: = HoseService.current
	if player != null:
		var riding: Variant = player.get_attr("Vehicle")
		if riding is Vehicle and player.seat != null:
			(riding as Vehicle).leave(player)
	if hoses != null and pumper != null:
		for line: Dictionary in hoses.lines.duplicate():
			if line.get("player") != null or line.get("down") != null:
				hoses.disconnect_line(line)
		if player != null:
			if hoses._loose.has(player):
				hoses._drop_loose(player, false)
			if player.get_attr("HoseRoll") != null:
				hoses._return_roll(player)
		for rig: Dictionary in hoses.rigs:
			hoses.stow_supply(rig)
			if rig.has("roll_full"):
				for kind: String in rig["roll_full"]:
					hoses._add_rolls(rig, kind, int(rig["roll_full"][kind]))
	var air: = AirService.current
	if air != null and player != null:
		air.return_worn(player)
		for source: String in air.bars:
			var full: Array = air.bars[source]
			for index in full.size():
				full[index] = float(Config.Air.Capacity)
	if pumper != null:
		pumper.set_lockers(false)
		pumper.water = pumper.capacity
		_park(pumper, (pumper.spec["spawn"] as Transform3D).origin - Vector3(0, float(pumper.spec["spawn"].origin.y), 0), (pumper.spec["spawn"] as Transform3D).basis.get_euler().y)
	if player != null:
		player.teleport(Game.spawn_point())
		player.rig.rotation.y = PI
		if player.camera != null:
			player.camera.yaw = PI








func _pick_place() -> Dictionary:
	var station: Vector3 = Game.station.door_position if Game.station else Vector3.ZERO
	var s: = settings()
	var best: Dictionary = {}
	var best_distance: = INF
	for building: Building in FireService.current.buildings:
		if building.ruined or building.counts_as_save:
			continue
		for entry: Dictionary in building.fuel:
			if not (String(entry.get("name", "")) in s["Things"]):
				continue
			var at: Vector3 = entry["position"]
			var distance: = at.distance_to(station)
			if distance < float(s["From"]) or distance >= best_distance:
				continue
			var hydrant: Variant = _hydrant_near(at, float(s["HydrantReach"]))
			if hydrant == null:
				continue
			var road: = _road_by(hydrant, float(s["RoadReach"]))
			if road.is_empty():
				continue
			var apart: = Vector2(road["at"].x, road["at"].z).distance_to(Vector2(at.x, at.z))
			if apart < float(s["FireClear"]) or apart > float(s["FireReach"]):
				continue
			best = {"fire": at, "hydrant": hydrant, "truck": road["at"], "yaw": road["yaw"]}
			best_distance = distance
	return best



func _hydrant_near(at: Vector3, reach: float) -> Variant:
	var found: Variant = null
	for hydrant: Dictionary in HoseService.current.hydrants:
		var distance: float = (hydrant["position"] as Vector3).distance_to(at)
		if distance < reach:
			reach = distance
			found = hydrant["position"]
	return found




func _road_by(at: Vector3, reach: float) -> Dictionary:
	var graph: = NavGraph.current
	if graph == null or not graph.layout.has("roads"):
		return {}
	var point: = Vector2(at.x, at.z)
	var best: = reach
	var found: Dictionary = {}
	for road: Dictionary in graph.layout["roads"]:
		var points: Array = road.get("points", [])
		for index in range(points.size() - 1):
			var a: = Vector2(float(points[index][0]), float(points[index][1]))
			var b: = Vector2(float(points[index + 1][0]), float(points[index + 1][1]))
			if a.distance_to(b) < 1.0:
				continue
			var near: = Geometry2D.get_closest_point_to_segment(point, a, b)
			var distance: = point.distance_to(near)
			if distance < best:
				best = distance
				var along: = (b - a).normalized()
				var lane: = (point - near).normalized() * minf(float(settings()["Lane"]), distance) if distance > 0.1 else Vector2.ZERO
				var spot: = near + lane - along * float(settings()["Back"])
				found = {"at": _ground(Vector3(spot.x, at.y, spot.y)), "yaw": atan2( - along.x, - along.y)}
	return found


func _light() -> void :
	var fire: Vector3 = place["fire"]
	var ground: = _ground(fire)
	for offset: Array in settings()["Flames"]:
		var at: = Vector3(fire.x + float(offset[0]), maxf(ground.y + 0.6, fire.y), fire.z + float(offset[1]))
		flames.append(FireService.current.spot(at))


static func _ground(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(Vector3(at.x, at.y + 40.0, at.z), Vector3(at.x, at.y - 80.0, at.z), World.LAYER_SOLID)
	return hit["position"] if not hit.is_empty() else at



static func _park(vehicle: Vehicle, at: Vector3, yaw: float) -> void :
	vehicle.global_transform = Transform3D(Basis(Vector3.UP, yaw), at + Vector3(0, float(vehicle.spec["spawn"].origin.y), 0))
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.angular_velocity = Vector3.ZERO
	vehicle.reset_physics_interpolation()
