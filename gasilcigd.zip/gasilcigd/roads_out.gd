class_name RoadsOut
extends RefCounted














const PATH: = "res://data/godot/RoadsOut.json"
const RING: = "Obvoznica"
const NEW_STREET: = "Breg revolucije"
const SIGN_CLEAR: = 40.0
const ASPHALT: = Color8(58, 58, 62)
const BEYOND: = 360.0



static var gone: Array = []
static var laid: Array = []
static var unjoined: Array[Vector2] = []
static var edges: Array = []


static func extend_layout(layout: Dictionary) -> void :
	if layout.get("roads_out", false) or Edition.skips("roads_out"):
		return
	layout["roads_out"] = true
	var plan: Variant = Rbx.load_json(PATH)
	if not plan is Dictionary:
		push_warning("roads out: no %s; the ring road stays" % PATH)
		return
	gone.clear()
	laid.clear()
	unjoined.clear()
	edges.clear()
	var nodes: Array = layout["nodes"]
	var roads: Array = layout["roads"]
	var going: Array = []
	for pair: Array in plan["going"]:
		going.append(Vector2i(int(pair[0]), int(pair[1])))
	var touched: = {}

	var kept: Array = []
	for road: Dictionary in roads:
		if str(road.get("name", "")) != RING:
			kept.append(road)
			continue
		var ends: = Vector2i(int(road["from"]), int(road["to"]))
		if going.has(ends) or going.has(Vector2i(ends.y, ends.x)):
			gone.append([_line(road["points"]), float(road["width"])])
			touched[ends.x] = true
			touched[ends.y] = true
			continue
		road.erase("name")
		kept.append(road)
	roads.assign(kept)

	var cut: Dictionary = plan["cut"]
	var cut_at: = Vector2(float(cut["at"][0]), float(cut["at"][1]))
	for road: Dictionary in roads:
		if int(road["from"]) == int(cut["from"]) and int(road["to"]) == int(cut["to"]):
			var points: Array = road["points"]
			var keep: = 0
			for index in points.size():
				if Vector2(points[index][0], points[index][1]).distance_to(cut_at) < 1.0:
					keep = index
			if keep == 0:
				push_warning("roads out: the south side's cut is not where it was")
				break
			var rest: Array = points.slice(keep)
			gone.append([_line(rest), float(road["width"])])
			road["points"] = points.slice(0, keep + 1)
			nodes.append({"arms": 1, "kind": "end", "x": cut_at.x, "z": cut_at.y})
			touched[int(road["to"])] = true
			road["to"] = nodes.size()

	var by_way: = {}
	for carry: Dictionary in plan["roads"]:
		var start: = int(carry["node"])
		var old: = _road_ending(roads, start)
		if old.is_empty():
			push_warning("roads out: no road ends at node %d" % start)
			continue
		var points: Array = carry["points"]
		var last: = Vector2(points[-1][0], points[-1][1])
		var end_kind: = "end"
		if str(carry["end"]) == "edge":
			var before: = Vector2(points[-2][0], points[-2][1])
			edges.append([last, (last - before).normalized()])
		nodes.append({"arms": 1, "kind": end_kind, "x": last.x, "z": last.y})
		var road: = {
			"class": old["class"], "rank": old["rank"], "width": old["width"], "from": start, "to": nodes.size(), 
			"points": points.duplicate(true), 
		}
		if carry.get("name") != null:
			road["name"] = carry["name"]
		roads.append(road)
		laid.append(road)
		by_way[int(carry["way"])] = road

	for carry: Dictionary in plan["roads"]:
		if carry.get("joins") == null or not by_way.has(int(carry["way"])) or not by_way.has(int(carry["joins"])):
			continue
		var road: Dictionary = by_way[int(carry["way"])]
		var other: Dictionary = by_way[int(carry["joins"])]
		var at: = Vector2(road["points"][-1][0], road["points"][-1][1])
		var split: = _split(other, at)
		if split.is_empty():
			continue
		var meet: = int(road["to"])
		var tail: = {
			"class": other["class"], "rank": other["rank"], "width": other["width"], "from": meet, "to": int(other["to"]), 
			"points": split[1], 
		}
		if other.has("name"):
			tail["name"] = other["name"]
		other["points"] = split[0]
		other["to"] = meet
		road["points"][-1] = split[0][-1]
		nodes[meet - 1]["x"] = float(split[0][-1][0])
		nodes[meet - 1]["z"] = float(split[0][-1][1])
		roads.append(tail)
		laid.append(tail)
		touched[meet] = true

	var crossed: = true
	while crossed:
		crossed = false
		for first: Dictionary in laid:
			for second: Dictionary in laid:
				if first == second or crossed:
					continue
				var hit: Variant = _crossing(first["points"], second["points"])
				if hit == null:
					continue
				nodes.append({"arms": 4, "kind": "junction", "control": "give_way", "x": hit.x, "z": hit.y})
				var meet: = nodes.size()
				for road: Dictionary in [first, second]:
					var split: = _split(road, hit)
					var tail: = {
						"class": road["class"], "rank": road["rank"], "width": road["width"], "from": meet, "to": int(road["to"]), 
						"points": split[1], 
					}
					if road.has("name"):
						tail["name"] = road["name"]
					road["points"] = split[0]
					road["to"] = meet
					roads.append(tail)
					laid.append(tail)
				touched[meet] = true
				crossed = true

	var arms: = {}
	for road: Dictionary in roads:
		for end: String in ["from", "to"]:
			arms[int(road[end])] = int(arms.get(int(road[end]), 0)) + 1
	for road: Dictionary in laid:
		touched[int(road["from"])] = true
		touched[int(road["to"])] = true
	for number: int in touched:
		var node: Dictionary = nodes[number - 1]
		var count: = int(arms.get(number, 0))
		var was_junction: bool = node.get("kind") == "junction"
		node["arms"] = count
		if count >= 3:
			node["kind"] = "junction"
			if not node.has("control"):
				node["control"] = "give_way"
		else:
			node.erase("control")
			node["kind"] = "bend" if count == 2 else "end"
			if was_junction:
				unjoined.append(Vector2(node["x"], node["z"]))

	var signs: Array = []
	for sign: Dictionary in layout.get("signs", []):
		if not _near_any(unjoined, Vector2(sign["x"], sign["z"]), SIGN_CLEAR):
			signs.append(sign)
	layout["signs"] = signs

	for building: Dictionary in layout["buildings"]:
		if str(building.get("street", "")) == RING:
			building["street"] = NEW_STREET


static func _line(points: Array) -> PackedVector2Array:
	var line: = PackedVector2Array()
	for point: Array in points:
		line.append(Vector2(point[0], point[1]))
	return line


static func _road_ending(roads: Array, node: int) -> Dictionary:
	for road: Dictionary in roads:
		if int(road["from"]) == node or int(road["to"]) == node:
			return road
	return {}



static func _split(road: Dictionary, at: Vector2) -> Array:
	var points: Array = road["points"]
	var best: = INF
	var best_index: = -1
	var best_point: = Vector2.ZERO
	for index in points.size() - 1:
		var a: = Vector2(points[index][0], points[index][1])
		var b: = Vector2(points[index + 1][0], points[index + 1][1])
		var near: = Geometry2D.get_closest_point_to_segment(at, a, b)
		if near.distance_to(at) < best:
			best = near.distance_to(at)
			best_index = index
			best_point = near
	if best_index < 0 or best > 20.0:
		return []
	var first: Array = points.slice(0, best_index + 1)
	var second: Array = points.slice(best_index + 1)
	if Vector2(first[-1][0], first[-1][1]).distance_to(best_point) > 0.5:
		first.append([best_point.x, best_point.y])
	if Vector2(second[0][0], second[0][1]).distance_to(best_point) > 0.5:
		second.push_front([best_point.x, best_point.y])
	if first.size() < 2 or second.size() < 2:
		return []
	return [first, second]



static func _crossing(a: Array, b: Array) -> Variant:
	for i in a.size() - 1:
		for j in b.size() - 1:
			var p1: = Vector2(a[i][0], a[i][1])
			var p2: = Vector2(a[i + 1][0], a[i + 1][1])
			var q1: = Vector2(b[j][0], b[j][1])
			var q2: = Vector2(b[j + 1][0], b[j + 1][1])
			var hit: Variant = Geometry2D.segment_intersects_segment(p1, p2, q1, q2)
			if hit == null:
				continue
			var spot: Vector2 = hit
			var ends: = [Vector2(a[0][0], a[0][1]), Vector2(a[-1][0], a[-1][1]), Vector2(b[0][0], b[0][1]), Vector2(b[-1][0], b[-1][1])]
			var near_end: = false
			for end: Vector2 in ends:
				if end.distance_to(spot) < 6.0:
					near_end = true
			if not near_end:
				return spot
	return null


static func _near_any(spots: Array[Vector2], at: Vector2, within: float) -> bool:
	for spot in spots:
		if spot.distance_to(at) < within:
			return true
	return false


static func _near_line(line: PackedVector2Array, at: Vector2) -> float:
	var best: = INF
	for index in line.size() - 1:
		best = minf(best, at.distance_to(Geometry2D.get_closest_point_to_segment(at, line[index], line[index + 1])))
	return best







static func build(kit: PolishKit) -> String:
	_way_of_parent.clear()
	var layout: = kit.layout()
	if gone.is_empty():
		return ""
	var store: = kit.store
	var kept_lines: Array = []
	for road: Dictionary in layout["roads"]:
		var line: = _line(road["points"])
		var bounds: = Rect2(line[0], Vector2.ZERO)
		for point in line:
			bounds = bounds.expand(point)
		kept_lines.append([line, float(road["width"]), bounds.grow(float(road["width"]) / 2.0 + 2.0)])
	var hidden: = 0
	for row in kit.rows_under("Map/Surfaces"):
		if not store.name_at(row) in ["road", "paint", "drain", "manhole", "tar", "lane"]:
			continue
		var at: = store.position(row)
		var flat: = Vector2(at.x, at.z)
		var on_gone: = false
		for line: Array in gone:
			if _near_line(line[0], flat) < float(line[1]) / 2.0 + 6.0:
				on_gone = true
				break
		if not on_gone:
			continue
		var on_kept: = false
		for line: Array in kept_lines:
			if (line[2] as Rect2).has_point(flat) and _near_line(line[0], flat) < float(line[1]) / 2.0 + 1.0:
				on_kept = true
				break

		if on_kept and not (store.name_at(row) == "paint" and _across(store, row, kept_lines) and _near_any(unjoined, flat, SIGN_CLEAR)):
			continue
		_hide(store, row)
		hidden += 1
	var signs: = 0
	var sign_folder: = kit.folder("Map/Signs")
	if sign_folder >= 0:
		for row in kit.rows_under("Map/Signs"):
			var at: = store.position(row)
			if _near_any(unjoined, Vector2(at.x, at.z), SIGN_CLEAR):
				_hide(store, row)
				signs += 1
	var parent: = kit.own_folder("RoadsOut")
	var made: = store.count
	var cleared: = 0
	for road: Dictionary in laid:
		cleared += lay(kit, parent, road)
	for edge: Array in edges:
		var from: Vector2 = edge[0]
		var way: Vector2 = edge[1]
		var to: = from + way * BEYOND
		var middle: = (from + to) / 2.0
		var basis: = Basis.looking_at(Vector3(way.x, 0, way.y), Vector3.UP)
		kit.box(parent, Transform3D(basis, Vector3(middle.x, -0.02, middle.y)), Vector3(22.0, 0.4, BEYOND), ASPHALT, "Asphalt", "RoadOut", PolishKit.LOOK | PartStore.QUERY)


	for row in kit.rows_under("Map/Backdrop"):
		if store.name_at(row) == "RoadOut":
			store.set_flags(row, store.flags(row) | PartStore.QUERY)
	var barriers: = _barriers(kit, parent, layout)

	var crossings: = 0
	var crossed: Array[Vector2] = []
	if IndustryZone.places.has("crossing"):
		var main: Vector3 = IndustryZone.places["crossing"]
		crossed.append(Vector2(main.x, main.z))
	for road: Array in _road_lines(kit, layout):
		var line: PackedVector2Array = road[0]
		for index in line.size() - 1:
			var a: = line[index]
			var b: = line[index + 1]
			if (a.y - Train.LINE_Z) * (b.y - Train.LINE_Z) >= 0.0:
				continue
			var at: = a + (b - a) * ((Train.LINE_Z - a.y) / (b.y - a.y))
			if at.x < Train.FROM_X or at.x > Train.TO_X or _near_any(crossed, at, 40.0):
				continue
			crossed.append(at)
			var along: = Vector3(b.x - a.x, 0, b.y - a.y).normalized()
			IndustryZone.level_crossing(kit, parent, Vector3(at.x, 0, Train.LINE_Z), along * signf(along.z), float(road[1]))
			crossings += 1
	return "roads out: the ring's sides gone (%d pieces and %d of signs hidden), %d lanes laid (%d parts, %d things cleared from their way), %d run on out, %d level crossings, %d barriers at the edge" % [
		hidden, signs, laid.size(), store.count - made, cleared, edges.size(), crossings, barriers]




static func _road_lines(kit: PolishKit, layout: Dictionary) -> Array:
	var lines: Array = []
	for road: Dictionary in layout["roads"]:
		lines.append([_line(road["points"]), float(road["width"])])
	var store: = kit.store
	for row in kit.rows_under("Map/Backdrop"):
		if store.name_at(row) != "RoadOut":
			continue
		var place: = store.transform(row)
		var half: = place.basis.z.normalized() * store.size(row).z / 2.0
		lines.append([PackedVector2Array([Vector2(place.origin.x - half.x, place.origin.z - half.z), Vector2(place.origin.x + half.x, place.origin.z + half.z)]), store.size(row).x])
	return lines




static func _barriers(kit: PolishKit, parent: int, layout: Dictionary) -> int:
	var store: = kit.store
	var walls: Array = []
	for row in kit.rows_under("Map"):
		if store.name_at(row) == "Edge":
			walls.append([store.position(row), store.size(row)])
	if walls.size() < 4:
		return 0
	var centre: = Vector2.ZERO
	for wall: Array in walls:
		centre += Vector2(wall[0].x, wall[0].z) / walls.size()
	var low: = Vector2( - INF, - INF)
	var high: = Vector2(INF, INF)
	for wall: Array in walls:
		var at: Vector3 = wall[0]
		var size: Vector3 = wall[1]
		if size.x < size.z:
			if at.x < centre.x:
				low.x = maxf(low.x, at.x + size.x / 2.0)
			else:
				high.x = minf(high.x, at.x - size.x / 2.0)
		elif at.z < centre.y:
			low.y = maxf(low.y, at.z + size.z / 2.0)
		else:
			high.y = minf(high.y, at.z - size.z / 2.0)
	var inside: = Rect2(low, high - low)
	var placed: Array[Vector2] = []
	for road: Array in _road_lines(kit, layout):
		var line: PackedVector2Array = road[0]
		for index in line.size() - 1:
			for pair: Array in [[line[index], line[index + 1]], [line[index + 1], line[index]]]:
				var a: Vector2 = pair[0]
				var b: Vector2 = pair[1]
				var way: = (b - a).normalized()
				if a.distance_to(b) < 0.1 or not inside.grow(-6.0).has_point(a):
					continue

				var reach: = INF
				for axis in 2:
					if absf(way[axis]) > 0.01:
						var wall: = high[axis] if way[axis] > 0.0 else low[axis]
						reach = minf(reach, (wall - a[axis]) / way[axis])
				if reach > a.distance_to(b) + 4.0:
					continue
				var at: = a + way * (reach - 1.5)
				if _near_any(placed, at, 30.0):
					continue
				placed.append(at)
				barrier(kit, parent, at, way, float(road[1]))
	return placed.size()




static func barrier(kit: PolishKit, parent: int, at: Vector2, way: Vector2, width: float) -> void :
	var basis: = Basis.looking_at(Vector3(way.x, 0, way.y), Vector3.UP)
	var across: = basis.x
	var foot: = Vector3(at.x, 0, at.y)
	var board: = width - 2.0
	for side: float in [-1.0, 1.0]:
		kit.post(parent, foot + across * side * (board / 2.0), 3.4, 0.3, Color8(230, 230, 226), "Metal", "BarrierPost")
	var pieces: = 8
	for index in pieces:
		var offset: = - board / 2.0 + board * (index + 0.5) / pieces
		var colour: = Color8(200, 30, 30) if index % 2 == 0 else Color8(240, 240, 236)
		kit.box(parent, Transform3D(basis, foot + across * offset + Vector3(0, 2.6, 0)), Vector3(board / pieces, 0.9, 0.15), colour, "SmoothPlastic", "Barrier")



static func _across(store: PartStore, row: int, lines: Array) -> bool:
	var at: = store.position(row)
	var flat: = Vector2(at.x, at.z)
	var size: = store.size(row)
	var basis: = store.basis(row)
	var long: = basis.x if size.x > size.z else basis.z
	var best: = INF
	var way: = Vector2.ZERO
	for line: Array in lines:
		if line.size() > 2 and not (line[2] as Rect2).grow(20.0).has_point(flat):
			continue
		var points: PackedVector2Array = line[0]
		for index in points.size() - 1:
			var away: = flat.distance_to(Geometry2D.get_closest_point_to_segment(flat, points[index], points[index + 1]))
			if away < best:
				best = away
				way = (points[index + 1] - points[index]).normalized()
	return absf(Vector2(long.x, long.z).normalized().dot(way)) < 0.8


static func _hide(store: PartStore, row: int) -> void :
	store.set_transparency(row, 1.0)
	store.set_flags(row, 0)




static func lay(kit: PolishKit, parent: int, road: Dictionary, color: = ASPHALT, material: = "Asphalt") -> int:
	var store: = kit.store
	var width: = float(road["width"])
	var line: = _line(road["points"])
	for index in line.size() - 1:
		var a: = line[index]
		var b: = line[index + 1]
		var way: = (b - a).normalized()
		var middle: = (a + b) / 2.0
		var basis: = Basis.looking_at(Vector3(way.x, 0, way.y), Vector3.UP)
		kit.box(parent, Transform3D(basis, Vector3(middle.x, -0.01, middle.y)), Vector3(width, 0.4, a.distance_to(b)), color, material, "road", PolishKit.SOLID)


	for index in line.size():
		var at: = line[index]
		if index > 0 and index < line.size() - 1:
			var turn: = (line[index] - line[index - 1]).normalized().dot((line[index + 1] - line[index]).normalized())
			if turn > 0.985:
				continue
		var disc: = Transform3D(Basis(Vector3.BACK, PI / 2), Vector3(at.x, -0.015, at.y))
		store.add(PartStore.Shape.CYLINDER, disc, Vector3(0.4, width, width), color, material, "road", parent, PolishKit.SOLID)


	var spots: = {}
	for spot: Array in PolishKit.along_road(road["points"], 4.0):
		var on_road: Vector3 = spot[0]
		var way: Vector3 = spot[1]
		var across: = Vector3( - way.z, 0, way.x)
		for offset: float in [ - width / 2.0, - width / 4.0, 0.0, width / 4.0, width / 2.0]:
			var at: = on_road + across * offset
			var square: = Vector2i(floori(at.x / PolishKit.CELL), floori(at.z / PolishKit.CELL))
			if not spots.has(square):
				spots[square] = []
			spots[square].append(at)
	kit._build_grid()
	var cleared: = {}
	for square: Vector2i in spots:
		for row: int in kit._grid.get(square, PackedInt32Array()):
			if cleared.has(row) or store.parent(row) == parent or store.name_at(row) == "Ground":
				continue
			if kit._top(row) <= 0.5 or not _in_the_way(kit, row):
				continue
			for at: Vector3 in spots[square]:
				if kit._covers(row, at):
					cleared[row] = true
					_hide(store, row)
					break
	return cleared.size()


static var _way_of_parent: Dictionary = {}


static func _in_the_way(kit: PolishKit, row: int) -> bool:
	var store: = kit.store
	if store.name_at(row) == "Edge":
		return false
	var parent: = store.parent(row)
	if not _way_of_parent.has(parent):
		_way_of_parent[parent] = _clearable(store, parent)
	return _way_of_parent[parent]


static func _clearable(store: PartStore, parent: int) -> bool:
	var top: = parent
	var path: = ""
	while top > 0:
		path = str(store.nodes[top]["n"]) + "/" + path
		top = int(store.nodes[top].get("p", 0))
	if path.begins_with("Map/Surfaces") or path.begins_with("Map/Backdrop") or path.begins_with("Map/Polish/RoadsOut"):
		return false
	return path.begins_with("Map/")
