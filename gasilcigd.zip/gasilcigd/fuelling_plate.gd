class_name FuellingPlate
extends Control




const WIDTH: = 360.0
const HEIGHT: = 74.0

var _plate: Control
var _name: Label
var _title: Label
var _tank: Control
var _litres: Label
var _capacity: Label
var _filled: Label
var _paid: Label
var _clock: = 1.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEIGHT))
	_plate.visible = false
	add_child(_plate)
	var tile: = Ui.tile("pump", Ui.AMBER, 40)
	tile.position = Vector2(10, 8)
	_plate.add_child(tile)

	_name = Ui.caps("", 13)
	_name.position = Vector2(60, 4)
	_plate.add_child(_name)
	_title = Ui.label("", 13, Ui.AMBER)
	_plate.add_child(_title)
	_tank = Ui.bar(Vector2(186, 18), Ui.YELLOW)
	_tank.position = Vector2(60, 26)
	_plate.add_child(_tank)
	_capacity = Ui.label("", 15, Ui.DIM)
	_capacity.size = Vector2(70, 36)
	_capacity.position = Vector2(WIDTH - 12 - 70, 16)
	_capacity.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_capacity)
	_litres = Ui.display("", 28)
	_litres.size = Vector2(60, 36)
	_litres.position = Vector2(WIDTH - 12 - 70 - 60, 6)
	_litres.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_litres)
	_filled = Ui.label("", 13, Ui.TEXT)
	_filled.position = Vector2(60, 50)
	_plate.add_child(_filled)
	_paid = Ui.label("", 13, Ui.TEXT)
	_paid.size = Vector2(100, 16)
	_paid.position = Vector2(WIDTH - 12 - 100, 50)
	_paid.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_paid)



func _vehicle() -> Vehicle:
	var player: = Game.local_player
	if player == null:
		return null
	var paying: Variant = player.get_attr("FuelVehicle")
	if paying is Vehicle and is_instance_valid(paying):
		return paying
	var sat_in: Variant = player.get_attr("Vehicle")
	if sat_in is Vehicle and is_instance_valid(sat_in) and FuelService.filling(sat_in) != null:
		return sat_in
	return null


func _process(delta: float) -> void :
	_clock += delta
	if _clock < 0.2:
		return
	_clock = 0.0
	var vehicle: = _vehicle()
	_plate.visible = vehicle != null
	if vehicle == null:
		return
	_plate.position = Vector2((size.x - WIDTH) / 2.0, size.y * 0.78 - HEIGHT)
	var fill: Variant = FuelService.filling(vehicle)
	Ui.set_bar(_tank, vehicle.fuel / maxf(vehicle.fuel_capacity, 1.0))
	_litres.text = str(int(vehicle.fuel))
	_capacity.text = "/ %d L" % int(vehicle.fuel_capacity)
	_name.text = Text.say(Text.upper(Text.named("vehicles", vehicle.spec["name"])))
	_title.text = "◂ " + Text.say(Text.m("hud.fuelling.title"))
	_title.position = Vector2(60 + _name.get_minimum_size().x + 12, 4)
	_filled.text = Text.say(Text.f("hud.fuelling.filled", [int(floorf(fill["litres"])) if fill != null else 0]))
	_paid.text = Text.say(Text.f("hud.fuelling.paid", [int(fill["paid"]) if fill != null else 0]))
