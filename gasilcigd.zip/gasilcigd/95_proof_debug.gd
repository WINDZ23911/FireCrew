extends RefCounted




const MORE: = "res://scripts/debug/proofs"


static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if not arg.begins_with("--scenario="):
			continue
		var method: = "_scenario_" + arg.substr(11)
		var scripts: Array = [ProofDebug]
		for file in DirAccess.get_files_at(MORE):
			if file.ends_with(".gd"):
				scripts.append(load(MORE + "/" + file))
		for script: Variant in scripts:
			var debug: ProofDebug = script.new()
			if debug.has_method(method):
				debug.name = "ProofDebug"
				debug.proof_name = arg.substr(11)
				main.add_child(debug)
				debug.call_deferred(method)
				return
			debug.free()
