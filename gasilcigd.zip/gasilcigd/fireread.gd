extends ProofDebug





















func _burning(prefix: = "Family house") -> House:
	var fire: = FireService.current
	var house: = _house(prefix)
	VictimService.current.forced = 0
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	fire.run_incident(house)
	await _wait(0.5)
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	return house



func _floor_at(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(at, at - Vector3(0, 30, 0), World.LAYER_SOLID)
	return (hit["position"] if not hit.is_empty() else at) + Vector3(0, 0.3, 0)



func _in_room(house: House, room: Dictionary) -> Vector3:
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	return _floor_at(house.lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0))



func _hold_smoke(house: House, room_name: String, level: float, seconds: float) -> void :
	var left: = seconds
	while left > 0.0:
		FireService.current.incident["rooms"][room_name]["smoke"] = level
		house.show_smoke(room_name, level)
		await get_tree().process_frame
		left -= get_process_delta_time()


func _nodes() -> Array:
	return FireService.current.incident["group"]["nodes"]



func _quiet_all() -> void :
	var fire: = FireService.current
	for node: Dictionary in _nodes():
		if node["burning"]:
			fire._douse(node)
		node["heat"] = 0.0
		node["wet_until"] = 0.0



func _pane_and_node(house: House) -> Array:
	var best: Array = []
	var best_score: = INF
	for room_name: String in house.rooms:
		var room: Dictionary = house.rooms[room_name]
		if int(room["floor"]) != 0 or room.get("open", false):
			continue
		for pane: Dictionary in room["panes"]:
			for node: Dictionary in _nodes():
				if node["room"] != room_name or String(node["name"]).ends_with("door") or String(node["name"]).ends_with("floor"):
					continue
				var away: float = node["position"].distance_to(pane["position"])
				if away >= 3.0 and away <= 9.0 and absf(away - 5.0) < best_score:
					best_score = absf(away - 5.0)
					best = [pane, node]
	return best



func _out_of(house: House, pane: Dictionary) -> Vector3:
	var size: Vector3 = pane["size"]
	var basis: Basis = (pane["node"] as Node3D).global_basis
	var normal: = basis.z if size.z <= size.x and size.z <= size.y else (basis.x if size.x <= size.y else basis.y)
	normal = Vector3(normal.x, 0, normal.z).normalized()
	if normal.dot(pane["position"] - house.position) < 0.0:
		normal = - normal
	return normal




func _wall_shot(house: House, pane: Dictionary, node: Dictionary, out: Vector3) -> Array:
	var across: = out.cross(Vector3.UP).normalized()
	var at: Vector3 = node["position"]
	for side: float in [3.0, -3.0, 4.5, -4.5, 6.0, -6.0, 1.5, -1.5]:
		var from: = at + out * 16.0 + across * side * 0.5
		var hit: = Game.world.raycast(from, at, World.LAYER_QUERY)
		if hit.is_empty():
			continue
		var row: = Game.world.row_hit(hit)
		if row >= 0 and house._barriers.has(Game.store.id_at(row)) and Game.store.id_at(row) != int(pane["id"]):
			return [from, hit["position"]]
	return []


func _scenario_walls() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var found: = _pane_and_node(house)
	if not _check( not found.is_empty(), "a ground-floor room has a pane with something to burn a few studs in"):
		await _done()
		return
	var pane: Dictionary = found[0]
	var node: Dictionary = found[1]
	_quiet_all()
	fire._ignite(node, 0.6)
	var out: = _out_of(house, pane)
	print("walls: %s in the %s, %.1f studs in from a pane; %d barrier parts in the house" % [node["name"], node["room"], node["position"].distance_to(pane["position"]), house._barriers.size()])
	var shot: = _wall_shot(house, pane, node, out)
	if not _check( not shot.is_empty(), "there is outside wall beside the pane to aim at"):
		await _done()
		return

	var path: = PackedVector3Array([shot[0], shot[1]])
	print("walls: the jet lands on the wall %.1f studs from the %s" % [(shot[1] as Vector3).distance_to(node["position"]), node["name"]])
	var before: float = node["damage"]
	var result: = fire.spray(player, path, 0.5)
	print("walls: on the wall: hits %d, damage %.1f -> %.1f" % [result["hits"], before, node["damage"]])
	_check(result["hits"] == 0 and is_equal_approx(float(node["damage"]), before), "water on the outside wall does not reach the flame behind it")

	result = fire.spray(player, path, 0.5, float(Config.Hose.Fog.Radius))
	_check(result["hits"] == 0, "nor does fog on the wall")

	var through: = PackedVector3Array([pane["position"] + out * 14.0, pane["position"] + out * 0.3])
	result = fire.spray(player, through, 0.5)
	_check(result["hits"] == 0, "water on a whole pane does not reach inside")
	_view(pane["position"] + out * 18.0 + out.cross(Vector3.UP) * 6.0 + Vector3(0, 4, 0), pane["position"])
	await _snap("wall")

	pane["shatter"].call( - out)
	await _wait(0.2)
	through = PackedVector3Array([pane["position"] + out * 14.0, pane["position"], node["position"]])
	result = fire.spray(player, through, 0.5)
	print("walls: in through the broken pane: hits %d, damage %.1f" % [result["hits"], node["damage"]])
	_check(result["hits"] >= 1 and float(node["damage"]) > before, "through a broken pane the water reaches the flame")

	var inside: Vector3 = node["position"] - out * 5.0 + Vector3(0, 1, 0)
	before = node["damage"]
	result = fire.spray(player, PackedVector3Array([inside, node["position"]]), 0.5)
	_check(result["hits"] >= 1 and float(node["damage"]) > before, "from inside the room the water reaches the flame")


	var mind: Crewman = CrewService.current.members[0] if CrewService.current and not CrewService.current.members.is_empty() else null
	if mind != null:
		var spot: = CrewWater.spot_for(mind, node["position"], mind.body.global_position)
		print("walls: the crew's spot for the %s: %s" % [node["name"], spot])
		_check(spot != Vector3.INF, "the crew finds somewhere to put water on it from")
	await _done()


func _scenario_tic() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var found: = _pane_and_node(house)
	if not _check( not found.is_empty(), "a ground-floor room has a pane with something to burn a few studs in"):
		await _done()
		return
	var pane: Dictionary = found[0]
	var node: Dictionary = found[1]
	_quiet_all()
	fire._ignite(node, 0.8)
	var out: = _out_of(house, pane)
	var across: = out.cross(Vector3.UP).normalized()
	await _wait(0.5)
	_take_tool("Thermal camera")
	await _wait(0.3)
	var thermal: Thermal = Hud.current.widgets["thermal"]

	var shot: = _wall_shot(house, pane, node, out)
	var eye: Vector3 = shot[0] if not shot.is_empty() else pane["position"] + out * 16.0 + across * 3.0
	_view(eye, node["position"])
	await _wait(0.4)
	var seen: = _flames_seen(thermal)
	print("tic: from the lawn behind the wall: %d spots; range %s" % [seen, Config.Tools.ThermalRange])
	_check(Thermal.hidden_from(eye, node["position"]), "the flame is hidden by the wall")
	_check(seen >= 1, "the camera sees the flame through the wall")
	await _snap("wall")

	_check( not Thermal.hidden_from(eye, eye + Vector3(0, 0, 1)), "open air hides nothing")

	pane["shatter"].call( - out)
	await _wait(0.2)

	var window_eye: Vector3 = node["position"] + (pane["position"] - node["position"]).normalized() * (node["position"].distance_to(pane["position"]) + 10.0)
	_view(window_eye, node["position"])
	await _wait(0.4)
	seen = _flames_seen(thermal)
	var blocked: = Game.world.raycast(window_eye, node["position"], World.LAYER_QUERY)
	print("tic: through the broken pane: %d spots (hidden %s; the ray stops at %s, %s, %.1f studs short)" % [seen, Thermal.hidden_from(window_eye, node["position"]), Game.world.name_hit(blocked), blocked.get("collider"), blocked["position"].distance_to(node["position"]) if not blocked.is_empty() else 0.0])
	_check(seen >= 1, "through a broken window the camera sees the flame")
	await _snap("window")

	var room: Dictionary = house.rooms[node["room"]]
	fire.incident["rooms"][node["room"]]["smoke"] = 1.0
	house.show_smoke(node["room"], 1.0)
	await _wait(0.3)
	var layer: MeshInstance3D = room.get("layer")
	print("tic: the room's smoke layer drawn with the camera up: %s" % (layer.visible if layer != null else false))
	_check(layer == null or not layer.visible, "the camera sees through the smoke: the layer is not drawn")
	player.teleport(_floor_at(node["position"] - out * 5.0 + Vector3(0, 2, 0)))
	_view(node["position"] - out * 9.0 + Vector3(0, 5, 0), node["position"])
	await _wait(0.4)
	await _snap("inside")

	_take_tool("Axe")
	await _wait(0.4)
	_check(layer != null and layer.visible, "with the camera down the smoke is drawn again")

	var warm: Dictionary = {}
	for link: Dictionary in node["links"]:
		if not link["node"]["burning"] and link["node"]["room"] == node["room"] and link["node"]["fuel"] > 0.0:
			warm = link["node"]
			break
	if not warm.is_empty():
		warm["heat"] = 0.8
		fire._publish()
		await _wait(0.3)
		_check(fire._warm_shown.size() >= 1, "something heating to catch is shown smoking")
		var puff: Warming = fire._warm_shown.values()[0]
		var look: Dictionary = Config.Fire.Warming
		print("tic: warming at heat %.2f: crackle %.1f dB" % [puff.heat, puff._crackle.volume_db])
		_check(puff._crackle != null, "it crackles")
		_check(Rbx.rgb(look["Puff"]).r > Rbx.rgb(look["Puff"]).b + 0.1, "its smoke is yellow-brown, not grey")
	await _done()



func _flames_seen(thermal: Thermal) -> int:
	thermal._next_look = 0.0
	thermal._process(0.0)
	var count: = 0
	for each: Array in thermal._seen:
		if not each[3] and (each[2] as Color).g > 0.6:
			count += 1
	return count


func _scenario_flowpath() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var flow: Dictionary = fire.settings()["Flow"]

	for door_name: String in house.doors:
		var door: Dictionary = house.doors[door_name]
		if door["outside"] and door["open"]:
			house._swing(door, false, false)
	await _wait(0.8)
	var ways: = fire._air_ways(house)
	var none: = true
	for room_name: String in ways:
		none = none and int(ways[room_name]) == 0
	print("flowpath: shut up, ways out by room: %s" % ways)
	_check(none, "a shut-up house has no way out for the air")

	var hall: = "Hall"
	var target: Dictionary = {}
	for node: Dictionary in _nodes():
		if node["room"] == "Living room" and not String(node["name"]).ends_with("door"):
			target = node
			break
	_quiet_all()
	fire._ignite(target, 0.2)
	for step in 200:
		fire._burn(0.5)
	print("flowpath: 100 s shut up: the %s burns at %.2f (cap %.2f)" % [target["name"], target["intensity"], flow["ClosedCap"]])
	_check(target["burning"] and float(target["intensity"]) <= float(flow["ClosedCap"]) + 0.001, "shut up, the fire grows only to Fire.Flow.ClosedCap")

	var front: Dictionary = house.doors["FrontDoor"]
	front["locked"] = false
	house._swing(front, true, false)
	await _wait(0.8)
	ways = fire._air_ways(house)
	print("flowpath: front door open: ways %s; the front door gives onto the %s" % [ways, front.get("room")])
	_check(int(ways.get(hall, 0)) >= 1 and int(ways.get("Living room", 0)) >= 1, "the open front door is a way out for the hall and the rooms open to it")
	var shut_off: = ""
	for opening: Dictionary in house.openings:
		var door: Variant = opening.get("door")
		if door is Dictionary and not door["open"] and (opening["a"] == hall or opening["b"] == hall):
			shut_off = opening["a"] if opening["b"] == hall else opening["b"]
	if not shut_off.is_empty():
		print("flowpath: the %s, behind its shut door: ways %d" % [shut_off, int(ways.get(shut_off, 0))])
		_check(int(ways.get(shut_off, 0)) == 0, "a room behind a shut door is out of the flow")
	_check(fire._fed("Living room", int(ways["Living room"]), Game.now()) > 1.0, "with no water on it the opened-up fire is fed")
	var grown_from: float = target["intensity"]
	for step in 40:
		fire._burn(0.5)
	print("flowpath: 20 s with the door open: %.2f -> %.2f" % [grown_from, target["intensity"]])
	_check(float(target["intensity"]) > float(flow["ClosedCap"]) + 0.05, "opened up, the fire grows past the closed cap")

	fire.incident["rooms"]["Living room"]["watered_at"] = Game.now()
	_check(is_equal_approx(fire._fed("Living room", 1, Game.now()), 1.0), "with water on it lately it is not fed")


	_quiet_all()
	var kitchen_node: Dictionary = {}
	for node: Dictionary in _nodes():
		if node["room"] == "Kitchen" and not String(node["name"]).ends_with("door") and kitchen_node.is_empty():
			kitchen_node = node
	fire._ignite(kitchen_node, 0.5)
	var kitchen_door: Dictionary = house.doors["KitchenDoor"]
	if not kitchen_door["open"]:
		house._swing(kitchen_door, true, false)
	await _wait(0.8)
	var to_shut: Variant = fire._door_to_shut()

	var step: Variant = fire._next_step()
	var said: = Text.say(step, "en") if step != null else ""
	print("flowpath: the card's step: %s (door %s)" % [said, to_shut["name"] if to_shut != null else "none"])

	var searching: = Victims.next_words() != null
	_check(to_shut != null and (said.find("shut the door") >= 0 or searching), "the card says which door to shut to hold the fire (after the search, when people may be inside)")
	_check(to_shut == null or to_shut["name"] == "KitchenDoor", "the door it asks for is the one that holds it")
	if to_shut != null:
		house._swing(to_shut, false, false)
		await _wait(0.8)
		print("flowpath: shut, the card says: %s" % Text.say(fire._next_step(), "en"))
		_check(fire._door_to_shut() != to_shut, "once shut, that door is not asked for again")
	await _snap("door")

	var middle: = House.door_middle(front)
	var out: = Vector3(middle.x - house.position.x, 0, middle.z - house.position.z)
	var across: Vector3 = house.place.basis.x
	var deep: Vector3 = house.place.basis.z
	out = across * signf(out.dot(across)) if absf(out.dot(across)) > absf(out.dot(deep)) else deep * signf(out.dot(deep))
	var place: = Transform3D(Basis.looking_at( - out, Vector3.UP), _ground(middle + out * 5.0))
	_check(fire.fan(Transform3D(Basis.looking_at(out, Vector3.UP), place.origin), 0.25) == "", "a fan blowing away from the door does nothing")
	fire.incident["rooms"][hall]["smoke"] = 0.8
	fire.incident["rooms"][hall].erase("watered_at")
	var did: = fire.fan(place, 1.0)
	var smoke_after: float = fire.incident["rooms"][hall]["smoke"]
	var fed: = fire._fed(hall, int(fire._air_ways(house)[hall]), Game.now())
	print("flowpath: fan into the front door, no exhaust: %s; hall smoke 0.80 -> %.2f; the hall fed x%.1f" % [did, smoke_after, fed])
	_check(did == "noexhaust" and is_equal_approx(smoke_after, 0.8), "with no exhaust the fan clears nothing")
	_check(fed >= float(flow["FedGrow"]) * float(Config.Tools.Fan.FeedPace) - 0.01, "and pushes the fire on")

	var living: Dictionary = house.rooms["Living room"]
	living["panes"][0]["shatter"].call(Vector3.ZERO)
	did = fire.fan(place, 1.0)
	smoke_after = fire.incident["rooms"][hall]["smoke"]
	print("flowpath: with a pane of the living room broken: %s; hall smoke -> %.2f; along %s" % [did, smoke_after, fire.incident.get("fan_path")])
	_check(did == "clearing" and smoke_after < 0.8, "with an exhaust beyond, the fan clears the rooms on the way")
	_check( not (fire.incident.get("fan_path", []) as Array).has(shut_off) or shut_off.is_empty(), "and not a room off its way")
	await _done()


func _scenario_search() -> void :
	await _wait(1.0)
	var house: = await _burning()
	var plan: HudFloorPlan = Hud.current.widgets["floor_plan"]
	var front: Dictionary = house.outside_door()
	var out: = _stand_outside(house, front["lock"].global_position, 8.0)
	await _wait(1.2)
	var searched: = 0
	for room_name: String in house.rooms:
		searched += 1 if house.rooms[room_name].get("searched", false) else 0
	print("search: outside: plan shown %s, %d of %d searched" % [plan.visible, searched, house.rooms.size()])
	_check(plan.visible, "the floor plan shows by the burning house")
	_check(searched == 0, "no room is searched from outside")
	await _snap("outside")

	var visited: Array = []
	for room_name: String in ["Hall", "Living room"]:
		if not house.rooms.has(room_name):
			continue
		player.teleport(_in_room(house, house.rooms[room_name]))
		visited.append(room_name)
		await _wait(0.8)
	var ticked: Array = []
	for room_name: String in house.rooms:
		if house.rooms[room_name].get("searched", false):
			ticked.append(room_name)
	print("search: went through %s; ticked %s; the plan says '%s'" % [visited, ticked, plan._title.text])
	_check(ticked.size() >= visited.size(), "each room gone into is ticked off")
	_check(plan._title.text == Text.say(Text.f("hud.floorPlan.searched", [ticked.size(), house.rooms.size()])), "the plan counts the searched rooms")

	var state: = house.net_state()
	var bits: PackedByteArray = state.get("rm", PackedByteArray())
	var at: = 0
	var shared: = 0
	for room_name: String in house.rooms:
		if at + 1 < bits.size() and int(bits[at + 1]) & 16 != 0:
			shared += 1
		at += 2
	_check(shared == ticked.size(), "the searched rooms are in the house's shared state")
	_view(player.head_position() + Vector3(0, 30, 10), player.head_position())
	await _wait(0.3)
	_view_player()
	await _snap("inside")
	await _done()


func _scenario_smokeview() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var room_name: = "Living room"
	var room: Dictionary = house.rooms[room_name]
	fire.incident["rooms"][room_name]["smoke"] = 1.0
	house.show_smoke(room_name, 1.0)
	var middle: Vector3 = house.lot * (((room["low"] as Vector3) + (room["high"] as Vector3)) / 2.0)
	player.teleport(_in_room(house, room))
	player.crouching = false
	await _hold_smoke(house, room_name, 1.0, 1.5)
	var view: SmokeView = SmokeView.current
	var standing: = SmokeView.lost_at(player)
	var breathed_up: = fire.breathed_at(player.head_position())
	print("smokeview: standing in full smoke: view lost %.2f (shown %.2f), breathing %.2f" % [standing, view._amount, breathed_up])
	_check(standing >= 0.8 and view.visible, "standing in thick smoke the view is all but gone")
	await _snap("standing")
	player.crouching = true
	await _hold_smoke(house, room_name, 1.0, 1.5)
	var crouched: = SmokeView.lost_at(player)
	var breathed_down: = fire.breathed_at(player.head_position())
	var tall: float = room["high"].y - room["low"].y
	print("smokeview: crouched: view lost %.2f, breathing %.2f; the layer's underside %.1f studs up, the head %.1f (crouch %.2f, ui open %s, frozen %s, feet %.1f)" % [crouched, breathed_down, House.layer_bottom(1.0, tall, house._floor_of(room)) * tall, (house.lot.affine_inverse() * player.head_position()).y - room["low"].y, player._crouch_amount, Game.ui_open, player.frozen, (house.lot.affine_inverse() * player.global_position).y - room["low"].y])
	_check(crouched <= 0.2 and view._amount <= 0.25, "crouched under the layer the view clears")
	_check(breathed_down < breathed_up, "and the air is clearer down there")
	await _snap("crouched")
	player.crouching = false
	await _wait(1.0)
	Settings.smoke = Settings.SMOKE_LESS
	House.redraw_smoke()
	await _hold_smoke(house, room_name, 1.0, 1.5)
	var layer: MeshInstance3D = room["layer"]
	var density: = float((layer.material_override as ShaderMaterial).get_shader_parameter("density"))
	print("smokeview: less smoke: view lost %.2f (shown %.2f), the layer's density %.2f of %.2f" % [SmokeView.lost_at(player), view._amount, density, House.layer_density(1.0)])
	_check(SmokeView.lost_at(player) == 0.0 and density < House.layer_density(1.0) * 0.5, "with less smoke the smoke is thinner and the view is kept")
	await _snap("reduced")
	Settings.smoke = Settings.SMOKE_MORE
	House.redraw_smoke()
	await _hold_smoke(house, room_name, 1.0, 1.5)
	var more: = float((layer.material_override as ShaderMaterial).get_shader_parameter("density"))
	print("smokeview: more smoke: view lost %.2f, the layer's density %.2f of %.2f" % [SmokeView.lost_at(player), more, House.layer_density(1.0)])
	_check(more > House.layer_density(1.0) * 1.2 and SmokeView.lost_at(player) > 0.0, "with more smoke the smoke is thicker and the view is lost")
	await _snap("more")
	Settings.smoke = Settings.SMOKE_NORMAL
	House.redraw_smoke()
	await _done()


func _scenario_heatread() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var room_name: = "Living room"
	var room: Dictionary = house.rooms[room_name]
	var state: Dictionary = fire.incident["rooms"][room_name]
	_quiet_all()

	for node: Dictionary in _nodes():
		if node["room"] == "Bathroom" and not node["burning"] and fire.incident["count"] == 0:
			fire._ignite(node, 0.3)
	var middle: Vector3 = house.lot * (((room["low"] as Vector3) + (room["high"] as Vector3)) / 2.0)
	player.teleport(_in_room(house, room))
	player.crouching = false
	state["smoke"] = 0.6
	house.show_smoke(room_name, 0.6)
	await _wait(1.2)

	var hurt: = []
	for crouch: bool in [false, true]:
		player.crouching = crouch
		await _hold_smoke(house, room_name, 1.0, 1.0)
		player.health = player.max_health
		state["warmth"] = 4.0
		fire._heat_stress(house, player, 1.0)
		hurt.append(player.max_health - player.health)
	player.crouching = false
	print("heatread: a second in a room of heat 4: %.2f HP standing, %.2f crouched (gear %s)" % [hurt[0], hurt[1], player.heat_protection()])
	_check(hurt[0] > 0.0 and hurt[1] < hurt[0] * 0.75, "a hot room hurts a head up in its gas more than one crouched under it")
	player.health = player.max_health
	state["warmth"] = 0.5
	fire._heat_stress(house, player, 1.0)
	_check(is_equal_approx(player.health, player.max_health), "a cool room does not")

	for door_name: String in house.doors:
		var door: Dictionary = house.doors[door_name]
		if door["open"]:
			house._swing(door, false, false)
	await _wait(0.8)
	var aim: Vector3 = middle + Vector3(0, 3, 0)
	var steamed: = []
	for held: float in [0.5, 2.5]:
		player.health = player.max_health
		state.erase("steam_last")
		var t: = 0.0
		var scalded: = 0.0
		while t < held:
			state["warmth"] = 3.0
			var was: = player.health
			fire.fog(aim, 0.1, player, 0.1)
			scalded += was - player.health
			await _wait(0.1)
			t += 0.1
		steamed.append(scalded)
	print("heatread: fog into the shut room: a %.1f s pulse scalds %.2f HP, held %.1f s %.2f HP" % [0.5, steamed[0], 2.5, steamed[1]])
	_check(steamed[0] < 0.01 and steamed[1] > 1.0, "fog held on in a shut hot room scalds its holder; a pulse does not")
	room["panes"][0]["shatter"].call(Vector3.ZERO)
	await _wait(0.5)
	player.health = player.max_health
	state.erase("steam_last")
	var vented_scald: = 0.0
	for i in 25:
		state["warmth"] = 3.0
		var was: = player.health
		fire.fog(aim, 0.1, player, 0.1)
		vented_scald += was - player.health
		await _wait(0.1)
	print("heatread: with a pane broken, held 2.5 s: %.2f HP" % vented_scald)
	_check(vented_scald < 0.01, "with a way out for the steam it does not")

	house.set_read(room_name, "water", false)
	room["rolling"] = false
	room["heat"] = 0.3
	var young: Array = house._vent_look(room)
	room["heat"] = 4.0
	var hot: Array = house._vent_look(room)
	room["rolling"] = true
	var rolling: Array = house._vent_look(room)
	room["rolling"] = false
	house.set_read(room_name, "water", true)
	var watered: Array = house._vent_look(room)
	print("heatread: the smoke out of it: young %s x%.1f, hot %s x%.1f, flashover near %s x%.1f, under water %s x%.1f" % [young[0], young[1], hot[0], hot[1], rolling[0], rolling[1], watered[0], watered[1]])
	_check((young[0] as Color).v > (hot[0] as Color).v and float(hot[1]) > float(young[1]), "a hotter room pushes darker, faster smoke")
	_check((rolling[0] as Color).v < 0.1 and float(rolling[1]) > float(hot[1]) - 0.01, "before a flashover it is black and fast")
	_check((watered[0] as Color).v > 0.75, "under water it turns white")
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _hold_smoke(house, room_name, 0.8, 0.5)
	_view(room["panes"][0]["position"] + _out_of(house, room["panes"][0]) * 16.0 + Vector3(0, 4, 0), room["panes"][0]["position"])
	await _hold_smoke(house, room_name, 0.8, 2.5)
	await _snap("white")
	house.set_read(room_name, "water", false)

	var other: = ""
	for each: String in house.rooms:
		if each != room_name and not house.rooms[each]["panes"].is_empty() and int(house.rooms[each]["floor"]) == 1:
			other = each
			break
	fire.incident["sealed"] = other
	await _wait(1.0)
	var breaths: Array = house.rooms[other].get("breaths", [])
	print("heatread: the %s breathing: %d puffing gaps" % [other, breaths.size()])
	_check(breaths.size() >= 1, "a shut room starved of air puffs smoke at its gaps")
	_view(house.rooms[other]["panes"][0]["position"] + _out_of(house, house.rooms[other]["panes"][0]) * 14.0 + Vector3(0, 2, 0), house.rooms[other]["panes"][0]["position"])
	await _wait(1.2)
	await _snap("breathing")
	fire.incident["sealed"] = null
	await _wait(0.5)
	_check(house.rooms[other].get("breaths", []).is_empty(), "vented, it stops")
	await _done()
