extends ProofDebug




const ROWS: = ["Fire.Crew", "Victims.Most", "Incidents.Crash.Casualties", "Incidents.Tree.Cuts", "Incidents.Tree.Limbs", "Incidents.Flood.Litres"]


func _scenario_bigcrew() -> void :
	await _wait(1.0)
	for path: String in ROWS:
		var table: Variant = Config.data
		for key in path.split("."):
			table = table[key]
		_check((table as Array).size() == 10, "%s has a row for every crew size up to ten" % path)

	var alone: = _sized(1)
	var base_row: Array = Config.Alarm.Weights[clampi(Alarm.crew_rank(), 0, Config.Alarm.Weights.size() - 1)]
	_check(Alarm.crowd() == 0 and Alarm.level_weights() == base_row, "one player: no crowd, the rank's level odds as they were %s" % [base_row])

	var others: Array[Player] = []
	for index in 5:
		var body: = Player.new()
		body.name = "Other%d" % index
		get_tree().current_scene.add_child(body)
		body.teleport(_ground(Game.station.door_position + Vector3(4 + index * 3, 0, 8)) + Vector3(0, 0.3, 0))
		others.append(body)
	await _wait(0.5)
	var row: = Alarm.level_weights()
	print("bigcrew: humans %d crowd %d weights %s (rank's %s)" % [Game.humans(), Alarm.crowd(), row, base_row])
	_check(Game.humans() == 6 and Alarm.crowd() == 3, "six players: a crowd of 3")
	_check(float(row[0]) < float(base_row[0]) and float(row[2]) > float(base_row[2]), "the level drawn leans away from I toward III")
	var six: = _sized(6)
	print("bigcrew: alone %s, six %s" % [alone, six])
	_check(six[3]["crew"] == 10 and six[3]["flames"] == 26 and six[3]["victims"] == 4 and six[3]["cuts"] == 7, "six players at level III: sized for ten (26 flames, up to 4 people inside, 7 cuts)")
	_check(six[1]["flames"] > alone[1]["flames"] and six[3]["flames"] > six[1]["flames"], "and a higher level is still a bigger call (I %d, III %d flames)" % [six[1]["flames"], six[3]["flames"]])

	Alarm.forced = 3
	CallService.current.forced = "fire"
	CallService.current.hold = false
	CallService.current.wait_left = 0.3
	var waited: = 0.0
	while (FireService.current == null or FireService.current.incident.is_empty()) and waited < 20.0:
		await _wait(0.2)
		waited += 0.2
	await _wait(0.5)
	print("bigcrew: fire at %s, level %d, flame cap %d" % [Game.incident.get("address", "?"), Alarm.level, FireService.current._flame_cap()])
	_check(FireService.current._flame_cap() >= 26, "the fire is capped for the crew of ten")
	await _wait(25.0)
	var house: Vector3 = Game.incident.get("position", Game.station.door_position)
	_view(house + Vector3(40, 30, 40), house)
	await _wait(1.0)
	await _snap("fire")
	await _done()



func _sized(_players: int) -> Dictionary:
	var sizes: = {}
	for level in [1, 2, 3]:
		Alarm.forced = level
		Alarm.begin()
		sizes[level] = {"crew": Alarm.crew(), "flames": int(CallKit.by_crew(Config.Fire.Crew)["flames"]), 
			"victims": int(CallKit.by_crew(Config.Victims.Most)), "cuts": int(CallKit.by_crew(Config.Incidents.Tree.Cuts))}
		Alarm.end()
	Alarm.forced = 0
	return sizes
