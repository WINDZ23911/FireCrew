class_name Crewman
extends Node








signal job_changed
signal stuck(at: Vector3, to: Vector3)

const SLOTS: = [Vector2(-4.5, 6.0), Vector2(4.5, 6.0), Vector2(0.0, 10.0), Vector2(-7.0, 12.0), Vector2(7.0, 12.0)]
const FEELER: = 3.5
const AHEAD: = 200.0
const SAY_EVERY: = 6.0
const STRIPE_PATTERNS: = ["band", "bands", "chevron", "checker"]

static var _stripe_paints: Dictionary = {}

var auto_note: Variant = null
var autonomy: = -1
var body: Player
var service: CrewService
var member: Dictionary
var role: = "nozzle"
var slot: = 0


var wish: = Vector3.ZERO
var look: = Vector3.INF
var pitch: = 0.0
var crouch: = false
var jump: = false


var pace: = 1.0:
	get:
		return pace * (float(Config.Crew.get("WalkPace", 1.0)) * CrewRoster.trait_value(member, "Pace") if job != null else 1.0)
var drive_input: = 0.0
var steer_input: = 0.0

var job: CrewJob = null
var queue: Array[CrewJob] = []
var mode: = "follow"
var hold_at: = Vector3.INF
var last_line: Variant = null
var last_line_at: = -100.0
var told: Variant = null
var told_at: = -100.0

var _token: = 0
var _path: Array[Vector3] = []
var _path_until: = 0.0
var _path_to: = Vector3.INF
var _on_mesh: = false
var _mesh_left: = 0
var _planned: = 0
var _no_route: = false
var _said: Dictionary = {}
var _bubble: Label3D
var _tag: Label3D
var _bubble_until: = 0.0
var _side: = 1.0
var _side_until: = 0.0
var _idle_since: = 0.0
var _boarding_since: = -1.0
var _leave_at: = -1.0
var _next_door_check: = 0.0
var blocked_by: Dictionary = {}
var failed: Dictionary = {}
var failures: Dictionary = {}
var _waiting_told: = false
var _stripes: Array[MeshInstance3D] = []
var last_auto_kind: = ""
var last_auto_at: = -100.0


func _ready() -> void :
	_bubble = Label3D.new()
	_bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_bubble.no_depth_test = false
	_bubble.fixed_size = true
	_bubble.pixel_size = 0.0011
	_bubble.font_size = 30
	_bubble.outline_size = 10
	_bubble.outline_modulate = Color(0, 0, 0, 0.8)
	_bubble.position = Vector3(0, 7.5, 0)
	_bubble.visible = false
	body.add_child.call_deferred(_bubble)

	_tag = Label3D.new()
	_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_tag.fixed_size = true
	_tag.pixel_size = 0.0008
	_tag.font_size = 26
	_tag.outline_size = 8
	_tag.outline_modulate = Color(0, 0, 0, 0.7)
	_tag.position = Vector3(0, 6.6, 0)
	_tag.text = display_name()
	_tag.modulate = member.get("colour", Color.WHITE)
	body.add_child.call_deferred(_tag)
	Game.notified.connect( func(text: Variant, _kind: String, player: Player) -> void :
		if player == body:
			told = text
			told_at = Game.now()
	)
	_idle_since = Game.now()
	dress_role.call_deferred()
	dress_person.call_deferred()




func dress_person() -> void :
	if not is_instance_valid(body) or body.rig == null:
		return
	var years: = clampf(float(member.get("level", 0)) / maxf(float((Config.Crew.Skill as Array).size() - 1), 1.0) * 0.6 + float(int(rand_from_seed(hash([display_name(), "years"]))[0]) % 100) / 250.0, 0.0, 1.0)
	body.rig.dress_person(display_name(), years)






func dress_role() -> void :
	for stripe in _stripes:
		if is_instance_valid(stripe):
			stripe.queue_free()
	_stripes.clear()
	if not is_instance_valid(body) or body.rig == null or not body.rig.joints.has("ShoulderL"):
		return
	var pattern: = CrewRoster.role_pattern(role)
	var paint: = stripe_paint(pattern)
	var places: Array = [
		[body.rig.joints["ShoulderL"], Config.Crew.Stripes.Arm], 
	]
	for place: Array in places:
		var spec: Dictionary = place[1]
		var box: = BoxMesh.new()
		box.size = Rbx.v3(spec["Size"]) if spec["Size"] is Array else spec["Size"]
		var stripe: = MeshInstance3D.new()
		stripe.mesh = box
		stripe.material_override = paint
		stripe.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		stripe.position = Rbx.v3(spec["At"]) if spec["At"] is Array else spec["At"]
		stripe.set_meta("pattern", pattern)
		(place[0] as Node3D).add_child(stripe)
		stripe.set_instance_shader_parameter("box", box.size)
		_stripes.append(stripe)



static func stripe_paint(pattern: String) -> ShaderMaterial:
	if not _stripe_paints.has(pattern):
		var paint: = ShaderMaterial.new()
		paint.shader = load("res://shaders/role_stripe.gdshader")
		paint.set_shader_parameter("lime", Ui.YELLOW)
		paint.set_shader_parameter("pattern", maxi(STRIPE_PATTERNS.find(pattern), 0))
		paint.set_shader_parameter("glow", float(Config.Crew.Stripes.Glow))
		_stripe_paints[pattern] = paint
	return _stripe_paints[pattern]


func set_role(new_role: String) -> void :
	role = new_role
	member["role"] = new_role
	dress_role()



func back_out_at() -> float:
	return float(Config.Crew.BackOutHealth) * CrewRoster.trait_value(member, "Heat")


func display_name() -> String:
	return member.get("name", body.display_name)


func commander() -> Player:
	return Game.local_player



func hands_free() -> bool:
	return body.holding == "" and body.get_attr("Line") == null and body.get_attr("Supply") == null and body.get_attr("Carrying") != true


func busy() -> bool:
	return job != null






func give(new_job: CrewJob, after: = false) -> void :
	new_job.who = self
	if after and job != null:
		queue.append(new_job)
		return
	for waiting in queue:
		waiting.cancelled = true
	queue.clear()
	if job != null:
		job.cancelled = true
		_token += 1


		queue.append(new_job)
		return
	_start(new_job)



func stand_down() -> void :
	for waiting in queue:
		waiting.cancelled = true
	queue.clear()
	if job != null:
		job.cancelled = true
		_token += 1


func _start(new_job: CrewJob) -> void :
	job = new_job
	_token += 1
	job_changed.emit()
	_run(new_job)


func _run(running: CrewJob) -> void :
	var done: bool = await running.run()
	running.finish(done)
	if OS.get_cmdline_user_args().has("--crew-trace"):
		print("crew trace: %s %s %s (%s) at %s" % [display_name(), running.kind, "done" if done else ("called off" if running.cancelled else "failed"), running.reason, body.global_position.snapped(Vector3.ONE)])
	if job == running:
		job = null
	_path.clear()
	wish = Vector3.ZERO
	look = Vector3.INF
	crouch = false
	body.set_attr("Trigger", false)
	if done and not running.cancelled:
		service.job_done(self, running)
	elif not running.cancelled:
		service.job_failed(self, running)
	if not done and not running.done_flag.is_empty():
		service.done_here.erase(running.done_flag)
	_idle_since = Game.now()
	while not queue.is_empty():
		var next: CrewJob = queue.pop_front()
		if not next.cancelled:
			_start(next)
			return
	job_changed.emit()



func token() -> int:
	return _token


func alive(held: int) -> bool:
	return held == _token and is_instance_valid(body) and body.health > 0.0






func tick() -> void :
	await get_tree().physics_frame


func wait(seconds: float, held: = -1) -> bool:
	var until: = Game.now() + seconds
	var holding: = held if held >= 0 else _token
	while Game.now() < until:
		await tick()
		if not alive(holding):
			return false
	return true





func go(to: Vector3, near: = 3.0, give_up: = 45.0, until: = Callable()) -> bool:
	var held: = _token
	blocked_by = {}
	if body.seat != null:
		_get_out()
		await wait(0.4, held)
	_path_to = Vector3.INF


	if CrewNav.current and CrewNav.current.ready_at(to):
		var snapped: = CrewNav.current.closest(to)
		if _flat(snapped - to).length() < 5.0:
			near = maxf(near, _flat(snapped - to).length() + 0.5) if _flat(snapped - to).length() > near else near
			to = snapped
	var started: = Game.now()
	var best: = INF
	var best_at: = Game.now()
	var measured_plan: = -1
	var tries: = 0
	while true:
		if not alive(held):
			wish = Vector3.ZERO
			return false
		var here: = body.global_position
		var flat_left: = _flat(to - here).length()
		if flat_left <= near and absf(to.y - here.y) < 8.0:
			wish = Vector3.ZERO
			return true

		if until.is_valid() and until.call():
			wish = Vector3.ZERO
			return true
		_steer(to, near)
		if Game.now() >= _next_door_check:
			_next_door_check = Game.now() + 0.3
			var door: = _door_ahead()
			if not door.is_empty():
				wish = Vector3.ZERO
				if door["locked"]:
					blocked_by = door
					return false

				if not await press(door["prompt"]):
					return false
				await wait(0.6, held)
				best_at = Game.now()
		var left: = _remaining(to)
		if _planned != measured_plan:


			measured_plan = _planned
			if best != INF and left > best:
				best = left
		if left < best - 1.0:
			best = left
			best_at = Game.now()
		elif Game.now() - best_at > 2.5:


			tries += 1
			best_at = Game.now()
			stuck.emit(here, to)
			if OS.get_cmdline_user_args().has("--crew-trace"):
				print("crew trace: %s stuck (try %d) at %s going to %s, best %.1f, path %s, seen %s" % [display_name(), tries, here.snapped(Vector3.ONE * 0.1), to.snapped(Vector3.ONE * 0.1), best, _path.map( func(p: Vector3) -> Vector3: return p.snapped(Vector3.ONE)), service.seen(body.root_position())])
			if tries == 1:
				jump = true
				_side = - _side
				_side_until = Game.now() + 1.5
			elif not service.seen(body.root_position()) or tries >= 5 or _no_route:
				_skip_ahead(to, near)
			else:
				_side = - _side
				_side_until = Game.now() + 2.0
				_path_to = Vector3.INF
		if Game.now() - started > give_up:
			wish = Vector3.ZERO
			return false
		await tick()
	return false




func _door_ahead() -> Dictionary:
	var fire: = FireService.current
	if fire == null or wish.length() < 0.1:
		return {}
	var here: = body.global_position
	var ahead: = wish.normalized()
	for building in fire.buildings:
		if not building is House or building.position.distance_to(here) > 90.0:
			continue
		for door_name: String in building.doors:
			var door: Dictionary = building.doors[door_name]
			if door["open"] or door["burnt"] or door["moving"]:
				continue
			var leaf: Node3D = door["leaf"]
			var at: Vector3 = leaf.global_position if is_instance_valid(leaf) else door["shut"].origin
			var offset: = _flat(at - here)
			if offset.length() < 5.0 and absf(at.y - here.y - 3.0) < 5.0 and offset.normalized().dot(ahead) > 0.2:
				return door
	return {}



func go_face(to: Vector3, face: Vector3, near: = 2.5) -> bool:
	if not await go(to, near):
		return false
	look = face
	return await wait(0.25)



func press(prompt: Prompt, held_for: = -1.0) -> bool:
	if prompt == null or not is_instance_valid(prompt):
		return false
	var held: = _token
	if _flat(prompt.global_position - body.root_position()).length() > prompt.reach * 0.85 or body.global_position.y > prompt.global_position.y + 1.0:
		var by: = stand_by(prompt.global_position, clampf(prompt.reach * 0.55, 2.5, 5.5))
		if OS.get_cmdline_user_args().has("--crew-trace"):
			print("crew trace: %s to prompt %s at %s: stand %s" % [display_name(), Text.say(prompt.action, "en"), prompt.global_position, by])
		if not await go(by, 1.5):
			return false
	look = prompt.global_position
	await wait(0.2, held)
	if not alive(held) or not is_instance_valid(prompt) or not prompt.shown_to(body):
		return false
	var hold: = prompt.hold if held_for < 0.0 else held_for
	if hold <= 0.0:
		body.begin_act(prompt, true)
		prompt.triggered.emit(body)
		return true
	body.begin_act(prompt, false)
	prompt.hold_began.emit(body)
	var finished: = await wait(hold, held)
	body.end_act()
	if not is_instance_valid(prompt):
		return false
	prompt.hold_ended.emit(body)
	if not finished:
		return false
	prompt.triggered.emit(body)
	return true




func stand_by(at: Vector3, gap: float) -> Vector3:
	var away: = _flat(body.global_position - at)
	if away.length() < 0.1:
		away = Vector3(1, 0, 0)
	away = away.normalized()
	var floor_y: = minf(body.global_position.y, at.y)

	for turn: float in [0.0, 0.6, -0.6, 1.2, -1.2, 1.8, -1.8, PI]:
		var way: = away.rotated(Vector3.UP, turn)
		for extra: float in [0.0, 2.0]:
			var spot: = at + way * (gap + extra)

			var hit: = Game.world.raycast(Vector3(spot.x, at.y + 16.0, spot.z), Vector3(spot.x, at.y - 30.0, spot.z), World.LAYER_SOLID | World.LAYER_VEHICLE)
			if hit.is_empty():
				continue

			var walkable: = reachable(hit["position"])
			if walkable and hit["position"].y < floor_y + 1.4 and not hit.get("collider") is PhysicsBody3D:
				if Game.world.raycast(Vector3(spot.x, hit["position"].y + 2.5, spot.z), Vector3(at.x, hit["position"].y + 2.5, at.z), World.LAYER_VEHICLE).is_empty() or extra > 0.0:
					return hit["position"]
	return service.ground(at + away * gap)




func reachable(at: Vector3) -> bool:
	var nav: = CrewNav.current
	if nav == null or not nav.ready_at(at) or not nav.ready_at(body.global_position):
		return true
	var found: = nav.path(body.global_position, at)
	if found.is_empty():
		return false
	var end: = found[found.size() - 1]
	return _flat(end - at).length() < 1.2 and absf(end.y - at.y) < 2.5


func _get_out() -> void :
	var vehicle: Variant = body.get_attr("Vehicle")
	if vehicle is Vehicle and is_instance_valid(vehicle):
		vehicle.leave(body)
	elif body.seat != null:
		body.leave_seat(body.global_position + Vector3(4, 0, 0))





func _flat(v: Vector3) -> Vector3:
	return Vector3(v.x, 0.0, v.z)


func _plan_path(to: Vector3) -> void :
	_planned += 1
	_path.clear()
	var here: = body.global_position
	var nav: = CrewNav.current
	if nav != null:
		nav.ensure(here)
		if _flat(to - here).length() < CrewNav.TILE * 1.5:
			nav.ensure(to)
		var found: = nav.path(here, to)
		if not found.is_empty():
			for point in found:
				_path.append(point)
			if _path[_path.size() - 1].distance_to(to) > 0.5:
				_path.append(to)
			_path_until = Game.now() + 4.0
			_set_mesh(_path.size())
			_no_route = false
			return

		_no_route = nav.ready_at(here) and nav.ready_at(to)
	_set_mesh(0)
	_path_until = Game.now() + 1.0

	var rough: Array[Vector3] = []
	var graph: = NavGraph.current
	if graph != null and _flat(to - here).length() >= 60.0 and not _clear(here, to):
		var start: Array = graph.nearest_walk(here.x, here.z)
		var finish: Array = graph.nearest_walk(to.x, to.z)
		if start[0] >= 0 and finish[0] >= 0 and float(start[1]) <= 40.0:
			for id in graph.walk_route(start[0], finish[0]):
				var node: Dictionary = graph.walk[id]
				rough.append(Vector3(node["x"], here.y, node["z"]))
	rough.append(to)


	if nav != null and not _no_route:
		var along: = 0.0
		var last: = here
		var reachable: Array[int] = []
		for index in rough.size():
			along += _flat(rough[index] - last).length()
			last = rough[index]
			if along > AHEAD:
				break
			nav.ensure(rough[index], 0.2)
			if nav.ready_at(rough[index]):
				reachable.append(index)
		var tries: = 0
		for k in range(reachable.size() - 1, -1, -1):
			tries += 1
			if tries > 5:
				break
			var index: int = reachable[k]
			var stretch: = nav.path(here, rough[index])
			if stretch.is_empty():
				continue
			for point in stretch:
				_path.append(point)
			_set_mesh(_path.size())
			for rest in range(index + 1, rough.size()):
				_path.append(rough[rest])
			if _path.is_empty() or _path[_path.size() - 1].distance_to(to) > 0.5:
				_path.append(to)
			_path_until = Game.now() + 2.0
			return
	_path.append_array(rough)


func _set_mesh(count: int) -> void :
	_mesh_left = count
	_on_mesh = count > 0




func _remaining(to: Vector3) -> float:
	var here: = body.global_position
	if _path.is_empty():
		return _flat(to - here).length()
	var total: = _flat(_path[0] - here).length()
	for index in range(1, _path.size()):
		total += _flat(_path[index] - _path[index - 1]).length()
	return total



func _clear(from: Vector3, to: Vector3) -> bool:
	var a: = Vector3(from.x, from.y + 3.0, from.z)
	var b: = Vector3(to.x, a.y, to.z)
	return Game.world.raycast(a, b, World.LAYER_SOLID, [body.get_rid()]).is_empty()


func _steer(to: Vector3, near: float) -> void :
	var here: = body.global_position
	if _path_to == Vector3.INF or _path_to.distance_to(to) > 5.0 or Game.now() > _path_until or _path.is_empty():
		_plan_path(to)
		_path_to = to
	_path[_path.size() - 1] = to

	while _path.size() > 1:
		var corner: = _path[0]
		if _flat(corner - here).length() < 1.6 and absf(corner.y - here.y) < 4.0:
			_path.pop_front()
			_set_mesh(maxi(_mesh_left - 1, 0))
		elif not _on_mesh and _clear(here, _path[1]) and _flat(_path[1] - here).length() < 30.0:
			_path.pop_front()
		else:
			break
	var aim: Vector3 = _path[0]
	var toward: = _flat(aim - here)
	if toward.length() < 0.01:
		wish = Vector3.ZERO
		return
	var dir: = toward.normalized()
	dir = _round_obstacles(dir, toward.length() if _path.size() <= 1 else INF)

	var push: = Vector3.ZERO
	for other in Game.players:
		if other == body or not is_instance_valid(other) or other.seat != null:
			continue
		var off: = _flat(here - other.global_position)
		var gap: = off.length()
		if gap < 3.2 and gap > 0.01:
			push += off / gap * (3.2 - gap) / 3.2
	dir = (dir + push * 0.6).normalized()
	var left: = _flat(to - here).length()
	var speed: = 1.0 if left > near + 6.0 else clampf((left - near) / 6.0 + 0.35, 0.35, 1.0)
	wish = dir * speed
	look = Vector3.INF



func _round_obstacles(dir: Vector3, left: = INF) -> Vector3:
	var from: = body.global_position + Vector3(0, 2.2, 0)

	var mask: = World.LAYER_SOLID | World.LAYER_VEHICLE
	var ahead: = Game.world.raycast(from, from + dir * FEELER, mask, [body.get_rid()])


	if not ahead.is_empty() and _on_mesh and not ahead.get("collider") is PhysicsBody3D:
		ahead = {}


	if not ahead.is_empty() and (from.distance_to(ahead["position"]) > left - 0.8 or _flat(ahead["normal"]).normalized().dot(dir) > -0.45):
		ahead = {}
	if ahead.is_empty():
		return dir
	if Game.now() > _side_until:
		var left_dir: = dir.rotated(Vector3.UP, 0.8)
		var right_dir: = dir.rotated(Vector3.UP, -0.8)
		var left_open: = Game.world.raycast(from, from + left_dir * FEELER * 1.5, mask, [body.get_rid()]).is_empty()
		var right_open: = Game.world.raycast(from, from + right_dir * FEELER * 1.5, mask, [body.get_rid()]).is_empty()
		if left_open != right_open:
			_side = 1.0 if left_open else -1.0
		_side_until = Game.now() + 1.2

	var normal: Vector3 = _flat(ahead["normal"]).normalized()
	if normal == Vector3.ZERO:
		return dir.rotated(Vector3.UP, _side * 1.2)
	var along: = normal.cross(Vector3.UP) * - _side
	return (along + normal * 0.3).normalized()



func _skip_ahead(to: Vector3, near: float) -> void :
	var next: Vector3 = _path[0] if not _path.is_empty() else to
	var here: = body.global_position
	var step: = _flat(next - here)
	var place: = next if step.length() < 25.0 else here + step.normalized() * 25.0
	if not _path.is_empty() and step.length() < 25.0:
		_path.pop_front()
		_set_mesh(maxi(_mesh_left - 1, 0))
	if _flat(to - place).length() < near:
		place = to - _flat(to - here).normalized() * near * 0.8
	if CrewNav.current and CrewNav.current.ready_at(place):
		place = CrewNav.current.closest(place)
	jump_to(service.ground(place + Vector3(0, 1.0, 0)) + Vector3(0, 0.2, 0))




func jump_to(place: Vector3) -> void :
	if not service.seen(body.root_position()) and not service.seen(place):
		body.teleport(place)
		return
	var fade: = float(Config.Crew.Fade.Time)
	_puff(body.root_position())
	body.rig.visible = false
	body.teleport(place)
	_puff(place)
	var seen_body: = body
	get_tree().create_timer(fade, false).timeout.connect( func() -> void :
		if is_instance_valid(seen_body):
			seen_body.rig.visible = true)



func _puff(at: Vector3) -> void :
	var puff: = Node3D.new()
	Game.world.add_child(puff)
	puff.global_position = at + Vector3(0, 2.5, 0)
	var stuff: = StandardMaterial3D.new()
	stuff.albedo_color = Color(0.82, 0.82, 0.8, 0.55)
	stuff.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	stuff.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var ball: = SphereMesh.new()
	ball.radius = 1.0
	ball.height = 2.0
	ball.radial_segments = 8
	ball.rings = 4
	for index in int(Config.Crew.Fade.Puffs):
		var part: = MeshInstance3D.new()
		part.mesh = ball
		part.material_override = stuff
		part.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		part.position = Vector3(randf_range(-1, 1), randf_range(-1.5, 1.5), randf_range(-1, 1))
		puff.add_child(part)
	var time: = float(Config.Crew.Fade.Time) * 2.0
	var tween: = puff.create_tween()
	tween.set_parallel(true)
	tween.tween_property(puff, "scale", Vector3.ONE * 2.2, time)
	tween.tween_property(stuff, "albedo_color:a", 0.0, time)
	tween.chain().tween_callback(puff.queue_free)





func _physics_process(delta: float) -> void :
	if not is_instance_valid(body):
		return
	_recover(delta)
	if job != null:
		return
	if body.seat != null:
		_ride()
		return
	match mode:
		"hold":
			if hold_at != Vector3.INF and _flat(hold_at - body.global_position).length() > 3.0:
				_steer(hold_at, 2.0)
			else:
				wish = Vector3.ZERO
		_:
			_follow()




func _recover(delta: float) -> void :
	if body.health <= 0.0 or body.health >= body.max_health:
		return
	var fire: = FireService.current

	if fire != null and fire.smoke_at(body.root_position()) > float(Config.Crew.get("RecoverSmoke", 0.12)):
		return
	body.heal(float(Config.Crew.Recover) * delta)



func slot_position() -> Vector3:
	var lead: = commander()
	if lead == null:
		return body.global_position
	var yaw: = lead.rig.global_rotation.y
	var offset: Vector2 = SLOTS[slot % SLOTS.size()]
	return lead.global_position + Basis(Vector3.UP, yaw) * Vector3(offset.x, 0, offset.y)


func _follow() -> void :
	var lead: = commander()
	if lead == null:
		wish = Vector3.ZERO
		return
	var lead_vehicle: Variant = lead.get_attr("Vehicle")
	if lead_vehicle is Vehicle and lead.seat != null:
		_board_with(lead_vehicle)
		return
	_boarding_since = -1.0
	var spot: = slot_position()
	var gap: = _flat(spot - body.global_position).length()
	var far: = _flat(lead.global_position - body.global_position).length()
	if far > 160.0 and not service.seen(body.root_position()) and not service.seen(spot):
		body.teleport(service.free_spot(spot, lead.global_position) + Vector3(0, 0.2, 0))
		return
	_waiting_told = false
	if gap > 3.5:
		_steer(spot, 2.0)
		pace = 1.15 if far > 25.0 else 1.0
	else:
		wish = Vector3.ZERO
		pace = 1.0
		_path.clear()

		look = body.global_position + lead.facing() * 20.0



func _board_with(vehicle: Vehicle) -> void :
	if body.seat != null:
		return
	if not service.free_seat(vehicle):

		wish = Vector3.ZERO
		if _boarding_since < 0.0:
			_boarding_since = Game.now()
			if not service.no_room(self, vehicle):
				say("crew.say.noRoom", [], "info")
		return
	if _boarding_since < 0.0:
		_boarding_since = Game.now()
	var door: = service.door_for(vehicle, body.global_position)
	var at: Vector3 = service.door_spot(vehicle, door)
	var gap: = _flat(at - body.global_position).length()


	var waited: = Game.now() - _boarding_since
	var unseen: = not service.seen(body.root_position())
	if gap < 4.0 or absf(vehicle.forward_speed) > 3.0 or (unseen and waited > float(Config.Crew.BoardUnseen)) or waited > float(Config.Crew.BoardMost):
		wish = Vector3.ZERO
		CrewKit.stow_all(self)
		if gap >= 4.0 and not unseen:
			_puff(body.root_position())
		vehicle._board(body, door)
		return
	if waited > float(Config.Crew.BoardUnseen) and not _waiting_told:
		_waiting_told = true
		Game.notify(Text.f("crew.say.waitingFor", [display_name()]), "", commander())
	_steer(at, 2.0)
	pace = 1.15



func _ride() -> void :
	wish = Vector3.ZERO
	var lead: = commander()
	if lead == null or mode == "hold":
		return
	var mine: Variant = body.get_attr("Vehicle")
	var theirs: Variant = lead.get_attr("Vehicle")
	if mine is Vehicle and theirs != mine:
		if _leave_at < 0.0:
			_leave_at = Game.now() + 0.4 + slot * 0.35
		elif Game.now() >= _leave_at and absf(mine.forward_speed) < 2.0:
			_leave_at = -1.0
			_get_out()
			_arrived()
		return
	_leave_at = -1.0



func _arrived() -> void :
	service.member_arrived(self)






func say(key: String, args: Array = [], kind: = "info", force: = false) -> void :
	if not force and Game.now() - _said.get(key, -100.0) < SAY_EVERY:
		return

	if not service.voice_free(key, args):
		return
	_said[key] = Game.now()
	if is_instance_valid(body) and body.rig != null and body.rig.has_method("set_mood"):
		body.rig.set_mood(3, 1.8)
	var line: Variant = Text.f(key, args) if not args.is_empty() else Text.m(key)
	last_line = line
	last_line_at = Game.now()
	_bubble.text = Text.say(line)
	_bubble.modulate = Color(1, 0.86, 0.5) if kind == "warning" else (Color(1, 0.55, 0.5) if kind == "danger" else Color(1, 1, 1))


	var lead: = commander()
	_bubble.visible = service.seen(body.root_position()) and lead != null and lead.global_position.distance_to(body.global_position) < float(Config.Crew.Voice.BubbleRange)
	_bubble_until = Game.now() + 3.5
	service.spoke(self, line, kind)




func report(key: String, args: Array = [], kind: = "info") -> void :
	if not service.first_report(key, args):
		return
	say(key, args, kind, true)


func _process(_delta: float) -> void :
	if _bubble.visible and Game.now() > _bubble_until:
		_bubble.visible = false
	var lead: = commander()
	_tag.visible = lead != null and body.seat == null and lead.global_position.distance_to(body.global_position) < 70.0
