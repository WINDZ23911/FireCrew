class_name HandLook
extends Node








const STAGE: = Vector3(0, 600, 0)

var _prefix: = ""
var _camera: Camera3D


func _ready() -> void :
	var mode: = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--handlook="):
			mode = arg.substr(11)
		elif arg.begins_with("--shots="):
			_prefix = arg.substr(8)
	match mode:
		"models":
			_models.call_deferred()
		"hold":
			_holds.call_deferred()
		"bench":
			_bench.call_deferred()
		"suit":
			_suit.call_deferred()


func _shot(path: String) -> void :
	await get_tree().process_frame
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)
	print("handlook: shot ", path)


func _stage() -> void :
	var floor_box: = MeshInstance3D.new()
	var plate: = BoxMesh.new()
	plate.size = Vector3(60, 1, 60)
	floor_box.mesh = plate
	var grey: = StandardMaterial3D.new()
	grey.albedo_color = Color(0.55, 0.56, 0.58)
	floor_box.material_override = grey
	add_child(floor_box)
	floor_box.global_position = STAGE - Vector3(0, 0.5, 0)
	_camera = Camera3D.new()
	_camera.fov = 40
	add_child(_camera)
	_camera.make_current()
	if Hud.current:
		Hud.current.visible = false


func _models() -> void :
	await get_tree().create_timer(1.0).timeout
	_stage()
	var names: = _arg("--hand-tools=", "Axe,Halligan bar,Crowbar,Bolt cutters,Spreader,Cutter,Chainsaw,Extinguisher,Floodlight,Fan,Thermal camera,Divider,Cone,Tape post,Tape reel,Attack roll,Supply roll").split(",")
	for tool_name: String in names:
		var model: = ToolModels.instance(tool_name)
		add_child(model)
		model.global_position = STAGE + Vector3(0, 1.2 if tool_name in ["Axe", "Halligan bar", "Crowbar", "Bolt cutters", "Divider"] else 0.0, 0) + (Vector3(0, 1, 0) if tool_name in ["Spreader", "Cutter"] else Vector3.ZERO) + (Vector3(0, 1.8, 0) if tool_name.ends_with("roll") else Vector3.ZERO)
		var box: = AABB()
		var first: = true
		for mesh: MeshInstance3D in model.find_children("*", "MeshInstance3D", true, false):
			var seen: AABB = mesh.global_transform * mesh.get_aabb()
			box = seen if first else box.merge(seen)
			first = false
		var middle: = box.get_center()
		var size: = box.get_longest_axis_size()
		var file: = _prefix + "_" + tool_name.replace(" ", "_").to_lower()
		for view: Array in [["front", Vector3(0.55, 0.35, -1.0)], ["side", Vector3(1.0, 0.25, 0.3)], ["back", Vector3(-0.5, 0.45, 1.0)]]:
			_camera.look_at_from_position(middle + (view[1] as Vector3).normalized() * size * 2.2, middle)
			await _shot(file + "_" + view[0] + ".png")
		model.queue_free()
	Game.quit()





func _arg(prefix: String, default: String) -> String:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with(prefix):
			return arg.substr(prefix.length())
	return default



func _take(thing: String) -> Dictionary:
	var player: = Game.local_player
	if thing == "nozzle":
		HoseService.current._connect_line(HoseService.current.lines[0], player)
		return {"nozzle": true}
	if thing in ["roll", "supplyroll"]:
		HoseService.current._on_roll_line(HoseService.current.rigs[0], "attack" if thing == "roll" else "supply", player)
		return {"roll": true}
	if thing == "carry":
		var house: = _house()
		_stand_outside(house, house.outside_door()["lock"].global_position, 14.0)
		await get_tree().create_timer(0.3).timeout

		var place: = Figure.lying(player.global_position + Vector3(0, -2.9, -2.5), Vector3.RIGHT)
		var victim: = VictimService.current._create(place, "test", 7)
		VictimService.current.lift(victim, player)
		var waist: Node3D = player.rig.joints["Waist"]
		for part: String in victim.figure.parts:
			var mesh: MeshInstance3D = victim.figure.parts[part]
			print("handlook: carried ", part, " ", waist.global_transform.affine_inverse() * mesh.global_transform * mesh.get_aabb())
		print("handlook: shoulders from the waist ", waist.global_transform.affine_inverse() * player.rig.joints["ShoulderR"].global_position)
		return {"carry": victim}
	if thing == "wheel":
		var truck: = Vehicle.named("Fire Truck")
		truck._board(player, "DoorCabLeft")
		await get_tree().create_timer(0.5).timeout
		var wheel: Node3D = truck._steering_wheel
		for mesh in wheel.get_children():
			if mesh is MeshInstance3D:
				print("handlook: wheel piece ", mesh.name, " ", mesh.transform * mesh.get_aabb())
		var rig: = player.rig
		var local: = wheel.global_transform.affine_inverse()
		print("handlook: wheel from the rig ", rig.global_transform.affine_inverse() * wheel.global_transform, " shoulders in the wheel's frame ", local * rig.joints["ShoulderR"].global_position, local * rig.joints["ShoulderL"].global_position)
		return {"wheel": truck}
	if thing in ["turntable", "basket"]:
		var ladder: = LadderService.current
		ladder.sit(player, thing == "basket")
		await get_tree().create_timer(0.5).timeout
		var seat_from: = player.seat.global_transform.affine_inverse()
		for node in ladder.vehicle.find_children("*", "MeshInstance3D", true, false):
			var mesh: = node as MeshInstance3D
			if mesh.is_visible_in_tree() and not player.is_ancestor_of(mesh):
				var box: = seat_from * mesh.global_transform * mesh.get_aabb()
				if box.get_center().length() < 5.0 or box.size.length() > 6.0 and box.grow(0.5).has_point(Vector3(0, 3, -1.5)):
					print("handlook: near the seat ", mesh.name, " ", box)
		return {"ladder": ladder}
	if thing == "divider":
		HoseService.current._carry_divider(player)
		return {"divider": true}
	if thing in ["Cones", "Barrier tape"] and Cordon.current:
		for one: Dictionary in Cordon.current.items:
			if one["name"] == thing and one["holder"] == null:
				Cordon.current._take(one, player)
				return {"cordon": one}
	for one: Dictionary in ToolService.current.items:
		if one["name"] == thing and one["holder"] == null and not one["standing"]:
			ToolService.current._on_line(player, one)
			return one
	print("handlook: no %s to take" % thing)
	return {}


func _give_back(thing: String, item: Dictionary) -> void :
	if item.has("nozzle"):
		HoseService.current.disconnect_line(HoseService.current.lines[0])
	elif item.has("roll"):
		HoseService.current._return_roll(Game.local_player)
	elif item.has("cordon"):
		Cordon.current.put_back(item["cordon"])
	elif item.has("carry"):
		VictimService.current.put_down(item["carry"])
		VictimService.current._discard(item["carry"].figure)
	elif item.has("ladder"):
		item["ladder"].leave(Game.local_player)
	elif item.has("wheel"):
		item["wheel"].leave(Game.local_player)
	elif item.has("divider"):
		pass
	elif not item.is_empty():
		ToolService.current._on_line(Game.local_player, item)


func _house() -> House:
	var best: House = null
	var best_distance: = INF
	for building in FireService.current.buildings:
		if building is House and building.name.begins_with("Family house") and not building.ruined:
			var distance: float = building.position.distance_to(Vector3(120, 0, 40))
			if distance < best_distance:
				best = building
				best_distance = distance
	return best



func _stand_outside(house: Building, point: Vector3, off: float) -> void :
	var player: = Game.local_player
	var out: = Vector3(point.x - house.position.x, 0, point.z - house.position.z)
	var across: Vector3 = house.place.basis.x if house.place != Transform3D.IDENTITY else Vector3.RIGHT
	var deep: Vector3 = house.place.basis.z if house.place != Transform3D.IDENTITY else Vector3.BACK
	var half: = Vector3(out.dot(across), 0, out.dot(deep))
	out = (across * signf(half.x) if absf(half.x) > absf(half.z) else deep * signf(half.z))
	out = Vector3(out.x, 0, out.z).normalized()
	var from: = point + out * off
	var hit: = Game.world.raycast(from + Vector3(0, 40, 0), from - Vector3(0, 80, 0), World.LAYER_SOLID)
	player.teleport((hit["position"] if not hit.is_empty() else from) + Vector3(0, 0.3, 0))
	player.camera.yaw = atan2(out.x, out.z)
	player.camera.pitch = -0.1
	player.rig.rotation.y = player.camera.yaw



func _views(base: String, eyes: bool) -> void :
	var player: = Game.local_player
	var gaps: Array = player.rig.gaps()
	print("handlook: %s gap right %.3f left %.3f, hold '%s', reach %s, act %s" % [base.get_file(), gaps[0], gaps[1], FirefighterRig.hold_kind(player.rig.held()), player.rig.reach_need, player.rig.hands_at])
	if eyes:
		if player.seat != null:
			player.camera.driver_view = true
			await get_tree().create_timer(0.3).timeout
		player.camera.camera.make_current()
		await _shot(base + "_eyes.png")
		if player.seat == null:

			var level: = player.camera.pitch
			for look: Array in [["down", -0.85], ["feet", -1.35]]:
				player.camera.pitch = float(look[1])
				await get_tree().create_timer(0.3).timeout
				await _shot(base + "_eyes_%s.png" % look[0])
			player.camera.pitch = level
		if player.seat != null:

			player.camera.pitch = -0.45
			await _shot(base + "_eyes_down.png")
			var truck: = player.seat.get_parent().get_parent() as Vehicle
			truck.set_process(false)
			for turn: float in [0.6, -1.6]:
				truck._steering_wheel.rotation.z = turn
				await get_tree().create_timer(0.4).timeout
				await _shot(base + "_eyes_turn%d.png" % int(turn * 10))
				print("handlook: wheel turned %.1f, gaps %s" % [turn, player.rig.gaps()])
			truck.set_process(true)

			player.camera.pitch = -0.12
			var ahead: = player.camera.yaw
			for look: Array in [["left", 0.95], ["right", -0.75]]:
				player.camera.yaw = ahead + float(look[1])
				await get_tree().create_timer(0.5).timeout
				await _shot(base + "_eyes_%s.png" % look[0])
			player.camera.yaw = ahead
			player.camera.pitch = -0.06
		player.camera.driver_view = false
		return
	var facing: Basis = player.rig.global_basis
	var chest: = player.global_position + Vector3(0, 3.4, 0)
	var views: = [["front", Vector3(4.5, 1.2, -8.0)], ["side", Vector3(9.0, 0.8, -1.0)], ["back", Vector3(-3.5, 2.5, 8.5)]]
	if player.seat != null and not player.seat.has_meta("wheel"):
		views = [["front", Vector3(2.5, 4.5, -7.0)], ["side", Vector3(7.0, 4.0, -1.0)], ["back", Vector3(-2.5, 6.0, 6.0)]]
	elif player.seat != null:
		chest = player.rig.global_transform * Vector3(0, 1.6, 0)
		views = [["front", Vector3(2.5, 1.0, -8.5)], ["passenger", Vector3(8.5, 0.5, -1.5)], ["behind", Vector3(4.0, 3.5, 6.5)]]
		chest = player.rig.global_transform * Vector3(0, 2.4, -0.6)
	if base.contains("_force_"):
		views = [["side", Vector3(9.0, 0.8, -1.0)], ["left", Vector3(-9.0, 0.8, -1.0)], ["back", Vector3(-3.5, 2.5, 8.5)]]

	var hidden: Array[Node3D] = []
	if player.seat != null and player.seat.has_meta("wheel"):
		var wheel: Node3D = player.seat.get_meta("wheel")
		for node in player.seat.get_parent().find_children("*", "GeometryInstance3D", true, false):
			if (node as Node3D).visible and not wheel.is_ancestor_of(node) and not player.is_ancestor_of(node):
				node.visible = false
				hidden.append(node)
	for view: Array in views:
		_camera.look_at_from_position(chest + facing * (view[1] as Vector3), chest)
		_camera.make_current()
		await _shot(base + "_" + view[0] + ".png")
	if not hidden.is_empty():

		var truck: = player.seat.get_parent().get_parent() as Vehicle
		truck.set_process(false)
		for turn: float in [0.6, -1.6]:
			truck._steering_wheel.rotation.z = turn
			await get_tree().create_timer(0.3).timeout
			_camera.look_at_from_position(chest + facing * (views[0][1] as Vector3), chest)
			await _shot(base + "_turn%d.png" % int(turn * 10))
		truck.set_process(true)
	for node in hidden:
		node.visible = true
	player.camera.camera.make_current()


func _holds() -> void :
	await get_tree().create_timer(1.5).timeout
	_camera = Camera3D.new()
	_camera.fov = 45
	add_child(_camera)
	if Hud.current:
		Hud.current.visible = false
	var player: = Game.local_player
	var things: = _arg("--hand-tools=", "Axe,Halligan bar,Crowbar,Bolt cutters,Spreader,Cutter,Chainsaw,Extinguisher,Floodlight,Fan,Thermal camera,nozzle").split(",")
	var acts: = _arg("--hand-act=", "idle").split(",")
	Player.force_stand = float(_arg("--hand-stand=", str(Player.FORCE_STAND)))
	var home: = player.global_position
	var passes: Array = {"eyes": [true], "body": [false]}.get(_arg("--hand-views=", ""), [false, true])
	for eyes: bool in passes:
		player.camera.wanted_distance = 0.0 if eyes else 16.0
		for thing: String in things:
			for act: String in acts:
				player.teleport(home)
				player.camera.pitch = -0.15
				await get_tree().create_timer(0.3).timeout
				var item: Dictionary = await _take(thing)
				if item.is_empty():
					continue
				await get_tree().create_timer(0.8).timeout
				var base: = _prefix + "_" + thing.replace(" ", "_").to_lower() + "_" + act
				match act:
					"idle":
						await _views(base, eyes)
					"walk":
						Input.action_press("move_forward")
						await get_tree().create_timer(0.55).timeout
						await _views(base, eyes)
						Input.action_release("move_forward")
					"work":
						await get_tree().process_frame
						Input.action_press("fire")
						await get_tree().create_timer(1.0).timeout
						await _views(base, eyes)
						Input.action_release("fire")
					"swing":
						if item.has("next_swing"):
							for at: float in [0.15, 0.32, 0.5, 0.62]:
								Holds.debug_phase = at
								item["next_swing"] = 0.0
								ToolService.current._swing(item, player)
								await get_tree().create_timer(0.15).timeout
								await _views(base + "_%02d" % int(at * 100), eyes)
							Holds.debug_phase = -1.0
					"place":
						await get_tree().process_frame
						Input.action_press("fire")
						await get_tree().create_timer(0.15).timeout
						await _views(base + "_15", eyes)
						await get_tree().create_timer(0.1).timeout
						await _views(base + "_35", eyes)
						Input.action_release("fire")
						await get_tree().create_timer(0.6).timeout
						for one: Dictionary in ToolService.current.items:
							if one["standing"]:
								ToolService.current._pick_up(one, player)
						await get_tree().create_timer(0.3).timeout
					"tap", "hold", "low":

						var spot: = Node3D.new()
						add_child(spot)
						var ahead: = - player.rig.global_basis.z
						var height: = {"tap": 3.6, "hold": 3.0, "low": 0.4}[act] as float
						spot.global_position = player.global_position + ahead * (3.0 if act != "low" else 2.6) + Vector3(0, height, 0)
						var prompt: = Prompt.make(spot, "Test", "", 0.0 if act == "tap" else 3.0, 8.0)
						await get_tree().create_timer(0.3).timeout
						await get_tree().process_frame
						Input.action_press("interact")
						for at: float in ([0.1, 0.2, 0.35] if act == "tap" else [0.4, 1.0]):
							await get_tree().create_timer(at - (0.0 if at == 0.1 or at == 0.4 else (0.1 if act == "tap" and at == 0.2 else (0.2 if act == "tap" else 0.4)))).timeout
							await _views(base + "_%02d" % int(at * 100), eyes)
						Input.action_release("interact")
						await get_tree().create_timer(0.5).timeout
						spot.queue_free()
					"force":
						var house: = _house()
						house.lock_up(true)
						var door: Dictionary = house.outside_door()
						_stand_outside(house, door["lock"].global_position, 4.0)
						await get_tree().create_timer(0.8).timeout
						print("handlook: at the door, offered '%s', hold %.1f" % [Text.say(player.prompt.action, "en") if player.prompt != null else "nothing", player.prompt.hold if player.prompt != null else -1.0])
						await get_tree().process_frame
						Input.action_press("interact")
						var started: = Game.now()
						await get_tree().create_timer(0.5).timeout
						for at: float in [0.0, 0.45, 0.6, 0.75]:
							Holds.debug_phase = at
							await get_tree().create_timer(0.12).timeout
							await _views(base + "_%02d" % int(at * 100), eyes)
						Holds.debug_phase = -1.0
						await get_tree().create_timer(maxf(0.0, float(Config.Tools.ForceTime) + 0.3 - (Game.now() - started))).timeout
						Input.action_release("interact")
						await get_tree().create_timer(0.6).timeout
						house._restore_door(door) if door["burnt"] else null
						house._swing(door, false, false)
						await get_tree().create_timer(0.8).timeout
				_give_back(thing, item)
				await get_tree().create_timer(0.4).timeout
	Game.quit()



func _bench() -> void :
	await get_tree().create_timer(1.5).timeout
	var player: = Game.local_player
	var started: = Time.get_ticks_usec()
	ToolModels._made.clear()
	for tool_name in ["Axe", "Halligan bar", "Crowbar", "Bolt cutters", "Spreader", "Cutter", "Chainsaw", "Extinguisher", "Floodlight", "Fan", "Thermal camera", "Divider", "Cone", "Tape post", "Tape reel", "Attack roll", "Supply roll"]:
		var made: = ToolModels.of(tool_name)
		var triangles: = 0
		var surfaces: = 0
		for part: String in made:
			var mesh: ArrayMesh = made[part]
			surfaces += mesh.get_surface_count()
			for index in mesh.get_surface_count():
				triangles += mesh.surface_get_array_len(index) / 3
		print("handlook bench: %s %d triangles, %d surfaces" % [tool_name, triangles, surfaces])
	print("handlook bench: every model built in %.1f ms" % ((Time.get_ticks_usec() - started) / 1000.0))
	for thing: String in ["", "Axe", "Chainsaw", "nozzle", "Extinguisher"]:
		var item: Dictionary = await _take(thing) if not thing.is_empty() else {}
		await get_tree().create_timer(0.6).timeout
		if thing == "Extinguisher":
			Input.action_press("fire")
			await get_tree().create_timer(0.5).timeout
		var t0: = Time.get_ticks_usec()
		for index in 2000:
			player.rig._reach(0.016)
		var each: = (Time.get_ticks_usec() - t0) / 2000.0
		print("handlook bench: hands with '%s': %.1f us a frame" % [thing, each])
		Input.action_release("fire")
		if not item.is_empty():
			_give_back(thing, item)
		await get_tree().create_timer(0.4).timeout
	Game.quit()




func _suit() -> void :
	await get_tree().create_timer(1.5).timeout
	var player: = Game.local_player
	if not GearService.current.is_geared(player):
		GearService.current._gear_up(player, null, true)
	await get_tree().create_timer(0.3).timeout
	ChemSuit.current._on_line(player)
	await get_tree().create_timer(0.3).timeout
	print("handlook: suit on %s, yellow pieces %d" % [ChemSuit.wearing(player), _yellow(player)])
	GearService.current.add_soot(player, 0.6)
	await get_tree().create_timer(1.0).timeout
	ChemSuit.current._on_line(player)
	await get_tree().create_timer(0.5).timeout
	print("handlook: suit off %s, yellow pieces %d" % [ not ChemSuit.wearing(player), _yellow(player)])
	Game.quit()


func _yellow(player: Player) -> int:
	var count: = 0
	for sheet: String in player.rig.pieces:
		for mesh: MeshInstance3D in player.rig.pieces[sheet]:
			if not mesh.visible:
				continue
			for surface in mesh.get_surface_override_material_count():
				var material: = mesh.get_active_material(surface) as BaseMaterial3D

				if material != null and is_equal_approx(material.roughness, 0.45) and is_equal_approx(material.metallic_specular, 0.6):
					count += 1
	return count
