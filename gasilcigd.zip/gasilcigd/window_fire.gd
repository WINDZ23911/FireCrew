class_name WindowFire
extends Node3D








const LOOK_EVERY: = 0.3
const REACH: = 260.0

static var current: WindowFire

var _since: = 0.0
var _flames: Array[MeshInstance3D] = []
var _glows: Array[MeshInstance3D] = []
var _soots: Array[Decal] = []
var _glow_mesh: QuadMesh
var _glow_material: ShaderMaterial
static var _soot_picture: ImageTexture


var shown: = {"flames": 0, "glows": 0, "soots": 0, "flame_panes": [], "glow_panes": []}


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var look: Dictionary = Config.Art.WindowFire
	for index in int(look["Flames"]):
		var card: = MeshInstance3D.new()
		card.mesh = ToonFire.card()
		card.material_override = ToonFire.flame_material()
		card.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		card.custom_aabb = AABB(Vector3(-8, -1, -8), Vector3(16, 14, 16))
		card.set_instance_shader_parameter("seed", 40.0 + index * 2.9)
		card.set_instance_shader_parameter("pull", 0.0)
		card.visible = false
		add_child(card)
		_flames.append(card)
	_glow_mesh = QuadMesh.new()
	_glow_mesh.size = Vector2.ONE
	_glow_material = ShaderMaterial.new()
	_glow_material.shader = load("res://shaders/glass_glow.gdshader")
	for index in int(look["Glows"]):
		var glow: = MeshInstance3D.new()
		glow.mesh = _glow_mesh
		glow.material_override = _glow_material
		glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		glow.set_instance_shader_parameter("seed", index * 1.7)
		glow.visible = false
		add_child(glow)
		_glows.append(glow)
	for index in int(look["Soots"]):
		var decal: = Decal.new()
		decal.texture_albedo = _soot()
		decal.cull_mask = 1
		decal.upper_fade = 0.05
		decal.lower_fade = 0.3
		decal.visible = false
		add_child(decal)
		_soots.append(decal)


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var camera: = get_viewport().get_camera_3d()
	var eye: = camera.global_position if camera != null else Vector3.ZERO
	var look: Dictionary = Config.Art.WindowFire
	var flames: Array = []
	var glows: Array = []
	var soots: Array = []
	for house: House in House.all:
		if not is_instance_valid(house) or house.holder == null or house.position.distance_to(eye) > REACH:
			continue
		var heat: = _heat(house)
		for room_name: String in house.rooms:
			var room: Dictionary = house.rooms[room_name]
			var hot: float = heat.get(room_name, 0.0)
			var scorch: = float(room.get("scorch", 0.0))
			if hot <= 0.0 and scorch <= 0.0:
				continue
			for pane: Dictionary in room["panes"]:
				var near: = 1.0 - clampf((pane["position"] as Vector3).distance_to(eye) / REACH, 0.0, 1.0)
				if pane["broken"]:
					if hot >= float(look["FlameFrom"]):
						flames.append([hot + near, pane, hot, house, room])
					if scorch >= float(look["SootFrom"]):
						soots.append([scorch + near, pane, scorch, house, room])
				elif hot >= float(look["GlowFrom"]):
					glows.append([hot + near, pane, hot, house, room])
	var by_score: = func(a: Array, b: Array) -> bool: return a[0] > b[0]
	flames.sort_custom(by_score)
	glows.sort_custom(by_score)
	soots.sort_custom(by_score)
	for index in _flames.size():
		_flames[index].visible = index < flames.size()
		if index < flames.size():
			_place_flame(_flames[index], flames[index])
	for index in _glows.size():
		_glows[index].visible = index < glows.size()
		if index < glows.size():
			_place_glow(_glows[index], glows[index])
	for index in _soots.size():
		_soots[index].visible = index < soots.size()
		if index < soots.size():
			_place_soot(_soots[index], soots[index])
	shown = {
		"flames": mini(flames.size(), _flames.size()), "glows": mini(glows.size(), _glows.size()), 
		"soots": mini(soots.size(), _soots.size()), 
		"flame_panes": flames.slice(0, _flames.size()).map( func(entry: Array) -> int: return int(entry[1]["id"])), 
		"glow_panes": glows.slice(0, _glows.size()).map( func(entry: Array) -> int: return int(entry[1]["id"])), 
	}



static func _heat(house: House) -> Dictionary:
	var heat: Dictionary = {}
	for flame in Flame.all:
		if not is_instance_valid(flame) or not flame.is_inside_tree() or flame.global_position.distance_to(house.position) > 80.0:
			continue
		var inside: Variant = house.room_at(flame.global_position)
		if inside != null:
			heat[inside["name"]] = heat.get(inside["name"], 0.0) + 0.25 + 0.75 * flame.intensity
	return heat




static func frame(house: House, room: Dictionary, pane: Dictionary) -> Array:
	var place: Transform3D = (pane["node"] as Node3D).global_transform
	var size: Vector3 = pane["size"]
	var axes: = [place.basis.x.normalized(), place.basis.y.normalized(), place.basis.z.normalized()]
	var sizes: = [size.x, size.y, size.z]
	var thin: = 0
	for index in 3:
		if sizes[index] < sizes[thin]:
			thin = index
	var out: Vector3 = axes[thin]
	var middle: Vector3 = house.lot * (((room["low"] as Vector3) + (room["high"] as Vector3)) / 2.0)
	if out.dot(place.origin - middle) < 0.0:
		out = - out
	var up_axis: = -1
	for index in 3:
		if index != thin and (up_axis < 0 or absf((axes[index] as Vector3).y) > absf((axes[up_axis] as Vector3).y)):
			up_axis = index
	var across_axis: = 3 - thin - up_axis
	return [place.origin, out, Vector3.UP, (axes[across_axis] as Vector3), float(sizes[across_axis]), float(sizes[up_axis]), float(sizes[thin])]



func _place_flame(card: MeshInstance3D, entry: Array) -> void :
	var look: Dictionary = Config.Art.WindowFire
	var f: = frame(entry[3], entry[4], entry[1])
	var hot: = clampf(float(entry[2]) / float(look["FullAt"]), 0.0, 1.0)
	var wide: = minf(float(f[4]) * 0.9, 1.6 + 1.8 * hot)
	var tall: = float(f[5]) * (0.9 + 1.1 * hot)
	card.global_position = (f[0] as Vector3) - Vector3(0, float(f[5]) * 0.45, 0) + (f[1] as Vector3) * (0.35 + 0.2 * wide)
	card.set_instance_shader_parameter("height", tall)
	card.set_instance_shader_parameter("width", wide)
	card.set_instance_shader_parameter("speed", 0.5 + 0.5 * hot)
	card.set_instance_shader_parameter("lean", (f[1] as Vector3) * float(look["Lean"]))



func _place_glow(glow: MeshInstance3D, entry: Array) -> void :
	var look: Dictionary = Config.Art.WindowFire
	var f: = frame(entry[3], entry[4], entry[1])
	var out: Vector3 = f[1]
	var across: Vector3 = f[3]
	var basis: = Basis(across * float(f[4]), Vector3.UP * float(f[5]), out)
	glow.global_transform = Transform3D(basis, (f[0] as Vector3) + out * (float(f[6]) * 0.5 + 0.04))
	var hot: = clampf((float(entry[2]) - float(look["GlowFrom"])) / maxf(float(look["FullAt"]) - float(look["GlowFrom"]), 0.01), 0.0, 1.0)
	glow.set_instance_shader_parameter("strength", float(look["Glow"]) * (0.35 + 0.65 * hot))



func _place_soot(decal: Decal, entry: Array) -> void :
	var look: Dictionary = Config.Art.WindowFire
	var f: = frame(entry[3], entry[4], entry[1])
	var out: Vector3 = f[1]
	var high: = float(look["SootHeight"])

	var y_axis: = out
	var z_axis: = Vector3.UP
	var x_axis: = y_axis.cross(z_axis).normalized()
	var at: = (f[0] as Vector3) + Vector3(0, float(f[5]) * 0.5 + high * 0.5 - 0.6, 0)
	decal.global_transform = Transform3D(Basis(x_axis, y_axis, z_axis), at)
	decal.size = Vector3(float(f[4]) * 1.7, 2.4, high)
	decal.modulate = Color(1, 1, 1, clampf(float(entry[2]) * 1.2, 0.0, 0.92))




static func _soot() -> ImageTexture:
	if _soot_picture == null:
		var picture: = Image.create(64, 128, false, Image.FORMAT_RGBA8)
		var noise: = FastNoiseLite.new()
		noise.frequency = 0.05
		noise.seed = 77
		for y in 128:
			var up: = float(y) / 127.0

			var half: = (0.3 + 0.1 * up) * sqrt(clampf(1.0 - pow(up / 0.92, 3.0), 0.0, 1.0))
			for x in 64:
				var across: = absf(float(x) / 63.0 - 0.5)
				var wobble: = noise.get_noise_2d(x * 2.0, y * 0.8) * 0.07
				var edge: = half + wobble * (0.4 + up) - across
				var alpha: = 0.0
				if edge > 0.07 and up < 0.62:
					alpha = 0.92
				elif edge > 0.0:
					alpha = 0.5
				picture.set_pixel(x, y, Color(0.03, 0.026, 0.024, alpha))
		picture.generate_mipmaps()
		_soot_picture = ImageTexture.create_from_image(picture)
	return _soot_picture
