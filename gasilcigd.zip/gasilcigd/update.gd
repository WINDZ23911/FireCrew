extends ProofDebug






func _scenario_updateline() -> void :
	await _wait(1.0)
	var title: = TitleScreen.new()
	get_tree().current_scene.add_child(title)
	await _wait(2.5)
	var screen: = get_viewport().get_visible_rect()
	_check( not title._update_card.visible, "no update card while there is nothing to say (%s)" % Updater.state)
	var version_rect: = title._version_line.get_global_rect()
	print("update: version line '%s' at %s" % [title._version_line.text, version_rect])
	_check(Net.base_version() in title._version_line.text and screen.encloses(version_rect) and version_rect.size.x > 0.0, "the version played is in the corner")
	var keys: Label = title._keys
	var keys_end: = keys.get_global_rect().position.x + keys.get_theme_font("font").get_string_size(keys.text, HORIZONTAL_ALIGNMENT_LEFT, -1, keys.get_theme_font_size("font_size")).x
	_check(keys_end + 24.0 < version_rect.position.x, "the version keeps clear of the keys line (it ends at %.0f)" % keys_end)
	Updater.target = "0.4.1"
	Updater.latest = "0.5.0"
	for state: String in ["downloading", "ready", "full"]:
		Updater.state = state
		Updater.progress = 0.42
		Updater.changed.emit()
		await _wait(0.3)
		var card: Control = title._update_card
		var rect: = card.get_global_rect()
		print("update: %s -> '%s' / '%s' at %s" % [state, title._update_note.text, title._update.text, rect])
		_check(card.is_visible_in_tree() and screen.encloses(rect) and rect.size.x > 0.0, "the %s card is on screen" % state)
		_check(rect.end.y <= title._play.get_global_rect().position.y, "the %s card is above the way in" % state)
		var steps_top: float = screen.size.y - 100.0
		_check(title._discord.get_global_rect().end.y < steps_top, "with the %s card up the menu still ends above the steps (%.0f)" % [state, title._discord.get_global_rect().end.y])
		_check(title._update.is_visible_in_tree() == (state != "downloading"), "the %s card has a button only once there is something to do" % state)
		_check(title._update_bar.is_visible_in_tree() == (state == "downloading"), "the %s card shows how far the download is only while it comes down" % state)
		await _snap("title_" + state)
	var was: = Text.language
	Settings.set_language("en" if was == "sl" else "sl")
	await _wait(0.3)
	print("update: in %s '%s'" % [Text.language, title._update_note.text])
	_check(("NEW VERSION" if was == "sl" else "RAZLIČICA") in title._update_note.text, "the card follows the language")
	await _snap("title_full_" + Text.language)
	Settings.set_language(was)
	Updater.state = "off"
	Updater.changed.emit()
	_done()
