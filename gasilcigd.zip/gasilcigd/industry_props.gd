class_name IndustryProps
extends RefCounted





const WHITE: = Color8(232, 232, 226)
const STEEL: = Color8(120, 124, 130)
const DARK: = Color8(60, 64, 70)
const ORANGE: = Color8(236, 120, 30)
const RED: = Color8(196, 36, 32)
const YELLOW: = Color8(240, 196, 40)
const CONCRETE: = Color8(150, 150, 146)
const BED: = Color8(128, 122, 114)
const SLEEPER: = Color8(96, 78, 62)
const RAIL: = Color8(150, 150, 154)





static func tank_farm(kit: PolishKit, parent: int, plot: Dictionary) -> void :
	if plot.is_empty():
		return
	var folder: = kit.own_folder("TankFarm")
	var x: float = plot["x"]

	var x0: = x - 40.0
	var x1: = x + 38.0
	var z0: = 1046.0
	var z1: = 1098.0
	kit.box(folder, Transform3D(Basis(), Vector3((x0 + x1) / 2.0, 0.3, (z0 + z1) / 2.0)), Vector3(x1 - x0, 0.36, z1 - z0), CONCRETE, "Concrete", "BundFloor", PolishKit.SOLID)
	for wall: Array in [[x0, z0, x1, z0], [x0, z1, x1, z1], [x0, z0, x0, z1], [x1, z0, x1, z1]]:
		var a: = Vector3(wall[0], 0, wall[1])
		var b: = Vector3(wall[2], 0, wall[3])
		var middle: = (a + b) / 2.0
		var size: = Vector3(absf(b.x - a.x) + 0.8, 3.0, absf(b.z - a.z) + 0.8)
		kit.box(folder, Transform3D(Basis(), middle + Vector3(0, 1.5, 0)), size, CONCRETE, "Concrete", "BundWall", PolishKit.SOLID)

	for step in 3:
		kit.box(folder, Transform3D(Basis(), Vector3(x + 20.0, 0.5 + step, z1 + 1.6 + (2 - step) * 1.0)), Vector3(4.0, 1.0, 1.0), CONCRETE, "Concrete", "BundStep", PolishKit.SOLID)
	var tanks: Array = []
	var number: = 1
	for dz: float in [1059.0, 1085.0]:
		for dx: float in [-21.0, 17.0]:
			var foot: = Vector3(x + dx, 0.48, dz)
			_tank(kit, folder, foot, 16.0, 24.0, number)
			tanks.append(foot)
			number += 1

	var rack_z: = 1104.0
	for dx: float in [-28.0, -10.0, 8.0, 26.0]:
		kit.post(folder, Vector3(x + dx, 0, rack_z), 7.0, 0.6, STEEL, "Metal", "PipeRackPost", PolishKit.SOLID)
	for lane in 3:
		var y: = 5.2 + lane * 0.9
		kit.rod(folder, Vector3(x - 30.0, y, rack_z), Vector3(x + 28.0, y, rack_z), 0.7, [Color8(200, 190, 60), WHITE, Color8(150, 60, 40)][lane], "Metal", "Pipe")
	for tank: Vector3 in tanks:
		var out: = Vector3(tank.x, 1.6, z1 - 1.0)
		kit.rod(folder, Vector3(tank.x, 1.6, tank.z + 8.0), out, 0.6, WHITE, "Metal", "Pipe")
		kit.rod(folder, out, Vector3(tank.x, 5.2, rack_z), 0.6, WHITE, "Metal", "Pipe")

	kit.box(folder, Transform3D(Basis(), Vector3(x - 4.0, 0.4, rack_z + 6.0)), Vector3(18.0, 0.8, 6.0), CONCRETE, "Concrete", "PumpPlinth", PolishKit.SOLID)
	for dx: float in [-9.0, -1.0]:
		kit.box(folder, Transform3D(Basis(), Vector3(x + dx, 2.2, rack_z + 6.0)), Vector3(3.6, 2.8, 2.6), Color8(40, 110, 170), "Metal", "Pump", PolishKit.SOLID)
		kit.rod(folder, Vector3(x + dx, 3.6, rack_z + 6.0), Vector3(x + dx, 5.2, rack_z), 0.5, WHITE, "Metal", "Pipe")
	var manifold: = Vector3(x + 7.0, 3.8, rack_z + 6.0)
	kit.rod(folder, manifold + Vector3(-3.0, 0, 0), manifold + Vector3(3.0, 0, 0), 1.0, WHITE, "Metal", "Manifold")
	kit.rod(folder, manifold + Vector3(0, 0, 0), manifold + Vector3(0, 1.4, 0), 0.25, STEEL, "Metal", "ValveStem")
	var wheel: = Transform3D(Basis(Vector3.BACK, PI / 2), manifold + Vector3(0, 1.5, 0))
	kit.store.add(PartStore.Shape.CYLINDER, wheel, Vector3(0.18, 1.8, 1.8), RED, "Metal", "TankValve", folder, PolishKit.FIXTURE)
	IndustryZone.places["valve.tanks"] = manifold + Vector3(0, 1.5, 0)

	var bay: = Vector3(x - 26.0, 0, 1114.0)
	for dx: float in [-8.0, 8.0]:
		for dz: float in [-9.0, 9.0]:
			kit.post(folder, bay + Vector3(dx, 0, dz), 13.0, 0.8, STEEL, "Metal", "GantryPost", PolishKit.SOLID)
	kit.box(folder, Transform3D(Basis(), bay + Vector3(0, 13.4, 0)), Vector3(18.0, 0.8, 20.0), WHITE, "Metal", "GantryRoof")
	kit.box(folder, Transform3D(Basis(), bay + Vector3(-6.0, 10.0, 0)), Vector3(2.0, 1.0, 16.0), Color8(200, 190, 60), "Metal", "LoadingArm")
	var tanker: = Transform3D(Basis(Vector3.UP, PI / 2), bay + Vector3(0, 0, 0))
	road_tanker(kit, folder, tanker)
	IndustryZone.places["tanker"] = bay + Vector3(0, 5.0, 0)
	IndustryZone.places["tanks"] = tanks

	_warning(kit, folder, Vector3(x + 26.0, 0, z1 + 1.2), "VNETLJIVO\nPREPOVEDANO KAJENJE")
	_warning(kit, folder, Vector3(x - 34.0, 0, z1 + 1.2), "NEVARNOST\nEKSPLOZIJE")




static func _tank(kit: PolishKit, parent: int, foot: Vector3, width: float, height: float, number: int) -> void :
	kit.post(parent, foot, height, width, WHITE, "Metal", "Tank", PolishKit.SOLID)
	kit.post(parent, foot + Vector3(0, height, 0), 0.6, width + 0.3, Color8(200, 200, 196), "Metal", "TankRoof")
	kit.post(parent, foot + Vector3(0, height + 0.6, 0), 0.8, width * 0.55, Color8(200, 200, 196), "Metal", "TankRoof")
	kit.post(parent, foot + Vector3(0, height + 1.4, 0), 1.2, 0.9, STEEL, "Metal", "TankVent")
	var r: = width / 2.0
	for index in 12:
		var a: = TAU * index / 12.0
		var b: = TAU * (index + 1) / 12.0
		var pa: = foot + Vector3(cos(a) * r, height + 3.4, sin(a) * r)
		var pb: = foot + Vector3(cos(b) * r, height + 3.4, sin(b) * r)
		kit.rod(parent, pa, pb, 0.16, YELLOW, "Metal", "TankRail")
		kit.rod(parent, pa, pa - Vector3(0, 2.8, 0), 0.12, YELLOW, "Metal", "TankRailPost")

	var face: = foot + Vector3(0, 0, r + 0.9)
	for side: float in [-0.8, 0.8]:
		kit.rod(parent, face + Vector3(side, 0, 0), face + Vector3(side, height + 3.4, 0), 0.14, STEEL, "Metal", "LadderRail")
	var rung: = 1.0
	while rung < height + 3.0:
		kit.rod(parent, face + Vector3(-0.8, rung, 0), face + Vector3(0.8, rung, 0), 0.1, STEEL, "Metal", "LadderRung")
		rung += 1.2
	var hoop: = 8.0
	while hoop < height + 3.0:
		for index in 6:
			var a: = PI * index / 6.0
			var b: = PI * (index + 1) / 6.0
			kit.rod(parent, face + Vector3(cos(a) * 1.4, hoop, sin(a) * 1.4), face + Vector3(cos(b) * 1.4, hoop, sin(b) * 1.4), 0.08, STEEL, "Metal", "LadderHoop")
		hoop += 3.0
	var plate: = Transform3D(Basis(Vector3.UP, PI), foot + Vector3(2.8, 6.0, r + 0.08))
	StreetKit.board(kit, parent, plate, Vector2(2.4, 1.6), ORANGE, "33\n1203", Color8(20, 20, 20), "AdrPlate")
	StreetKit.board(kit, parent, plate.translated_local(Vector3(-5.6, 2.6, 0)), Vector2(3.2, 2.0), WHITE, "T%d" % number, Color8(30, 40, 60), "TankNumber")



static func road_tanker(kit: PolishKit, parent: int, place: Transform3D) -> void :
	tractor_unit(kit, parent, place * Transform3D(Basis(), Vector3(0, 0, -15.0)), Color8(200, 40, 40), "Tanker")
	var metal: = Color8(220, 222, 224)
	kit.box(parent, place * Transform3D(Basis(), Vector3(0, 2.6, 2.0)), Vector3(3.0, 1.0, 26.0), DARK, "Metal", "TankerChassis", PolishKit.SOLID)

	var shell: = place * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(0, 6.6, 2.0))
	kit.store.add(PartStore.Shape.CYLINDER, shell, Vector3(24.0, 8.4, 8.4), metal, "Metal", "TankerShell", parent, PolishKit.SOLID)
	for end: float in [-1.0, 1.0]:
		kit.store.add(PartStore.Shape.ELLIPSOID, place * Transform3D(Basis(), Vector3(0, 6.6, 2.0 + end * 12.0)), Vector3(8.4, 8.4, 2.4), metal, "Metal", "TankerEnd", parent, PolishKit.LOOK)
	for band: float in [-6.0, 0.0, 6.0]:
		kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(0, 6.6, 2.0 + band)), Vector3(0.3, 8.6, 8.6), metal.darkened(0.12), "Metal", "TankerBand", parent, PolishKit.LOOK)
	kit.box(parent, place * Transform3D(Basis(), Vector3(0, 10.9, 2.0)), Vector3(1.6, 0.2, 22.0), STEEL, "DiamondPlate", "TankerWalkway")
	for side: float in [-1.0, 1.0]:
		kit.rod(parent, place * Vector3(side * 1.0, 12.2, -8.0), place * Vector3(side * 1.0, 12.2, 12.0), 0.12, YELLOW, "Metal", "TankerRail")
	for hatch: float in [-6.0, 0.0, 6.0]:
		kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(Basis(Vector3.BACK, PI / 2), Vector3(0, 11.0, 2.0 + hatch)), Vector3(0.5, 1.6, 1.6), STEEL, "Metal", "TankerHatch", parent, PolishKit.LOOK)
	for side: float in [-0.6, 0.6]:
		kit.rod(parent, place * Vector3(side, 2.0, 14.6), place * Vector3(side, 10.8, 14.2), 0.12, STEEL, "Metal", "TankerLadder")

	kit.box(parent, place * Transform3D(Basis(), Vector3(0, 2.4, 6.0)), Vector3(6.4, 1.8, 3.0), STEEL, "Metal", "TankerValves")
	for side: float in [-1.0, 1.0]:
		kit.box(parent, place * Transform3D(Basis(), Vector3(side * 3.9, 2.0, 0.0)), Vector3(0.12, 0.8, 10.0), STEEL, "Metal", "SideGuard")
		kit.box(parent, place * Transform3D(Basis(), Vector3(side * 3.0, 6.8, 14.3)), Vector3(1.2, 0.5, 0.15), RED, "SmoothPlastic", "TailLight")
	kit.box(parent, place * Transform3D(Basis(), Vector3(0, 1.6, 14.4)), Vector3(7.6, 0.5, 0.5), DARK, "Metal", "RearBar")
	for dz: float in [8.0, 11.0]:
		_wheels(kit, parent, place, dz, 3.6)
		for side: float in [-1.0, 1.0]:
			kit.box(parent, place * Transform3D(Basis(), Vector3(side * 3.6, 3.4, dz)), Vector3(1.4, 0.15, 3.6), DARK, "Metal", "Mudguard")
	var plate: = place * Transform3D(Basis(Vector3.UP, PI), Vector3(0, 3.0, 14.75))
	StreetKit.board(kit, parent, plate, Vector2(2.4, 1.6), ORANGE, "33\n1203", Color8(20, 20, 20), "AdrPlate")



static func _wheels(kit: PolishKit, parent: int, place: Transform3D, dz: float, track: float) -> void :
	for side: float in [-1.0, 1.0]:
		kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(Basis(), Vector3(side * track, 1.6, dz)), Vector3(1.0, 3.2, 3.2), Color8(30, 30, 32), "Rubber", "Wheel", parent, PolishKit.LOOK)
		kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(Basis(), Vector3(side * (track + 0.12), 1.6, dz)), Vector3(0.9, 1.7, 1.7), Color8(170, 172, 176), "Metal", "Hub", parent, PolishKit.LOOK)





static func tractor_unit(kit: PolishKit, parent: int, place: Transform3D, color: Color, prefix: String) -> void :
	var at: = func(x: float, y: float, z: float) -> Transform3D:
		return place * Transform3D(Basis(), Vector3(x, y, z))
	var glass: = Color8(34, 44, 56)
	var chrome: = Color8(190, 192, 196)
	kit.box(parent, at.call(0, 5.6, -0.6), Vector3(8.0, 6.4, 6.4), color, "SmoothPlastic", prefix + "Cab", PolishKit.SOLID)
	kit.box(parent, at.call(0, 9.6, 0.0), Vector3(7.8, 1.8, 5.6), color, "SmoothPlastic", prefix + "CabRoof", PolishKit.SOLID)
	kit.wedge(parent, at.call(0, 11.6, 0.4), Vector3(7.4, 2.2, 4.4), color.lightened(0.08), "SmoothPlastic", prefix + "Deflector")
	kit.box(parent, at.call(0, 7.4, -3.85), Vector3(7.2, 2.9, 0.12), glass, "Glass", prefix + "Windscreen")
	kit.box(parent, at.call(0, 9.6, -2.85), Vector3(7.4, 1.0, 0.1), color.darkened(0.2), "SmoothPlastic", prefix + "SunVisor")
	for side: float in [-1.0, 1.0]:
		kit.box(parent, at.call(side * 4.02, 7.5, -1.6), Vector3(0.1, 2.4, 2.8), glass, "Glass", prefix + "SideWindow")
		kit.box(parent, at.call(side * 4.03, 4.4, -1.6), Vector3(0.08, 0.15, 2.0), color.darkened(0.35), "SmoothPlastic", prefix + "DoorHandle")
		kit.rod(parent, place * Vector3(side * 4.0, 8.4, -3.2), place * Vector3(side * 4.9, 8.6, -3.6), 0.12, DARK, "Metal", prefix + "MirrorArm")
		kit.box(parent, at.call(side * 5.0, 7.8, -3.6), Vector3(0.3, 1.8, 0.8), DARK, "SmoothPlastic", prefix + "Mirror")
		kit.box(parent, at.call(side * 2.9, 3.7, -3.95), Vector3(1.5, 0.7, 0.12), Color8(250, 246, 220), "Glass", prefix + "Headlight")
		kit.box(parent, at.call(side * 4.1, 2.7, -1.6), Vector3(1.0, 0.2, 1.6), DARK, "DiamondPlate", prefix + "Step")
		kit.box(parent, at.call(side * 3.6, 3.5, 0.0), Vector3(1.4, 0.2, 3.8), color.darkened(0.25), "SmoothPlastic", prefix + "Mudguard")
	kit.box(parent, at.call(0, 5.0, -3.92), Vector3(4.6, 2.6, 0.12), Color8(28, 30, 34), "Metal", prefix + "Grille")
	for slat in 4:
		kit.box(parent, at.call(0, 4.0 + slat * 0.65, -3.99), Vector3(4.6, 0.12, 0.06), chrome, "Metal", prefix + "GrilleBar")
	kit.box(parent, at.call(0, 2.4, -4.0), Vector3(8.2, 1.3, 0.9), Color8(70, 72, 78), "SmoothPlastic", prefix + "Bumper", PolishKit.SOLID)

	var along: = Basis(Vector3.UP, PI / 2)
	for side: float in [-1.0, 1.0]:
		kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(along, Vector3(side * 3.3, 2.7, 4.6)), Vector3(3.6, 1.7, 1.7), chrome, "Metal", prefix + "FuelTank", parent, PolishKit.LOOK)
	kit.post(parent, place * Vector3(3.4, 4.0, 3.0), 9.0, 0.45, chrome, "Metal", prefix + "Exhaust")
	kit.box(parent, at.call(0, 2.2, 6.0), Vector3(3.0, 1.2, 14.0), DARK, "Metal", prefix + "Chassis", PolishKit.SOLID)
	kit.store.add(PartStore.Shape.CYLINDER, place * Transform3D(Basis(Vector3.BACK, PI / 2), Vector3(0, 3.0, 9.0)), Vector3(0.3, 3.6, 3.6), Color8(40, 42, 46), "Metal", prefix + "FifthWheel", parent, PolishKit.LOOK)
	for dz: float in [0.0, 9.0, 12.0]:
		_wheels(kit, parent, place, dz, 3.6)
	for dz: float in [9.0, 12.0]:
		for side: float in [-1.0, 1.0]:
			kit.box(parent, at.call(side * 3.6, 3.4, dz), Vector3(1.4, 0.15, 3.6), DARK, "Metal", prefix + "RearMudguard")





static func curtain_trailer(kit: PolishKit, parent: int, place: Transform3D, color: Color) -> void :
	var at: = func(x: float, y: float, z: float) -> Transform3D:
		return place * Transform3D(Basis(), Vector3(x, y, z))
	kit.box(parent, at.call(0, 8.4, 0), Vector3(8.2, 9.6, 40.0), color, "Fabric", "Trailer", PolishKit.SOLID)
	kit.box(parent, at.call(0, 3.0, 0), Vector3(7.0, 1.2, 40.0), DARK, "Metal", "TrailerChassis", PolishKit.SOLID)
	kit.box(parent, at.call(0, 13.3, 0), Vector3(8.4, 0.4, 40.2), STEEL, "Metal", "TrailerTopRail")
	kit.box(parent, at.call(0, 3.8, 0), Vector3(8.4, 0.6, 40.2), STEEL, "Metal", "TrailerBottomRail")
	for side: float in [-1.0, 1.0]:
		var strap: = -18.0
		while strap <= 18.5:
			kit.box(parent, at.call(side * 4.13, 8.4, strap), Vector3(0.06, 8.8, 0.3), color.darkened(0.3), "Fabric", "CurtainStrap")
			strap += 3.0
		kit.box(parent, at.call(side * 3.9, 2.2, 2.0), Vector3(0.12, 0.8, 18.0), STEEL, "Metal", "SideGuard")
		kit.box(parent, at.call(side * 3.0, 3.4, 20.06), Vector3(1.4, 0.6, 0.12), RED, "SmoothPlastic", "TailLight")

	kit.box(parent, at.call(0, 8.4, 20.08), Vector3(8.2, 9.6, 0.12), STEEL.lightened(0.15), "Metal", "TrailerDoors")
	kit.box(parent, at.call(0, 8.4, 20.16), Vector3(0.12, 9.4, 0.06), DARK, "Metal", "DoorSplit")
	for side: float in [-1.0, 1.0]:
		kit.rod(parent, place * Vector3(side * 1.6, 4.2, 20.2), place * Vector3(side * 1.6, 12.8, 20.2), 0.14, chrome_bar(), "Metal", "DoorBar")
	kit.box(parent, at.call(0, 1.6, 19.6), Vector3(7.6, 0.5, 0.5), DARK, "Metal", "UnderrunBar")
	for dz: float in [12.0, 15.0, 18.0]:
		_wheels(kit, parent, place, dz, 3.4)
	for side: float in [-1.0, 1.0]:
		kit.box(parent, at.call(side * 1.8, 1.4, -14.0), Vector3(0.4, 2.8, 0.4), DARK, "Metal", "Landing")
		kit.box(parent, at.call(side * 1.8, 0.1, -14.0), Vector3(1.0, 0.2, 1.0), DARK, "Metal", "LandingFoot")


static func chrome_bar() -> Color:
	return Color8(190, 192, 196)



static func _warning(kit: PolishKit, parent: int, foot: Vector3, words: String) -> void :
	kit.post(parent, foot, 5.5, 0.3, STEEL, "Metal", "SignPost", PolishKit.FIXTURE)
	StreetKit.board(kit, parent, Transform3D(Basis(Vector3.UP, PI), foot + Vector3(0, 4.6, 0.2)), Vector2(3.6, 2.0), YELLOW, words, Color8(20, 20, 20), "WarningSign")





static func substation(kit: PolishKit, parent: int, plot: Dictionary) -> void :
	if plot.is_empty():
		return
	var folder: = kit.own_folder("Substation")
	var x: float = plot["x"]
	kit.box(folder, Transform3D(Basis(), Vector3(x, 0.3, 1070.0)), Vector3(70.0, 0.2, 52.0), Color8(140, 136, 128), "Pebble", "Gravel", PolishKit.SOLID)
	for dx: float in [-14.0, 14.0]:
		var at: = Vector3(x + dx, 0, 1072.0)
		kit.box(folder, Transform3D(Basis(), at + Vector3(0, 0.6, 0)), Vector3(14.0, 1.2, 12.0), CONCRETE, "Concrete", "TransformerPlinth", PolishKit.SOLID)
		kit.box(folder, Transform3D(Basis(), at + Vector3(0, 5.6, 0)), Vector3(9.0, 8.8, 7.0), Color8(96, 102, 104), "Metal", "Transformer", PolishKit.SOLID)
		for side: float in [-1.0, 1.0]:
			for fin in 7:
				kit.box(folder, Transform3D(Basis(), at + Vector3(-3.6 + fin * 1.2, 5.0, side * 4.0)), Vector3(0.15, 6.8, 1.2), Color8(90, 96, 98), "Metal", "TransformerFin")
		var tank: = Transform3D(Basis(), at + Vector3(0, 11.2, -2.4))
		kit.store.add(PartStore.Shape.CYLINDER, tank, Vector3(7.0, 2.0, 2.0), Color8(96, 102, 104), "Metal", "Conservator", folder, PolishKit.LOOK)
		for b in 3:
			var bush: = at + Vector3(-2.6 + b * 2.6, 10.0, 1.4)
			for disc in 5:
				kit.post(folder, bush + Vector3(0, disc * 0.6, 0), 0.4, 1.0 - disc * 0.06, Color8(120, 70, 40), "SmoothPlastic", "Bushing")
			kit.rod(folder, bush + Vector3(0, 3.0, 0), Vector3(bush.x, 19.0, 1052.0), 0.12, Color8(150, 150, 150), "Metal", "Conductor")

	for dx: float in [-26.0, 26.0]:
		kit.post(folder, Vector3(x + dx, 0, 1052.0), 22.0, 1.2, STEEL, "Metal", "GantryLeg", PolishKit.SOLID)
	kit.box(folder, Transform3D(Basis(), Vector3(x, 21.5, 1052.0)), Vector3(53.0, 1.2, 1.2), STEEL, "Metal", "GantryBeam")
	for dx: float in [-16.0, -2.6, 0.0, 2.6, 12.0]:
		for disc in 6:
			kit.post(folder, Vector3(x + dx, 18.6 + disc * 0.45, 1052.0), 0.3, 0.9, Color8(200, 200, 196), "SmoothPlastic", "Insulator")

	var hut: = Vector3(x + 22.0, 0, 1108.0)
	kit.box(folder, Transform3D(Basis(), hut + Vector3(0, 5.0, 0)), Vector3(20.0, 10.0, 12.0), WHITE, "Concrete", "ControlRoom", PolishKit.SOLID)
	kit.box(folder, Transform3D(Basis(), hut + Vector3(0, 10.2, 0)), Vector3(21.0, 0.6, 13.0), DARK, "Metal", "ControlRoof", PolishKit.SOLID)
	kit.box(folder, Transform3D(Basis(), hut + Vector3(-5.0, 3.6, 6.05)), Vector3(3.6, 7.2, 0.2), Color8(70, 80, 90), "Metal", "ControlDoor", PolishKit.FIXTURE)
	_warning(kit, folder, Vector3(x - 30.0, 0, 1125.0), "VISOKA NAPETOST\nŽIVLJENJSKO NEVARNO")
	_warning(kit, folder, Vector3(x + 6.0, 0, 1125.0), "VISOKA NAPETOST\nŽIVLJENJSKO NEVARNO")
	IndustryZone.places["substation"] = Vector3(x, 0, 1072.0)





static func truck_yard(kit: PolishKit, parent: int, plot: Dictionary) -> void :
	if plot.is_empty():
		return
	var folder: = kit.own_folder("TruckYard")
	var x: float = plot["x"]

	var trailers: = [[x + 12.0, Color8(232, 232, 228)], [x + 30.0, Color8(40, 70, 130)]]
	for entry: Array in trailers:
		curtain_trailer(kit, folder, Transform3D(Basis(), Vector3(entry[0], 0, 1068.0)), entry[1])
	tractor_unit(kit, folder, Transform3D(Basis(Vector3.UP, 0.4), Vector3(x - 20.0, 0, 1090.0)) * Transform3D(Basis(), Vector3(0, 0, -4.0)), Color8(30, 90, 60), "Tractor")

	var colors: = [Color8(170, 50, 40), Color8(40, 90, 150), Color8(60, 120, 70), Color8(200, 140, 40)]
	for index in 4:
		var at: = Vector3(x - 54.0 + (index % 2) * 0.0, 4.3 + (index / 2) * 8.6, 1060.0 + (index % 2) * 9.0)
		kit.box(folder, Transform3D(Basis(Vector3.UP, PI / 2), at), Vector3(8.0, 8.6, 20.0), colors[index], "DiamondPlate", "Container", PolishKit.SOLID)
	for index in 3:
		var at: = Vector3(x - 46.0 + index * 11.0, 0, 1108.0)
		kit.box(folder, Transform3D(Basis(), at + Vector3(0, 0.5, 0)), Vector3(8.0, 1.0, 14.0), [YELLOW, Color8(40, 90, 150), Color8(90, 96, 100)][index], "Metal", "SkipFloor", PolishKit.SOLID)
		for side: float in [-1.0, 1.0]:
			kit.box(folder, Transform3D(Basis(), at + Vector3(side * 3.8, 3.0, 0)), Vector3(0.4, 5.0, 14.0), [YELLOW, Color8(40, 90, 150), Color8(90, 96, 100)][index], "Metal", "SkipSide", PolishKit.SOLID)
			kit.box(folder, Transform3D(Basis(), at + Vector3(0, 3.0, side * 6.8)), Vector3(8.0, 5.0, 0.4), [YELLOW, Color8(40, 90, 150), Color8(90, 96, 100)][index], "Metal", "SkipSide", PolishKit.SOLID)
		kit.box(folder, Transform3D(Basis(), at + Vector3(0, 3.2, 0)), Vector3(7.0, 3.0, 12.0), Color8(110, 96, 80), "Pebble", "SkipLoad")

	var office: = Vector3(x + 52.0, 0, 1110.0)
	kit.box(folder, Transform3D(Basis(), office + Vector3(0, 4.3, 0)), Vector3(20.0, 8.6, 8.0), WHITE, "DiamondPlate", "OfficeContainer", PolishKit.SOLID)
	kit.box(folder, Transform3D(Basis(), office + Vector3(-4.0, 5.0, 4.05)), Vector3(5.0, 3.0, 0.1), Color8(40, 50, 60), "Glass", "OfficeWindow")
	kit.box(folder, Transform3D(Basis(), office + Vector3(5.0, 3.6, 4.05)), Vector3(3.2, 7.0, 0.1), Color8(80, 86, 92), "Metal", "OfficeDoor")
	IndustryZone.places["trailers"] = [Vector3(x + 12.0, 8.0, 1068.0), Vector3(x + 30.0, 8.0, 1068.0)]





static func siding(kit: PolishKit, parent: int) -> void :
	var folder: = kit.own_folder("Siding")
	var z: = IndustryZone.SIDING_Z
	var from: = IndustryZone.SIDING_FROM
	var to: = IndustryZone.SIDING_TO
	_track(kit, folder, Vector3(from, 0, z), Vector3(to, 0, z))

	_track(kit, folder, Vector3(to, 0, z), Vector3(to + 72.0, 0, Train.LINE_Z))

	kit.box(folder, Transform3D(Basis(), Vector3(from - 1.0, 2.2, z)), Vector3(1.6, 3.0, 7.0), RED, "Metal", "BufferStop", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:
		kit.box(folder, Transform3D(Basis(), Vector3(from - 1.0, 2.6, z + side * 2.4)), Vector3(1.8, 0.8, 0.8), WHITE, "SmoothPlastic", "BufferStopBand")
	var wagons: Array = []
	for wx: float in [-335.0, -294.0, -253.0]:
		tank_wagon(kit, folder, Vector3(wx, 0.98, z))
		wagons.append(Vector3(wx, 8.0, z))
	for wx: float in [-575.0, -534.0]:
		box_wagon(kit, folder, Vector3(wx, 0.98, z))
	IndustryZone.places["wagons"] = wagons



static func _track(kit: PolishKit, parent: int, a: Vector3, b: Vector3) -> void :
	var along: = (b - a).normalized()
	var basis: = Basis.looking_at(along, Vector3.UP)
	var length: = a.distance_to(b)
	kit.box(parent, Transform3D(basis, (a + b) / 2.0 + Vector3(0, 0.35, 0)), Vector3(9.0, 0.7, length), BED, "Pebble", "RailBed", PolishKit.SOLID)
	var t: = 1.5
	while t < length:
		kit.box(parent, Transform3D(basis, a + along * t + Vector3(0, 0.82, 0)), Vector3(7.2, 0.24, 0.9), SLEEPER, "Wood", "Sleeper")
		t += 3.0
	for side: float in [-1.0, 1.0]:
		var piece: = 0.0
		while piece < length:
			var span: = minf(40.0, length - piece)
			var middle: = a + along * (piece + span / 2.0) + basis.x * side * Train.GAUGE / 2.0 + Vector3(0, 0.98, 0)
			kit.box(parent, Transform3D(basis, middle), Vector3(0.24, 0.26, span), RAIL, "Metal", "Rail")
			piece += span




static func tank_wagon(kit: PolishKit, parent: int, at: Vector3) -> void :
	var base: = Transform3D(Basis(Vector3.UP, PI / 2), at)
	_bogies(kit, parent, base)
	kit.box(parent, base * Transform3D(Basis(), Vector3(0, 3.0, 0)), Vector3(7.0, 0.9, 36.0), DARK, "Metal", "WagonFrame", PolishKit.SOLID)
	var shell: = base * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(0, 7.6, 0))
	kit.store.add(PartStore.Shape.CYLINDER, shell, Vector3(33.0, 8.6, 8.6), Color8(206, 208, 210), "Metal", "WagonTank", parent, PolishKit.SOLID)
	kit.store.add(PartStore.Shape.CYLINDER, shell.translated_local(Vector3(0, 0, 0)), Vector3(5.0, 8.7, 8.7), ORANGE, "SmoothPlastic", "WagonBand", parent, PolishKit.LOOK)
	kit.post(parent, base * Vector3(0, 11.8, 0), 1.2, 2.6, Color8(206, 208, 210), "Metal", "WagonDome")
	for end: float in [-1.0, 1.0]:
		kit.box(parent, base * Transform3D(Basis(), Vector3(0, 3.8, end * 17.0)), Vector3(7.4, 0.2, 2.6), STEEL, "DiamondPlate", "WagonPlatform")
		for side: float in [-1.0, 1.0]:
			kit.store.add(PartStore.Shape.CYLINDER, base * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(side * 2.4, 3.2, end * 18.6)), Vector3(1.4, 1.2, 1.2), DARK, "Metal", "Buffer", parent, PolishKit.LOOK)
		kit.rod(parent, base * Vector3(2.0, 3.9, end * 16.2), base * Vector3(2.0, 12.0, end * 13.2), 0.12, STEEL, "Metal", "WagonLadder")
	for side: float in [-1.0, 1.0]:
		var plate: = base * Transform3D(Basis(Vector3.UP, side * PI / 2), Vector3(side * 3.65, 3.2, -10.0))
		StreetKit.board(kit, parent, plate, Vector2(2.4, 1.6), ORANGE, "33\n1203", Color8(20, 20, 20), "AdrPlate")



static func box_wagon(kit: PolishKit, parent: int, at: Vector3) -> void :
	var base: = Transform3D(Basis(Vector3.UP, PI / 2), at)
	_bogies(kit, parent, base)
	kit.box(parent, base * Transform3D(Basis(), Vector3(0, 3.0, 0)), Vector3(7.0, 0.9, 36.0), DARK, "Metal", "WagonFrame", PolishKit.SOLID)
	kit.box(parent, base * Transform3D(Basis(), Vector3(0, 8.4, 0)), Vector3(8.6, 9.6, 36.0), Color8(120, 64, 46), "DiamondPlate", "WagonBody", PolishKit.SOLID)
	kit.box(parent, base * Transform3D(Basis(), Vector3(0, 13.4, 0)), Vector3(8.2, 0.6, 35.4), Color8(150, 150, 150), "Metal", "WagonRoof")
	for side: float in [-1.0, 1.0]:
		kit.box(parent, base * Transform3D(Basis(), Vector3(side * 4.36, 8.0, 0)), Vector3(0.1, 8.0, 9.0), Color8(104, 56, 40), "DiamondPlate", "WagonDoor")
	for end: float in [-1.0, 1.0]:
		for side: float in [-1.0, 1.0]:
			kit.store.add(PartStore.Shape.CYLINDER, base * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(side * 2.4, 3.2, end * 18.6)), Vector3(1.4, 1.2, 1.2), DARK, "Metal", "Buffer", parent, PolishKit.LOOK)


static func _bogies(kit: PolishKit, parent: int, base: Transform3D) -> void :
	for end: float in [-12.0, 12.0]:
		kit.box(parent, base * Transform3D(Basis(), Vector3(0, 1.9, end)), Vector3(5.6, 1.2, 8.0), Color8(40, 40, 42), "Metal", "Bogie", PolishKit.SOLID)
		for axle: float in [-2.5, 2.5]:
			for side: float in [-1.0, 1.0]:
				var wheel: = base * Transform3D(Basis(), Vector3(side * Train.GAUGE / 2.0, 1.4, end + axle))
				kit.store.add(PartStore.Shape.CYLINDER, wheel, Vector3(0.5, 2.6, 2.6), Color8(50, 46, 44), "Metal", "Wheel", parent, PolishKit.LOOK)
