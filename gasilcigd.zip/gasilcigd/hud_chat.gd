class_name HudChat
extends Control





const WIDTH: = 560.0
const HEIGHT: = 50.0

var _box: Control
var _field: LineEdit
var _caption: Label
var _open: = false
var _saved: Dictionary = {}


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_box = Ui.plate(Vector2(WIDTH, HEIGHT))
	_box.visible = false
	add_child(_box)
	Ui.stripe(_box, 60)
	_caption = Ui.caps("", int(Config.Hud.CapsFloor))
	_caption.position = Vector2(12, 15)
	_box.add_child(_caption)
	_field = LineEdit.new()
	_field.position = Vector2(80, 6)
	_field.size = Vector2(WIDTH - 92, HEIGHT - 12)
	_field.max_length = int(Config.Talk.ChatMax)
	_field.add_theme_font_override("font", Ui.label_font())
	_field.add_theme_font_size_override("font_size", int(Config.Hud.TextFloor) + 2)
	_field.add_theme_color_override("font_color", Ui.TEXT)
	_field.add_theme_color_override("font_placeholder_color", Color(Ui.DIM, 0.7))
	_field.add_theme_color_override("caret_color", Ui.YELLOW)
	var flat: = StyleBoxFlat.new()
	flat.bg_color = Color(Ui.INSET, 0.55)
	flat.set_corner_radius_all(4)
	flat.content_margin_left = 8
	flat.content_margin_right = 8
	for state: String in ["normal", "focus", "read_only"]:
		_field.add_theme_stylebox_override(state, flat)
	_field.text_submitted.connect(_submit)
	_box.add_child(_field)


func is_open() -> bool:
	return _open


func _process(_delta: float) -> void :
	if _open:

		_box.position = Vector2(Ui.MARGIN, size.y - 330.0)


func _input(event: InputEvent) -> void :
	if _open:
		if event is InputEventKey and event.pressed and event.physical_keycode == KEY_ESCAPE:
			close()
			get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("chat") and not event.is_echo():
		var me: = Game.local_player
		if me != null and me.camera != null and me.camera.captured and not Game.ui_open:
			open()
			get_viewport().set_input_as_handled()


func open() -> void :
	if _open:
		return
	_open = true
	_caption.text = Text.say(Text.m("talk.chat.title"))
	_field.placeholder_text = Text.say(Text.m("talk.chat.hint"))
	_field.text = ""
	_box.position = Vector2(Ui.MARGIN, size.y - 330.0)
	_box.visible = true
	Game.ui_open = true
	_mute_keys()
	_field.grab_focus()



func say(text: String) -> void :
	_submit(text)


func _submit(text: String) -> void :
	var said: = text.strip_edges().left(int(Config.Talk.ChatMax))
	if not said.is_empty():
		Net.request("talk.chat", [said])
	close()


func close() -> void :
	if not _open:
		return
	_open = false
	_box.visible = false
	_field.release_focus()
	Game.ui_open = false
	_unmute_keys()



func _mute_keys() -> void :
	for action: StringName in InputMap.get_actions():
		if String(action).begins_with("ui_"):
			continue
		_saved[action] = InputMap.action_get_events(action)
		Input.action_release(action)
		InputMap.action_erase_events(action)


func _unmute_keys() -> void :
	for action: StringName in _saved:
		for event: InputEvent in _saved[action]:
			InputMap.action_add_event(action, event)
		Input.action_release(action)
	_saved.clear()
