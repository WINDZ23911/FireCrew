extends RefCounted



static func start(main: Node) -> void :
	if OS.get_cmdline_user_args().has("--hose-test"):
		var debug: = HoseDebug.new()
		debug.name = "HoseDebug"
		main.add_child(debug)
