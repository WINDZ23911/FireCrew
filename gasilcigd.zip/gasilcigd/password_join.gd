extends ProofDebug








func _scenario_passwordjoin() -> void :
	await _wait(1.0)
	var title: = TitleScreen.new()
	get_tree().current_scene.add_child(title)
	await _wait(2.0)
	title._open("crew")
	print("passwordjoin: style before joining %s" % Style.NAMES[Style.kind])
	Net.join("127.0.0.1")
	var since: = Time.get_ticks_msec()
	var left_at: = -1.0
	var was_in: = false
	var longest: = 0.0
	var frame_at: = Time.get_ticks_usec()
	while Time.get_ticks_msec() - since < 40000:
		await get_tree().process_frame
		var now: = Time.get_ticks_usec()
		if (now - frame_at) / 1000.0 > longest:
			longest = (now - frame_at) / 1000.0
			if longest > 250.0:
				print("passwordjoin: a frame of %.0f ms at %.1f s" % [longest, (Time.get_ticks_msec() - since) / 1000.0])
		frame_at = now
		var seconds: = (Time.get_ticks_msec() - since) / 1000.0
		if Net.active() and Net.players.size() > 1 and not was_in:
			was_in = true
			print("passwordjoin: in the crew after %.1f s (style %s)" % [seconds, Style.NAMES[Style.kind]])
		if was_in and not Net.active() and left_at < 0.0:
			left_at = seconds
			print("passwordjoin: out of the crew after %.1f s: %s" % [seconds, Text.say(Net.refusal, "en") if Net.refusal else "(no reason)"])
	print("passwordjoin: the longest frame %.0f ms" % longest)
	await _snap("after")
	_check(was_in, "the crew was joined with the password")
	_check(left_at < 0.0 and Net.active(), "still in the crew 40 s later (style %s)" % Style.NAMES[Style.kind])
	_done()









func _scenario_titlejoin() -> void :
	var typed: = "abc"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--password="):
			typed = arg.substr(11)
	await _wait(1.0)
	var title: = TitleScreen.new()
	get_tree().current_scene.add_child(title)
	await _wait(2.0)
	title._open("crew")
	var waited: = 0.0
	while title._crews.is_empty() and waited < 20.0:
		await _wait(0.5)
		waited += 0.5
	print("titlejoin: the list has %d server(s): %s" % [title._crews.size(), title._crews.map( func(c: Dictionary) -> String: return "%s locked=%s" % [c.get("name"), c.get("locked")])])
	if not _check( not title._crews.is_empty(), "the server is on the list"):
		_done()
		return
	title._chosen = str(title._crews[0]["id"])
	title._show_rows()
	await _wait(0.3)
	title._password.text = typed
	await _snap("password")
	print("titlejoin: style before joining %s; JOIN with '%s'" % [Style.NAMES[Style.kind], typed])
	title._join_crew()
	var since: = Time.get_ticks_msec()
	var was_in: = false
	var left_at: = -1.0
	while Time.get_ticks_msec() - since < 45000:
		await _wait(0.25)
		var seconds: = (Time.get_ticks_msec() - since) / 1000.0
		if Net.active() and Net.players.size() > 1 and not was_in:
			was_in = true
			print("titlejoin: in the crew after %.1f s (style %s)" % [seconds, Style.NAMES[Style.kind]])
		if was_in and not Net.active() and left_at < 0.0:
			left_at = seconds
			print("titlejoin: out of the crew after %.1f s" % seconds)
	await _snap("after")
	_check(was_in, "the crew was joined through the list with the password")
	_check(left_at < 0.0 and Net.active() and Net.players.size() > 1, "still in the crew 45 s later (style %s)" % Style.NAMES[Style.kind])
	_done()
