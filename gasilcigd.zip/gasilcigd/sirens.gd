extends ProofDebug



const GHOST_SPEED: = 36.0
const TURN_SPEED: = 14.0
const HELD_MOST: = 6.0








func _scenario_pullover() -> void :
	await _wait(1.0)
	var traffic: = Traffic.current
	var graph: = NavGraph.current
	_hearing(traffic)
	await _lingering()


	var truck: = Vehicle.named("Fire Truck")
	var start: = Vector3(-104, 0, 14)
	var finish: = Vector3(700, 0, 300)
	var way: = Guide._way_between(graph, start, finish)
	if way.is_empty():
		_fail("no way across the town from the station")
		await _done()
		return
	var before: = {}
	for vehicle in traffic.vehicles:
		before[vehicle] = true

	var own: Dictionary = Config.Traffic
	var kept: = {}
	for key: String in ["SetPieceCars", "SetPieceFrom", "SetPieceTo", "SetPieceHidden", "SetPieceRoom"]:
		kept[key] = own[key]
	own["SetPieceCars"] = 6
	own["SetPieceFrom"] = 50.0
	own["SetPieceTo"] = 420.0
	own["SetPieceHidden"] = 0.0
	own["SetPieceRoom"] = 30.0
	var placed: = traffic.put_on_way(start, finish)
	own.merge(kept, true)
	var tracked: Array = []
	for vehicle in traffic.vehicles:
		if not before.has(vehicle):
			vehicle.deaf = false
			tracked.append(vehicle)
	print("pullover: %d cars put on the way, %d tracked" % [placed, tracked.size()])
	_check(tracked.size() >= 2, "cars on the street ahead of the fire engine (%d)" % tracked.size())

	var ghost: = TownLifeDebug.Ghost.new()
	add_child(ghost)
	Emergency.watch(ghost, true)
	truck.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
	truck.freeze = true
	truck.siren = 1
	truck.blue_on = true

	var route: Array = way["route"]
	var index: = 0
	var along: float = way["from_along"]
	var driven: = 0.0
	var reach: = minf(float(way["length"]), 700.0)
	var held: = 0.0
	var held_most: = 0.0
	var held_all: = 0.0
	var seen: = {}
	for vehicle in tracked:
		seen[vehicle] = {"alarmed": false, "side": 0.0, "stood": false, "rolled_on": false}
	var snapped: = false
	var clock: = 0.0
	while driven < reach and clock < 75.0:
		await get_tree().physics_frame
		var dt: = get_physics_process_delta_time()
		clock += dt
		var segment: Dictionary = graph.segments[route[index]]
		var found: = NavGraph.sample(segment, along)
		var ahead: = Vector2(found.z, found.w)

		var over: float = segment.get("offset", float(segment.get("width", 20.0)) / 4.0)
		var at: = Vector2(found.x, found.y) + Vector2(ahead.y, - ahead.x) * over
		var speed: = TURN_SPEED if segment["kind"] == "turn" else GHOST_SPEED
		var standing_in_way: = false
		for vehicle in traffic.vehicles:
			var rx: = vehicle.x - at.x
			var rz: = vehicle.z - at.y
			var forward: = rx * ahead.x + rz * ahead.y
			var aside: = absf(rx * ahead.y - rz * ahead.x)
			if aside < 4.0 + vehicle.half_width + 0.3 and forward > 0.0 and forward < 14.0 + vehicle.half + 30.0:
				var gap: = forward - 14.0 - vehicle.half
				speed = minf(speed, maxf(0.0, (gap - 3.0) * 1.5) + vehicle.v)
				if gap < 6.0 and vehicle.v < 1.0:
					standing_in_way = true
		if speed < 0.5:
			speed = 0.0
		if standing_in_way and speed == 0.0:
			held += dt
			held_all += dt
			held_most = maxf(held_most, held)
		else:
			held = 0.0
		ghost.global_position = Vector3(at.x, 2.0, at.y)
		ghost.linear_velocity = Vector3(ahead.x, 0.0, ahead.y) * speed
		var ground: = _ground(Vector3(at.x, 4.0, at.y))
		truck.global_transform = Transform3D(Basis.looking_at(Vector3(ahead.x, 0.0, ahead.y)), ground + Vector3(0, float(truck.spec["spawn"].origin.y), 0))
		along += speed * dt
		driven += speed * dt
		while along > float(graph.segments[route[index]]["length"]) and index < route.size() - 1:
			along -= float(graph.segments[route[index]]["length"])
			index += 1

		var told: = floori(clock / 4.0) != floori((clock - dt) / 4.0)
		for vehicle: Traffic.Car in seen:
			var note: Dictionary = seen[vehicle]
			if not traffic.vehicles.has(vehicle):
				continue
			if told:
				print("  t %.0f car %d: %.0f studs from the engine, v %.1f, pulled over %.1f, alarmed %s, behind %s, held by '%s'" % [
					clock, vehicle.id, Vector2(vehicle.x - at.x, vehicle.z - at.y).length(), vehicle.v, vehicle.side, vehicle.alarmed, vehicle.behind, vehicle.waiting_for])
			if vehicle.alarmed:
				note["alarmed"] = true
				note["side"] = maxf(note["side"], vehicle.side)
				var lane: = traffic._segment_of(vehicle)
				if vehicle.v < 0.5 and lane["kind"] == "lane":
					note["stood"] = true
				if lane["kind"] == "lane" and float(lane["pull_over"]) < float(Config.Traffic.PullOverRoom) and vehicle.v > 5.0:
					note["rolled_on"] = true

			if not snapped and vehicle.alarmed and vehicle.v < 0.5 and vehicle.side > 1.0:
				var rx: = vehicle.x - at.x
				var rz: = vehicle.z - at.y
				var forward: = rx * ahead.x + rz * ahead.y
				if forward > 25.0 and forward < 55.0:
					snapped = true
					var right: = Vector3( - vehicle.dz, 0, vehicle.dx)
					var car: = Vector3(vehicle.x, ground.y, vehicle.z)
					var eye: = car + right * (vehicle.half_width + 9.0) + Vector3(vehicle.dx, 0, vehicle.dz) * 26.0 + Vector3(0, 5.0, 0)
					_view(eye, (car + Vector3(at.x, ground.y, at.y)) / 2.0 + Vector3(0, 2.5, 0), 62.0)
					await _picture("kerb")

	var alarmed: = 0
	var stood: = 0
	var rolled: = 0
	var widest: = 0.0
	for vehicle: Traffic.Car in seen:
		var note: Dictionary = seen[vehicle]
		alarmed += int(note["alarmed"])
		stood += int(note["stood"])
		rolled += int(note["rolled_on"])
		widest = maxf(widest, note["side"])
	print("pullover: drove %.0f of %.0f studs in %.1f s; %d of %d cars heard it, %d stood aside, %d kept rolling with no room, pulled over up to %.1f studs; held behind a car standing in its way %.1f s at most, %.1f s in all" % [
		driven, reach, clock, alarmed, seen.size(), stood, rolled, widest, held_most, held_all])
	_check(driven >= reach - 1.0, "the fire engine got through (%.0f of %.0f studs in %.0f s)" % [driven, reach, clock])
	_check(alarmed >= mini(2, seen.size()), "the cars ahead heard the siren (%d of %d)" % [alarmed, seen.size()])
	_check(widest >= 1.0, "they pulled over to the kerb (up to %.1f studs)" % widest)
	_check(held_most < HELD_MOST, "never held behind a car standing in its way for long (%.1f s at most)" % held_most)
	_check(snapped, "a car stood at the kerb as the engine came past")


	ghost.linear_velocity = Vector3.ZERO
	Emergency.watch(ghost, false)
	truck.siren = 0
	await _wait(float(Config.Life.SirenLinger) + float(Config.Life.SirenCalm) + 3.0)
	var still_aside: = 0
	for vehicle: Traffic.Car in seen:
		if traffic.vehicles.has(vehicle) and (vehicle.alarmed or vehicle.waiting_for == "siren"):
			still_aside += 1
	_check(still_aside == 0, "after it has gone by every car drives on (%d still waiting)" % still_aside)
	truck.freeze = false

	await _no_room(traffic, graph, ghost)
	await _people(graph, ghost)
	ghost.queue_free()
	truck.siren = 0
	truck.freeze = false
	await _done()





func _no_room(traffic: Traffic, graph: NavGraph, ghost: Node3D) -> void :
	var room: = float(Config.Traffic.PullOverRoom)
	var busy: = {}
	for vehicle in traffic.vehicles:
		busy[vehicle.route[vehicle.index]] = true
	var lanes: Array = []
	for segment: Dictionary in graph.segments:
		if segment["kind"] == "lane" and float(segment["pull_over"]) < room and float(segment["length"]) >= 100.0 and not busy.has(segment["id"]) and not segment.get("exit", false):
			lanes.append(segment)
	lanes.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["length"] < b["length"])
	print("pullover: %d stretches with no room to pull over" % lanes.size())
	var car: Traffic.Car = null
	var lane: Dictionary = {}
	var own: Dictionary = Config.Traffic
	var kept: Array = [own["SetPieceHidden"], own["SetPieceRoom"]]
	own["SetPieceHidden"] = 0.0
	own["SetPieceRoom"] = 30.0
	for each: Dictionary in lanes:
		var before: = traffic.vehicles.size()
		if traffic._put_on_lane([each["id"]], 25.0, false) and traffic.vehicles.size() > before:
			car = traffic.vehicles[traffic.vehicles.size() - 1]
			lane = each
			break
	own["SetPieceHidden"] = kept[0]
	own["SetPieceRoom"] = kept[1]
	if car == null:
		_fail("no car could be put on a stretch with no room to pull over")
		return
	Emergency.watch(ghost, true)
	var slowest: = INF
	var heard: = false
	var left: = false
	var clock: = 0.0
	while clock < 20.0 and traffic.vehicles.has(car):
		await get_tree().physics_frame
		clock += get_physics_process_delta_time()
		if car.route[car.index] != lane["id"]:
			left = true
			break
		_siren_at(ghost, Vector2(car.x - car.dx * 35.0, car.z - car.dz * 35.0), Vector2(car.dx, car.dz))
		if car.alarmed and car.behind:
			heard = true
			if clock > 1.0:
				slowest = minf(slowest, car.v)
	var red: = car.waiting_for == "junction"
	print("pullover: no room (lane %d, %.0f studs, room %.1f): heard %s, slowest %.1f, out of the stretch %s after %.1f s (held by '%s')" % [
		lane["id"], lane["length"], lane["pull_over"], heard, slowest, left, clock, car.waiting_for])
	_check(heard, "a car on a stretch with no room hears the siren coming up behind")
	_check(slowest > 5.0, "and keeps going rather than stopping in the lane (slowest %.1f studs a second)" % slowest)
	_check(left or red, "and on through the junction at its end (out of the stretch: %s)" % left)
	_siren_at(ghost, Vector2(0, 5000), Vector2(0, -1))
	ghost.set("linear_velocity", Vector3.ZERO)
	Emergency.watch(ghost, false)



func _hearing(traffic: Traffic) -> void :
	var car: = Traffic.Car.new()

	car.x = 40.0
	car.z = 0.0
	car.dx = -1.0
	car.dz = 0.0


	var at_it: = [{"x": 40.0, "z": 120.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}]
	var for_junction: = [{"x": 0.0, "z": 120.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}]
	_check( not traffic._hears(car, at_it).is_empty(), "a car in the siren's way on a cross street, 120 studs off, hears it")
	_check(traffic._hears(car, for_junction).is_empty(), "one on the cross street 40 studs from the junction it is heading for, 126 off, does not")

	car.x = 0.0
	car.dx = 0.0
	car.dz = -1.0
	traffic._hears(car, [{"x": 0.0, "z": 60.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}])
	_check(car.behind, "a siren coming up the street behind the car is behind it")
	traffic._hears(car, [{"x": 0.0, "z": -60.0, "dx": 0.0, "dz": 1.0, "speed": 20.0}])
	_check( not car.behind, "one coming the other way is not")



func _lingering() -> void :
	var ghost: = TownLifeDebug.Ghost.new()
	add_child(ghost)
	ghost.global_position = Vector3(0, 2, 5000)
	Emergency.watch(ghost, true)
	ghost.linear_velocity = Vector3(0, 0, -20)
	_check(Emergency.sirens().size() >= 1, "a moving siren is counted")
	ghost.linear_velocity = Vector3(0, 0, -1)
	await _wait(1.0)
	var crawling: = Emergency.sirens().any( func(siren: Dictionary) -> bool: return absf(siren["z"] - 5000.0) < 1.0)
	_check(crawling, "and still, a second after it slowed to a crawl")
	await _wait(float(Config.Life.SirenLinger) + 0.5)
	var gone: = not Emergency.sirens().any( func(siren: Dictionary) -> bool: return absf(siren["z"] - 5000.0) < 1.0)
	_check(gone, "but not once it has stood for longer than %.0f s" % float(Config.Life.SirenLinger))
	Emergency.watch(ghost, false)
	ghost.queue_free()



func _people(graph: NavGraph, ghost: Node3D) -> void :
	var people: = Pedestrians.current
	if people == null:
		_fail("no townspeople")
		return
	Emergency.watch(ghost, true)
	var walk: Array = graph.walk


	var edge: Array = []
	for a in walk.size():
		for link: Dictionary in walk[a]["links"]:
			if link["kind"] == "roadside" and float(link["length"]) > 14.0 and (edge.is_empty() or float(link["length"]) > edge[2]):
				edge = [a, link["to"], float(link["length"]), link["road"]]
	if edge.is_empty():
		print("pullover: the town has no road without a pavement; the walk along one is not tried")
	else:
		var person: = _walker(people, edge[0], edge[1])
		await _wait(0.4)
		var at: = people.where(person)
		var heading: = Vector2(walk[edge[1]]["x"] - walk[edge[0]]["x"], walk[edge[1]]["z"] - walk[edge[0]]["z"]).normalized()

		_siren_at(ghost, Vector2(at.x, at.z) + heading * 70.0, - heading)
		await _wait(2.5)
		var spot: = people.where(person)
		var lane_found: = graph.nearest_lane(spot.x, spot.z, func(lane: Dictionary) -> bool: return lane["road"] == edge[3])
		var lane: Dictionary = graph.segments[lane_found[0]]
		var edge_off: float = float(lane["width"]) / 2.0 - float(lane["offset"])
		print("pullover: walker by the road: %s, %.1f studs from the lane's middle (the road's edge %.1f)" % [person.state, lane_found[2], edge_off])
		_check(person.state == "wait" and not person.aside.is_empty(), "someone walking along the edge of a road stops for the siren")
		_check(float(lane_found[2]) > edge_off + 0.5, "out of the road, over its edge (%.1f studs from the lane, the edge %.1f)" % [lane_found[2], edge_off])

		var middle: = NavGraph.sample(lane, lane_found[1])
		var inward: = Vector2(middle.x - spot.x, middle.y - spot.z).normalized()
		var truck_spot: = Vector2(middle.x, middle.y) + heading * 26.0
		_show_engine(truck_spot, - heading)
		var ground: = _ground(Vector3(spot.x, spot.y + 4.0, spot.z))
		var eye: = Vector3(spot.x + inward.x * 16.0 - heading.x * 12.0, ground.y + 5.0, spot.z + inward.y * 16.0 - heading.y * 12.0)
		_view(eye, Vector3((spot.x + truck_spot.x) / 2.0, ground.y + 2.5, (spot.z + truck_spot.y) / 2.0), 62.0)
		await _wait(0.6)
		await _picture("roadside")

		_siren_at(ghost, Vector2(at.x, at.z) - heading * 40.0, - heading)
		await _wait(1.5)
		_check(person.state == "walk" and person.aside.is_empty(), "and goes on once it has passed (%s)" % person.state)


	var pick: Dictionary = {}
	for crossing: Dictionary in graph.crossings:
		var length: = Vector2(walk[crossing["a"]]["x"] - walk[crossing["b"]]["x"], walk[crossing["a"]]["z"] - walk[crossing["b"]]["z"]).length()
		if int(crossing["phase"]) == 0 and length > 14.0 and crossing["walkers"] == 0 and (pick.is_empty() or length > pick["length"]):
			pick = crossing.duplicate()
			pick["length"] = length
	if pick.is_empty():
		_fail("no crossing to try")
		return
	_siren_at(ghost, Vector2(0, 5000), Vector2(0, -1))
	var person: = _walker(people, pick["a"], pick["b"])
	await _wait(0.3)
	_check(person.on >= 0, "someone sets out over a crossing")
	var at: = people.where(person)
	var across: = Vector2(walk[pick["b"]]["x"] - walk[pick["a"]]["x"], walk[pick["b"]]["z"] - walk[pick["a"]]["z"]).normalized()
	var road: = Vector2(across.y, - across.x)
	_siren_at(ghost, Vector2(at.x, at.z) + road * 70.0, - road)
	await _wait(2.5)
	var kerb: = Vector3(walk[pick["a"]]["x"], 0, walk[pick["a"]]["z"])
	var stood: = people.where(person)
	print("pullover: on the crossing: %s, %.1f studs from the kerb they set out from" % [person.state, Vector2(stood.x - kerb.x, stood.z - kerb.z).length()])
	_check(person.state == "wait" and Vector2(stood.x - kerb.x, stood.z - kerb.z).length() < 1.0 and person.on < 0, "back on the kerb, off the crossing, until it has passed")
	_siren_at(ghost, Vector2(at.x, at.z) - road * 40.0, - road)
	var over: = false
	for tick in 60:
		await _wait(0.25)
		if person.gone or person.on >= 0 or person.index >= 1:
			over = true
			break
	_check(over, "and then over the crossing as anyone goes")
	Emergency.watch(ghost, false)



func _walker(people: Pedestrians, a: int, b: int) -> Pedestrians.Person:
	var person: = people._create({"node": a})
	person.route.assign([a, b])
	person.index = 0
	person.goal = {}
	person.cleared = true
	people._start_leg(person)
	people.person_added.emit(person)
	return person


func _siren_at(ghost: Node3D, at: Vector2, heading: Vector2) -> void :
	ghost.global_position = Vector3(at.x, 2.0, at.y)
	ghost.set("linear_velocity", Vector3(heading.x, 0, heading.y) * GHOST_SPEED)



func _show_engine(at: Vector2, heading: Vector2) -> void :
	var truck: = Vehicle.named("Fire Truck")
	truck.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
	truck.freeze = true
	truck.siren = 1
	truck.blue_on = true
	var ground: = _ground(Vector3(at.x, 4.0, at.y))
	truck.global_transform = Transform3D(Basis.looking_at(Vector3(heading.x, 0, heading.y)), ground + Vector3(0, float(truck.spec["spawn"].origin.y), 0))



func _picture(stage: String) -> void :
	var layers: = get_tree().root.find_children("*", "CanvasLayer", true, false)
	var shown: Array = []
	for layer: Node in layers:
		shown.append((layer as CanvasLayer).visible)
		(layer as CanvasLayer).visible = false
	await _snap(stage)
	for i in layers.size():
		(layers[i] as CanvasLayer).visible = shown[i]
