class_name CrewTasks
extends RefCounted








static func open_tasks(service: CrewService) -> Array:
	var tasks: Array = []
	if Game.incident.is_empty():
		return tasks
	match str(Game.incident.get("kind", "")):
		"fire":
			_fire(service, tasks)
		"flood":
			_flood(tasks)
		"hazmat":
			_hazmat(tasks)
		"medical":
			_medical(service, tasks)
		"accident":
			_accident(tasks)
		"alarm":
			_alarm(tasks)
		"crash":
			_crash(tasks)
		"tree":
			_tree(tasks)
	_people(service, tasks)
	_scene(service, tasks)
	tasks.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return int(a["order"]) < int(b["order"]))
	for task: Dictionary in tasks:
		_owners(service, task)
	return tasks


static func _task(order: int, text: Variant, kinds: Array, make: Variant = null) -> Dictionary:
	return {"order": order, "text": text, "kinds": kinds, "make": make, "who": [], "lead": false}



static func _owners(service: CrewService, task: Dictionary) -> void :
	var kinds: Array = task["kinds"]
	for mind in service.members:
		var on: = mind.job != null and mind.job.kind in kinds
		for waiting in mind.queue:
			on = on or waiting.kind in kinds
		if on:
			task["who"].append(mind.display_name())
	var lead: = Game.local_player
	if lead == null:
		return
	if "attack" in kinds and HoseService.current != null and HoseService.current.line_of(lead) != null:
		task["lead"] = true
	if "carry" in kinds and lead.holding == "carry":
		task["lead"] = true
	if "cutTree" in kinds and lead.get_attr("Tool") == "Chainsaw":
		task["lead"] = true





static func _people(service: CrewService, tasks: Array) -> void :
	var found: = JobCarry.free_victims().size()
	if found > 0:
		tasks.append(_task(0, Text.f("crew.tasks.carry", [found]), ["carry"], func() -> CrewJob: return JobCarry.new()))
	if str(Game.incident.get("kind", "")) in ["fire", "medical"] and CrewSearch.open(service):
		var house: = CrewSearch.house()
		var rooms: = CrewSearch.rooms(house)
		var searched: = 0
		for room_name: String in rooms:
			searched += 1 if CrewSearch.searched(service, house, room_name) else 0
		var building: = house
		tasks.append(_task(1, Text.f("crew.tasks.search", [searched, rooms.size()]), ["search"], func() -> CrewJob: return JobSearch.new(building)))





static func _fire(service: CrewService, tasks: Array) -> void :
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty():
		return
	var control: Variant = fire.incident.get("control")
	if is_instance_valid(control) and (control.get_meta("prompt") as Prompt).enabled:
		var prompt: Prompt = control.get_meta("prompt")
		var gas: = fire.incident.get("fed") != null
		tasks.append(_task(2, Text.m("crew.tasks.gas" if gas else "crew.tasks.power"), ["valve", "switch"], func() -> CrewJob: return JobPress.new("valve" if gas else "switch", prompt, "rescue")))
	if fire.incident.get("sealed") != null and CrewAuto._sealed_seen(service, fire):
		tasks.append(_task(3, Text.m("crew.tasks.window"), ["window"]))
	var truck: Variant = service.home_vehicle(Game.local_player)
	if truck is Vehicle:
		var rig: = CrewWater.rig_of(truck)
		if not rig.is_empty() and rig["supply"]["state"] == "stowed" and not CrewWater.hydrant_for(truck).is_empty():
			var pumper: Vehicle = truck
			tasks.append(_task(5, Text.m("crew.tasks.supply"), ["supply"], func() -> CrewJob: return JobSupply.new(pumper)))
	var flames: = CrewWater.targets().size()
	if flames > 0:
		tasks.append(_task(4, Text.f("crew.tasks.attack", [flames]), ["attack", "backup"], func() -> CrewJob: return JobAttack.new()))


static func _flood(tasks: Array) -> void :
	var hatch: = JobPump.hatch()
	if hatch.is_empty() or hatch["over"]:
		return
	if hatch["power"]:
		var switch: Prompt = hatch["switch_prompt"]
		tasks.append(_task(2, Text.m("crew.tasks.cellarPower"), ["power"], func() -> CrewJob: return JobPress.new("power", switch, "rescue")))
	if (hatch["boom_prompt"] as Prompt).enabled:
		var boom: Prompt = hatch["boom_prompt"]
		tasks.append(_task(3, Text.m("crew.tasks.boom"), ["boom"], func() -> CrewJob: return JobPress.new("boom", boom, "safety")))
	var most: = int(Config.Incidents.Flood.Pumps)
	var running: = 0
	for pump: Dictionary in hatch["pumps"]:
		running += 1 if pump["drain"] else 0
	if running < most:
		tasks.append(_task(4, Text.f("crew.tasks.pumps", [running, most]), ["portablePump", "pump"], func() -> CrewJob: return JobPump.new()))


static func _hazmat(tasks: Array) -> void :
	var hazmat: = HazmatLeak.current
	if hazmat == null or hazmat._leak.is_empty():
		return
	var leak: Dictionary = hazmat._leak
	var at: Vector3 = leak["leak"]
	if not leak["cordon"]:
		tasks.append(_task(1, Text.f("crew.tasks.cordon", [hazmat._cordon_count(at), int(Config.Incidents.Hazmat.CordonNeeded)]), ["cones"], func() -> CrewJob: return JobCones.ring(at)))
	var prompts: Dictionary = hazmat._prompts
	if prompts.has("drain") and is_instance_valid(prompts["drain"]) and (prompts["drain"] as Prompt).enabled:
		var drain: Prompt = prompts["drain"]
		tasks.append(_task(2, Text.m("crew.tasks.drain"), ["drainCover"], func() -> CrewJob: return JobPress.new("drainCover", drain, "safety")))
	if not leak["foamed"] and float(leak["spill"]) > 0.2 and prompts.has("foam") and is_instance_valid(prompts["foam"]):
		var foam: Prompt = prompts["foam"]
		tasks.append(_task(3, Text.m("crew.tasks.foam"), ["foam"], func() -> CrewJob: return JobKitUse.new("foam", "Foam", foam, true)))
	if leak["leaking"]:
		tasks.append(_task(4, Text.m("crew.tasks.leak"), ["leak"], func() -> CrewJob: return JobValve.new()))
	if float(leak["cloud"]) > float(Config.Crew.Hazmat.CloudDone):
		tasks.append(_task(5, Text.f("crew.tasks.fog", [ceili(float(leak["cloud"]) * 100.0)]), ["fog"], func() -> CrewJob: return JobFog.new()))
	var left: = hazmat._decon_left()
	if left > 0:
		tasks.append(_task(6, Text.f("crew.tasks.decon", [left]), ["decon"]))


static func _medical(_service: CrewService, tasks: Array) -> void :
	var call: = LockedIn.current
	if call == null or call.scene.is_empty() or call.house == null:
		return
	var scene: Dictionary = call.scene
	if not scene["asked"] and is_instance_valid(scene["neighbour_prompt"]):
		var ask: Prompt = scene["neighbour_prompt"]
		tasks.append(_task(2, Text.m("crew.tasks.neighbour"), ["neighbour"], func() -> CrewJob: return JobPress.new("neighbour", ask, "rescue")))
	var front: Variant = call.house.outside_door()
	if front is Dictionary and front["locked"]:
		var door: Dictionary = front
		var house: = call.house
		tasks.append(_task(3, Text.m("crew.tasks.door"), ["forceDoor"], func() -> CrewJob: return JobForceDoor.new(house, door)))
	var aid: Variant = scene.get("aid_prompt")
	if not scene["aided"] and aid is Prompt and is_instance_valid(aid) and (aid as Prompt).enabled:
		var at: Prompt = aid
		tasks.append(_task(0, Text.m("crew.tasks.aid"), ["firstAid"], func() -> CrewJob: return JobKitUse.new("firstAid", "First aid kit", at)))


static func _accident(tasks: Array) -> void :
	var accident: = WorkAccident.current
	if accident == null or accident._call.is_empty():
		return
	var call: Dictionary = accident._call
	if call["live"]:
		tasks.append(_task(1, Text.m("crew.tasks.isolate." + str(call["isolate"])), ["isolate"]))
	elif call.get("air", false) and not call.get("bled", false):
		tasks.append(_task(1, Text.m("crew.tasks.bleed"), ["bleed"]))
	if not call["freed"]:
		tasks.append(_task(2, Text.m("crew.tasks.free"), ["cutOpen"]))


static func _alarm(tasks: Array) -> void :
	if FireAlarm.current != null and not FireAlarm.current._panel.is_empty():
		tasks.append(_task(1, Text.m("crew.tasks.alarm"), ["alarm"], func() -> CrewJob: return JobAlarm.new()))


static func _crash(tasks: Array) -> void :
	var crash: = CarCrash.current
	if crash == null or crash.scene.is_empty():
		return
	var engine: Variant = crash.scene.get("engine")
	if engine is Dictionary and engine["state"] == "smoking":
		var prompt: Prompt = engine["prompt"]
		tasks.append(_task(1, Text.m("crew.tasks.battery"), ["battery"], func() -> CrewJob: return JobPress.new("battery", prompt, "rescue")))
	var left: = 0
	for door: Dictionary in crash.scene.get("doors", []):
		left += 1 if int(door["stage"]) <= CarCrash.JOBS.size() else 0
	if left > 0:
		tasks.append(_task(2, Text.f("crew.tasks.cutOpen", [left]), ["cutOpen"], func() -> CrewJob: return JobCutOpen.new()))


static func _tree(tasks: Array) -> void :
	var tree: = FallenTree.current
	if tree == null or tree.scene.is_empty():
		return
	var cuts: = 0
	for ring: Dictionary in tree.scene["rings"]:
		cuts += 0 if ring["done"] else 1
	if cuts > 0:
		tasks.append(_task(2, Text.f("crew.tasks.cutTree", [cuts]), ["cutTree"], func() -> CrewJob: return JobCutTree.new()))
	else:
		tasks.append(_task(3, Text.m("crew.tasks.clear"), ["drag"], func() -> CrewJob: return JobDrag.new()))



static func _scene(service: CrewService, tasks: Array) -> void :
	var at: Vector3 = Game.incident.get("pos", Vector3.ZERO)
	var kind: = str(Game.incident.get("kind", ""))
	if kind != "hazmat" and not service.done_here.has("cones") and not CrewKit.road_at(at).is_empty() and kind in ["crash", "tree", "fire", "accident"]:
		tasks.append(_task(8, Text.m("crew.tasks.cones"), ["cones"], func() -> CrewJob: return JobCones.new(at)))
	if Bystanders.current != null and not service.done_here.has("bystanders") and CrewAuto._crowd_middle(at) != Vector3.INF:
		var crowd: = CrewAuto._crowd_middle(at)
		tasks.append(_task(9, Text.m("crew.tasks.crowd"), ["bystanders"], func() -> CrewJob: return JobBystanders.new(crowd)))
