class_name FirstShift
extends Node











static var current: FirstShift

var active: = false

var call_index: = -1
var _phase: = ""
var _in_call: = false
var _call_over: = false
var _seen_blue: = false
var _seen_siren: = false
var _sprayed: = false
var _waited: = 0.0
var _clock: = 0.0
var _close_at: = -1.0

var ticked: Array[String] = []


func _init() -> void :
	current = self


func _ready() -> void :
	Game.water_landed.connect( func(_hit: Dictionary, _dt: float, _direction: Vector3, player: Player) -> void :
		if _in_call and player == Game.local_player:
			_sprayed = true
	)

	Game.incident_changed.connect( func() -> void : _handed_over(Game.incident))
	Game.incident_ending.connect(_handed_over)


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Onboarding.FirstShift




static func offered() -> bool:
	if Net.active() or CallService.current == null or FireService.current == null:
		return false
	if OS.get_cmdline_user_args().has("--no-save"):
		return OS.get_cmdline_user_args().has("--first-shift")
	return not PlayerData.first_shift_done



func begin(again: = false) -> void :
	if Net.active() or CallService.current == null or FireService.current == null:
		return
	var calls: = CallService.current
	active = true
	ticked.clear()
	_close_at = -1.0
	_list(0)
	Game.notify(Text.m("onboarding.firstShift.welcome"), "good", Game.local_player)
	calls.scripted = [["fire", _run_small], ["fire", _run_house]]
	_waited = 0.0
	_phase = "gear"
	if not calls.running:
		calls.hold = true
	print("first shift: begun%s" % (" again" if again else ""))



func stop() -> void :
	if CallService.current:
		CallService.current.scripted.clear()
		if _phase == "gear":
			CallService.current.hold = false
	active = false
	_phase = ""
	if HudChecklist.current:
		HudChecklist.current.close()


func _list(index: int) -> void :
	call_index = index
	_seen_blue = false
	_seen_siren = false
	_sprayed = false
	_call_over = false
	var steps: Array = []
	for key: String in settings()["Calls"][index]:
		steps.append([key, _words(key)])
	if HudChecklist.current:
		HudChecklist.current.show_list(Text.f("onboarding.firstShift.title", [index + 1, settings()["Calls"].size()]), steps)



static func _words(key: String) -> Dictionary:
	var at: = "onboarding.firstShift.steps." + key
	match key:
		"gear":
			return Text.f(at, [Controls.key_name("interact")])
		"board":
			return Text.f(at, [Controls.key_name("item")])
		"lights":
			if Settings.simple():
				return Text.f(at + "Wheel", [Controls.bound_name("interact")])
			return Text.f(at, [Controls.key_name("veh_blue"), Controls.key_name("veh_siren")])
		"hose":
			return Text.f(at, [Controls.key_name("coupling")])
		"spray":
			return Text.f(at, [Controls.key_name("fire")])
	return Text.m(at)


func _process(delta: float) -> void :
	if _close_at > 0.0 and Game.now() >= _close_at:
		_close_at = -1.0
		if not active and HudChecklist.current:
			HudChecklist.current.close()
	if not active:
		return
	_clock += delta
	if _clock < float(settings()["Every"]):
		return
	_waited += _clock
	_clock = 0.0
	var player: = Game.local_player
	if player == null or Net.active():
		if Net.active():
			stop()
		return
	_check_steps(player)
	var calls: = CallService.current
	if _phase == "gear" and (_done("gear") or _waited >= float(settings()["GearWait"])):
		_phase = "call"
		calls.hold = false
		calls.hurry(float(settings()["CallAfter"]))


func _done(key: String) -> bool:
	return HudChecklist.current != null and HudChecklist.current.is_done(key)


func _tick(key: String) -> void :
	if HudChecklist.current and HudChecklist.current.tick(key):
		ticked.append(key)
		print("first shift: ticked %s (call %d)" % [key, call_index + 1])



func _check_steps(player: Player) -> void :

	if player.get_attr("Geared", false) == true:
		_tick("gear")
	var vehicle: Variant = player.get_attr("Vehicle")
	var riding: = vehicle is Vehicle and player.seat != null
	if riding and (vehicle as Vehicle).spec.get("name") == "Fire Truck":
		_tick("board")
	var incident: = Game.incident
	if _in_call and not incident.is_empty():
		if riding:
			_seen_blue = _seen_blue or (vehicle as Vehicle).blue_on
			_seen_siren = _seen_siren or (vehicle as Vehicle).siren != 0
			if _seen_blue and _seen_siren:
				_tick("lights")
		if incident.has("pos") and player.root_position().distance_to(incident["pos"]) <= float(Config.Fire.ArriveRange):
			_tick("route")
		if player.get_attr("Line") != null or player.holding == "nozzle":
			_tick("hose")
		if _sprayed:
			_tick("spray")
		_handed_over(incident)
	if _call_over and _back(player):
		_tick("back")
		_next_call()



func _handed_over(card: Dictionary) -> void :
	if active and _in_call and int(card.get("victims_out", 0)) >= 1:
		_tick("carry")



func _back(player: Player) -> bool:
	if Game.station == null:
		return true
	if player.root_position().distance_to(Game.station.door_position) > float(settings()["StationReach"]):
		return false
	var pumper: = Vehicle.named("Fire Truck")
	if pumper == null or not (pumper.spec.get("spawn") is Transform3D):
		return true
	return pumper.global_position.distance_to((pumper.spec["spawn"] as Transform3D).origin) <= float(Config.Duty.BayReach)



func _next_call() -> void :
	_call_over = false
	if call_index + 1 < settings()["Calls"].size():
		_list(call_index + 1)
		Game.notify(Text.m("onboarding.firstShift.between"), "good", Game.local_player)
		var calls: = CallService.current
		calls.hurry(float(settings()["NextCallAfter"]))
		return
	active = false
	_phase = ""
	_close_at = Game.now() + float(settings()["DoneTime"])
	Game.notify(Text.m("onboarding.firstShift.done"), "good", Game.local_player)
	Sounds.ui("ui_fanfare")
	PlayerData.finish_first_shift()
	print("first shift: done")







func _run_small() -> Variant:
	var building: = _pick( func(b: Building) -> bool: return not b.counts_as_save, float(settings()["SmallFrom"]), float(settings()["SmallTo"]))
	if building == null:
		return false
	return await _run_fire(building, 0, 0)



func _run_house() -> Variant:
	var building: = _pick( func(b: Building) -> bool: return b is House and b.has_rooms() and b.counts_as_save and b.name.begins_with("Family house"), float(settings()["HouseFrom"]), float(settings()["HouseTo"]))
	if building == null:
		return false
	return await _run_fire(building, int(settings()["Victims"]), 1)




func _pick(fits: Callable, from: float, to: float) -> Building:
	var station: Vector3 = Game.station.door_position if Game.station else Vector3.ZERO
	var best: Building = null
	var best_distance: = INF
	var any: Building = null
	var any_distance: = INF
	for building: Building in FireService.current.buildings:
		if building.ruined or not fits.call(building):
			continue
		var distance: = building.position.distance_to(station)
		if distance < any_distance:
			any = building
			any_distance = distance
		if distance >= from and distance <= to and distance < best_distance:
			best = building
			best_distance = distance
	return best if best != null else any




func _run_fire(building: Building, people: int, index: int) -> Variant:
	if active and call_index != index:
		_list(index)
	Alarm.level = 1
	var traits: Dictionary = Config.Fire["Traits"]
	var had_force: bool = traits.has("Force")
	var force: Variant = traits.get("Force")
	traits["Force"] = "none"

	var embers: Variant = Config.Alarm.get("EmberChance")
	if embers is Array:
		var none: Array = embers.duplicate()
		none.fill(0.0)
		Config.Alarm["EmberChance"] = none
	var victims: = VictimService.current
	var forced: = victims.forced if victims else -1
	if victims:
		victims.forced = people
	_in_call = true
	_call_over = false
	print("first shift: call %d at %s, %.0f studs from the station, %d inside" % [call_index + 1, building.name, building.position.distance_to(Game.station.door_position) if Game.station else 0.0, people])
	await FireService.current.run_incident(building)
	if had_force:
		traits["Force"] = force
	else:
		traits.erase("Force")
	if victims and is_instance_valid(victims):
		victims.forced = forced
	if embers is Array:
		Config.Alarm["EmberChance"] = embers
	_in_call = false
	_call_over = true
	return true
