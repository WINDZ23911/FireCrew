class_name EngineAudio
extends Node3D













const REVS: = {"four": [800.0, 1500.0, 3000.0], "car": [800.0, 1500.0, 3000.0], "six": [600.0, 1100.0, 1750.0], "eight": [600.0, 1050.0, 1650.0]}
const START_TIME: = 0.9
const STOP_TIME: = 0.6
const NEAR: = 15.0
const FOLLOWED_NEAR: = 45.0
const AIR_BRAKES: = ["air_brake", "air_brake_2"]

var profile: Dictionary
var pitch: = 1.0
var layers: Array = []
var off: Dictionary
var running: = false
var spin: = 0.0
var boost: = 0.0
var moved: = false
var shifts: = 0
var turbo: AudioStreamPlayer3D
var road: AudioStreamPlayer3D
var starter: AudioStreamPlayer3D
var clunk: AudioStreamPlayer3D
var air_brake: AudioStreamPlayer3D
var pump: = 0.0
var _followed: = false
var _air_brakes: Array[AudioStream] = []


func setup(drive_profile: Dictionary) -> void :
	profile = drive_profile
	pitch = profile.get("pitch", 1.0)
	var engine: String = profile["sound"]
	var revs: Array = REVS[engine]
	var names: = ["idle", "low", "high"]
	for index in 3:
		layers.append({"loop": _loop(engine + "_" + names[index], 220.0), "rpm": revs[index]})

	layers[0]["fade_from"] = revs[0]
	layers[0]["fade_to"] = revs[0] * 1.5
	layers[1]["fade_from"] = revs[1]
	layers[1]["fade_to"] = revs[2]
	off = {"loop": _loop(engine + "_off", 220.0), "rpm": revs[2], "from": revs[1] * 0.8}
	if profile["turbo"] > 0.0:
		turbo = _loop("turbo", 140.0)
	road = _loop("road", 160.0)
	starter = Sounds.emitter(self, Assets.sound(profile.get("starter", "starter")), 0.0, 15.0, 160.0)
	if profile.get("clunk", false):
		clunk = Sounds.emitter(self, Assets.sound("clunk"), 0.0, 15.0, 100.0)
	if profile["airBrakes"]:
		for sound_name: String in AIR_BRAKES:
			var stream: = Assets.sound(sound_name)
			if stream != null:
				_air_brakes.append(stream)
		air_brake = Sounds.emitter(self, _air_brakes[0] if not _air_brakes.is_empty() else null, 0.0, 15.0, 200.0)


func _loop(sound_name: String, reach: float) -> AudioStreamPlayer3D:
	return Sounds.emitter(self, Sounds.loop(sound_name), 0.0, NEAR, reach)




func _follow(on: bool) -> void :
	if on == _followed:
		return
	_followed = on
	for child in get_children():
		var player: = child as AudioStreamPlayer3D
		if player:
			player.unit_size = FOLLOWED_NEAR if on else NEAR
			player.attenuation_filter_db = 0.0 if on else -24.0


static func _playing(player: AudioStreamPlayer3D, on: bool) -> void :
	if player == null or player.stream == null:
		return
	if on and not player.playing:
		player.play()
	elif not on and player.playing:
		player.stop()


static func _volume(player: AudioStreamPlayer3D, volume: float) -> void :
	player.volume_db = linear_to_db(maxf(volume, 0.0001))




func update(state: VehicleDrive, is_running: bool, inside: bool, dt: float) -> void :
	var volume: float = Config.Truck.EngineVolume
	var cab: = inside and Game.local_player != null and Game.local_player.camera != null and Game.local_player.camera.seated_view()
	_follow(inside and not cab)
	if cab:
		volume *= 0.8


	var vehicle: = get_parent() as Vehicle
	var asked: = HoseService.current.pump_load(vehicle) if (HoseService.current != null and vehicle != null) else 0.0
	pump = move_toward(pump, asked, dt * (1.0 / float(Config.Water.Pump.RiseTime) if asked > pump else 1.0 / float(Config.Water.Pump.FallTime)))
	is_running = is_running or pump > 0.01
	if is_running != running:
		running = is_running
		if running and spin < 0.2:
			_volume(starter, volume * 0.9)
			starter.play()
		elif not running and air_brake and absf(state.speed) < 4.0:
			_brakes_out(volume, 1)
	spin = clampf(spin + (dt / START_TIME if running else - dt / STOP_TIME), 0.0, 1.0)
	var alive: = spin > 0.0

	var heard: = clampf(spin * 2.0 - 1.0, 0.0, 1.0) if running else spin
	var dying: = 1.0 if running else 0.55 + 0.45 * spin

	var idle: float = layers[0]["rpm"]
	var high: float = layers[layers.size() - 1]["rpm"]
	var rpm: = state.rpm * dying
	var load: = state.load if running else 0.0
	if pump > 0.0 and running:
		var pump_rpm: = lerpf(idle, high, float(Config.Water.Pump.Revs))
		rpm = maxf(rpm, lerpf(idle, pump_rpm, pump) * dying)
		load = maxf(load, float(Config.Water.Pump.Load) * pump)
	var level: = volume * heard * (0.7 + 0.3 * state.revs)
	var before: = 1.0
	for index in layers.size():
		var part: Dictionary = layers[index]
		var given: = 0.0
		if part.has("fade_to"):
			given = clampf((rpm - part["fade_from"]) / (part["fade_to"] - part["fade_from"]), 0.0, 1.0)
		var pulling: = 0.8 + 0.2 * load if index == 0 else 0.45 + 0.55 * load
		var loop: AudioStreamPlayer3D = part["loop"]
		_playing(loop, alive)
		if alive:
			_volume(loop, level * sin(before * PI / 2.0) * cos(given * PI / 2.0) * pulling)
			loop.pitch_scale = clampf(pitch * rpm / part["rpm"], 0.5, 2.0)
		before = given
	var off_loop: AudioStreamPlayer3D = off["loop"]
	_playing(off_loop, alive)
	if alive:
		_volume(off_loop, level * clampf((rpm - off["from"]) / (off["rpm"] - off["from"]), 0.0, 1.0) * (1.0 - load) * 0.55)
		off_loop.pitch_scale = clampf(pitch * rpm / off["rpm"], 0.5, 2.0)


	if turbo:
		var wanted: = load * clampf((rpm - idle) / (high - idle), 0.0, 1.0)
		boost += (wanted - boost) * minf(1.0, dt * (2.4 if wanted > boost else 1.2))
		_playing(turbo, alive and boost > 0.03)
		_volume(turbo, volume * 0.3 * profile["turbo"] * boost * heard * (0.5 if inside else 1.0))
		turbo.pitch_scale = 0.6 + 0.6 * boost


	var pace: = clampf(absf(state.speed) / profile["topSpeed"], 0.0, 1.2)
	var scrub: = state.slip * minf(1.0, pace * 3.0)
	_playing(road, pace > 0.03)
	_volume(road, volume * (0.75 * pow(pace, 1.5) + 0.5 * scrub))
	road.pitch_scale = 0.6 + 0.7 * pace + 0.25 * scrub


	if absf(state.speed) > 4.0:
		moved = true
	elif air_brake and moved and state.standing > 0.4:
		moved = false
		_brakes_out(volume, 0)
	if state.shifts != shifts:
		shifts = state.shifts
		if clunk and running:
			_volume(clunk, volume * (1.0 if inside else 0.6))
			clunk.play()




func _brakes_out(volume: float, which: int) -> void :
	if _air_brakes.is_empty():
		return
	air_brake.stream = _air_brakes[mini(which, _air_brakes.size() - 1)]
	_volume(air_brake, volume * 1.3)
	air_brake.pitch_scale = randf_range(0.94, 1.06)
	air_brake.play()
