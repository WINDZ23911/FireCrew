class_name Settings
extends RefCounted






const PATH: = "user://settings.cfg"
const SENSITIVITY_MIN: = 0.25
const SENSITIVITY_MAX: = 3.0



static var path: = PATH


static var sensitivity: = 1.0

static var invert_y: = false

static var fov: = 70.0

static var volume: = 1.0

static var music: = 0.5

static var ui_volume: = 0.8


static var effects: = 1.0

static var radio_volume: = 1.0

static var mic_gain: = 0.5

static var mic_device: = ""

static var quality: = 2


static var window_mode: = WINDOWED
const WINDOWED: = 0
const FULLSCREEN: = 1
static var vsync: = true
static var max_fps: = 0
static var render_scale: = 1.0

static var crew: = false

static var crew_count: = 5

static var style: = Style.SUMMER


static var camera_motion: = MOTION_FULL
const MOTION_OFF: = 0
const MOTION_REDUCED: = 1
const MOTION_FULL: = 2

static var shake: = 1.0

static var reduce_motion: = false

static var subtitles: = true

static var colour_blind: = false


static var tap_holds: = false


static var spray_toggle: = false


static var hud_scale: = 1.0

static var hints_used: Dictionary = {}



const SMOKE_LESS: = 0
const SMOKE_NORMAL: = 1
const SMOKE_MORE: = 2
static var smoke: = SMOKE_NORMAL

static var reduce_smoke: bool:
	get:
		return smoke == SMOKE_LESS
	set(on):
		smoke = SMOKE_LESS if on else SMOKE_NORMAL




static var controls: = SIMPLE
const SIMPLE: = 0
const CLASSIC: = 1



static var click_use: = false

static var usage_stats: = true


static var telemetry_id: = ""
static var _loaded: = false



static func load_all() -> void :
	if _loaded:
		return
	_loaded = true
	fov = float(Config.Settings.Fov)
	shake = float(Config.Settings.Shake)
	ui_volume = float(Config.UiSounds.BusVolume)
	subtitles = bool(Config.Settings.Subtitles)
	controls = CLASSIC if _scripted() else SIMPLE


	tap_holds = not _scripted()
	spray_toggle = not _scripted()
	click_use = not _scripted()
	_controls_from_command_line()
	_route_sounds()
	var file: = ConfigFile.new()
	if file.load(path) != OK:

		Text.choose(first_language())
		_apply_volume()
		_quality_from_command_line()
		return
	read(file)
	_quality_from_command_line()



static func read(file: ConfigFile) -> void :
	sensitivity = clampf(float(file.get_value("controls", "sensitivity", 1.0)), SENSITIVITY_MIN, SENSITIVITY_MAX)
	camera_motion = clampi(int(file.get_value("controls", "camera_motion", camera_motion)), MOTION_OFF, MOTION_FULL)
	hud_scale = _hud_scale_clamped(float(file.get_value("display", "hud_scale", hud_scale)))
	smoke = clampi(int(file.get_value("display", "smoke", SMOKE_LESS if bool(file.get_value("display", "reduce_smoke", false)) else smoke)), SMOKE_LESS, SMOKE_MORE)
	var used: Variant = file.get_value("display", "hints_used", {})
	if used is Dictionary:
		hints_used = used
	volume = clampf(float(file.get_value("sound", "volume", 1.0)), 0.0, 1.0)
	music = clampf(float(file.get_value("sound", "music", music)), 0.0, 1.0)
	ui_volume = clampf(float(file.get_value("sound", "ui", ui_volume)), 0.0, 1.0)
	effects = clampf(float(file.get_value("sound", "effects", effects)), 0.0, 1.0)
	radio_volume = clampf(float(file.get_value("sound", "radio", radio_volume)), 0.0, 1.0)
	mic_gain = clampf(float(file.get_value("sound", "mic", mic_gain)), 0.0, 1.0)
	mic_device = str(file.get_value("sound", "mic_device", mic_device))
	_apply_volume()
	apply_music()
	quality = clampi(int(file.get_value("graphics", "quality", quality)), Graphics.VERY_LOW, Graphics.HIGH)
	crew = bool(file.get_value("game", "crew", false))
	crew_count = clampi(int(file.get_value("game", "crew_count", crew_count)), 1, 5)
	style = clampi(int(file.get_value("graphics", "style", style)), Style.SUMMER, Style.WINTER)
	Style.choose(style)
	Graphics.apply(quality)
	subtitles = bool(file.get_value("access", "subtitles", subtitles))
	usage_stats = bool(file.get_value("telemetry", "on", usage_stats))
	telemetry_id = str(file.get_value("telemetry", "id", telemetry_id))

	var played: = {
		"invert_y": bool(file.get_value("controls", "invert_y", false)), 
		"fov": _fov_clamped(float(file.get_value("controls", "fov", fov))), 
		"tap_holds": bool(file.get_value("access", "tap_holds", true)), 
		"spray_toggle": bool(file.get_value("access", "spray_toggle", true)), 
		"colour_blind": bool(file.get_value("access", "colour_blind", false)), 
		"reduce_motion": bool(file.get_value("access", "reduce_motion", false)), 
		"shake": clampf(float(file.get_value("access", "shake", shake)), 0.0, 1.0), 
		"window_mode": clampi(int(file.get_value("display", "window_mode", WINDOWED)), WINDOWED, FULLSCREEN), 
		"vsync": bool(file.get_value("display", "vsync", true)), 
		"max_fps": maxi(0, int(file.get_value("display", "max_fps", 0))), 
		"render_scale": _render_scale_clamped(float(file.get_value("display", "render_scale", 1.0))), 
		"controls": clampi(int(file.get_value("controls", "controls", SIMPLE)), SIMPLE, CLASSIC), 
		"click_use": bool(file.get_value("controls", "click_use", true)), 
	}
	var keys: Variant = file.get_value("controls", "keys", {})
	if not _scripted():
		invert_y = played["invert_y"]
		fov = played["fov"]
		tap_holds = played["tap_holds"]
		spray_toggle = played["spray_toggle"]
		colour_blind = played["colour_blind"]
		reduce_motion = played["reduce_motion"]
		shake = played["shake"]
		window_mode = played["window_mode"]
		vsync = played["vsync"]
		max_fps = played["max_fps"]
		render_scale = played["render_scale"]
		controls = played["controls"]
		click_use = played["click_use"]
		Controls.apply_click_use()
		if keys is Dictionary:
			Controls.restore(keys)
		apply_display()
	Ui.colour_blind = colour_blind
	var language: = str(file.get_value("game", "language", Text.language))
	Text.choose(language)



static func _scripted() -> bool:
	return OS.get_cmdline_user_args().has("--no-save")





static func first_language() -> String:
	var code: = OS.get_locale_language()
	var own: = str(Edition.data().get("language", ""))
	if not Edition.is_metlika() and own in Text.LANGUAGES:
		code = own
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--locale="):
			code = arg.substr(9)
	return code if code in Text.LANGUAGES else "en"




static func save() -> void :
	if _scripted() and path == PATH:
		return
	var file: = ConfigFile.new()
	file.set_value("game", "language", Text.language)
	file.set_value("controls", "sensitivity", sensitivity)
	file.set_value("controls", "camera_motion", camera_motion)
	file.set_value("display", "hud_scale", hud_scale)
	file.set_value("display", "hints_used", hints_used)
	file.set_value("display", "smoke", smoke)
	file.set_value("sound", "volume", volume)
	file.set_value("sound", "music", music)
	file.set_value("sound", "ui", ui_volume)
	file.set_value("sound", "effects", effects)
	file.set_value("sound", "radio", radio_volume)
	file.set_value("sound", "mic", mic_gain)
	file.set_value("sound", "mic_device", mic_device)
	file.set_value("graphics", "quality", quality)
	file.set_value("graphics", "style", style)
	file.set_value("game", "crew", crew)
	file.set_value("game", "crew_count", crew_count)
	file.set_value("access", "subtitles", subtitles)
	file.set_value("telemetry", "on", usage_stats)
	if not telemetry_id.is_empty():
		file.set_value("telemetry", "id", telemetry_id)
	var played: = {
		"invert_y": invert_y, "fov": fov, "tap_holds": tap_holds, "spray_toggle": spray_toggle, 
		"colour_blind": colour_blind, "reduce_motion": reduce_motion, "shake": shake, "window_mode": window_mode, 
		"vsync": vsync, "max_fps": max_fps, "render_scale": render_scale, "controls": controls, "click_use": click_use, 
	}
	var sections: = {
		"invert_y": "controls", "fov": "controls", "tap_holds": "access", "spray_toggle": "access", 
		"colour_blind": "access", "reduce_motion": "access", "shake": "access", "window_mode": "display", 
		"vsync": "display", "max_fps": "display", "render_scale": "display", "controls": "controls", "click_use": "controls", 
	}
	for setting: String in played:
		file.set_value(sections[setting], setting, played[setting])
	file.set_value("controls", "keys", Controls.moved())
	file.save(path)


static func set_language(code: String) -> void :
	Text.choose(code)
	save()


static func set_sensitivity(value: float) -> void :
	sensitivity = clampf(value, SENSITIVITY_MIN, SENSITIVITY_MAX)
	save()


static func set_camera_motion(level: int) -> void :
	camera_motion = clampi(level, MOTION_OFF, MOTION_FULL)
	save()


static func set_hud_scale(value: float) -> void :
	hud_scale = _hud_scale_clamped(value)
	save()


static func set_smoke(level: int) -> void :
	smoke = clampi(level, SMOKE_LESS, SMOKE_MORE)
	House.redraw_smoke()
	save()


static func set_reduce_smoke(on: bool) -> void :
	set_smoke(SMOKE_LESS if on else SMOKE_NORMAL)


static func _hud_scale_clamped(value: float) -> float:
	var step: = float(Config.Hud.ScaleStep)
	return clampf(snappedf(value, step), float(Config.Hud.ScaleMin), float(Config.Hud.ScaleMax))


static func _fov_clamped(value: float) -> float:
	return clampf(roundf(value), float(Config.Settings.FovMin), float(Config.Settings.FovMax))


static func _render_scale_clamped(value: float) -> float:
	return clampf(snappedf(value, 0.05), float(Config.Settings.RenderScaleMin), 1.0)



static func hint_used(hint_name: String) -> void :
	var count: = int(hints_used.get(hint_name, 0)) + 1
	hints_used[hint_name] = count
	if count == int(Config.Hud.HintLearned):
		save()


static func set_volume(value: float) -> void :
	volume = clampf(value, 0.0, 1.0)
	_apply_volume()
	save()


static func set_music(value: float) -> void :
	music = clampf(value, 0.0, 1.0)
	apply_music()
	save()


static func set_ui_volume(value: float) -> void :
	ui_volume = clampf(value, 0.0, 1.0)
	_apply_volume()
	save()


static func set_effects(value: float) -> void :
	effects = clampf(value, 0.0, 1.0)
	_apply_volume()
	save()


static func set_radio_volume(value: float) -> void :
	radio_volume = clampf(value, 0.0, 1.0)
	TeamRadio.apply_volume()
	save()


static func set_mic_gain(value: float) -> void :
	mic_gain = clampf(value, 0.0, 1.0)
	save()



static func mic_devices() -> Array[String]:
	var found: Array[String] = [""]
	for device in AudioServer.get_input_device_list():
		if device != "Default":
			found.append(device)
	return found



static func next_mic_device() -> void :
	var devices: = mic_devices()
	mic_device = devices[(devices.find(mic_device) + 1) % devices.size()]
	apply_mic()
	save()



static func apply_mic() -> void :
	var wanted: = mic_device if mic_device in AudioServer.get_input_device_list() else "Default"
	if AudioServer.input_device != wanted:
		AudioServer.input_device = wanted


static func set_fov(value: float) -> void :
	fov = _fov_clamped(value)
	save()


static func set_invert_y(on: bool) -> void :
	invert_y = on
	save()


static func set_shake(value: float) -> void :
	shake = clampf(value, 0.0, 1.0)
	save()


static func set_reduce_motion(on: bool) -> void :
	reduce_motion = on
	save()


static func set_subtitles(on: bool) -> void :
	subtitles = on
	save()


static func set_usage_stats(on: bool) -> void :
	usage_stats = on
	save()


static func set_colour_blind(on: bool) -> void :
	colour_blind = on
	Ui.colour_blind = on
	save()


static func set_tap_holds(on: bool) -> void :
	tap_holds = on
	save()


static func set_spray_toggle(on: bool) -> void :
	spray_toggle = on
	save()


static func set_controls(scheme: int) -> void :
	controls = clampi(scheme, SIMPLE, CLASSIC)
	Controls.bindings_changed.emit()
	save()


static func set_click_use(on: bool) -> void :
	click_use = on
	Controls.apply_click_use()
	Controls.bindings_changed.emit()
	save()



static func simple() -> bool:
	return controls == SIMPLE



static func _controls_from_command_line() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg == "--controls=simple":
			controls = SIMPLE
		elif arg == "--controls=classic":
			controls = CLASSIC
		elif arg == "--click-use":
			click_use = true
	Controls.apply_click_use()


static func set_window_mode(mode: int) -> void :
	window_mode = clampi(mode, WINDOWED, FULLSCREEN)
	apply_display()
	save()


static func set_vsync(on: bool) -> void :
	vsync = on
	apply_display()
	save()


static func set_max_fps(value: int) -> void :
	max_fps = maxi(0, value)
	apply_display()
	save()


static func set_render_scale(value: float) -> void :
	render_scale = _render_scale_clamped(value)
	apply_display()
	save()



static func rebind(action: String, key: int) -> void :
	Controls.rebind(action, key)
	save()


static func reset_keys() -> void :
	Controls.reset()
	save()



static func shake_share() -> float:
	return 0.0 if reduce_motion else shake



static func motion_level() -> int:
	return MOTION_OFF if reduce_motion else camera_motion




static func apply_display() -> void :
	if _scripted() or DisplayServer.get_name() == "headless":
		return
	var tree: = Engine.get_main_loop() as SceneTree
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if window_mode == FULLSCREEN else DisplayServer.WINDOW_MODE_WINDOWED)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = max_fps
	if tree:
		tree.root.scaling_3d_scale = Graphics.render_scale()




static func crew_size() -> int:
	return crew_count if crew and CrewService.enabled() else 0


static func set_crew_size(count: int) -> void :
	crew = count > 0
	if count > 0:
		crew_count = clampi(count, 1, 5)
	save()
	if CrewService.current:
		CrewService.current.despawn()
		CrewService.current.spawn()


static func set_quality(level: int) -> void :
	quality = clampi(level, Graphics.VERY_LOW, Graphics.HIGH)
	Graphics.apply(quality)
	save()


static func set_style(value: int) -> void :
	style = clampi(value, Style.SUMMER, Style.WINTER)
	Style.choose(style)
	save()





static func _quality_from_command_line() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--quality="):
			quality = clampi(int(arg.substr(10)), Graphics.VERY_LOW, Graphics.HIGH)
			Graphics.apply(quality)
		elif arg.begins_with("--camera-motion="):
			camera_motion = clampi(int(arg.substr(16)), MOTION_OFF, MOTION_FULL)
		elif arg.begins_with("--hud-scale="):
			hud_scale = _hud_scale_clamped(float(arg.substr(12)))
		elif arg.begins_with("--lang=") and arg.substr(7) in Text.LANGUAGES:
			Text.choose.call_deferred(arg.substr(7))
		elif arg == "--fresh-hints":
			hints_used = {}
		elif arg == "--reduce-smoke":
			smoke = SMOKE_LESS
		elif arg.begins_with("--smoke="):
			smoke = clampi(["less", "normal", "more"].find(arg.substr(8)), SMOKE_LESS, SMOKE_MORE)
		elif arg == "--colour-blind":
			colour_blind = true
			Ui.colour_blind = true
		elif arg == "--invert-y":
			invert_y = true
		elif arg == "--tap-holds":
			tap_holds = true
		elif arg == "--spray-toggle":
			spray_toggle = true
		elif arg == "--reduce-motion":
			reduce_motion = true




const EFFECTS_BUS: = "Effects"




static func _route_sounds() -> void :
	effects_bus()
	var tree: = Engine.get_main_loop() as SceneTree
	if tree == null:
		return
	for node: Node in tree.root.find_children("*", "AudioStreamPlayer3D", true, false):
		_route(node)
	for node: Node in tree.root.find_children("*", "AudioStreamPlayer", true, false):
		_route(node)
	if not tree.node_added.is_connected(_route):
		tree.node_added.connect(_route)


static func _route(node: Node) -> void :
	if node is AudioStreamPlayer3D:
		var player: = node as AudioStreamPlayer3D
		if player.bus == &"Master":
			player.bus = EFFECTS_BUS
		else:
			_send_to_effects(player.bus)
	elif node is AudioStreamPlayer:
		var player: = node as AudioStreamPlayer
		if player.bus == &"Master":
			player.bus = EFFECTS_BUS
		else:
			_send_to_effects(player.bus)



static func _send_to_effects(bus: StringName) -> void :
	if bus == &"Master" or bus == StringName(EFFECTS_BUS) or bus == StringName(Soundtrack.BUS) or bus == StringName(str(Config.UiSounds.Bus))\
	or bus == StringName(TeamRadio.BUS) or bus == StringName(TeamRadio.IN_BUS):
		return
	var index: = AudioServer.get_bus_index(bus)
	if index > 0 and AudioServer.get_bus_send(index) == &"Master":
		AudioServer.set_bus_send(index, EFFECTS_BUS)


static func effects_bus() -> int:
	var index: = AudioServer.get_bus_index(EFFECTS_BUS)
	if index < 0:
		index = AudioServer.bus_count


		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, EFFECTS_BUS)
		AudioServer.set_bus_send(index, "Master")


		var limiter: = AudioEffectHardLimiter.new()
		limiter.ceiling_db = -1.0
		AudioServer.add_bus_effect(0, limiter)
	return index


static func _apply_volume() -> void :
	AudioServer.set_bus_mute(0, volume <= 0.001)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.001)))
	var index: = effects_bus()
	AudioServer.set_bus_mute(index, effects <= 0.001)
	AudioServer.set_bus_volume_db(index, linear_to_db(maxf(effects, 0.001)))
	var ui_index: = AudioServer.get_bus_index(Sounds.ui_bus())
	AudioServer.set_bus_mute(ui_index, ui_volume <= 0.001)
	AudioServer.set_bus_volume_db(ui_index, linear_to_db(maxf(ui_volume, 0.001)))


static func apply_music() -> void :
	var bus: = AudioServer.get_bus_index(Soundtrack.BUS)
	if bus >= 0:
		AudioServer.set_bus_mute(bus, music <= 0.001)
		AudioServer.set_bus_volume_db(bus, linear_to_db(maxf(music, 0.001)))
