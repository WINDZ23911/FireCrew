extends RefCounted

















const WINDOW_GROUP: = ["Window", "WindowFrame", "Sill", "GlazingBar", "Shutter", "WindowBox", "Flowers", "Bloom", "FlowerLeaves"]
const DOOR_GROUP: = ["Door", "DoorFrame", "Step", "Porch", "PorchPost"]
const STOREY: = 13.0
const EDGE: = 3.5
const DOOR_CLEAR: = 3.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var table: Dictionary = Edition.data().get("shell_kit", {})
	if table.is_empty():
		return ""
	var districts: Dictionary = kit.get_meta("districts", {})
	var layout: Array = kit.layout()["buildings"]
	var folder: = kit.own_folder("ShellKit")
	var houses: = 0
	var placed: = 0
	var hidden: = 0
	var made: = store.count
	for model in kit.models_under("Map/Buildings"):
		var rows: = store.rows_in(model)
		var body: = -1
		for row in rows:
			if store.name_at(row) == "Body":
				body = row
				break
		if body < 0:
			continue
		var frame: = store.transform(body).orthonormalized()
		if _kind(layout, Vector2(frame.origin.x, frame.origin.z)) != "house":
			continue
		var era: = "1970s"
		match districts.get(model, ""):
			"old_town":
				era = "old"
			"edge":
				era = "farm"
		var kit_era: Dictionary = table.get(era, {})
		if kit_era.is_empty():
			continue
		var counts: = _relay(kit, folder, model, rows, frame, store.size(body), kit_era, era)
		placed += counts[0]
		hidden += counts[1]
		houses += 1
	return "shell kit: %d houses' openings laid out again (%d windows placed, %d hidden; %d parts added)" % [houses, placed, hidden, store.count - made]



static func _relay(kit: PolishKit, folder: int, model: int, rows: PackedInt32Array, frame: Transform3D, size: Vector3, era: Dictionary, era_name: String) -> Array:
	var store: = kit.store
	var inverse: = frame.affine_inverse()
	var floor_y: = - size.y / 2.0
	var rng: = RandomNumberGenerator.new()
	rng.seed = rand_from_seed(hash([int(frame.origin.x), int(frame.origin.z), "shell kit"]))[0]

	var walls: = {
		"F": [Vector3.RIGHT, Vector3.FORWARD, size.x], "B": [Vector3.LEFT, Vector3.BACK, size.x], 
		"L": [Vector3.BACK, Vector3.LEFT, size.z], "R": [Vector3.FORWARD, Vector3.RIGHT, size.z], 
	}



	var wall_of: = func(at: Vector3, facing: = Vector3.ZERO) -> String:
		var best: = ""
		var nearest: = 1.6
		for key: String in walls:
			var normal: Vector3 = walls[key][1]
			if facing != Vector3.ZERO and absf(facing.dot(normal)) < 0.7:
				continue
			var half: = absf(normal.dot(size)) / 2.0
			var away: = absf(at.dot(normal) - half)
			if away < nearest:
				nearest = away
				best = key
		return best
	var thin_of: = func(row: int) -> Vector3:
		var part_size: = store.size(row)
		var basis: = store.basis(row)
		var thin: = 0
		for axis in [1, 2]:
			if part_size[axis] < part_size[thin]:
				thin = axis
		return (frame.basis.inverse() * basis[thin]).normalized()

	var windows: Dictionary = {}
	var door: Array = []
	var winged: Dictionary = {}
	var loose: Array = []
	for row in rows:
		var part: = store.name_at(row)
		var local: Vector3 = inverse * store.position(row)
		if part == "Window":
			var wall: String = wall_of.call(local, thin_of.call(row))
			if wall.is_empty():
				continue
			if not windows.has(wall):
				windows[wall] = []
			windows[wall].append([floori((local.y - floor_y) / STOREY), local, [row]])
		elif part in WINDOW_GROUP:
			loose.append([row, local])
		elif part == "Door":
			door = [wall_of.call(local), local, [row]]
		elif part.begins_with("Wing"):

			for key: String in walls:
				var normal: Vector3 = walls[key][1]
				if local.dot(normal) > absf(normal.dot(size)) / 2.0 - 0.5:
					var along: Vector3 = walls[key][0]
					var reach: = maxf(store.size(row).x, store.size(row).z) / 2.0
					var span: Array = winged.get(key, [INF, - INF])
					winged[key] = [minf(span[0], local.dot(along) - reach), maxf(span[1], local.dot(along) + reach)]
	if door.is_empty() or (door[0] as String).is_empty():
		return [0, 0]
	for row in rows:
		var part: = store.name_at(row)
		if part in DOOR_GROUP and part != "Door":
			var local: Vector3 = inverse * store.position(row)
			var along: Vector3 = walls[door[0]][0]
			if absf((local - door[1]).dot(along)) < 6.0 and local.y - floor_y < STOREY + 2.0:
				door[2].append(row)

	for entry: Array in loose:
		var local: Vector3 = entry[1]
		var wall: String = wall_of.call(local, thin_of.call(entry[0]) if store.name_at(entry[0]) in ["Window", "WindowFrame", "Shutter", "GlazingBar"] else Vector3.ZERO)
		if not windows.has(wall):
			continue
		var best: Array = []
		var nearest: = 5.5
		for window: Array in windows[wall]:
			var away: = Vector2((local - window[1]).dot(walls[wall][0]), local.y - (window[1] as Vector3).y).length()
			if away < nearest:
				nearest = away
				best = window
		if not best.is_empty():
			best[2].append(entry[0])

	var size_w: = float(era["window"][0])
	var size_h: = float(era["window"][1])
	var placed: = 0
	var hidden: = 0
	for wall: String in windows:
		var along: Vector3 = walls[wall][0]
		var length: float = walls[wall][2]
		var by_storey: Dictionary = {}
		for window: Array in windows[wall]:
			if not by_storey.has(window[0]):
				by_storey[window[0]] = []
			by_storey[window[0]].append(window)
		for storey: int in by_storey:
			var have: Array = by_storey[storey]

			var module: = float(era["module"])
			var count: = maxi(int((length - EDGE * 2.0) / module), 1)
			var slots: Array[float] = []
			var start: = - (count - 1) * module / 2.0 + rng.randf_range(-0.25, 0.25) * module
			for index in count:
				slots.append(start + index * module)
			var door_at: = INF
			if wall == door[0] and storey == 0:
				door_at = (door[1] as Vector3).dot(along)
				var wanted: = ( - length / 2.0 + float(era["door"][1]) * length) * (1.0 if rng.randf() < 0.5 else -1.0)
				door_at = wanted
				for row: int in door[2]:
					_move(store, frame, row, along * (wanted - (door[1] as Vector3).dot(along)), Vector3.ZERO, 1.0, 1.0)
				var clear: = float(era["door"][0]) / 2.0 + DOOR_CLEAR + size_w / 2.0
				slots = slots.filter( func(x: float) -> bool: return absf(x - door_at) > clear and absf(x) < length / 2.0 - EDGE - size_w / 2.0)
			else:
				slots = slots.filter( func(x: float) -> bool: return absf(x) < length / 2.0 - EDGE - size_w / 2.0)
			if winged.has(wall) and storey == 0:
				var span: Array = winged[wall]
				slots = slots.filter( func(x: float) -> bool: return x < float(span[0]) - size_w / 2.0 - 1.0 or x > float(span[1]) + size_w / 2.0 + 1.0)
			if slots.is_empty():
				for window: Array in have:
					for row: int in window[2]:
						store.set_transparency(row, 1.0)
						store.set_flags(row, 0)
					hidden += 1
				continue

			var wanted_count: = clampi(roundi(slots.size() * float(era["fill"]) + rng.randf_range(-0.6, 0.6)), 1, have.size())
			var chosen: Array[float] = []
			var pool: = slots.duplicate()
			while chosen.size() < wanted_count and not pool.is_empty():
				chosen.append(pool.pop_at(rng.randi_range(0, pool.size() - 1)))
			chosen.sort()
			have.sort_custom( func(a: Array, b: Array) -> bool: return (a[1] as Vector3).dot(along) < (b[1] as Vector3).dot(along))

			var small: = false
			if era.has("bathroom") and door_at != INF and have.size() > chosen.size():
				var x: = door_at + signf( - door_at if door_at != 0.0 else 1.0) * (float(era["door"][0]) / 2.0 + DOOR_CLEAR + 1.5)
				if absf(x) < length / 2.0 - EDGE:
					chosen.append(x)
					small = true
			for index in have.size():
				var window: Array = have[index]
				if index >= chosen.size():
					for row: int in window[2]:
						store.set_transparency(row, 1.0)
						store.set_flags(row, 0)
					hidden += 1
					continue
				var tiny: bool = small and index == chosen.size() - 1
				var w: = float(era["bathroom"][0]) if tiny else size_w
				var h: = float(era["bathroom"][1]) if tiny else size_h
				var sill: = floor_y + storey * STOREY + (8.0 if tiny else float(era["sill"]))
				var centre: Vector3 = window[1]
				var old_size: = store.size(window[2][0])
				var old_w: = maxf(old_size.x, old_size.z)
				var target: = Vector3(0, sill + h / 2.0, 0) + along * chosen[index]
				var shift: = along * (chosen[index] - centre.dot(along)) + Vector3(0, target.y - centre.y, 0)
				for row: int in window[2]:
					var part: = store.name_at(row)
					if part == "Shutter" and not era.get("shutters", false):
						store.set_transparency(row, 1.0)
						store.set_flags(row, 0)
						continue
					_move(store, frame, row, shift, centre, w / old_w, h / old_size.y, along, part == "Shutter")
				placed += 1
				_extras(kit, folder, frame, era, centre + shift, along, walls[wall][1], w, h)
	return [placed, hidden]




static func _move(store: PartStore, frame: Transform3D, row: int, shift: Vector3, centre: Vector3, wide: float, tall: float, along: = Vector3.ZERO, shutter: = false) -> void :
	var place: = store.transform(row)
	var local: = frame.affine_inverse() * place.origin
	var offset: = local - centre
	if along != Vector3.ZERO:
		var a: = offset.dot(along)
		var moved_a: = a * wide if not shutter else signf(a) * (absf(a) + (wide - 1.0) * 2.4)
		offset += along * (moved_a - a)
		offset.y *= tall
	local = centre + offset + shift
	place.origin = frame * local
	store.set_transform(row, place)
	if along != Vector3.ZERO:
		var size: = store.size(row)
		var world_along: = (frame.basis * along).normalized()
		var axes: = [place.basis.x.normalized(), place.basis.y.normalized(), place.basis.z.normalized()]
		var scaled: = size
		for axis in 3:
			var dot: = absf((axes[axis] as Vector3).dot(world_along))
			if dot > 0.7 and not shutter:
				scaled[axis] = size[axis] * wide
			elif absf((axes[axis] as Vector3).y) > 0.7:
				scaled[axis] = size[axis] * tall
		store.set_size(row, scaled)



static func _extras(kit: PolishKit, folder: int, frame: Transform3D, era: Dictionary, centre: Vector3, along: Vector3, out: Vector3, w: float, h: float) -> void :
	var basis: = frame.basis * Basis(along, Vector3.UP, along.cross(Vector3.UP))
	if era.has("surround"):
		kit.box(folder, Transform3D(basis, frame * (centre - out * 0.02)), Vector3(w + 1.1, h + 1.1, 0.12), Color("#" + String(era["surround"])), "Concrete", "StoneSurround")
	if era.has("roller") and w > 3.0:
		kit.box(folder, Transform3D(basis, frame * (centre + Vector3(0, h / 2.0 + 0.5, 0) + out * 0.25)), Vector3(w + 0.4, 0.8, 0.5), Color("#" + String(era["roller"])), "SmoothPlastic", "RollerBox")


static func _kind(layout: Array, spot: Vector2) -> String:
	var best: = "house"
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building["kind"]
	return best
