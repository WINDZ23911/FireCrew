class_name World
extends Node3D










const CHUNK: = 160.0

const REACH: = [0.0, 340.0, 620.0]


const SWAY: = {
	"Leaves": 2, "FarTree": 2, "Needles": 1, "Woods": 1, 
	"Bush": 3, "WildShrub": 3, "FenceBush": 3, "PlanterBush": 3, "Plant": 3, 
}
const SWAY_STUDS: = [0.0, 0.7, 1.1, 0.4]
const WIND: = Vector3(0.85, 0.0, 0.53)
const LAYER_SOLID: = 1
const LAYER_QUERY: = 2
const LAYER_PLAYER: = 4
const LAYER_VEHICLE: = 8
const LAYER_PROP: = 16
const LAYER_POST: = 32

static var current: World

var store: PartStore
var _mesh_of: Array = []
var _index_of: = PackedInt32Array()
var _baked_of: Array = []
var _body_of: Array = []
var _shape_of: = PackedInt32Array()
var _rows_of_body: Dictionary = {}
var _hidden: Dictionary = {}
var _unsolid: Dictionary = {}
var _bodies: Array[RID] = []
var _shapes: Array[RID] = []
var _shape_cache: Dictionary = {}
var _dirty_baked: Dictionary = {}
var _reached: Array = []
var _reach_scale: = 1.0




const FAR_HARD: = ["Asphalt", "Pavement", "Concrete", "Cobblestone"]
const FAR_LEFT_OUT: = ["Neon", "ForceField"]
const FAR_MARGIN: = 40.0
const FAR_CELL: = 2
var _far: = 0.0
var _near_groups: Array = []
var _far_groups: Array[GeometryInstance3D] = []
var _far_roots: Dictionary = {}
var _far_copy: Dictionary = {}
var _far_baked: Dictionary = {}
var _far_square_of: Dictionary = {}
var _buffers: Dictionary = {}

static var _unit_meshes: Dictionary = {}


class BakedGroup:
	var instance: MeshInstance3D
	var material: Material
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var colors: = PackedColorArray()


	var middles: = PackedVector2Array()
	var feet: = PackedVector2Array()
	var first: Dictionary = {}
	var counts: Dictionary = {}

	func rebuild() -> void :
		var arrays: = []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = vertices
		arrays[Mesh.ARRAY_NORMAL] = normals
		arrays[Mesh.ARRAY_COLOR] = colors
		arrays[Mesh.ARRAY_TEX_UV] = middles
		arrays[Mesh.ARRAY_TEX_UV2] = feet
		var mesh: = ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		mesh.surface_set_material(0, material)
		instance.mesh = mesh


func _init() -> void :
	current = self


func _exit_tree() -> void :
	for body in _bodies:
		PhysicsServer3D.free_rid(body)
	for shape in _shapes:
		PhysicsServer3D.free_rid(shape)
	if current == self:
		current = null



func build(parts: PartStore) -> void :
	store = parts
	var count: = store.count
	_mesh_of.resize(count)
	_index_of.resize(count)
	_baked_of.resize(count)
	_body_of.resize(count)
	_shape_of.resize(count)


	var sway_of_name: Dictionary = {}
	for index in store.names.size():
		if SWAY.has(store.names[index]):
			sway_of_name[index] = SWAY[store.names[index]]
	var drawn: Dictionary = {}
	var collided: Dictionary = {}
	var data: = store.data
	var columns: = PartStore.COLUMNS
	var glass: = store.materials.find("Glass")



	var trunks: = [store.names.find("Trunk"), store.names.find("FarTrunk")]
	for row in count:
		var at: = row * columns
		var cx: = floori(data[at + PartStore.POS] / CHUNK)
		var cz: = floori(data[at + PartStore.POS + 2] / CHUNK)
		var flags: = int(data[at + PartStore.FLAGS])
		var transparency: = data[at + PartStore.TRANSPARENCY]
		if transparency < 0.99:
			var key: = Vector4i(
				cx, cz, 
				int(data[at + PartStore.MATERIAL]) * 8 + int(data[at + PartStore.SHAPE]), 
				(1 if transparency > 0.01 else 0) + (2 if flags & PartStore.SHADOW else 0)
					+ 4 * (0 if int(data[at + PartStore.NAME]) in trunks else _reach_class(data[at + PartStore.SIZE], data[at + PartStore.SIZE + 1], data[at + PartStore.SIZE + 2]))
					+ 16 * int(sway_of_name.get(int(data[at + PartStore.NAME]), 0))

					+ (256 if row >= store.exported and int(data[at + PartStore.MATERIAL]) == glass else 0)
			)
			if not drawn.has(key):
				drawn[key] = PackedInt32Array()
			drawn[key].append(row)
		var layers: = (LAYER_SOLID if flags & PartStore.COLLIDE else 0) | (LAYER_QUERY if flags & PartStore.QUERY else 0)
		if layers != 0:
			var key: = Vector3i(cx, cz, layers)
			if not collided.has(key):
				collided[key] = PackedInt32Array()
			collided[key].append(row)

	var far_parts: Dictionary = {}
	var far_wedges: Dictionary = {}
	for key: Vector4i in drawn:
		var shape: = key.z % 8
		var material: String = store.materials[key.z / 8]
		var transparent: = key.w & 1 == 1
		var reach: int = (key.w / 4) % 4
		var sway_class: int = (key.w % 256) / 16
		var sway: float = SWAY_STUDS[sway_class]
		var rooms: = key.w < 256
		var shadows: = key.w & 2 == 2 and reach != 1
		var made: GeometryInstance3D
		var wedge: = shape == PartStore.Shape.WEDGE or shape == PartStore.Shape.CORNER_WEDGE
		if wedge:
			made = _bake(drawn[key], WorldMaterials.of(material, transparent, true, 0.0, rooms), shadows)
		else:
			made = _instance(drawn[key], shape, WorldMaterials.of(material, transparent, false, sway, rooms), shadows)
		if reach > 0:
			made.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
			_reached.append([made, reach])
		elif not transparent and not material in FAR_LEFT_OUT:


			var square: = Vector2i(floori(key.x / float(FAR_CELL)), floori(key.y / float(FAR_CELL)))
			_near_groups.append([made, square])
			if wedge:
				if not far_wedges.has(square):
					far_wedges[square] = []
				far_wedges[square].append(_baked_of[drawn[key][0]])
			else:
				var kind: = 3 if material == "Glass" else (2 if material == "Asphalt" else (1 if material in FAR_HARD else 0))
				var far_key: = Vector4i(square.x, square.y, shape, kind)
				if not far_parts.has(far_key):
					far_parts[far_key] = []
				far_parts[far_key].append([(made as MultiMeshInstance3D).multimesh, drawn[key]])
	_build_far(far_parts, far_wedges)
	_buffers.clear()
	set_reach_scale(_reach_scale)
	set_far(Graphics.far_distance(Settings.quality))
	for key: Vector3i in collided:
		_collide(collided[key], key.z)



func set_reach_scale(scale: float) -> void :
	_reach_scale = scale
	for entry: Array in _reached:
		var made: GeometryInstance3D = entry[0]
		var far: float = REACH[entry[1]] * scale
		made.visibility_range_end = far
		made.visibility_range_end_margin = far * 0.1





func _build_far(parts: Dictionary, wedges: Dictionary) -> void :
	var started: = Time.get_ticks_msec()
	for far_key: Vector4i in parts:
		var buffer: = PackedFloat32Array()
		var count: = 0
		var copied: Array = []
		for entry: Array in parts[far_key]:
			var source: MultiMesh = entry[0]
			buffer.append_array(_buffers[source])
			copied.append([source, count])
			count += source.instance_count
		var multimesh: = MultiMesh.new()
		multimesh.transform_format = MultiMesh.TRANSFORM_3D
		multimesh.use_colors = true
		multimesh.use_custom_data = true
		multimesh.mesh = unit_mesh(far_key.z)
		multimesh.instance_count = count
		multimesh.buffer = buffer
		for pair: Array in copied:
			_far_copy[pair[0]] = [multimesh, pair[1]]
		var drawn: = MultiMeshInstance3D.new()
		drawn.multimesh = multimesh
		drawn.material_override = WorldMaterials.far(far_key.w, false)
		_add_far(drawn, Vector2i(far_key.x, far_key.y))
	for cell: Vector2i in wedges:
		var drawn: = MeshInstance3D.new()
		drawn.material_override = WorldMaterials.far(0, true)
		_far_baked[cell] = [drawn, wedges[cell]]
		for group: BakedGroup in wedges[cell]:
			_far_square_of[group] = cell
		_merge_wedges(cell)
		_add_far(drawn, cell)
	if OS.get_cmdline_user_args().has("--far-trace"):
		print("far squares: %d groups in %d cells for %d near ones, built in %d ms" % [_far_groups.size(), _far_roots.size(), _near_groups.size(), Time.get_ticks_msec() - started])



func _add_far(drawn: GeometryInstance3D, cell: Vector2i) -> void :
	var side: = CHUNK * FAR_CELL
	drawn.custom_aabb = AABB(Vector3(cell.x * side, -40.0, cell.y * side), Vector3(side, 200.0, side))
	drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	drawn.visible = false
	add_child(drawn)
	_far_groups.append(drawn)
	if not _far_roots.has(cell):
		_far_roots[cell] = drawn



func _far_of(row: int) -> Array:
	var source: MultiMesh = _mesh_of[row]
	if source == null or not _far_copy.has(source):
		return []
	var pair: Array = _far_copy[source]
	return [pair[0], int(pair[1]) + _index_of[row]]



func _merge_wedges(square: Vector2i) -> void :
	var entry: Array = _far_baked[square]
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var colors: = PackedColorArray()
	var middles: = PackedVector2Array()
	var feet: = PackedVector2Array()
	for group: BakedGroup in entry[1]:
		vertices.append_array(group.vertices)
		normals.append_array(group.normals)
		colors.append_array(group.colors)
		middles.append_array(group.middles)
		feet.append_array(group.feet)
	if vertices.is_empty():
		return
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV] = middles
	arrays[Mesh.ARRAY_TEX_UV2] = feet
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	(entry[0] as MeshInstance3D).mesh = mesh



func set_far(distance: float) -> void :
	_far = distance
	for made in _far_groups:
		made.visible = distance > 0.0
		made.visibility_range_begin = distance
		made.visibility_range_begin_margin = FAR_MARGIN
		made.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DEPENDENCIES
	for entry: Array in _near_groups:
		var made: GeometryInstance3D = entry[0]
		var root: GeometryInstance3D = _far_roots.get(entry[1])
		made.visibility_parent = made.get_path_to(root) if distance > 0.0 and root != null else NodePath()





static func _reach_class(x: float, y: float, z: float) -> int:
	var middle: = maxf(minf(x, y), minf(maxf(x, y), z))
	if middle < 0.9:
		return 1
	if middle < 2.6:
		return 2
	return 0



func _instance(rows: PackedInt32Array, shape: int, material: Material, shadows: bool) -> GeometryInstance3D:
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = true

	multimesh.use_custom_data = true
	multimesh.mesh = unit_mesh(shape)
	multimesh.instance_count = rows.size()
	var buffer: = PackedFloat32Array()
	buffer.resize(rows.size() * 20)
	var data: = store.data
	var columns: = PartStore.COLUMNS
	var write: = 0
	for index in rows.size():
		var row: = rows[index]
		var at: = row * columns
		var sx: = data[at + PartStore.SIZE]
		var sy: = data[at + PartStore.SIZE + 1]
		var sz: = data[at + PartStore.SIZE + 2]
		if shape == PartStore.Shape.CYLINDER:
			sy = minf(sy, sz)
			sz = sy
		elif shape == PartStore.Shape.BALL:
			sx = minf(sx, minf(sy, sz))
			sy = sx
			sz = sx
		var rot: = at + PartStore.ROT
		for line in 3:
			buffer[write] = data[rot + line * 3] * sx
			buffer[write + 1] = data[rot + line * 3 + 1] * sy
			buffer[write + 2] = data[rot + line * 3 + 2] * sz
			buffer[write + 3] = data[at + PartStore.POS + line]
			write += 4
		buffer[write] = data[at + PartStore.COLOR]
		buffer[write + 1] = data[at + PartStore.COLOR + 1]
		buffer[write + 2] = data[at + PartStore.COLOR + 2]
		buffer[write + 3] = 1.0 - data[at + PartStore.TRANSPARENCY]
		var wear: = data[at + PartStore.REFLECTANCE]
		buffer[write + 4] = wear - PartStore.WEAR if wear >= PartStore.WEAR else 0.0
		write += 8
		_mesh_of[row] = multimesh
		_index_of[row] = index
	multimesh.buffer = buffer
	_buffers[multimesh] = buffer
	var instance: = MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return instance



func _bake(rows: PackedInt32Array, material: Material, shadows: bool) -> GeometryInstance3D:
	var group: = BakedGroup.new()
	group.material = material
	for row in rows:
		var corners: = wedge_corners(store.shape(row))
		var place: = store.transform(row).scaled_local(store.size(row))
		var color: = store.color(row)
		color.a = 1.0 - store.transparency(row)
		group.first[row] = group.vertices.size()
		var middle: = place * solid_middle(corners)
		var foot: = INF
		for corner: Vector3 in corners:
			foot = minf(foot, (place * corner).y)
		var where: = Vector2(place.origin.x, place.origin.z)
		var height: = Vector2(place.origin.y, foot)
		for face: Array in wedge_faces(store.shape(row)):
			var a: Vector3 = place * corners[face[0]]
			var b: Vector3 = place * corners[face[1]]
			var c: Vector3 = place * corners[face[2]]
			var normal: = (c - a).cross(b - a)
			if normal.length_squared() < 1e-12:
				continue
			normal = normal.normalized()

			if normal.dot((a + b + c) / 3.0 - middle) < 0.0:
				var swap: = b
				b = c
				c = swap
				normal = - normal
			group.vertices.append_array([a, b, c])
			group.normals.append_array([normal, normal, normal])
			group.colors.append_array([color, color, color])
			group.middles.append_array([where, where, where])
			group.feet.append_array([height, height, height])
		group.counts[row] = group.vertices.size() - group.first[row]
		_baked_of[row] = group
	group.instance = MeshInstance3D.new()
	group.instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	group.rebuild()
	add_child(group.instance)
	return group.instance


func _collide(rows: PackedInt32Array, layers: int) -> void :
	var body: = PhysicsServer3D.body_create()
	PhysicsServer3D.body_set_mode(body, PhysicsServer3D.BODY_MODE_STATIC)
	PhysicsServer3D.body_set_collision_layer(body, layers)
	PhysicsServer3D.body_set_collision_mask(body, 0)
	var listed: = PackedInt32Array()
	for row in rows:
		var shape: = shape_rid(store.shape(row), store.size(row))
		var place: = store.transform(row)
		if store.shape(row) == PartStore.Shape.CYLINDER:
			place = place * Transform3D(Basis(Vector3.BACK, PI / 2), Vector3.ZERO)
		PhysicsServer3D.body_add_shape(body, shape, place)
		_body_of[row] = body
		_shape_of[row] = listed.size()
		listed.append(row)
	_rows_of_body[body] = listed

	PhysicsServer3D.body_set_space(body, get_world_3d().space)
	_bodies.append(body)



func shape_rid(shape: int, size: Vector3) -> RID:
	var key: = [shape, size]
	if _shape_cache.has(key):
		return _shape_cache[key]
	var rid: RID
	match shape:
		PartStore.Shape.CYLINDER:
			rid = PhysicsServer3D.cylinder_shape_create()
			PhysicsServer3D.shape_set_data(rid, {"radius": minf(size.y, size.z) / 2.0, "height": size.x})
		PartStore.Shape.BALL:
			rid = PhysicsServer3D.sphere_shape_create()
			PhysicsServer3D.shape_set_data(rid, minf(size.x, minf(size.y, size.z)) / 2.0)
		PartStore.Shape.ELLIPSOID:
			rid = PhysicsServer3D.sphere_shape_create()
			PhysicsServer3D.shape_set_data(rid, (size.x + size.y + size.z) / 6.0)
		PartStore.Shape.WEDGE, PartStore.Shape.CORNER_WEDGE:
			rid = PhysicsServer3D.convex_polygon_shape_create()
			var points: = PackedVector3Array()
			for corner: Vector3 in wedge_corners(shape):
				points.append(corner * size)
			PhysicsServer3D.shape_set_data(rid, points)
		_:
			rid = PhysicsServer3D.box_shape_create()
			PhysicsServer3D.shape_set_data(rid, size / 2.0)
	_shape_cache[key] = rid
	_shapes.append(rid)
	return rid



static func unit_mesh(shape: int) -> Mesh:
	if _unit_meshes.has(shape):
		return _unit_meshes[shape]
	var mesh: Mesh
	match shape:
		PartStore.Shape.CYLINDER:
			var upright: = CylinderMesh.new()
			upright.top_radius = 0.5
			upright.bottom_radius = 0.5
			upright.height = 1.0
			upright.radial_segments = 16
			upright.rings = 1
			mesh = _turned(upright, Basis(Vector3.BACK, - PI / 2))
		PartStore.Shape.BALL, PartStore.Shape.ELLIPSOID:
			var ball: = SphereMesh.new()
			ball.radius = 0.5
			ball.height = 1.0
			ball.radial_segments = 14
			ball.rings = 7
			mesh = ball
		PartStore.Shape.WEDGE, PartStore.Shape.CORNER_WEDGE:
			mesh = _wedge_mesh(shape)
		_:
			var box: = BoxMesh.new()
			box.size = Vector3.ONE
			mesh = box
	_unit_meshes[shape] = mesh
	return mesh


static func _turned(source: PrimitiveMesh, turn: Basis) -> ArrayMesh:
	var arrays: = source.get_mesh_arrays()
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
	for index in vertices.size():
		vertices[index] = turn * vertices[index]
		normals[index] = turn * normals[index]
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TANGENT] = null
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh




static func _wedge_mesh(shape: int) -> ArrayMesh:
	var corners: = wedge_corners(shape)
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	for face: Array in wedge_faces(shape):
		var a: Vector3 = corners[face[0]]
		var b: Vector3 = corners[face[1]]
		var c: Vector3 = corners[face[2]]
		var normal: = (c - a).cross(b - a).normalized()
		if normal.dot((a + b + c) / 3.0 - solid_middle(corners)) < 0.0:
			var swap: = b
			b = c
			c = swap
			normal = - normal
		vertices.append_array([a, b, c])
		normals.append_array([normal, normal, normal])
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh




static func wedge_corners(shape: int) -> Array:
	if shape == PartStore.Shape.CORNER_WEDGE:
		return [
			Vector3(-0.5, -0.5, -0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, -0.5, 0.5), Vector3(-0.5, -0.5, 0.5), 
			Vector3(0.5, 0.5, -0.5), 
		]
	return [
		Vector3(-0.5, -0.5, -0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, -0.5, 0.5), Vector3(-0.5, -0.5, 0.5), 
		Vector3(-0.5, 0.5, 0.5), Vector3(0.5, 0.5, 0.5), 
	]




static func solid_middle(corners: Array) -> Vector3:
	var sum: = Vector3.ZERO
	for corner: Vector3 in corners:
		sum += corner
	return sum / corners.size()


static func wedge_faces(shape: int) -> Array:
	if shape == PartStore.Shape.CORNER_WEDGE:
		return [[0, 1, 2], [0, 2, 3], [0, 1, 4], [1, 2, 4], [2, 3, 4], [3, 0, 4]]
	return [[0, 1, 2], [0, 2, 3], [2, 3, 4], [2, 4, 5], [0, 1, 5], [0, 5, 4], [0, 3, 4], [1, 2, 5]]





func set_color(id: int, color: Color) -> void :
	var row: int = store.row_of.get(id, -1)
	if row < 0:
		return
	var at: = row * PartStore.COLUMNS + PartStore.COLOR
	store.data[at] = color.r
	store.data[at + 1] = color.g
	store.data[at + 2] = color.b
	color.a = 1.0 - store.transparency(row)
	var far: = _far_of(row)
	if not far.is_empty():
		(far[0] as MultiMesh).set_instance_color(far[1], color)
	if _mesh_of[row]:
		_mesh_of[row].set_instance_color(_index_of[row], color)
	elif _baked_of[row]:
		var group: BakedGroup = _baked_of[row]
		for index in range(group.first[row], group.first[row] + group.counts[row]):
			group.colors[index] = color
		if _dirty_baked.is_empty():
			_rebuild_baked.call_deferred()
		_dirty_baked[group] = true






func set_glow(id: int, color: Color, glow: float) -> void :
	set_color(id, color)
	var row: int = store.row_of.get(id, -1)
	if row >= 0 and _mesh_of[row] and glow > 0.0:
		color.a = 1.0 + glow
		_mesh_of[row].set_instance_color(_index_of[row], color)
		var far: = _far_of(row)
		if not far.is_empty():
			(far[0] as MultiMesh).set_instance_color(far[1], color)



func glow_of(id: int) -> float:
	var row: int = store.row_of.get(id, -1)
	if row < 0 or not _mesh_of[row]:
		return 0.0
	return maxf(_mesh_of[row].get_instance_color(_index_of[row]).a - 1.0, 0.0)


func _rebuild_baked() -> void :
	var squares: = {}
	for group: BakedGroup in _dirty_baked:
		group.rebuild()
		if _far_square_of.has(group):
			squares[_far_square_of[group]] = true
	_dirty_baked.clear()
	for square: Vector2i in squares:
		_merge_wedges(square)



func set_hidden(id: int, hidden: bool) -> void :
	var row: int = store.row_of.get(id, -1)
	if row < 0 or hidden == _hidden.has(row):
		return
	if not _mesh_of[row]:

		var group: BakedGroup = _baked_of[row]
		if group == null:
			return
		var first: int = group.first[row]
		var count: int = group.counts[row]
		if hidden:
			_hidden[row] = group.vertices.slice(first, first + count)
			for index in range(first, first + count):
				group.vertices[index] = store.position(row)
		else:
			var kept: PackedVector3Array = _hidden[row]
			for index in count:
				group.vertices[first + index] = kept[index]
			_hidden.erase(row)
		if _dirty_baked.is_empty():
			_rebuild_baked.call_deferred()
		_dirty_baked[group] = true
		return
	var multimesh: MultiMesh = _mesh_of[row]
	var far: = _far_of(row)
	if hidden:
		_hidden[row] = multimesh.get_instance_transform(_index_of[row])
		multimesh.set_instance_transform(_index_of[row], Transform3D(Basis.from_scale(Vector3.ZERO), store.position(row)))
		if not far.is_empty():
			(far[0] as MultiMesh).set_instance_transform(far[1], Transform3D(Basis.from_scale(Vector3.ZERO), store.position(row)))
	else:
		multimesh.set_instance_transform(_index_of[row], _hidden[row])
		if not far.is_empty():
			(far[0] as MultiMesh).set_instance_transform(far[1], _hidden[row])
		_hidden.erase(row)


func set_solid(id: int, solid: bool) -> void :
	var row: int = store.row_of.get(id, -1)
	if row >= 0 and _body_of[row]:
		PhysicsServer3D.body_set_shape_disabled(_body_of[row], _shape_of[row], not solid)
		if solid:
			_unsolid.erase(row)
		else:
			_unsolid[row] = true



func is_solid_row(row: int) -> bool:
	return _body_of[row] and not _unsolid.has(row)



func row_hit(result: Dictionary) -> int:
	if result.is_empty():
		return -1
	var rows: Variant = _rows_of_body.get(result.get("rid"))
	if rows == null:
		return -1
	return rows[result.get("shape", 0)]


func name_hit(result: Dictionary) -> String:
	var row: = row_hit(result)
	return store.name_at(row) if row >= 0 else ""



func raycast(from: Vector3, to: Vector3, mask: = LAYER_QUERY, exclude: Array[RID] = []) -> Dictionary:
	var query: = PhysicsRayQueryParameters3D.create(from, to, mask, exclude)
	return get_world_3d().direct_space_state.intersect_ray(query)



func take(id: int, solid: = true) -> PartNode:
	var row: int = store.row_of.get(id, -1)
	if row < 0:
		return null
	set_hidden(id, true)
	set_solid(id, false)
	var node: = PartNode.make(store, row, solid)
	add_child(node)
	return node
