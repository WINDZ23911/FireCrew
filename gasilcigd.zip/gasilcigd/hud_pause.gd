class_name HudPause
extends Control














const SIZE: = Vector2(1060, 820)
const SIDE: = 260.0
const COLUMN: = 350.0
const GAP: = 30.0
const ROW: = 34.0
const TABS: Array[String] = ["game", "controls", "display", "sound", "access"]

const RECORD_KINDS: = ["fire", "crash", "tree", "flood", "medical", "rescue", "hazmat", "accident", "alarm"]

const PLACE_ORDER: Array[String] = ["foot", "wheel", "ladder", "any"]

static var current: HudPause

var open: = false
var tab: = "game"
var _over_title: TitleScreen = null
var _home: Node = null
var _title_layer: CanvasLayer = null
var _plate: Control
var _pages: Dictionary = {}
var _tab_buttons: Dictionary = {}
var _said: Array = []
var _choices: Array = []
var _values: Array = []
var _language_buttons: Dictionary = {}
var _crew_buttons: Array[Button] = []
var _code_caption: Label
var _code: Button
var _crew_net: Button
var _records: Array = []
var _first_shift: Button
var _tutorial: Button
var _last_calls: Array[Button] = []
var _key_rows: Dictionary = {}
var _key_status: Label
var _waiting: = ""
var _swatches: Array[ColorRect] = []
var _mouse_rows: Array = []
var _resume: Button
var _main_menu: Button
var _title_label: Label
var _mic_device: Button
var _mic_meter: ColorRect
var _mic_hint: Label




static func word(key: String) -> String:
	if Text.has("ui.pause." + key):
		return Text.say(Text.m("ui.pause." + key))
	var said: = Text.say(Text.m(key))
	return said.left(1).to_upper() + said.substr(1).to_lower()



static func action_word(action: String) -> String:
	if action.begins_with("slot_"):
		return Text.say(Text.f("ui.actions.slot", [int(action.substr(5))]))
	if Text.has("ui.actions." + action):
		return Text.say(Text.m("ui.actions." + action))
	return action.replace("_", " ").capitalize()


func _ready() -> void :
	current = self

	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false

	var dim: = ColorRect.new()
	dim.color = Color(0.02, 0.02, 0.03, 0.62)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)

	_plate = Ui.plate(SIZE)
	_plate.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_plate.position = - SIZE / 2
	add_child(_plate)
	Ui.stripe(_plate, 160)

	var title: = Ui.display("", 44)
	title.position = Vector2(32, 18)
	_plate.add_child(title)
	_said.append([title, "title", false])
	_title_label = title


	var discord: = _button(_plate, "", Vector2(32, SIZE.y - 32 - 44 - 52 - 52), Vector2(SIDE - 32, 40))
	discord.text = "DISCORD"
	discord.tooltip_text = TitleScreen.DISCORD
	discord.pressed.connect( func() -> void : OS.shell_open(TitleScreen.DISCORD))

	var resume: = _button(_plate, "resume", Vector2(32, 100), Vector2(SIDE - 32, 48), true)
	resume.pressed.connect(close)
	_resume = resume
	var y: = 176.0
	for name: String in TABS:
		var button: = _button(_plate, "tabs." + name, Vector2(32, y), Vector2(SIDE - 32, 46))
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.set_meta("indent", 18.0)
		button.pressed.connect(show_tab.bind(name))
		_tab_buttons[name] = button
		y += 54

	_main_menu = _button(_plate, "mainMenu", Vector2(32, SIZE.y - 32 - 44 - 52), Vector2(SIDE - 32, 44))
	_main_menu.pressed.connect( func() -> void :
		Settings.save()
		PlayerData.save()
		Edition.restart()
	)
	var quit: = _button(_plate, "quit", Vector2(32, SIZE.y - 32 - 44), Vector2(SIDE - 32, 44))
	quit.pressed.connect( func() -> void :
		Settings.save()
		Game.quit()
	)
	var rule: = ColorRect.new()
	rule.color = Color(1, 1, 1, 0.1)
	rule.position = Vector2(SIDE + GAP / 2, 30)
	rule.size = Vector2(1, SIZE.y - 60)
	_plate.add_child(rule)

	for name: String in TABS:
		var page: = Control.new()
		page.position = Vector2(SIDE + GAP + 8, 30)
		page.size = Vector2(SIZE.x - SIDE - GAP - 8 - 32, SIZE.y - 60)
		page.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_plate.add_child(page)
		_pages[name] = page
	_game_page(_pages["game"])
	_controls_page(_pages["controls"])
	_display_page(_pages["display"])
	_sound_page(_pages["sound"])
	_access_page(_pages["access"])

	Text.language_changed.connect( func(_code_now: String) -> void : _say_all())
	Controls.bindings_changed.connect(_show_keys)
	show_tab(tab)
	_say_all()
	_show_code()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hud-tab=") and arg.substr(10) in TABS:
			show_tab(arg.substr(10))
	if OS.get_cmdline_user_args().has("--hud-open=pause"):
		show_menu.call_deferred()


func show_tab(name: String) -> void :
	tab = name
	_cancel_rebind()
	for each: String in _pages:
		_pages[each].visible = each == name
	for each: String in _tab_buttons:
		_paint(_tab_buttons[each], each == name)




func _game_page(page: Control) -> void :
	var y: = 0.0
	_heading(page, "language", Vector2(0, y))
	y += 24
	var count_languages: = Text.LANGUAGES.size()
	var each: = (COLUMN - 10 * (count_languages - 1)) / count_languages
	var x: = 0.0
	for code: String in Text.LANGUAGES:
		var button: = _button(page, "", Vector2(x, y), Vector2(each, 42))
		button.pressed.connect(Settings.set_language.bind(code))
		_language_buttons[code] = button
		x += each + 10
	y += 72

	if CrewService.enabled():
		_heading(page, "crew", Vector2(0, y))
		y += 24
		x = 0.0
		var sixth: = (COLUMN - 5 * 8) / 6
		for count in 6:
			var button: = _button(page, "", Vector2(x, y), Vector2(sixth, 42))
			button.text = str(count)
			button.pressed.connect( func() -> void :
				Settings.set_crew_size(count)
				_say_all()
			)
			_crew_buttons.append(button)
			x += sixth + 8
		y += 72

	_crew_net = _button(page, "", Vector2(0, y), Vector2(COLUMN, 48))
	_crew_net.pressed.connect( func() -> void :
		close()
		if Net.active():
			Net.leave_crew()
		else:
			Net.open_to_crew()
	)
	Net.stopped.connect(_show_code)
	y += 66
	_code_caption = _heading(page, "code", Vector2(0, y))
	_code = _button(page, "", Vector2(0, y + 24), Vector2(COLUMN, 48))
	_code.add_theme_font_size_override("font_size", 24)
	_code.clip_text = true
	_code.focus_mode = Control.FOCUS_NONE
	Net.listed.connect( func(_ok: bool) -> void : _show_code())
	y += 100

	_first_shift = _button(page, "", Vector2(0, y), Vector2(COLUMN, 44))
	_first_shift.pressed.connect( func() -> void :
		close()
		if FirstShift.current:
			FirstShift.current.begin(true)
	)

	_tutorial = _button(page, "", Vector2(0, y + 52), Vector2(COLUMN, 44))
	_tutorial.pressed.connect( func() -> void :
		close()
		if Tutorial.current:
			Tutorial.current.begin(true)
	)



	var right: = COLUMN + GAP
	_records_strip(page, Vector2(right, 0), COLUMN)
	_heading(page, "hud.pause.lastCalls", Vector2(right, 150))
	var cell: = COLUMN / 2.0
	for index in int(Config.Alarm.EndScreen.Kept):
		var button: = _button(page, "", Vector2(right + (index % 2) * cell, 174 + (index / 2) * 34), Vector2(cell - 6, 30))
		button.add_theme_font_size_override("font_size", 14)
		button.pressed.connect( func() -> void :
			var reports: = CallLog.recent()
			if index < reports.size() and HudDebrief.current:
				close()
				HudDebrief.current.open(reports[index])
		)
		_last_calls.append(button)


func _controls_page(page: Control) -> void :
	_heading(page, "sensitivity", Vector2(0, 0))
	_value(page, Vector2(0, 0), func() -> String: return Ui.decimal(Settings.sensitivity, 2) + "×")
	var sensitivity: = _slider(page, Vector2(0, 26), Settings.SENSITIVITY_MIN, Settings.SENSITIVITY_MAX, 0.05, Settings.sensitivity)
	sensitivity.value_changed.connect( func(value: float) -> void :
		Settings.set_sensitivity(value)
		_show_values()
	)
	_choice_row(page, "invertY", Vector2(COLUMN + GAP, 0), ["off", "on"], func() -> int: return int(Settings.invert_y), func(pick: int) -> void : Settings.set_invert_y(pick == 1))

	_choice_row(page, "controls", Vector2(0, 84), ["controlsSimple", "controlsClassic"], func() -> int: return Settings.controls, func(pick: int) -> void : Settings.set_controls(pick))
	_choice_row(page, "clickUse", Vector2(COLUMN + GAP, 84), ["off", "on"], func() -> int: return int(Settings.click_use), func(pick: int) -> void : Settings.set_click_use(pick == 1))
	const BELOW: = 84.0


	_key_status = Ui.label("", 15, Ui.DIM)
	_key_status.position = Vector2(0, 82 + BELOW)
	_key_status.size = Vector2(page.size.x - 190, 30)
	_key_status.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_key_status.clip_text = true
	page.add_child(_key_status)
	var reset: = _button(page, "reset", Vector2(page.size.x - 180, 80 + BELOW), Vector2(180, 34))
	reset.add_theme_font_size_override("font_size", 16)
	reset.pressed.connect( func() -> void :
		_cancel_rebind()
		Settings.reset_keys()
		_status(Text.m("ui.pause.resetDone"), Ui.DIM)
	)
	var scroll: = ScrollContainer.new()
	scroll.position = Vector2(0, 126 + BELOW)
	scroll.size = Vector2(page.size.x, page.size.y - 126 - BELOW)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	page.add_child(scroll)
	var list: = Control.new()
	list.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scroll.add_child(list)

	var columns: = {"foot": [0.0, 0.0], "wheel": [COLUMN + GAP - 16, 0.0], "ladder": [COLUMN + GAP - 16, 0.0], "any": [COLUMN + GAP - 16, 0.0]}
	var bottom: = 0.0
	var right_y: = 0.0
	for place: String in PLACE_ORDER:
		var x: float = columns[place][0]
		var y: float = 0.0 if place == "foot" else right_y
		_heading(list, "places." + place, Vector2(x, y))
		y += 26
		for action: String in Controls.bindings:
			if Controls.places(action)[0] != place:
				continue
			if action == "crew_order" and not CrewService.enabled():
				continue
			_key_row(list, action, Vector2(x, y))
			y += ROW
		if place == "foot":
			for button: String in Controls.BUTTONS:
				_mouse_rows.append([_row_words(list, Vector2(x, y)), button])
				var cap: = Ui.action_key(button)
				cap.position = Vector2(x + COLUMN - cap.size.x, y)
				list.add_child(cap)
				y += ROW
		else:
			right_y = y + 14
		bottom = maxf(bottom, y)
	list.custom_minimum_size = Vector2(page.size.x - 16, maxf(bottom, right_y) + 8)


func _display_page(page: Control) -> void :
	_choice_row(page, "graphics", Vector2(0, 0), ["veryLow", "low", "medium", "high"], func() -> int: return Settings.quality - Graphics.VERY_LOW, func(pick: int) -> void : Settings.set_quality(pick + Graphics.VERY_LOW))
	_choice_row(page, "window", Vector2(0, 90), ["windowed", "fullscreen"], func() -> int: return Settings.window_mode, func(pick: int) -> void : Settings.set_window_mode(pick))
	_choice_row(page, "vsync", Vector2(0, 180), ["off", "on"], func() -> int: return int(Settings.vsync), func(pick: int) -> void : Settings.set_vsync(pick == 1))
	var caps: Array = Config.Settings.FrameCaps
	var words: Array = []
	for cap: Variant in caps:
		words.append("none" if int(cap) == 0 else str(int(cap)))
	_choice_row(page, "frameCap", Vector2(0, 270), words, func() -> int: return _frame_cap(caps), func(pick: int) -> void : Settings.set_max_fps(int(caps[pick])))

	var right: = COLUMN + GAP
	_heading(page, "renderScale", Vector2(right, 0))
	_value(page, Vector2(right, 0), func() -> String: return "%d %%" % roundi(Settings.render_scale * 100))
	var scale: = _slider(page, Vector2(right, 26), float(Config.Settings.RenderScaleMin), 1.0, 0.05, Settings.render_scale)
	scale.value_changed.connect( func(value: float) -> void :
		Settings.set_render_scale(value)
		_show_values()
	)
	_heading(page, "fov", Vector2(right, 90))
	_value(page, Vector2(right, 90), func() -> String: return "%d°" % roundi(Settings.fov))
	var fov: = _slider(page, Vector2(right, 116), float(Config.Settings.FovMin), float(Config.Settings.FovMax), 1.0, Settings.fov)
	fov.value_changed.connect( func(value: float) -> void :
		Settings.set_fov(value)
		_show_values()
	)

	_heading(page, "hud.hudScale.title", Vector2(right, 180))
	_value(page, Vector2(right, 180), func() -> String: return Text.say(Text.f("hud.hudScale.value", [roundi(Settings.hud_scale * 100)])))
	var hud_scale: = _slider(page, Vector2(right, 206), float(Config.Hud.ScaleMin), float(Config.Hud.ScaleMax), float(Config.Hud.ScaleStep), Settings.hud_scale)
	hud_scale.value_changed.connect( func(value: float) -> void :
		Settings.set_hud_scale(value)
		Sounds.ui("ui_click")
		_show_values()
	)



static func _frame_cap(caps: Array) -> int:
	for index in caps.size():
		if int(caps[index]) == Settings.max_fps:
			return index
	return 0


func _sound_page(page: Control) -> void :
	var y: = 0.0
	for entry: Array in [
		["volume", func() -> float: return Settings.volume, Settings.set_volume], 
		["effects", func() -> float: return Settings.effects, Settings.set_effects], 
		["music", func() -> float: return Settings.music, Settings.set_music], 
		["uiVolume", func() -> float: return Settings.ui_volume, Settings.set_ui_volume], 

		["radioVolume", func() -> float: return Settings.radio_volume, Settings.set_radio_volume], 
		["micGain", func() -> float: return Settings.mic_gain, Settings.set_mic_gain], 
	]:
		var read: Callable = entry[1]
		var write: Callable = entry[2]
		var right: bool = entry[0] in ["radioVolume", "micGain"]
		var at: = Vector2(COLUMN + GAP if right else 0.0, (80.0 if entry[0] == "micGain" else 0.0) if right else y)
		_heading(page, entry[0], at)
		_value(page, at, func() -> String: return "%d %%" % roundi(read.call() * 100))
		var slider: = _slider(page, at + Vector2(0, 26), 0.0, 1.0, 0.01, read.call())
		slider.value_changed.connect( func(value: float) -> void :
			write.call(value)
			_show_values()
		)
		if not right:
			y += 80
	var credits: = Ui.label("", 13, Color(1, 1, 1, 0.45))
	credits.position = Vector2(0, page.size.y - 24)
	page.add_child(credits)
	_said.append([credits, "credits", false])
	_mouse_rows.append([_row_words(page, Vector2(0, y + 10)), "music"])
	var cap: = Ui.action_key("music")
	cap.position = Vector2(COLUMN - cap.size.x, y + 10)
	page.add_child(cap)

	_mouse_rows.append([_row_words(page, Vector2(COLUMN + GAP, 170)), "talk"])
	var talk_cap: = Ui.action_key("talk")
	talk_cap.position = Vector2(COLUMN * 2 + GAP - talk_cap.size.x, 170)
	page.add_child(talk_cap)

	_heading(page, "micDevice", Vector2(COLUMN + GAP, 222))
	_mic_device = _button(page, "", Vector2(COLUMN + GAP, 246), Vector2(COLUMN, 42))
	_mic_device.pressed.connect(Settings.next_mic_device)
	var track: = ColorRect.new()
	track.color = Ui.INSET
	track.position = Vector2(COLUMN + GAP, 300)
	track.size = Vector2(COLUMN, 10)
	page.add_child(track)
	_mic_meter = ColorRect.new()
	_mic_meter.color = Ui.YELLOW
	_mic_meter.size = Vector2(0, 10)
	track.add_child(_mic_meter)
	_mic_hint = Ui.label("", 13, Ui.DIM)
	_mic_hint.position = Vector2(COLUMN + GAP, 316)
	_mic_hint.size = Vector2(COLUMN, 40)
	_mic_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(_mic_hint)



func _process(_delta: float) -> void :
	var radio: = TeamRadio.current
	var testing: bool = radio != null and _mic_device != null and is_visible_in_tree() and _pages["sound"].visible
	if radio != null and radio.monitoring != testing:
		radio.monitoring = testing
	if not testing:
		return
	_mic_device.text = Settings.mic_device if Settings.mic_device != "" else word("micDefault")
	_mic_meter.size.x = COLUMN * clampf(radio.level, 0.0, 1.0)
	_mic_meter.color = Ui.YELLOW if radio.level > 0.05 else Ui.DIM
	_mic_hint.text = word("micSilent" if radio.mic_dead else "micTest")


func _access_page(page: Control) -> void :
	_choice_row(page, "subtitles", Vector2(0, 0), ["off", "on"], func() -> int: return int(Settings.subtitles), func(pick: int) -> void : Settings.set_subtitles(pick == 1))
	_choice_row(page, "colourBlind", Vector2(0, 90), ["off", "on"], func() -> int: return int(Settings.colour_blind), func(pick: int) -> void : Settings.set_colour_blind(pick == 1))

	for index in 3:
		var swatch: = ColorRect.new()
		swatch.position = Vector2(index * (COLUMN / 3.0 + 4.0), 164)
		swatch.size = Vector2(COLUMN / 3.0 - 8.0, 6)
		page.add_child(swatch)
		_swatches.append(swatch)
	_choice_row(page, "reduceMotion", Vector2(0, 196), ["off", "on"], func() -> int: return int(Settings.reduce_motion), func(pick: int) -> void : Settings.set_reduce_motion(pick == 1))

	_choice_row(page, "hud.cameraMotion.title", Vector2(0, 286), ["hud.cameraMotion.off", "hud.cameraMotion.reduced", "hud.cameraMotion.full"], func() -> int: return Settings.camera_motion, func(pick: int) -> void : Settings.set_camera_motion(pick))
	_heading(page, "shake", Vector2(0, 376))
	_value(page, Vector2(0, 376), func() -> String: return "%d %%" % roundi(Settings.shake * 100))
	var shake: = _slider(page, Vector2(0, 402), 0.0, 1.0, 0.05, Settings.shake)
	shake.value_changed.connect( func(value: float) -> void :
		Settings.set_shake(value)
		_show_values()
	)
	var right: = COLUMN + GAP
	_choice_row(page, "holds", Vector2(right, 0), ["hold", "tap"], func() -> int: return int(Settings.tap_holds), func(pick: int) -> void : Settings.set_tap_holds(pick == 1))
	_choice_row(page, "spray", Vector2(right, 90), ["hold", "toggle"], func() -> int: return int(Settings.spray_toggle), func(pick: int) -> void : Settings.set_spray_toggle(pick == 1))

	_choice_row(page, "hud.smoke.title", Vector2(right, 180), ["less", "normal", "more"], func() -> int: return Settings.smoke, Settings.set_smoke)

	_choice_row(page, "usageStats", Vector2(right, 270), ["off", "on"], func() -> int: return int(Settings.usage_stats), func(pick: int) -> void : Settings.set_usage_stats(pick == 1))




func _heading(parent: Control, words: String, at: Vector2) -> Label:
	var label: = Ui.caps("", 14)
	label.position = at
	parent.add_child(label)
	_said.append([label, words, true])
	return label



func _value(parent: Control, at: Vector2, say: Callable) -> Label:
	var label: = Ui.label("", 14, Ui.YELLOW)
	label.position = Vector2(at.x + COLUMN - 120, at.y)
	label.size = Vector2(120, 20)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	parent.add_child(label)
	_values.append([label, say])
	return label


func _box(color: Color, indent: = 0.0) -> StyleBoxFlat:
	var box: = StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(6)
	box.content_margin_left = indent
	return box


func _button(parent: Control, words: String, at: Vector2, button_size: Vector2, strong: = false) -> Button:
	var button: = Button.new()
	button.position = at
	button.size = button_size
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.add_theme_font_override("font", Ui.display_font())
	button.add_theme_font_size_override("font_size", 20)
	button.clip_text = true
	_paint(button, strong)
	parent.add_child(button)
	if words != "":
		_said.append([button, words, true])
	button.pressed.connect( func() -> void : Sounds.ui("ui_click"))
	button.mouse_entered.connect( func() -> void :
		if not button.disabled:
			Sounds.ui("ui_hover"))
	return button



func _choice_row(parent: Control, heading: String, at: Vector2, words: Array, current_pick: Callable, pick: Callable) -> void :
	_heading(parent, heading, at)
	var gap: = 10.0
	var width: = (COLUMN - gap * (words.size() - 1)) / words.size()
	var buttons: Array[Button] = []
	for index in words.size():
		var button: = _button(parent, "", Vector2(at.x + index * (width + gap), at.y + 24), Vector2(width, 42))
		button.pressed.connect( func() -> void :
			pick.call(index)
			_say_all()
		)
		buttons.append(button)
	_choices.append([buttons, words, current_pick])



func _paint(button: Button, strong: bool) -> void :
	var indent: float = button.get_meta("indent", 0.0)
	button.add_theme_stylebox_override("normal", _box(Ui.YELLOW if strong else Ui.INSET, indent))
	button.add_theme_stylebox_override("hover", _box(Ui.YELLOW.lightened(0.25) if strong else Ui.INSET.lightened(0.18), indent))
	button.add_theme_stylebox_override("pressed", _box(Ui.YELLOW.darkened(0.15), indent))
	button.add_theme_stylebox_override("disabled", _box(Ui.INSET, indent))
	for state: String in ["font_color", "font_hover_color", "font_focus_color"]:
		button.add_theme_color_override(state, Ui.DARK if strong else Ui.TEXT)
	button.add_theme_color_override("font_pressed_color", Ui.DARK)
	button.add_theme_color_override("font_hover_pressed_color", Ui.DARK)


func _slider(parent: Control, at: Vector2, low: float, high: float, step_by: float, value: float) -> HSlider:
	var slider: = HSlider.new()
	slider.position = at
	slider.size = Vector2(COLUMN, 24)
	slider.min_value = low
	slider.max_value = high
	slider.step = step_by
	slider.value = value
	slider.focus_mode = Control.FOCUS_NONE
	var track: = _box(Ui.INSET)
	track.content_margin_top = 4
	track.content_margin_bottom = 4
	var filled: = _box(Ui.YELLOW)
	filled.content_margin_top = 4
	filled.content_margin_bottom = 4
	slider.add_theme_stylebox_override("slider", track)
	slider.add_theme_stylebox_override("grabber_area", filled)
	slider.add_theme_stylebox_override("grabber_area_highlight", filled)
	parent.add_child(slider)
	return slider


func _row_words(parent: Control, at: Vector2) -> Label:
	var label: = Ui.label("", 16)
	label.position = at
	label.size = Vector2(COLUMN - 120, 30)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.clip_text = true
	parent.add_child(label)
	return label



func _key_row(parent: Control, action: String, at: Vector2) -> void :
	var label: = _row_words(parent, at)
	var key: = Button.new()
	key.position = Vector2(at.x + COLUMN - 110, at.y)
	key.size = Vector2(110, 30)
	key.focus_mode = Control.FOCUS_NONE
	key.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	key.add_theme_font_override("font", Ui.label_font())
	key.add_theme_font_size_override("font_size", 16)
	key.clip_text = true
	key.disabled = action in Controls.FIXED
	key.pressed.connect( func() -> void :
		Sounds.ui("ui_click")
		_begin_rebind(action)
	)
	parent.add_child(key)
	_key_rows[action] = [label, key]



func _records_strip(parent: Control, at: Vector2, width: float) -> void :
	_heading(parent, "records", at)
	var cell: = width / 3.0
	for index in RECORD_KINDS.size():
		var x: = at.x + (index % 3) * cell
		var y: = at.y + 26 + (index / 3) * 34
		var grade: = Ui.display("", 24)
		grade.position = Vector2(x, y - 4)
		grade.size = Vector2(30, 30)
		parent.add_child(grade)
		var label: = Ui.caps("", 12)
		label.position = Vector2(x + 30, y + 6)
		label.size = Vector2(cell - 34, 18)
		label.clip_text = true
		parent.add_child(label)
		_records.append([RECORD_KINDS[index], grade, label])




func _begin_rebind(action: String) -> void :
	if action in Controls.FIXED:
		return
	_cancel_rebind()
	_waiting = action
	var key: Button = _key_rows[action][1]
	key.text = "…"
	_paint(key, true)
	_status(Text.f("ui.pause.waiting", [action_word(action)]), Ui.YELLOW)


func _cancel_rebind() -> void :
	if _waiting.is_empty():
		return
	_waiting = ""
	_show_keys()
	_status(Text.m("ui.pause.keysHint"), Ui.DIM)



func _input(event: InputEvent) -> void :
	if _waiting.is_empty() or not open:
		return
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	get_viewport().set_input_as_handled()
	var key: int = event.physical_keycode if event.physical_keycode != KEY_NONE else event.keycode
	var action: = _waiting
	_waiting = ""
	if key == KEY_ESCAPE:
		_show_keys()
		_status(Text.m("ui.pause.keysHint"), Ui.DIM)
		return
	Settings.rebind(action, key)
	var clashes: = Controls.clashes(action, key)
	if clashes.is_empty():
		_status(Text.f("ui.pause.moved", [action_word(action), Controls.label(key)]), Ui.DIM)
	else:
		var others: Array[String] = []
		for other: String in clashes:
			others.append(action_word(other))
		_status(Text.f("ui.pause.clash", [Controls.label(key), ", ".join(others)]), Ui.state(Ui.RED))
	Sounds.ui("ui_click")


func _status(words: Variant, color: Color) -> void :
	_key_status.set_meta("words", words)
	_key_status.text = Text.say(words)
	_key_status.add_theme_color_override("font_color", color)


static func _caps(words: String) -> String:
	return Text.say(Text.upper(words))



func _show_keys() -> void :
	for row: Array in _mouse_rows:
		(row[0] as Label).text = action_word(row[1])
	for action: String in _key_rows:
		var row: Array = _key_rows[action]
		(row[0] as Label).text = action_word(action)
		var key: Button = row[1]
		if action == _waiting:
			continue
		key.text = Controls.bound_name(action)
		var clash: = false
		for physical: int in Controls.bindings[action]:
			clash = clash or not Controls.clashes(action, physical).is_empty()
		_paint(key, false)
		if clash:
			key.add_theme_stylebox_override("normal", _box(Ui.state(Ui.RED).darkened(0.35)))
		key.set_meta("clash", clash)




func _show_records() -> void :
	var player: = Game.local_player
	for entry: Array in _records:
		var best: String = String(player.get_attr("Best_" + entry[0], "")) if player else ""
		var grade: Label = entry[1]
		grade.text = best if not best.is_empty() else "–"
		var color: Color = HudDebrief.GRADE_COLORS.get(best, Color(1, 1, 1, 0.3))
		grade.add_theme_color_override("font_color", Ui.state(color))
		var name_label: Label = entry[2]
		name_label.text = Text.say(Text.m("hud.dispatch.kinds.%s.tag" % entry[0])).to_upper()

		var font: = name_label.get_theme_font("font")
		var size: = 12
		while size > 9 and font.get_string_size(name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x > name_label.size.x:
			size -= 1
		name_label.add_theme_font_size_override("font_size", size)


func _say_all() -> void :
	_show_records()
	_show_last_calls()
	for entry: Array in _said:
		entry[0].text = _caps(word(entry[1])) if entry[2] else word(entry[1])
	if _resume != null and _over_title != null:
		_resume.text = _caps(TitleScreen.word("back"))
		_title_label.text = TitleScreen.word("setup")
	for code: String in _language_buttons:
		_language_buttons[code].text = Text.say(Text.m("ui.languageNames." + code))
		_paint(_language_buttons[code], code == Text.language)
	for row: Array in _choices:
		var lit: int = (row[2] as Callable).call()
		for index in row[0].size():
			var button: Button = row[0][index]
			var words: String = row[1][index]
			button.text = _caps(word(words)) if not words.is_valid_int() else words
			_paint(button, index == lit)
	_first_shift.text = Text.say(Text.m("onboarding.firstShift.replay")).to_upper()
	_first_shift.disabled = Net.active() or FirstShift.current == null or FirstShift.current.active
	_first_shift.modulate.a = 0.35 if _first_shift.disabled else 1.0
	_tutorial.text = Text.say(Text.m("onboarding.tutorial.replay")).to_upper()
	_tutorial.disabled = Net.active() or Tutorial.current == null or Tutorial.current.active or not Game.incident.is_empty()
	_tutorial.modulate.a = 0.35 if _tutorial.disabled else 1.0
	var hired: = CrewService.current.roster.members.size() if CrewService.current else 5
	var shown: = mini(Settings.crew_size(), hired)
	for count in _crew_buttons.size():
		_paint(_crew_buttons[count], count == shown)

		_crew_buttons[count].disabled = Net.active() or count > hired
		_crew_buttons[count].modulate.a = 0.35 if count > hired else 1.0
	for index in _swatches.size():
		_swatches[index].color = Ui.state([Ui.GREEN, Ui.AMBER, Ui.RED][index])
	_show_keys()
	if _key_status.has_meta("words"):
		_key_status.text = Text.say(_key_status.get_meta("words"))
	else:
		_status(Text.m("ui.pause.keysHint"), Ui.DIM)
	_show_values()
	_show_code()



func _show_last_calls() -> void :
	var reports: = CallLog.recent()
	for index in _last_calls.size():
		var button: Button = _last_calls[index]
		button.visible = index < reports.size()
		if button.visible:
			var report: Dictionary = reports[index]
			button.text = "%s · %s" % [report.get("grade", "-"), Text.say(Text.m("hud.dispatch.kinds.%s.tag" % report.get("kind", "fire"))).to_upper()]




func _show_code() -> void :
	var listed: = Net.mode == Net.HOST and Net.crew_list.is_listed()
	_code.text = (Net.crew_name + ("  🔒" if Net.is_locked() else "")) if listed else ""
	_code.visible = listed
	_code_caption.visible = _code.visible
	_crew_net.text = Text.say(Text.m("talk.leave.host" if Net.mode == Net.HOST else ("talk.leave.client" if Net.is_client() else "talk.open.button")))


func _show_values() -> void :
	for entry: Array in _values:
		(entry[0] as Label).text = (entry[1] as Callable).call()


func show_menu() -> void :
	if open:
		return
	open = true
	visible = true
	Game.ui_open = true
	Game.set_paused(true)
	_say_all()
	var player: = Game.local_player
	if player and player.camera:
		player.camera.capture(false)





func show_over_title(title: TitleScreen) -> void :
	if open:
		return
	_over_title = title
	if _title_layer == null:
		_title_layer = CanvasLayer.new()
		_title_layer.layer = 60
		title.add_child(_title_layer)
	_home = get_parent()
	reparent(_title_layer)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tab_buttons["game"].visible = false
	_main_menu.visible = false
	show_tab("display")
	open = true
	visible = true
	_say_all()


func close() -> void :
	if not open:
		return
	_cancel_rebind()
	open = false
	visible = false
	if _over_title != null:

		_tab_buttons["game"].visible = true
		_main_menu.visible = true
		if is_instance_valid(_home):
			reparent(_home)
		_over_title = null
		Settings.save()
		return
	Game.ui_open = false
	Game.set_paused(false)
	var player: = Game.local_player
	if player and player.camera:
		player.camera.capture(true)


func _unhandled_input(event: InputEvent) -> void :
	if not event.is_action_pressed("pause"):
		return
	if open:
		close()
	elif HudMap.current and HudMap.current.visible:
		HudMap.current.visible = false
	elif HudDebrief.current and HudDebrief.current.is_open() and not Game.ui_open:
		HudDebrief.current.close()
	elif not Game.ui_open:
		show_menu()
	else:
		return
	get_viewport().set_input_as_handled()
