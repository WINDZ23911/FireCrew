extends RefCounted




const KEEP_OFF: = ["road", "pavement", "driveway", "path", "paving", "parking", "lane", "forecourt", "crossover", "kerb", "court", "playground"]
const WOOD_SHARE: = 0.5
const BIKE_SHARE: = 0.18
const CATS_ON_WALLS: = 7
const CATS_ON_STEPS: = 9


static func apply(kit: PolishKit) -> String:
	var folder: = kit.own_folder("Yards")
	var made: = kit.store.count
	var piles: = 0
	var bikes: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		if not shell["homely"]:
			continue
		var rng: = kit.rng("yard:%d" % shell["model"])
		if rng.randf() < WOOD_SHARE and _woodpile(kit, folder, shell, rng):
			piles += 1
		if rng.randf() < BIKE_SHARE and _bike(kit, folder, shell, rng):
			bikes += 1
	var cats: = _cats(kit, folder)
	return "yards: %d woodpiles, %d bicycles, %d cats (%d parts)" % [piles, bikes, cats, kit.store.count - made]



static func _garden(kit: PolishKit, at: Vector3, radius: float, ignoring: Array = []) -> bool:
	return not KEEP_OFF.has(kit.surface_at(at)) and StreetKit.clear_below(kit, at, radius, 6.0, 0.3, ignoring)


static func _near_door(kit: PolishKit, shell: Dictionary, at: Vector3, within: float) -> bool:
	for door: int in shell["rows"].get("Door", []):
		var spot: = kit.store.position(door)
		if Vector2(spot.x - at.x, spot.z - at.z).length() < within:
			return true
	return false



static func _woodpile(kit: PolishKit, folder: int, shell: Dictionary, rng: RandomNumberGenerator) -> bool:
	var place: Transform3D = shell["place"]
	var width: float = shell["width"]
	var depth: float = shell["depth"]
	var walls: Array = [
		[place.basis.x.normalized(), width / 2.0, place.basis.z.normalized(), depth], 
		[ - place.basis.x.normalized(), width / 2.0, place.basis.z.normalized(), depth], 
		[place.basis.z.normalized(), depth / 2.0, place.basis.x.normalized(), width], 
	]
	var first: = rng.randi_range(0, walls.size() - 1)
	var length: = rng.randf_range(6.0, 9.5)
	var height: = rng.randf_range(2.4, 2.8)
	for turn in walls.size():
		var wall: Array = walls[(first + turn) % walls.size()]
		var out: Vector3 = wall[0]
		var along: Vector3 = wall[2]
		var room: float = float(wall[3]) / 2.0 - length / 2.0 - 2.5
		if room < 0.0:
			continue
		for offset: float in [rng.randf_range( - room, room), room * 0.8, - room * 0.8]:
			var middle: = place.origin + out * (float(wall[1]) + 1.05) + along * offset
			middle.y = 0.0
			if _near_door(kit, shell, middle, length / 2.0 + 4.0):
				continue

			var fits: = _garden(kit, middle + out * 2.0, 1.0)
			for spot: Vector3 in [middle, middle - along * (length / 2.0 - 0.7), middle + along * (length / 2.0 - 0.7)]:

				if not fits or not _garden(kit, spot, 0.85, ["Plinth", "Sill"]):
					fits = false
					break
			if not fits:
				continue
			StreetKit.woodpile(kit, folder, PolishKit.facing(middle, out), length, height)
			return true
	return false



static func _bike(kit: PolishKit, folder: int, shell: Dictionary, rng: RandomNumberGenerator) -> bool:
	var doors: Array = shell["rows"].get("Door", [])
	if doors.is_empty():
		return false
	var place: Transform3D = shell["place"]
	var out: = - place.basis.z.normalized()
	var side: = place.basis.x.normalized()
	var door: = kit.store.position(doors[0])
	var front: = place.origin + out * (float(shell["depth"]) / 2.0 + 1.1)

	var at_door: = front + side * side.dot(door - front)
	for along: float in [6.0, -6.0, 8.5, -8.5]:
		var at: = at_door + side * along
		at.y = 0.0
		if not (_garden(kit, at, 0.6) and _garden(kit, at + side * 2.0, 0.6) and _garden(kit, at - side * 2.0, 0.6)):
			continue
		var bike: = PolishKit.facing(at, side if rng.randf() < 0.5 else - side)
		var lean: = -0.16 if bike.basis.x.dot( - out) > 0.0 else 0.16
		StreetKit.bicycle(kit, folder, bike, StreetKit.BIKE_PAINTS[rng.randi_range(0, StreetKit.BIKE_PAINTS.size() - 1)], lean)
		return true
	return false



static func _cats(kit: PolishKit, folder: int) -> int:
	var store: = kit.store
	var rng: = kit.rng("cats")
	var made: = 0
	var copings: = Array(store.rows_named("WallCoping"))
	var steps: Array = []
	for row: int in store.rows_named("Step"):
		if row < store.exported and store.size(row).x <= 8.0:
			steps.append(row)
	for pick: Array in [[copings, CATS_ON_WALLS], [steps, CATS_ON_STEPS]]:
		var rows: Array = pick[0]
		var placed: = 0
		var tries: = 0
		while placed < int(pick[1]) and tries < 60 and not rows.is_empty():
			tries += 1
			var row: int = rows[rng.randi_range(0, rows.size() - 1)]
			rows.erase(row)
			var frame: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			var x: = rng.randf_range( - size.x / 2.0 + 0.8, size.x / 2.0 - 0.8)
			var top: = frame * Vector3(x, size.y / 2.0, 0)
			if not kit.clear(top + Vector3(0, 0.1, 0), 0.5, top.y + 0.05):
				continue

			var toward: = frame.basis.z * (1.0 if rng.randf() < 0.5 else -1.0)
			var body: = store.find_row(store.parent(row), "Body") if store.name_at(row) == "Step" else -1
			if body >= 0 and toward.dot(top - store.position(body)) < 0.0:
				toward = - toward
			var place: = Transform3D(Basis.looking_at(Vector3(toward.x, 0, toward.z).normalized(), Vector3.UP).rotated(Vector3.UP, rng.randf_range(-0.6, 0.6)), top)
			StreetKit.cat(kit, folder, place, StreetKit.CAT_COATS[rng.randi_range(0, StreetKit.CAT_COATS.size() - 1)])
			placed += 1
			made += 1
	return made
