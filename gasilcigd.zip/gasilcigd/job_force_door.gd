class_name JobForceDoor
extends CrewJob



const TOOLS: Array[String] = ["Halligan bar", "Axe", "Crowbar"]

var house: House
var door: Dictionary


func _init(building: House, which: Dictionary) -> void :
	kind = "forceDoor"
	role = "rescue"
	house = building
	door = which


func place() -> Vector3:
	return door["prompt"].global_position


func run() -> bool:
	if not door["locked"]:
		if door["open"] or door["burnt"]:
			return true

		if not await who.press(door["prompt"]):
			return fail("crew.say.cannot")
		return true
	if await CrewKit.take_tool(who, TOOLS, who.service.home_vehicle(who.commander())) == "":
		return fail("crew.say.noTool", [Text.named("tools", "Halligan bar")])
	var prompt: Prompt = door["prompt"]
	if not await CrewKit.press_skilled(who, prompt):
		return fail("crew.say.cannot") if not cancelled else false
	return not door["locked"]


func finish(_done: bool) -> void :
	CrewKit.free_hands(who)
