class_name CrewTargets
extends RefCounted







const REACH: = 160.0


static func look(lead: Player) -> Dictionary:
	if lead == null or lead.camera == null:
		return {}
	var eye: = lead.camera.camera
	var from: = eye.global_position
	var along: = - eye.global_basis.z
	var hit: = Game.world.raycast(from + along * (lead.camera.distance + 1.0), from + along * REACH, World.LAYER_SOLID | World.LAYER_QUERY | World.LAYER_VEHICLE | World.LAYER_PLAYER, [lead.get_rid()])
	var point: Vector3 = hit["position"] if not hit.is_empty() else from + along * REACH
	var view: = {"from": from, "along": along, "point": point, "hit": hit, "lead": lead}
	var best: Dictionary = {}
	var best_score: = INF
	for finder: Callable in finders():
		var found: Dictionary = finder.call(view)
		if found.is_empty():
			continue
		var score: float = found.get("score", 100.0)
		if score < best_score:
			best_score = score
			best = found
	return best



static func finders() -> Array[Callable]:
	var list: Array[Callable] = [_find_ask, _find_member, _find_vehicle, _find_ground]
	list.append_array(CrewWork.finders())
	return list



static func off_sight(view: Dictionary, at: Vector3) -> float:
	var offset: Vector3 = at - view["from"]
	var along: float = offset.dot(view["along"])
	if along < 0.0:
		return INF
	return (offset - view["along"] * along).length()


static func order(text: Variant, icon: String, make: Callable) -> Dictionary:
	return {"text": text, "icon": icon, "make": make}


static func everyone(text: Variant, icon: String, act: Callable) -> Dictionary:
	return {"text": text, "icon": icon, "all": true, "act": act}



static func general(lead: Player) -> Array:
	var options: Array = [
		everyone(Text.m("crew.orders.follow"), "arrow", func(service: CrewService) -> void : service.all_follow()), 
		everyone(Text.m("crew.orders.hold"), "pin", func(service: CrewService) -> void : service.all_hold()), 
		everyone(Text.m("crew.orders.work"), "check", func(service: CrewService) -> void : service.all_work()), 
	]
	var truck: Variant = CrewService.current.home_vehicle(lead)
	if truck is Vehicle:
		options.append(everyone(Text.m("crew.orders.standby"), "truck", _all_standby.bind(truck)))
	if CrewPack.anything(CrewService.current):
		options.append(pack_up())

	var next: = (CrewService.current.autonomy + 1) % CrewService.LEVELS.size()
	options.append(everyone(Text.f("crew.orders.autonomy", [CrewService.level_name(next)]), "check", func(service: CrewService) -> void : service.set_autonomy(next)))
	return options




static func _find_ask(view: Dictionary) -> Dictionary:
	var service: = CrewService.current
	if service == null or service.ask.is_empty() or not is_instance_valid(service.ask["mind"]):
		return {}
	var mind: Crewman = service.ask["mind"]
	var kind: String = service.ask["kind"]
	var key: = "crew.orders.confirm." + kind
	return {
		"kind": "ask", "position": view["from"] + view["along"] * 12.0, "score": -1000.0, "member": mind, 
		"label": Text.m("crew.targets.ask"), 
		"options": [{"text": Text.m(key if Text.has(key) else "crew.orders.confirm.any"), "icon": "check", "act": func(on: CrewService) -> void : on.confirm_ask()}], 
	}



static func pack_up() -> Dictionary:
	return everyone(Text.m("crew.orders.packUp"), "cone", func(service: CrewService) -> void : service.all_pack_up())






static func _find_member(view: Dictionary) -> Dictionary:
	var best: Crewman = null
	var best_off: = 2.5
	for mind in CrewService.current.members:
		if not is_instance_valid(mind) or mind.body.seat != null:
			continue
		var off: = off_sight(view, mind.body.global_position + Vector3(0, 3, 0))
		var far: float = (mind.body.global_position - view["from"]).length()
		if off < best_off and far < 60.0:
			best_off = off
			best = mind
	if best == null:
		return {}
	var chosen: = best
	return {
		"kind": "member", "position": chosen.body.global_position + Vector3(0, 6.5, 0), "member": chosen, "score": best_off - 3.0, 
		"label": Text.join([chosen.display_name(), " · ", CrewRoster.position_name(chosen.role)]), 
		"options": [

			{"text": Text.m("crew.orders.backMeUp"), "icon": "shield", "make": func() -> CrewJob: return JobBackup.new(Game.local_player)}, 
			{"text": Text.m("crew.orders.followMe"), "icon": "arrow", "act": _member_follow.bind(chosen)}, 
			{"text": Text.m("crew.orders.holdHere"), "icon": "pin", "act": _member_hold.bind(chosen)}, 
			{"text": Text.m("crew.orders.drop"), "icon": "warning", "act": _member_drop.bind(chosen)}, 
			{"text": Text.f("crew.orders.memberAutonomy", [CrewService.level_name((CrewService.current.level_of(chosen) + 1) % CrewService.LEVELS.size())]), "icon": "check", 
				"act": func(service: CrewService) -> void : service.cycle_autonomy(chosen)}, 
		], 
	}


static func _member_follow(_service: CrewService, mind: Crewman) -> void :
	mind.mode = "follow"
	mind.stand_down()
	mind.say("crew.say.follow", [], "info", true)


static func _member_hold(_service: CrewService, mind: Crewman) -> void :
	mind.stand_down()
	mind.mode = "hold"
	mind.hold_at = mind.body.global_position
	mind.say("crew.say.hold", [], "info", true)


static func _member_drop(_service: CrewService, mind: Crewman) -> void :
	mind.stand_down()
	mind.say("crew.say.dropped", [], "info", true)



static func _find_vehicle(view: Dictionary) -> Dictionary:
	var hit: Dictionary = view["hit"]
	var vehicle: Vehicle = null
	if not hit.is_empty() and hit.get("collider") is Vehicle:
		vehicle = hit["collider"]
	if vehicle == null or vehicle.seats.is_empty():
		return {}
	var lead: Player = view["lead"]
	var target: = vehicle
	var options: Array = []


	options.append_array(CrewWork.vehicle_orders(target, lead))
	options.append(order(Text.m("crew.orders.mount"), "truck", func() -> CrewJob: return JobBoard.new(target)))
	options.append(everyone(Text.m("crew.orders.mountAll"), "truck", _all_mount.bind(target)))
	options.append(everyone(Text.m("crew.orders.standbyThis"), "pin", _all_standby.bind(target)))

	if vehicle == CrewService.current.home_vehicle(lead) and CrewPack.anything(CrewService.current):
		if Game.incident.is_empty():
			options.push_front(pack_up())
		else:
			options.append(pack_up())
	return {
		"kind": "vehicle", "position": vehicle.global_position + Vector3(0, float(vehicle.data.get("top", 9.0)) + 2.0, 0), 
		"vehicle": vehicle, "score": 6.0, "label": Text.named("vehicles", vehicle.spec["name"]), "options": options, 
	}



static func _find_ground(view: Dictionary) -> Dictionary:
	var hit: Dictionary = view["hit"]
	if hit.is_empty() or hit.get("normal", Vector3.ZERO).y < 0.6:
		return {}
	var at: Vector3 = hit["position"]
	if (at - view["from"]).length() > 120.0:
		return {}
	return {
		"kind": "ground", "position": at, "score": 50.0, "label": Text.m("crew.targets.here"), "quiet": true, 
		"options": [
			order(Text.m("crew.orders.goThere"), "pin", func() -> CrewJob: return JobGoto.new(at)), 
			everyone(Text.m("crew.orders.allThere"), "pin", _all_goto.bind(at)), 
		] + CrewWork.ground_orders(at), 
	}


static func _all_standby(service: CrewService, vehicle: Vehicle) -> void :
	for mind in service.members:
		mind.give(JobStandby.new(vehicle))
	service.lead_say("crew.say.standby")


static func _all_mount(service: CrewService, vehicle: Vehicle) -> void :
	var seats: = 0
	for index in range(1, vehicle.riders.size()):
		if vehicle.riders[index] == null:
			seats += 1
	for mind in service.members:
		if seats > 0 and mind.body.get_attr("Vehicle") != vehicle:
			mind.give(JobBoard.new(vehicle))
			seats -= 1
	service.lead_say("crew.say.yes.mount")


static func _all_goto(service: CrewService, at: Vector3) -> void :
	for mind in service.members:
		mind.give(JobGoto.new(at + Vector3(mind.slot * 3.0 - 6.0, 0, (mind.slot % 2) * 3.0)))
	service.lead_say("crew.say.yes.goto")
