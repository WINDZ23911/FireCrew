extends ProofDebug









func _scenario_controls() -> void :
	await _wait(1.0)
	Text.choose("en")
	var was_controls: = Settings.controls
	Settings.controls = Settings.SIMPLE
	var truck: = Vehicle.named("Fire Truck")
	_park(truck, Vector3(-104, 0, 14), - PI / 2.0)
	await _wait(0.5)
	var door: Dictionary = truck.doors["DoorCabLeft"]
	truck.set_door("DoorCabLeft", false)
	await _to_door(truck)


	var said: Array[String] = []
	for each in player.choices:
		said.append(Text.say(each.action, "en"))
	print("controls: at the cab door E offers %s (chosen %d)" % [said, player.choice])
	_check(player.prompt == door["seat_prompt"], "at the shut cab door E offers to drive")
	_check(door["prompt"] in player.choices, "Open door is among the door's actions")
	var plates: = 0
	for key: String in HudPrompts.current._rows:
		plates += int(HudPrompts.current._rows[key]["plate"].visible)
	_check(plates == 1 and HudPrompts.current._more.visible, "one plate is shown, with the other actions under it (%d plates)" % plates)
	_check(Controls.key_name("item") == Controls.key_name("interact") and Controls.key_name("coupling") == Controls.key_name("interact"), "hints name E for getting in and for hoses ('%s')" % Controls.key_name("item"))
	await _snap("door_choices")


	var wheel: = InputEventMouseButton.new()
	wheel.button_index = MOUSE_BUTTON_WHEEL_DOWN
	wheel.pressed = true
	Input.parse_input_event(wheel)
	await get_tree().process_frame
	await get_tree().process_frame
	print("controls: after the wheel E offers '%s'" % Text.say(player.prompt.action, "en") if player.prompt else "nothing")
	_check(player.prompt == door["prompt"], "the mouse wheel steps E to Open door")
	await _snap("door_stepped")
	await _tap("interact")
	await _wait(0.8)
	_check(door["open"] and player.seat == null, "E opens the door and does not get in")


	truck.set_door("DoorCabLeft", false)
	await _wait(0.8)
	await _to_door(truck)
	if player.prompt != door["seat_prompt"]:
		player.step_choice(1)
	await _tap("interact")
	await _wait(1.2)
	_check(player.seat != null and truck.driver() == player, "E on Drive sits the player at the wheel")


	var cab: = HudCabWheel.current
	await _tap("interact")
	await _wait(0.4)
	_check(cab != null and cab.is_open(), "a tap of E in the cab opens the cab wheel and leaves it up")
	var ids: Array = []
	for option: Dictionary in cab._options:
		ids.append(option["id"])
	print("controls: the cab wheel offers %s" % [ids])
	_check(ids.has("blue") and ids.has("siren_next") and ids.has("headlights") and ids.has("exit"), "it has the blue lights, the siren, the headlights and getting out")
	_check(ids.has("mast") == truck.data.has("mast"), "the light mast is there just where the truck has one")
	_check( not HudTruck.driven() or (Hud.current.widgets["truck"] as HudTruck)._wheel_hint.visible, "the driver's panel says E opens the cab controls")
	await _snap("cab_wheel")
	var blue_before: = truck.blue_on
	cab.choose("blue")
	await _wait(0.6)
	_check(truck.blue_on != blue_before and not cab.is_open(), "Blue lights on the wheel turns them on and the wheel goes away")
	await _snap("cab_blue")

	await get_tree().process_frame
	Input.action_press("interact")
	await _wait(0.5)
	_check(cab.is_open() and not cab._sticky, "E held keeps the wheel up while held")
	cab._chosen = ids.find("exit")
	Input.action_release("interact")
	await _wait(1.2)
	_check(player.seat == null, "let go over Get out, the player gets out")


	truck.set_door("DoorCabLeft", false)
	await _wait(0.8)
	await _to_door(truck)
	await _tap("item")
	await _wait(1.2)
	_check(player.seat != null, "F still gets in")
	truck.leave(player)
	await _wait(1.0)


	Settings.controls = Settings.CLASSIC
	truck.set_door("DoorCabLeft", false)
	await _wait(0.8)
	await _to_door(truck)
	plates = 0
	for key: String in HudPrompts.current._rows:
		plates += int(HudPrompts.current._rows[key]["plate"].visible)
	_check(player.prompts.get("item") == door["seat_prompt"] and player.prompts.get("interact") == door["prompt"] and plates == 2, "Classic controls: F to drive and E to open the door, on two plates")
	_check(Controls.key_name("item") != Controls.key_name("interact"), "and the hints name F again")
	await _snap("classic")
	Settings.controls = Settings.SIMPLE
	await _wait(0.2)



	Text.choose("sl")
	Settings.set_click_use(true)
	await _wait(0.3)
	var row: Dictionary = HudPrompts.current._rows["interact"]
	var cap: Control = row["cap"]
	var cap_end: = cap.position.x + cap.size.x
	var cap_words: float = (cap.get_child(0) as Label).get_minimum_size().x
	print("controls: left-button cap '%s' %.0f wide (its word %.0f), the plate's words from %.0f" % [(cap.get_child(0) as Label).text, cap.size.x, cap_words, row["action"].position.x])
	_check(cap.size.x >= cap_words and row["action"].position.x > cap_end and row["object"].position.x > cap_end, "the left button's key cap fits its word and the plate's words stand right of it")
	_check(row["plate"].size.x >= row["action"].position.x + row["action"].get_minimum_size().x, "the plate is wide enough for its words after the cap")
	await _snap("click_use_plate")
	Text.choose("en")
	await _wait(0.2)
	var has_button: = false
	for event in InputMap.action_get_events("fire"):
		has_button = has_button or event is InputEventMouseButton
	_check( not has_button, "with the setting on the left button is taken off the tool's action")
	_check(Controls.key_name("interact") == Text.say(Text.m("ui.keyNames.LMB")), "E's plate says the left button")
	await _wait(0.2)
	_check(Controls.click_target(player), "a click at the cab door goes to E")
	await _click()
	await _wait(1.2)
	_check(player.seat != null, "a left click at the cab door gets in")
	truck.leave(player)
	await _wait(1.0)

	var held_was: = player.holding
	player.holding = "nozzle"
	await _to_door(truck)
	var near_ok: = Controls.click_target(player)
	player.camera.pitch = 1.1
	await _wait(0.3)
	var lit: = player.prompt != null
	if lit:
		var eye: = player.camera.camera
		print("controls: looked away, E offers '%s' %.0f° off the crosshair, %.1f studs off" % [Text.say(player.prompt.action, "en"), rad_to_deg(( - eye.global_basis.z).angle_to(player.prompt.global_position - eye.global_position)), player.root_position().distance_to(player.prompt.global_position)])
	var away_ok: = Controls.click_target(player)
	print("controls: with a nozzle, a click at the door goes to %s; looked away (door still lit: %s) to %s" % ["E" if near_ok else "the nozzle", lit, "E" if away_ok else "the nozzle"])
	_check(near_ok and not away_ok, "with a tool in hand a click is E's only at a thing near and under the crosshair")
	player.holding = held_was
	Settings.set_click_use(false)


	var orders: Variant = Hud.current.widgets.get("crew_orders")
	if orders is HudCrewOrders:
		(orders as HudCrewOrders)._target = {}
		(orders as HudCrewOrders)._show_wheel(true)
		var pinged: = false
		for option: Dictionary in (orders as HudCrewOrders)._options:
			pinged = pinged or Text.say(option["text"], "en") == "Ping this"
		_check(pinged, "the crew wheel offers a ping")
		await _snap("crew_wheel")
		(orders as HudCrewOrders)._close()
	Settings.controls = was_controls
	_done()



func _to_door(vehicle: Vehicle, off: = 3.5) -> void :
	var doorway: Vector3 = vehicle.doors["DoorCabLeft"]["doorway"]
	var outside: = vehicle.global_transform * (doorway + Vector3(signf(doorway.x) * off, 0, 0))
	player.teleport(_ground(outside) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	await _aim_view(vehicle.global_transform * doorway)
	await _wait(0.3)



func _click() -> void :
	var down: = InputEventMouseButton.new()
	down.button_index = MOUSE_BUTTON_LEFT
	down.pressed = true
	Input.parse_input_event(down)
	await get_tree().process_frame
	await get_tree().process_frame
	var up: = down.duplicate() as InputEventMouseButton
	up.pressed = false
	Input.parse_input_event(up)
	await get_tree().process_frame
