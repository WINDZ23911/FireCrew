class_name Guide
extends Node3D










const ARM: = Vector3(0.7, 0.12, 3.4)
const SPLAY: = deg_to_rad(40)
const LIFT: = 0.12
const BEHIND: = 8.0
const PASSING: = 45.0

static var current: Guide

static var nearest_pump: = Callable()

var points: = PackedVector3Array()
var kind: = ""

var full: = PackedVector3Array()
var full_length: = -1.0

static var waypoint: = Vector3.INF
var _clock: = 0.0
var _chevrons: Array = []
var _count: = 0
var _material: ShaderMaterial


func _init() -> void :
	current = self


func _ready() -> void :
	_material = ShaderMaterial.new()
	_material.shader = load("res://shaders/chevron.gdshader")



static func _lanes_near(graph: NavGraph, x: float, z: float) -> Array:
	var first: = graph.nearest_lane(x, z)
	if first[0] < 0:
		return []
	var road: Variant = graph.segments[first[0]].get("road")
	var second: = graph.nearest_lane(x, z, func(segment: Dictionary) -> bool: return segment["id"] != first[0] and segment.get("road") == road)
	var lanes: = [[first[0], first[1]]]
	if second[0] >= 0:
		lanes.append([second[0], second[1]])
	return lanes




static func _way_between(graph: NavGraph, from: Vector3, to: Vector3) -> Dictionary:
	var best: = {}
	for start: Array in _lanes_near(graph, from.x, from.z):
		for finish: Array in _lanes_near(graph, to.x, to.z):
			var route: Array[int] = []
			var driven: = -1.0
			var cost: = 0.0
			if start[0] == finish[0]:

				if finish[1] >= start[1]:
					route = [start[0]]
					driven = finish[1] - start[1]
			else:
				route = graph.drive_route(start[0], finish[0], {}, _cost)
				if not route.is_empty():
					driven = graph.segments[start[0]]["length"] - start[1] + graph.route_length - graph.segments[finish[0]]["length"] + finish[1]
					cost += graph.route_cost - graph.route_length
			cost += driven
			if not route.is_empty() and driven >= 0.0 and (best.is_empty() or cost < best["cost"]):
				best = {"route": route, "from_along": start[1], "to_along": finish[1], "length": driven, "cost": cost}
	return best





static func _cost(segment: Dictionary) -> float:
	var length: float = segment["length"]
	if segment["kind"] == "lane" and String(segment.get("road_class", "")) in Config.Guide.SideRoads\
	and not String(segment.get("key", "")) in Config.Guide.SideRoadsFree:
		return length * float(Config.Guide.SideRoadCost)
	return length




static func road_length(from: Vector3, to: Vector3) -> float:
	var graph: = NavGraph.current
	if graph == null:
		return -1.0
	var way: = _way_between(graph, from, to)
	return float(way["length"]) if not way.is_empty() else -1.0




static func _points_along(graph: NavGraph, way: Dictionary, short: float, height: float, reach: = -1.0, spacing: = -1.0) -> PackedVector3Array:
	var settings: Dictionary = Config.Guide
	if spacing <= 0.0:
		spacing = settings["Spacing"]
	var made: = PackedVector3Array()
	var left: float = minf(way["length"] - short, float(settings["Reach"]) if reach < 0.0 else reach)
	var over: = 0.0
	var route: Array = way["route"]
	for index in route.size():
		var segment: Dictionary = graph.segments[route[index]]
		var along: float = way["from_along"] if index == 0 else over
		var last: float = way["to_along"] if index == route.size() - 1 else float(segment["length"])
		while along <= last and left >= 0.0:
			made.append(NavGraph.sample_position(segment, along, height))
			along += spacing
			left -= spacing
		over = along - last
		if left < 0.0:
			break
	return made


func _physics_process(delta: float) -> void :
	_clock -= delta
	if _clock > 0.0:
		return
	_clock = float(Config.Guide.Every)
	_work_out()


func _work_out() -> void :
	var graph: = NavGraph.current
	var player: = Game.local_player
	var made: = PackedVector3Array()
	var whole: = PackedVector3Array()
	var whole_length: = -1.0
	var way_kind: = "call"
	var vehicle: Variant = player.get_attr("Vehicle") if player else null
	if graph != null and vehicle is Vehicle and vehicle.driver() != null:
		var settings: Dictionary = Config.Guide
		var at: Vector3 = vehicle.global_position
		var home: Vector3 = Game.station.door_position
		var goal: Variant = Game.incident.get("approach", Game.incident.get("pos"))
		var short: float = settings["StopShort"]
		if goal == null and waypoint != Vector3.INF:

			if Vector2(at.x - waypoint.x, at.z - waypoint.z).length() <= float(settings["StopShort"]) + 10.0:
				waypoint = Vector3.INF
			else:
				goal = waypoint
				way_kind = "waypoint"
		if goal == null:
			way_kind = "home"
			short = 0.0

			var dry: bool = vehicle.fuel / vehicle.fuel_capacity < float(Config.Readiness.PumpBelow)
			var pump: Variant = nearest_pump.call(at) if (dry and nearest_pump.is_valid()) else null
			if pump != null:
				goal = pump
			elif at.distance_to(home) > float(settings["HomeBeyond"]):
				goal = home
		if goal != null and at.distance_to(goal) > float(settings["StopShort"]):
			var way: = _way_between(graph, at, goal)
			if not way.is_empty():
				made = _points_along(graph, way, short, at.y)
				whole = _points_along(graph, way, short, at.y, INF, float(settings["MapSpacing"]))
				whole_length = maxf(float(way["length"]) - short, 0.0)
	if made.size() < 2:
		made = PackedVector3Array()
	points = made
	kind = way_kind
	full = whole if made.size() >= 2 else PackedVector3Array()
	full_length = whole_length if made.size() >= 2 else -1.0
	if made.is_empty():
		HudRadar.clear_route()
	else:
		HudRadar.set_route(made, way_kind)
	HudRadar.set_full_route(full, full_length)
	_lay()


func _arm() -> MeshInstance3D:
	var arm: = MeshInstance3D.new()
	arm.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	arm.material_override = _material
	arm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(arm)
	return arm



func _lay() -> void :
	_count = 0

	var color: Color = Ui.ROUTES.get(kind, Ui.ROUTES["home"])
	var run: = 0.0
	for index in points.size() - 1:
		if run > float(Config.Guide.Shown):
			break
		var here: = points[index]
		var onward: = points[index + 1]
		run += here.distance_to(onward)

		var hit: = Game.world.raycast(here + Vector3(0, 6, 0), here + Vector3(0, -24, 0), World.LAYER_SOLID)
		var at: = Vector3(here.x, (hit["position"].y + LIFT) if not hit.is_empty() else here.y, here.z)
		var facing: = Rbx.look_at(at, Vector3(onward.x, at.y, onward.z))
		if _count >= _chevrons.size():
			_chevrons.append({"left": _arm(), "right": _arm()})
		var chevron: Dictionary = _chevrons[_count]
		_count += 1

		var reach: = sin(SPLAY) * ARM.z / 2.0
		var size: = Transform3D(Basis.from_scale(ARM), Vector3.ZERO)
		chevron["left"].global_transform = facing * Transform3D(Basis(Vector3.UP, - SPLAY), Vector3( - reach, 0, 0)) * size
		chevron["right"].global_transform = facing * Transform3D(Basis(Vector3.UP, SPLAY), Vector3(reach, 0, 0)) * size
		chevron["at"] = at
		chevron["ahead"] = - facing.basis.z
		chevron["found"] = not hit.is_empty()
		chevron["color"] = color
	for index in range(_count, _chevrons.size()):
		_chevrons[index]["left"].visible = false
		_chevrons[index]["right"].visible = false


func _process(_delta: float) -> void :
	if _count == 0:
		return
	var player: = Game.local_player
	if player == null:
		return

	var beat: = Game.now() * 1.6
	var from: = player.global_position
	for index in _count:
		var chevron: Dictionary = _chevrons[index]
		var offset: Vector3 = from - chevron["at"]
		var passed: bool = offset.dot(chevron["ahead"]) > BEHIND and offset.length() < PASSING
		var shown: bool = chevron["found"] and not passed
		chevron["left"].visible = shown
		chevron["right"].visible = shown
		if shown:
			var color: Color = chevron["color"]
			color.a = 1.0 - (0.25 + 0.45 * (0.5 + 0.5 * sin(beat * PI - index * 0.9)))
			chevron["left"].set_instance_shader_parameter("tint", color)
			chevron["right"].set_instance_shader_parameter("tint", color)
