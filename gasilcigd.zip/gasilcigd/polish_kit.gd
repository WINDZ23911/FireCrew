class_name PolishKit
extends RefCounted





const LOOK: = PartStore.SHADOW
const FIXTURE: = PartStore.SHADOW | PartStore.QUERY
const SOLID: = PartStore.SHADOW | PartStore.QUERY | PartStore.COLLIDE
const CELL: = 16.0

var store: PartStore
var _folders: Dictionary = {}
var _grid: Dictionary = {}
var _gridded: = false


func _init(parts: PartStore) -> void :
	store = parts



func folder(path: String) -> int:
	if _folders.has(path):
		return _folders[path]
	var id: = 0
	var found: = -1
	for bit in path.split("/"):
		found = -1
		for child in store.nodes_under.get(id, PackedInt32Array()):
			if store.nodes[child]["n"] == bit:
				found = child
				break
		if found < 0:
			break
		id = found
	_folders[path] = found
	return found



func own_folder(folder_name: String) -> int:
	var path: = "Map/Polish/" + folder_name
	var id: = folder(path)
	if id >= 0:
		return id
	var top: = folder("Map/Polish")
	if top < 0:
		top = store.add_node(folder("Map"), "Folder", "Polish")
		_folders["Map/Polish"] = top
	id = store.add_node(top, "Folder", folder_name)
	_folders[path] = id
	return id



func rng(seed_name: String) -> RandomNumberGenerator:
	var made: = RandomNumberGenerator.new()
	made.seed = hash("polish:" + seed_name)
	return made



func rows_under(path: String) -> PackedInt32Array:
	var id: = folder(path)
	return store.rows_in(id) if id >= 0 else PackedInt32Array()



func models_under(path: String) -> PackedInt32Array:
	var id: = folder(path)
	return store.nodes_under.get(id, PackedInt32Array()) if id >= 0 else PackedInt32Array()







func parts_at(at: Vector3, above: = 0.0) -> PackedInt32Array:
	_build_grid()
	var found: = PackedInt32Array()
	for row: int in _grid.get(Vector2i(floori(at.x / CELL), floori(at.z / CELL)), PackedInt32Array()):
		if _covers(row, at) and _top(row) > above:
			found.append(row)
	return found




func clear(at: Vector3, radius: float, above: = 0.3) -> bool:
	_build_grid()
	var low: = Vector2i(floori((at.x - radius) / CELL), floori((at.z - radius) / CELL))
	var high: = Vector2i(floori((at.x + radius) / CELL), floori((at.z + radius) / CELL))
	for cx in range(low.x, high.x + 1):
		for cz in range(low.y, high.y + 1):
			for row: int in _grid.get(Vector2i(cx, cz), PackedInt32Array()):
				if _top(row) > above and _near(row, at, radius):
					return false
	return true




func surface_at(at: Vector3) -> String:
	var best: = ""
	var best_top: = - INF
	for row in parts_at(Vector3(at.x, 0, at.z)):
		var top: = _top(row)
		if top < 0.6 and top > best_top:
			best_top = top
			best = store.name_at(row)
	return best



func surface_top(at: Vector3) -> float:
	var best_top: = - INF
	for row in parts_at(Vector3(at.x, 0, at.z)):
		var top: = _top(row)
		if top < 0.6 and top > best_top:
			best_top = top
	return best_top




func _top(row: int) -> float:
	var d: = store.data
	var i: = row * PartStore.COLUMNS
	return d[i + 3] + absf(d[i + 8]) * (d[i + 14] / 2.0) + absf(d[i + 9]) * (d[i + 15] / 2.0) + absf(d[i + 10]) * (d[i + 16] / 2.0)





const EDGE_DOUBT: = 0.02




func _covers(row: int, at: Vector3) -> bool:
	var d: = store.data
	var i: = row * PartStore.COLUMNS
	var xx: = d[i + 5]
	var xy: = d[i + 6]
	var xz: = d[i + 7]
	var yx: = d[i + 8]
	var yy: = d[i + 9]
	var yz: = d[i + 10]
	var c0: = yy * d[i + 13] - yz * d[i + 12]
	var c1: = yz * d[i + 11] - yx * d[i + 13]
	var c2: = yx * d[i + 12] - yy * d[i + 11]
	var det: = xx * c0 + xy * c1 + xz * c2
	if absf(det) < 1e-06:
		return _covers_exact(row, at)
	var dx: = at.x - d[i + 2]
	var dz: = at.z - d[i + 4]
	var lx: = absf((c0 * dx + (xy * yz - xz * yy) * dz) / det)
	var lz: = (c2 * dx + (xx * yy - xy * yx) * dz) / det
	var hx: = d[i + 14] / 2.0
	var hz: = d[i + 16] / 2.0
	var margin: float
	if int(d[i + 1]) == PartStore.Shape.CYLINDER:
		var radius: = minf(d[i + 15] / 2.0, hz)
		if absf(yx) > 0.9:
			var ly: = (c1 * dx + (xz * yx - xx * yz) * dz) / det
			margin = radius - sqrt(ly * ly + lz * lz)
		else:
			margin = minf(hx - lx, radius - absf(lz))
	else:
		margin = minf(hx + 0.01 - lx, hz + 0.01 - absf(lz))
	if absf(margin) < EDGE_DOUBT:
		return _covers_exact(row, at)
	return margin > 0.0


func _covers_exact(row: int, at: Vector3) -> bool:
	var place: = store.transform(row)
	var local: = place.affine_inverse() * Vector3(at.x, place.origin.y, at.z)
	var half: = store.size(row) / 2.0
	if store.shape(row) == PartStore.Shape.CYLINDER:
		var radius: = minf(half.y, half.z)
		if absf(place.basis.x.y) > 0.9:
			return Vector2(local.y, local.z).length() <= radius
		return absf(local.x) <= half.x and absf(local.z) <= radius
	return absf(local.x) <= half.x + 0.01 and absf(local.z) <= half.z + 0.01


func _near(row: int, at: Vector3, radius: float) -> bool:
	var d: = store.data
	var i: = row * PartStore.COLUMNS
	var margin: float
	if absf(d[i + 9]) < 0.9:
		var reach: = maxf(d[i + 14] / 2.0, maxf(d[i + 15] / 2.0, d[i + 16] / 2.0))
		margin = reach + radius - Vector2(at.x - d[i + 2], at.z - d[i + 4]).length()
	else:
		var xx: = d[i + 5]
		var xy: = d[i + 6]
		var xz: = d[i + 7]
		var yx: = d[i + 8]
		var yy: = d[i + 9]
		var yz: = d[i + 10]
		var c0: = yy * d[i + 13] - yz * d[i + 12]
		var c1: = yz * d[i + 11] - yx * d[i + 13]
		var c2: = yx * d[i + 12] - yy * d[i + 11]
		var det: = xx * c0 + xy * c1 + xz * c2
		if absf(det) < 1e-06:
			return _near_exact(row, at, radius)
		var ox: = at.x - d[i + 2]
		var oz: = at.z - d[i + 4]
		var dx: = maxf(absf((c0 * ox + (xy * yz - xz * yy) * oz) / det) - d[i + 14] / 2.0, 0.0)
		var dz: = maxf(absf((c2 * ox + (xx * yy - xy * yx) * oz) / det) - d[i + 16] / 2.0, 0.0)
		margin = radius - sqrt(dx * dx + dz * dz)
	if absf(margin) < EDGE_DOUBT:
		return _near_exact(row, at, radius)
	return margin > 0.0


func _near_exact(row: int, at: Vector3, radius: float) -> bool:
	var place: = store.transform(row)
	var local: = place.affine_inverse() * Vector3(at.x, place.origin.y, at.z)
	var half: = store.size(row) / 2.0
	var dx: = maxf(absf(local.x) - half.x, 0.0)
	var dz: = maxf(absf(local.z) - half.z, 0.0)
	if absf(place.basis.y.y) < 0.9:
		var reach: = maxf(half.x, maxf(half.y, half.z))
		return Vector2(at.x - place.origin.x, at.z - place.origin.z).length() < reach + radius
	return dx * dx + dz * dz < radius * radius


func _build_grid() -> void :
	if _gridded:
		return
	_gridded = true
	for row in store.count:
		_grid_row(row)


func _grid_row(row: int) -> void :
	var d: = store.data
	var i: = row * PartStore.COLUMNS
	var hx: = d[i + 14] / 2.0
	var hy: = d[i + 15] / 2.0
	var hz: = d[i + 16] / 2.0
	var ex: = absf(d[i + 5]) * hx + absf(d[i + 6]) * hy + absf(d[i + 7]) * hz
	var ez: = absf(d[i + 11]) * hx + absf(d[i + 12]) * hy + absf(d[i + 13]) * hz
	if ex > 900.0 or ez > 900.0:
		return
	var ox: = d[i + 2]
	var oz: = d[i + 4]
	var low: = Vector2i(floori((ox - ex) / CELL), floori((oz - ez) / CELL))
	var high: = Vector2i(floori((ox + ex) / CELL), floori((oz + ez) / CELL))
	for cx in range(low.x, high.x + 1):
		for cz in range(low.y, high.y + 1):
			var key: = Vector2i(cx, cz)
			if not _grid.has(key):
				_grid[key] = PackedInt32Array()
			_grid[key].append(row)





func box(parent: int, place: Transform3D, size: Vector3, color: Color, material: String, part_name: String, flags: = LOOK) -> int:
	return _made(store.add(PartStore.Shape.BLOCK, place, size, color, material, part_name, parent, flags))



func post(parent: int, foot: Vector3, height: float, width: float, color: Color, material: String, part_name: String, flags: = LOOK) -> int:
	var place: = Transform3D(Basis(Vector3.BACK, PI / 2), foot + Vector3(0, height / 2, 0))
	return _made(store.add(PartStore.Shape.CYLINDER, place, Vector3(height, width, width), color, material, part_name, parent, flags))



func rod(parent: int, from: Vector3, to: Vector3, width: float, color: Color, material: String, part_name: String, flags: = LOOK) -> int:
	var along: = to - from
	var x: = along.normalized()
	var helper: = Vector3.UP if absf(x.y) < 0.95 else Vector3.RIGHT
	var z: = x.cross(helper).normalized()
	var y: = z.cross(x)
	var place: = Transform3D(Basis(x, y, z), (from + to) / 2.0)
	return _made(store.add(PartStore.Shape.CYLINDER, place, Vector3(along.length(), width, width), color, material, part_name, parent, flags))


func ball(parent: int, at: Vector3, size: Vector3, color: Color, material: String, part_name: String, flags: = LOOK) -> int:
	return _made(store.add(PartStore.Shape.ELLIPSOID if size.x != size.y or size.y != size.z else PartStore.Shape.BALL, Transform3D(Basis(), at), size, color, material, part_name, parent, flags))


func wedge(parent: int, place: Transform3D, size: Vector3, color: Color, material: String, part_name: String, flags: = LOOK) -> int:
	return _made(store.add(PartStore.Shape.WEDGE, place, size, color, material, part_name, parent, flags))



func _made(id: int) -> int:
	if _gridded:
		_grid_row(store.row_of[id])
	return id



static func facing(at: Vector3, toward: Vector3) -> Transform3D:
	var flat: = Vector3(toward.x, 0, toward.z)
	if flat.length_squared() < 1e-06:
		return Transform3D(Basis(), at)
	return Transform3D(Basis.looking_at(flat.normalized(), Vector3.UP), at)


static func rgb(r: int, g: int, b: int) -> Color:
	return Color8(r, g, b)





const OPEN_GROUND: = ["", "meadow", "field", "verge", "scrub", "orchard", "park", "forest"]
const GROUND_EDGE: = Rect2(-1360, -1360, 2920, 2920)

var _layout: Dictionary = {}
var _building_grid: Dictionary = {}



func layout() -> Dictionary:
	if _layout.is_empty():
		_layout = Rbx.module("TownLayout")
		for building: Dictionary in _layout["buildings"]:
			var key: = Vector2i(floori(float(building["x"]) / 100.0), floori(float(building["z"]) / 100.0))
			if not _building_grid.has(key):
				_building_grid[key] = []
			_building_grid[key].append(Vector2(float(building["x"]), float(building["z"])))
	return _layout



func building_distance(at: Vector3, within: = 200.0) -> float:
	layout()
	var best: = INF
	var here: = Vector2(at.x, at.z)
	var reach: = ceili(within / 100.0)
	var cell: = Vector2i(floori(at.x / 100.0), floori(at.z / 100.0))
	for dx in range( - reach, reach + 1):
		for dz in range( - reach, reach + 1):
			for spot: Vector2 in _building_grid.get(cell + Vector2i(dx, dz), []):
				best = minf(best, here.distance_to(spot))
	return best if best <= within else INF



func open_ground(at: Vector3, radius: float) -> bool:
	if not GROUND_EDGE.has_point(Vector2(at.x, at.z)):
		return false
	if not OPEN_GROUND.has(surface_at(at)):
		return false
	return clear(at, radius)




func paved_street(on_road: Vector3, across: Vector3, setback: float) -> bool:
	for side: float in [-1.0, 1.0]:
		for out: float in [setback - 4.0, setback, setback + 5.0]:
			if surface_at(on_road + across * side * out) == "pavement":
				return true
	return false




static func along_road(points: Array, step: float, first: = 0.0) -> Array:
	var spots: Array = []
	var next: = first
	var walked: = 0.0
	for leg in points.size() - 1:
		var a: = Vector3(float(points[leg][0]), 0, float(points[leg][1]))
		var b: = Vector3(float(points[leg + 1][0]), 0, float(points[leg + 1][1]))
		var length: = a.distance_to(b)
		if length < 0.5:
			continue
		var way: = (b - a) / length
		while next <= walked + length:
			spots.append([a + way * (next - walked), way])
			next += step
		walked += length
	return spots



func country_road(on_road: Vector3, way: Vector3, half_width: float, clearance: = 70.0) -> bool:
	if building_distance(on_road, clearance) < clearance:
		return false
	return not paved_street(on_road, Vector3( - way.z, 0, way.x), half_width + 4.0)
