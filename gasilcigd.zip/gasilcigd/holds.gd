class_name Holds
extends RefCounted




















const SHOULDER: = 1.47
const BODY_HEIGHT: = 1.43





const VIEW: = Vector3(-0.3, -1.15, -1.25)
const VIEWS: = {
	"nozzle": Vector3(0.8, -0.6, -0.3), 
	"Thermal camera": Vector3(0.25, -0.4, -0.65), 
	"Fan": Vector3(0.0, -0.45, -0.4), 
	"Spreader": Vector3(0.3, -0.3, -0.1), 
	"Cutter": Vector3(0.3, -0.3, -0.1), 
	"Chainsaw": Vector3(0.25, -0.3, -0.1), 
	"Bolt cutters": Vector3(0.4, -0.5, -0.3), 
	"reel": Vector3(0.25, -0.3, -0.5), 
}





const VIEW_AT_WORK: = Vector3(-0.15, -1.5, 0.1)
const LIFT: = 1.3

const VIEW_SHOULDERS: = Vector3(1.0, 0.45, 1.0)


const VIEW_SHOULDERS_BY: = {"Extinguisher": Vector3.ZERO, "Floodlight": Vector3.ZERO, "cone": Vector3.ZERO, "roll": Vector3.ZERO, "divider": Vector3.ZERO, "hose_end": Vector3.ZERO, "reel": Vector3(0.5, 0.2, 0.5), 
	"nozzle": Vector3(1.0, 0.0, 0.4), "Thermal camera": Vector3(1.0, 0.0, 0.4)}
const LIFTS: = {"Extinguisher": 1.5, "Floodlight": 1.5, "cone": 1.5, "roll": 1.5, "divider": 1.5, "reel": 1.35, "hose_end": 1.45, "Fan": 1.05}


const FORCING_TIP: = {
	"Axe": Vector3(0, 2.03, -0.86), 
	"Halligan bar": Vector3(0, -1.86, -0.24), 
	"Crowbar": Vector3(0, -1.32, 0), 
	"Spreader": Vector3(0, -0.48, -1.95), 
}


const BAR_REACH: = 1.85
const BAR_SLACK: = {"Halligan bar": 1.3, "Crowbar": 0.45}

static var debug_phase: = -1.0
const BLOW: = 0.7
const FIRST_BLOW: = 0.25





static func _grip(point: Vector3, thumb: Vector3, wrist: Vector3) -> Transform3D:
	return ArmReach.grip(point, thumb, wrist)


static func _ease(t: float) -> float:
	t = clampf(t, 0.0, 1.0)
	return t * t * (3.0 - 2.0 * t)


static func _mix(a: Transform3D, b: Transform3D, t: float) -> Transform3D:
	return a.interpolate_with(b, clampf(t, 0.0, 1.0))



static func _keys(keys: Array, t: float) -> Transform3D:
	if t <= keys[0][0]:
		return keys[0][1]
	for index in keys.size() - 1:
		var a: Array = keys[index]
		var b: Array = keys[index + 1]
		if t <= b[0]:
			return _mix(a[1], b[1], _ease((t - a[0]) / maxf(b[0] - a[0], 0.0001)))
	return keys[keys.size() - 1][1]



static func _sway(ctx: Dictionary, amount: = 1.0) -> Transform3D:
	var stride: float = minf(ctx.get("stride", 0.0), 1.0) * amount
	var phase: float = ctx.get("phase", 0.0)
	var breath: = sin(float(ctx.get("now", 0.0)) * 1.7) * 0.012 * amount
	return Transform3D(Basis(Vector3.RIGHT, sin(phase) * 0.08 * stride), Vector3(0, - absf(sin(phase)) * 0.07 * stride + breath, sin(phase) * 0.06 * stride))



static func body_of(kind: String, ctx: Dictionary) -> Transform3D:
	return ctx["body"]



static func act_weight(act: Dictionary, reach_time: = 0.22, back_time: = 0.25) -> float:
	if act.is_empty():
		return 0.0
	var done: float = act.get("done", -1.0)
	var t: float = act.get("t", 0.0)
	var going: = _ease(t / reach_time)
	if done >= 0.0:
		return going * (1.0 - _ease(done / back_time))
	return going





static func pose(kind: String, ctx: Dictionary) -> Dictionary:
	match kind:
		"Axe":
			return _axe(ctx)
		"Halligan bar", "Crowbar":
			return _bar(kind, ctx)
		"Bolt cutters":
			return _bolt_cutters(ctx)
		"Spreader", "Cutter":
			return _hydraulic(kind, ctx)
		"Chainsaw":
			return _chainsaw(ctx)
		"Extinguisher":
			return _extinguisher(ctx)
		"Floodlight":
			return _hanging(ctx, Vector3(0, 1.08, 0.1), Vector3(1, 0, 0), - PI / 2.0)
		"Fan":
			return _fan(ctx)
		"Thermal camera":
			return _thermal(ctx)
		"nozzle":
			return _nozzle(ctx)
		"roll":
			return _roll(ctx)
		"divider":
			return _hanging(ctx, Vector3.ZERO, Vector3(0, 0, -1), 0.0)
		"cone":
			return _hanging(ctx, Vector3(0, 2.1, 0), Vector3(0, 0, -1), 0.0)
		"reel":
			return _reel(ctx)
		"hose_end":
			return _hose_end(ctx)
	return {}





static func _hanging(ctx: Dictionary, point: Vector3, handle: Vector3, yaw: float) -> Dictionary:
	var right: = _grip(point, handle, Vector3.UP)
	var stride: float = minf(ctx.get("stride", 0.0), 1.0)
	var phase: float = ctx.get("phase", 0.0)

	var turn: = Basis(Vector3.RIGHT, sin(phase) * 0.12 * stride) * Basis(Vector3.BACK, 0.05) * Basis(Vector3.UP, yaw)
	var hand: = Vector3(SHOULDER + 0.12, -1.66 + absf(sin(phase)) * 0.04 * stride, -0.12)
	return {"place": body_of("", ctx) * ArmReach.place(turn, point, hand), "right": right}


static func _axe(ctx: Dictionary) -> Dictionary:

	var grip_high: = _grip(Vector3(0, 0.3, 0), Vector3.UP, Vector3.BACK)
	var grip_low: = _grip(Vector3(0, -0.38, 0), Vector3.UP, Vector3.BACK)
	var left_grip: = _grip(Vector3(0, -0.8, 0), Vector3.UP, Vector3.BACK)
	var ready: = ArmReach.place(ArmReach.facing(Vector3(0.08, 0.92, -0.38), Vector3(0.3, 0.0, -1.0)), Vector3(0, 0.3, 0), Vector3(1.18, -1.34, -0.82))
	var out: = {"right": grip_high}
	var place: = _sway(ctx) * ready
	var swing: float = ctx.get("swing", -1.0)
	if debug_phase >= 0.0 and swing >= 0.0:
		swing = debug_phase
	var act: Dictionary = ctx.get("act", {})
	if act.get("kind", "") == "force":
		var forced: = _axe_blows(ctx, act)
		place = _mix(place, forced["place"], forced["weight"])
		out["right"] = grip_low
		out["left"] = left_grip
		out["left_weight"] = forced["weight"]
		out["twist"] = forced["twist"]
		out["view_lift"] = 1.0 - forced["weight"]
	elif swing >= 0.0:
		var raised: = ArmReach.place(ArmReach.facing(Vector3(0.12, 0.55, 0.83), Vector3(0, 0.83, -0.55)), Vector3(0, -0.38, 0), Vector3(0.45, 0.3, 0.05))
		var struck: = ArmReach.place(ArmReach.facing(Vector3(0.0, -0.25, -0.97), Vector3(0, -0.97, 0.25)), Vector3(0, -0.38, 0), Vector3(0.08, -0.85, -1.3))
		var low_ready: = ArmReach.place(ready.basis, Vector3(0, -0.38, 0), Vector3(1.0, -1.25, -0.9))
		place = _keys([[0.0, low_ready], [0.32, raised], [0.5, struck], [0.62, struck * Transform3D(Basis(Vector3.RIGHT, 0.06), Vector3(0, 0.05, 0))], [1.0, low_ready]], swing)
		out["right"] = grip_low
		out["left"] = left_grip
		out["left_weight"] = _ease(swing / 0.12) * (1.0 - _ease((swing - 0.82) / 0.18))
		out["twist"] = _keys1([[0.0, 0.0], [0.32, -0.35], [0.5, 0.1], [1.0, 0.0]], swing)
		out["lean"] = _keys1([[0.0, 0.0], [0.32, -0.08], [0.5, 0.2], [0.7, 0.12], [1.0, 0.0]], swing)
	out["place"] = body_of("Axe", ctx) * place
	return out



static func _keys1(keys: Array, t: float) -> float:
	if t <= keys[0][0]:
		return keys[0][1]
	for index in keys.size() - 1:
		var a: Array = keys[index]
		var b: Array = keys[index + 1]
		if t <= b[0]:
			return lerpf(a[1], b[1], _ease((t - a[0]) / maxf(b[0] - a[0], 0.0001)))
	return keys[keys.size() - 1][1]




static func _blow(act: Dictionary) -> Array:
	var t: float = act.get("t", 0.0)

	var u: = (t - FIRST_BLOW) / BLOW + 0.6
	if debug_phase >= 0.0:
		return [debug_phase, 1.0]
	return [fposmod(u, 1.0), act_weight(act, 0.3, 0.3)]



static func _axe_blows(ctx: Dictionary, act: Dictionary) -> Dictionary:
	var lock: Vector3 = _in_body(ctx, act["at"])
	var blow: = _blow(act)
	var u: float = blow[0]
	var tip: Vector3 = FORCING_TIP["Axe"]

	var hands: = Vector3(0.35, -0.85, -0.7)
	var toward: = (lock - hands).normalized()
	var struck_basis: = ArmReach.facing(toward, Vector3(0, -1, 0).slerp(toward, 0.2))
	var struck: = ArmReach.place(struck_basis, tip, lock)
	var raised: = ArmReach.place(ArmReach.facing(Vector3(0.15, 0.6, 0.78), Vector3(0, 0.8, -0.6)), Vector3(0, -0.38, 0), Vector3(0.55, 0.25, 0.05))
	var place: = _keys([[0.0, raised], [0.45, raised], [0.6, struck], [0.72, struck * Transform3D(Basis.IDENTITY, Vector3(0, 0.0, 0.06))], [1.0, raised]], u)
	var twist: = _keys1([[0.0, -0.3], [0.45, -0.3], [0.6, 0.2], [1.0, -0.3]], u)
	return {"place": place, "weight": blow[1], "twist": twist}




static func _bar(kind: String, ctx: Dictionary) -> Dictionary:
	var hand_at: = Vector3(0, 0.25, 0) if kind == "Halligan bar" else Vector3(0, 0.2, 0)
	var right: = _grip(hand_at, Vector3.UP, Vector3.BACK)
	var ready: = ArmReach.place(ArmReach.facing(Vector3(0.1, 0.9, -0.42), Vector3(0.6, 0.0, -1.0)), hand_at, Vector3(1.2, -1.36, -0.8))
	var place: = _sway(ctx) * ready
	var out: = {"right": right}
	var act: Dictionary = ctx.get("act", {})
	var swing: float = ctx.get("swing", -1.0)
	if debug_phase >= 0.0 and swing >= 0.0:
		swing = debug_phase
	if act.get("kind", "") == "force":
		var lock: Vector3 = _in_body(ctx, act["at"])
		var normal: Vector3 = _dir_in_body(ctx, act.get("normal", Vector3.ZERO))
		var blow: = _blow(act)
		var u: float = blow[0]
		var tip: Vector3 = FORCING_TIP[kind]


		var tip_along: float = - tip.y
		var right_at: = Vector3(0, - tip_along + 1.7, 0)
		var left_at: = Vector3(0, - tip_along + 0.8, 0)
		var up_bar: = Vector3(0.6, -0.02, 2.7).normalized()
		if normal != Vector3.ZERO:
			up_bar = (up_bar + Vector3(normal.x, 0, normal.z).normalized() * 0.3).normalized()
		var basis: = ArmReach.facing(up_bar, Vector3(1, 0, 0))
		var driven: = ArmReach.place(basis, tip, lock + up_bar * 0.12)
		var lever: = _keys1([[0.0, 0.0], [0.35, 0.04], [0.6, 0.3], [0.75, 0.26], [1.0, 0.0]], u)
		var drive: = _keys1([[0.0, 0.12], [0.3, 0.12], [0.55, -0.04], [1.0, 0.12]], u)
		var forced: = ArmReach.about(lock, Basis(Vector3.UP, lever)) * Transform3D(Basis.IDENTITY, up_bar * drive) * driven


		var short: = 0.0
		for side: float in [1.0, -1.0]:
			var held_at: Vector3 = driven * (right_at if side > 0.0 else left_at)
			var over: = held_at.distance_to(Vector3(SHOULDER * side, 0, 0)) - BAR_REACH
			short = maxf(short, over / maxf(0.5, - (driven.basis * Vector3.UP).normalized().dot((held_at - Vector3(SHOULDER * side, 0, 0)).normalized())))
		short = clampf(short, 0.0, BAR_SLACK[kind])
		right_at.y += short
		left_at.y += short
		place = _mix(place, forced, blow[1])
		out["right"] = _grip(right_at, Vector3.UP, Vector3(1, 0, 0.3))
		out["left"] = _grip(left_at, Vector3.UP, Vector3(-1, 0, 0.3))
		out["left_weight"] = blow[1]
		out["twist"] = (-0.5 - lever * 0.3) * blow[1]
		out["lean"] = (0.22 + lever * 0.2) * blow[1]
		out["view_lift"] = 1.0 - blow[1]
	elif swing >= 0.0:
		var raised: = ArmReach.place(ArmReach.facing(Vector3(0.1, 0.7, 0.7), Vector3(0, 0.7, -0.7)), hand_at, Vector3(0.6, 0.25, 0.0))
		var struck: = ArmReach.place(ArmReach.facing(Vector3(0.0, -0.1, -1.0), Vector3(0, -1, 0)), hand_at, Vector3(0.35, -0.85, -1.45))
		place = _keys([[0.0, ready], [0.32, raised], [0.5, struck], [0.62, struck], [1.0, ready]], swing)
		out["twist"] = _keys1([[0.0, 0.0], [0.32, -0.3], [0.5, 0.2], [1.0, 0.0]], swing)
		out["lean"] = _keys1([[0.0, 0.0], [0.5, 0.15], [1.0, 0.0]], swing)
	out["place"] = body_of(kind, ctx) * place
	return out


static func _bolt_cutters(ctx: Dictionary) -> Dictionary:

	var right: = _grip(Vector3(0.2, -0.8, 0), Vector3(0.06, 1, 0), Vector3(0, 0, 1))
	var left: = _grip(Vector3(-0.2, -0.8, 0), Vector3(-0.06, 1, 0), Vector3(0, 0, 1))
	var ready: = ArmReach.place(ArmReach.facing(Vector3(0, 0.5, -0.87), Vector3(0, -0.87, -0.5)), Vector3(0, -0.8, 0), Vector3(0.15, -1.15, -1.1))
	return {"place": body_of("Bolt cutters", ctx) * _sway(ctx) * ready, "right": right, "left": left, "left_weight": 1.0}





static func _hydraulic(kind: String, ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0.24, -0.48, 1.1), Vector3(1, 0, 0), Vector3(0, 0.3, 1))
	var left: = _grip(Vector3(0, 0.02, -0.05), Vector3(0, 0, -1), Vector3(-0.6, 1, 0))
	var tool: HandTool = ctx.get("tool")
	var level: = int(tool.get_attr("Working", 0)) if tool != null else 0
	var now: float = ctx.get("now", 0.0)
	var work: = 0.0 if tool == null else tool.work_blend()
	var load: = 0.0 if tool == null else tool.load_blend()


	var ready: = ArmReach.place(Basis(Vector3.UP, 0.5) * ArmReach.facing(Vector3(0, 1, 0), Vector3(0.0, -0.12, -1)), Vector3(0, -0.48, 0.3), Vector3(0.05, -1.28, -1.5))
	var held: = ArmReach.place(Basis(Vector3.UP, 0.42) * ArmReach.facing(Vector3(0, 1, 0), Vector3(0.0, -0.04, -1)), Vector3(0, -0.48, 0.3), Vector3(0.0, -1.12, -1.62))
	var heave: = sin(now * 5.0) * 0.06 * load
	var place: = _mix(_sway(ctx, 0.6) * ready, held * Transform3D(Basis.IDENTITY, Vector3(0, 0, - heave)), work)
	var out: = {"right": right, "left": left, "left_weight": 1.0, "lean": (0.06 + heave * 0.5) * work, "twist": -0.25}
	var act: Dictionary = ctx.get("act", {})
	if act.get("kind", "") == "force":
		var lock: Vector3 = _in_body(ctx, act["at"])
		var blow: = _blow(act)
		var toward: = (lock - Vector3(0.1, -1.0, -0.8))
		toward.y *= 0.3
		var basis: = ArmReach.aiming(toward.normalized())
		var pushed: = ArmReach.place(basis, FORCING_TIP["Spreader"], lock + toward.normalized() * 0.05)
		var shove: = _keys1([[0.0, 0.0], [0.5, 0.0], [0.6, 0.12], [1.0, 0.0]], blow[0])
		place = _mix(place, Transform3D(Basis.IDENTITY, toward.normalized() * shove) * pushed, blow[1])
		out["lean"] = 0.12 * blow[1]
		out["view_lift"] = 1.0 - blow[1]
	out["place"] = body_of(kind, ctx) * place
	return out




static func _chainsaw(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0, 0.37, 0.45), Vector3(0, 0.86, -0.51), Vector3(0, 0.51, 0.86))
	var left: = _grip(Vector3(-0.43, 0.7, -0.82), Vector3(0, 1, 0), Vector3(-1, 0, 0.3))
	var tool: HandTool = ctx.get("tool")
	var now: float = ctx.get("now", 0.0)
	var work: = 0.0 if tool == null else tool.work_blend()
	var load: = 0.0 if tool == null else tool.load_blend()

	var ready: = ArmReach.place(Basis(Vector3.UP, 0.5), Vector3(0, 0.37, 0.45), Vector3(0.5, -1.35, -0.95))
	var revving: = ArmReach.place(Basis(Vector3.UP, 0.5) * Basis(Vector3.RIGHT, 0.08), Vector3(0, 0.37, 0.45), Vector3(0.45, -1.22, -1.0))
	var cutting: = ArmReach.place(Basis(Vector3.UP, 0.65) * Basis(Vector3.RIGHT, -0.3), Vector3(0, 0.37, 0.45), Vector3(0.5, -1.4, -1.0))
	var rock: = Transform3D(Basis(Vector3.RIGHT, sin(now * 9.0) * 0.05 * load), Vector3(0, sin(now * 9.0) * 0.04 * load, 0))
	var place: = _mix(_mix(_sway(ctx, 0.5) * ready, revving, work), cutting * rock, load)
	return {"place": body_of("Chainsaw", ctx) * place, "right": right, "left": left, "left_weight": 1.0, "lean": 0.05 * work + 0.12 * load, "twist": -0.2}




static func _extinguisher(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0, 1.75, 0.18), Vector3(0, 0, -1), Vector3(0, 1, 0.15))
	var tool: HandTool = ctx.get("tool")
	var work: = 0.0 if tool == null else tool.work_blend()
	var phase: float = ctx.get("phase", 0.0)
	var stride: float = minf(ctx.get("stride", 0.0), 1.0)
	var carried: = ArmReach.place(Basis(Vector3.RIGHT, sin(phase) * 0.1 * stride), Vector3(0, 1.75, 0.18), Vector3(SHOULDER + 0.1, -1.62, -0.15))
	var raised: = ArmReach.place(Basis(Vector3.UP, 0.35) * Basis(Vector3.RIGHT, -0.12), Vector3(0, 1.75, 0.18), Vector3(0.65, -1.2, -1.05))
	var place: = _mix(carried, raised, work)
	var out: = {"right": right, "place": body_of("Extinguisher", ctx) * place}
	if work > 0.0:

		var body: Transform3D = body_of("Extinguisher", ctx)
		var hand: = Vector3(-0.15, -1.05, -1.45)
		var aim: Vector3 = ctx.get("aim", Vector3.INF)
		var ahead: = Vector3(0, -0.15, -1).normalized()
		if aim != Vector3.INF:
			var to: = body.affine_inverse() * aim - hand
			if to.length() > 2.0:
				ahead = to.normalized()
				ahead.y = clampf(ahead.y, -0.7, 0.5)
				ahead = ahead.normalized()
		var horn: = ArmReach.place(ArmReach.aiming(ahead), Vector3(0, 0, -0.05), hand)
		out["horn"] = body * horn
		var horn_hand: = _grip(Vector3(0, 0, -0.05), Vector3(0, 0, -1), Vector3(-0.5, 0.2, 1))
		out["left"] = (body * place).affine_inverse() * (body * horn) * horn_hand
		out["left_weight"] = work
	return out



static func _fan(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0.55, 1.9, 0.4), Vector3(-1, 0, 0), Vector3(0, 0.4, 1))
	var left: = _grip(Vector3(-0.55, 1.9, 0.4), Vector3(1, 0, 0), Vector3(0, 0.4, 1))
	var ready: = ArmReach.place(Basis(Vector3.RIGHT, 0.12), Vector3(0, 1.9, 0.4), Vector3(0.0, -1.05, -1.25))
	return {"place": body_of("Fan", ctx) * _sway(ctx, 0.6) * ready, "right": right, "left": left, "left_weight": 1.0, "lean": -0.06}



static func _thermal(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0, 0.12, 0.0), Vector3(0, 0.95, -0.3), Vector3(0, 0, 1))
	var left: = _grip(Vector3(-0.2, 0.5, 0.05), Vector3(0, 0, -1), Vector3(-1, -0.4, 0))
	var aim: Vector3 = ctx.get("aim", Vector3.INF)
	var tilt: = 0.0
	var body: Transform3D = body_of("Thermal camera", ctx)
	if aim != Vector3.INF:
		var to: = body.affine_inverse() * aim
		tilt = clampf(atan2(to.y + 0.4, - to.z), -0.6, 0.5) if to.z < -1.0 else 0.0
	var ready: = ArmReach.place(Basis(Vector3.RIGHT, tilt * 0.8), Vector3(0, 0.5, 0), Vector3(0.18, -0.55, -1.15))

	return {"place": body * _sway(ctx, 0.4) * ready, "right": right, "left": left, "left_weight": 0.0 if ctx.get("view", false) else 1.0}




static func _nozzle(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0, -0.45, 0.04), Vector3(0, 0.97, -0.24), Vector3(0, 0, 1))
	var left: = _grip(Vector3(0, 0.0, 0.4), Vector3(0, 0, -1), Vector3(-0.8, 0.6, 0))
	var body: Transform3D = body_of("nozzle", ctx)
	var hand: = Vector3(0.18, -1.05, -1.1)
	var ahead: = Vector3(0, 0, -1)
	var aim: Vector3 = ctx.get("aim", Vector3.INF)
	if aim != Vector3.INF:
		var from: = hand + Vector3(0, 0.45, 0)
		var to: = body.affine_inverse() * aim - from

		if ctx.get("view", false):
			to = to.normalized() * maxf( - to.z, 25.0) if to.z < 0.0 else Vector3(0, 0, -25)
		if to.length() > 1.0:
			ahead = to.normalized()
	ahead.y = clampf(ahead.y, -0.75, 0.85)
	ahead = ahead.normalized()
	hand.y += ahead.y * 0.35
	var place: = ArmReach.place(ArmReach.aiming(ahead), Vector3(0, -0.45, 0.04), hand)
	place = _sway(ctx, 0.5) * place
	return {"place": body * place, "right": right, "left": left, "left_weight": 1.0}



static func _roll(ctx: Dictionary) -> Dictionary:

	var right: = _grip(Vector3(0, 0, 0), Vector3(0, 0, -1), Vector3(0, 1, 0))
	var phase: float = ctx.get("phase", 0.0)
	var stride: float = minf(ctx.get("stride", 0.0), 1.0)
	var place: = ArmReach.place(Basis(Vector3.RIGHT, sin(phase) * 0.1 * stride), Vector3.ZERO, Vector3(SHOULDER + 0.18, -1.62, -0.1))
	return {"place": body_of("roll", ctx) * place, "right": right}



static func _reel(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3(0, 0.5, 0), Vector3(0, 1, 0), Vector3(0, 0, 1))
	var place: = ArmReach.place(Basis(Vector3.RIGHT, -0.2), Vector3(0, 0.5, 0), Vector3(1.25, -1.4, -0.7))
	return {"place": body_of("reel", ctx) * _sway(ctx) * place, "right": right}



static func _hose_end(ctx: Dictionary) -> Dictionary:
	var right: = _grip(Vector3.ZERO, Vector3(0, 0, -1), Vector3(0, 1, 0.3))
	var place: = ArmReach.place(Basis.IDENTITY, Vector3.ZERO, Vector3(1.35, -1.5, -0.55))
	return {"place": body_of("hose_end", ctx) * _sway(ctx) * place, "right": right}







static func act_hand(ctx: Dictionary, shoulder: Vector3, left: bool) -> Array:
	var act: Dictionary = ctx.get("act", {})
	if act.is_empty() or act.get("kind", "") == "force":
		return []
	var weight: = act_weight(act, 0.2 if act.get("kind") == "reach" else 0.28)
	if act.get("kind") in ["reach", "place"] and float(act.get("done", -1.0)) < 0.0:

		var t: float = act.get("t", 0.0)
		weight = _ease(t / 0.18) * (1.0 - _ease((t - 0.32) / 0.22))
	if weight <= 0.0:
		return []
	var at: Vector3 = act["at"]
	var body: Transform3D = ctx["body"]
	var reach: = (ArmReach.UPPER + ArmReach.LOWER + ArmReach.FIST) * (0.95 if not ctx.get("view", false) else 0.9)
	var to: = at - shoulder
	var distance: = to.length()
	var hand: = shoulder + to.normalized() * minf(distance - 0.25, reach) if distance > 0.3 else at

	var ahead: = to.normalized()
	var up: = body.basis.y.normalized()
	var turn: = Basis(ArmReach.aiming(ahead, up))

	var hand_basis: = Basis(turn.x, - turn.z, turn.y).rotated(ahead, (0.4 if left else -0.4))
	if act.get("kind") == "work":
		var t: float = act.get("t", 0.0)
		hand_basis = hand_basis.rotated(ahead, sin(t * 6.0) * 0.35)
		hand += ahead.cross(up).normalized() * sin(t * 6.0) * 0.05
	return [Transform3D(hand_basis, hand), weight]



static func _in_body(ctx: Dictionary, at: Vector3) -> Vector3:
	return (ctx["body"] as Transform3D).affine_inverse() * at


static func _dir_in_body(ctx: Dictionary, direction: Vector3) -> Vector3:
	if direction == Vector3.ZERO:
		return Vector3.ZERO
	return ((ctx["body"] as Transform3D).basis.inverse() * direction).normalized()
