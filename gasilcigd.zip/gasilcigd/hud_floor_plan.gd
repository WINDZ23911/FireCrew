class_name HudFloorPlan
extends Control






const NEAR: = 70.0
const CELL: = 120.0

var _house: House
var _title: Label


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_title = Ui.caps("", 13)
	_title.add_theme_constant_override("outline_size", 4)
	_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	add_child(_title)
	visible = false



static func burning_house() -> House:
	var fire: = FireService.current
	if fire == null:
		return null
	var building: Variant = null
	if Net.is_client():
		if fire._net_building >= 0 and fire._net_building < fire.buildings.size():
			building = fire.buildings[fire._net_building]
	elif not fire.incident.is_empty():
		building = fire.incident["group"]["building"]
	return building as House if building is House else null


func _process(_delta: float) -> void :
	var player: = Game.local_player
	_house = burning_house()
	var wanted: = _house != null and player != null and player.seat == null and not Game.ui_open\
	and player.root_position().distance_to(_house.position) <= NEAR + float(_house.data["size"][0]) / 2.0
	var hud: = Hud.current
	if wanted and hud != null and hud.widgets.has("map") and (hud.widgets["map"] as Control).visible:
		wanted = false
	visible = wanted
	if wanted:
		queue_redraw()


func _scale() -> float:
	return Settings.hud_scale * get_viewport_rect().size.y / 1080.0


func _draw() -> void :
	if _house == null:
		return
	var k: = _scale()
	var floors: Dictionary = {}
	for room_name: String in _house.rooms:
		var room: Dictionary = _house.rooms[room_name]
		var number: = int(room["floor"])
		if not floors.has(number):
			floors[number] = []
		floors[number].append(room)
	var plan: Array = _house.data["size"]
	var wide: = maxf(float(plan[0]), float(plan[2]))
	var unit: = CELL * k / maxf(wide, 1.0)
	var gap: = 10.0 * k
	var top: = get_viewport_rect().size.y * 0.5
	var left: = 24.0 * k
	var numbers: = floors.keys()
	numbers.sort()
	var burning: = {}
	for flame in Flame.all:
		if is_instance_valid(flame) and flame.global_position.distance_to(_house.position) < 120.0:
			var inside: Variant = _house.room_at(flame.global_position)
			if inside != null:
				burning[inside["name"]] = true
	var searched: = 0
	var player: = Game.local_player
	var me: Vector3 = _house.lot.affine_inverse() * player.root_position() if player != null else Vector3.INF
	var at_x: = left
	for number: int in numbers:
		var origin: = Vector2(at_x, top + 22.0 * k)
		draw_rect(Rect2(origin - Vector2(4, 4) * k, Vector2(float(plan[0]) * unit, float(plan[2]) * unit) + Vector2(8, 8) * k), Color(Ui.PANEL, 0.72))
		for room: Dictionary in floors[number]:
			var low: Vector3 = room["low"]
			var high: Vector3 = room["high"]

			var corner: = origin + Vector2((low.x + float(plan[0]) / 2.0) * unit, (float(plan[2]) / 2.0 - high.z) * unit)
			var box: = Rect2(corner, Vector2((high.x - low.x) * unit, (high.z - low.z) * unit)).grow(-1.0 * k)
			var fill: = Color(Ui.INSET, 0.85).lerp(Color(0.05, 0.05, 0.05, 0.95), clampf(float(room.get("level", 0.0)), 0.0, 1.0))
			draw_rect(box, fill)
			if room.get("searched", false):
				searched += 1
				draw_rect(box, Color(Ui.GREEN, 0.28))
				_tick(box.get_center(), minf(box.size.x, box.size.y) * 0.3, k)
			if burning.has(room["name"]):
				draw_rect(box, Color(Ui.AMBER, 0.95), false, 2.0 * k)
			if me.x >= low.x and me.x <= high.x and me.z >= low.z and me.z <= high.z and me.y >= low.y - 1.0 and me.y <= high.y:
				var dot: = origin + Vector2((me.x + float(plan[0]) / 2.0) * unit, (float(plan[2]) / 2.0 - me.z) * unit)
				draw_circle(dot, 3.5 * k, Ui.YELLOW)
		at_x += float(plan[0]) * unit + gap
	_title.position = Vector2(left, top)
	_title.add_theme_font_size_override("font_size", int(13 * k))
	_title.text = Text.say(Text.f("hud.floorPlan.searched", [searched, _house.rooms.size()]))


func _tick(middle: Vector2, reach: float, k: float) -> void :
	var points: = PackedVector2Array([middle + Vector2( - reach, 0), middle + Vector2( - reach * 0.3, reach * 0.7), middle + Vector2(reach, - reach * 0.8)])
	draw_polyline(points, Ui.GREEN, maxf(2.0 * k, 1.5))
