class_name JobSearch
extends CrewJob






var house: House
var found_before: = 0
var skipped: Array = []
var room: = ""


func _init(building: House = null) -> void :
	kind = "search"
	role = "rescue"
	house = building


func place() -> Vector3:
	var building: = house if house != null else CrewSearch.house()
	if building == null:
		return who.body.global_position if who != null else Vector3.ZERO
	return building.position


func title() -> Variant:
	if room.is_empty():
		return Text.m("crew.jobs.search")
	return Text.f("crew.jobs.searchRoom", [CrewSearch.room_words(room)])


func _found_now() -> int:
	var count: = 0
	if VictimService.current != null:
		for victim: Victim in VictimService.current.victims:
			count += 1 if victim.found and victim.state == "lying" else 0
	return count


func run() -> bool:
	if house == null:
		house = CrewSearch.house()
	if house == null:
		return fail("crew.say.nothingThere")
	var held: = who.token()
	var service: = who.service
	found_before = _found_now()
	var fire: = FireService.current
	var smoky: = fire != null and not fire.incident.is_empty()
	if smoky and not await CrewWater.wear_set(who):
		who.say("crew.say.noSet", [], "warning")
	if not on(held):
		return false
	CrewKit.free_hands(who)
	var low: = float(Config.Crew.Search.CrouchSmoke)
	while on(held):
		if _found_now() > found_before:
			return true
		if not CrewWater.breathe(who):
			return fail("crew.say.lowAir")
		if who.body.health < who.body.max_health * who.back_out_at():
			return fail("crew.say.hurt")
		room = CrewSearch.next_room(service, who, house, skipped)
		if room.is_empty():
			if skipped.is_empty():

				var waiting: = false
				for hot_room: Variant in CrewSearch.hot_rooms(house):
					waiting = waiting or not CrewSearch.searched(service, house, str(hot_room))
				if not waiting:
					who.report("crew.say.report.searchDone", [], "good")
				else:
					quiet = true
				return true
			return fail("crew.say.cannotReach", [CrewSearch.room_words(skipped[0])])
		who.job_changed.emit()
		CrewSearch.claim(service, who, room)
		var target: = CrewSearch.middle(house, room)
		var aim: = room
		var reached: = await who.go(target, 2.5, float(Config.Crew.Search.RoomGiveUp), func() -> bool:

			who.crouch = fire != null and fire.smoke_at(who.body.head_position()) > low
			if _found_now() > found_before:
				return true
			var inside: Variant = house.room_at(who.body.root_position())
			return inside != null and inside["name"] == aim and who.body.global_position.distance_to(target) < float(Config.Crew.Search.Near)
		)
		who.crouch = false
		if not on(held):
			return false
		if not reached:
			if not who.blocked_by.is_empty() and who.blocked_by["locked"]:
				var door: = who.blocked_by
				if await CrewSearch.force_way(who, door, held):
					continue
			skipped.append(room)
			continue

		for spot: Vector3 in _sweep(room):
			if _found_now() > found_before or not on(held):
				break
			await who.go(spot, 2.0, 12.0, func() -> bool: return _found_now() > found_before)
		CrewSearch.visited(service, room)

		who.look = target + Vector3(randf_range(-3, 3), 0, randf_range(-3, 3))
		await who.wait(float(Config.Crew.Search.Look), held)
	return false



func _sweep(room_name: String) -> Array[Vector3]:
	var spots: Array[Vector3] = []
	var room: Dictionary = house.rooms[room_name]
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var size: = high - low
	var sees: = float(Config.Victims.Search.FindRange) * float(Config.Crew.Search.Sweep)
	if maxf(size.x, size.z) <= sees:
		return spots
	var middle: = (low + high) / 2.0
	var along: = Vector3(size.x / 4.0, 0, 0) if size.x >= size.z else Vector3(0, 0, size.z / 4.0)
	for side: float in [-1.0, 1.0]:
		var local: = Vector3(middle.x, low.y + 2.0, middle.z) + along * side
		spots.append(house.lot * local)
	return spots


func finish(_done: bool) -> void :
	who.crouch = false
	var claims: Dictionary = who.service.done_here.get("claims", {})
	for key: Variant in claims.keys():
		if claims[key] == who:
			claims.erase(key)
