extends ProofDebug










func _scenario_scbalocker() -> void :
	await _wait(1.0)
	var air: = AirService.current
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.8)
	GearService.current._gear_up(player, null, true)

	air.bars["truck"][1] = 140.0
	air.bars["truck"][2] = 90.0
	air.bars["truck"][3] = 40.0
	air._update_counts()
	var lockers: = Lockers.of(pumper)
	var handle: Dictionary = lockers.handles[0]
	var node: Node3D = handle["node"]
	var out: = node.global_position - pumper.global_position
	out = Vector3(out.x, 0, out.z).normalized()
	player.teleport(_ground(node.global_position + out * 4.0) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	lockers.set_open(handle, true)
	await _wait(1.5)
	var lines: Array = []
	for slot in 4:
		lines.append(air.line_of_set("truck", slot))
	var said: Array = lines.map( func(line: LockerLine) -> String: return "%s · %s" % [Text.say(line.action, "en"), Text.say(line.object, "en")])
	print("scbalocker: the pumper's set lines: %s" % [said])
	_check(lines.all( func(line: Variant) -> bool: return line != null and line in lockers.lines), "four lines, one for each set in the pumper")
	_check(said == ["Set 1 · 300 bar", "Set 2 · 140 bar", "Set 3 · 90 bar", "Set 4 · 40 bar"], "each line says its set and the air in it")
	var menu: LockerMenu = Hud.current.widgets["locker"]
	menu.open(player, handle, lockers)
	await _wait(0.5)
	var colours: Array = lines.map( func(line: LockerLine) -> Color: return menu._line_color(line))
	_check(colours == [Ui.GREEN, Ui.AMBER, Ui.AMBER, Ui.RED], "coloured by the air: green, amber below half, red at the whistle")
	var rows: = _row_texts(menu)
	print("scbalocker: the menu reads %s" % [rows])
	var set3: = Text.say(Text.f("gear.air.setNumber", [3])).to_upper() + " · 90 BAR"
	_check(rows.any( func(text: String) -> bool: return text.contains(set3)), "the menu shows set 3 with its 90 bar")
	_view(player.global_position + Vector3(0, 6, 0) - out * 8.0, node.global_position)
	await _wait(0.3)
	await _snap("menu")


	menu._choose(lines[2])
	await _wait(0.6)
	print("scbalocker: took set 3: wearing %s, slot %s, %.0f bar; sets left %d; prop Set3 shown %s, Set1 %s" % [air.wearing(player), 
		air.sets[player].get("slot") if air.wearing(player) else "-", air.pressure(player), int(air.pool["truck"]), 
		pumper.props["Set3"]["node"].visible if pumper.props.has("Set3") else "?", pumper.props["Set1"]["node"].visible if pumper.props.has("Set1") else "?"])
	_check(air.wearing(player) and int(air.sets[player]["slot"]) == 2 and is_equal_approx(air.pressure(player), 90.0), "set 3 taken, with its 90 bar")
	_check( not air.held("truck", 0) and int(air.pool["truck"]) == 3, "set 1 still in the locker")
	_check((lines[2] as LockerLine).holder == player, "set 3's line is with the player")
	if pumper.props.has("Set3"):
		_check( not pumper.props["Set3"]["node"].visible and pumper.props["Set1"]["node"].visible, "set 3's own place in the locker is empty")
	menu.open(player, handle, lockers)
	await _wait(0.5)
	var tags: = menu._rows.find_children("*", "Label", true, false).filter( func(label: Label) -> bool: return label.text == Text.say(Text.m("hud.locker.withYou")))
	_check(tags.size() == 1, "the menu marks set 3 as with you")
	await _wait(0.2)
	await _snap("taken")


	menu._choose(lines[0])
	await _wait(0.6)
	print("scbalocker: swapped for set 1: slot %s, %.0f bar; set 3 waits at %.0f bar" % [air.sets[player].get("slot") if air.wearing(player) else "-", air.pressure(player), float(air.bars["truck"][2])])
	_check(air.wearing(player) and int(air.sets[player]["slot"]) == 0 and is_equal_approx(air.pressure(player), 300.0), "set 1 taken in its place")
	_check( not air.held("truck", 2) and is_equal_approx(float(air.bars["truck"][2]), 90.0), "set 3 back in its own place with its 90 bar")

	var told: Array = []
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))
	var other: = Player.new()
	other.display_name = "Ana"
	air.holders["truck"][1] = other
	air._recount()
	air._update_counts()
	menu.open(player, handle, lockers)
	await _wait(0.5)
	rows = _row_texts(menu)
	print("scbalocker: with set 2 out with Ana the menu reads %s" % [rows])
	var set2: = Text.say(Text.f("gear.air.setNumber", [2])).to_upper()
	_check(rows.any( func(text: String) -> bool: return text.contains(set2) and text.contains("ANA")), "a set out with somebody says who has it")
	await _snap("others")
	menu.close()
	lockers.use(player, handle, lines[1])
	await _wait(0.3)
	_check(int(air.sets[player]["slot"]) == 0 and told.any( func(line: String) -> bool: return line.contains("Set 2 is with Ana")), "set 2 is not taken from Ana")
	air.holders["truck"][1] = null
	other.free()
	air._recount()
	air._update_counts()
	lockers.use(player, handle, "all")
	await _wait(0.4)
	_check( not air.wearing(player) and int(air.pool["truck"]) == 4 and is_equal_approx(float(air.bars["truck"][0]), 300.0), "Return all puts set 1 back in its place")
	await _done()



func _row_texts(menu: LockerMenu) -> Array:
	var texts: Array = []
	for control in menu._rows.find_children("*", "", true, false):
		if control is Button and not (control as Button).text.is_empty():
			texts.append((control as Button).text)
		elif control is Label and not (control as Label).text.is_empty():
			texts.append((control as Label).text)
	return texts


func _scenario_scbaroom() -> void :
	await _wait(1.5)
	var air: = AirService.current
	var station: = Game.station
	var base: Transform3D = Game.records["station"]["places"]["compressor"]

	var hidden: = 0
	var found: = 0
	for part_name: String in ["ApparatusDoor", "ApparatusDoorPane", "ApparatusDoorHandle", "ApparatusAlleyDoor", "ApparatusAlleyDoorPane", "ApparatusAlleyDoorHandle"]:
		for row in Game.store.rows_named(part_name):
			found += 1
			hidden += 1 if Game.world._hidden.has(row) else 0
	print("scbaroom: the room's door parts: %d, hidden %d" % [found, hidden])
	_check(found == 6 and hidden == found, "the breathing-apparatus room's doors are gone")
	var near_leaves: = 0
	for key: String in station.leaves:
		var hinge: Vector3 = station.leaves[key]["hinge"]
		if Vector2(hinge.x - base.origin.x, hinge.z - base.origin.z).length() < 6.0 and absf(hinge.y - base.origin.y) < 12.0:
			print("scbaroom: a door leaf hinged at %s near the filling station" % hinge)
			near_leaves += 1
	_check(near_leaves == 0, "no door swings near the filling station")
	GearService.current._gear_up(player, null, true)
	player.teleport(_ground(base * Vector3(-1.0, 0, 6.5)) + Vector3(0, 0.3, 0))
	await _wait(0.5)

	_view(base * Vector3(-10.5, 6.0, 6.0), base * Vector3(-1.0, 2.6, -0.5), 70.0)
	await _wait(0.4)
	await _snap("doorway")
	_view(base * Vector3(-1.2, 5.6, 6.0), base * Vector3(0, 2.4, -0.6), 65.0)
	await _wait(0.3)
	await _snap("room")


	var told: Array = []
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))
	var pumper: = air.truck
	var by_station: = pumper.global_position.distance_to(air._compressor_at) <= float(Config.Air.RestockRange)
	print("scbaroom: the pumper %.0f studs from the compressor" % pumper.global_position.distance_to(air._compressor_at))
	air.bars["rack"][0] = 60.0
	air.bars["rack"][1] = 120.0
	air.bars["rack"][2] = 200.0
	air.bars["truck"][1] = 50.0
	air.spares = int(Config.Air.TruckSpares) - 1
	air._update_counts()
	air._on_compressor(player)
	await _wait(3.0)
	var cylinders: Array = air._station["cylinders"]
	var shown: = cylinders.filter( func(cylinder: Node3D) -> bool: return cylinder.visible).size()
	var lamp: MeshInstance3D = air._station["lamp"]
	var needle: Node3D = air._station["needle"]
	print("scbaroom: 3 s in: %d cylinders in the cradles, lamp red %s, needle at %.0f°, rack sets %s, told %s" % [shown, lamp.material_override == CallKit.plain(AirService.RED, 2.5), rad_to_deg(needle.rotation.z), str(air.bars["rack"].slice(0, 3)), told])
	_check(by_station, "the pumper stands by the station")
	_check(shown == 3, "three cylinders fill in the cradles at once")
	_check(lamp.material_override == CallKit.plain(AirService.RED, 2.5), "the lamp is red while it runs")
	_check(needle.rotation.z < deg_to_rad(120.0), "the needle has moved up")
	_check(float(air.bars["rack"][0]) > 60.0 and float(air.bars["rack"][0]) < 300.0, "they fill over time, not at once")
	_check(told.any( func(line: String) -> bool: return line.begins_with("The compressor is filling")), "the player is told it is filling")
	_view(base * Vector3(1.8, 5.0, 4.2), base * Vector3(-0.3, 2.9, -0.6), 55.0)
	await _wait(0.3)
	await _snap("filling")
	_view(base * Vector3(-1.2, 5.6, 6.0), base * Vector3(0, 2.4, -0.6), 65.0)
	await _wait(0.2)
	await _snap("filling_room")
	await _wait(float(Config.Air.CradleFillTime) * 2.0 + 1.0)
	shown = cylinders.filter( func(cylinder: Node3D) -> bool: return cylinder.visible).size()
	print("scbaroom: after: rack %s, pumper's set 2 %.0f, spares %d, cylinders shown %d; told %s" % [str(air.bars["rack"].slice(0, 3)), float(air.bars["truck"][1]), air.spares, shown, told])
	var capacity: = float(Config.Air.Capacity)
	_check([0, 1, 2].all( func(slot: int) -> bool: return is_equal_approx(float(air.bars["rack"][slot]), capacity)), "the rack's sets are full")
	_check(is_equal_approx(float(air.bars["truck"][1]), capacity) and told.has("Set 2 of the fire truck filled"), "the pumper's set 2 is full, and said")
	_check(air.spares == int(Config.Air.TruckSpares), "the spare cylinder is full again")
	_check(told.has("All cylinders are full"), "and the player told when all are full")
	_check(shown == 0 and lamp.material_override == CallKit.plain(AirService.GREEN, 2.5), "the cradles empty and the lamp green again")
	await _snap("done")
	await _done()
