class_name ShapeKit
extends RefCounted





enum {PAINT, METAL, RUBBER, GLOW}

static var _finishes: Array[StandardMaterial3D] = []

var at: = Transform3D.IDENTITY
var _parts: Dictionary = {}


static func finish(kind: int) -> StandardMaterial3D:
	if _finishes.is_empty():
		for index in 4:
			var made: = StandardMaterial3D.new()
			made.vertex_color_use_as_albedo = true
			made.vertex_color_is_srgb = true
			match index:
				PAINT:
					made.roughness = 0.42
					made.metallic = 0.1
				METAL:
					made.roughness = 0.3
					made.metallic = 0.85
				RUBBER:
					made.roughness = 0.88
				GLOW:
					made.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			_finishes.append(made)
	return _finishes[kind]


func _tri(kind: int, color: Color, a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3) -> void :
	if not _parts.has(kind):
		_parts[kind] = [PackedVector3Array(), PackedVector3Array(), PackedColorArray()]
	var part: Array = _parts[kind]
	var turn: = at.basis
	var normals: = turn.inverse().transposed()


	part[0].append_array([at * a, at * c, at * b])
	part[1].append_array([(normals * na).normalized(), (normals * nc).normalized(), (normals * nb).normalized()])
	part[2].append_array([color, color, color])



func poly(kind: int, color: Color, points: Array, outward: = Vector3.ZERO) -> void :
	if points.size() < 3:
		return
	var normal: = Vector3.ZERO
	for index in points.size():
		var p: Vector3 = points[index]
		var q: Vector3 = points[(index + 1) % points.size()]
		normal += Vector3((p.y - q.y) * (p.z + q.z), (p.z - q.z) * (p.x + q.x), (p.x - q.x) * (p.y + q.y))
	if normal.length() < 1e-09:
		return
	normal = normal.normalized()
	var ordered: = points
	if outward != Vector3.ZERO and normal.dot(outward) < 0.0:
		ordered = points.duplicate()
		ordered.reverse()
		normal = - normal
	for index in range(1, ordered.size() - 1):
		_tri(kind, color, ordered[0], ordered[index], ordered[index + 1], normal, normal, normal)



func box(kind: int, color: Color, low: Vector3, high: Vector3, bevel: = 0.0, turn: = Basis.IDENTITY) -> void :
	var middle: = (low + high) / 2.0
	var half: = (high - low).abs() / 2.0
	bevel = clampf(bevel, 0.0, minf(half.x, minf(half.y, half.z)) * 0.95)
	var corner: = func(s: Vector3, axis: int) -> Vector3:
		var p: = s * (half - Vector3.ONE * bevel)
		p[axis] += s[axis] * bevel
		return middle + turn * p
	var signs: Array[Vector3] = []
	for x in [-1.0, 1.0]:
		for y in [-1.0, 1.0]:
			for z in [-1.0, 1.0]:
				signs.append(Vector3(x, y, z))

	for axis in 3:
		for side in [-1.0, 1.0]:
			var out: = Vector3.ZERO
			out[axis] = side
			var u: = (axis + 1) % 3
			var v: = (axis + 2) % 3
			var fixed: Array = []
			for pair: Array in [[-1.0, -1.0], [1.0, -1.0], [1.0, 1.0], [-1.0, 1.0]]:
				var s: = Vector3.ZERO
				s[axis] = side
				s[u] = pair[0]
				s[v] = pair[1]
				fixed.append(corner.call(s, axis))
			poly(kind, color, fixed, turn * out)
	if bevel <= 0.0:
		return

	for a in 3:
		for b in range(a + 1, 3):
			var c: = 3 - a - b
			for sa in [-1.0, 1.0]:
				for sb in [-1.0, 1.0]:
					var s0: = Vector3.ZERO
					s0[a] = sa
					s0[b] = sb
					s0[c] = -1.0
					var s1: = s0
					s1[c] = 1.0
					var out: = Vector3.ZERO
					out[a] = sa
					out[b] = sb
					poly(kind, color, [corner.call(s0, a), corner.call(s1, a), corner.call(s1, b), corner.call(s0, b)], turn * out)
	for s in signs:
		poly(kind, color, [corner.call(s, 0), corner.call(s, 1), corner.call(s, 2)], turn * s)




func tube(kind: int, color: Color, points: Array, radius: Variant, sides: = 10, caps: = true) -> void :
	var count: = points.size()
	if count < 2:
		return
	var radii: Array = []
	for index in count:
		radii.append(radius[index] if radius is Array else float(radius))
	var tangents: Array[Vector3] = []
	for index in count:
		var before: Vector3 = points[maxi(index - 1, 0)]
		var after: Vector3 = points[mini(index + 1, count - 1)]
		tangents.append((after - before).normalized())
	var helper: = Vector3.UP if absf(tangents[0].dot(Vector3.UP)) < 0.9 else Vector3.RIGHT
	var side: = tangents[0].cross(helper).normalized()
	var rings: Array = []
	for index in count:
		var t: = tangents[index]
		side = (side - t * side.dot(t)).normalized()
		var up: = t.cross(side)
		var ring: Array[Vector3] = []
		var normals: Array[Vector3] = []
		for k in sides:
			var angle: = TAU * k / sides
			var n: = side * cos(angle) + up * sin(angle)
			ring.append(points[index] + n * float(radii[index]))
			normals.append(n)
		rings.append([ring, normals])
	for index in count - 1:
		var r0: Array = rings[index]
		var r1: Array = rings[index + 1]
		for k in sides:
			var k1: = (k + 1) % sides
			_tri(kind, color, r0[0][k], r1[0][k1], r1[0][k], r0[1][k], r1[1][k1], r1[1][k])
			_tri(kind, color, r0[0][k], r0[0][k1], r1[0][k1], r0[1][k], r0[1][k1], r1[1][k1])
	if caps:
		poly(kind, color, rings[0][0], - tangents[0])
		poly(kind, color, rings[count - 1][0], tangents[count - 1])



func lathe(kind: int, color: Color, origin: Vector3, axis: Vector3, profile: Array, sides: = 14) -> void :
	axis = axis.normalized()
	var helper: = Vector3.UP if absf(axis.dot(Vector3.UP)) < 0.9 else Vector3.RIGHT
	var side: = axis.cross(helper).normalized()
	var up: = axis.cross(side)
	for index in profile.size() - 1:
		var a: Vector2 = Vector2(profile[index][0], profile[index][1])
		var b: Vector2 = Vector2(profile[index + 1][0], profile[index + 1][1])

		var n2: = Vector2( - (b.y - a.y), b.x - a.x).normalized()
		for k in sides:
			var a0: = TAU * k / sides
			var a1: = TAU * (k + 1) / sides
			var d0: = side * cos(a0) + up * sin(a0)
			var d1: = side * cos(a1) + up * sin(a1)
			var p00: = origin + axis * a.x + d0 * a.y
			var p01: = origin + axis * a.x + d1 * a.y
			var p10: = origin + axis * b.x + d0 * b.y
			var p11: = origin + axis * b.x + d1 * b.y
			var n0: = (axis * n2.x + d0 * n2.y).normalized()
			var n1: = (axis * n2.x + d1 * n2.y).normalized()
			if b.y > 1e-05:
				_tri(kind, color, p00, p11, p10, n0, n1, n0)
			if a.y > 1e-05:
				_tri(kind, color, p00, p01, p11, n0, n1, n1)




func slab(kind: int, color: Color, origin: Vector3, u: Vector3, v: Vector3, outline: Array, thickness: float) -> void :
	var normal: = u.cross(v).normalized()
	var flat: = PackedVector2Array()
	for p: Variant in outline:
		flat.append(Vector2(p[0], p[1]))
	if Geometry2D.is_polygon_clockwise(flat):
		flat.reverse()
	var front: Array[Vector3] = []
	var back: Array[Vector3] = []
	for p in flat:
		var at_plane: = origin + u * p.x + v * p.y
		front.append(at_plane + normal * thickness / 2.0)
		back.append(at_plane - normal * thickness / 2.0)
	var indices: = Geometry2D.triangulate_polygon(flat)
	for index in range(0, indices.size(), 3):
		var i0: = indices[index]
		var i1: = indices[index + 1]
		var i2: = indices[index + 2]
		poly(kind, color, [front[i0], front[i1], front[i2]], normal)
		poly(kind, color, [back[i0], back[i1], back[i2]], - normal)
	for index in flat.size():
		var next: = (index + 1) % flat.size()
		var edge: = flat[next] - flat[index]
		var out: = u * edge.y - v * edge.x
		poly(kind, color, [front[index], back[index], back[next], front[next]], out)



func ball(kind: int, color: Color, middle: Vector3, radii: Vector3, sides: = 10, rings: = 6) -> void :
	for r in rings:
		var t0: = PI * r / rings
		var t1: = PI * (r + 1) / rings
		for k in sides:
			var a0: = TAU * k / sides
			var a1: = TAU * (k + 1) / sides
			var n00: = Vector3(sin(t0) * cos(a0), cos(t0), sin(t0) * sin(a0))
			var n01: = Vector3(sin(t0) * cos(a1), cos(t0), sin(t0) * sin(a1))
			var n10: = Vector3(sin(t1) * cos(a0), cos(t1), sin(t1) * sin(a0))
			var n11: = Vector3(sin(t1) * cos(a1), cos(t1), sin(t1) * sin(a1))
			var p: = func(n: Vector3) -> Vector3: return middle + n * radii
			var w: = func(n: Vector3) -> Vector3: return (n / radii).normalized()
			if r > 0:
				_tri(kind, color, p.call(n00), p.call(n01), p.call(n11), w.call(n00), w.call(n01), w.call(n11))
			if r < rings - 1:
				_tri(kind, color, p.call(n00), p.call(n11), p.call(n10), w.call(n00), w.call(n11), w.call(n10))



func ring(kind: int, color: Color, middle: Vector3, axis: Vector3, big: float, small: float, sides: = 16, from_angle: = 0.0, to_angle: = TAU) -> void :
	axis = axis.normalized()
	var helper: = Vector3.UP if absf(axis.dot(Vector3.UP)) < 0.9 else Vector3.RIGHT
	var side: = axis.cross(helper).normalized()
	var up: = axis.cross(side)
	var points: Array = []
	var closed: = is_equal_approx(to_angle - from_angle, TAU)
	var steps: = sides if closed else maxi(2, int(ceil(sides * (to_angle - from_angle) / TAU)))
	for k in steps + 1:
		var angle: = from_angle + (to_angle - from_angle) * k / steps
		points.append(middle + (side * cos(angle) + up * sin(angle)) * big)
	tube(kind, color, points, small, 6, not closed)



func commit() -> ArrayMesh:
	var mesh: = ArrayMesh.new()
	for kind: int in _parts:
		var part: Array = _parts[kind]
		var arrays: = []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = part[0]
		arrays[Mesh.ARRAY_NORMAL] = part[1]
		arrays[Mesh.ARRAY_COLOR] = part[2]
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, finish(kind))
	return mesh


func is_empty() -> bool:
	return _parts.is_empty()
