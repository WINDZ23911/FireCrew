class_name JobKitUse
extends CrewJob




var kit_name: = ""
var prompt: Prompt
var smoke_set: = false


func _init(job_kind: String, kit: String, at: Prompt, wear_set: = false) -> void :
	kind = job_kind
	kit_name = kit
	prompt = at
	smoke_set = wear_set


func place() -> Vector3:
	return prompt.global_position if is_instance_valid(prompt) else who.body.global_position


func run() -> bool:
	var held: = who.token()
	if not is_instance_valid(prompt) or not prompt.enabled:
		return fail("crew.say.nothingThere")
	if smoke_set and not await CrewWater.wear_set(who):
		who.say("crew.say.noSet", [], "warning")
	if not on(held):
		return false
	var have: = false
	if Cordon.RESCUE_KIT.has(kit_name):
		have = Cordon.current != null and Cordon.current.carries(who.body, kit_name)
		if not have and Cordon.current != null:
			var item: Dictionary = await CrewKit.take_cordon(who, kit_name, who.service.home_vehicle(who.commander()))
			have = not item.is_empty()
	else:
		have = await CrewKit.take_kit(who, kit_name)
	if not have:
		return fail("crew.say.noTool", [Text.named("tools", kit_name)]) if on(held) else false
	if not is_instance_valid(prompt) or not prompt.enabled:
		return true
	if smoke_set:
		CrewWater.breathe(who)
	if not await CrewKit.press_skilled(who, prompt):
		return fail("crew.say.cannot") if on(held) else false
	return true


func finish(_done: bool) -> void :
	CrewKit.put_kit_back(who)
	if Cordon.current != null and Cordon.RESCUE_KIT.has(kit_name):
		for item: Dictionary in Cordon.current.items:
			if item["holder"] == who.body and item["name"] == kit_name:
				Cordon.current.put_back(item)
