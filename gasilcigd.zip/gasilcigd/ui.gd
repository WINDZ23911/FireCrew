class_name Ui
extends RefCounted




const PANEL: = Color(18 / 255.0, 19 / 255.0, 22 / 255.0)
const INSET: = Color(48 / 255.0, 50 / 255.0, 56 / 255.0)
const TEXT: = Color(240 / 255.0, 242 / 255.0, 235 / 255.0)
const DIM: = Color(160 / 255.0, 165 / 255.0, 160 / 255.0)
const DARK: = Color(20 / 255.0, 22 / 255.0, 10 / 255.0)
const YELLOW: = Color(215 / 255.0, 1.0, 60 / 255.0)
const RED: = Color(226 / 255.0, 54 / 255.0, 40 / 255.0)
const AMBER: = Color(1.0, 190 / 255.0, 30 / 255.0)
const GREEN: = Color(90 / 255.0, 210 / 255.0, 110 / 255.0)
const BLUE: = Color(70 / 255.0, 160 / 255.0, 235 / 255.0)



const FIRE: = Color(1.0, 143 / 255.0, 26 / 255.0)


const ROUTES: = {"call": FIRE, "home": YELLOW, "waypoint": TEXT}
const MARGIN: = 24.0

const ICONS: Array[String] = [
	"flame", "drop", "heart", "house", "hydrant", 
	"helmet", "cylinder", "arrow", "warning", "check", 
	"coin", "crouch", "stand", "mask", "nozzle", 
	"truck", "shield", "pin", "ring", "dot", 
	"saw", "ladder", "car", "pump", "axe", 
	"halligan", "crowbar", "boltCutters", "spreader", "cutter", 
	"extinguisher", "floodlight", "fan", "camera", "cone", 
	"tape", 
]
const ICON_CELL: = 128
const ICON_COLUMNS: = 5


const HELMET_LIME: = Color(215 / 255.0, 1.0, 60 / 255.0)
const RANK_COLORS: = {
	"gasilec": HELMET_LIME, 
	"gasilec1": Color(0.98, 0.84, 0.22), 
	"vodjaSkupine": Color(0.95, 0.52, 0.14), 
	"vodjaOddelka": Color(0.9, 0.24, 0.2), 
	"vodnik": Color(0.3, 0.52, 0.92), 
	"podpoveljnik": Color(0.8, 0.82, 0.86), 
	"poveljnik": Color(0.97, 0.97, 0.95), 



	"helmetProbie": Color(0.95, 0.52, 0.14), 
	"helmet": Color(0.78, 0.8, 0.84), 
	"helmetEngineer": Color(0.78, 0.8, 0.84), 
	"helmetRed": Color(0.9, 0.24, 0.2), 
	"helmetCaptain": Color(0.9, 0.24, 0.2), 
	"helmetWhite": Color(0.97, 0.97, 0.95), 
	"helmetChief": Color(0.97, 0.97, 0.95), 


	"helmetAnwaerter": HELMET_LIME, 
	"helmetFeuerwehrmann": HELMET_LIME, 
	"helmetOberfeuerwehrmann": HELMET_LIME, 
	"helmetLoeschmeister": Color(0.9, 0.24, 0.2), 
	"helmetBrandmeister": Color(0.9, 0.24, 0.2), 
	"helmetHauptbrandmeister": Color(0.9, 0.24, 0.2), 
	"helmetKommandant": Color(0.9, 0.24, 0.2), 
}

static var _display: Font
static var _label: Font
static var _world_display: Font
static var _world_label: Font
static var _textures: Dictionary = {}



static func display_font() -> Font:
	if _display == null:
		_display = _font("res://assets/fonts/Oswald-Variable.ttf", ["Oswald", "Avenir Next Condensed", "DIN Condensed", "Arial Narrow"], 600)
	return _display



static func label_font() -> Font:
	if _label == null:
		_label = _font("res://assets/fonts/RobotoCondensed-Variable.ttf", ["Roboto Condensed", "Avenir Next Condensed", "Helvetica Neue", "Arial"], 700)
	return _label




static func world_display_font() -> Font:
	if _world_display == null:
		_world_display = _font("res://assets/fonts/Oswald-Variable.ttf", ["Oswald", "Avenir Next Condensed", "DIN Condensed", "Arial Narrow"], 600, true)
	return _world_display


static func world_label_font() -> Font:
	if _world_label == null:
		_world_label = _font("res://assets/fonts/RobotoCondensed-Variable.ttf", ["Roboto Condensed", "Avenir Next Condensed", "Helvetica Neue", "Arial"], 700, true)
	return _world_label


static func _font(path: String, families: Array, weight: int, distance_field: = false) -> Font:
	if ResourceLoader.exists(path):

		var base: FontFile = (load(path) as FontFile).duplicate() if distance_field else load(path)
		base.multichannel_signed_distance_field = distance_field
		base.msdf_pixel_range = 16
		var face: = FontVariation.new()
		face.base_font = base
		face.variation_opentype = {TextServerManager.get_primary_interface().name_to_tag("wght"): weight}
		return face
	var font: = SystemFont.new()
	font.font_names = PackedStringArray(families)
	font.font_weight = weight
	font.multichannel_signed_distance_field = distance_field
	return font


static func image(name: String) -> Texture2D:
	if not _textures.has(name):
		_textures[name] = load("res://assets/textures/hud/%s.png" % name)
	return _textures[name]



static func plate(size: Vector2, kind: = "panel") -> Control:
	var frame: = Control.new()
	frame.custom_minimum_size = size
	frame.size = size
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var art: = NinePatchRect.new()
	art.name = "Plate"
	art.texture = image(kind)
	art.patch_margin_left = 34
	art.patch_margin_top = 34
	art.patch_margin_right = 34
	art.patch_margin_bottom = 34
	art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	art.offset_left = -14
	art.offset_top = -14
	art.offset_right = 14
	art.offset_bottom = 14
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	art.show_behind_parent = true
	frame.add_child(art)
	return frame



static func stripe(parent: Control, width: float) -> TextureRect:
	var band: = TextureRect.new()
	band.texture = image("stripe")

	band.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	band.stretch_mode = TextureRect.STRETCH_SCALE
	band.position = Vector2(6, 0)
	band.size = Vector2(width, 5)
	band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(band)
	return band


static func icon_texture(name: String) -> AtlasTexture:
	var index: = ICONS.find(name)
	if index < 0:
		index = ICONS.find("dot")
	var atlas: = AtlasTexture.new()
	atlas.atlas = image("icons")
	atlas.region = Rect2((index % ICON_COLUMNS) * ICON_CELL, (index / ICON_COLUMNS) * ICON_CELL, ICON_CELL, ICON_CELL)
	return atlas


static func icon(name: String, size: float, color: = TEXT) -> TextureRect:
	var rect: = TextureRect.new()
	rect.texture = icon_texture(name)
	rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	rect.custom_minimum_size = Vector2(size, size)
	rect.size = Vector2(size, size)
	rect.modulate = color
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return rect



static func tile(name: String, color: Color, size: float) -> Panel:
	var panel: = Panel.new()
	var style: = StyleBoxFlat.new()
	style.bg_color = color.darkened(0.15)
	style.set_corner_radius_all(6)
	panel.add_theme_stylebox_override("panel", style)
	panel.custom_minimum_size = Vector2(size, size)
	panel.size = Vector2(size, size)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var picture: = icon(name, size * 0.68, Color.WHITE)
	picture.position = Vector2(size * 0.16, size * 0.16)
	panel.add_child(picture)
	return panel


static func label(text: = "", size: = 16, color: = TEXT, font: Font = null) -> Label:
	var made: = Label.new()
	made.text = text
	made.add_theme_font_override("font", font if font else label_font())
	made.add_theme_font_size_override("font_size", size)
	made.add_theme_color_override("font_color", color)
	made.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return made


static func display(text: = "", size: = 24, color: = TEXT) -> Label:
	return label(text, size, color, display_font())


static func caps(text: = "", size: = 14) -> Label:
	return label(text, size, DIM)



static func bar(size: Vector2, color: Color, segments: = 1) -> Control:
	var track: = NinePatchRect.new()
	track.texture = image("bar_track")
	track.patch_margin_left = 5
	track.patch_margin_right = 5
	track.patch_margin_top = 5
	track.patch_margin_bottom = 5
	track.custom_minimum_size = size
	track.size = size
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill: = ColorRect.new()
	fill.name = "Fill"
	fill.color = color
	fill.position = Vector2(2, 2)
	fill.size = Vector2(0, size.y - 4)
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	track.add_child(fill)
	for index in range(1, segments):
		var notch: = ColorRect.new()
		notch.color = Color(12 / 255.0, 13 / 255.0, 15 / 255.0)
		notch.position = Vector2(2 + (size.x - 4) * index / segments - 1, 2)
		notch.size = Vector2(2, size.y - 4)
		notch.mouse_filter = Control.MOUSE_FILTER_IGNORE
		track.add_child(notch)
	track.set_meta("share", 0.0)
	return track


static func set_bar(track: Control, share: float, color: Variant = null) -> void :
	share = clampf(share, 0.0, 1.0)
	var fill: ColorRect = track.get_node("Fill")
	fill.visible = share > 0.005
	fill.size.x = (track.size.x - 4) * share
	if color != null:
		fill.color = color



static func key(text: String) -> Control:
	var cap: = NinePatchRect.new()
	cap.texture = image("keycap")
	cap.patch_margin_left = 9
	cap.patch_margin_right = 9
	cap.patch_margin_top = 9
	cap.patch_margin_bottom = 11
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var letter: = label(text, 17, Color(28 / 255.0, 30 / 255.0, 34 / 255.0))
	letter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	letter.offset_top = -2
	letter.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	letter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	cap.add_child(letter)
	_fit_key(cap)
	return cap



static func _fit_key(cap: Control) -> void :
	var letter: = cap.get_child(0) as Label
	var words: = letter.get_theme_font("font").get_string_size(letter.text, HORIZONTAL_ALIGNMENT_LEFT, -1, letter.get_theme_font_size("font_size")).x
	cap.custom_minimum_size = Vector2(maxf(28, ceilf(words) + 18), 30)
	cap.size = cap.custom_minimum_size




static func action_key(action: String) -> Control:
	var cap: = key(Controls.key_name(action))
	cap.set_meta("action", action)
	cap.add_to_group("action_keys")
	return cap



static func say_action_keys(tree: SceneTree) -> void :
	for cap: Node in tree.get_nodes_in_group("action_keys"):
		var said: = Controls.key_name(String(cap.get_meta("action")))
		(cap.get_child(0) as Label).text = said
		_fit_key(cap as Control)






static var colour_blind: = false




static func state(color: Color) -> Color:
	if not colour_blind:
		return color
	var swaps: Dictionary = Config.Settings.ColourBlind
	if color.is_equal_approx(GREEN):
		return swaps["Good"]
	if color.is_equal_approx(AMBER):
		return swaps["Warn"]
	if color.is_equal_approx(RED):
		return swaps["Bad"]
	return color





static func thousands(number: float, code: = "") -> String:
	var mark: = "." if _language(code) in Text.COMMA else ","
	var whole: = int(floorf(absf(number)))
	var text: = str(whole)
	var out: = ""
	while text.length() > 3:
		out = mark + text.right(3) + out
		text = text.left(text.length() - 3)
	return ("-" if number <= -1.0 else "") + text + out



static func decimal(number: float, places: = 1, code: = "") -> String:
	var text: = ("%." + str(places) + "f") % number
	return text.replace(".", ",") if _language(code) in Text.COMMA else text




static func money(amount: float, signed: = false, code: = "") -> String:
	var sum: = thousands(absf(amount), code)
	var sign: = str(Edition.data().get("currency", "€"))
	var shown: = (sum + " " + sign) if _language(code) in Text.COMMA else (sign + sum)
	if amount < 0.0:
		return "−" + shown
	return ("+" + shown) if signed else shown


static func _language(code: String) -> String:
	return code if not code.is_empty() else Text.language



static func imperial() -> bool:
	return Edition.data().get("units", "metric") == "imperial"



static func length(metres_value: float) -> int:
	return int(round(metres_value * (3.28084 if imperial() else 1.0)))



static func speed(kmh: float) -> int:
	return int(round(kmh * (0.621371 if imperial() else 1.0)))



static func metres(studs: float) -> Array:
	var value: float = studs * Config.Hud.MetresPerStud
	if imperial():
		var feet: = value * 3.28084
		if feet >= 1000.0:
			return [decimal(feet / 5280.0, 1), "mi"]
		return [str(int(round(feet / 10.0) * 10)), "ft"]
	if value >= 1000.0:
		return [decimal(value / 1000.0, 1), "km"]
	return [str(int(value)), "m"]
