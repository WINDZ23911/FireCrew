class_name JobPump
extends CrewJob





func _init() -> void :
	kind = "portablePump"
	role = "pump"


func place() -> Vector3:
	return FloodedCellar.current.position if FloodedCellar.current != null else who.body.global_position


static func hatch() -> Dictionary:
	var cellar: = FloodedCellar.current
	if cellar == null or cellar.source.is_empty():
		return {}
	return cellar._hatch


func run() -> bool:
	var at: = hatch()
	if at.is_empty():
		return fail("crew.say.nothingThere")
	var held: = who.token()
	if at["power"]:
		return fail("crew.say.powerFirst")
	if not await CrewKit.take_kit(who, "Portable pump"):
		return fail("crew.say.noTool", [Text.named("tools", "Portable pump")]) if on(held) else false
	if not on(held):
		return false
	if at["power"] or at["over"]:
		return fail("crew.say.powerFirst")
	if not await CrewKit.press_skilled(who, at["pump_prompt"]):
		return fail("crew.say.cannot") if on(held) else false
	if who.body.get_attr("Discharge") == null:
		return fail("crew.say.cannot")

	if not await who.press(at["drain_prompt"]):
		return fail("crew.say.stuck") if on(held) else false
	return who.body.get_attr("Discharge") == null


func finish(_done: bool) -> void :
	CrewKit.put_kit_back(who)
