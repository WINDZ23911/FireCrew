class_name LockerLine
extends RefCounted




signal chosen(player: Player)

var action: Variant = ""
var object: Variant = ""
var category: = "other"
var icon: = ""
var locker: = ""
var order: = 0
var holder: Player = null


var tint: = ""
