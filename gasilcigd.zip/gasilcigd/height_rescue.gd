class_name HeightRescue
extends Node

















const TICK: = 0.25
const STREET_REACH: = 42.0
const MIN_ROOF: = 14.0
const EDGE_ROOM: = 3.0
const BOARD_REACH: = 12.0
const BOARD_RISE: = 8.0
const BOARD_TIME: = 2.0
const PLAYER_ROOM: = 60.0
const TRIES: = 20
const THANKS: = 8.0
const DOWN_SLOPE: = 0.55

const CAT_COATS: Array[Color] = [
	Color8(222, 140, 70), Color8(60, 58, 60), Color8(150, 150, 154), Color8(240, 236, 226), Color8(120, 90, 66), 
]

static var current: HeightRescue


static func settings() -> Dictionary:
	return Config.Incidents.Rescue

var kind: = "rescue"
var stranded: Dictionary = {}

var pretend_near: = false
var pretend_stowed: = false


var _roofs: Array = []
var _branches: Array = []
var _serial: = 0
var _shown: Array = []
var _mirrors: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null







func _roof_place(layout: Dictionary, building: Building, size: Vector3) -> Dictionary:
	var best: = {}
	for edge: Array in [[0, -1], [0, 1], [-1, 0], [1, 0]]:
		var out: = Vector3(edge[0], 0, edge[1])
		var at: = Vector3(edge[0] * (size.x / 2.0 - EDGE_ROOM), building.height, edge[1] * (size.z / 2.0 - EDGE_ROOM))
		var world: = building.place * at
		var nearest: Dictionary = Roads.nearest(layout, world.x, world.z)[0]
		if not nearest.is_empty() and nearest["distance"] <= STREET_REACH and (best.is_empty() or nearest["distance"] < best["distance"]):
			var facing: = building.place.basis * out

			best = {"distance": nearest["distance"], "feet": Rbx.look_at(world, world + facing), "span": (size.x if edge[0] == 0 else size.z) / 2.0 - EDGE_ROOM - 2.0}
	return best



static func _slope_point(building: Building, slope: float, x: float) -> Vector3:
	var pitch: = building.pitch
	var place: Transform3D = pitch["place"]
	return place * Vector3(x, building.height + float(pitch["rise"]) * (1.0 - DOWN_SLOPE), slope * float(pitch["run"]) * DOWN_SLOPE)


func _find_places(layout: Dictionary, buildings: Array) -> void :
	for building: Building in buildings:
		if building is House or building.record.is_empty():
			continue
		var row: int = Game.store.row_of.get(int(building.record.get("body", 0)), -1)
		if building.roof == "flat" and building.height >= MIN_ROOF and row >= 0:
			var place: = _roof_place(layout, building, Game.store.size(row))
			if not place.is_empty():
				_roofs.append({"building": building, "feet": place["feet"], "span": place["span"]})
		elif not building.pitch.is_empty() and float(building.pitch["half"]) > 5.0:

			var best: = 0.0
			var best_distance: = INF
			for slope: float in [-1.0, 1.0]:
				var point: = _slope_point(building, slope, 0.0)
				var nearest: Dictionary = Roads.nearest(layout, point.x, point.z)[0]
				if point.y >= MIN_ROOF and not nearest.is_empty() and nearest["distance"] <= STREET_REACH and nearest["distance"] < best_distance:
					best = slope
					best_distance = nearest["distance"]
			if best != 0.0:
				_roofs.append({"building": building, "slope": best})
	var trees: Array = layout["trees"]
	for index in trees.size():
		var tree: Dictionary = trees[index]
		if tree["kind"] != "broadleaf":
			continue
		var found: = Roads.nearest(layout, tree["x"], tree["z"])
		var nearest: Dictionary = found[0]
		if not nearest.is_empty() and nearest["distance"] <= STREET_REACH and nearest["distance"] > float(found[1]["width"]) / 2.0 + 4.0:
			_branches.append({
				"index": index, 
				"base": Vector3(tree["x"], 0, tree["z"]), 
				"toward": Vector3(nearest["x"] - tree["x"], 0, nearest["z"] - tree["z"]).normalized(), 
				"name": Roads.name_of(found[1]), 
			})







func _person(roof: Dictionary) -> Dictionary:
	var building: Building = roof["building"]
	var own: = CallKit.rows_of(building.model)
	var world: = Game.world
	var feet: Transform3D
	var floor_y: = 0.0
	var board: Variant = null
	if roof.has("slope"):

		var pitch: = building.pitch
		var half: float = pitch["half"]
		var place: Transform3D = pitch["place"]
		var found: = false
		for attempt in 10:
			var point: = _slope_point(building, roof["slope"], randf_range( - (half - 3.0), half - 3.0))
			var hit: = world.raycast(point + Vector3(0, 10, 0), point + Vector3(0, -10, 0), World.LAYER_SOLID)
			if not hit.is_empty() and own.has(world.row_hit(hit)) and world.name_hit(hit) == "Roof":
				var at: Vector3 = hit["position"]
				var out: = place.basis * Vector3(0, 0, roof["slope"])
				floor_y = at.y + 0.3
				feet = Rbx.look_at(at, at + out)
				board = Transform3D(feet.basis, Vector3(at.x, floor_y - 1.2, at.z))
				found = true
				break
		if not found:
			return {}
	else:
		var edge: Transform3D = roof["feet"]
		feet = edge * Transform3D(Basis.IDENTITY, Vector3(randf_range( - roof["span"], roof["span"]), 0, 0))

		var hit: = world.raycast(feet.origin + Vector3(0, 8, 0), feet.origin + Vector3(0, -6, 0), World.LAYER_SOLID)
		floor_y = hit["position"].y if not hit.is_empty() else feet.origin.y
	var made: = _make_person({"who": "roof", "seed": randi_range(1, 1000000), "board": board, "place": Transform3D(feet.basis, Vector3(feet.origin.x, floor_y + Figure.ROOT_HEIGHT, feet.origin.z))})
	made["name"] = Text.join([Text.m("calls.rescue.roof.title"), Text.m("calls.separator"), CallKit.building_name(building)])
	return made





static func _roof_ladder(model: Node3D, under: Transform3D) -> void :
	var feet: = under * Transform3D(Basis.IDENTITY, Vector3(0, 1.15, 0))
	var down: = - feet.basis.z

	var length: = 9.0
	var rails: = Color8(196, 200, 206)
	var holder: = Node3D.new()
	holder.name = "RoofLadder"
	model.add_child(holder)
	var top: = feet.origin - down * length * 0.55
	var bottom: = feet.origin + down * length * 0.45
	for end: Array in [[top, -1.0], [bottom, 1.0]]:
		var hit: = Game.world.raycast(end[0] + Vector3(0, 6, 0), end[0] + Vector3(0, -6, 0), World.LAYER_SOLID) if Game.world != null else {}
		if not hit.is_empty():
			if end[1] < 0.0:
				top = hit["position"] + Vector3(0, 0.12, 0)
			else:
				bottom = hit["position"] + Vector3(0, 0.12, 0)
	var along: = (bottom - top)
	var place: = Rbx.look_at((top + bottom) / 2.0, bottom)
	for side: float in [-0.7, 0.7]:
		CallKit.piece(holder, CallKit.BLOCK, Vector3(0.14, 0.2, along.length()), place * Transform3D(Basis.IDENTITY, Vector3(side, 0, 0)), rails)
	var rungs: = int(along.length() / 0.9)
	for rung in rungs:
		var z: = - along.length() / 2.0 + 0.45 + rung * 0.9
		CallKit.piece(holder, CallKit.CYLINDER, Vector3(1.4, 0.1, 0.1), place * Transform3D(Basis.IDENTITY, Vector3(0, 0.05, z)), rails)

	for side: float in [-0.7, 0.7]:
		CallKit.piece(holder, CallKit.BLOCK, Vector3(0.14, 0.7, 0.14), place * Transform3D(Basis.IDENTITY, Vector3(side, 0.3, - along.length() / 2.0 - 0.05)), rails)




func _make_person(params: Dictionary) -> Dictionary:
	var model: = CallKit.model("Stranded")
	if params["board"] != null:
		_roof_ladder(model, params["board"])
	var figure: = Figure.build(params["seed"])
	figure.name = "Stranded"
	model.add_child(figure)
	figure.pose("wave")
	figure.global_transform = params["place"]
	return {
		"params": params, 
		"model": model, 
		"root": figure, 
		"rise": Figure.ROOT_HEIGHT, 
		"figure": figure, 
		"name": "", 
		"words": "calls.rescue.roof", 
		"who": Text.m("calls.markers.help"), 
		"cry": null, 
	}




func _cat(branch: Dictionary, standing: int, coat_drawn: = -1) -> Dictionary:
	var store: = Game.store
	if coat_drawn < 0:
		coat_drawn = randi() % CAT_COATS.size()
	var trunk: = store.find_row(standing, "Trunk")
	var leaves: = store.find_row(standing, "Leaves")
	if trunk < 0 or leaves < 0:
		return {}
	var toward: Vector3 = branch["toward"]
	var base: Vector3 = branch["base"]
	var reach: = store.size(leaves).x / 2.0 + 1.5
	var height: = store.position(leaves).y - 1.0
	var tip: = base + toward * reach + Vector3(0, height, 0)

	var model: = CallKit.model("StrandedCat")
	var along: = Rbx.look_at(base + Vector3(0, height - 0.45, 0), tip - Vector3(0, 0.45, 0))
	CallKit.part(model, CallKit.CYLINDER, Vector3(reach, 0.9, 0.9), along * Transform3D(Basis(Vector3.UP, PI / 2), Vector3(0, 0, - reach / 2.0)), store.color(trunk), "Wood", false, 0.0, "Bough")


	var coat: = CAT_COATS[coat_drawn]
	var root: = Node3D.new()
	root.name = "Cat"
	model.add_child(root)
	root.global_transform = Rbx.look_at(tip + Vector3(0, 0.6, 0) - toward * 1.2, tip + Vector3(0, 0.6, 0))
	var fur: = func(size: Vector3, place: Transform3D, shape: = CallKit.BLOCK) -> void :
		CallKit.piece(root, shape, size, place, coat)
	fur.call(Vector3(0.8, 0.9, 1.6), Transform3D(Basis.IDENTITY, Vector3(0, -0.1, 0)))
	fur.call(Vector3(0.8, 0.75, 0.7), Transform3D(Basis.IDENTITY, Vector3(0, 0.55, -0.85)))
	for side: float in [-1.0, 1.0]:
		fur.call(Vector3(0.22, 0.3, 0.16), Transform3D(Basis.IDENTITY, Vector3(side * 0.26, 1.05, -0.8)))
		fur.call(Vector3(0.24, 0.5, 0.3), Transform3D(Basis.IDENTITY, Vector3(side * 0.25, -0.5, -0.65)))
	fur.call(Vector3(1.2, 0.2, 0.2), Transform3D(Basis(Vector3.BACK, deg_to_rad(60)), Vector3(0, 0.5, 1.0)), CallKit.CYLINDER)
	return {
		"params": {"who": "cat", "index": branch["index"], "coat": coat_drawn}, 
		"model": model, 
		"root": root, 
		"rise": 0.6, 
		"figure": null, 
		"name": Text.join([Text.m("calls.rescue.cat.title"), Text.m("calls.separator"), branch["name"]]), 
		"words": "calls.rescue.cat", 
		"who": Text.m("calls.markers.cat"), 
		"cry": Config.Incidents.Rescue.MeowSoundId, 
	}





func available() -> bool:
	return LadderService.current != null and _roofs.size() + _branches.size() > 0


func run() -> bool:

	stranded = {}
	var wanted: Variant = Config.Incidents.Rescue.get("Who")
	for attempt in TRIES:
		var roof_turn: = not _roofs.is_empty() and (_branches.is_empty() or randf() < 0.65)
		if wanted is String:
			roof_turn = wanted == "roof" and not _roofs.is_empty()
		if roof_turn:
			var roof: Dictionary = _roofs[randi() % _roofs.size()]
			var building: Building = roof["building"]
			if not building.ruined and not CallKit.player_near(building.position, PLAYER_ROOM):
				stranded = _person(roof)
		elif not _branches.is_empty():
			var branch: Dictionary = _branches[randi() % _branches.size()]
			var standing: = CallKit.tree_model(branch["index"])
			if standing != 0 and not CallKit.player_near(branch["base"], PLAYER_ROOM):
				stranded = _cat(branch, standing)
		if not stranded.is_empty():
			break
	if stranded.is_empty():
		return false

	var root: Node3D = stranded["root"]
	var words: String = stranded["words"]
	var rise: float = stranded["rise"]
	var figure: Figure = stranded["figure"]

	_serial += 1
	var call_serial: = _serial
	_attend(stranded, _serial)
	_shown.append(stranded)
	var marker: CallMarker = stranded["marker"]
	CallService.current.publish("rescue", stranded["name"], root.global_position, 2)
	Alarm.par(float(Alarm.settings()["Grade"]["Job"]["rescue"]["Base"]))
	Game.notify(Text.f("calls.rescue.alarm", [stranded["name"]]))
	Game.notify(Text.m("calls.rescue.briefGrip"))

	var times: Array = settings()["GripTimes"]
	var grip_drain: = 100.0 / randf_range(float(times[0]), float(times[1]))
	var panic: = Alarm.complicated("rescue", "panic")
	if Alarm.complicated("rescue", "wind"):
		grip_drain *= float(settings()["WindFactor"])
		Game.notify(Text.m("calls.rescue.wind"), "warning")
	if panic:
		grip_drain *= float(settings()["PanicFactor"])
		Game.notify(Text.m("calls.rescue.panic"), "warning")
	Escalation.begin_other(["gutter"])


	var led: Array = [null]
	var prompt: Prompt = stranded["prompt"]
	prompt.triggered.connect( func(player: Player) -> void : led[0] = player)

	var harness_prompt: Prompt = stranded["harness_prompt"]
	harness_prompt.triggered.connect( func(player: Player) -> void :
		if stranded.get("aboard", false) and not stranded.get("harness", false):
			stranded["harness"] = true
			harness_prompt.enabled = false
			Game.notify(Text.m("calls.rescue.harness.on"), "good", player)
	)

	var waited: = 0.0
	var near: = 0.0
	var next_cry: = 0.0
	var aboard: = false
	var down: = false
	var fell: = false
	var raised: = false
	var slipping_told: = false
	while not down and not fell and not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK

		if stranded["cry"] != null and not aboard and waited >= next_cry:
			var pitch: = randf_range(0.9, 1.15)
			Sounds.once(root, stranded["cry"], 1.0, 12.0, 160.0, pitch)
			Net.broadcast("rescue.cry", [call_serial, pitch])
			var every: Vector2 = Config.Incidents.Rescue.MeowEvery
			next_cry = waited + randf_range(every.x, every.y)

		if Escalation.due() == "gutter" and not aboard:
			var gutter: Dictionary = Config.Alarm.Escalations.rescue
			stranded["grip"] = maxf(float(stranded["grip"]) - float(gutter["Drop"]), 1.0)
			grip_drain *= float(gutter["Factor"])
		if not aboard and Alarm.arrived_at >= 0.0:
			var feet_at: = root.global_position - Vector3(0, rise, 0)
			var drain: = grip_drain
			if CallKit.player_near(feet_at, float(settings()["ReassureReach"])):
				drain *= float(settings()["ReassureFactor"])
			stranded["grip"] = maxf(float(stranded["grip"]) - drain * TICK, 0.0)
			_show_grip(stranded)
			if stranded["grip"] <= float(settings()["SlipAt"]) and not slipping_told:
				slipping_told = true
				Game.notify(Text.m(words + ".slipping"), "danger")
			if stranded["grip"] <= 0.0:
				fell = true
				break
		var grip_left: = ceili(float(stranded["grip"]))
		if aboard:
			CallService.current.next_step(Text.m("calls.rescue.next.stow") if stranded.get("harness", false) or stranded["cry"] != null else Text.m("calls.rescue.next.harness"))
		else:
			CallService.current.next_step(Text.join([Text.f("calls.rescue.next.reach", [Text.m(words + ".what")]), Text.m("calls.separator"), Text.f("calls.rescue.grip", [grip_left])]))
		var ladder: = LadderService.current

		if aboard and not stranded.get("harness", false) and stranded["cry"] == null and ladder != null and is_instance_valid(ladder._perch_rider):
			stranded["harness_time"] = float(stranded.get("harness_time", 0.0)) + TICK
			if float(stranded["harness_time"]) >= float(settings()["HarnessHold"]):
				harness_prompt.triggered.emit(ladder._perch_rider)
		if ladder == null:
			if led[0] != null:
				Game.notify(Text.m("calls.rescue.needLadder"), "", led[0])
				led[0] = null
			continue
		if not aboard:
			var feet: = root.global_position - Vector3(0, rise, 0)
			var offset: = ladder.basket_position() - feet
			var level: = Vector3(offset.x, 0, offset.z).length()

			var close: = pretend_near or (level <= BOARD_REACH and absf(offset.y) <= BOARD_RISE and not panic)
			near = near + TICK if close else 0.0
			var shown: bool = led[0] != null and level <= float(settings()["LeadReach"]) and absf(offset.y) <= float(settings()["LeadRise"])
			if led[0] != null and not shown:
				Game.notify(Text.m("calls.rescue.tooFar"), "", led[0])
			led[0] = null
			if near >= BOARD_TIME or shown:

				aboard = true
				stranded["aboard"] = true
				ladder.take_aboard(root, rise)
				if figure:
					figure.pose("stand")
				marker.visible = false
				prompt.enabled = false

				harness_prompt.enabled = stranded["cry"] == null
				_show_grip(stranded)
				CallService.current.progress(1)
				Game.notify(Text.f("calls.rescue.aboard", [Text.m(words + ".aboard")]))
		else:

			raised = raised or not ladder.is_stowed()
			if (raised and ladder.is_stowed()) or pretend_stowed:
				down = true

	var ladder: = LadderService.current
	var let_down: = false
	if down and ladder != null:
		Alarm.done()

		if stranded["cry"] == null:
			Alarm.check("harness", stranded.get("harness", false))

		ladder.set_down(root, rise)
		stranded["aboard"] = false
		if figure:
			figure.pose("wave")
		CallService.current.progress(2)
		var reward: = int(Config.Incidents.Rescue.Reward)
		CallKit.pay_helpers(CallKit.crew_near(ladder.vehicle.global_position, float(Config.Incidents.Rescue.Range)), reward, "", "bonus")
		Game.notify(Text.f("calls.rescue.thanks", [Text.m(words + ".thanks"), Alarm.pay(reward)]), "good")
	elif fell:
		_fall(stranded)
		Game.notify(Text.f("calls.rescue.closed", [stranded["name"], Text.m(words + ".fell")]), "danger")
	else:
		Game.notify(Text.f("calls.rescue.closed", [stranded["name"], Text.m(words + ".closed")]), "warning")
		if aboard and ladder != null and ladder.is_aboard(root):

			ladder.set_down(root, rise)
			let_down = true

	marker.queue_free()
	prompt.enabled = false
	harness_prompt.enabled = false
	stranded["over"] = true
	Escalation.reset()
	Game.incident.erase("next")

	await CallService.current.settle()
	CallService.current.clear( not down)
	var model: Node3D = stranded["model"]
	var who: = root
	stranded = {}
	get_tree().create_timer(THANKS if down or fell or let_down else 0.05, false).timeout.connect( func() -> void :
		if is_instance_valid(who):
			who.queue_free()
		if is_instance_valid(model):
			model.queue_free()
	)
	return true



static func _show_grip(held: Dictionary) -> void :
	var bar: Variant = held.get("bar")
	if not is_instance_valid(bar):
		return
	var share: = float(held["grip"]) / 100.0
	CallKit.set_bar(bar, share, Color8(90, 210, 110) if share > 0.5 else (Color8(255, 190, 30) if share > 0.3 else Color8(226, 54, 40)))
	bar.visible = not held.get("aboard", false) and not held.get("over", false)



static func _fall(held: Dictionary) -> void :
	var root: Node3D = held["root"]
	if not is_instance_valid(root):
		return
	var feet: = root.global_position
	var away: = - root.global_basis.z * Vector3(1, 0, 1)
	away = away.normalized() * 2.5 if away.length() > 0.1 else Vector3(2.5, 0, 0)
	var ground: = CallKit.ground_at(feet + away + Vector3(0, -2, 0)) if Game.world != null else feet
	var hit: = Game.world.raycast(feet + away, feet + away + Vector3(0, -80, 0), World.LAYER_SOLID)
	if not hit.is_empty():
		ground = hit["position"]
	if held["figure"] != null:
		held["figure"].pose("lying")
		root.global_transform = Figure.lying(ground, away.normalized())
	else:
		root.global_position = ground + Vector3(0, held["rise"], 0)
	held["grip"] = 0.0
	_show_grip(held)



func start(layout: Dictionary, buildings: Array) -> void :
	_find_places(layout, buildings)
	Net.share("call.rescue", _net_state, _net_apply, 10.0)
	Net.stopped.connect( func() -> void : _net_apply([], true))
	Net.handle("rescue.cry", func(serial: int, pitch: float) -> void :
		var held: Dictionary = _mirrors.get(serial, {})
		if not held.is_empty() and held["cry"] != null and is_instance_valid(held["root"]):
			Sounds.once(held["root"], held["cry"], 1.0, 12.0, 160.0, pitch)
	)




func _attend(held: Dictionary, serial: int) -> void :
	var root: Node3D = held["root"]
	var words: String = held["words"]
	held["serial"] = serial
	held["aboard"] = false
	held["over"] = false
	held["marker"] = CallMarker.make(root.global_position + Vector3(0, 6, 0), held["who"], Color8(226, 150, 30))
	held["marker"].own = true
	held["prompt"] = CallKit.prompt(root, "rescue.%d.lead" % serial, Text.m(words + ".lead"), Text.m(words + ".what"), 0.5, 10.0)
	held["harness_prompt"] = CallKit.prompt(root, "rescue.%d.harness" % serial, Text.m("calls.rescue.harness.action"), Text.m(words + ".what"), float(settings()["HarnessHold"]), 8.0)
	held["harness_prompt"].enabled = false
	held["grip"] = 100.0
	held["bar"] = CallKit.bar(root, 3.4, Color8(90, 210, 110), 90.0)







func _net_state() -> Variant:
	var list: Array = []
	for held: Dictionary in _shown.duplicate():
		var root: Variant = held["root"]
		if not CallKit.there(root) or not CallKit.there(held["model"]):
			_shown.erase(held)
			continue
		list.append({
			"serial": held["serial"], "params": held["params"], "aboard": held["aboard"], "place": root.global_transform, 
			"pose": held["figure"].pose_name if held["figure"] != null else "", 
			"marked": CallKit.there(held["marker"]) and held["marker"].visible, "over": held["over"], 
			"grip": snappedf(float(held.get("grip", 100.0)), 0.5), "harness": held.get("harness", false), 
		})
	return list




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array or (leaving and _mirrors.is_empty()):
		return
	var told: = {}
	for state: Dictionary in list:
		var serial: int = state["serial"]
		told[serial] = true
		var held: Dictionary = _mirrors.get(serial, {})
		if held.is_empty():
			var params: Dictionary = state["params"]
			if params["who"] == "cat":
				for branch: Dictionary in _branches:
					if branch["index"] == params["index"]:
						held = _cat(branch, CallKit.tree_model(params["index"]), params["coat"])
			else:
				held = _make_person(params)
			if held.is_empty():
				continue
			_attend(held, serial)
			_mirrors[serial] = held
		var root: Node3D = held["root"]
		if not is_instance_valid(root):
			continue

		var ladder: = LadderService.current
		if state["aboard"] != held["aboard"] and ladder != null:
			held["aboard"] = state["aboard"]
			if held["aboard"]:
				root.reparent(ladder.floor_node, false)
				root.transform = Transform3D(Basis.IDENTITY, Vector3(0, held["rise"], 0.4))
			elif is_instance_valid(held["model"]):
				root.reparent(held["model"], false)
		if not held["aboard"]:
			root.global_transform = state["place"]
		var figure: Figure = held["figure"]
		if figure != null and figure.pose_name != state["pose"]:
			figure.pose(state["pose"])
		if is_instance_valid(held["marker"]):
			held["marker"].visible = state["marked"]
		held["grip"] = state["grip"]
		held["harness"] = state["harness"]
		_show_grip(held)
		if state["over"] and not held["over"]:
			held["over"] = true
			held["prompt"].enabled = false
			if is_instance_valid(held["marker"]):
				held["marker"].queue_free()
	for serial: int in _mirrors.keys():
		if not told.has(serial):
			var gone: Dictionary = _mirrors[serial]
			_mirrors.erase(serial)
			for node: Variant in [gone["root"], gone["model"], gone["marker"]]:
				if is_instance_valid(node):
					node.queue_free()
