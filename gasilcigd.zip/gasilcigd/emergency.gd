class_name Emergency
extends RefCounted




static var _others: Dictionary = {}



static var _moved: Dictionary = {}




static func watch(model: Node3D, on: bool) -> void :
	if on:
		_others[model] = true
	else:
		_others.erase(model)



static func sirens() -> Array:
	var list: Array = []
	var models: Array = []
	models.append_array(Vehicle.all)
	for model: Variant in _others.keys():
		if is_instance_valid(model):
			models.append(model)
		else:
			_others.erase(model)
	var moving: float = Config.Life.SirenMoving
	var linger: = int(float(Config.Life.get("SirenLinger", 0.0)) * 1000.0)
	var clock: = Time.get_ticks_msec()
	for model: Node3D in models:
		var siren: Variant = model.get("siren")
		if not model.is_inside_tree() or siren == null or float(siren) <= 0.0:
			_moved.erase(model)
			continue
		var velocity: Variant = model.get("linear_velocity")
		if not velocity is Vector3:
			continue
		var speed: = sqrt(velocity.x * velocity.x + velocity.z * velocity.z)
		var position: = model.global_position
		if speed > moving:
			var dx: float = velocity.x / speed
			var dz: float = velocity.z / speed
			_moved[model] = [clock, dx, dz]
			list.append({"x": position.x, "z": position.z, "dx": dx, "dz": dz, "speed": speed})
		elif _moved.has(model):
			var last: Array = _moved[model]
			if clock - int(last[0]) <= linger:
				list.append({"x": position.x, "z": position.z, "dx": last[1], "dz": last[2], "speed": moving})
			else:
				_moved.erase(model)
	return list



static func nearest(list: Array, x: float, z: float) -> Dictionary:
	var best: Dictionary = {}
	var gap: = INF
	for siren: Dictionary in list:
		var far: float = (x - siren["x"]) ** 2 + (z - siren["z"]) ** 2
		if far < gap:
			gap = far
			best = siren
	return best




static func near(list: Array, x: float, z: float, reach: float, passed: = -1.0) -> bool:
	for siren: Dictionary in list:
		var rx: float = x - siren["x"]
		var rz: float = z - siren["z"]
		if rx * rx + rz * rz < reach * reach and (passed < 0.0 or rx * siren["dx"] + rz * siren["dz"] > - passed):
			return true
	return false
