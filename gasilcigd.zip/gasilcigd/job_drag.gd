class_name JobDrag
extends CrewJob



var piece_only: Variant = null


func _init(piece: Variant = null) -> void :
	kind = "drag"
	piece_only = piece


func place() -> Vector3:
	return FallenTree.current.position_of_call


func _next(tree: FallenTree) -> Dictionary:
	if piece_only is Dictionary:
		return piece_only if not piece_only.get("cleared", false) and piece_only["free"] else {}
	var best: Dictionary = {}
	var best_distance: = INF
	for piece: Dictionary in tree.scene.get("pieces", []):
		if piece["butt"] or not piece["free"] or piece.get("cleared", false):
			continue
		var holders: Dictionary = piece["holders"]
		var wanted: = 2 if piece["heavy"] else 1
		if holders.size() >= wanted:
			continue
		var distance: float = piece["log"].global_position.distance_to(who.body.global_position)
		if distance < best_distance:
			best_distance = distance
			best = piece
	return best


func run() -> bool:
	var tree: = FallenTree.current
	if tree == null or tree.scene.is_empty():
		return fail("crew.say.nothingThere")
	CrewKit.free_hands(who)
	var held: = who.token()
	var dragged: = 0
	var idle_since: = Game.now()
	while on(held):
		if tree.scene.is_empty():
			return true
		var piece: = _next(tree)
		if piece.is_empty():
			if piece_only != null:
				return piece_only.get("cleared", false)

			if _left(tree) == 0:
				return true
			if Game.now() - idle_since > 45.0:
				return dragged > 0
			if not await who.wait(1.0, held):
				return false
			continue
		idle_since = Game.now()

		var taken_side: = 0.0
		for holder: Player in piece["holders"]:
			taken_side = piece["holders"][holder]["side"]
		var index: = 0 if taken_side > 0.0 else (1 if taken_side < 0.0 else _nearest_grip(piece))
		var prompt: Prompt = piece["prompts"][index]
		if not await who.press(prompt):
			return fail("crew.say.stuck")
		if not piece["holders"].has(who.body):
			continue

		var log_at: Vector3 = piece["log"].global_position
		var on_road: Dictionary = Roads.on_road(piece["road"], log_at.x, log_at.z)
		var away: = Vector3(log_at.x - on_road["x"], 0, log_at.z - on_road["z"])
		if away.length() < 0.5:
			var run_dir: Array = Roads.at(piece["road"], on_road["along"])
			away = Vector3( - run_dir[3], 0, run_dir[2])
		away = away.normalized()
		var needed: float = piece["half"] + 0.5 + piece["length"] * 0.25 + (12.0 if piece["crown"] else 0.0) + 8.0
		var road_point: = Vector3(on_road["x"], log_at.y, on_road["z"])
		var target: = who.service.ground(road_point + away * (needed + piece["length"] * 0.5) + Vector3(0, 2, 0))
		var started: = Game.now()
		while on(held) and not piece.get("cleared", false) and Game.now() - started < 60.0:
			if await who.go(target, 2.0, 25.0):
				break
		await who.wait(0.6, held)
		if piece["holders"].has(who.body):
			tree.release(piece, who.body)
		if piece.get("cleared", false):
			dragged += 1
		elif not on(held):
			return false
		if piece_only != null:
			return piece.get("cleared", false)
	return false



func _left(tree: FallenTree) -> int:
	var left: = 0
	for piece: Dictionary in tree.scene.get("pieces", []):
		if not piece["butt"] and not piece.get("cleared", false):
			left += 1
	return left


func _nearest_grip(piece: Dictionary) -> int:
	var grips: Array = piece["grips"]
	if grips.size() < 2:
		return 0
	return 0 if grips[0].global_position.distance_to(who.body.global_position) <= grips[1].global_position.distance_to(who.body.global_position) else 1


func finish(_done: bool) -> void :
	var tree: = FallenTree.current
	if tree and tree._dragging.has(who.body):
		tree.release(tree._dragging[who.body], who.body)
