class_name Smoulder
extends Node3D




const LASTS: = 9.0
const POOF: = {
	"Color": Color(0.95, 0.96, 0.97), "Speed": [5, 9], "Lifetime": [0.7, 1.1], "SpreadAngle": 80, 
	"Direction": Vector3.UP, "Acceleration": Vector3(0, 3, 0) + World.WIND * 2.0, "Drag": 2.2, 
	"Rotation": [0, 360], "Size": [[0.0, 0.8], [0.3, 2.4], [1.0, 0.0]], "Sphere": 0.8, 
}

var _wisp: RbxEmitter
var _born: = 0.0


static func at(position: Vector3) -> void :
	if Game.world == null or not Game.world.is_inside_tree():
		return
	var made: = Smoulder.new()
	Game.world.add_child(made)
	made.global_position = position


func _ready() -> void :
	_born = Game.now()
	var poof: = POOF.duplicate()
	poof["Mesh"] = ToonFire.puff_mesh()
	poof["Material"] = ToonFire.puff_material(true)
	RbxEmitter.burst(self, poof, 14)
	Sounds.once_at(global_position, "fire_sizzle", 0.9, 12.0, 180.0, randf_range(0.92, 1.08))
	_wisp = ToonFire.puffs(self, {
		"Color": Color(0.72, 0.72, 0.74), "Speed": [2, 3.5], "Lifetime": [2.0, 3.0], "SpreadAngle": 10, 
		"Direction": Vector3.UP, "Acceleration": Vector3(0, 0.8, 0) + World.WIND * 1.4, "Rotation": [0, 360], 
		"Size": [[0.0, 0.4], [0.4, 1.1], [1.0, 0.0]], "Rate": 3, "MaxRate": 3, 
	}, true)


func _process(_delta: float) -> void :
	var age: = Game.now() - _born
	var left: = 1.0 - age / LASTS
	if left <= 0.0:
		_wisp.set_rate(0.0)
		if age > LASTS + 4.0:
			queue_free()
		return
	_wisp.set_rate(3.0 * left)
