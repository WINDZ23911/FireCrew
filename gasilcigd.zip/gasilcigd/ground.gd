class_name Ground
extends MeshInstance3D




const LOW: = -1400.0
const SIZE: = 3000.0
static var COLOR_MAP: = Edition.path("world/ground_color.png", "res://data/world/ground_color.png")
static var KIND_MAP: = Edition.path("world/ground_kind.png", "res://data/world/ground_kind.png")

static var top: = - INF
static var current: Ground
static var _kinds: Image
static var _noise_texture: NoiseTexture2D


static func painted() -> bool:
	return ResourceLoader.exists(COLOR_MAP) and ResourceLoader.exists(KIND_MAP)




static func kind_at(x: float, z: float) -> int:
	if _kinds == null:
		if not painted():
			return 0
		_kinds = (load(KIND_MAP) as Texture2D).get_image()
	var px: = int((x - LOW) / SIZE * _kinds.get_width())
	var pz: = int((z - LOW) / SIZE * _kinds.get_height())
	if px < 0 or pz < 0 or px >= _kinds.get_width() or pz >= _kinds.get_height():
		return 0
	return int(round(_kinds.get_pixel(px, pz).r * 255.0 / 16.0))


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var plane: = PlaneMesh.new()
	plane.size = Vector2(SIZE, SIZE)
	mesh = plane
	position = Vector3(LOW + SIZE / 2.0, (top if top > - INF else 0.0) + 0.002, LOW + SIZE / 2.0)
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var material: = ShaderMaterial.new()
	material.shader = load("res://shaders/ground.gdshader")
	material.set_shader_parameter("color_map", load(COLOR_MAP))
	material.set_shader_parameter("kind_map", load(KIND_MAP))
	material.set_shader_parameter("grass", load("res://assets/textures/materials/Grass.png"))
	material.set_shader_parameter("soil", load("res://assets/textures/materials/Ground.png"))
	material.set_shader_parameter("noise", noise())
	material.set_shader_parameter("low", LOW)
	material.set_shader_parameter("size", SIZE)

	material.set_shader_parameter("sage", float(Config.Art.Lawn.Sage))
	material.set_shader_parameter("night_grey", float(Config.Art.Lawn.NightGrey))
	material_override = material



static func noise() -> NoiseTexture2D:
	if _noise_texture != null:
		return _noise_texture
	var source: = FastNoiseLite.new()
	source.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	source.frequency = 0.012
	source.fractal_octaves = 4
	source.seed = 11
	var texture: = NoiseTexture2D.new()
	texture.width = 512
	texture.height = 512
	texture.seamless = true
	texture.generate_mipmaps = true
	texture.noise = source
	_noise_texture = texture
	return texture
