class_name WaterJet
extends Node3D











const SPRAY: = Color(0.7, 0.87, 1.0)
const DROP: = Color(0.26, 0.6, 1.0)
const NOZZLE_WIDTH: = 0.5
const END_WIDTH: = 2.6
const SPREAD: = 0.04
const MARKS: = 14
const MARK_SIZE: = 6.0
const MARK_STEP: = 2.5
const MARK_TIME: = 50.0


const WET: = Color(0.38, 0.46, 0.58, 0.55)
const FOG: = Color(0.42, 0.7, 1.0)
const FOG_HALF_ANGLE: = 36.0
const FOG_LENGTH: = 11.0
const FOG_SHADER: = "\nshader_type spatial;\nrender_mode unshaded, blend_mix, depth_draw_never, cull_disabled, shadows_disabled;\n// The fog pattern's cone: blue, see-through, thickest a little out from the nozzle and thinning to nothing\n// at its far end and at its outline, with mist rolling out along it.\nuniform vec4 tint : source_color;\nuniform float strength = 0.0;\nuniform sampler2D noise : repeat_enable;\nuniform sampler2D depth_tex : hint_depth_texture, filter_nearest;\nvoid fragment() {\n\tfloat along = UV.y;  // 0 at the nozzle, 1 at the far end\n\tfloat mist = texture(noise, vec2(UV.x * 3.0, along * 1.2 - TIME * 1.6)).r;\n\tfloat facing = abs(dot(NORMAL, VIEW));\n\tfloat a = smoothstep(0.0, 0.1, along) * (1.0 - smoothstep(0.3, 0.95, along));\n\ta *= mix(0.45, 1.25, mist) * mix(0.3, 1.0, facing);\n\t// Soft where it meets the ground or a wall, not cut off in a hard line.\n\tfloat depth = texture(depth_tex, SCREEN_UV).r;\n\tvec4 scene = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0, depth, 1.0);\n\tscene.xyz /= scene.w;\n\ta *= clamp((VERTEX.z - scene.z) / 2.0, 0.0, 1.0);\n\tALBEDO = tint.rgb * mix(0.85, 1.2, mist);\n\tALPHA = clamp(a * tint.a * strength, 0.0, 1.0);\n}\n"
























var spraying: = false
var fog: = false
var origin: = Vector3.ZERO
var aim: = Vector3.ZERO
var flow: = 1.0
var speed: = 55.0


var pressure: = 1.0

var sputter: = false
var landing: = Vector3.ZERO
var landed: = false
var exclude: Array[RID] = []

var _body: MeshInstance3D
var _material: ShaderMaterial
var _mist: RbxEmitter
var _drops: RbxEmitter
var _cone: RbxEmitter
var _fog_drops: RbxEmitter
var _fog_body: MeshInstance3D
var _fog_material: ShaderMaterial
var _fog_shown: = 0.0
var _shed: Array[RbxEmitter] = []
var _shed_nodes: Array[Node3D] = []
var _landing_node: Node3D
var _nozzle_node: Node3D
var _head: = 0.0
var _tail: = 0.0
var _velocity: = Vector3.ZERO
var _from: = Vector3.ZERO
var _flight: = 0.0
var _sound: AudioStreamPlayer3D
var _splash_sound: AudioStreamPlayer3D
var _marks: Array = []
var _last_mark: = Vector3.INF


func _ready() -> void :
	top_level = true
	_body = MeshInstance3D.new()
	_body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_material = ShaderMaterial.new()
	_material.shader = load("res://shaders/toon_water.gdshader")
	_material.set_shader_parameter("noise", Ground.noise())
	_material.set_shader_parameter("speed", speed * 0.5)
	_body.material_override = _material
	add_child(_body)
	_landing_node = Node3D.new()
	add_child(_landing_node)
	_nozzle_node = Node3D.new()
	add_child(_nozzle_node)

	_mist = ToonFire.puffs(_landing_node, {
		"Color": SPRAY, "Speed": [4, 9], "Lifetime": [0.5, 0.9], "SpreadAngle": 75, "Direction": Vector3.UP, 
		"Drag": 1.5, "Rotation": [0, 360], "Size": [[0.0, 0.6], [0.3, 2.2], [1.0, 0.0]], "Rate": 0, "MaxRate": 14, 
		"Sphere": 0.8, 
	}, true)
	_drops = ToonFire.puffs(_landing_node, {
		"Color": DROP, "Speed": [7, 15], "Lifetime": [0.45, 0.8], "SpreadAngle": 60, "Direction": Vector3.UP, 
		"Acceleration": Vector3(0, -55, 0), "Size": [[0.0, 0.4], [1.0, 0.12]], "Rate": 0, "MaxRate": 30, 
		"Sphere": 0.6, 
	}, true)


	var fog_settings: Dictionary = Config.Hose.Fog
	_fog_body = MeshInstance3D.new()
	_fog_body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var funnel: = CylinderMesh.new()
	funnel.top_radius = 0.2
	funnel.bottom_radius = FOG_LENGTH * tan(deg_to_rad(FOG_HALF_ANGLE))
	funnel.height = FOG_LENGTH
	funnel.radial_segments = 24
	funnel.rings = 4
	funnel.cap_top = false
	funnel.cap_bottom = false
	_fog_body.mesh = funnel

	_fog_body.transform = Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(0, 0, - FOG_LENGTH / 2.0))
	_fog_material = ShaderMaterial.new()
	var shader: = Shader.new()
	shader.code = FOG_SHADER
	_fog_material.shader = shader
	_fog_material.set_shader_parameter("tint", Color(FOG, 0.42))
	_fog_material.set_shader_parameter("noise", Ground.noise())
	_fog_body.material_override = _fog_material
	_fog_body.visible = false
	_nozzle_node.add_child(_fog_body)
	_cone = RbxEmitter.make(_nozzle_node, {
		"Color": FOG, "Speed": [float(fog_settings["Speed"]) * 0.35, float(fog_settings["Speed"]) * 0.6], 
		"Lifetime": [0.35, 0.55], "SpreadAngle": FOG_HALF_ANGLE - 4.0, "Direction": Vector3.FORWARD, "Rotation": [0, 360], 
		"Drag": 2.0, "Size": [[0.0, 0.3], [0.5, float(fog_settings["Width"]) * 0.11], [1.0, 0.0]], "Rate": 0, "MaxRate": 50, 
		"Mesh": ToonFire.puff_mesh(), "Material": ToonFire.fog_material(), 
	})
	_fog_drops = ToonFire.puffs(_nozzle_node, {
		"Color": DROP, "Speed": [float(fog_settings["Speed"]) * 0.5, float(fog_settings["Speed"]) * 0.8], 
		"Lifetime": [0.3, 0.5], "SpreadAngle": FOG_HALF_ANGLE, "Direction": Vector3.FORWARD, 
		"Acceleration": Vector3(0, -30, 0), "Size": [[0.0, 0.22], [1.0, 0.08]], "Rate": 0, "MaxRate": 90, 
	}, true)

	for index in 2:
		var holder: = Node3D.new()
		add_child(holder)
		_shed_nodes.append(holder)
		_shed.append(ToonFire.puffs(holder, {
			"Color": SPRAY if index == 0 else DROP, "Speed": [1, 3] if index == 0 else [2, 6], 
			"Lifetime": [0.5, 0.9], "SpreadAngle": 180, 
			"Acceleration": Vector3(0, -10, 0) if index == 0 else Vector3(0, -60, 0), "Rotation": [0, 360], 
			"Size": [[0.0, 0.4], [0.4, 1.0], [1.0, 0.0]] if index == 0 else [[0.0, 0.3], [1.0, 0.1]], 
			"Rate": 0, "MaxRate": 8 if index == 0 else 22, "Box": Vector3(1.2, 1.2, 1.2), 
		}, true))
	_sound = Sounds.emitter(_nozzle_node, Sounds.loop("hose_spray"), 0.5, 14.0, 220.0)
	_splash_sound = Sounds.emitter(_landing_node, Sounds.loop("water_splash"), 0.35, 10.0, 160.0)


func _cast(from: Vector3, to: Vector3) -> Variant:
	var hit: = Game.world.raycast(from, to, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
	if hit.is_empty():
		return null
	return hit["position"]


func _process(delta: float) -> void :
	var hose: Dictionary = Config.Hose
	var gravity: float = hose["StreamGravity"]
	var wet: = spraying and not fog
	if wet and sputter:

		var now: = Game.now()
		wet = sin(now * 17.0) + sin(now * 29.0) > -0.3
	if wet:
		_from = origin
		_velocity = Ballistics.launch_toward(origin, aim, speed, gravity)
		_tail = 0.0
		_head = minf(_head + delta, float(hose["StreamTime"]))
	else:

		_tail += delta
		_head = minf(_head + delta, float(hose["StreamTime"]))
	_nozzle_node.global_position = origin
	if spraying:
		var out: = (aim - origin).normalized()
		if out.length_squared() > 0.5:
			_nozzle_node.global_transform = Rbx.look_at(origin, origin + out)
	ToonFire.look(Game.now())
	var fogging: = spraying and fog
	_cone.set_rate(50.0 * flow if fogging else 0.0)
	_fog_drops.set_rate(90.0 * flow if fogging else 0.0)
	_fog_shown = move_toward(_fog_shown, (0.6 + 0.4 * flow) if fogging else 0.0, delta * 4.0)
	_fog_body.visible = _fog_shown > 0.01
	if _fog_body.visible:
		_fog_material.set_shader_parameter("strength", _fog_shown)
	if spraying != _sound.playing and _sound.stream:
		if spraying:
			_sound.play()
		else:
			_sound.stop()
	if spraying:
		_sound.pitch_scale = 0.85 + 0.3 * flow
		_sound.volume_db = linear_to_db(0.25 + 0.45 * flow)

	var drawn: = _tail < _head and _velocity != Vector3.ZERO
	_body.visible = drawn
	landed = false
	if drawn:
		var traced: = Ballistics.trace(_from, _velocity, gravity, float(hose["StreamTime"]), int(hose["StreamSteps"]) * 2, _cast)
		_flight = traced["time"]
		var front: = minf(_head, _flight)
		if _tail >= front:
			drawn = false
			_body.visible = false
			_head = 0.0 if not wet else _head
		else:
			var path: = PackedVector3Array()
			var steps: = 18
			for index in steps + 1:
				var t: = lerpf(_tail, front, float(index) / steps)
				path.append(Ballistics.position(_from, _velocity, gravity, t))
			var thick: = (0.6 + 0.4 * flow) * lerpf(float(Config.Water.Pressure.WidthLeast), 1.0, clampf(pressure, 0.0, 1.0))
			var width_at: = func(t: float) -> float:
				return minf(NOZZLE_WIDTH + SPREAD * speed * t * 4.0, END_WIDTH) * thick
			var radius: float = width_at.call(_tail) / 2.0
			_body.mesh = HoseLine.tube(path, radius, 8, width_at.call(front) / 2.0)

			var span: = 0.0
			for index in range(1, path.size()):
				span += path[index].distance_to(path[index - 1])
			_material.set_shader_parameter("stud_scale", radius * 6.0)
			_material.set_shader_parameter("span", span)
			var daylight: float = Sky3D.current.daylight() if Sky3D.current else 1.0
			_material.set_shader_parameter("glow", lerpf(0.6, 1.05, daylight))
			landed = traced["hit"] and front >= _flight - 0.001
			landing = path[path.size() - 1]

			for index in _shed.size():
				var at: float = lerpf(_tail, front, 0.45 + 0.3 * index)
				_shed_nodes[index].global_position = Ballistics.position(_from, _velocity, gravity, at)
				_shed[index].set_rate((8.0 if index == 0 else 22.0) * flow * (1.0 if wet else 0.4))
	elif not wet:
		_head = 0.0
	if not drawn:
		for emitter in _shed:
			emitter.set_rate(0.0)
	_landing_node.global_position = landing
	var bursting: = landed
	_mist.set_rate(14.0 * flow if bursting else 0.0)
	_drops.set_rate(30.0 * flow if bursting else 0.0)
	if _splash_sound.stream and bursting != _splash_sound.playing:
		if bursting:
			_splash_sound.play()
		else:
			_splash_sound.stop()
	if bursting and landing.distance_to(_last_mark) > MARK_STEP:
		_wet(landing)
	_dry()



func _wet(at: Vector3) -> void :
	_last_mark = at
	var mark: Decal
	if _marks.size() < MARKS:
		mark = Decal.new()
		mark.texture_albedo = Assets.texture("water_wet_patch")
		mark.size = Vector3(MARK_SIZE, 3.0, MARK_SIZE)
		mark.cull_mask = 1
		mark.upper_fade = 0.2
		mark.lower_fade = 0.2
		mark.top_level = true
		add_child(mark)
	else:
		mark = _marks.pop_front()[0]
	mark.global_position = at
	mark.rotation.y = randf() * TAU
	var spread: = randf_range(0.8, 1.25)
	mark.size = Vector3(MARK_SIZE * spread, 3.0, MARK_SIZE * spread * randf_range(0.7, 1.0))
	mark.modulate = WET
	_marks.append([mark, Game.now()])


func _dry() -> void :
	var now: = Game.now()
	for entry: Array in _marks:
		entry[0].modulate.a = WET.a * clampf(1.0 - (now - entry[1]) / MARK_TIME, 0.0, 1.0)
