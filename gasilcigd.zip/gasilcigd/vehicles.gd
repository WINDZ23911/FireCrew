class_name Vehicles
extends RefCounted



const TRUCK_EYE: = 6.8
const PICKUP_EYE: = 4.4
const TRUCK_LEAD: = 0.7
const PICKUP_LEAD: = 0.3



static func parked(x: float, clearance: float, z: float) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, PI), Vector3(x, clearance + 0.2, z))






static func specs() -> Array:
	var list: = _metlika()
	var own: Dictionary = Edition.data().get("vehicles", {})
	var pumper: Dictionary = own.get("Fire Truck", {})
	for spec: Dictionary in list:
		var change: Variant = own.get(spec["name"])
		if change is Dictionary:
			for key: String in change:
				spec[key] = Rbx.decode(change[key]) if change[key] is Dictionary or change[key] is Array else change[key]

			if change.has("data") and not change.has("rescueKit"):
				spec.erase("rescueKit")
			if spec.has("spawn_x"):
				spec["spawn"] = parked(float(spec["spawn_x"]), float(spec.get("clearance", 2.8)), float(spec.get("spawn_z", -74)))

		for borrowed: Dictionary in spec.get("borrowed", []):
			if borrowed["kit"] == "truck_kit" and pumper.has("kit"):
				borrowed["kit"] = pumper["kit"]
				borrowed["data"] = pumper.get("data", borrowed["data"])
	return list


static func _metlika() -> Array:
	return [
		{
			"name": "Fire Truck", 
			"pumper": true, 
			"hoses": true, 
			"data": "TruckData", "kit": "truck_kit", 
			"eyeHeight": TRUCK_EYE, "eyeLead": TRUCK_LEAD, 
			"spawn": parked(-12, 2.8, -74), 
			"bay": int(Config.Station.PumperBay), 
			"tankCapacity": float(Config.Truck.TankCapacity), 
			"cones": {"locker": "Rear", "spot": Vector3(1.3, 3.0, 12.85)}, 
			"tape": {"locker": "Rear", "spot": Vector3(-1.3, 3.0, 12.85)}, 
			"fuelCapacity": 200.0, "fuelUse": 1.0, 
		}, 
		{
			"name": "Tanker", 
			"data": "TankerData", "kit": "tanker_kit", 
			"eyeHeight": TRUCK_EYE, "eyeLead": TRUCK_LEAD, 
			"spawn": parked(-30, 2.8, -74), 
			"bay": int(Config.Station.TankerBay), 
			"tankCapacity": 5000.0, 
			"hoses": true, 
			"pumpRate": 100.0, 
			"cones": {"locker": "Rear", "spot": Vector3(1.3, 3.0, 12.85)}, 
			"tape": {"locker": "Rear", "spot": Vector3(-1.3, 3.0, 12.85)}, 
			"fuelCapacity": 300.0, "fuelUse": 1.5, 
		}, 
		{
			"name": "Ladder Truck", 
			"ladder": true, 
			"hoses": true, 
			"tankCapacity": 400.0, 
			"tankEmpty": true, 
			"data": "LadderData", "kit": "ladder_kit", 
			"eyeHeight": TRUCK_EYE, "eyeLead": TRUCK_LEAD, 
			"spawn": parked(-48, 2.8, -74), 
			"bay": int(Config.Station.LadderBay), 
			"cones": {"locker": "R2", "spot": Vector3(3.9, -0.6, 3.1)}, 
			"tape": {"locker": "R2", "spot": Vector3(3.9, -0.6, 4.1)}, 
			"fuelCapacity": 300.0, "fuelUse": 1.5, 
		}, 
		{
			"name": "Command Vehicle", 
			"data": "PickupData", "kit": "pickup_kit", 
			"eyeHeight": PICKUP_EYE, "eyeLead": PICKUP_LEAD, 
			"spawn": parked(6, 1.9, -71), 
			"bay": 1, 
			"cones": {"locker": "BedL", "spot": Vector3(-2.6, 3.11, 6.8)}, 
			"tape": {"locker": "BedR", "spot": Vector3(2.6, 3.11, 7.4)}, 
			"fuelCapacity": 80.0, "fuelUse": 0.3, 
			"horn": "car_horn", 

			"blueLamps": [
				{"phase": 1, "pos": [-1.05, 1.32, -10.44], "size": [0.62, 0.22, 0.08]}, 
				{"phase": 0, "pos": [1.05, 1.32, -10.44], "size": [0.62, 0.22, 0.08]}, 
				{"phase": 0, "pos": [-2.3, 5.2, 10.0], "size": [0.9, 0.28, 0.08]}, 
				{"phase": 1, "pos": [2.3, 5.2, 10.0], "size": [0.9, 0.28, 0.08]}, 
			], 



			"borrowed": [
				{"kit": "truck_kit", "data": "TruckData", "prop": "Extinguisher1", "locker": "BedR", "at": Vector3(2.75, 3.05, 4.55)}, 
				{"kit": "truck_kit", "data": "TruckData", "prop": "Set1", "locker": "BedL", "at": Vector3(-1.8, 2.25, -0.3), "turn": -90.0}, 
				{"kit": "truck_kit", "data": "TruckData", "prop": "Set2", "locker": "BedL", "at": Vector3(1.8, 2.25, -0.3), "turn": -90.0}, 

				{"kit": "truck_kit", "data": "TruckData", "prop": "ThermalCamera", "locker": "BedL", "at": Vector3(-2.2, 3.18, 4.0)}, 
			], 
			"airSets": 2, 


			"rescueKit": {
				"First aid kit": {"locker": "BedL", "spot": Vector3(-2.3, 4.29, 5.15), "turn": Vector3.ZERO}, 
			}, 
		}, 
	]
