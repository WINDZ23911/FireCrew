class_name JobStandTool
extends CrewJob



var tool_name: = ""
var face: = Vector3.ZERO


func _init(which: String, at: Vector3, toward: Vector3) -> void :
	tool_name = which
	kind = "floodlight" if which == "Floodlight" else "fan"
	role = "safety"
	target = at
	face = toward


func place() -> Vector3:
	return target


func run() -> bool:
	if await CrewKit.take_tool(who, [tool_name], who.service.home_vehicle(who.commander())) == "":
		return fail("crew.say.noTool", [Text.named("tools", tool_name)])
	var held: = who.token()

	var way: = Vector3(face.x - target.x, 0, face.z - target.z)
	way = way.normalized() if way.length() > 0.1 else Vector3(0, 0, -1)
	if not await who.go(who.service.ground(target - way * 4.0 + Vector3(0, 2, 0)), 1.2, 60.0):
		return fail("crew.say.stuck")
	who.look = who.body.global_position + way * 20.0
	if not await who.wait(0.5, held):
		return false
	CrewKit.pull(who)
	await who.wait(0.3, held)
	return ToolService.current.held(who.body) != tool_name
