class_name Hotbar
extends Control







const GAP: = 10.0
const NAME_LINES: = 2

var _slots: Control
var _watched: Player
var _slot: = 86.0
var _held: = -1
var _kit: = ""


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_slots = Control.new()
	_slots.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_slots)
	ToolService.current.carried_changed.connect( func(player: Player) -> void :
		if player == Game.local_player:
			_rebuild()
	)
	Text.language_changed.connect( func(_code: String) -> void : _rebuild())
	_rebuild()


func _rebuild() -> void :
	_slot = float(Config.Hud.HotbarSlot)
	var side: = _slot
	for child in _slots.get_children():
		_slots.remove_child(child)
		child.queue_free()
	var player: = Game.local_player
	if player == null:
		return
	var tools: = ToolService.current.slots(player)
	_kit = CallGear.carried(player)
	var held_now: = -1
	var plates: = tools.duplicate()
	if not _kit.is_empty():
		plates.append({"name": _kit, "kit": true})
	for index in plates.size():
		var item: Dictionary = plates[index]
		var held: bool = item.has("kit") or ToolService.current.slot_in_hand(player, item)
		if held:
			held_now = index
		var slot: = Ui.plate(Vector2(side, side))
		slot.position = Vector2(index * (side + GAP), 0)
		_slots.add_child(slot)
		if held:
			var ring: = Panel.new()
			var style: = StyleBoxFlat.new()
			style.bg_color = Color(0, 0, 0, 0)
			style.border_color = Ui.YELLOW
			style.set_border_width_all(2)
			style.set_corner_radius_all(4)
			ring.add_theme_stylebox_override("panel", style)
			ring.position = Vector2(3, 3)
			ring.size = Vector2(side - 6, side - 6)
			ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
			slot.add_child(ring)
		var tone: = Ui.TEXT if held else Ui.DIM
		var icon: String = CallGear.ICONS.get(item["name"], "") if item.has("kit") else ToolIcons.of(item["name"])
		if not icon.is_empty():
			var picture: = Ui.icon(icon, 34, tone)
			picture.position = Vector2((side - 34) / 2, 8)
			slot.add_child(picture)
		var words: = Text.say(Text.upper(Text.named("tools", item["name"])))
		var font_size: = _name_size(words, side - 8)
		var caption: = Ui.label(words, font_size, tone)
		caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		caption.max_lines_visible = NAME_LINES
		caption.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		caption.add_theme_constant_override("line_spacing", -3)
		caption.position = Vector2(4, 44 if not icon.is_empty() else 8)
		caption.size = Vector2(side - 8, side - 48 if not icon.is_empty() else side - 16)
		slot.add_child(caption)
		if index < 9:
			var number: = Ui.label(str(index + 1), 13, Ui.YELLOW if held else Ui.DIM)
			number.position = Vector2(7, 3)
			slot.add_child(number)
	_slots.set_meta("width", plates.size() * side + maxi(plates.size() - 1, 0) * GAP)
	if held_now != _held:
		Sounds.ui("ui_hotbar", 1.06 if held_now >= 0 else 0.94)
	_held = held_now



func _name_size(words: String, room: float) -> int:
	var font: = Ui.label_font()
	var size: = int(Config.Hud.CapsFloor)
	while size > 10:
		var fits: = true
		for word in words.split(" "):
			if font.get_string_size(word, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x > room:
				fits = false
		if fits:
			break
		size -= 1
	return size


func _process(_delta: float) -> void :
	if Game.local_player != null and CallGear.carried(Game.local_player) != _kit:
		_rebuild()
	var view: = get_parent_area_size()
	var width: float = _slots.get_meta("width", 0.0)
	_slots.position = Vector2((view.x - width) / 2.0, view.y - Ui.MARGIN - _slot).round()
