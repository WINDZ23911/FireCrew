class_name HudFireOut
extends Control








static var current: HudFireOut

var _call: = ""
var _out: = 0
var _burning: = 0
var _beaten: = false
var _streak: = 0
var _last_out: = -100.0
var _beat_until: = 0.0
var _heard: Dictionary = {}
var _title: Label
var _sub: Label
var _plate: Control


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Control.new()
	_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.visible = false
	add_child(_plate)
	_title = Ui.display("", 64, Ui.GREEN)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.add_theme_constant_override("outline_size", 10)
	_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_plate.add_child(_title)
	_sub = Ui.label("", 20)
	_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_sub.add_theme_constant_override("outline_size", 6)
	_sub.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_plate.add_child(_sub)
	Game.incident_ending.connect(_on_ending)



static func holding() -> bool:
	return current != null and Game.now() < current._beat_until


func _process(_delta: float) -> void :
	var incident: = Game.incident
	if not incident.is_empty() and incident.has("flames"):
		var name_now: = Text.say(incident.get("name", ""), "sl")
		var out: = int(incident.get("flames_out", 0))
		var burning: = int(incident.get("flames", 0))
		if name_now != _call:
			_call = name_now
			_out = out
			_burning = burning
			_beaten = false
		else:
			if out > _out:
				_flames_out(out - _out)
			if burning == 0 and _burning > 0 and out > 0 and float(incident.get("health", 100.0)) > 0.0:
				beat()
			_out = out
			_burning = burning
	_plate.visible = Game.now() < _beat_until
	if _plate.visible:
		var view: = get_parent_area_size()
		var width: = view.x
		_title.size = Vector2(width, 80)
		_sub.size = Vector2(width, 30)
		_plate.position = Vector2(0, view.y * 0.3)
		_sub.position = Vector2(0, 82)
		var left: = _beat_until - Game.now()
		var total: = float(Config.Hud.FireOutBeat)

		_plate.modulate.a = clampf((total - left) / 0.15, 0.0, 1.0) * clampf(left / 0.4, 0.0, 1.0)
		var pop: = 1.0 + 0.15 * clampf(1.0 - (total - left) / 0.2, 0.0, 1.0)
		_title.pivot_offset = _title.size / 2
		_title.scale = Vector2(pop, pop)



func _on_ending(last: Dictionary) -> void :
	if last.has("flames") and not _beaten and int(last.get("flames_out", 0)) > 0 and float(last.get("health", 0.0)) > 0.0 and not last.get("failed", false):
		if int(last.get("flames_out", 0)) > _out:
			_flames_out(int(last.get("flames_out", 0)) - _out)
		beat()
	_call = ""
	_out = 0
	_burning = 0



func _flames_out(count: int) -> void :
	var now: = Game.now()
	_streak = _streak + count if now - _last_out <= float(Config.Hud.FlameStreak) else count
	_last_out = now
	var step: = mini(_streak - 1, int(Config.Hud.FlameStreakMost))
	Sounds.ui("flame_out_chime", 1.0 + float(Config.Hud.FlameStreakPitch) * step)
	_pfff()

	get_tree().create_timer(0.4).timeout.connect(_pfff)


func _pfff() -> void :
	if Game.world == null:
		return
	for child in Game.world.get_children():
		if child is Smoulder and not _heard.has(child.get_instance_id()) and Game.now() - (child as Smoulder)._born < 1.5:
			_heard[child.get_instance_id()] = true
			var sounds: Dictionary = Config.UiSounds
			Sounds.once_at((child as Smoulder).global_position, "flame_out_pfff", float(sounds["PfffVolume"]), float(sounds["PfffNear"]), float(sounds["PfffFar"]), randf_range(0.94, 1.06))
	if _heard.size() > 200:
		_heard.clear()



func beat() -> void :
	if _beaten:
		return
	_beaten = true
	_beat_until = Game.now() + float(Config.Hud.FireOutBeat)
	_title.text = Text.say(Text.m("hud.fireOut.title"))

	var next: Variant = Game.incident.get("next")
	_sub.text = Text.say(next) if next != null else ""
	Sounds.ui("fire_out_sting")
