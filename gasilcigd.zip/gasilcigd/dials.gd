extends ProofDebug
















func _ai_crew(count: int) -> Array[Player]:
	var bodies: Array[Player] = []
	var service: = CrewService.current
	if service == null:
		return bodies
	for index in count:
		var entry: = service.roster._member("", "nozzle", 0, 0)
		var mind: = service._make(entry, service.members.size(), player)
		bodies.append(mind.body)
	return bodies


func _hud_duty() -> HudDuty:
	return Hud.current.widgets.get("duty") as HudDuty


func _kind(kind_name: String) -> Variant:
	for kind in CallService.current.kinds:
		if kind.kind == kind_name:
			return kind
	return null



func _far_from(at: Vector3) -> Vector3:
	var best: Vector3 = at
	for building in FireService.current.buildings:
		if building is House and building.position.distance_to(at) > best.distance_to(at) and building.position.distance_to(at) < 900.0:
			best = building.position
	var spot: = _ground(best + Vector3(0, 30, 0) + (at - best).normalized() * 25.0)
	return spot + Vector3(0, 0.5, 0)


func _scenario_dutyreport() -> void :
	await _wait(1.0)
	var calls: = CallService.current
	_check(Duty.current != null and _hud_duty() != null, "the duty and its HUD widget are there")
	calls.forced = "medical"
	calls.wait_left = 200.0
	await _wait(1.0)
	print("dutyreport: trucks out %d, status %s; hud: %s" % [CallService.trucks_out(), calls.status(), _hud_duty().shown_text()])
	_check(calls.status() == "available", "with every truck in its bay the unit is available")
	_check(Text.say(Text.m("hud.duty.available")) in _hud_duty().shown_text(), "the HUD says AVAILABLE")
	await _snap("available")

	var truck: Vehicle = Vehicle.all[0]
	var home: = truck.global_transform
	truck.global_position = home.origin + Vector3(0, 0, -60)
	await _wait(1.0)
	await _tap(Duty.ACTION)
	await _wait(0.5)
	print("dutyreport: a truck out: status %s, %.0f s to the next call; hud: %s" % [calls.status(), calls.wait_left, _hud_duty().shown_text()])
	_check(calls.status() == "returning" and Text.say(Text.m("hud.duty.returning")) in _hud_duty().shown_text(), "with a truck out the unit is returning")
	_check( not calls.reported and calls.wait_left > 150.0, "the report is refused while a truck is out")
	await _snap("returning")
	truck.global_transform = home
	truck.linear_velocity = Vector3.ZERO
	await _wait(1.5)

	calls.hold = false
	var reported_at: = Game.now()
	await _tap(Duty.ACTION)
	await _wait(0.5)
	var left: = calls.wait_left
	print("dutyreport: reported: %.1f s to the next call; hud: %s" % [left, _hud_duty().shown_text()])
	var gap: Array = Config.Duty.ReportGap
	_check(calls.reported and left >= float(gap[0]) - 1.0 and left <= float(gap[1]), "a report with the trucks home brings the next call within %s-%s s" % gap)
	var came: = [-1.0]
	Game.call_started.connect( func(_kind_name: String) -> void : came[0] = Game.now(), CONNECT_ONE_SHOT)
	var waited: = 0.0
	while came[0] < 0.0 and waited < 40.0:
		await _wait(0.5)
		waited += 0.5
	var after: float = came[0] - reported_at
	print("dutyreport: the call came %.1f s after the report" % after)
	_check(came[0] > 0.0 and after <= float(gap[1]) + 1.0, "the call came within %d s of the report" % int(gap[1]))
	await _wait(2.0)
	print("dutyreport: on the call: hud %s" % _hud_duty().shown_text())
	_check(calls.status() == "out" and Text.say(Text.m("hud.duty.out")) in _hud_duty().shown_text(), "on a call the unit is out")
	await _snap("out")
	await _done()


func _levels(samples: int) -> Array:
	var counts: = [0, 0, 0]
	for index in samples:
		Alarm.begin()
		counts[Alarm.level - 1] += 1
		Alarm.end()
	return counts


func _scenario_dutyshift() -> void :
	await _wait(1.0)
	_check(Alarm.ai_crew() == 0 and Game.humans() == 1, "alone, with the AI crew off")
	var samples: = 400
	var seen: Dictionary = {}
	for shift: String in Shift.NAMES:
		Shift.apply(shift)
		var counts: = _levels(samples)
		seen[shift] = counts
		print("dutyshift: %s: levels I/II/III %s of %d; gap %s; pay ×%.1f" % [shift, counts, samples, Shift.gap(), Shift.pay()])
	_check(seen["quiet"][0] == samples, "a quiet shift draws level I only")
	_check(seen["busy"][0] == 0 and seen["busy"][2] == 0, "a busy night alone with the crew off: level II only (no I; III capped by AloneMost)")
	_check(float(Shift.gap()[1]) <= 150.0 and float((Config.Duty.Shifts["quiet"]["Gap"] as Array)[0]) >= 300.0, "busy gaps are short, quiet ones long (FIXES_0.4.0 #3: busy 90-150 s, quiet 300-420)")
	Alarm.forced = 2
	Alarm.begin()
	var busy_pay: = Alarm.pay(100)
	Alarm.end()
	Shift.apply("normal")
	Alarm.begin()
	var normal_pay: = Alarm.pay(100)
	Alarm.end()
	Alarm.forced = 0
	print("dutyshift: 100 at level II pays %d on a normal shift, %d on a busy night" % [normal_pay, busy_pay])
	_check(busy_pay == int(round(normal_pay * 1.3)), "a busy night pays ×1.3")

	_check(Alarm.crew() == 1, "alone the call is sized for one")
	var bodies: = _ai_crew(4)
	await _wait(0.5)
	print("dutyshift: with %d of the AI crew the call is sized for %d" % [Alarm.ai_crew(), Alarm.crew()])
	_check(Alarm.ai_crew() == 4 and Alarm.crew() == 3, "four AI crew count as two (1 + 4 × 0.5 = 3)")
	Shift.apply("busy")
	var busy: = _levels(samples)
	print("dutyshift: busy with the crew: %s" % [busy])
	_check(busy[0] == 0 and busy[2] > samples * 0.25, "a busy night with the crew draws II and III")
	Shift.apply("normal")

	var veteran: = Alarm.median_rank([0, 250])
	var three: = Alarm.median_rank([0, 5, 250])
	print("dutyshift: ranks of a new player and a veteran: %d; with one more of 5 calls: %d" % [veteran, three])
	_check(veteran == 0 and three == Alarm.rank_of(5), "the crew's rank is its median, the lower in an even crew")
	player.set_attr("Saved", 30)
	_check(Alarm.crew_rank() == Alarm.rank_of(30), "one player alone goes by their own rank")
	player.set_attr("Saved", 0)
	await _done()


func _scenario_dutymix() -> void :
	await _wait(1.0)
	var calls: = CallService.current
	var draws: = 600
	var counts: Dictionary = {}
	var repeats: = 0
	var last: Array[String] = []
	calls._recent.clear()
	for index in draws:
		var kind: Variant = calls.draw()
		if kind == null:
			continue
		var kind_name: String = kind.kind
		counts[kind_name] = int(counts.get(kind_name, 0)) + 1
		if kind_name != "fire" and not last.is_empty() and last[0] == kind_name:
			repeats += 1
		last.push_front(kind_name)
		calls.note_drawn(kind_name)
	var mix: Dictionary = Config.Incidents.Mix
	var lines: PackedStringArray = []
	var names: Array = counts.keys()
	names.sort()
	for kind_name: String in names:
		lines.append("%s %d (%.0f%%, share %.0f%%)" % [kind_name, counts[kind_name], 100.0 * counts[kind_name] / draws, 100.0 * float(mix.get(kind_name, 0.0))])
	print("dutymix: %d calls drawn: %s; the same kind (not fire) twice running %d times" % [draws, ", ".join(lines), repeats])
	var fires: = float(counts.get("fire", 0)) / draws
	_check(fires > 0.42 and fires < 0.64, "about half the calls are fires (%.0f%%)" % (fires * 100.0))
	_check(counts.size() >= 8, "every kind comes up (%d kinds)" % counts.size())

	var expected: = 0.0
	for kind_name: String in mix:
		expected += 0.0 if kind_name == "fire" else pow(float(mix[kind_name]), 2.0) * draws
	_check(repeats < expected * 0.8, "the bag makes the same kind twice running rarer (%d, against %.0f without it)" % [repeats, expected])

	var fire: = FireService.current
	var keep: House = _house("Family house")
	var others: Array = []
	for building in fire.buildings:
		if building != keep and not building.ruined:
			others.append(building)
	calls._burnt = others
	calls._run_fire(fire)
	await _wait(0.5)
	var drawn: Variant = fire.incident.get("group", {}).get("building")
	var back: = true
	for building: Variant in others:
		back = back and not building.ruined
	print("dutymix: with every other building just burnt, the fire is at %s" % (drawn.name if drawn != null else "nothing"))
	_check(drawn == keep, "the buildings of the last fires are not drawn")
	_check(back, "and are back in use the moment after the draw")
	calls._burnt = []

	var waits: = Text.say(CallService.level_line("fire", 2), "en")
	var crash: = Text.say(CallService.level_line("crash", 2), "en")
	var medical: = Text.say(CallService.level_line("medical", 3), "en")
	print("dutymix: level lines: %s | %s | %s" % [waits, crash, medical])
	_check("will not wait" in waits, "a fire at II says it will not wait")
	var honest: = true
	for kind_name: String in ["tree", "crash", "flood", "medical", "rescue", "accident", "alarm"]:
		for level in [2, 3]:
			honest = honest and not ("will not wait for you" in Text.say(CallService.level_line(kind_name, level), "en"))
	_check(honest, "no call that waits says it will not")
	_check(medical == Text.say(Text.f("calls.alarm.level", ["III"]), "en"), "a kind with nothing changed by its level says the level alone")

	var before: = Text.language
	Text.choose("sl")
	var name_sl: = PlayerData.default_name()
	Text.choose("en")
	var name_en: = PlayerData.default_name()
	Text.choose(before)
	print("dutymix: the first run's language here: %s (OS %s); the default name: %s / %s" % [Settings.first_language(), OS.get_locale_language(), name_sl, name_en])
	_check(name_sl == "Gasilec" and name_en == "Firefighter", "the default name is in the player's language")
	_check(Settings.first_language() == ("sl" if OS.get_locale_language() == "sl" else "en"), "a first run starts in the computer's language where the game has it")
	await _done()


func _scenario_dutyclose() -> void :
	await _wait(1.0)
	var calls: = CallService.current
	Config.Incidents["CloseAfter"] = 40.0
	var medical: Variant = _kind("medical")
	if not _check(medical != null, "the medical call is there"):
		await _done()
		return
	calls.run_call("medical", medical.run)
	var waited: = 0.0
	while not Game.incident.has("pos") and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	var at: Vector3 = Game.incident["pos"]
	player.teleport(_far_from(at))
	await _wait(1.0)
	print("dutyclose: the call at %s; standing %.0f away" % [at, player.global_position.distance_to(at)])
	await _wait(14.0)
	print("dutyclose: 15 s, nobody there: call open %s, card closes_in %s" % [ not Game.incident.is_empty(), Game.incident.get("closes_in", "-")])
	_check( not Game.incident.is_empty() and not Game.incident.has("closes_in"), "before anyone gets there the call stays open and shows no close timer")
	await _wait(15.0)
	_check( not Game.incident.is_empty(), "30 s after dispatch, nobody there, it is still open")

	var arrived_at: = Game.now()
	player.teleport(_ground(at + Vector3(0, 30, 0) + Vector3(12, 0, 12)) + Vector3(0, 0.5, 0))
	await _wait(3.0)
	var shown: = int(Game.incident.get("closes_in", -1))
	print("dutyclose: on scene: closes_in %d; hud: %s" % [shown, _hud_duty().shown_text()])
	_check(shown > 30 and shown <= 40, "on arrival the close timer starts from CloseAfter (%d)" % shown)
	_check(Text.say(Text.f("hud.duty.closesIn", [HudDuty.clock(shown)])) in _hud_duty().shown_text(), "the HUD shows when the call closes")
	await _snap("closetimer")
	waited = 0.0
	while not Game.incident.is_empty() and waited < 60.0:
		await _wait(0.5)
		waited += 0.5
	var closed: = Game.now() - arrived_at
	print("dutyclose: the call closed %.0f s after the crew got there" % closed)
	_check(Game.incident.is_empty() and closed >= 38.0 and closed <= 46.0, "the call closes CloseAfter after the arrival")
	await _done()



func _view_panel() -> void :
	var holder: Node3D = FireAlarm.current._panel.get("holder")
	var face: Node3D = holder.get_node_or_null("Panel") if holder != null else null
	if face == null:
		return
	var out: = face.global_transform.basis.z.normalized()
	var screen: = face.global_transform * Vector3(0, 0.2, 0.3)
	_view(screen + out * 1.4 + Vector3(0, 0.05, 0), screen, 70.0)


func _scenario_dutyalarm() -> void :
	await _wait(1.0)
	var chances: = [FireAlarm.real_chance(1), FireAlarm.real_chance(2), FireAlarm.real_chance(3)]
	var real: = 0
	for index in 1000:
		real += 1 if randf() < FireAlarm.real_chance(2) else 0
	print("dutyalarm: real-fire chance by level %s; at II, %d of 1000 drawn real" % [chances, real])
	_check(is_equal_approx(chances[0], 0.2) and is_equal_approx(chances[1], 0.3) and is_equal_approx(chances[2], 0.45), "most alarms are false: 20/30/45 % real")
	var alarm: = FireAlarm.current
	if not _check(alarm != null and alarm.available(), "the factories' alarms are there"):
		await _done()
		return
	alarm.forced_real = 1
	VictimService.current.forced = 0
	CallService.current.run_call("alarm", alarm.run)
	await _wait(2.0)
	var marker: Variant = FireService.current.incident.get("marker")
	var marker_words: String = Text.say(marker.get_meta("text", ""), "en") if marker is CallMarker else "-"
	var lcd: Label3D = alarm._panel.get("lcd")
	print("dutyalarm: a real fire, unread: card kind %s, flames %s, marker %s; display: %s" % [Game.incident.get("kind"), Game.incident.get("flames", "-"), marker_words, lcd.text.replace("\n", " / ") if lcd != null else "-"])
	_check(Game.incident.get("kind") == "alarm" and not Game.incident.has("flames") and not Game.incident.has("victims"), "unread, the real fire's card is an alarm's: no flames or people counted")
	_check(marker_words == Text.say(Text.m("calls.markers.alarm"), "en"), "and its marker says ALARM")
	_check(lcd != null and Text.say(Text.m("calls.alarm.lcd.alarm")) in lcd.text, "the panel's display shows the alarm")
	_view_panel()
	await _snap("panel_unread")
	var zone: = [0]
	var zone_pattern: = RegEx.create_from_string("zone (\\d+)")
	Game.notified.connect( func(text: Variant, _how: String, _who: Player) -> void :
		var found: = zone_pattern.search(Text.say(text, "en"))
		if found != null:
			zone[0] = int(found.get_string(1))
	)
	alarm._panel["prompt"].triggered.emit(player)
	await _wait(1.0)
	var zone_words: = Text.say(Text.f("calls.alarm.lcd.zone", [zone[0], ""])).get_slice("·", 0).strip_edges()
	_check(zone[0] > 0 and lcd != null and zone_words in lcd.text, "the display names the zone the panel's message does (%s)" % zone_words)
	marker_words = Text.say(marker.get_meta("text", ""), "en") if marker is CallMarker and is_instance_valid(marker) else "-"
	print("dutyalarm: read: card kind %s, flames %s, marker %s; display: %s" % [Game.incident.get("kind"), Game.incident.get("flames", "-"), marker_words, lcd.text.replace("\n", " / ") if lcd != null else "-"])
	_check(Game.incident.get("kind") == "fire" and Game.incident.has("flames"), "once read it is a fire on the card")
	_check(marker_words == Text.say(Text.m("calls.markers.fire"), "en"), "and the marker says FIRE")
	_check(lcd != null and lcd.text.split("\n").size() >= 2 and Text.say(Text.m("calls.alarm.lcd.zone")).get_slice(" ", 0) in lcd.text, "the display names the zone")
	await _snap("panel_read")
	_view_player()
	await _snap("card")
	await _done()


func _scenario_dutyhazmat() -> void :
	await _wait(1.0)
	var leak: = HazmatLeak.current
	if not _check(leak != null, "the hazmat call is there"):
		await _done()
		return
	leak.forced_source = "tanker"
	Alarm.forced = 3
	var ignite: = float((Config.Incidents.Hazmat.Ignite as Array)[2])
	CallService.current.run_call("hazmat", leak.run)
	var waited: = 0.0
	while leak._leak.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	var at: Vector3 = leak._leak["leak"]
	player.teleport(_far_from(at))
	await _wait(8.0)
	print("dutyhazmat: 8 s, the crew away: ignite_in %s (%s); hud: %s" % [Game.incident.get("ignite_in"), Game.incident.get("ignite_state"), _hud_duty().shown_text()])
	_check(int(Game.incident.get("ignite_in", -1)) == int(ignite) and Game.incident.get("ignite_state") == "wait", "before the crew gets there the ignition clock stands at %d s" % int(ignite))
	_check(Text.say(Text.f("hud.duty.igniteFrom", [HudDuty.clock(ignite)])) in _hud_duty().shown_text(), "and the card says it runs from arrival")

	var victims: Array = VictimService.current.victims
	var before: Array = []
	for victim: Victim in victims:
		before.append(victim.condition)
	await _wait(4.0)
	var drains: Array = []
	for index in victims.size():
		drains.append(snappedf((before[index] - victims[index].condition) / 4.0, 0.01))
	var base: = 100.0 / float(Config.Incidents.Hazmat.CasualtyTime)
	print("dutyhazmat: casualties lose %s a second in the cloud (base %.2f, cloud %.2f)" % [drains, base, float(leak._leak["cloud"])])
	_check( not drains.is_empty() and float(drains.max()) > base * 1.15, "the vapour round a casualty hurts them more than clear air")

	player.teleport(_ground(at + Vector3(0, 30, 0) + Vector3(-25, 0, -25)) + Vector3(0, 0.5, 0))
	await _wait(5.0)
	var running: = int(Game.incident.get("ignite_in", -1))
	print("dutyhazmat: 5 s on scene: ignite_in %d (%s); hud: %s" % [running, Game.incident.get("ignite_state"), _hud_duty().shown_text()])
	_check(running < int(ignite) and running >= int(ignite) - 7 and Game.incident.get("ignite_state") == "run", "on arrival the clock runs")
	await _snap("clock")

	player.set_attr("Pattern", "Fog")
	var held_from: = int(Game.incident.get("ignite_in", -1))
	for step in 24:
		leak._on_water({"position": leak._cloud_middle()}, 0.25, Vector3.DOWN, player)
		await _wait(0.25)
	var held: = int(Game.incident.get("ignite_in", -1))
	print("dutyhazmat: 6 s of fog: ignite_in %d -> %d (%s); hud: %s" % [held_from, held, Game.incident.get("ignite_state"), _hud_duty().shown_text()])
	_check(held >= held_from - 1 and Game.incident.get("ignite_state") == "held", "fog on the vapour holds the clock")
	await _snap("fog")
	await _wait(3.0)
	_check(int(Game.incident.get("ignite_in", -1)) < held, "and it runs again when the fog stops")
	Alarm.forced = 0
	await _done()
