class_name JobBreakWindow
extends CrewJob



var pane: Dictionary


func _init(which: Dictionary) -> void :
	kind = "window"
	role = "rescue"
	pane = which


func place() -> Vector3:
	return pane["position"]


func run() -> bool:
	if pane["broken"]:
		return true
	if await CrewKit.take_tool(who, ["Axe", "Halligan bar", "Crowbar"], who.service.home_vehicle(who.commander())) == "":
		return fail("crew.say.noTool", [Text.named("tools", "Axe")])
	var held: = who.token()
	var at: Vector3 = pane["position"]
	var spot: = who.stand_by(at, 2.5)
	if spot.distance_to(at) > float(Config.Tools.GlassReach) - 0.5:
		return fail("crew.say.tooHigh")
	if not await who.go(spot, 1.0, 40.0):
		return fail("crew.say.stuck")
	for swing in 6:
		if pane["broken"]:
			break
		who.look = at
		who.pitch = asin(clampf((at - who.body.head_position()).normalized().y, -1.0, 1.0))
		if not await who.wait(0.4, held):
			return false

		who.body.set_attr("Aim", at)
		CrewKit.pull(who)
		if not await who.wait(0.7, held):
			return false
	return pane["broken"]


func finish(_done: bool) -> void :
	CrewKit.free_hands(who)
