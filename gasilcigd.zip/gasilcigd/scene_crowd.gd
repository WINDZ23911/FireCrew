class_name SceneCrowd
extends Node3D












const TICK: = 0.5
const GOWNS: Array[Color] = [
	Color8(120, 34, 48), Color8(36, 48, 92), Color8(196, 150, 170), Color8(110, 112, 118), Color8(80, 60, 48), 
	Color8(214, 206, 190), Color8(52, 82, 66), 
]
const PYJAMAS: Array[Color] = [
	Color8(150, 180, 214), Color8(200, 200, 206), Color8(214, 168, 184), Color8(176, 196, 160), Color8(90, 100, 140), 
]
const PHONES: = 14
static var big_fire: = 4
const FLASH_EVERY: = 2.6
const FLASH_TIME: = 0.09

var _dressed: Dictionary = {}
var _since: = 0.0
var _screens: Array[MeshInstance3D] = []
var _photographer: Node3D
var _camera_box: MeshInstance3D
var _flash: OmniLight3D
var _flash_card: MeshInstance3D
var _photo_for: = Vector3.INF
var _last_flash: = -1


func _ready() -> void :
	var screen: = StandardMaterial3D.new()
	screen.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	screen.albedo_color = Color(0.75, 0.85, 1.0)
	screen.emission_enabled = true
	screen.emission = Color(0.7, 0.82, 1.0)
	screen.emission_energy_multiplier = 3.0
	screen.cull_mode = BaseMaterial3D.CULL_DISABLED
	var quad: = QuadMesh.new()
	quad.size = Vector2(0.38, 0.62)
	quad.material = screen
	for index in PHONES:
		var phone: = MeshInstance3D.new()
		phone.mesh = quad
		phone.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		phone.top_level = true
		phone.visible = false
		add_child(phone)
		_screens.append(phone)


func _process(delta: float) -> void :
	var folk: = Townsfolk.current
	var at: Variant = Game.incident.get("pos")
	_since += delta
	if _since >= TICK:
		_since = 0.0
		if folk != null:
			_dress(folk, at)
		_press(at)
	_phones(folk)
	_flashes()






static func _in_night_things(person: Pedestrians.Person) -> bool:
	return Game.night and posmod(person.seed, 5) != 0


func _dress(folk: Townsfolk, at: Variant) -> void :
	for id: int in folk.bodies:
		var body: Townsfolk.Body = folk.bodies[id]
		if body == null or not body.built or body.person == null:
			continue
		var person: = body.person
		var wanted: Array = _dressed.get(id, [])
		if wanted.is_empty():

			if not (at is Vector3 and person.shown_state == "watch" and _in_night_things(person)):
				continue
			wanted = [GOWNS[posmod(person.seed * 7, GOWNS.size())], PYJAMAS[posmod(person.seed * 3, PYJAMAS.size())]]
			_dressed[id] = wanted
		_recolour(body, wanted[0], wanted[1])

	for id: int in _dressed.keys():
		if not folk.bodies.has(id) or not Game.night and not at is Vector3:
			_dressed.erase(id)




static func _recolour(body: Townsfolk.Body, gown: Color, pyjamas: Color) -> void :



	if is_instance_valid(body.rig):
		body.rig.tint("townTop", gown)
		body.rig.tint("townTopLong", gown)
		body.rig.tint("townLegs", pyjamas)
	var torso_done: = false
	for piece: Variant in body.pieces:
		if not piece is Array or piece.size() < 7 or not piece[6] is Color:
			return


		if piece.size() > 7 and piece[7] is String and piece[7] != "":
			match piece[7]:
				"top", "sleeve", "trim":
					piece[6] = gown
				"legs":
					piece[6] = pyjamas
			continue
		var size: Vector3 = piece[5] if piece[5] is Vector3 else Vector3.ONE
		var thin: = size.y < 0.5 * body.scale
		match int(piece[1]):
			Townsfolk.ROLE_NONE:
				if not torso_done and int(piece[0]) == Figure.BOX and not thin:
					piece[6] = gown
					torso_done = true
			Townsfolk.ROLE_ARM, Townsfolk.ROLE_HAND:
				if not thin:
					piece[6] = gown
			Townsfolk.ROLE_LEG:
				if not thin:
					piece[6] = pyjamas






func _phones(folk: Townsfolk) -> void :
	var used: = 0
	if folk != null and Game.night and not Game.incident.is_empty():
		var camera: = get_viewport().get_camera_3d()
		for id: int in folk.bodies:
			if used >= PHONES:
				break
			var body: Townsfolk.Body = folk.bodies[id]
			if body == null or not body.built or body.yaw == null or body.person.shown_state != "watch":
				continue

			if posmod(body.person.seed, 4) != 1 or body.gesture < 1.5:
				continue
			if camera != null and camera.global_position.distance_to(body.head_at) > 140.0:
				continue
			var turn: = Basis(Vector3.UP, float(body.yaw))
			var ahead: = turn * Vector3(0, 0, -1)
			var right: = turn * Vector3(1, 0, 0)
			var screen: = _screens[used]
			var spot: Vector3 = body.head_at + ahead * 1.25 * body.scale + right * 0.75 * body.scale + Vector3(0, 0.25, 0)

			screen.global_transform = Transform3D(Basis.looking_at(ahead), spot)
			screen.visible = true
			used += 1
	for index in range(used, _screens.size()):
		_screens[index].visible = false





func _press(at: Variant) -> void :
	var big: bool = at is Vector3 and Game.incident.get("kind", "fire") == "fire" and int(Game.incident.get("flames", 0)) >= big_fire
	if _photographer != null and ( not at is Vector3 or (at as Vector3).distance_to(_photo_for) > 1.0):
		_photographer.queue_free()
		_photographer = null
		_photo_for = Vector3.INF
	if _photographer != null or not big:
		return
	var spot: = _press_spot(at)
	if spot.is_empty():
		return
	_photo_for = at
	_photographer = Node3D.new()
	_photographer.name = "Photographer"
	_photographer.top_level = true
	add_child(_photographer)
	var body: = FirefighterRig.new()
	body.with_kit = false
	body.springs = false
	body.outfit = {"civil": true}
	_photographer.add_child(body)

	body.extras["camera"] = {"ShoulderR": Vector3(1.9, 0, 0), "ElbowR": Vector3(0.36, 0, 0)}
	var eyes: = FirefighterRig.HEAD_HEIGHT + 0.1
	var face: Vector3 = (at as Vector3) - spot["at"]
	face.y = 0.0
	_photographer.global_transform = Transform3D(Basis.looking_at(face.normalized() if face.length() > 0.1 else Vector3.FORWARD), spot["at"])
	_camera_box = MeshInstance3D.new()
	var box: = BoxMesh.new()
	box.size = Vector3(0.7, 0.45, 0.4)
	_camera_box.mesh = box
	var black: = StandardMaterial3D.new()
	black.albedo_color = Color8(24, 24, 26)
	_camera_box.material_override = black
	if body.hand_right != null:
		body.hand_right.add_child(_camera_box)
	else:
		_camera_box.position = Vector3(0, eyes, -1.0)
		_photographer.add_child(_camera_box)
	_flash = OmniLight3D.new()
	_flash.light_color = Color(0.95, 0.97, 1.0)
	_flash.omni_range = 30.0
	_flash.light_energy = 0.0
	_flash.position = Vector3(0, 0.2, -0.4)
	_camera_box.add_child(_flash)
	_flash_card = MeshInstance3D.new()
	var card: = QuadMesh.new()
	card.size = Vector2(1.6, 1.6)
	var white: = StandardMaterial3D.new()
	white.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	white.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	white.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	white.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	white.albedo_texture = Assets.texture("water_mist")
	white.albedo_color = Color(1, 1, 1, 1)
	card.material = white
	_flash_card.mesh = card
	_flash_card.position = Vector3(0, 0.2, -0.35)
	_flash_card.visible = false
	_camera_box.add_child(_flash_card)





func _press_spot(at: Vector3) -> Dictionary:
	var graph: = NavGraph.current
	if graph == null:
		return {}
	var band: Vector2 = Config.Life["WatchBand"]
	var bearing: = fposmod(at.x * 0.37 + at.z * 0.61, TAU)
	var best: Dictionary = {}
	var best_turn: = INF
	for node: Dictionary in graph.walk:
		var offset: = Vector2(float(node["x"]) - at.x, float(node["z"]) - at.z)
		var far: = offset.length()
		if far < band.x + 6.0 or far > band.y + 10.0:
			continue
		if Bystanders.current and Bystanders.current._in_any_building(node["x"], node["z"]):
			continue
		var turn: = absf(wrapf(atan2(offset.y, offset.x) - bearing, - PI, PI))
		if turn < best_turn:
			best_turn = turn
			best = node
	if best.is_empty():
		return {}
	var ground: = AmbulanceService.current.ground_at(best["x"], best["z"]) if AmbulanceService.current else 0.5
	return {"at": Vector3(best["x"], ground, best["z"])}



func _flashes() -> void :
	if _photographer == null:
		return
	var now: = HostClock.now()
	var slot: = floori(now / FLASH_EVERY)
	var into: = now - slot * FLASH_EVERY

	var taken: = posmod(hash(slot * 31 + int(_photo_for.x)), 5)
	var lit: = (taken >= 1 and into < FLASH_TIME) or (taken >= 3 and into > 0.35 and into < 0.35 + FLASH_TIME)
	_flash.light_energy = 12.0 if lit else 0.0
	_flash_card.visible = lit
