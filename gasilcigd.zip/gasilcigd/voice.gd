extends ProofDebug












func _scenario_voicecodec() -> void :
	await _wait(1.0)
	var samples: = PackedFloat32Array()
	for index in 4000:
		var t: = index / float(TeamRadio.RATE)
		samples.append(0.4 * sin(TAU * 220.0 * t) + 0.2 * sin(TAU * 660.0 * t))
	var state: Array = [0, 0]
	var back: = PackedFloat32Array()
	var packets: Array[PackedByteArray] = []
	for start in range(0, samples.size(), TeamRadio.PACKET):
		var packet: = TeamRadio.encode(samples.slice(start, start + TeamRadio.PACKET), state)
		packets.append(packet)
		back.append_array(TeamRadio.decode(packet))
	_check(packets[0].size() == 3 + TeamRadio.PACKET / 2, "a packet of %d samples is %d bytes" % [TeamRadio.PACKET, packets[0].size()])
	_check(back.size() == samples.size(), "as many samples come back as went in")
	var snr: = _snr(samples, back, 400)
	print("voicecodec: SNR %.1f dB" % snr)
	_check(snr > 18.0, "what comes back is close to what went in (SNR %.1f dB)" % snr)

	var later: = TeamRadio.decode(packets[6])
	var alone: = _snr(samples.slice(6 * TeamRadio.PACKET, 7 * TeamRadio.PACKET), later, 0)
	_check(alone > 18.0, "a packet heard after a lost one is as good (SNR %.1f dB)" % alone)

	var radio: = TeamRadio.current
	_check(radio != null, "the radio is made with the game")
	if radio != null:
		await _hold("talk", 0.6)
		await _wait(0.3)
		_check( not radio.talking and radio.counts["permits"] == 0 and radio.counts["sent"] == 0, "alone the talk key gives no tone and sends nothing (%s)" % [radio.counts])
	_check(InputMap.action_get_events("talk").size() == 2, "the talk key is Alt and the mouse's side button")
	_done()


static func _snr(a: PackedFloat32Array, b: PackedFloat32Array, skip: int) -> float:
	var signal_power: = 0.0
	var noise: = 0.0
	for index in range(skip, mini(a.size(), b.size())):
		signal_power += a[index] * a[index]
		noise += (a[index] - b[index]) * (a[index] - b[index])
	return 10.0 * log(signal_power / maxf(noise, 1e-09)) / log(10.0)


func _scenario_mictest() -> void :
	await _wait(1.0)
	var radio: = TeamRadio.current
	if not _check(radio != null and radio._fake_mic, "the radio, with the stand-in microphone (--voice-test)"):
		await _done()
		return
	var pause: = Hud.current.widgets.get("pause") as HudPause
	pause.show_menu()
	Game.set_paused(false)
	pause.show_tab("sound")
	await _wait(1.5)
	print("mictest: monitoring %s, level %.2f, dead %s" % [radio.monitoring, radio.level, radio.mic_dead])
	_check(radio.monitoring and radio._mic != null, "the sound tab opens the microphone for its test")
	_check(radio.level > 0.3 and not radio.mic_dead, "and shows what it hears (level %.2f)" % radio.level)
	_check(radio.counts["sent"] == 0, "nothing is sent while testing")
	await _snap("sound_tab")

	radio.fake_level = 0.05
	await _wait(4.0)
	print("mictest: quiet: level %.2f, gain %.1f" % [radio.level, radio._gain])
	_check(radio.level > 0.2, "a quiet microphone is brought up to be heard (level %.2f, gain %.1f)" % [radio.level, radio._gain])

	radio.fake_level = 0.0
	radio._close_mic()
	await _wait(float(Config.TeamRadio.DeadAfter) + 1.0)
	print("mictest: silent: level %.2f, dead %s, hint '%s'" % [radio.level, radio.mic_dead, pause._mic_hint.text])
	_check(radio.mic_dead and pause._mic_hint.text == HudPause.word("micSilent"), "a silent microphone is told under the test")
	await _snap("silent")
	pause.close()
	await _wait(0.5)
	_check( not radio.monitoring and radio._mic == null, "the menu put away: the test stops and the microphone is off")

	var devices: = Settings.mic_devices()
	print("mictest: microphones %s" % [devices])
	_check(devices[0] == "" and devices.size() == AudioServer.get_input_device_list().size(), "the microphones to choose from: the default and each by name")
	for index in devices.size():
		Settings.next_mic_device()
	_check(Settings.mic_device == "" and AudioServer.input_device == "Default", "chosen round, back at the default")
	await _done()


func _scenario_voice() -> void :
	var radio: = TeamRadio.current
	var deadline: = Time.get_ticks_msec() + 40000
	while Net.players.size() < 2 and Time.get_ticks_msec() < deadline:
		await _wait(0.2)
	if not _check(Net.players.size() >= 2, "the crew came together"):
		_done()
		return
	if Net.is_host():
		await _wait(4.0)
		await get_tree().process_frame
		Input.action_press("talk")
		await _wait(0.5)
		_check(radio.talking and TeamRadio.is_on_air(player), "the talk key held: on the air")
		await _snap("host_talking")
		await _wait(2.5)
		print("voice: host level %.2f, sent %d" % [radio.level, radio.counts["sent"]])
		_check(radio.counts["sent"] >= 40 and radio.level > 0.05, "the voice goes out (%d packets, level %.2f)" % [radio.counts["sent"], radio.level])
		Input.action_release("talk")
		await _wait(0.5)
		_check( not radio.talking and radio.counts["permits"] == 1 and radio.counts["rogers"] == 1, "its own beeps, key down and key up (%s)" % [radio.counts])

		var waited: = 0.0
		while radio.counts["rogers"] < 2 and waited < 20.0:
			await _wait(0.25)
			waited += 0.25
		print("voice: host heard %s" % [radio.counts])
		_check(radio.counts["heard"] >= 30 and radio.counts["permits"] == 2 and radio.counts["rogers"] == 2, "the host hears the client's call, beeps and all (%s)" % [radio.counts])
		await _wait(2.0)
	else:
		var other: Player = Net.players.get(1)
		var on_air_seen: = false
		var status_seen: = false
		var waited: = 0.0
		var loudest: = -200.0
		var air_since: = -1.0
		while radio.counts["rogers"] < 1 and waited < 25.0:
			await _wait(0.1)
			waited += 0.1
			if other != null and TeamRadio.is_on_air(other) and not on_air_seen:
				on_air_seen = true
				air_since = waited
				status_seen = (NetTalk.status_of(other)[0] as Dictionary).get("k", "") == "talk.status.onRadio"
				await _snap("client_hearing")
			if air_since >= 0.0 and waited - air_since > 0.8 and TeamRadio.is_on_air(other):
				var bus: = AudioServer.get_bus_index(TeamRadio.BUS)
				loudest = maxf(loudest, AudioServer.get_bus_peak_volume_left_db(bus, 0))
		print("voice: client heard %s, the Radio bus at most %.1f dB" % [radio.counts, loudest])
		_check(loudest > -24.0, "the voice is heard out loud on the Radio bus (%.1f dB)" % loudest)
		_check(radio.counts["permits"] == 1, "the talk-permit tone as the host keys up")
		_check(radio.counts["heard"] >= 40, "the host's voice comes through (%d packets)" % radio.counts["heard"])
		_check(radio.counts["rogers"] == 1 and radio.on_air.is_empty(), "the end-of-call beep as the host lets go, and nobody on the air")
		_check(on_air_seen and status_seen, "the host is shown on the radio while talking (HUD, name tag, crew panel)")
		await _wait(1.0)
		await get_tree().process_frame
		Input.action_press("talk")
		await _wait(2.5)
		Input.action_release("talk")
		await _wait(1.0)
		_check(radio.counts["sent"] >= 30, "the client's voice goes out (%d packets)" % radio.counts["sent"])
		await _wait(3.0)
	_done()
