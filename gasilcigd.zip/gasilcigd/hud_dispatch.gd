class_name HudDispatch
extends Control











const KINDS: = {
	"fire": ["flame", Ui.RED], 
	"tree": ["saw", Ui.AMBER], 
	"crash": ["car", Ui.RED], 
	"medical": ["heart", Ui.RED], 
	"flood": ["drop", Ui.BLUE], 
	"rescue": ["ladder", Ui.AMBER], 
	"hazmat": ["warning", Ui.AMBER], 
	"accident": ["spreader", Ui.RED], 
	"alarm": ["flame", Ui.AMBER], 
}
const RADAR: = 210.0
const BANNER: = Vector2(760, 124)
const LEVEL_COLORS: = [Color(0.62, 0.64, 0.6), Color(1.0, 0.55, 0.12), Color(0.88, 0.16, 0.12)]

static var current: HudDispatch

var _card: Control
var _tile_holder: Control
var _tag: Label
var _title: Label
var _place: Label
var _away: Label
var _health: Control
var _count: Label
var _people: Label
var _ladder: Label
var _badge: Panel
var _badge_text: Label
var _alert: Label
var _next: Label
var _banner: Control
var _banner_title: Label
var _banner_place: Label
var _banner_tag: Label
var _width: = 260.0
var _said_next: = ""
var _said_done: = -1
var _kind: = ""
var _last: Dictionary = {}
var _final: Dictionary = {}
var _result_until: = 0.0
var _tag_words: Variant = ""


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_width = float(Config.Hud.CardWidth)
	var text_size: = int(Config.Hud.TextFloor)
	var caps_size: = int(Config.Hud.CapsFloor)
	_card = Ui.plate(Vector2(_width, 98))
	_card.position = Vector2(Ui.MARGIN, Ui.MARGIN + RADAR + 12)
	_card.visible = false
	add_child(_card)
	_tile_holder = Control.new()
	_tile_holder.position = Vector2(8, 8)
	_card.add_child(_tile_holder)
	_tag = _fitted(Ui.display("", 22), Vector2(48, 1), _width - 56)
	_away = _fitted(Ui.caps("", caps_size), Vector2(48, 29), _width - 56)
	_title = _fitted(Ui.label("", text_size + 1), Vector2(8, 50), _width - 16)
	_place = _fitted(Ui.label("", text_size, Ui.DIM), Vector2(8, 70), _width - 16)
	_health = Ui.bar(Vector2(_width - 16, 10), Ui.GREEN)
	_card.add_child(_health)
	_count = _fitted(Ui.caps("", text_size), Vector2(8, 0), _width - 16)
	_people = _fitted(Ui.caps("", text_size), Vector2(8, 0), _width - 16)
	_people.add_theme_color_override("font_color", Ui.AMBER)
	_ladder = _fitted(Ui.caps("", text_size), Vector2(8, 0), _width - 16)
	_ladder.add_theme_color_override("font_color", Ui.AMBER)
	_ladder.visible = false
	_badge = Panel.new()
	_badge.size = Vector2(40, 22)
	_badge.position = Vector2(_width - 46, 6)
	_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_badge.visible = false
	_card.add_child(_badge)
	_badge_text = Ui.display("", 16, Color.WHITE)
	_badge_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_badge_text.size = Vector2(40, 22)
	_badge_text.position = Vector2(0, -1)
	_badge.add_child(_badge_text)
	_alert = _fitted(Ui.display("", text_size + 1, Ui.RED), Vector2(8, 0), _width - 16)
	_alert.visible = false
	_next = Ui.label("", text_size)
	_next.size = Vector2(_width - 16, 20)
	_next.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_next.max_lines_visible = 3
	_next.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_next.add_theme_color_override("font_color", Color(1.0, 0.93, 0.6))
	_next.visible = false
	_card.add_child(_next)

	_banner = Ui.plate(BANNER, "banner")
	_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_banner.position = Vector2( - BANNER.x / 2, 150)
	_banner.visible = false
	add_child(_banner)
	_banner_tag = Ui.caps("", 16)
	_banner_tag.add_theme_color_override("font_color", Color.WHITE)
	_banner_tag.position = Vector2(110, 12)
	_banner.add_child(_banner_tag)
	_banner_title = Ui.display("", 34, Color.WHITE)
	_banner_title.position = Vector2(110, 32)
	_banner_title.size = Vector2(BANNER.x - 130, 48)
	_banner_title.clip_text = true
	_banner_title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_banner.add_child(_banner_title)
	_banner_place = Ui.label("", 20, Color(1, 1, 1, 0.9))
	_banner_place.position = Vector2(110, 82)
	_banner_place.size = Vector2(BANNER.x - 130, 28)
	_banner_place.clip_text = true
	_banner_place.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_banner.add_child(_banner_place)
	Game.incident_changed.connect(_on_incident)
	Game.incident_ending.connect( func(last: Dictionary) -> void : _final = last.duplicate())
	Text.language_changed.connect( func(_code: String) -> void :
		_tag.text = Text.say(_tag_words)
		_banner_tag.text = Text.say(Text.m("hud.dispatch.banner"))
		_show_name(_banner_title, _banner_place, Game.incident.get("name", ""))
	)



func _fitted(label: Label, at: Vector2, width: float) -> Label:
	label.position = at
	label.size = Vector2(width, ceilf(label.get_theme_font("font").get_height(label.get_theme_font_size("font_size"))))
	label.clip_text = true
	label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_card.add_child(label)
	return label



static func split_name(name: Variant) -> PackedStringArray:
	var words: = Text.say(name)
	var cut: = words.find(" · ")
	if cut < 0:
		return PackedStringArray([words, ""])
	return PackedStringArray([words.left(cut), words.substr(cut + 3)])


func _show_name(kind_label: Label, place_label: Label, name: Variant) -> void :
	var parts: = split_name(name)
	kind_label.text = parts[0]
	place_label.text = parts[1]



func card_bottom() -> float:
	return _card.position.y + (_card.size.y if _card.visible else 0.0)



func banner_bottom() -> float:
	if not _banner.visible:
		return -1.0
	return _banner.position.y + _banner.size.y


func _on_incident() -> void :
	var incident: = Game.incident
	if incident.is_empty():
		if not _last.is_empty():
			_show_final(_final if not _final.is_empty() else _last)
		_last = {}
		_final = {}
		return
	var fresh: bool = _last.is_empty() or Text.say(_last.get("name"), "sl") != Text.say(incident.get("name"), "sl")
	_last = incident.duplicate()
	if fresh:
		_kind = incident.get("kind", "fire")
		var look: Array = KINDS.get(_kind, KINDS["fire"])
		for child in _tile_holder.get_children():
			child.queue_free()
		_tile_holder.add_child(Ui.tile(look[0], look[1], 34))
		_tag_words = Text.m("hud.dispatch.kinds.%s.tag" % _kind)
		_tag.text = Text.say(_tag_words)
		_tag.add_theme_color_override("font_color", Ui.TEXT)
		_fit_tag()
		_card.visible = true
		_result_until = 0.0
		_said_next = ""
		_said_done = -1

		for child in _banner.get_children():
			if child.name == "Tile":
				child.queue_free()
		var big: = Ui.tile(look[0], Color(0.1, 0.02, 0.02), 78)
		big.name = "Tile"
		big.position = Vector2(16, 16)
		_banner.add_child(big)
		_banner_tag.text = Text.say(Text.m("hud.dispatch.banner"))
		if incident.has("alarm"):
			_banner_tag.text += "  ·  " + Text.say(Text.f("hud.dispatch.level", [Alarm.numeral(int(incident["alarm"]))]))
		if incident.get("ladder", false):
			_banner_tag.text += "  ·  " + Text.say(Text.m("hud.dispatch.ladderBanner"))
		_show_name(_banner_title, _banner_place, incident.get("name", ""))
		_banner.visible = true
		_banner.modulate.a = 0.0
		var show: = create_tween()
		show.tween_property(_banner, "modulate:a", 1.0, 0.3)
		show.tween_interval(float(Config.Hud.CallOutTime))
		show.tween_property(_banner, "modulate:a", 0.0, 0.4)
		show.tween_callback( func() -> void : _banner.visible = false)


func _process(_delta: float) -> void :
	var incident: = Game.incident
	if incident.is_empty():
		if _card.visible and Game.now() > _result_until:
			_card.visible = false
		return
	_show_name(_title, _place, incident.get("name", ""))
	var player: = Game.local_player
	if player and incident.has("pos"):
		var far: Array = Ui.metres(player.global_position.distance_to(incident["pos"]))
		_away.text = Text.say(Text.f("hud.dispatch.away", far)).to_upper()
	var health: float = incident.get("health", 100.0)
	if incident.has("total") and not incident.has("flames"):

		var jobs: = int(incident.get("done", 0))
		var all: = maxi(int(incident["total"]), 1)
		Ui.set_bar(_health, float(jobs) / all, Ui.GREEN)
		if not incident.has("progress_text"):

			incident["progress_text"] = "%d%%" % int(jobs * 100.0 / all) if all > 99 else "%d/%d" % [jobs, all]
	else:
		Ui.set_bar(_health, health / 100.0, Ui.GREEN if health > 60 else (Ui.AMBER if health > 30 else Ui.RED))
	if incident.has("flames"):
		var burning: = int(incident.get("flames", 0))
		var out: = int(incident.get("flames_out", 0))
		_count.text = Text.say(Text.f("hud.dispatch.out", [out, out + burning]))
	else:
		_count.text = Text.say(incident.get("progress_text", ""))
	var total: = int(incident.get("victims", 0))
	_people.visible = total > 0
	if total > 0:
		_people.text = Text.say(Text.f("hud.dispatch.rescued", [int(incident.get("victims_out", 0)), total]))
		_people.add_theme_color_override("font_color", Ui.AMBER)
	_ladder.visible = bool(incident.get("ladder", false))
	if _ladder.visible:
		_ladder.text = Text.say(Text.m("hud.dispatch.ladder"))
	_lay_out()
	_show_level(int(incident.get("alarm", 0)))
	_fit_tag()
	var alert: Variant = null
	if incident.has("evacuate"):
		alert = Text.f("hud.dispatch.evacuate", [int(incident["evacuate"])])
	elif incident.has("leak"):
		alert = Text.f("hud.dispatch.leak", [int(incident["leak"])])
	elif incident.get("collapsed", false):
		alert = Text.m("hud.dispatch.collapsed")
	_alert.visible = alert != null
	if alert != null:
		_alert.position = Vector2(8, _card.size.y - 4)
		_card.size.y += 24

		_alert.modulate.a = 1.0 if incident.get("collapsed", false) or fmod(Game.now(), 1.0) < 0.7 else 0.35
		_alert.text = Text.say(alert).to_upper()
	var next: Variant = incident.get("next")
	var tasks: Array = incident.get("tasks", []) if incident.get("tasks") is Array else []
	_next.visible = next != null or not tasks.is_empty()
	if _next.visible:
		_next.text = _task_lines(tasks) if not tasks.is_empty() else "→ " + Text.say(next)
		_next.max_lines_visible = 14 if not tasks.is_empty() else 3
		_next.position = Vector2(8, _card.size.y - 4)
		var line: = _next.get_line_height() + 1
		var lines: = mini(_next.get_line_count(), _next.max_lines_visible)
		_next.size = Vector2(_width - 16, line * lines)
		_card.size.y += 6 + line * lines


	var said: String = str(next.get("k", Text.say(next, "sl"))) if next is Dictionary else (Text.say(next, "sl") if next != null else "")
	var done: = int(incident.get("done", 0))

	var jobs_counted: = int(incident.get("total", 0)) <= 99
	if (said != _said_next and not _said_next.is_empty()) or (jobs_counted and _said_done >= 0 and done > _said_done):
		Sounds.ui("ui_tick")
	_said_next = said
	_said_done = done




func _task_lines(tasks: Array) -> String:
	var lines: PackedStringArray = []
	for task: Variant in tasks:
		if task is Dictionary:
			var mark: = "✗ " if task.get("failed", false) else ("✓ " if task.get("done", false) else ("→ " if task.get("next", false) else "•  "))
			lines.append(mark + Text.say(task.get("t", "")))
	return "\n".join(lines)



func _lay_out() -> void :
	_place.visible = not _place.text.is_empty()
	var y: = (_place.position.y + _place.size.y + 4.0) if _place.visible else (_title.position.y + _title.size.y + 4.0)
	_health.position = Vector2(8, y)
	y += 14
	_count.position = Vector2(8, y)
	y += _count.size.y
	if _people.visible:
		_people.position = Vector2(8, y)
		y += _people.size.y
	if _ladder.visible:
		_ladder.position = Vector2(8, y)
		y += _ladder.size.y
	_card.size.y = y + 8



func _show_final(last: Dictionary) -> void :
	var good: bool = float(last.get("health", 100.0)) > 0.0 and not last.get("failed", false)
	_tag_words = Text.m("hud.dispatch.kinds.%s.%s" % [_kind, "good" if good else "bad"])
	_tag.text = Text.say(_tag_words)
	_tag.add_theme_color_override("font_color", Ui.GREEN if good else Ui.RED)
	_fit_tag()
	_show_name(_title, _place, last.get("name", ""))
	_away.text = Text.say(Text.m("hud.dispatch.final")).to_upper()

	_badge.visible = false
	_badge_text.text = ""
	if last.has("flames"):
		var burning: = int(last.get("flames", 0))
		var out: = int(last.get("flames_out", 0))
		var health: = float(last.get("health", 0.0))
		Ui.set_bar(_health, health / 100.0, Ui.GREEN if health > 60 else (Ui.AMBER if health > 30 else Ui.RED))
		_count.text = Text.say(Text.f("hud.dispatch.out", [out, out + burning]))
	else:
		var jobs: = int(last.get("done", 0))
		var all: = maxi(int(last.get("total", 1)), 1)
		Ui.set_bar(_health, float(jobs) / all, Ui.GREEN if good else Ui.AMBER)
		_count.text = Text.say(last.get("progress_text", "%d/%d" % [jobs, all]))
	var total: = int(last.get("victims", 0))
	_people.visible = total > 0
	if total > 0:
		_people.text = Text.say(Text.f("hud.dispatch.peopleFinal", [int(last.get("victims_out", 0)), total, int(last.get("victims_fetched", 0)), int(last.get("victims_lost", 0))]))
		var clean: = int(last.get("victims_fetched", 0)) == 0 and int(last.get("victims_lost", 0)) == 0
		_people.add_theme_color_override("font_color", Ui.GREEN if clean else Ui.AMBER)
	_alert.visible = false
	_ladder.visible = false
	_next.visible = false
	_said_next = ""
	_said_done = -1
	_lay_out()
	_fit_tag()
	_result_until = Game.now() + float(Config.Hud.FinalTime)




func _fit_tag() -> void :
	var room: = _width - 56.0 - (_badge.size.x + 8.0 if _badge.visible else 0.0)
	var wide: = _tag.get_theme_font("font").get_string_size(_tag.text, HORIZONTAL_ALIGNMENT_LEFT, -1, _tag.get_theme_font_size("font_size")).x
	var share: = clampf(room / wide, 0.8, 1.0) if wide > 0.0 else 1.0
	_tag.scale = Vector2(share, share)
	_tag.size.x = room / share
	_tag.position = Vector2(48, 1 + (1.0 - share) * 12.0)



func shown_text() -> String:
	if not _card.visible:
		return ""
	var lines: Array[String] = []
	for label: Label in [_tag, _away, _title, _place, _count, _people, _ladder, _alert, _next]:
		if label.visible and not label.text.is_empty():
			lines.append(label.text)
	return " | ".join(lines)


func _show_level(level: int) -> void :
	_badge.visible = level > 0
	if level <= 0:
		return
	var words: = Alarm.numeral(level)
	if _badge_text.text == words:
		return
	_badge_text.text = words
	var style: = StyleBoxFlat.new()
	style.bg_color = LEVEL_COLORS[clampi(level, 1, 3) - 1]
	style.set_corner_radius_all(4)
	_badge.add_theme_stylebox_override("panel", style)
