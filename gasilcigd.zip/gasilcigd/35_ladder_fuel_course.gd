extends RefCounted



static func start(main: Node) -> void :
	for vehicle in Vehicle.all:
		if vehicle.spec.get("ladder", false) and vehicle.data.has("ladder"):
			var ladder: = LadderService.new(vehicle)
			ladder.name = "LadderService"
			main.add_child(ladder)
			break
	var fuel: = FuelService.new()
	fuel.name = "FuelService"
	main.add_child(fuel)
	var course: = TrainingCourse.new()
	course.name = "TrainingCourse"
	main.add_child(course)

	var breeze: = Breeze.new()
	breeze.name = "Breeze"
	main.add_child(breeze)
	if Hud.current:
		Hud.current.add_widget("ladder", LadderPanel.new())
		Hud.current.add_widget("fuelling", FuellingPlate.new())
