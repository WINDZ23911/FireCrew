class_name Graphics
extends RefCounted








enum {VERY_LOW = -1, LOW, MEDIUM, HIGH}

const VERY_LOW_SCALE: = 0.7
const VERY_LOW_FAR: = 320.0
const VERY_LOW_REACH: = 0.4


const LEVELS: = [
	[0.0, 0, 2, 260.0, false, Viewport.MSAA_DISABLED, 0.6], 
	[80.0, 3, 2, 400.0, true, Viewport.MSAA_2X, 0.8], 
	[130.0, 5, 4, 520.0, true, Viewport.MSAA_2X, 1.0], 
]



const FAR: = [450.0, 560.0, 0.0]


static func far_distance(level: int) -> float:
	return VERY_LOW_FAR if level <= VERY_LOW else FAR[clampi(level, LOW, HIGH)]




static func render_scale() -> float:
	return minf(Settings.render_scale, VERY_LOW_SCALE) if Settings.quality <= VERY_LOW else Settings.render_scale


static func apply(level: int) -> void :
	var settings: Array = LEVELS[clampi(level, LOW, HIGH)]
	var very_low: = level <= VERY_LOW
	var tree: = Engine.get_main_loop() as SceneTree
	if tree:
		tree.root.msaa_3d = settings[5]
		tree.root.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if level == LOW else Viewport.SCREEN_SPACE_AA_DISABLED
		if not Settings._scripted() and DisplayServer.get_name() != "headless":
			tree.root.scaling_3d_scale = render_scale()
	if Sky3D.current:
		Sky3D.current.set_shadows(settings[2], settings[3], settings[4])
		Sky3D.current.set_plain(very_low)
	if World.current:
		World.current.set_reach_scale(VERY_LOW_REACH if very_low else settings[6])
		World.current.set_far(far_distance(level))
	if Grass.current:
		Grass.current.set_growth(settings[0], settings[1])
	if ApronLights.current:
		ApronLights.current.set_level(level)
	WorldMaterials.set_lace()

	RenderingServer.global_shader_parameter_set("cover_taps", 1.0 if level == LOW else 2.0)
	ToonFire.set_level(level)
	VehicleLook.tape_level(level)




static func lamp_shadows() -> bool:
	return Settings.quality > VERY_LOW





static func lamp_shadow(beam: SpotLight3D, wanted: = true) -> void :
	beam.shadow_enabled = wanted and lamp_shadows()
	beam.shadow_bias = 0.1
	beam.shadow_normal_bias = 2.0



static func reflections_on() -> bool:
	return Settings.quality >= HIGH


static func grass(level: int) -> Array:
	var settings: Array = LEVELS[clampi(level, LOW, HIGH)]
	return [settings[0], settings[1]]
