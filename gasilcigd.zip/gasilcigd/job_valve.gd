class_name JobValve
extends CrewJob





func _init() -> void :
	kind = "leak"
	role = "rescue"


func place() -> Vector3:
	var hazmat: = HazmatLeak.current
	return hazmat._leak["at"] if hazmat != null and not hazmat._leak.is_empty() else who.body.global_position


func run() -> bool:
	var hazmat: = HazmatLeak.current
	if hazmat == null or hazmat._leak.is_empty() or not hazmat._leak["leaking"]:
		return fail("crew.say.nothingThere")
	if HazmatLeak.SUBSTANCES[hazmat._leak["substance"]].get("skin", false):
		return fail("crew.say.needSuit")
	if not hazmat._leak.get("cordon", false):
		return fail("crew.say.cordonFirst")
	var held: = who.token()
	if not await CrewWater.wear_set(who):
		return fail("crew.say.noSet")
	CrewKit.free_hands(who)
	var air: = AirService.current

	if air != null and air.sets.has(who.body) and not air.sets[who.body]["mask"]:
		air.move_mask(who.body)
		if not await who.wait(1.2, held):
			return false
	var prompt: Prompt = hazmat._valve_prompt
	if not is_instance_valid(prompt):
		return fail("crew.say.nothingThere")
	if not await CrewKit.press_skilled(who, prompt):
		return fail("crew.say.cannot") if on(held) else false
	return not hazmat._leak.is_empty() and not hazmat._leak["leaking"]
