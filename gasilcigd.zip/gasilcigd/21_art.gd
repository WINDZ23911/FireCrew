extends RefCounted







static func start(main: Node) -> void :
	for made: Node in [FoliageFade.new(), ApronLights.new(), OldTown.new(), TreeKit.new(), ApronWear.new(), CallAddress.new()]:
		made.name = made.get_script().get_global_name()
		main.add_child(made)
