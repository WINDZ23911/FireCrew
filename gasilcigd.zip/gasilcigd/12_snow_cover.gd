extends RefCounted



static func start(main: Node) -> void :
	var cover: = SnowCover.new()
	cover.name = "SnowCover"
	main.add_child(cover)
