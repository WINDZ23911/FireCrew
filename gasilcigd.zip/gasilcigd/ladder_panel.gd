class_name LadderPanel
extends Control




const WIDTH: = 264.0
const HEIGHT: = 324.0
const ROW: = 24.0
const READINGS: = ["raised", "turned", "length", "reach", "basket", "water"]

var _panel: Control
var _values: Dictionary = {}
var _names: Dictionary = {}
var _blocked: Label
var _keys: Label
var _camera_key: Label
var _note: Label
var _title: Label
var _water_lamp: ColorRect
var _sight: Control
var _clock: = 1.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel = Ui.plate(Vector2(WIDTH, HEIGHT))
	_panel.visible = false
	add_child(_panel)
	Ui.stripe(_panel, 90)
	var tile: = Ui.tile("ladder", Ui.RED, 34)
	tile.position = Vector2(12, 14)
	_panel.add_child(tile)
	_title = Ui.display("", 24)
	_title.position = Vector2(56, 12)
	_panel.add_child(_title)

	_water_lamp = ColorRect.new()
	_water_lamp.size = Vector2(12, 12)
	_water_lamp.position = Vector2(WIDTH - 28, 26)
	_water_lamp.color = Ui.INSET
	_water_lamp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_water_lamp)

	var y: = 58.0
	for reading: String in READINGS:
		var caption: = Ui.caps("", 14)
		caption.position = Vector2(16, y + 2)
		_panel.add_child(caption)
		_names[reading] = caption
		var value: = Ui.display("", 18)
		value.position = Vector2(WIDTH - 136, y - 2)
		value.size = Vector2(120, ROW)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_panel.add_child(value)
		_values[reading] = value
		y += ROW
	_blocked = Ui.label("", 14, Ui.AMBER)
	_blocked.position = Vector2(16, y + 2)
	_blocked.size = Vector2(WIDTH - 32, 20)
	_blocked.clip_text = true
	_panel.add_child(_blocked)
	y += 26
	_keys = Ui.label("", 13, Ui.DIM)
	_keys.position = Vector2(16, y)
	_panel.add_child(_keys)
	_camera_key = Ui.label("", 13, Ui.DIM)
	_camera_key.position = Vector2(16, HEIGHT - 32)
	_panel.add_child(_camera_key)

	_note = Ui.label("", 15, Ui.TEXT)
	_note.position = Vector2(16, 66)
	_note.size = Vector2(WIDTH - 32, 120)
	_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_panel.add_child(_note)


	_sight = Control.new()
	_sight.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_sight.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sight.draw.connect( func() -> void :
		_sight.draw_circle(Vector2.ZERO, 3.0, Color(1, 1, 1, 0.75))
		_sight.draw_arc(Vector2.ZERO, 9.0, 0, TAU, 24, Color(1, 1, 1, 0.35), 1.5)
	)
	_sight.visible = false
	add_child(_sight)



static func metres(studs: float) -> int:
	return int(floorf(studs * float(Config.Hud.MetresPerStud) + 0.5))


func _reading(key: String, unit: String, value: float) -> void :
	_values[key].text = Text.say(Text.f("hud.ladder." + unit, [int(floorf(value + 0.5))]))


func _process(delta: float) -> void :
	var ladder: = LadderService.current
	var player: = Game.local_player
	var shown: = ladder != null and ladder.seated(player)
	_panel.visible = shown
	if not shown:
		_sight.visible = false
		return
	var in_control: = ladder.state == "ready" and ladder.controller == player
	_sight.visible = in_control
	_panel.position = Vector2(Ui.MARGIN, (size.y - HEIGHT) / 2.0)
	_clock += delta
	if _clock < 0.1:
		return
	_clock = 0.0
	_title.text = Text.say(Text.m("hud.ladder.title"))
	for reading: String in READINGS:
		_names[reading].visible = in_control
		_values[reading].visible = in_control
		_names[reading].text = Text.say(Text.m("hud.ladder." + reading))
	_blocked.visible = in_control
	_keys.visible = in_control
	_camera_key.visible = in_control and ladder.at_stand(player)
	_water_lamp.visible = in_control
	_note.visible = not in_control
	if not in_control:
		_note.text = Text.say(Text.m("hud.ladder.otherControls" if ladder.state == "ready" else "hud.ladder.notReady"))
		return
	_reading("raised", "degrees", ladder.elevation)
	_reading("turned", "degrees", ladder.turned)
	_reading("length", "metres", metres(ladder.length()))
	_reading("reach", "metres", metres(ladder.outreach()))
	_reading("basket", "metres", metres(ladder.height()))
	_reading("water", "fed" if ladder.supplied() else "litres", ladder.vehicle.water)
	_blocked.text = Text.say(ladder.blocked)
	_keys.text = Text.say(Text.m("hud.ladder.keys"))
	_camera_key.text = Text.say(Text.m("hud.ladder.keysCamera"))
	_water_lamp.color = Ui.BLUE if ladder.spraying() else Ui.INSET
