class_name HoseDebug
extends Node





var _shots: = ""
var _player: Player


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hose-shots="):
			_shots = arg.substr(13)
	_run.call_deferred()


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false, false, true).timeout


func _snap(tag: String, from: Vector3, at: Vector3) -> void :
	if _shots.is_empty():
		return
	var before: = get_viewport().get_camera_3d()
	var camera: = Camera3D.new()
	get_tree().root.add_child(camera)
	camera.look_at_from_position(from, at)
	camera.current = true
	await _wait(0.5)
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])
	camera.queue_free()
	if before != null:
		before.make_current()


func _say(what: String) -> void :
	var line: Variant = HoseService.current.line_of(_player)
	print("hose: %s | roll %s, holding '%s', line %s, tool %s" % [what, _player.get_attr("HoseRoll"), _player.holding, "held" if line != null else "-", _player.get_attr("Tool")])


func _run() -> void :
	await _wait(2.0)
	CallService.current.hold = true
	_player = Game.local_player
	var hoses: = HoseService.current
	GearService.current._gear_up(_player, null, true)
	await _wait(0.3)
	var rig: Dictionary = hoses.rigs[0]
	var truck: Vehicle = rig["vehicle"]
	var line: Dictionary = {}
	for each: Dictionary in hoses.lines:
		if each["kind"] == "outlet" and is_same(each["rig"], rig):
			line = each
			break
	var outlet: Node3D = line["source"]
	var out: = (outlet.global_position - truck.global_position) * Vector3(1, 0, 1)
	out = out.normalized()
	_player.teleport(outlet.global_position + out * 3.0)
	await _wait(0.4)
	print("hose: %s has %s rolled" % [truck.name, rig["rolls"]])

	hoses._on_outlet(line, _player)
	await _wait(1.1)
	_say("outlet with empty hands")

	hoses._on_roll_line(rig, "attack", _player)
	await _wait(0.6)
	_say("attack hose taken")
	print("hose: rolls left %s" % [rig["rolls"]])
	var side: = _player.global_transform.basis.x
	await _snap("roll", _player.global_position + side * 6.0 + out * 2.0 + Vector3(0, 2.0, 0), _player.global_position + Vector3(0, 0.5, 0))
	hoses._on_outlet(line, _player)
	await _wait(1.1)
	_say("put on at the outlet")

	for step in 12:
		_player.teleport(outlet.global_position + out * (3.0 + step * 2.0))
		await _wait(0.12)
	_player.look_at(_player.global_position + out, Vector3.UP)
	await _wait(0.3)
	hoses._put_down(line, _player)
	await _wait(0.6)
	_say("nozzle put down")
	print("hose: the hose still laid: %s points, %.0f studs" % [line["hose"].points.size() if is_instance_valid(line["hose"]) else -1, line["hose"].length() if is_instance_valid(line["hose"]) else 0.0])
	var down_at: Vector3 = line["down"]["node"].global_position if line.get("down") != null else _player.global_position
	await _snap("down", down_at + out * 6.0 + Vector3(-3, 4, 3), down_at)

	var tools: = ToolService.current
	var halligan: Variant = null
	for item: Dictionary in tools.items:
		if item["name"] == "Halligan bar" and item["holder"] == null:
			halligan = item
			break
	if halligan != null:
		halligan["tool"] = tools._create_tool(halligan)
		tools._give(_player, halligan)
		await _wait(0.4)
		_say("halligan taken with the nozzle down")
		await _snap("tool", _player.global_position + out * 5.0 + Vector3(3, 3, 0), _player.global_position + Vector3(0, 1.5, 0))
		tools.clear_hands(_player)
		await _wait(0.3)

	_player.teleport(down_at + Vector3(0, 0.5, 0) - out * 1.5)
	await _wait(0.3)
	hoses._pick_up(line, _player)
	await _wait(0.4)
	_say("picked up")
	print("hose: the hose's end on the nozzle again: %s" % [is_instance_valid(line["hose"]) and line.get("nozzle") != null and line["hose"].finish == line["nozzle"].hose_in])

	var list: = tools.slots(_player)
	for index in list.size():
		if list[index]["name"] == "Halligan bar":
			tools._on_slot(_player, index, "Halligan bar")
	await _wait(0.4)
	_say("halligan's key pressed with the nozzle in hand")
	print("hose: nozzle on the ground: %s" % [line.get("down") != null])
	tools.clear_hands(_player)
	await _wait(0.2)
	_player.teleport(line["down"]["node"].global_position + Vector3(0, 0.5, 0) - out * 1.5)
	await _wait(0.3)
	hoses._pick_up(line, _player)
	await _wait(0.3)

	list = tools.slots(_player)
	var names: Array = []
	for slot: Dictionary in list:
		names.append(slot["name"])
	print("hose: hotbar with the nozzle in hand: %s" % [names])
	if not _shots.is_empty():
		await _wait(0.5)
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("%s_hotbar.png" % _shots)
	for index in list.size():
		if list[index]["name"] == "Nozzle":
			tools._on_slot(_player, index, "Nozzle")
	await _wait(0.4)
	_say("the nozzle's own key pressed")
	names = []
	for slot: Dictionary in tools.slots(_player):
		names.append(slot["name"])
	print("hose: nozzle on the ground: %s; hotbar now %s" % [line.get("down") != null, names])
	if line.get("down") != null:
		_player.teleport(line["down"]["node"].global_position + Vector3(0, 0.5, 0) - out * 1.5)
		await _wait(0.3)
		hoses._pick_up(line, _player)
		await _wait(0.3)
		_say("picked up again with E")

	hoses._put_down(line, _player)
	await _wait(0.3)
	_player.teleport(outlet.global_position + out * 3.0)
	await _wait(1.1)
	hoses._on_outlet(line, _player)
	await _wait(0.4)
	_say("rolled up at the coupling")
	print("hose: rolls back %s, a nozzle still on the ground: %s" % [rig["rolls"], line.get("down") != null])

	var supply: Dictionary = rig["supply"]
	hoses._on_intake(rig, _player)
	await _wait(1.1)
	print("hose: supply without the roll: %s" % supply["state"])
	hoses._on_roll_line(rig, "supply", _player)
	await _wait(0.3)
	hoses._on_intake(rig, _player)
	await _wait(0.3)
	print("hose: supply with the roll: %s, rolls %s" % [supply["state"], rig["rolls"]])
	hoses.stow_supply(rig)
	await _wait(0.3)
	print("hose: supply stowed, rolls %s" % [rig["rolls"]])
	get_tree().quit()
