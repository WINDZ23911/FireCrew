class_name TitleScreen
extends CanvasLayer



















const DISCORD: = "https://discord.gg/nybr3rzN8R"

const LINEUP: = [
	["blue", "helmetBlue", false], 
	["sand", "helmetSand", false], 
	["", "helmetWhite", false], 
	["", "helmetRed", true], 
	["gold", "helmetGold", false], 
	["redblue", "helmetOrange", false], 
]
const SPACING: = 4.2
const COLUMN_X: = 110.0
const PANEL_WIDTH: = 600.0

const LIST_EVERY: = 8.0

signal started

var _camera: Camera3D
var _angle: = 0.0
var _title: Label
var _town: Label
var _sub: Label
var _play: Button
var _quit: Button
var _crew_item: Button
var _map_item: Button
var _setup_item: Button
var _more: Button
var _maps: Dictionary = {}
var _map_line: Label
var _play_line: Label
var _go: Button
var _name_caption: Label
var _name: LineEdit
var _language_caption: Label
var _languages: Dictionary = {}
var _style_captions: Array[Label] = []
var _styles: Array[Button] = []
var _shift_captions: Array[Label] = []
var _shifts: Array = []
var _shift_lines: Array[Label] = []
var _keys: Label
var _version_line: Label
var _steps: Array = []
var _root: Control
var _column: VBoxContainer
var _menu: VBoxContainer
var _crew_line: Label
var _browse: VBoxContainer
var _create: VBoxContainer
var _servers_caption: Label
var _refresh: Button
var _rows: VBoxContainer
var _crews: Array = []
var _chosen: = ""
var _listing: = false
var _list_clock: = 0.0
var _password_caption: Label
var _password: LineEdit
var _join: Button
var _create_open: Button
var _server_name_caption: Label
var _server_name: LineEdit
var _server_password_caption: Label
var _server_password: LineEdit
var _most_caption: Label
var _most: Dictionary = {}
var _most_chosen: = Net.MAX_CREW
var _start_server: Button
var _to_list: Button
var _status: Label
var _offer: Control
var _offer_title: Label
var _offer_line: Label
var _offer_play: Button
var _offer_skip: Button
var _discord: Button
var _update: Button
var _update_card: PanelContainer
var _update_note: Label
var _update_bar: Control
var _update_gap: Control
var _lead_gap: Control
var _update_pulse: Tween
var _panel: PanelContainer
var _pages: Dictionary = {}
var _page_heads: Dictionary = {}
var _name_rows: Dictionary = {}
var _back: Button
var _page: = ""
var _lineup: Node3D
var _opened_doors: Array[int] = []

var tutorial_wanted: = false



static func word(key: String) -> String:
	return Text.say(Text.m("ui.title." + key))


func _ready() -> void :
	layer = 50
	Game.ui_open = true
	if Hud.current:
		Hud.current.visible = false
	_camera = Camera3D.new()
	_camera.far = 6000.0
	_camera.fov = 40.0
	add_child(_camera)
	_camera.make_current()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_stand_crew()

	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var shade: = TextureRect.new()
	shade.texture = Ui.image("vignette")
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.modulate = Color(0, 0, 0, 0.45)
	_root.add_child(shade)


	var scrim: = TextureRect.new()
	scrim.texture = _scrim()
	scrim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scrim.stretch_mode = TextureRect.STRETCH_SCALE
	scrim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(scrim)
	_hold_clock()

	_column = VBoxContainer.new()
	_column.position = Vector2(COLUMN_X, 92)
	_column.custom_minimum_size = Vector2(560, 0)
	_column.add_theme_constant_override("separation", 6)
	_root.add_child(_column)
	var band: = TextureRect.new()
	band.texture = Ui.image("stripe")
	band.stretch_mode = TextureRect.STRETCH_TILE
	band.custom_minimum_size = Vector2(220, 6)
	band.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_column.add_child(band)

	var lockup: = VBoxContainer.new()
	lockup.add_theme_constant_override("separation", -14)
	_column.add_child(lockup)
	_title = Ui.display("", 104)
	_title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	_title.add_theme_constant_override("shadow_offset_y", 4)
	lockup.add_child(_title)
	_town = Ui.display("", 72)
	_town.add_theme_color_override("font_color", Ui.YELLOW)
	_town.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	_town.add_theme_constant_override("shadow_offset_y", 3)
	lockup.add_child(_town)
	_sub = Ui.label("", 20, Ui.DIM)
	_column.add_child(_sub)
	_lead_gap = _gap(44)
	_column.add_child(_lead_gap)


	_menu = VBoxContainer.new()
	_menu.add_theme_constant_override("separation", 4)
	_column.add_child(_menu)

	_update_card = PanelContainer.new()
	var red: = _box(Ui.RED, 0.94)
	red.content_margin_top = 12
	red.content_margin_bottom = 14
	_update_card.add_theme_stylebox_override("panel", red)
	_update_card.custom_minimum_size = Vector2(420, 0)
	_update_card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_menu.add_child(_update_card)
	var inside: = VBoxContainer.new()
	inside.add_theme_constant_override("separation", 10)
	_update_card.add_child(inside)
	_update_note = Ui.display("", 24)
	_update_note.custom_minimum_size = Vector2(384, 0)
	_update_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inside.add_child(_update_note)
	_update_bar = Ui.bar(Vector2(384, 14), Ui.YELLOW)
	inside.add_child(_update_bar)
	_update = _button("", 30, Vector2(384, 60), true)
	_update.pressed.connect(_on_update_pressed)
	inside.add_child(_update)
	_update_gap = _gap(14)
	_menu.add_child(_update_gap)
	Updater.changed.connect(_show_update)
	_show_update()
	_play = _button("", 38, Vector2(420, 80), true)
	_play.pressed.connect( func() -> void : _open("play"))
	_menu.add_child(_play)
	_menu.add_child(_gap(14))
	_crew_item = _item()
	_crew_item.pressed.connect( func() -> void : _open("crew"))
	_menu.add_child(_crew_item)
	_map_item = _item()
	_map_item.pressed.connect( func() -> void : _open("map"))
	_menu.add_child(_map_item)
	_setup_item = _item()
	_setup_item.pressed.connect( func() -> void : _open("setup"))
	_menu.add_child(_setup_item)
	_quit = _item()
	_quit.pressed.connect( func() -> void : Game.quit())
	_menu.add_child(_quit)

	_menu.add_child(_gap(10))
	_discord = _item(22)
	_discord.tooltip_text = DISCORD
	_discord.add_theme_color_override("font_color", Ui.DIM)
	_discord.pressed.connect( func() -> void : OS.shell_open(DISCORD))
	_menu.add_child(_discord)

	_build_panel()
	_build_steps()
	_build_offer()
	Net.started.connect(_on_net_started)
	Net.join_failed.connect( func() -> void : _status.text = word("failed"))

	Net.join_status.connect( func(said: Variant) -> void : _status.text = Text.say(said))
	Text.language_changed.connect( func(_code: String) -> void : _say())
	_say()
	_play.grab_focus()
	_come_in()








func _stand_crew() -> void :
	var station: = Game.station
	var front: = float(station.front) if station else -50.0
	if station and not Net.is_client():
		for bay in station.doors.size():
			if not station.door_open(bay):
				station.set_door(bay, true)
				_opened_doors.append(bay)
	_lineup = Node3D.new()
	_lineup.name = "Lineup"
	add_child(_lineup)
	var gear: = GearService.current
	var chem: = StandardMaterial3D.new()
	chem.albedo_color = ChemSuit.SUIT_COLOR
	chem.roughness = 0.45
	chem.metallic_specular = 0.6
	var centre: = _lineup_centre()
	var lineup: Array = Edition.data().get("lineup", LINEUP)
	for index in lineup.size():
		var look: Array = lineup[index]
		var sheets: = {"limbs": true, "jacket": true}
		if gear:
			sheets = gear.suit_sheets(null if String(look[0]).is_empty() else look[0])
		sheets[look[1] if gear == null or gear.has_sheet(look[1]) else "helmet"] = true
		var rig: = FirefighterRig.new()
		rig.outfit = sheets
		rig.springs = false
		_lineup.add_child(rig)
		var at: = centre + Vector3((index - (lineup.size() - 1) / 2.0) * SPACING, 0, absf(index - 2.5) * 0.8)
		rig.global_position = _ground(at)

		rig.rotation.y = PI - (index - 2.5) * 0.07
		if look[2]:
			for sheet: String in rig.pieces:
				if sheet.begins_with("jacket") or sheet.begins_with("limbs"):
					for mesh: MeshInstance3D in rig.pieces[sheet]:
						mesh.material_override = chem


func _lineup_centre() -> Vector3:
	var front: = float(Game.station.front) if Game.station else -50.0
	return Vector3(-27.0, 0.0, front + 20.0)


func _ground(at: Vector3) -> Vector3:
	if Game.world == null:
		return at
	var hit: = Game.world.raycast(at + Vector3(0, 40, 0), at - Vector3(0, 80, 0), World.LAYER_SOLID)
	return hit["position"] if not hit.is_empty() else at







func _build_panel() -> void :
	_panel = PanelContainer.new()
	_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_panel.offset_left = - PANEL_WIDTH - 72
	_panel.offset_right = -72
	_panel.offset_top = 92
	_panel.offset_bottom = 92
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(Ui.PANEL.r, Ui.PANEL.g, Ui.PANEL.b, 0.93)
	box.border_color = Ui.YELLOW
	box.border_width_top = 5
	box.set_corner_radius_all(6)
	box.corner_radius_top_left = 0
	box.corner_radius_top_right = 0
	box.content_margin_left = 40
	box.content_margin_right = 40
	box.content_margin_top = 32
	box.content_margin_bottom = 32
	box.shadow_color = Color(0, 0, 0, 0.45)
	box.shadow_size = 24
	_panel.add_theme_stylebox_override("panel", box)
	_panel.visible = false
	_root.add_child(_panel)
	var holder: = VBoxContainer.new()
	holder.add_theme_constant_override("separation", 0)
	_panel.add_child(holder)
	for page: String in ["play", "crew", "map", "setup"]:
		var list: = VBoxContainer.new()
		list.add_theme_constant_override("separation", 10)
		holder.add_child(list)
		_pages[page] = list
		var head: = Ui.display("", 44)
		list.add_child(head)
		_page_heads[page] = head
		if page == "map":
			continue
		var row: = VBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		list.add_child(row)
		_name_rows[page] = row


	_name_caption = Ui.caps("", 15)
	_name = LineEdit.new()
	_name.max_length = 18
	_name.custom_minimum_size = Vector2(0, 52)
	_name.add_theme_font_override("font", Ui.display_font())
	_name.add_theme_font_size_override("font_size", 26)
	_name.add_theme_stylebox_override("normal", _box(Ui.INSET, 0.7))
	_name.add_theme_stylebox_override("focus", _box(Ui.INSET, 1.0, true))
	_name.text = Game.local_player.display_name if Game.local_player else ""



	var play: VBoxContainer = _pages["play"]
	_play_line = Ui.label("", 19, Ui.DIM)
	_play_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	play.add_child(_play_line)
	play.move_child(_play_line, 1)
	play.add_child(_gap(4))
	_style_row(play)
	play.add_child(_gap(4))
	_shift_row(play)
	play.add_child(_gap(10))
	_go = _button("", 30, Vector2(0, 68), true)
	_go.size_flags_horizontal = Control.SIZE_FILL
	_go.pressed.connect(_play_alone)
	play.add_child(_go)


	var map: VBoxContainer = _pages["map"]
	_map_line = Ui.label("", 19, Ui.DIM)
	_map_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	map.add_child(_map_line)
	map.add_child(_gap(4))
	for edition: String in Edition.ALL:
		var button: = _button("", 24, Vector2(0, 64))
		button.size_flags_horizontal = Control.SIZE_FILL
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var open: bool = edition in Edition.AVAILABLE
		button.disabled = not open
		if not open:
			button.modulate.a = 0.45
			button.mouse_default_cursor_shape = Control.CURSOR_FORBIDDEN
		button.pressed.connect( func() -> void :
			if edition != Edition.id() and not Net.active():
				_map_line.text = "…"
				Edition.choose.call_deferred(edition)
			else:
				_open("")
		)
		map.add_child(button)
		_maps[edition] = button


	var crew: VBoxContainer = _pages["crew"]
	_crew_line = Ui.label("", 19, Ui.DIM)
	_crew_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	crew.add_child(_crew_line)
	crew.move_child(_crew_line, 1)
	var air: = _gap(8)
	crew.add_child(air)
	crew.move_child(air, 2)
	crew.add_child(_gap(6))
	_build_browse(crew)
	_build_create(crew)
	_status = Ui.label("", 18, Ui.AMBER)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	crew.add_child(_status)


	var setup: VBoxContainer = _pages["setup"]
	setup.add_child(_gap(4))
	_language_caption = Ui.caps("", 15)
	setup.add_child(_language_caption)
	var languages: = HBoxContainer.new()
	languages.add_theme_constant_override("separation", 10)
	setup.add_child(languages)
	for code: String in Text.LANGUAGES:
		var button: = _choice(Text.say(Text.m("ui.languageNames." + code)), 20)
		button.pressed.connect( func() -> void : Settings.set_language(code))
		languages.add_child(button)
		_languages[code] = button


	setup.add_child(_gap(10))
	_more = _button("", 22, Vector2(0, 54))
	_more.size_flags_horizontal = Control.SIZE_FILL
	_more.pressed.connect(_open_full_menu)
	setup.add_child(_more)

	holder.add_child(_gap(18))
	_back = _item()
	_back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_back.pressed.connect( func() -> void : _open(""))
	holder.add_child(_back)




func _style_row(page: VBoxContainer) -> void :
	var caption: = Ui.caps("", 15)
	page.add_child(caption)
	_style_captions.append(caption)
	var styles: = HBoxContainer.new()
	styles.add_theme_constant_override("separation", 10)
	page.add_child(styles)
	for style in [Style.SUMMER, Style.WINTER]:
		var button: = _choice("")
		button.pressed.connect( func() -> void :
			Settings.set_style(style)
			_hold_clock()
			_say()
		)
		styles.add_child(button)
		_styles.append(button)






func _shift_row(page: VBoxContainer, with_line: = true) -> void :
	var caption: = Ui.caps("", 15)
	page.add_child(caption)
	_shift_captions.append(caption)
	var shifts: = HBoxContainer.new()
	shifts.add_theme_constant_override("separation", 10)
	page.add_child(shifts)
	for shift: String in Shift.NAMES:
		var button: = _choice("", 20)
		button.pressed.connect( func() -> void :
			Shift.choose(shift, false)
			_say()
		)
		shifts.add_child(button)
		_shifts.append([shift, button])
	if not with_line:
		return
	var line: = Ui.label("", 16, Ui.DIM)
	line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(line)
	_shift_lines.append(line)




func _build_browse(crew: VBoxContainer) -> void :
	_browse = VBoxContainer.new()
	_browse.add_theme_constant_override("separation", 10)
	crew.add_child(_browse)
	var head: = HBoxContainer.new()
	_browse.add_child(head)
	_servers_caption = Ui.caps("", 15)
	_servers_caption.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_servers_caption.size_flags_vertical = Control.SIZE_SHRINK_END
	head.add_child(_servers_caption)
	_refresh = _button("", 16, Vector2(0, 36))
	_refresh.pressed.connect(_read_list)
	head.add_child(_refresh)
	var scroll: = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 236)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var well: = PanelContainer.new()
	well.add_theme_stylebox_override("panel", _box(Ui.INSET, 0.35))
	_browse.add_child(well)
	well.add_child(scroll)
	_rows = VBoxContainer.new()
	_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_rows.add_theme_constant_override("separation", 6)
	scroll.add_child(_rows)
	_password_caption = Ui.caps("", 15)
	_browse.add_child(_password_caption)
	_password = _field(true)
	_password.text_submitted.connect( func(_text: String) -> void : _join_crew())
	_browse.add_child(_password)
	_join = _button("", 26, Vector2(0, 60), true)
	_join.size_flags_horizontal = Control.SIZE_FILL
	_join.pressed.connect(_join_crew)
	_browse.add_child(_join)
	_browse.add_child(_gap(4))
	_create_open = _button("", 22, Vector2(0, 54))
	_create_open.size_flags_horizontal = Control.SIZE_FILL
	_create_open.pressed.connect( func() -> void : _show_create(true))
	_browse.add_child(_create_open)
	_show_password()




func _build_create(crew: VBoxContainer) -> void :
	_create = VBoxContainer.new()
	_create.add_theme_constant_override("separation", 7)
	_create.visible = false
	crew.add_child(_create)
	_server_name_caption = Ui.caps("", 15)
	_create.add_child(_server_name_caption)
	_server_name = _field()
	_server_name.max_length = 32
	_create.add_child(_server_name)
	_create.add_child(_gap(4))
	_server_password_caption = Ui.caps("", 15)
	_create.add_child(_server_password_caption)
	_server_password = _field(true)
	_server_password.max_length = 64
	_create.add_child(_server_password)
	_create.add_child(_gap(4))
	_most_caption = Ui.caps("", 15)
	_create.add_child(_most_caption)
	var most: = HBoxContainer.new()
	most.add_theme_constant_override("separation", 10)
	_create.add_child(most)
	for count in range(2, Net.MAX_CREW + 1):
		var button: = _choice(str(count), 22)
		button.pressed.connect( func() -> void :
			_most_chosen = count
			_say()
		)
		most.add_child(button)
		_most[count] = button
	_create.add_child(_gap(4))
	_style_row(_create)
	_create.add_child(_gap(4))
	_shift_row(_create, false)
	_create.add_child(_gap(6))
	_start_server = _button("", 26, Vector2(0, 60), true)
	_start_server.size_flags_horizontal = Control.SIZE_FILL
	_start_server.pressed.connect(_host_crew)
	_create.add_child(_start_server)
	_to_list = _item(22)
	_to_list.pressed.connect( func() -> void : _show_create(false))
	_create.add_child(_to_list)



func _field(secret: = false) -> LineEdit:
	var field: = LineEdit.new()
	field.custom_minimum_size = Vector2(0, 52)
	field.secret = secret
	field.add_theme_font_override("font", Ui.label_font())
	field.add_theme_font_size_override("font_size", 21)
	field.add_theme_stylebox_override("normal", _box(Ui.INSET, 0.7))
	field.add_theme_stylebox_override("focus", _box(Ui.INSET, 1.0, true))
	return field



func _show_create(shown: bool) -> void :
	Sounds.ui("ui_click")
	_browse.visible = not shown
	_create.visible = shown
	_status.text = ""
	if shown:
		if _server_name.text.strip_edges().is_empty():
			_take_name()
			_server_name.text = Net.crew_name if not Net.crew_name.is_empty() else Net.default_crew_name()
		_server_name.grab_focus()
	else:
		_read_list()
		_create_open.grab_focus()



func _read_list() -> void :
	if _listing:
		return
	_listing = true
	_list_clock = 0.0
	if _crews.is_empty():
		_status.text = word("looking")
	var read: Dictionary = await Net.crew_list.fetch(Net.base_version())
	_listing = false
	if not is_inside_tree():
		return
	_crews = read["crews"]
	if not read["ok"]:
		_status.text = word("offline")
	elif _crews.is_empty():
		_status.text = word("none")
	elif _status.text == word("looking") or _status.text == word("offline") or _status.text == word("none"):
		_status.text = ""
	_show_rows()


func _show_rows() -> void :
	for row in _rows.get_children():
		row.queue_free()
	var still_there: = false
	for crew: Dictionary in _crews:
		var id: = str(crew.get("id", ""))
		still_there = still_there or id == _chosen
		_rows.add_child(_row(crew, id == _chosen))
	if not still_there:
		_chosen = ""
	_show_password()




func _row(crew: Dictionary, chosen: bool) -> Button:
	var row: = Button.new()
	row.custom_minimum_size = Vector2(0, 52)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_theme_stylebox_override("normal", _box(Ui.INSET, 1.0 if chosen else 0.55, chosen))
	row.add_theme_stylebox_override("hover", _box(Ui.INSET, 1.0, chosen))
	row.add_theme_stylebox_override("pressed", _box(Ui.INSET, 1.0, true))
	row.add_theme_stylebox_override("focus", _box(Ui.INSET, 1.0, true))
	_sounds(row)
	var line: = HBoxContainer.new()
	line.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	line.offset_left = 16
	line.offset_right = -16
	line.add_theme_constant_override("separation", 12)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(line)
	var name_label: = Ui.display(str(crew.get("name", "")), 22, Ui.YELLOW if chosen else Ui.TEXT)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	name_label.clip_text = true
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_child(name_label)
	var bits: Array[String] = []
	if bool(crew.get("locked", false)):
		bits.append("🔒")
	var map: = str(crew.get("map", ""))
	if map != Edition.id() and map in Edition.ALL:
		bits.append(word("maps." + map).get_slice(",", 0))
	var players: = int(crew.get("players", 0))
	var most: = int(crew.get("max", Net.MAX_CREW))
	bits.append(word("full_row") if players >= most else word("players") % [players, most])
	var right: = Ui.label("  ·  ".join(bits), 17, Ui.DIM)
	right.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_child(right)
	var id: = str(crew.get("id", ""))
	row.pressed.connect( func() -> void :
		if _chosen == id:
			_join_crew()
			return
		Sounds.ui("ui_click")
		_chosen = id
		_status.text = ""
		_show_rows()
		if _password.visible:
			_password.grab_focus()
	)
	return row



func _chosen_crew() -> Dictionary:
	for crew: Dictionary in _crews:
		if str(crew.get("id", "")) == _chosen:
			return crew
	return {}



func _show_password() -> void :
	var crew: = _chosen_crew()
	var locked: = bool(crew.get("locked", false))
	_password.visible = locked
	_password_caption.visible = locked
	if not locked:
		_password.text = ""
	_join.disabled = crew.is_empty()
	var map: = str(crew.get("map", Edition.id()))
	if not crew.is_empty() and map != Edition.id() and map in Edition.ALL:
		_status.text = word("other_map") % word("maps." + map)




func _open_full_menu() -> void :
	var menu: = HudPause.current
	if menu == null:
		return
	Sounds.ui("ui_click")
	menu.show_over_title(self)



func _build_steps() -> void :
	var strip: = PanelContainer.new()
	strip.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	strip.grow_vertical = Control.GROW_DIRECTION_BEGIN
	strip.offset_top = 0
	strip.offset_bottom = 0
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var shade_box: = StyleBoxTexture.new()
	shade_box.texture = _floor_shade()
	shade_box.content_margin_left = COLUMN_X
	shade_box.content_margin_right = COLUMN_X
	shade_box.content_margin_top = 40
	shade_box.content_margin_bottom = 26
	strip.add_theme_stylebox_override("panel", shade_box)
	_root.add_child(strip)
	var foot: = VBoxContainer.new()
	foot.add_theme_constant_override("separation", 12)
	foot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	strip.add_child(foot)
	var how: = HBoxContainer.new()
	how.add_theme_constant_override("separation", 44)
	foot.add_child(how)
	for step in 3:
		var card: = HBoxContainer.new()
		card.add_theme_constant_override("separation", 12)
		how.add_child(card)
		var number: = Ui.display(str(step + 1), 36)
		number.add_theme_color_override("font_color", Ui.YELLOW)
		card.add_child(number)
		var lines: = VBoxContainer.new()
		lines.add_theme_constant_override("separation", 0)
		card.add_child(lines)
		var head: = Ui.display("", 19)
		head.uppercase = true
		var line: = Ui.label("", 15, Ui.DIM)
		lines.add_child(head)
		lines.add_child(line)
		_steps.append([head, line])
	_keys = Ui.label("", 17, Ui.DIM)
	_keys.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	foot.add_child(_keys)
	_version_line = Ui.label("", 17, Ui.DIM)
	_version_line.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_version_line.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_version_line.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_version_line.offset_left = 0
	_version_line.offset_top = 0
	_version_line.offset_right = -48
	_version_line.offset_bottom = -26
	_version_line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_version_line)



func _come_in() -> void :
	_root.modulate.a = 0.0
	var tween: = create_tween().set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tween.tween_property(_root, "modulate:a", 1.0, 0.7)
	_column.position.x = COLUMN_X - 40.0
	var slide: = create_tween().set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	slide.tween_property(_column, "position:x", COLUMN_X, 0.8)
	var delay: = 0.25
	for child in _menu.get_children():
		var control: = child as Control
		if control == null:
			continue
		control.modulate.a = 0.0
		var each: = create_tween()
		each.tween_interval(delay)
		each.tween_property(control, "modulate:a", 1.0, 0.35)
		delay += 0.07



func _open(page: String) -> void :
	if page == _page:
		page = ""
	_page = page
	Sounds.ui("ui_click")
	for key: String in _pages:
		_pages[key].visible = key == page
	if page.is_empty():
		var out: = create_tween().set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_CUBIC)
		out.tween_property(_panel, "modulate:a", 0.0, 0.15)
		out.tween_callback( func() -> void : _panel.visible = false)
		_play.grab_focus()
	else:

		if _name.get_parent():
			_name.get_parent().remove_child(_name)
			_name_caption.get_parent().remove_child(_name_caption)
		if _name_rows.has(page):
			_name_rows[page].add_child(_name_caption)
			_name_rows[page].add_child(_name)
		_panel.visible = true
		_panel.modulate.a = 0.0
		var left: = _panel.offset_left
		_panel.offset_left = left + 40.0
		_panel.offset_right = -72.0 + 40.0
		var tween: = create_tween().set_parallel().set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
		tween.tween_property(_panel, "modulate:a", 1.0, 0.25)
		tween.tween_property(_panel, "offset_left", left, 0.3)
		tween.tween_property(_panel, "offset_right", -72.0, 0.3)
		if page == "crew":
			_show_create(false)
		elif page == "play":
			_go.grab_focus()
		elif page == "map":
			(_maps[Edition.id()] as Button).grab_focus()
		else:
			(_languages[Text.language] as Button).grab_focus()
	_mark_items()



func _mark_items() -> void :
	for pair in [[_crew_item, "crew"], [_map_item, "map"], [_setup_item, "setup"]]:
		var item: Button = pair[0]
		var open: bool = _page == pair[1]
		item.add_theme_stylebox_override("normal", _item_box(open))
		item.add_theme_color_override("font_color", Ui.YELLOW if open else Ui.TEXT)




func _hold_clock() -> void :

	if ApronLights.current:
		ApronLights.current.set_fill(true)
	var sky: = Sky3D.current
	if sky == null or Net.is_client():
		return
	sky.running = false
	if not sky.hour_given:
		sky.set_hour(Sky3D.start_hour())



static func _scrim() -> GradientTexture2D:
	var gradient: = Gradient.new()
	var dark: = float(Config.Art.Title.Scrim)
	gradient.set_color(0, Color(0.03, 0.035, 0.05, dark))
	gradient.set_color(1, Color(0.03, 0.035, 0.05, 0.0))
	gradient.add_point(0.36, Color(0.03, 0.035, 0.05, dark * 0.92))
	gradient.add_point(0.55, Color(0.03, 0.035, 0.05, dark * 0.6))
	var texture: = GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill_from = Vector2(0, 0)
	texture.fill_to = Vector2(0.62, 0)
	texture.width = 256
	texture.height = 4
	return texture



static func _floor_shade() -> GradientTexture2D:
	var gradient: = Gradient.new()
	gradient.set_color(0, Color(0.03, 0.035, 0.05, 0.0))
	gradient.set_color(1, Color(0.03, 0.035, 0.05, 0.85))
	gradient.add_point(0.45, Color(0.03, 0.035, 0.05, 0.6))
	var texture: = GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill_from = Vector2(0, 0)
	texture.fill_to = Vector2(0, 1)
	texture.width = 4
	texture.height = 128
	return texture


func _gap(height: float) -> Control:
	var gap: = Control.new()
	gap.custom_minimum_size = Vector2(0, height)
	return gap


static func _box(color: Color, alpha: float, edged: = false) -> StyleBoxFlat:
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(color.r, color.g, color.b, alpha)
	box.set_corner_radius_all(6)
	box.content_margin_left = 18
	box.content_margin_right = 18
	if edged:
		box.border_color = Ui.YELLOW
		box.set_border_width_all(2)
	return box




static func _item_box(lit: bool) -> StyleBoxFlat:
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(Ui.PANEL.r, Ui.PANEL.g, Ui.PANEL.b, 0.7 if lit else 0.0)
	box.border_color = Ui.YELLOW
	box.border_width_left = 6 if lit else 0
	box.content_margin_left = 24 if lit else 18
	box.content_margin_right = 18
	return box


func _item(size: = 30) -> Button:
	var button: = Button.new()
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.custom_minimum_size = Vector2(420, 54 if size >= 30 else 40)
	button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	button.add_theme_font_override("font", Ui.display_font())
	button.add_theme_font_size_override("font_size", size)
	button.add_theme_color_override("font_color", Ui.TEXT)
	button.add_theme_color_override("font_hover_color", Ui.YELLOW)
	button.add_theme_color_override("font_focus_color", Ui.YELLOW)
	button.add_theme_color_override("font_pressed_color", Ui.YELLOW)
	button.add_theme_color_override("font_hover_pressed_color", Ui.YELLOW)
	button.add_theme_stylebox_override("normal", _item_box(false))
	button.add_theme_stylebox_override("hover", _item_box(true))
	button.add_theme_stylebox_override("pressed", _item_box(true))
	button.add_theme_stylebox_override("focus", _item_box(true))
	_sounds(button)
	return button



func _choice(text: String, size: = 22) -> Button:
	var button: = _button(text, size, Vector2(0, 50))
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return button


func _button(text: String, size: int, minimum: Vector2, strong: = false) -> Button:
	var button: = Button.new()
	button.text = text
	button.custom_minimum_size = minimum
	button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	button.add_theme_font_override("font", Ui.display_font())
	button.add_theme_font_size_override("font_size", size)
	button.add_theme_color_override("font_color", Ui.DARK if strong else Ui.TEXT)
	button.add_theme_color_override("font_hover_color", Ui.DARK if strong else Ui.YELLOW)
	button.add_theme_color_override("font_pressed_color", Ui.DARK)
	button.add_theme_color_override("font_focus_color", Ui.DARK if strong else Ui.TEXT)
	button.add_theme_stylebox_override("normal", _box(Ui.YELLOW if strong else Ui.INSET, 1.0 if strong else 0.7))
	button.add_theme_stylebox_override("hover", _box(Ui.YELLOW.lightened(0.25) if strong else Ui.INSET, 1.0))
	button.add_theme_stylebox_override("pressed", _box(Ui.YELLOW, 1.0))
	button.add_theme_stylebox_override("focus", _box(Ui.YELLOW.lightened(0.25) if strong else Ui.INSET, 1.0, not strong))
	_sounds(button)
	return button



func _sounds(button: Button) -> void :
	button.mouse_entered.connect( func() -> void :
		if not button.disabled:
			Sounds.ui("ui_hover", 1.0, 0.5)
	)
	button.focus_entered.connect( func() -> void :
		if not button.is_hovered():
			Sounds.ui("ui_hover", 1.0, 0.5)
	)


func _say() -> void :


	var defaults: Array[String] = []
	for code: String in Text.LANGUAGES:
		defaults.append(Text.say(Text.m("world.defaultName"), code))
	if Game.local_player and Game.local_player.display_name in defaults:
		Game.local_player.display_name = PlayerData.default_name()
	if _name and _name.text.strip_edges() in defaults:
		_name.text = PlayerData.default_name()
	_title.text = Text.say(Text.m("world.title.lockupName"))
	_town.text = Text.say(Text.m("world.title.lockupTown"))
	_sub.text = Text.say(Text.m("world.title.lockupLine"))
	_play.text = word("play")
	_quit.text = word("quit")
	_discord.text = word("discord")
	_show_update()
	_crew_item.text = word("crew_menu")
	_map_item.text = word("select_map")
	_setup_item.text = word("setup")
	_back.text = "‹  " + word("back")
	_page_heads["play"].text = word("play")
	_page_heads["crew"].text = word("crew_menu")
	_page_heads["map"].text = word("select_map")
	_page_heads["setup"].text = word("setup")
	_crew_line.text = word("crew_line")
	_name_caption.text = word("name")
	_language_caption.text = word("language")
	for caption in _style_captions:
		caption.text = word("style")
	_play_line.text = word("play_line")
	_go.text = word("start")
	_map_line.text = word("map_line")
	_more.text = word("more")
	for edition: String in _maps:
		var open: bool = edition in Edition.AVAILABLE
		var here: = edition == Edition.id()
		_maps[edition].text = word("maps." + edition) + ("" if open else "  ·  " + word("coming_soon")) + ("   ✓" if here else "")
		_maps[edition].add_theme_color_override("font_color", Ui.YELLOW if here else Ui.TEXT)
		_maps[edition].add_theme_color_override("font_disabled_color", Ui.DIM)
	for index in _styles.size():
		var style: = index % 2
		_styles[index].text = word(Style.NAMES[style])
		_styles[index].add_theme_color_override("font_color", Ui.YELLOW if Style.kind == style else Ui.TEXT)
	for caption in _shift_captions:
		caption.text = word("difficulty")
	for pair: Array in _shifts:
		var button: Button = pair[1]
		button.text = Text.say(Shift.words(pair[0])).to_upper()
		button.tooltip_text = Text.say(Shift.detail(pair[0]))
		button.add_theme_color_override("font_color", Ui.YELLOW if Shift.current() == pair[0] else Ui.TEXT)
	for line in _shift_lines:
		line.text = _detail_line()
	_keys.text = word("keys")
	_version_line.text = word("version") % Net.base_version()
	for step in _steps.size():
		_steps[step][0].text = Text.say(Text.m("world.title.step%d" % (step + 1)))
		_steps[step][1].text = Text.say(Text.m("world.title.step%dLine" % (step + 1)))
	_offer_title.text = Text.say(Text.m("onboarding.tutorial.popup.title"))
	_offer_line.text = Text.say(Text.m("onboarding.tutorial.popup.line"))
	_offer_play.text = Text.say(Text.m("onboarding.tutorial.popup.play"))
	_offer_skip.text = Text.say(Text.m("onboarding.tutorial.popup.skip"))
	_servers_caption.text = word("servers")
	_refresh.text = word("refresh")
	_password_caption.text = word("password")
	_join.text = word("join")
	_create_open.text = word("create")
	_server_name_caption.text = word("server_name")
	_server_password_caption.text = word("password_optional")
	_server_password.placeholder_text = word("password_field")
	_most_caption.text = word("max_players")
	for count: int in _most:
		_most[count].add_theme_color_override("font_color", Ui.YELLOW if count == _most_chosen else Ui.TEXT)
	_start_server.text = word("start_server")
	_to_list.text = word("back_to_list")
	for code: String in _languages:
		var chosen: bool = code == Text.language
		_languages[code].add_theme_color_override("font_color", Ui.YELLOW if chosen else Ui.TEXT)



static func _detail_line() -> String:
	var words: = Text.say(Shift.detail())
	return words.left(1).to_upper() + words.substr(1) + "."


func _process(delta: float) -> void :


	_angle += delta * float(Config.Art.Title["Dolly"])
	var centre: = _lineup_centre()
	var side: = -8.5 + sin(_angle * 2.0) * 2.5
	var from: = centre + Vector3(side, 4.6, 40.0 - cos(_angle * 2.0) * 1.5)
	_camera.look_at_from_position(from, centre + Vector3(side - 1.0, 5.0, 0.0))

	if _page == "crew" and _browse.visible and not Net.active():
		_list_clock += delta
		if _list_clock >= LIST_EVERY:
			_read_list()




func _show_update() -> void :
	var state: = Updater.state
	match state:
		"downloading":
			_update_note.text = word("update_downloading") % [Updater.target, roundi(Updater.progress * 100.0)]
			Ui.set_bar(_update_bar, Updater.progress)
		"ready":
			_update_note.text = word("update_ready_note") % Updater.target
			_update.text = word("update_restart")
		"full":
			_update_note.text = word("update_full_note") % Updater.latest
			_update.text = word("update_download")
	var shown: = state in ["downloading", "ready", "full"]
	_update_card.visible = shown
	_update_gap.visible = shown
	_lead_gap.custom_minimum_size.y = 20.0 if shown else 44.0
	_update_bar.visible = state == "downloading"
	_update.visible = state in ["ready", "full"]
	_update.tooltip_text = Updater.download_page if state == "full" else ""
	if _update.visible and not _update_pulse:
		_update_pulse = create_tween().set_loops()
		_update_pulse.tween_property(_update, "modulate", Color(1.25, 1.25, 1.25), 0.6).set_trans(Tween.TRANS_SINE)
		_update_pulse.tween_property(_update, "modulate", Color.WHITE, 0.6).set_trans(Tween.TRANS_SINE)
	elif not _update.visible and _update_pulse:
		_update_pulse.kill()
		_update_pulse = null
		_update.modulate = Color.WHITE


func _on_update_pressed() -> void :
	if Updater.state == "ready" and not Net.active():
		Sounds.ui("ui_click")
		_update.text = "…"
		Edition.restart.call_deferred()
	elif Updater.state == "full":
		OS.shell_open(Updater.download_page)



func _host_crew() -> void :
	_take_name()
	var shown_name: = _server_name.text.strip_edges()
	if shown_name.is_empty():
		_status.text = word("no_name")
		_server_name.grab_focus()
		return
	if Net.host_online(Net.PORT, shown_name, _server_password.text, _most_chosen):

		Net.online.connect(Net.said_code, CONNECT_ONE_SHOT)
		Net.router_opened.connect(_say_router, CONNECT_ONE_SHOT)
		_start()
		Game.notify(word("hosting") % ", ".join(local_addresses()), "good")
	else:
		_status.text = word("no_host")


static func _say_router(address: String) -> void :
	if address.is_valid_ip_address():
		Game.notify(word("router") % address, "good")




func _join_crew() -> void :
	var crew: = _chosen_crew()
	if crew.is_empty():
		_status.text = word("pick")
		return
	if int(crew.get("players", 0)) >= int(crew.get("max", Net.MAX_CREW)):
		_status.text = Text.say(Text.f("talk.join.full", [int(crew.get("max", Net.MAX_CREW))]))
		return
	var password: = _password.text
	if bool(crew.get("locked", false)) and password.is_empty():
		_status.text = word("need_password")
		_password.grab_focus()
		return
	_take_name()
	Sounds.ui("ui_click")
	_status.text = word("joining")
	var code: = str(crew["code"])
	var map: = str(crew.get("map", Edition.id()))
	if map != Edition.id() and map in Edition.ALL:
		PlayerData.save()
		Edition.choose(map, ["--join=" + code, "--crew-password=" + password])
		return
	Net.join_code(code, password)


func _on_net_started() -> void :
	if Net.is_client() and is_inside_tree():
		_start()


func _take_name() -> void :
	var chosen: = _name.text.strip_edges()
	if Game.local_player and not chosen.is_empty():
		Game.local_player.display_name = chosen



static func local_addresses() -> PackedStringArray:
	var found: = PackedStringArray()
	for address in IP.get_local_addresses():
		if address.begins_with("192.168.") or address.begins_with("10.") or (address.begins_with("172.") and address.split(".")[1].to_int() in range(16, 32)):
			found.append(address)
	return found if not found.is_empty() else PackedStringArray(["127.0.0.1"])


func _unhandled_input(event: InputEvent) -> void :
	if HudPause.current != null and HudPause.current.open:
		return
	if _offer.visible:
		if event.is_action_pressed("ui_cancel"):
			_show_offer(false)
			get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("ui_cancel") and not _page.is_empty():
		_open("")
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ui_accept") and _page.is_empty():
		_open("play")



func _play_alone() -> void :
	if Tutorial.offered() and not Net.active():
		Sounds.ui("ui_click")
		_show_offer(true)
	else:
		_start()



func _build_offer() -> void :
	_offer = ColorRect.new()
	(_offer as ColorRect).color = Color(0, 0, 0, 0.55)
	_offer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_offer.visible = false
	_root.add_child(_offer)
	var centre: = CenterContainer.new()
	centre.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_offer.add_child(centre)
	var box: = PanelContainer.new()
	box.custom_minimum_size = Vector2(640, 0)
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(Ui.PANEL.r, Ui.PANEL.g, Ui.PANEL.b, 0.97)
	style.border_color = Ui.YELLOW
	style.border_width_top = 5
	style.set_corner_radius_all(6)
	style.corner_radius_top_left = 0
	style.corner_radius_top_right = 0
	style.content_margin_left = 44
	style.content_margin_right = 44
	style.content_margin_top = 36
	style.content_margin_bottom = 36
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.shadow_size = 28
	box.add_theme_stylebox_override("panel", style)
	centre.add_child(box)
	var column: = VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	box.add_child(column)
	_offer_title = Ui.display("", 44)
	column.add_child(_offer_title)
	_offer_line = Ui.label("", 19, Ui.DIM)
	_offer_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_offer_line.custom_minimum_size = Vector2(552, 0)
	column.add_child(_offer_line)
	column.add_child(_gap(10))
	var row: = HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	column.add_child(row)
	_offer_play = _button("", 28, Vector2(300, 64), true)
	_offer_play.pressed.connect( func() -> void : _offered(true))
	row.add_child(_offer_play)
	_offer_skip = _button("", 24, Vector2(236, 64))
	_offer_skip.pressed.connect( func() -> void : _offered(false))
	row.add_child(_offer_skip)
	_offer_play.focus_neighbor_right = _offer_skip.get_path()
	_offer_skip.focus_neighbor_left = _offer_play.get_path()


func _show_offer(shown: bool) -> void :
	_offer.visible = shown
	if shown:
		_offer.modulate.a = 0.0
		create_tween().tween_property(_offer, "modulate:a", 1.0, 0.2)
		_offer_play.grab_focus()
	else:
		Sounds.ui("ui_click")
		_go.grab_focus()


func _offered(play: bool) -> void :
	Sounds.ui("ui_click")
	tutorial_wanted = play
	_offer.visible = false
	_start()


func _start() -> void :
	var player: = Game.local_player
	if player:
		var chosen: = _name.text.strip_edges()
		if not chosen.is_empty():
			player.display_name = chosen
		PlayerData.save()
		player.camera.camera.make_current()
		player.camera.capture(true)
	Game.ui_open = false
	if Hud.current:
		Hud.current.visible = true
	tutorial_wanted = tutorial_wanted and not Net.active()
	if ApronLights.current:
		ApronLights.current.set_fill(false)

	if Game.station and not Net.is_client():
		for bay in _opened_doors:
			Game.station.set_door(bay, false)




	var sky: = Sky3D.current
	if sky and not sky.hour_given and not Net.is_client() and PlayerData.first_shift_done:
		sky.set_hour(Sky3D.session_hour(int(Time.get_unix_time_from_system())))

	if sky and not OS.get_cmdline_user_args().has("--still"):
		sky.running = true
	started.emit()
	queue_free()
