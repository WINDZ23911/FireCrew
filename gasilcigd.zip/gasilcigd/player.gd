class_name Player
extends CharacterBody3D



signal died
signal rewarded(amount: int, why: String)
signal paid(amount: int)
signal attribute_changed(key: String, value: Variant)
signal seat_changed(seat: Node3D)

const HEIGHT: = 5.2
const RADIUS: = 0.95
const STEP: = 1.7
const STAIR_TIME: = 0.35
const FEET_GRACE: = 0.15
const STEP_EASE: = 16.0
const JUMP: = 50.0

var display_name: = "Firefighter"
var is_local: = true

var brain: Crewman = null
var health: = 100.0
var max_health: = 100.0
var attributes: Dictionary = {}
var rig: FirefighterRig
var camera: PlayerCamera
var seat: Node3D = null
var frozen: = false
var crouching: = false
var walk_speed: = 20.0
var holding: = ""
const PROMPT_KEYS: Array[String] = ["interact", "item", "coupling", "mast"]
var prompts: Dictionary = {}
var prompt: Prompt
var prompt_held: Dictionary = {}


var choices: Array[Prompt] = []
var choice: = 0
var _stepped_to: Prompt = null
var _holding: Dictionary = {}
var _crouch_amount: = 0.0
var _collider: CollisionShape3D
var _last_safe: = Vector3.ZERO
var seat_hold_until: = 0.0
var _net_position: = Vector3.INF
var _net_yaw: = 0.0
var _net_speed: = 0.0
var _net_floor: = true
var _net_crouch: = 0.0
var _net_pitch: = 0.0

var stamina: = 1.0
var sprinting: = false
var _stepped_at: = -10.0
var _step_debt: = 0.0
var _off_floor: = 0.0
var _jumped: = false
var _step_shown: = 0.0
var _rungs_frame: = -10
var _climb_rate: = 0.0
var _net_climb: = -1.0
var _winded: = false
var _rested_for: = 0.0
var _vault: Dictionary = {}
var _rescue_prompt: Prompt


func _init() -> void :
	collision_layer = World.LAYER_PLAYER
	collision_mask = World.LAYER_SOLID | World.LAYER_VEHICLE | World.LAYER_POST
	floor_max_angle = deg_to_rad(50)
	floor_snap_length = 1.2
	_collider = CollisionShape3D.new()
	var capsule: = CapsuleShape3D.new()
	capsule.radius = RADIUS
	capsule.height = HEIGHT
	_collider.shape = capsule
	_collider.position.y = HEIGHT / 2.0
	add_child(_collider)
	rig = FirefighterRig.new()
	rig.name = "Rig"
	add_child(rig)


func _ready() -> void :
	Game.players.append(self)
	if is_local:
		Game.local_player = self
		camera = PlayerCamera.new()
		camera.name = "Camera"
		camera.player = self
		add_child(camera)
	_last_safe = global_position
	if not attributes.has("Geared"):
		set_attr("Geared", true)
	attribute_changed.connect( func(key: String, value: Variant) -> void :
		if key == "Down":
			_offer_rescue(value != null)
	)


func _exit_tree() -> void :
	Game.players.erase(self)


func get_attr(key: String, default: Variant = null) -> Variant:
	return attributes.get(key, default)


func set_attr(key: String, value: Variant) -> void :
	if attributes.get(key) == value:
		return
	if value == null:
		attributes.erase(key)
	else:
		attributes[key] = value
	attribute_changed.emit(key, value)
	if is_local:
		Net.own_attribute_changed(key, value)



func root_position() -> Vector3:
	return global_position + Vector3(0, 3.0, 0)


func head_position() -> Vector3:
	return global_position + Vector3(0, FirefighterRig.HEAD_HEIGHT - _crouch_amount * 1.4, 0)


func facing() -> Vector3:
	return - rig.global_basis.z


func take_damage(amount: float) -> void :
	if health <= 0.0 or amount <= 0.0:
		return
	Alarm.hurt(minf(amount, health))
	health = maxf(0.0, health - amount)
	if health <= 0.0:

		if DownService.current != null and DownService.current.should_go_down(self):
			DownService.current.go_down(self)
			return
		died.emit()
		respawn.call_deferred()



func heat_protection() -> float:
	var kept: = minf(float(Config.Gear.HeatProtection) * Training.factor(self, "heat"), 0.95) if get_attr("Geared", false) else 0.0

	return kept * 0.5 if get_attr("ChemSuit", false) == true else kept








func add_cash(amount: int, why: = "", scaled: = false, item: = "") -> void :
	if amount == 0:
		return
	if not scaled:
		amount = Alarm.pay(amount)

	if brain != null:
		var lead: = CallKit.payee(self)
		if lead != null and lead != self:
			lead.add_cash(amount, why, true, item)
		return
	if amount > 0:



		if Alarm.active:
			set_attr("Pending", int(get_attr("Pending", 0)) + amount)
		else:
			set_attr("Cash", int(get_attr("Cash", 0)) + amount)
		Alarm.earn(self, amount, item if not item.is_empty() else (why if not why.is_empty() else "work"))
		rewarded.emit(amount, why)
		return

	var pending: = int(get_attr("Pending", 0))
	var from_pending: = mini(pending, - amount)
	if from_pending > 0:
		set_attr("Pending", pending - from_pending)
	set_attr("Cash", maxi(int(get_attr("Cash", 0)) + amount + from_pending, 0))



func settle_pay() -> int:
	var pending: = int(get_attr("Pending", 0))
	if pending <= 0:
		return 0
	set_attr("Pending", 0)
	set_attr("Cash", int(get_attr("Cash", 0)) + pending)
	paid.emit(pending)
	return pending





func add_points(points: int) -> void :
	if brain != null or points == 0:
		return
	set_attr("Saved", maxi(int(get_attr("Saved", 0)) + points, 0))


func heal(amount: float) -> void :
	health = minf(max_health, health + amount)



func respawn(at: = Vector3.INF) -> void :
	leave_seat()
	health = max_health
	velocity = Vector3.ZERO
	Net.teleport(self, Game.spawn_point() if at == Vector3.INF else at)






func knock_down(seconds: float) -> void :
	if Net.is_client():
		return
	set_attr("Knocked", true)
	frozen = true
	get_tree().create_timer(seconds, false).timeout.connect( func() -> void :
		if is_instance_valid(self):
			set_attr("Knocked", null)
			if get_attr("Down") == null:
				frozen = false
	)



func lying() -> bool:
	return get_attr("Down") != null or get_attr("Knocked") != null



func _offer_rescue(on: bool) -> void :
	if not on:
		if is_instance_valid(_rescue_prompt):
			_rescue_prompt.queue_free()
		_rescue_prompt = null
		return
	if is_instance_valid(_rescue_prompt):
		return
	var offer: = Prompt.new()
	offer.net_id = "down.%d" % Net.peer_of(self)
	offer.key = "interact"
	offer.hold = 1.0
	offer.reach = float(Config.Down.RescueReach)
	offer.object = Text.f("calls.down.object", [display_name])
	offer.action = Text.m("calls.down.drag")
	offer.position = Vector3(0, 1.5, 0)
	offer.condition = func(other: Player) -> bool:
		if other == self or other.get_attr("Down") != null:
			return false
		var by: = DownService.rescuer_of(self)
		offer.action = Text.m("calls.down.letGo" if by == other else "calls.down.drag")
		offer.hold = 0.3 if by == other else 1.0
		return by == null or by == other
	offer.triggered.connect( func(other: Player) -> void :
		if not Net.is_client() and DownService.current != null:
			DownService.current.drag(self, other)
	)
	add_child(offer)
	_rescue_prompt = offer



func _lie(delta: float) -> void :
	var rescuer: Player = DownService.rescuer_of(self) if get_attr("Down") != null else null
	_collider.disabled = rescuer != null
	if rescuer != null and rescuer.is_inside_tree():
		var ahead: = rescuer.facing()
		ahead.y = 0.0
		ahead = ahead.normalized() if ahead.length() > 0.01 else Vector3.FORWARD
		global_position = rescuer.global_position - ahead * 6.6
		rig.rotation.y = rescuer.rig.rotation.y + PI
		velocity = Vector3.ZERO
	elif not is_local and brain == null:
		if _net_position != Vector3.INF:
			global_position = global_position.lerp(_net_position, 1.0 - exp( - delta * 18.0))
	else:
		velocity.x = 0.0
		velocity.z = 0.0
		if not is_on_floor():
			velocity.y -= ProjectSettings.get_setting("physics/3d/default_gravity") * delta
		move_and_slide()
	rig.lying = true
	rig.rotation.x = PI / 2.0
	rig.position.y = 0.7
	rig.speed = 0.0
	rig.on_floor = true
	rig.crouch = 0.0
	rig.hold = ""


func _stand_up() -> void :
	rig.lying = false
	rig.rotation.x = 0.0
	rig.position.y = 0.0
	_collider.disabled = seat != null


func teleport(place: Vector3) -> void :
	global_position = place
	velocity = Vector3.ZERO
	reset_physics_interpolation()


func sit(in_seat: Node3D) -> void :
	seat = in_seat
	_collider.disabled = true
	rig.seated = true
	rig.seat_lift = float(in_seat.get_meta("lift", 0.0))
	rig.seat_stand = bool(in_seat.get_meta("stand", false))
	rig.on_floor = true
	velocity = Vector3.ZERO


func leave_seat(to: = Vector3.INF) -> void :
	if seat == null:
		return
	seat = null
	_collider.disabled = false
	rig.seated = false
	rig.rotation = Vector3.ZERO
	global_rotation = Vector3.ZERO
	if to != Vector3.INF:
		Net.teleport(self, to)
	reset_physics_interpolation()


func _physics_process(delta: float) -> void :
	if seat != null:
		global_transform = seat.global_transform
		rig.rotation = Vector3.ZERO
		rig.speed = 0.0
		return
	if lying():
		_lie(delta)
		return
	if rig.lying:
		_stand_up()
	if not is_local and brain == null:
		_follow_net(delta)
		return
	if on_rungs():
		_on_rungs()
		return
	rig.climbing = false
	var wish: = Vector3.ZERO
	if brain != null and not frozen:
		wish = brain.wish.limit_length(1.0)
		_crouch_amount = move_toward(_crouch_amount, 1.0 if brain.crouch else 0.0, delta / Config.Stance.CrouchTime)
		if brain.jump and is_on_floor() and _crouch_amount < 0.5:
			velocity.y = JUMP
			_jumped = true
		brain.jump = false
	if is_local and not frozen and not Game.ui_open:
		var input: = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		if input.length() > 0.01:
			var yaw: = camera.yaw
			wish = (Basis(Vector3.UP, yaw) * Vector3(input.x, 0, input.y)).normalized() * minf(input.length(), 1.0)
		var held: = Input.is_action_pressed("crouch_hold")
		if Input.is_action_just_pressed("crouch"):
			crouching = not crouching
		_crouch_amount = move_toward(_crouch_amount, 1.0 if (crouching or held) else 0.0, delta / Config.Stance.CrouchTime)
		if Input.is_action_just_pressed("jump") and crouching:

			crouching = false
		elif Input.is_action_just_pressed("jump") and is_on_floor() and _crouch_amount < 0.5:
			if not _try_vault(wish):
				velocity.y = jump_speed()
				_jumped = true
		_breathe(wish, delta)
	if not _vault.is_empty():
		_vaulting(delta)
		return
	wish = _step_to_force(wish)
	var pace: = walk_speed * lerpf(1.0, Config.Stance.CrouchSpeedFactor, _crouch_amount)
	if brain != null:
		pace *= brain.pace
	else:
		pace *= float(Config.Move.Pace) * (float(Config.Move.Sprint) if sprinting else 1.0)
	if Game.now() - _stepped_at < STAIR_TIME:
		pace *= float(Config.Move.StairPace)
	var target: = wish * pace
	var grip: = 14.0 if is_on_floor() else 4.0
	velocity.x = move_toward(velocity.x, target.x, grip * pace * delta)
	velocity.z = move_toward(velocity.z, target.z, grip * pace * delta)
	if not is_on_floor():
		velocity.y -= ProjectSettings.get_setting("physics/3d/default_gravity") * delta

	_step_debt = minf(_step_debt + _step_up(delta), 1.0) if wish.length() > 0.05 else 0.0
	var walked: = Vector2(velocity.x, velocity.z)
	var travel: = walked.length() * delta
	var share: = 1.0
	if _step_debt > 0.0 and travel > 0.0:
		var paid: = minf(travel, _step_debt)
		_step_debt -= paid
		share = 1.0 - paid / travel
		velocity.x *= share
		velocity.z *= share
	var was_on_floor: = is_on_floor()
	move_and_slide()
	if share < 1.0:
		velocity.x = walked.x
		velocity.z = walked.y

	if was_on_floor and not is_on_floor() and not _jumped and velocity.y <= 0.0:
		_step_down()


	if is_on_floor():
		_off_floor = 0.0
		if velocity.y <= 0.0:
			_jumped = false
		_last_safe = global_position
	else:
		_off_floor += delta
		if global_position.y < -60.0:
			teleport(_last_safe + Vector3(0, 4, 0))

	_step_shown = move_toward(_step_shown * exp( - delta * STEP_EASE), 0.0, delta * 0.5)
	rig.position.y = _step_shown


	var flat: = Vector3(velocity.x, 0, velocity.z)
	var want: float = rig.rotation.y
	var at: = acting_at()
	var toward_act: = (at - global_position) * Vector3(1, 0, 1) if at != Vector3.INF else Vector3.ZERO
	if toward_act.length() > 0.5 and not (is_local and camera.first_person()):
		want = atan2( - toward_act.x, - toward_act.z)
	elif is_local and camera.aiming():
		want = camera.yaw
	elif brain != null and brain.look != Vector3.INF and (brain.look - global_position) * Vector3(1, 0, 1) != Vector3.ZERO:
		var toward: = brain.look - global_position
		want = atan2( - toward.x, - toward.z)
	elif flat.length() > 1.0:
		want = atan2( - flat.x, - flat.z)
	rig.rotation.y = lerp_angle(rig.rotation.y, want, 1.0 - exp( - delta * 12.0))
	rig.speed = flat.length()

	rig.on_floor = is_on_floor() or ( not _jumped and _off_floor < FEET_GRACE)
	rig.crouch = _crouch_amount
	rig.hold = holding
	if is_local:
		rig.aim_pitch = camera.pitch
	elif brain != null:
		rig.aim_pitch = brain.pitch







func jump_speed() -> float:
	if brain != null:
		return JUMP
	var gravity: = float(ProjectSettings.get_setting("physics/3d/default_gravity"))
	return sqrt(2.0 * gravity * float(Config.Move.JumpHeight))




func _breathe(wish: Vector3, delta: float) -> void :
	var settings: Dictionary = Config.Move
	var free_hands: bool = holding != "nozzle" and get_attr("Carrying") == null and get_attr("Dragging") == null
	var wants: bool = Input.is_action_pressed("sprint") and wish.length() > 0.3 and _crouch_amount < 0.5 and is_on_floor() and free_hands
	if stamina >= float(settings["SprintAgain"]):
		_winded = false
	sprinting = wants and not _winded and stamina > 0.0
	if sprinting:
		var drain: = 1.0 / (float(settings["SprintSeconds"]) * Training.factor(self, "endurance"))
		if get_attr("Mask", false) == true:
			drain *= float(settings["MaskedDrain"])
		stamina = maxf(0.0, stamina - drain * delta)
		_rested_for = 0.0
		if stamina <= 0.0:
			_winded = true
	else:
		_rested_for += delta
		if _rested_for >= float(settings["RecoverAfter"]):
			stamina = minf(1.0, stamina + delta / (float(settings["RecoverSeconds"]) * Training.factor(self, "recovery")))




func _try_vault(wish: Vector3) -> bool:
	if brain != null or get_attr("Carrying") != null:
		return false
	var settings: Dictionary = Config.Move
	var ahead: = wish if wish.length() > 0.3 else facing()
	ahead.y = 0.0
	if ahead.length() < 0.1:
		return false
	ahead = ahead.normalized()
	var space: = get_world_3d().direct_space_state
	var feet: = global_position
	var reach: = float(settings["VaultReach"])

	var knee: = feet + Vector3(0, STEP + 0.3, 0)
	var front: = space.intersect_ray(PhysicsRayQueryParameters3D.create(knee, knee + ahead * (RADIUS + reach), World.LAYER_SOLID, [get_rid()]))
	if front.is_empty():
		return false
	var face: Vector3 = front["position"]

	var most: = float(settings["VaultMost"])
	var over: = face + ahead * 0.3
	var top_hit: = space.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(over.x, feet.y + most + 1.5, over.z), Vector3(over.x, feet.y, over.z), World.LAYER_SOLID, [get_rid()]))
	if top_hit.is_empty():
		return false
	var top: float = top_hit["position"].y - feet.y
	if top <= STEP or top > most:
		return false

	var depth: = float(settings["VaultDepth"])
	var clear: = feet + Vector3(0, top + 0.4, 0)
	if not space.intersect_ray(PhysicsRayQueryParameters3D.create(clear, clear + ahead * (RADIUS + reach + depth), World.LAYER_SOLID, [get_rid()])).is_empty():
		return false
	var beyond: = face + ahead * depth
	var back: = space.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(beyond.x, feet.y + top - 0.3, beyond.z), Vector3(face.x, feet.y + top - 0.3, face.z), World.LAYER_SOLID, [get_rid()]))
	var far_face: Vector3 = back["position"] if not back.is_empty() else face + ahead * 0.5
	var landing: = far_face + ahead * (RADIUS + 0.5)
	var ground: = space.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(landing.x, feet.y + top + 1.0, landing.z), Vector3(landing.x, feet.y - 3.0, landing.z), World.LAYER_SOLID, [get_rid()]))
	if ground.is_empty() or absf(ground["position"].y - feet.y) > 2.0:
		return false
	var to: = Vector3(landing.x, ground["position"].y + 0.05, landing.z)
	if test_move(Transform3D(Basis.IDENTITY, to + Vector3(0, 0.2, 0)), Vector3(0, 0.05, 0)):
		return false
	_vault = {"from": feet, "top": feet.y + top + 0.4, "to": to, "time": 0.0, "length": float(settings["VaultTime"])}
	_collider.disabled = true
	velocity = Vector3.ZERO
	_step_shown = 0.0
	rig.position.y = 0.0
	return true



func _vaulting(delta: float) -> void :
	_vault["time"] = float(_vault["time"]) + delta
	var t: = clampf(float(_vault["time"]) / float(_vault["length"]), 0.0, 1.0)
	var from: Vector3 = _vault["from"]
	var to: Vector3 = _vault["to"]
	var flat: = from.lerp(to, t)
	var arc: = 4.0 * t * (1.0 - t)
	var base: = lerpf(from.y, to.y, t)
	global_position = Vector3(flat.x, base + (float(_vault["top"]) - base) * arc, flat.z)
	var toward: = (to - from) * Vector3(1, 0, 1)
	if toward.length() > 0.1:
		rig.rotation.y = atan2( - toward.x, - toward.z)
	rig.speed = 8.0
	rig.on_floor = false
	if t >= 1.0:
		_vault = {}
		_collider.disabled = false
		velocity = Vector3.ZERO



func vaulting() -> bool:
	return not _vault.is_empty()






func _step_up(delta: float) -> float:
	if not is_on_floor():
		return 0.0
	var motion: = Vector3(velocity.x, 0, velocity.z) * delta
	if motion.length() < 0.001:
		return 0.0
	var here: = global_transform
	if not test_move(here, motion):
		return 0.0
	var up: = Vector3(0, STEP, 0)
	if test_move(here, up):
		return 0.0
	var raised: = here.translated(up)
	var ahead: = motion.normalized() * maxf(motion.length(), 0.35)
	if test_move(raised, ahead):
		return 0.0

	var landing: = KinematicCollision3D.new()
	var over: = raised.translated(ahead)
	if test_move(over, - up * 1.05, landing):
		var travelled: = landing.get_travel()
		if landing.get_normal().y > 0.7 and travelled.y > - STEP + 0.05:
			var rise: = over.origin.y + travelled.y + 0.02 - global_position.y
			global_position = over.origin + travelled + Vector3(0, 0.02, 0)
			_step_shown = clampf(_step_shown - rise, - STEP, STEP)
			_stepped_at = Game.now()
			return ahead.length()
	return 0.0





func hold_rungs(yaw: float, rate: float) -> void :
	_rungs_frame = Engine.get_physics_frames()
	_climb_rate = rate
	rig.rotation.y = lerp_angle(rig.rotation.y, yaw, 0.35)



func on_rungs() -> bool:
	return Engine.get_physics_frames() - _rungs_frame <= 1


func _on_rungs() -> void :
	velocity = Vector3.ZERO
	crouching = false
	_crouch_amount = 0.0
	_jumped = false
	_off_floor = 0.0
	_step_debt = 0.0
	_step_shown = 0.0
	rig.position.y = 0.0
	rig.climbing = true
	rig.on_floor = true
	rig.speed = absf(_climb_rate)
	rig.crouch = 0.0
	rig.hold = holding
	if is_local:
		rig.aim_pitch = camera.pitch




func climb_off(to: Vector3, seconds: = 0.35) -> void :
	_rungs_frame = -10
	rig.climbing = false
	_vault = {"from": global_position, "top": maxf(global_position.y, to.y) + 0.5, "to": to, "time": 0.0, "length": seconds}
	_collider.disabled = true
	velocity = Vector3.ZERO




func _step_down() -> void :
	var landing: = KinematicCollision3D.new()
	if not test_move(global_transform, Vector3(0, - (STEP + 0.1), 0), landing):
		return
	if landing.get_normal().y <= 0.7:
		return
	var drop: = landing.get_travel()
	global_position += drop
	_step_shown = clampf(_step_shown - drop.y, - STEP, STEP)
	velocity.y = 0.0
	apply_floor_snap()


func _process(delta: float) -> void :
	if not is_local:
		return
	_update_prompts(delta)




func _update_prompts(delta: float) -> void :
	var looking: = camera.forward()
	var from: = root_position()
	var free: = not Game.ui_open and seat == null and not lying()
	var simple: = Settings.simple()
	if simple:
		_update_choices(from, free)
	for key: String in PROMPT_KEYS:
		var offered: Prompt = null
		if free:
			offered = Prompt.nearest(self, from, key, looking)

		if simple and key == "interact":
			offered = choices[choice] if choice < choices.size() else null
		prompts[key] = offered
		var holding: Prompt = _holding.get(key)
		if holding and ( not is_instance_valid(holding) or holding != offered or not Input.is_action_pressed(key)):
			if is_instance_valid(holding):
				_fire_prompt(holding, "end")
			end_act()
			_holding.erase(key)
			prompt_held.erase(key)
			holding = null
		if offered == null:
			continue
		if Input.is_action_just_pressed(key):
			if offered.hold <= 0.0:
				begin_act(offered, true)
				_fire_prompt(offered, "tap")
				continue
			_holding[key] = offered
			prompt_held[key] = 0.0
			begin_act(offered, false)
			_fire_prompt(offered, "begin")
		if _holding.get(key) == offered and offered.hold > 0.0:
			prompt_held[key] = prompt_held.get(key, 0.0) + delta
			if prompt_held[key] >= offered.hold:
				_holding.erase(key)
				prompt_held.erase(key)
				end_act()
				_fire_prompt(offered, "end")
				_fire_prompt(offered, "tap")
	prompt = prompts.get("interact")




func _update_choices(from: Vector3, free: bool) -> void :
	var found: Array[Prompt] = []
	if free and camera.camera != null:
		var eye: = camera.camera
		found = Prompt.choices(self, from, eye.global_position, - eye.global_basis.z, PROMPT_KEYS)
	var held: Variant = _holding.get("interact")
	var keep: Prompt = held if held is Prompt and is_instance_valid(held) else _stepped_to
	choices = found
	choice = 0
	if keep != null and is_instance_valid(keep) and keep in found:
		choice = found.find(keep)
	else:
		_stepped_to = null




func _input(event: InputEvent) -> void :
	if not is_local or choices.size() < 2 or not Settings.simple() or Game.ui_open:
		return
	if not event is InputEventMouseButton or not event.pressed or camera == null or not camera.captured:
		return
	var step: = 0
	if event.button_index == MOUSE_BUTTON_WHEEL_UP:
		step = -1
	elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
		step = 1
	if step == 0 or _holding.has("interact"):
		return
	step_choice(step)
	get_viewport().set_input_as_handled()



func step_choice(step: int) -> void :
	if choices.size() < 2:
		return
	choice = posmod(choice + step, choices.size())
	_stepped_to = choices[choice]
	prompts["interact"] = _stepped_to
	prompt = _stepped_to
	Sounds.ui("ui_tick")




const FORCE_STAND: = 2.7
static var force_stand: = FORCE_STAND



func begin_act(used: Prompt, tap: bool) -> void :
	if used == null or used.gesture == "none" or rig == null:
		return
	var at: = used.hand_point()
	var out: = global_position - at
	out.y = 0.0
	var kind: = used.gesture if not used.gesture.is_empty() else ("reach" if tap else "work")
	rig.hands_at = {"kind": kind, "at": at, "normal": out.normalized() if out.length() > 0.01 else Vector3.ZERO, "since": Game.now(), "ended": -1.0}




func set_down_ahead(distance: = 4.0) -> void :
	if rig == null:
		return
	var flat: = facing() * Vector3(1, 0, 1)
	flat = flat.normalized() if flat.length() > 0.01 else Vector3.FORWARD
	var at: = root_position() + flat * distance
	var ground: = Game.world.raycast(at + Vector3(0, 3, 0), at + Vector3(0, -9, 0), World.LAYER_SOLID, [get_rid()])
	if not ground.is_empty():
		at = ground["position"]
	rig.hands_at = {"kind": "place", "at": at + Vector3(0, 0.4, 0), "normal": - flat, "since": Game.now(), "ended": -1.0}



func end_act() -> void :
	if rig != null and not rig.hands_at.is_empty() and float(rig.hands_at.get("ended", -1.0)) < 0.0:
		rig.hands_at["ended"] = Game.now()



func acting_at() -> Vector3:
	if rig == null or rig.hands_at.is_empty() or float(rig.hands_at.get("ended", -1.0)) >= 0.0:
		return Vector3.INF
	if rig.hands_at.get("kind") in ["reach", "place"] and Game.now() - float(rig.hands_at.get("since", 0.0)) > 0.5:
		return Vector3.INF
	return rig.hands_at["at"]



func _step_to_force(wish: Vector3) -> Vector3:
	if wish != Vector3.ZERO or rig == null or rig.hands_at.get("kind", "") != "force" or acting_at() == Vector3.INF:
		return wish
	var to: Vector3 = rig.hands_at["at"] - global_position
	to.y = 0.0
	if to.length() > force_stand + 0.25:
		return to.normalized() * 0.45
	return wish



func _act_state() -> Array:
	if rig == null or rig.hands_at.is_empty():
		return []
	var now: = Game.now()
	var ended: float = rig.hands_at.get("ended", -1.0)
	if ended >= 0.0 and now - ended > 1.0:
		return []
	return [rig.hands_at["kind"], rig.hands_at["at"], rig.hands_at.get("normal", Vector3.ZERO), now - float(rig.hands_at["since"]), now - ended if ended >= 0.0 else -1.0]


func _apply_act(state: Variant) -> void :
	if rig == null:
		return
	if not (state is Array) or state.is_empty():
		if not rig.hands_at.is_empty() and float(rig.hands_at.get("ended", -1.0)) < 0.0:
			rig.hands_at["ended"] = Game.now()
		return
	var now: = Game.now()
	var same: bool = not rig.hands_at.is_empty() and rig.hands_at.get("kind") == state[0] and (rig.hands_at["at"] as Vector3).distance_to(state[1]) < 0.2
	if not same:
		rig.hands_at = {"kind": state[0], "at": state[1], "normal": state[2], "since": now - float(state[3]), "ended": -1.0}
	if float(state[4]) >= 0.0 and float(rig.hands_at.get("ended", -1.0)) < 0.0:
		rig.hands_at["ended"] = now - float(state[4])






func _fire_prompt(used: Prompt, phase: String) -> void :
	if Net.is_client() and not used.net_id.is_empty():
		Net.request("prompt", [used.net_id, phase])
		return
	match phase:
		"tap":
			used.triggered.emit(self)
		"begin":
			used.hold_began.emit(self)
		"end":
			used.hold_ended.emit(self)



func aim_point() -> Vector3:
	if not is_local or camera == null:
		return get_attr("Aim", root_position() + facing() * 30.0)
	var eye: = camera.camera
	var from: = eye.global_position
	var along: = - eye.global_basis.z
	var hit: = Game.world.raycast(from + along * (camera.distance + 1.0), from + along * 500.0, World.LAYER_QUERY | World.LAYER_VEHICLE, [get_rid()])
	return hit["position"] if not hit.is_empty() else from + along * 500.0



func net_state() -> Array:
	var flat: = Vector2(velocity.x, velocity.z).length()
	var trigger: bool = is_local and Input.is_action_pressed("fire") and camera != null and camera.captured and not Game.ui_open
	return [
		global_position, rig.rotation.y, flat if is_local else _net_speed, rig.on_floor if is_local else _net_floor, 
		_crouch_amount, rig.aim_pitch, aim_point(), trigger if is_local else get_attr("Trigger", false), 
		_act_state(), (absf(_climb_rate) if on_rungs() else -1.0) if is_local else _net_climb, 
	]


func net_apply(state: Array) -> void :
	_net_position = state[0]
	_net_yaw = state[1]
	_net_speed = state[2]
	_net_floor = state[3]
	_net_crouch = state[4]
	_net_pitch = state[5]

	attributes["Aim"] = state[6]
	attributes["Trigger"] = state[7]
	if state.size() > 8:
		_apply_act(state[8])
	_net_climb = float(state[9]) if state.size() > 9 else -1.0



func net_host_state() -> Array:
	return [health, holding, String(seat.get_path()) if (seat != null and seat.is_inside_tree()) else "", frozen, walk_speed, rig.shown_sheets()]


func net_apply_host(state: Array) -> void :
	health = state[0]
	holding = state[1]
	frozen = state[3]
	walk_speed = state[4]
	var seat_now: Node3D = get_node_or_null(NodePath(state[2])) if state[2] != "" else null
	if seat_now != null and is_local and Game.now() < seat_hold_until:
		seat_now = seat
	if seat_now != seat:
		if seat_now != null:
			sit(seat_now)
		else:
			leave_seat()
		seat_changed.emit(seat_now)
	if not is_local:
		rig.wear_sheets(state[5])



func _follow_net(delta: float) -> void :
	if seat != null:
		global_transform = seat.global_transform
		rig.rotation = Vector3.ZERO
		rig.speed = 0.0
		return
	if _net_position != Vector3.INF:
		if global_position.distance_to(_net_position) > 12.0:
			global_position = _net_position
		else:
			global_position = global_position.lerp(_net_position, 1.0 - exp( - delta * 18.0))
	rig.rotation.y = lerp_angle(rig.rotation.y, _net_yaw, 1.0 - exp( - delta * 14.0))
	rig.climbing = _net_climb >= 0.0
	rig.speed = _net_climb if rig.climbing else _net_speed
	rig.on_floor = _net_floor or rig.climbing
	_crouch_amount = _net_crouch
	rig.crouch = _net_crouch
	rig.hold = holding
	rig.aim_pitch = _net_pitch
