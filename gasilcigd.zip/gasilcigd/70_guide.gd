extends RefCounted


static func start(main: Node) -> void :
	var guide: = Guide.new()
	guide.name = "Guide"
	main.add_child(guide)

	if FuelService.current:


		Guide.nearest_pump = FuelService.current.nearest
