class_name ScenePolice
extends Node3D























static var delay: = 45.0
static var stay: = false
const ARRIVE_RANGE: = 90.0
const DRIVE_IN: = 240.0
const DRIVE_OUT: = 240.0
const SPEED: = 36.0
const BRAKING: = 16.0
const PULL_ACROSS: = 14.0
const STEP: = 4.0
const JUNCTION_ROOM: = 14.0
const OFFICER_OUT: = 2.0
const SHAPE: = "Estate"
const BAR_AT: = 0.1
const LAMP_BLUE: = Color(0.15, 0.35, 1.0)
const LIVERY: = "res://assets/textures/police/livery.png"

const PLATE_UV: = Vector4(0.0, 918.0 / 1024.0, 512.0 / 1536.0, 106.0 / 1024.0)



static var OWN: Dictionary = Edition.data().get("police_car", {})
static var _shape: String = str(OWN.get("shape", SHAPE))

static var current: ScenePolice
const KINDS: = ["fire", "crash", "tree", "hazmat", "accident"]
static var _looks: Dictionary = {}

var visit: Dictionary = {}
var _arrived_at: = -1.0
var _call_at: = Vector3.INF
var _visits: = 0
var _since: = 0.0
var _car: Node3D
var _lamps: Array[MeshInstance3D] = []
var _glares: Array[MeshInstance3D] = []
var _lit: = -1
var _light: OmniLight3D
var _siren: AudioStreamPlayer3D
var _body: AnimatableBody3D
var _officer: PoliceOfficer
var _shown_id: = -1
var siren: = 0.0
var linear_velocity: = Vector3.ZERO
var _last_pos: = Vector3.ZERO


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
	Emergency.watch(self, false)


func _ready() -> void :
	Net.share("scene.police", func() -> Variant: return visit, func(state: Variant) -> void :
		visit = state if state is Dictionary else {}
	, 2.0)
	Net.stopped.connect( func() -> void :
		visit = {}
		_arrived_at = -1.0
	)


func _process(delta: float) -> void :
	if not Net.is_client() and not stay:
		_since += delta
		if _since >= 0.5:
			_since = 0.0
			_decide()
	_draw(delta)





func _decide() -> void :
	var incident: = Game.incident
	var kind: String = incident.get("kind", "")
	var at: Variant = incident.get("pos")
	var live: = at is Vector3 and kind in KINDS

	if not live or (at as Vector3).distance_to(_call_at) > 1.0:
		if not visit.is_empty() and float(visit["t_out"]) < 0.0:
			_leave()
		_arrived_at = -1.0
		_call_at = at if live else Vector3.INF
	if not visit.is_empty() and float(visit["t_out"]) >= 0.0 and HostClock.now() > float(visit["t_out"]) + _duration(visit["way_out"]) + 1.0:
		visit = {}
	if not live:
		return
	if _arrived_at < 0.0:
		var there: = not CallKit.crew_near(at, ARRIVE_RANGE).is_empty()
		for vehicle in Vehicle.all:
			there = there or (vehicle.global_position.distance_to(at) < ARRIVE_RANGE and absf(vehicle.forward_speed) < 3.0)
		if there:
			_arrived_at = Game.now()
	if _arrived_at >= 0.0 and visit.is_empty() and Game.now() - _arrived_at >= delay:
		_come(at)


func _come(at: Vector3) -> void :
	var graph: = NavGraph.current
	if graph == null:
		return
	var place: = _find_place(graph, at)
	if place.is_empty():
		return
	var points: Array = []
	var best: Array = []
	var best_length: = INF
	for entry: int in graph.entries:
		var route: = graph.drive_route(entry, place["seg"])
		if not route.is_empty() and graph.route_length < best_length:
			best = route
			best_length = graph.route_length
	if best.is_empty():
		return
	points = _lane_points(graph, best, 0.0, maxf(place["along"] - PULL_ACROSS, 0.0))
	points.append(place["park"].origin)
	_visits += 1
	visit = {
		"id": _visits, 
		"park": place["park"], 
		"way_in": _last_stretch(points, DRIVE_IN), 
		"t_in": HostClock.now(), 
		"way_out": PackedVector3Array(), 
		"t_out": -1.0, 
		"seg": place["seg"], 
		"along": place["along"], 
		"aside": place["aside"], 
	}


func _leave() -> void :
	var graph: = NavGraph.current
	var out: = PackedVector3Array()
	if graph != null and int(visit.get("seg", -1)) >= 0:
		var best: Array = []
		var best_length: = INF
		for exit: int in graph.exits:
			var route: = graph.drive_route(int(visit["seg"]), exit)
			if not route.is_empty() and graph.route_length < best_length:
				best = route
				best_length = graph.route_length
		if not best.is_empty():
			var points: Array = [visit["park"].origin]
			points.append_array(_lane_points(graph, best, float(visit["along"]) + PULL_ACROSS, INF))
			out = _first_stretch(points, DRIVE_OUT)
	visit["way_out"] = out
	visit["t_out"] = HostClock.now()
	visit = visit.duplicate()




func _find_place(graph: NavGraph, at: Vector3) -> Dictionary:
	var radius: = 45.0
	if not graph.closure.is_empty():
		radius = float(graph.closure["radius"])
	var want: = radius * 0.82
	var road_along: = Vector3.ZERO
	if Bystanders.current != null and Bystanders.current.road.get("at", Vector3.INF) is Vector3 and (Bystanders.current.road.get("at", Vector3.INF) as Vector3).distance_to(at) < 1.0:
		road_along = Bystanders.current.road["along"]
	var engines: Array[Vector3] = []
	for vehicle in Vehicle.all:
		if vehicle.global_position.distance_to(at) < radius + 60.0:
			engines.append(vehicle.global_position)
	var candidates: Array = []
	for segment: Dictionary in graph.segments:
		if segment["kind"] != "lane":
			continue
		var length: float = segment["length"]
		var along: = JUNCTION_ROOM
		while along <= length - JUNCTION_ROOM:
			var s: = NavGraph.sample(segment, along)
			var d: = Vector2(s.x - at.x, s.y - at.z).length()
			if absf(d - want) < 14.0:
				var score: = - absf(d - want) * 1.5
				var nearest: = 80.0
				for engine in engines:
					nearest = minf(nearest, Vector2(s.x - engine.x, s.y - engine.z).length())
				score += nearest

				if not road_along.is_zero_approx() and absf(Vector3(s.x - at.x, 0, s.y - at.z).dot(Vector3(road_along.z, 0, - road_along.x))) < 8.0:
					score += 60.0
				candidates.append({"s": s, "seg": int(segment["id"]), "along": along, "score": score})
			along += STEP
	candidates.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return a["score"] > b["score"])
	var ambulance: = AmbulanceService.current
	for index in mini(candidates.size(), 60):
		var candidate: Dictionary = candidates[index]
		var s: Vector4 = candidate["s"]

		var aside: = -1.5
		var x: = s.x - s.w * aside
		var z: = s.y + s.z * aside
		var y: = ambulance.ground_at(x, z) if ambulance else 0.25
		var heading: = Vector3(s.z, 0, s.w).rotated(Vector3.UP, deg_to_rad(62.0))
		var park: = Transform3D(Basis.looking_at(heading), Vector3(x, y, z))
		if _clear(park, engines):
			return {"park": park, "seg": candidate["seg"], "along": candidate["along"], "aside": Vector3( - s.w, 0, s.z)}
	return {}



func _clear(park: Transform3D, engines: Array[Vector3]) -> bool:
	for engine in engines:
		if Vector2(engine.x - park.origin.x, engine.z - park.origin.z).length() < 18.0:
			return false
	var ambulance: = AmbulanceService.current
	if ambulance and not ambulance.has_room(park):
		return false
	return true


func _lane_points(graph: NavGraph, route: Array, from_along: float, to_along: float) -> Array:
	var points: Array = []
	var ambulance: = AmbulanceService.current
	for index in route.size():
		var segment: Dictionary = graph.segments[route[index]]
		var length: float = segment["length"]
		var first: = from_along if index == 0 else 0.0
		var last: = minf(to_along, length) if index == route.size() - 1 else length
		var along: = first
		while along <= last:
			var s: = NavGraph.sample(segment, along)
			points.append(Vector3(s.x, ambulance.ground_at(s.x, s.y) if ambulance else 0.25, s.y))
			along += STEP
	return points



static func _last_stretch(points: Array, length: float) -> PackedVector3Array:
	var kept: = PackedVector3Array()
	var gone: = 0.0
	for index in range(points.size() - 1, -1, -1):
		kept.insert(0, points[index])
		if index > 0:
			gone += (points[index] as Vector3).distance_to(points[index - 1])
		if gone >= length:
			break
	return kept



static func _first_stretch(points: Array, length: float) -> PackedVector3Array:
	var kept: = PackedVector3Array()
	var gone: = 0.0
	for index in points.size():
		kept.append(points[index])
		if index + 1 < points.size():
			gone += (points[index] as Vector3).distance_to(points[index + 1])
		if gone >= length:
			break
	return kept



static func bodies() -> Array:
	var found: Array = []
	if current == null:
		return found
	var pose: Array = current.pose_now()
	if pose[1] != "parked":
		return found
	var park: Transform3D = pose[0]
	for z: float in [-3.5, 0.0, 3.5]:
		var at: = park * Vector3(0, 0, z)
		found.append(Vector3(at.x, at.z, 3.0))
	return found





static func _length(way: PackedVector3Array) -> float:
	var total: = 0.0
	for index in range(1, way.size()):
		total += way[index].distance_to(way[index - 1])
	return total



static func _duration(way: Variant) -> float:
	var length: = _length(way)
	var braking: = SPEED * SPEED / (2.0 * BRAKING)
	if length <= braking:
		return sqrt(2.0 * length / BRAKING)
	return (length - braking) / SPEED + SPEED / BRAKING



static func _along_in(length: float, t: float) -> float:
	var braking: = SPEED * SPEED / (2.0 * BRAKING)
	var cruise: = maxf(length - braking, 0.0) / SPEED
	if t <= cruise:
		return SPEED * t
	var after: = t - cruise
	var v0: = minf(SPEED, sqrt(2.0 * BRAKING * length))
	return minf(length - braking + v0 * after - 0.5 * BRAKING * after * after, length) if length > braking else minf(v0 * after - 0.5 * BRAKING * after * after, length)



static func _along_out(t: float) -> float:
	var reach: = SPEED / BRAKING
	return 0.5 * BRAKING * t * t if t < reach else 0.5 * BRAKING * reach * reach + SPEED * (t - reach)


static func _on_way(way: PackedVector3Array, along: float) -> Array:
	var gone: = 0.0
	for index in range(1, way.size()):
		var piece: = way[index].distance_to(way[index - 1])
		if gone + piece >= along or index == way.size() - 1:
			var share: = clampf((along - gone) / maxf(piece, 0.001), 0.0, 1.0)
			return [way[index - 1].lerp(way[index], share), (way[index] - way[index - 1]) * Vector3(1, 0, 1)]
		gone += piece
	return [way[way.size() - 1] if way.size() > 0 else Vector3.ZERO, Vector3.FORWARD]




func pose_now() -> Array:
	if visit.is_empty():
		return [Transform3D(), "gone"]
	var now: = HostClock.now()
	var park: Transform3D = visit["park"]
	var t_out: float = visit["t_out"]
	if t_out >= 0.0 and now >= t_out:
		var way: PackedVector3Array = visit["way_out"]
		var length: = _length(way)
		var along: = _along_out(now - t_out)
		if way.size() < 2 or along >= length:
			return [park, "gone"]
		var at: Array = _on_way(way, along)
		var flat: Vector3 = at[1]
		var basis: = Basis.looking_at(flat.normalized()) if flat.length() > 0.01 else park.basis

		var share: = clampf(along / PULL_ACROSS, 0.0, 1.0)
		return [Transform3D(park.basis.slerp(basis, share), at[0]), "out"]
	var way_in: PackedVector3Array = visit["way_in"]
	var t: = now - float(visit["t_in"])
	var length_in: = _length(way_in)
	if way_in.size() < 2 or t >= _duration(way_in):
		return [park, "parked"]
	var along_in: = _along_in(length_in, t)
	var at_in: Array = _on_way(way_in, along_in)
	var flat_in: Vector3 = at_in[1]
	var heading: = Basis.looking_at(flat_in.normalized()) if flat_in.length() > 0.01 else park.basis

	var share_in: = clampf(1.0 - (length_in - along_in) / PULL_ACROSS, 0.0, 1.0)
	return [Transform3D(heading.slerp(park.basis, share_in * share_in), at_in[0]), "in"]


func _draw(delta: float) -> void :
	if visit.is_empty() or int(visit["id"]) != _shown_id:
		_undraw()
		if visit.is_empty():
			return
		_build()
		_shown_id = int(visit["id"])
	var pose: Array = pose_now()
	var phase: String = pose[1]
	if phase == "gone":
		_undraw()
		_shown_id = int(visit["id"])
		return
	var place: Transform3D = pose[0]
	_car.global_transform = place
	global_position = place.origin
	linear_velocity = (place.origin - _last_pos) / maxf(delta, 0.001)
	_last_pos = place.origin
	siren = 1.0 if phase == "in" else 0.0
	if _siren.stream:
		if (phase == "in") != _siren.playing:
			if phase == "in":
				_siren.play()
			else:
				_siren.stop()

	var now: = HostClock.now()
	var flip: = fmod(now * 3.2, 1.0) < 0.5
	if int(flip) != _lit:
		_lit = int(flip)
		for index in _lamps.size():
			var lit: = (index % 2 == 0) == flip
			_lamps[index].material_override = _lamp_look(_lamp_colour(index), lit)
			VehicleLook.shine(_glares[index], (0.55 + 0.45 * VehicleLook.glare_now()) if (index % 2 == 0) == flip else 0.0)
	_light.visible = Game.night or (Sky3D.current != null and Sky3D.current.daylight() < 0.6)
	_light.light_energy = (3.5 if absf(sin(now * 20.0)) > 0.4 else 0.6)
	_light.position.x = -0.9 if flip else 0.9
	_light.light_color = _lamp_colour(0 if flip else 1)

	var parked: = phase == "parked"
	_body.collision_layer = (World.LAYER_SOLID | World.LAYER_QUERY) if parked else 0

	var out: = parked and now - float(visit["t_in"]) - _duration(visit["way_in"]) > OFFICER_OUT
	_officer.visible = out
	if out:
		var aside: Vector3 = visit["aside"]
		var park: Transform3D = visit["park"]
		var call_at: Variant = Game.incident.get("pos")
		var away: = aside
		if call_at is Vector3 and aside.dot(park.origin - call_at) < 0.0:
			away = - aside

		var spot: = park.origin + park.basis.x * 4.6 * (1.0 if park.basis.x.dot(away) > 0.0 else -1.0) + away * 3.0
		_officer.global_transform = Transform3D(Basis.looking_at(away.normalized() if away.length() > 0.01 else Vector3.FORWARD), spot)
		_officer.wave(fmod(now + float(visit["id"]) * 3.0, 7.0) < 2.2)


func _build() -> void :
	_car = Node3D.new()
	_car.name = "PoliceCar"
	_car.top_level = true
	add_child(_car)
	var shape: = _shape if CarKit.shapes().has(_shape) else CarKit.pick(3)
	var made: Node3D = CarKit.build(shape, Color.WHITE, -1) if shape != "" else Node3D.new()
	_car.add_child(made)
	var looks: = _materials()

	if shape == _shape:
		for piece: String in CarKit.PAINTED:
			var mesh: = made.get_node_or_null(piece) as MeshInstance3D
			if mesh != null:
				mesh.material_override = looks["livery"]
	var measures: = CarKit.data(shape)
	var roof: float = float(measures.get("roof", 5.1))
	var half_width: = 3.3
	var doors: Dictionary = measures.get("doors", {})
	if doors.has("L"):
		half_width = absf(float(doors["L"]["middle"][0])) + 0.06

	for end in CarKit.plate_ends():
		var plate: = MeshInstance3D.new()
		plate.mesh = looks["plate_mesh"]
		plate.material_override = looks["plate"]
		plate.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		plate.transform = CarKit.plate_place(end, shape)
		_car.add_child(plate)


	var bar_y: = roof + 0.3
	var bar: = MeshInstance3D.new()
	bar.mesh = looks["bar_mesh"]
	bar.material_override = looks["bar"]
	bar.position = Vector3(0, bar_y - 0.06, BAR_AT)
	bar.rotation.z = PI / 2.0
	bar.scale = Vector3(0.42, 1.0, 1.0)
	_car.add_child(bar)
	for side: float in [-1.0, 1.0]:
		var foot: = MeshInstance3D.new()
		foot.mesh = looks["foot_mesh"]
		foot.material_override = looks["bar"]
		foot.position = Vector3(side * 1.6, bar_y - 0.24, BAR_AT)
		_car.add_child(foot)
	_lamps.clear()
	_glares.clear()
	_lit = -1
	for side: float in [-1.0, 1.0]:
		var lamp: = MeshInstance3D.new()
		lamp.mesh = looks["lens_mesh"]
		lamp.position = Vector3(side * 1.04, bar_y + 0.06, BAR_AT)
		lamp.rotation.z = PI / 2.0
		lamp.scale = Vector3(0.5, 1.0, 1.0)
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_car.add_child(lamp)
		_lamps.append(lamp)
		_glares.append(VehicleLook.flare(_car, lamp.position, _lamp_colour(_lamps.size() - 1).lightened(0.15), 3.4))

	var heads: Array = measures.get("lamps", {}).get("head", [[-2.0, 2.3, -7.4], [2.0, 2.3, -7.4]])
	var head: Array = heads[1]
	for side: float in [1.0, -1.0]:
		var lamp: = MeshInstance3D.new()
		lamp.mesh = looks["grille_mesh"]
		lamp.position = Vector3(side * 1.05, float(head[1]) - 0.32, float(head[2]) - 0.14)
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_car.add_child(lamp)
		_lamps.append(lamp)
		_glares.append(VehicleLook.flare(_car, lamp.position + Vector3(0, 0, -0.1), _lamp_colour(_lamps.size() - 1).lightened(0.15), 1.6, 1.0))
	if OWN.get("push_bar", false):
		_push_bar(head, half_width)
	_light = OmniLight3D.new()
	_light.light_color = LAMP_BLUE
	_light.omni_range = 34.0
	_light.shadow_enabled = false
	_light.position = Vector3(0, roof + 1.2, BAR_AT)
	_car.add_child(_light)

	_siren = Sounds.emitter(_car, Sounds.loop(Config.Siren.Patterns[0]["soundId"]), 0.55, 18.0, 300.0)

	_body = AnimatableBody3D.new()
	_body.sync_to_physics = false
	_body.collision_layer = 0
	_body.collision_mask = 0
	var collider: = CollisionShape3D.new()
	var shape_box: = BoxShape3D.new()
	shape_box.size = Vector3(half_width * 2.0, roof - 0.6, CarKit.length_of(shape) - 1.0 if OWN.has("shape") else 15.0)
	collider.shape = shape_box
	collider.position = Vector3(0, (roof - 0.6) / 2.0 + 0.6, 0)
	_body.add_child(collider)
	_car.add_child(_body)
	_officer = PoliceOfficer.new(int(visit["id"]))
	_officer.top_level = true
	_officer.visible = false
	add_child(_officer)
	Emergency.watch(self, true)



static func _materials() -> Dictionary:
	if not _looks.is_empty():
		return _looks
	var own_livery: = "res://assets/textures/police/%s.png" % str(OWN.get("livery", ""))
	var picture: Texture2D = load(own_livery if OWN.has("livery") and ResourceLoader.exists(own_livery) else LIVERY)
	var livery: = ShaderMaterial.new()
	livery.shader = load("res://shaders/police_livery.gdshader")
	livery.set_shader_parameter("livery", picture)
	if OWN.has("livery"):

		var measures: = CarKit.data(_shape)
		var half: = float(measures.get("width", 6.6)) / 2.0 + 0.1
		var long: = CarKit.length_of(_shape) / 2.0 + 0.1
		var high: = float(measures.get("roof", 5.4)) + 0.1
		livery.set_shader_parameter("box_low", Vector3( - half, 0.8, - long))
		livery.set_shader_parameter("box_size", Vector3(half * 2.0, high - 0.8, long * 2.0))
	_looks["livery"] = livery
	var plate: = StandardMaterial3D.new()
	plate.albedo_texture = picture
	var plate_uv: = PLATE_UV
	var own_plate: Variant = OWN.get("plate")
	if own_plate is Array and own_plate.size() == 4:
		plate_uv = Vector4(float(own_plate[0]) / 1536.0, float(own_plate[1]) / 1024.0, float(own_plate[2]) / 1536.0, float(own_plate[3]) / 1024.0)
	plate.uv1_offset = Vector3(plate_uv.x, plate_uv.y, 0)
	plate.uv1_scale = Vector3(plate_uv.z, plate_uv.w, 1)
	plate.roughness = 0.5
	_looks["plate"] = plate
	var plate_mesh: = QuadMesh.new()
	plate_mesh.size = CarKit.plate_size()
	_looks["plate_mesh"] = plate_mesh
	var bar: = StandardMaterial3D.new()
	bar.albedo_color = Color8(28, 29, 32)
	bar.metallic = 0.2
	bar.roughness = 0.4
	_looks["bar"] = bar

	var bar_mesh: = CapsuleMesh.new()
	bar_mesh.radius = 0.42
	bar_mesh.height = 4.7
	bar_mesh.radial_segments = 12
	bar_mesh.rings = 2
	_looks["bar_mesh"] = bar_mesh
	var lens_mesh: = CapsuleMesh.new()
	lens_mesh.radius = 0.36
	lens_mesh.height = 2.08
	lens_mesh.radial_segments = 12
	lens_mesh.rings = 2
	_looks["lens_mesh"] = lens_mesh
	var foot_mesh: = BoxMesh.new()
	foot_mesh.size = Vector3(0.3, 0.3, 0.5)
	_looks["foot_mesh"] = foot_mesh
	var grille_mesh: = BoxMesh.new()
	grille_mesh.size = Vector3(0.5, 0.12, 0.05)
	_looks["grille_mesh"] = grille_mesh
	var on: = StandardMaterial3D.new()
	on.albedo_color = LAMP_BLUE
	on.emission_enabled = true
	on.emission = LAMP_BLUE
	on.emission_energy_multiplier = 6.0
	_looks["lamp_on"] = on

	var off: = StandardMaterial3D.new()
	off.albedo_color = Color(0.1, 0.18, 0.5)
	off.metallic = 0.2
	off.roughness = 0.1
	_looks["lamp_off"] = off
	return _looks



static func _lamp_colour(index: int) -> Color:
	var colours: Array = OWN.get("lamps", [])
	if colours.is_empty():
		return LAMP_BLUE
	var c: Array = colours[index % colours.size()]
	return Color(float(c[0]), float(c[1]), float(c[2]))



static func _lamp_look(colour: Color, lit: bool) -> Material:
	if colour == LAMP_BLUE:
		return _looks["lamp_on" if lit else "lamp_off"]
	var key: = "lamp_%s_%s" % [colour.to_html(false), "on" if lit else "off"]
	if not _looks.has(key):
		var made: = StandardMaterial3D.new()
		if lit:
			made.albedo_color = colour
			made.emission_enabled = true
			made.emission = colour
			made.emission_energy_multiplier = 6.0
		else:
			made.albedo_color = colour.darkened(0.55)
			made.metallic = 0.2
			made.roughness = 0.1
		_looks[key] = made
	return _looks[key]



func _push_bar(head: Array, half_width: float) -> void :
	var look: = StandardMaterial3D.new()
	look.albedo_color = Color8(20, 20, 22)
	look.roughness = 0.5
	var nose_z: = float(head[2]) - 0.45
	var low: = 0.9
	var high: = float(head[1]) + 0.3
	for x: float in [-1.25, 1.25]:
		var post: = MeshInstance3D.new()
		var box: = BoxMesh.new()
		box.size = Vector3(0.28, high - low, 0.28)
		post.mesh = box
		post.material_override = look
		post.position = Vector3(x, (high + low) / 2.0, nose_z)
		_car.add_child(post)
	for y: float in [high - 0.2, low + 0.55]:
		var bar: = MeshInstance3D.new()
		var box: = BoxMesh.new()
		box.size = Vector3(minf(3.2, half_width), 0.22, 0.26)
		bar.mesh = box
		bar.material_override = look
		bar.position = Vector3(0, y, nose_z - 0.05)
		_car.add_child(bar)


func _undraw() -> void :
	if _car != null:
		_car.queue_free()
		_car = null
	if _officer != null:
		_officer.queue_free()
		_officer = null
	_lamps.clear()
	_glares.clear()
	_lit = -1
	siren = 0.0
	Emergency.watch(self, false)
	_shown_id = -1
