class_name Sky3D
extends Node3D

















const TICK: = 0.5

const SESSION_HOURS: = {"summer": Vector2(8.5, 18.0), "winter": Vector2(9.0, 15.0)}




const NIGHT: = {
	"ambient_energy": 0.9, 
	"top": Color(0.012, 0.018, 0.045), 
	"horizon": Color(0.05, 0.062, 0.105), 
	"haze": Color(0.04, 0.048, 0.075), 
	"saturation": 0.95, 
}
const DAY: = {
	"ambient": Color(0.84, 0.82, 0.8), 
	"ambient_energy": 0.85, 
	"horizon": Color(0.7, 0.79, 0.9), 
	"haze": Color(0.72, 0.79, 0.88), 
	"saturation": 0.98, 
}

const LOW_SUN: = {
	"horizon": Color(0.93, 0.66, 0.46), 
	"haze": Color(0.91, 0.7, 0.56), 
	"ambient": Color(0.62, 0.52, 0.5), 
}
const EVENING_TOP: = Color(0.36, 0.46, 0.7)
const CLOUD_DAY: = Color(1.0, 0.99, 0.97)
const CLOUD_SHADE: = Color(0.66, 0.71, 0.8)
const CLOUD_LOW: = Color(1.0, 0.72, 0.5)
const CLOUD_LOW_SHADE: = Color(0.4, 0.37, 0.52)
const CLOUD_NIGHT: = Color(0.09, 0.1, 0.15)
const CLOUD_NIGHT_SHADE: = Color(0.035, 0.04, 0.065)

const SUN_LOW: = Color(1.0, 0.56, 0.3)
const SUN_ENERGY: = 1.5
const SUN_LEAN: = 0.66
const MOON_LEAN: = 0.9
const HORIZON: = 0.4


const TWILIGHT: = {
	"top": Color(0.05, 0.1, 0.27), 
	"horizon": Color(0.36, 0.3, 0.42), 
	"glow": Color(0.78, 0.45, 0.3), 
	"ambient": Color(0.32, 0.38, 0.62), 
	"haze": Color(0.17, 0.19, 0.31), 
}
const TWILIGHT_DEPTH: = 0.17


const WINTER: = {
	"cloud": 0.88, 
	"horizon": Color(0.74, 0.76, 0.79), 
	"ambient": Color(0.78, 0.82, 0.9), 
	"sun": Color(0.9, 0.94, 1.0), 


	"sky": 0.86, 
	"exposure": 1.16, 
}

static var current: Sky3D

var hour: = 9.0
var running: = true
var overcast: = 0.0
var sun: DirectionalLight3D
var moon_disc: DirectionalLight3D
var environment: Environment
var world_environment: WorldEnvironment
var _material: ShaderMaterial
var _since: = TICK
var _night_known: = false
var hour_given: = false




static func daylight_at(at: float) -> float:
	var settings: Dictionary = Config.Day
	var rising: = clampf(at - (float(settings["Dawn"]) - 0.5), 0.0, 1.0)
	var setting: = clampf((float(settings["Dusk"]) + 0.5) - at, 0.0, 1.0)
	var amount: = minf(rising, setting)
	return amount * amount * (3.0 - 2.0 * amount)


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func daylight() -> float:
	return daylight_at(hour)



func cloud() -> float:
	return maxf(overcast, WINTER["cloud"]) if Style.winter() else overcast



func twilight() -> float:
	var under: = - sun_direction().y
	if under <= -0.04:
		return 0.0
	return clampf(1.0 - under / TWILIGHT_DEPTH, 0.0, 1.0) * clampf((0.04 + under) / 0.06, 0.0, 1.0)


func is_dark() -> bool:
	return hour < float(Config.Day.Dawn) or hour >= float(Config.Day.Dusk)


func set_hour(value: float) -> void :
	hour = fposmod(value, 24.0)
	_apply()


func _ready() -> void :
	sun = DirectionalLight3D.new()
	sun.name = "Sun"
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	sun.directional_shadow_max_distance = 520.0
	sun.directional_shadow_split_1 = 0.055
	sun.directional_shadow_split_2 = 0.16
	sun.directional_shadow_split_3 = 0.42
	sun.directional_shadow_blend_splits = true
	sun.shadow_bias = 0.05
	sun.shadow_normal_bias = 1.6
	sun.shadow_blur = 1.2
	sun.light_angular_distance = 0.5
	sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
	add_child(sun)

	moon_disc = DirectionalLight3D.new()
	moon_disc.name = "Moon"
	moon_disc.sky_mode = DirectionalLight3D.SKY_MODE_SKY_ONLY
	moon_disc.light_color = Color(0.86, 0.9, 1.0)
	moon_disc.light_angular_distance = 1.1
	add_child(moon_disc)

	_material = ShaderMaterial.new()
	_material.shader = load("res://shaders/sky.gdshader")
	_material.set_shader_parameter("stars", _stars())
	var sky: = Sky.new()
	sky.sky_material = _material

	sky.process_mode = Sky.PROCESS_MODE_REALTIME
	sky.radiance_size = Sky.RADIANCE_SIZE_256

	environment = Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	environment.ambient_light_sky_contribution = float(Config.Art.Noon.SkyAmbient)
	environment.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.tonemap_white = 6.0
	environment.ssao_enabled = true
	environment.ssao_radius = 2.4
	environment.ssao_intensity = 1.5
	environment.ssao_power = 1.6
	environment.ssao_light_affect = 0.12
	environment.glow_enabled = true
	environment.glow_intensity = 0.55
	environment.glow_bloom = 0.03
	environment.glow_hdr_threshold = 1.15
	environment.glow_hdr_scale = 1.6
	environment.fog_enabled = true
	environment.fog_density = 0.00035
	environment.fog_aerial_perspective = 0.55
	environment.fog_sky_affect = 0.0
	environment.fog_sun_scatter = 0.08
	environment.adjustment_enabled = true
	environment.adjustment_contrast = 1.05
	world_environment = WorldEnvironment.new()
	world_environment.environment = environment
	add_child(world_environment)

	hour = start_hour()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hour="):
			hour = fposmod(float(arg.substr(7)), 24.0)
			hour_given = true
		elif arg == "--still":
			running = false
	_apply()




static func start_hour() -> float:
	return float(Config.Art.WinterStart) if Style.winter() else float(Config.Day.Start)






static func session_hour(session: int) -> float:
	var span: Vector2 = SESSION_HOURS["winter" if Style.winter() else "summer"]
	var quarters: = int((span.y - span.x) * 4.0) + 1
	return span.x + float(rand_from_seed(hash([session, "hour"]))[0] %quarters) / 4.0



static func config_color(values: Array) -> Color:
	return Color(float(values[0]), float(values[1]), float(values[2]))



func set_shadows(splits: int, distance: float, ambient_occlusion: bool) -> void :
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if splits >= 4 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = distance
	sun.directional_shadow_split_1 = 0.055 if splits >= 4 else 0.2
	environment.ssao_enabled = ambient_occlusion



func set_plain(on: bool) -> void :
	sun.shadow_enabled = not on
	environment.glow_enabled = not on
	environment.fog_enabled = not on


func _process(delta: float) -> void :

	if not _night_known:
		_night_known = true

		if not hour_given and not Net.is_client():
			hour = start_hour()
			_apply()
		Game.set_night(is_dark())
	if running:


		var pace: = 24.0 / (float(Config.Day.Length) * 60.0)
		var dusk: = float(Config.Day.Dusk)
		var golden: = hour >= dusk - float(Config.Art.GoldenBefore) and hour < dusk + float(Config.Art.GoldenAfter)
		var speed: = float(Config.Art.GoldenPace) if golden else (float(Config.Day.NightSpeed) if Game.night else 1.0)
		hour = fposmod(hour + delta * pace * speed, 24.0)
	_since += delta
	if _since >= TICK:
		_since = 0.0
		_apply()
	else:
		_turn()




func sun_direction() -> Vector3:
	var rise: = float(Config.Day.Dawn) - HORIZON
	var set_at: = float(Config.Day.Dusk) + HORIZON
	return _arc((hour - rise) / (set_at - rise), SUN_LEAN)



func moon_direction() -> Vector3:
	var rise: = float(Config.Day.Dawn) - HORIZON
	var set_at: = float(Config.Day.Dusk) + HORIZON
	return _arc(fposmod(hour - set_at, 24.0) / (24.0 - (set_at - rise)), MOON_LEAN)


func _arc(share: float, lean: float) -> Vector3:
	var angle: = share * PI
	return Vector3(cos(angle), sin(angle) * cos(lean), sin(angle) * sin(lean)).normalized()


func _aim(light: DirectionalLight3D, toward: Vector3) -> void :

	light.basis = Basis.looking_at( - toward, Vector3.UP if absf(toward.y) < 0.99 else Vector3.RIGHT)




func _turn() -> void :
	var to_sun: = sun_direction()
	var to_moon: = moon_direction()
	_aim(moon_disc, to_moon)
	moon_disc.light_energy = clampf(to_moon.y / 0.08, 0.0, 1.0) * 0.55
	var cover: = cloud()
	if to_sun.y > 0.0:
		_aim(sun, to_sun)

		sun.light_color = SUN_LOW.lerp(config_color(Config.Art.Noon.Sun), smoothstep(0.08, 0.62, to_sun.y))
		if Style.winter():
			sun.light_color = WINTER["sun"].lerp(SUN_LOW, 0.25 * (1.0 - smoothstep(0.0, 0.2, to_sun.y)))
		sun.light_energy = SUN_ENERGY * smoothstep(0.0, 0.2, to_sun.y) * (1.0 - 0.62 * cover)

		sun.shadow_opacity = 1.0 - 0.75 * cover
		sun.light_angular_distance = 0.5
		sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
	else:
		_aim(sun, to_moon)
		var night: Dictionary = Config.Art.Night
		sun.light_color = config_color(night["MoonColor"])
		sun.light_energy = float(night["Moon"]) * smoothstep(0.0, 0.2, to_moon.y) * (1.0 - 0.8 * cover)
		sun.light_angular_distance = 1.5
		sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY


func _apply() -> void :
	_turn()
	var amount: = daylight()
	var cover: = cloud()
	var winter: = Style.winter()
	var dusk: = twilight()
	RenderingServer.global_shader_parameter_set("daylight", amount)
	FirefighterRig.night_bands(1.0 - amount)

	var low: = clampf(1.0 - absf(amount - 0.35) / 0.35, 0.0, 1.0)

	var to_sun: = sun_direction()
	var evening: = (1.0 - smoothstep(0.0, 0.45, to_sun.y)) * clampf(amount * 4.0 + 0.25, 0.0, 1.0)
	var glow: = maxf(low, maxf(clampf(1.0 - absf(to_sun.y) / 0.3, 0.0, 1.0) * clampf(amount * 4.0 + 0.25, 0.0, 1.0), evening * 0.75))
	var night_horizon: Color = NIGHT["horizon"]
	var horizon: = night_horizon.lerp(DAY["horizon"], amount).lerp(LOW_SUN["horizon"], glow * 0.85)
	var night_top: Color = NIGHT["top"]
	var night_ambient: Color = config_color(Config.Art.Night.Ambient)
	var night_haze: Color = NIGHT["haze"]
	var top: = night_top.lerp(config_color(Config.Art.Noon.Sky), amount)

	top = top.lerp(EVENING_TOP, evening * 0.55)

	top = top.lerp(TWILIGHT["top"], dusk * (1.0 - amount))
	horizon = horizon.lerp(TWILIGHT["horizon"].lerp(TWILIGHT["glow"], clampf(1.0 + to_sun.y / 0.06, 0.0, 1.0)), dusk * (1.0 - amount * 0.6))
	var ambient: Color = night_ambient.lerp(DAY["ambient"], amount).lerp(LOW_SUN["ambient"], maxf(low * 0.5, evening * 0.55)).lerp(TWILIGHT["ambient"], dusk * (1.0 - amount))
	var haze: Color = night_haze.lerp(DAY["haze"], amount).lerp(LOW_SUN["haze"], glow * 0.6).lerp(TWILIGHT["haze"], dusk * (1.0 - amount))
	_material.set_shader_parameter("ground_bottom_color", Color(0.03, 0.035, 0.045).lerp(Color(0.34, 0.36, 0.34), amount))
	_material.set_shader_parameter("star_strength", pow(1.0 - amount, 3.0) * (1.0 - dusk))

	var lit: Color = CLOUD_NIGHT.lerp(CLOUD_DAY, amount).lerp(CLOUD_LOW, glow * 0.8).lerp(TWILIGHT["glow"] * 0.7, dusk * (1.0 - amount) * 0.6)
	var shade: Color = CLOUD_NIGHT_SHADE.lerp(top.lerp(horizon, 0.5).lerp(CLOUD_SHADE, 0.6), amount).lerp(CLOUD_LOW_SHADE, glow * 0.6)
	_material.set_shader_parameter("sun_direction", to_sun if to_sun.y > -0.25 else moon_direction())
	_material.set_shader_parameter("cloud_alpha", lerpf(0.45, 1.0, maxf(amount, dusk * 0.8)))

	_material.set_shader_parameter("cloud_cover", lerpf(0.55, 1.05, cover))
	if cover > 0.0:
		var grey: = Color(0.58, 0.6, 0.64)
		if winter:
			grey = WINTER["horizon"]
			top = top.lerp(config_color(Config.Art.Winter.Sky).lerp(night_top, 1.0 - amount), cover)
		grey = grey.lerp(Color(0.08, 0.09, 0.11), 1.0 - maxf(amount, dusk * 0.5))
		lit = lit.lerp(grey, cover * 0.85)
		shade = shade.lerp(grey * 0.72, cover * 0.85)
		horizon = horizon.lerp(grey, cover * 0.92)
		top = top.lerp(grey * 0.9, cover * 0.92)
	if winter:
		var dim: float = WINTER["sky"]
		lit = lit.darkened(1.0 - dim)
		shade = shade.darkened(1.0 - dim)
		horizon = horizon.darkened(1.0 - dim)
		top = top.darkened(1.0 - dim)
	_material.set_shader_parameter("cloud_lit", lit)
	_material.set_shader_parameter("cloud_shade", shade)
	_material.set_shader_parameter("sky_top_color", top)
	_material.set_shader_parameter("sky_horizon_color", horizon)
	_material.set_shader_parameter("ground_horizon_color", horizon)
	if winter:
		ambient = ambient.lerp(WINTER["ambient"] * maxf(amount, 0.35), maxf(amount, dusk))
		haze = haze.lerp(config_color(Config.Art.Winter.Haze), amount)
	environment.ambient_light_color = ambient
	environment.ambient_light_energy = lerpf(NIGHT["ambient_energy"], DAY["ambient_energy"], amount) * (1.0 + 0.25 * cover)
	environment.fog_light_color = haze
	environment.fog_light_energy = lerpf(0.5, 1.0, amount) * (1.0 - 0.3 * cover) * (1.25 * float(WINTER["sky"]) if winter else 1.0)


	var mist: = clampf(1.0 - absf(hour - (float(Config.Day.Dawn) + 0.8)) / 1.6, 0.0, 1.0)
	environment.fog_density = 0.00035 * (1.0 + 2.2 * cover) + 0.0004 * mist
	environment.fog_height = 6.0
	environment.fog_height_density = 0.03 * mist + 0.006 * cover
	environment.fog_sky_affect = 0.0
	environment.fog_sun_scatter = 0.08
	if winter:
		environment.fog_density = float(Config.Art.Winter.Fog) + 0.0006 * mist
		environment.fog_height_density = 0.012 + 0.02 * mist
		environment.fog_sky_affect = 0.55
		environment.fog_sun_scatter = 0.0


	environment.tonemap_mode = Environment.TONE_MAPPER_AGX if winter else Environment.TONE_MAPPER_ACES
	environment.tonemap_white = 16.0 if winter else 6.0
	environment.tonemap_exposure = float(WINTER["exposure"]) if winter else 1.0
	environment.adjustment_contrast = 1.12 if winter else 1.05
	environment.adjustment_saturation = lerpf(NIGHT["saturation"], DAY["saturation"], amount) * (float(Config.Art.Winter.Saturation) if winter else 1.0)

	var lifted: = night_ambient * float(Config.Art.Night.GroundLift) * (1.0 - amount)
	RenderingServer.global_shader_parameter_set("ground_lift", Vector4(lifted.r, lifted.g, lifted.b, float(Config.Art.Night.LiftFrom)))
	VehicleLook.night_lift(lifted)

	RenderingServer.global_shader_parameter_set("low_sun", clampf(maxf(evening, dusk) * (1.0 - cover * 0.5), 0.0, 1.0))

	environment.glow_intensity = lerpf(0.9, 0.55, amount)
	environment.glow_hdr_threshold = lerpf(1.05, 1.15, amount)
	if _night_known:
		Game.set_night(is_dark())



func _stars() -> ImageTexture:
	var width: = 4096
	var height: = 2048
	var bytes: = PackedByteArray()
	bytes.resize(width * height)
	var random: = RandomNumberGenerator.new()
	random.seed = 1869
	for index in 2000:

		var up: = random.randf()
		var y: = int((1.0 - asin(up) / (PI / 2.0)) * (height / 2.0 - 2.0))
		var x: = random.randi_range(0, width - 1)
		var bright: = int(lerpf(50.0, 255.0, pow(random.randf(), 4.0)))

		var across: = clampi(roundi(1.0 / maxf(cos(asin(up)), 0.08)), 1, 12)
		for step in across:
			var at: = y * width + (x + step) % width
			bytes[at] = maxi(bytes[at], bright)
		if bright > 190 and y + 1 < height:
			for step in across:
				bytes[(y + 1) * width + (x + step) % width] = int(bright / 2.0)
	return ImageTexture.create_from_image(Image.create_from_data(width, height, false, Image.FORMAT_L8, bytes))
