extends Node

























signal changed

const MANIFEST_URL: = "https://play.firecrewgame.com/update/manifest.json"
const PUBLIC_KEY: = "-----BEGIN PUBLIC KEY-----\nMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEApHqYcKwmMLO2l+SjghoA\ntMcsR+VNXDq2toX0sT97m1fXgC1COva3GqE6r0z3k+rChQuGOa6ZAail28gr6Lim\n1fgfMFS/UZ5AWURcn26/e3SpY1uoAQhBNhcawDlJjuNAgAWD6zI0eWStYjFDsOYt\n8MNBKB7IoeESk0lomQQPCKb+C+qnhxm3o4hqJXZfub83JUMuiub7jJCuQivmFnD7\nolbX2P3HkzyuXmMefE/JJSKquHF2+kDWhqzG5/AwKG6qYmX+n/ZxxM8tcBakP3e1\n+Vc35ozpk6OLjqbUWzIPMMGSmDN+OzeE+I/kifxcJj0nANKvqrd2fi5kNQs4ZToc\ny0TbCRbtxvkRFYrUhaedugYio9f/YPPTYlEzZcvaNkms+B/8pdgJNXnCJ4CGB0fS\nIMaX2ds36vgMKLilYxj3h0PWeNIbCkZpFhy540GZgHs4POGgwbDdFgj4AwapgVpD\n6ftOxFQbzEeK32gZbffE+FShvmKTs1WP/qd5nH172FyDAgMBAAE=\n-----END PUBLIC KEY-----"











const TRIES: = 2
const MANIFEST_TIMEOUT: = 15.0

const GLOBAL_TYPES: = ["bool", "bvec2", "bvec3", "bvec4", "int", "ivec2", "ivec3", "ivec4", "rect2i", "uint", 
	"uvec2", "uvec3", "uvec4", "float", "vec2", "vec3", "vec4", "color", "rect2", "mat2", "mat3", "mat4", 
	"transform_2d", "transform", "sampler2D", "sampler2DArray", "sampler3D", "samplerCube", "samplerExternalOES"]



var state: = "off"

var base: = ""
var version: = ""

var target: = ""
var latest: = ""
var download_page: = "https://firecrewgame.com/"

var progress: = 0.0

var _dir: = "user://updates"
var _url: = MANIFEST_URL
var _platform: = ""
var _loaded: = ""
var _bad: Array = []
var _http: HTTPRequest
var _file: Dictionary = {}
var _hasher: Thread
var _told: = 0.0


func _init() -> void :
	base = _read_version()
	version = base
	var args: = OS.get_cmdline_user_args()
	var tried: = false
	for arg in args:
		if arg.begins_with("--update-url="):
			_url = arg.substr(13)
			tried = true
		elif arg.begins_with("--updates-dir="):
			_dir = arg.substr(14)
	_platform = {"macOS": "macos", "Windows": "windows"}.get(OS.get_name(), "")
	if not OS.has_feature("template") or args.has("--no-update") or _platform.is_empty() or base.is_empty():
		return
	if not _url.begins_with("https://") and not tried:
		return
	state = "checking"
	DirAccess.make_dir_recursive_absolute(_dir)
	var saved: = _state()
	_bad = saved.get_value("bad", "versions", [])
	var file: = str(saved.get_value("patch", "file", ""))
	if not file.is_empty() and str(saved.get_value("patch", "base", "")) != base:

		print("[update] the patch %s was for %s; this is %s" % [saved.get_value("patch", "version"), saved.get_value("patch", "base"), base])
		_forget(saved)
		file = ""
	if not file.is_empty():
		var patch: = str(saved.get_value("patch", "version", ""))
		var tries: = int(saved.get_value("patch", "tries", 0))
		var path: = _dir.path_join(file)
		if not FileAccess.file_exists(path) or FileAccess.get_size(path) != int(saved.get_value("patch", "size", -1)):
			print("[update] the patch %s is missing or cut short" % patch)
			_forget(saved)
		elif tries >= TRIES:
			print("[update] the patch %s never reached the title in %d starts: back to %s" % [patch, tries, base])
			_give_up(saved, patch)
		else:
			saved.set_value("patch", "tries", tries + 1)
			saved.save(_dir.path_join("state.cfg"))
			if ProjectSettings.load_resource_pack(path, true):
				version = patch
				_loaded = file
				_add_shader_globals()
				print("[update] running %s (a patch over %s)" % [version, base])
			else:
				print("[update] the patch %s would not load" % patch)
				_give_up(saved, patch)
	saved.save(_dir.path_join("state.cfg"))

	for name in DirAccess.get_files_at(_dir):
		if (name.ends_with(".pck") or name.ends_with(".part")) and name != _loaded:
			DirAccess.remove_absolute(_dir.path_join(name))


func _ready() -> void :
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process(false)
	if state == "off":
		return
	_http = HTTPRequest.new()
	_http.use_threads = true
	add_child(_http)
	_check.call_deferred()



func booted() -> void :
	if _loaded.is_empty():
		return
	var saved: = _state()
	if str(saved.get_value("patch", "file", "")) == _loaded:
		saved.set_value("patch", "tries", 0)
		saved.save(_dir.path_join("state.cfg"))


func _check() -> void :
	_http.timeout = MANIFEST_TIMEOUT
	_http.request_completed.connect(_on_manifest, CONNECT_ONE_SHOT)
	if _http.request(_url) != OK:
		_fail("could not ask for %s" % _url)


func _on_manifest(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void :
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_fail("no manifest (%d, HTTP %d)" % [result, code])
		return
	var manifest: = _verified(body)
	if manifest.is_empty():
		_fail("the manifest is not signed by our key")
		return
	latest = str(manifest.get("latest", ""))
	if manifest.get("download_page") is String and str(manifest["download_page"]).begins_with("https://"):
		download_page = manifest["download_page"]
	state = "current"
	var bases: Variant = manifest.get("bases")
	var entry: Variant = bases.get(base) if bases is Dictionary else null
	if entry is Dictionary and entry.get("version") is String:
		var want: String = entry["version"]
		if want == version or want in _bad:
			pass
		elif want == base:

			var saved: = _state()
			_forget(saved)
			saved.save(_dir.path_join("state.cfg"))
			target = base
			state = "ready"
			print("[update] back to %s at the next start" % base)
		else:
			var files: Variant = entry.get("files")
			var file: Variant = files.get(_platform) if files is Dictionary else null
			if file is Dictionary and file.get("url") is String and file.get("sha256") is String:
				_download(want, file)
				return
			print("[update] %s has no file for %s" % [want, _platform])
	_settle()


func _download(want: String, file: Dictionary) -> void :
	if not str(file["url"]).begins_with("https://") and _url == MANIFEST_URL:
		_fail("the patch is not on https")
		return
	target = want
	_file = file
	state = "downloading"
	progress = 0.0
	print("[update] downloading %s (%.1f MB)" % [want, float(file.get("size", 0)) / 1048576.0])
	_http.timeout = 0.0
	_http.body_size_limit = -1
	_http.download_file = _dir.path_join("download.part")
	_http.request_completed.connect(_on_downloaded, CONNECT_ONE_SHOT)
	if _http.request(file["url"]) != OK:
		_fail("could not ask for %s" % file["url"])
		return
	set_process(true)
	changed.emit()


func _process(delta: float) -> void :
	if state == "downloading" and _hasher == null:
		var size: = maxi(1, int(_file.get("size", _http.get_body_size())))
		progress = clampf(float(_http.get_downloaded_bytes()) / float(size), 0.0, 1.0)
		_told += delta
		if _told >= 0.25:
			_told = 0.0
			changed.emit()
	elif _hasher != null and not _hasher.is_alive():
		var digest: String = _hasher.wait_to_finish()
		_hasher = null
		set_process(false)
		_downloaded(digest)


func _on_downloaded(result: int, code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void :
	var part: = _dir.path_join("download.part")
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		DirAccess.remove_absolute(part)
		set_process(false)
		_fail("the download of %s stopped (%d, HTTP %d)" % [target, result, code])
		return
	progress = 1.0

	_hasher = Thread.new()
	_hasher.start(_sha256.bind(part))


func _downloaded(digest: String) -> void :
	var part: = _dir.path_join("download.part")
	var size: = FileAccess.get_size(part)
	if digest != str(_file["sha256"]).to_lower() or (_file.has("size") and size != int(_file["size"])):
		DirAccess.remove_absolute(part)
		_fail("the download of %s is not the file the manifest names" % target)
		return
	var name: = "%s-%s.pck" % [target, _platform]
	var path: = _dir.path_join(name)
	if name == _loaded:
		_fail("%s is already loaded" % target)
		return
	DirAccess.remove_absolute(path)
	if DirAccess.rename_absolute(part, path) != OK:
		_fail("could not keep the download of %s" % target)
		return
	var saved: = _state()
	_forget(saved)
	saved.set_value("patch", "version", target)
	saved.set_value("patch", "base", base)
	saved.set_value("patch", "file", name)
	saved.set_value("patch", "size", size)
	saved.set_value("patch", "tries", 0)
	saved.save(_dir.path_join("state.cfg"))
	state = "ready"
	print("[update] %s is ready for the next start" % target)
	_settle()



func _settle() -> void :
	if state in ["current", "failed"] and _newer(latest, version):
		state = "full"
		print("[update] %s is out as a new full download (%s)" % [latest, download_page])
	changed.emit()


func _fail(why: String) -> void :
	print("[update] " + why)
	state = "failed"
	_settle()



func _verified(body: PackedByteArray) -> Dictionary:
	var outer: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not outer is Dictionary or not outer.get("payload") is String or not outer.get("sig") is String:
		return {}
	var payload: = Marshalls.base64_to_raw(outer["payload"])
	var signature: = Marshalls.base64_to_raw(outer["sig"])
	var key: = CryptoKey.new()
	if payload.is_empty() or signature.is_empty() or key.load_from_string(PUBLIC_KEY, true) != OK:
		return {}
	var hashing: = HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(payload)
	if not Crypto.new().verify(HashingContext.HASH_SHA256, hashing.finish(), signature, key):
		return {}
	var data: Variant = JSON.parse_string(payload.get_string_from_utf8())
	return data if data is Dictionary and int(data.get("format", 0)) == 1 else {}


func _give_up(saved: ConfigFile, patch: String) -> void :
	if not patch in _bad:
		_bad.append(patch)
	saved.set_value("bad", "versions", _bad)
	_forget(saved)



static func _forget(saved: ConfigFile) -> void :
	if saved.has_section("patch"):
		saved.erase_section("patch")


func _state() -> ConfigFile:
	var saved: = ConfigFile.new()
	saved.load(_dir.path_join("state.cfg"))
	return saved





func _add_shader_globals() -> void :
	var settings: = FileAccess.open("res://project.binary", FileAccess.READ)
	if settings == null or settings.get_buffer(4).get_string_from_ascii() != "ECFG":
		return
	var have: = RenderingServer.global_shader_parameter_get_list()
	for i in settings.get_32():
		var key: = settings.get_pascal_string()
		var raw: = settings.get_buffer(settings.get_32())
		if not key.begins_with("shader_globals/") or StringName(key.substr(15)) in have:
			continue
		var spec: Variant = bytes_to_var(raw)
		if not spec is Dictionary or not str(spec.get("type", "")) in GLOBAL_TYPES:
			continue
		var value: Variant = spec.get("value")
		if value is String:
			value = load(value) if not value.is_empty() else null
		RenderingServer.global_shader_parameter_add(key.substr(15), GLOBAL_TYPES.find(spec["type"]), value)
		print("[update] shader global %s added" % key.substr(15))



static func _read_version() -> String:
	var settings: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/godot/Config.json"))
	if settings is Dictionary and settings.get("Net") is Dictionary:
		return str(settings["Net"].get("Version", ""))
	return ""


static func _sha256(path: String) -> String:
	var file: = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return ""
	var hashing: = HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	while file.get_position() < file.get_length():
		hashing.update(file.get_buffer(1 << 20))
	return hashing.finish().hex_encode()



static func _newer(a: String, b: String) -> bool:
	if a.is_empty() or b.is_empty():
		return false
	var x: = a.split("-", true, 1)
	var y: = b.split("-", true, 1)
	var xs: = x[0].split(".")
	var ys: = y[0].split(".")
	for i in maxi(xs.size(), ys.size()):
		var p: = int(xs[i]) if i < xs.size() else 0
		var q: = int(ys[i]) if i < ys.size() else 0
		if p != q:
			return p > q

	return x.size() < y.size()
