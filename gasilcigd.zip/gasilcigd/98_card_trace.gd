extends RefCounted



static func start(main: Node) -> void :
	if OS.get_cmdline_user_args().has("--card-trace"):
		var trace: = CardTrace.new()
		trace.name = "CardTrace"
		main.add_child(trace)
