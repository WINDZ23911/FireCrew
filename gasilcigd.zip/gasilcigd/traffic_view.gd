class_name TrafficView
extends Node3D





const FOLLOW: = 14.0
const UNDER: = 0.6
const HEARD: = 120.0
const BEAMS: = 160.0

const LAMP: = [Color8(210, 210, 200), Color8(255, 244, 214)]
const TAIL: = [Color8(96, 20, 18), Color8(255, 40, 30)]
const BLINK: = [Color8(120, 84, 20), Color8(255, 170, 30)]

const GLARES: = {"head": [Color(1.0, 0.93, 0.8), 2.4, 0.7], "tail": [Color(1.0, 0.12, 0.06), 1.8, 0.55], "blink": [Color(1.0, 0.6, 0.1), 1.6, 0.6]}

static var current: TrafficView


class Drawn:
	extends RefCounted
	var car: Traffic.Car
	var model: Node3D
	var lamps: Dictionary = {}
	var glares: Dictionary = {}
	var beam: SpotLight3D
	var shown: = Transform3D.IDENTITY
	var note: PassingEngine
	var head: = -1
	var tail: = -1
	var blink: = -1
	var beamed: = -1
	var flush: = false
	var beacons: Array = []
	var lit: = -1


var traffic: Traffic
var drawn: Dictionary = {}
var _range: = 500.0
var _keep: = 530.0
var _lamp_materials: Dictionary = {}


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func start(source: Traffic) -> void :
	traffic = source
	_range = Config.Life.VehicleRange
	_keep = _range + 30.0
	source.vehicle_added.connect( func(car: Traffic.Car) -> void :
		var record: = Drawn.new()
		record.car = car
		drawn[car.id] = record
	)
	source.vehicle_removed.connect( func(car: Traffic.Car) -> void :
		if drawn.has(car.id):
			_undraw(drawn[car.id])
			drawn.erase(car.id)
	)
	for car in source.vehicles:
		var record: = Drawn.new()
		record.car = car
		drawn[car.id] = record





func _lamp_material(colors: Array, on: bool) -> StandardMaterial3D:
	var key: = [colors[0], on]
	if _lamp_materials.has(key):
		return _lamp_materials[key]
	var made: = StandardMaterial3D.new()
	made.albedo_color = colors[1 if on else 0]
	if on:

		made.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	else:
		made.roughness = 0.5
	_lamp_materials[key] = made
	return made


func _lamp(record: Drawn, group: String, size: Vector3, place: Transform3D, colors: Array) -> void :
	var mesh: = MeshInstance3D.new()
	mesh.name = group
	mesh.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	mesh.transform = place * Transform3D(Basis.from_scale(size), Vector3.ZERO)
	mesh.material_override = _lamp_material(colors, false)
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mesh.visible = not record.flush
	record.model.add_child(mesh)
	if not record.lamps.has(group):
		record.lamps[group] = []
		record.glares[group] = []
	record.lamps[group].append(mesh)

	var glare: Array = GLARES[group]
	var behind: = place.origin.z > 0.0
	var flare: = VehicleLook.flare(record.model, place.origin + Vector3(0, 0, 0.15 if behind else -0.15), glare[0], glare[1], 1.0)
	if behind:
		flare.rotation.y = PI
	record.glares[group].append(flare)




func _lamps_at(record: Drawn, width: float, height: float, front: float, back: float, tail_width: float, tail_height: float) -> void :

	var tall: = tail_width > 2.5
	var deep: = 0.06 if record.flush else 0.2
	for side: float in [-1.0, 1.0]:
		var x: = side * width
		_lamp(record, "head", Vector3(1.0, 0.3, deep) if record.flush else Vector3(1.1, 0.5, 0.2), Rbx.at(x, height, front), LAMP)
		_lamp(record, "tail", Vector3(0.4, 1.4, deep) if tall else Vector3(1.0, 0.34 if record.flush else 0.5, deep), Rbx.at(side * tail_width, tail_height, back), TAIL)


		_lamp(record, "blink", Vector3(0.4, 0.5, 0.2), Rbx.at(x + side * 0.3, height, front - 0.03), BLINK)
		var rear: = Rbx.at(side * tail_width, tail_height - 0.5, back + 0.03) if tall else Rbx.at(side * (tail_width + 0.3), tail_height, back + 0.03)
		_lamp(record, "blink", Vector3(0.4, 0.4 if tall else 0.5, 0.2), rear, BLINK)



func _build(record: Drawn) -> void :
	var car: = record.car
	var beam_at: = Vector3(0, 2.2, -7.6)
	if car.kind == "plow":
		_build_plow(record)
		beam_at = Vector3(0, 8.9, PlowBody.CAB_FRONT - 0.2)
	elif car.kind == "bus":

		record.model = Node3D.new()
		record.model.name = "Bus"
		var body: = MeshInstance3D.new()
		body.name = "Body"
		body.mesh = BusBody.body_mesh(car.color)
		body.material_override = BusBody.paint()
		record.model.add_child(body)
		for piece: Dictionary in BusBody.pieces(car.color):
			if piece.has("lamp"):
				var colors: Array = LAMP if piece["lamp"] == "head" else (TAIL if piece["lamp"] == "tail" else BLINK)
				_lamp(record, piece["lamp"], piece["size"], piece["cframe"], colors)
			if piece.has("text"):
				record.model.add_child(BusBody.letter(piece))
		VehicleLook.contact_shadow(record.model, Vector3.ZERO, BusBody.SIZE.x, BusBody.SIZE.z)
		beam_at = Vector3(0, 3.1, BusBody.FRONT - 0.2)
	else:

		var shape: = CarKit.pick(car.shape)
		record.model = CarKit.build(shape, CarKit.paint_of(car.color), car.id)
		var lamps: Dictionary = CarKit.data(shape).get("lamps", {})
		var head: Array = lamps.get("head", [[-2.0, 2.2, -7.55], [2.0, 2.2, -7.55]])[1]
		var tail: Array = lamps.get("tail", [[-2.0, 2.2, 7.55], [2.0, 2.2, 7.55]])[1]
		record.flush = CarKit.data(shape).has("plates")
		var out: = 0.02 if record.flush else 0.08
		_lamps_at(record, head[0], head[1], head[2] - out, tail[2] + out, tail[0], tail[1])
		beam_at = Vector3(0, head[1], head[2] - 0.1)

	record.beam = SpotLight3D.new()
	record.beam.spot_angle = 38.0
	record.beam.spot_range = 50.0 if car.kind == "bus" else 46.0
	record.beam.light_energy = 2.2
	record.beam.light_color = LAMP[1]
	record.beam.shadow_enabled = false
	record.beam.position = beam_at
	record.beam.rotation = Vector3(deg_to_rad(-6.0), 0, 0)
	record.beam.visible = false
	record.model.add_child(record.beam)
	add_child(record.model)
	record.shown = car.place
	record.head = -1
	record.tail = -1
	record.blink = -1
	record.beamed = -1




func _build_plow(record: Drawn) -> void :
	var model: = Node3D.new()
	model.name = "Plow"
	record.model = model
	var body: = MeshInstance3D.new()
	body.name = "Body"
	body.mesh = PlowBody.mesh()
	body.material_override = BusBody.paint()
	model.add_child(body)
	for piece: Dictionary in PlowBody.pieces():
		if piece.has("lamp"):
			var colors: Array = LAMP if piece["lamp"] == "head" else (TAIL if piece["lamp"] == "tail" else BLINK)
			_lamp(record, piece["lamp"], piece["size"], piece["cframe"], colors)
		elif piece.has("beacon"):
			var at: Vector3 = piece["cframe"].origin
			var lamp: = CallKit.piece(model, CallKit.CYLINDER if piece.get("shape") == "cylinder" else CallKit.BLOCK, piece["size"], piece["cframe"], BLINK[0])
			lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var glare: = VehicleLook.flare(model, at, GLARES["blink"][0], 2.6, 0.0)
			record.beacons.append([lamp, glare])
	VehicleLook.contact_shadow(model, Vector3.ZERO, Traffic.PLOW_SIZE.x, Traffic.PLOW_SIZE.z)



func _flash_beacons(record: Drawn) -> void :
	if record.beacons.is_empty():
		return
	var beat: = fmod(HostClock.now() * 3.0, 2.0)
	var lit: = 0 if beat < 1.0 else 1
	if fmod(beat, 1.0) > 0.6:
		lit = -2
	if lit == record.lit:
		return
	record.lit = lit
	for index in record.beacons.size():
		var on: = index == lit
		var pair: Array = record.beacons[index]
		pair[0].material_override = _lamp_material(BLINK, on)
		VehicleLook.shine(pair[1], 0.9 * maxf(VehicleLook.glare_now(), 0.6) if on else 0.0)


func _undraw(record: Drawn) -> void :
	if record.note:
		record.note.stop()
		record.note = null
	if record.model:
		record.model.queue_free()
		record.model = null
		record.lamps = {}
		record.glares = {}
		record.beam = null
		record.beacons = []
		record.lit = -1



func _light(record: Drawn, group: String, colors: Array, level: int) -> void :
	var material: = _lamp_material(colors, level > 0) if level != 1 else _dim_material(colors)
	for mesh: MeshInstance3D in record.lamps.get(group, []):
		mesh.material_override = material
		if record.flush:
			mesh.visible = level > 0
	var glare: Array = GLARES[group]
	var strength: float = glare[2] * VehicleLook.glare_now() * (0.45 if level == 1 else 1.0)
	for flare: MeshInstance3D in record.glares.get(group, []):
		VehicleLook.shine(flare, strength if level > 0 else 0.0)


func _dim_material(colors: Array) -> StandardMaterial3D:
	var key: = [colors[0], "dim"]
	if not _lamp_materials.has(key):
		var made: = StandardMaterial3D.new()
		made.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		made.albedo_color = colors[0].lerp(colors[1], 0.55)
		_lamp_materials[key] = made
	return _lamp_materials[key]


func _process(dt: float) -> void :
	if traffic == null:
		return
	var camera: = get_viewport().get_camera_3d()
	var eye: = camera.global_position if camera else Vector3.ZERO
	var night: = Game.night
	var flash: = fmod(HostClock.now(), 1.0) < 0.5

	for record: Drawn in drawn.values():
		var car: = record.car
		var target: = car.place
		var away: = target.origin.distance_to(eye)
		if away > (_keep if record.model else _range):
			_undraw(record)
			continue
		if record.model == null:
			_build(record)


		var was: = record.shown.origin
		if was.distance_to(target.origin) > 40.0:
			record.shown = target
			was = target.origin
		else:
			record.shown = record.shown.interpolate_with(target, 1.0 - exp( - dt * FOLLOW))


		if record.note and away > HEARD + 20.0:
			record.note.stop()
			record.note = null
		elif record.note == null and away < HEARD:
			var bus: = car.kind == "bus" or car.kind == "plow"
			record.note = PassingEngine.make(record.model, "six" if bus else "four", 150.0 if bus else 110.0, 0.7 if bus else 0.4)
		if record.note:
			record.note.update(record.shown.origin.distance_to(was) / maxf(dt, 0.001), dt)

		var head: = 1 if night else 0
		if head != record.head:
			record.head = head
			_light(record, "head", LAMP, 2 if night else 0)
		var beamed: = 1 if night and away < BEAMS else 0
		if beamed != record.beamed:
			record.beamed = beamed
			record.beam.visible = beamed == 1

		var tail: = 2 if car.braking else (1 if night else 0)
		if tail != record.tail:
			record.tail = tail
			_light(record, "tail", TAIL, tail)
		_flash_beacons(record)
		var blink: = 1 if car.standing and flash else 0
		if blink != record.blink:
			record.blink = blink
			_light(record, "blink", BLINK, 2 if blink == 1 else 0)

		record.model.global_transform = record.shown * Transform3D(Basis.IDENTITY, Vector3(0, - (car.size.y / 2.0 + UNDER), 0))
