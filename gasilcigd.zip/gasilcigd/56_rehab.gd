extends RefCounted



static func start(main: Node) -> void :
	var rehab: = Rehab.new()
	rehab.name = "Rehab"
	main.add_child(rehab)
