class_name Lockers
extends Node3D
















signal menu_wanted(player: Player, handle: Dictionary)

const REACH: = 14.0

static var _made: Dictionary = {}
static var _shared: = false

var vehicle: Vehicle
var bay: = false
var hatches: = false
var lines: Array[LockerLine] = []
var handles: Array = []



static func of(wanted: Vehicle) -> Lockers:
	if wanted == null or wanted.shutters.is_empty():
		return null
	var made: Variant = _made.get(wanted)
	if made != null and is_instance_valid(made):
		return made
	var lockers: = Lockers.new()
	lockers.name = "Lockers"
	lockers.vehicle = wanted
	wanted.add_child(lockers)
	_made[wanted] = lockers
	return lockers


func _exit_tree() -> void :
	_made.erase(vehicle)






static func share() -> void :
	if _shared:
		return
	_shared = true

	Net.handle("locker.menu", func(path: String, index: int) -> void :
		var lockers: = _at(path)
		if lockers != null and index >= 0 and index < lockers.handles.size() and Game.local_player != null:
			lockers.menu_wanted.emit(Game.local_player, lockers.handles[index])
	)

	Net.handle("locker.use", func(player: Player, path: String, index: int, choice: Variant) -> void :
		var lockers: = _at(path)
		if lockers == null or index < 0 or index >= lockers.handles.size():
			return
		var handle: Dictionary = lockers.handles[index]
		if choice is String and choice == "all":
			lockers.use(player, handle, "all")
		elif choice is String and choice == "close":
			lockers.use(player, handle, null)
		elif (choice is int or choice is float) and int(choice) >= 0 and int(choice) < lockers.lines.size():
			lockers.use(player, handle, lockers.lines[int(choice)])
	)

	Net.handle("locker.clunk", func(path: String, index: int) -> void :
		var lockers: = _at(path)
		if lockers != null and index >= 0 and index < lockers.handles.size():
			lockers._clunk(lockers.handles[index])
	)

	Net.share("lockers.lines", func() -> Variant:
		var all: = {}
		for vehicle: Variant in _made:
			if not is_instance_valid(vehicle) or not is_instance_valid(_made[vehicle]):
				continue
			var said: Array = []
			for line: LockerLine in _made[vehicle].lines:
				said.append([line.action, line.object, Net.peer_of(line.holder) if (line.holder != null and is_instance_valid(line.holder)) else 0, line.tint])
			all[String(vehicle.get_path())] = said
		return all
	, func(all: Variant) -> void :
		for path: String in all:
			var lockers: = _at(path)
			if lockers == null:
				continue
			var said: Array = all[path]
			for at in mini(said.size(), lockers.lines.size()):
				var line: = lockers.lines[at]
				line.action = said[at][0]
				line.object = said[at][1]
				line.holder = Net.player_of(int(said[at][2])) if int(said[at][2]) != 0 else null
				line.tint = String(said[at][3]) if (said[at] as Array).size() > 3 else ""
	, 5.0)

	Net.stopped.connect( func() -> void :
		for vehicle: Variant in _made:
			if is_instance_valid(vehicle) and is_instance_valid(_made[vehicle]):
				for line: LockerLine in _made[vehicle].lines:
					if line.holder != null and not (is_instance_valid(line.holder) and line.holder.is_local):
						line.holder = null
	)


static func _at(path: String) -> Lockers:
	var vehicle: = Net.get_node_or_null(NodePath(path)) as Vehicle
	return of(vehicle) if vehicle != null else null


func _ready() -> void :
	var infos: Dictionary = Vehicle.table(vehicle.data.get("shutters"))
	for shutter_name: String in infos:
		hatches = hatches or infos[shutter_name].has("action")
	bay = infos.size() > 1
	if not bay:
		for shutter_name: String in infos:
			var at: Array = infos[shutter_name]["prompt"]
			_add_handle(Vector3(at[0], at[1], at[2]), [shutter_name], 9.0)
		return


	for side: float in [-1.0, 1.0]:
		var out: = 0.0
		var low: = INF
		var high: = - INF
		var height: = 2.6
		for shutter_name: String in infos:
			var at: Array = infos[shutter_name]["prompt"]
			if shutter_name != "Rear" and float(at[0]) * side > 0.0:
				out = maxf(out, absf(at[0]))
				low = minf(low, at[2])
				high = maxf(high, at[2])
				if hatches:
					height = at[1]
		if out > 0.0:
			_add_handle(Vector3(side * out, height, (low + high) / 2.0), [], 12.0)


func _add_handle(at: Vector3, shutter_names: Array, reach: float) -> void :
	var node: = Node3D.new()
	node.position = at
	add_child(node)
	var handle: = {"node": node, "lockers": shutter_names, "all": shutter_names.is_empty()}
	var prompt: = Prompt.make(node, _open_text(handle), Text.m("gear.truck.lockers" if bay else "gear.truck.locker"), 0.0, reach)
	prompt.triggered.connect( func(player: Player) -> void :
		if not is_open(handle):
			set_open(handle, true)
		else:


			show_menu(player, handle)
	)
	handle["prompt"] = prompt
	handle["index"] = handles.size()
	handles.append(handle)



func show_menu(player: Player, handle: Dictionary) -> void :
	if player.is_local:
		menu_wanted.emit(player, handle)
	elif Net.is_host():
		Net.send_to(player, "locker.menu", [String(vehicle.get_path()), int(handle["index"])])


func _open_text(handle: Dictionary) -> Dictionary:
	if handle["all"]:
		return Text.m("gear.truck.hatchesOpen" if hatches else "gear.truck.shuttersOpen")
	return Text.m("gear.truck.hatchOpen" if hatches else "gear.truck.shutterOpen")



func close_text(handle: Dictionary) -> Dictionary:
	if handle["all"]:
		return Text.m("gear.truck.hatchesClose" if hatches else "gear.truck.shuttersClose")
	return Text.m("gear.truck.hatchClose" if hatches else "hud.locker.close")


func is_open(handle: Dictionary) -> bool:
	if handle["all"]:
		return vehicle.lockers_open()
	for shutter_name: String in handle["lockers"]:
		if vehicle.shutters[shutter_name]["open"]:
			return true
	return false


func set_open(handle: Dictionary, open: bool) -> void :
	if handle["all"]:
		vehicle.set_lockers(open)
	else:
		for shutter_name: String in handle["lockers"]:
			vehicle.set_shutter(shutter_name, open)
	_clunk(handle)
	Net.broadcast("locker.clunk", [String(vehicle.get_path()), int(handle["index"])])


func _clunk(handle: Dictionary) -> void :
	Sounds.once(handle["node"], "shutter_roll", 0.6, 8.0, 80.0)



func lines_of(handle: Dictionary) -> Array[LockerLine]:
	if handle["all"]:
		return lines
	var found: Array[LockerLine] = []
	for line in lines:
		if line.locker in handle["lockers"]:
			found.append(line)
	return found





func add_line(locker: String, action: Variant, object: Variant = "", category: = "other", icon: = "") -> LockerLine:
	var line: = LockerLine.new()
	line.locker = locker
	line.action = action
	line.object = object
	line.category = category
	line.icon = icon
	line.order = lines.size() + 1
	lines.append(line)
	return line




func use(player: Player, handle: Dictionary, choice: Variant) -> void :
	if Net.is_client():

		if player.is_local:
			var said: Variant = "close"
			if choice is String:
				said = choice
			elif choice is LockerLine:
				said = lines.find(choice)
			Net.request("locker.use", [String(vehicle.get_path()), int(handle["index"]), said])
		return
	var node: Node3D = handle["node"]
	if not is_open(handle) or player.health <= 0.0 or player.root_position().distance_to(node.global_position) > REACH:
		return
	if choice == null:
		set_open(handle, false)
	elif choice is String and choice == "all":
		for line in lines_of(handle):
			if line.holder == player:
				line.chosen.emit(player)
	elif choice is LockerLine and choice in lines_of(handle):
		choice.chosen.emit(player)


func _process(_delta: float) -> void :
	if Net.is_client():
		return
	for handle: Dictionary in handles:
		var prompt: Prompt = handle["prompt"]
		prompt.action = Text.m("gear.truck.lockerUse") if is_open(handle) else _open_text(handle)

		prompt.enabled = absf(vehicle.forward_speed) < 3.0
