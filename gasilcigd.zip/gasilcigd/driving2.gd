extends ProofDebug



var _told: Array[String] = []





func _scenario_driving2() -> void :
	await _wait(1.0)
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : _told.append(Text.say(text, "en")))
	var settings: Dictionary = Config.Drive


	var drive: = VehicleDrive.new("Fire Truck")
	var own: Dictionary = settings["Profiles"]["Fire Truck"]
	_check(is_equal_approx(float(drive.profile["braking"]), float(own["braking"])) and is_equal_approx(float(drive.profile["grip"]), float(own["grip"])), "the pumper's braking and grip are Config.Drive's (%s, %s)" % [drive.profile["braking"], drive.profile["grip"]])
	var old: = VehicleDrive.new("Fire Truck")
	old.profile = old.profile.duplicate()
	for key: String in own:
		old.profile[key] = VehicleDrive.PROFILES["Fire Truck"][key]
	var stop_new: = _stopping(drive, 50.0)
	var stop_old: = _stopping(old, 50.0)
	print("driving2: from 50 km/h the pumper stops in %.1f m (the Roblox numbers: %.1f m)" % [stop_new, stop_old])
	_check(stop_new > stop_old * 1.15, "the pumper takes longer to stop from 50 km/h (%.1f m against %.1f m)" % [stop_new, stop_old])
	var launch_new: = _to_speed(VehicleDrive.new("Fire Truck"), 50.0)
	var launch_old: = _to_speed(old, 50.0)
	print("driving2: 0-50 km/h in %.1f s (the Roblox numbers: %.1f s)" % [launch_new, launch_old])
	_check(launch_new > launch_old, "the pumper is slower to 50 km/h (%.1f s against %.1f s)" % [launch_new, launch_old])

	var braked: = VehicleDrive.new("Fire Truck")
	var free: = VehicleDrive.new("Fire Truck")
	braked.speed = 40.0
	free.speed = 40.0
	for step in 30:
		braked.speed = 40.0
		free.speed = 40.0
		braked.step({"wheelbase": 14.5, "drive": -1.0, "steer": 1.0}, 1.0 / 60.0)
		free.step({"wheelbase": 14.5, "drive": 0.0, "steer": 1.0}, 1.0 / 60.0)
	print("driving2: half a second of full lock at 40 studs/s: grip used %.2f braking, %.2f coasting" % [braked.grip_use, free.grip_use])
	_check(braked.grip_use > free.grip_use * 1.1 and float(settings["BrakeGrip"]) > 0.0, "full lock while braking is nearer the tyres' limit than coasting")



	var crawl: = VehicleDrive.steer_curve(1.0, 0.0, 3.0)
	var fast: = VehicleDrive.steer_curve(1.0, 0.0, 50.0)
	var held: = VehicleDrive.steer_curve(1.0, float(settings["SteerRamp"]), 50.0)
	print("driving2: a steering key asks %.2f at a crawl, %.2f tapped at 50 km/h, %.2f held" % [crawl, fast, held])
	_check(is_equal_approx(crawl, 1.0), "at a crawl a steering key asks the whole lock")
	_check(absf(fast - float(settings["SteerTap"])) < 0.02, "at speed a tap asks only %.0f %% of the lock" % (float(settings["SteerTap"]) * 100.0))
	_check(is_equal_approx(held, 1.0), "held for the ramp's time it asks the whole lock")



	var car_launch: = _to_speed(VehicleDrive.new("Command Vehicle"), 60.0)
	var truck_launch: = _to_speed(VehicleDrive.new("Fire Truck"), 60.0)
	var car_stop: = _stopping(VehicleDrive.new("Command Vehicle"), 50.0)
	var car: = VehicleDrive.new("Command Vehicle")
	var car_tap: = VehicleDrive.steer_curve(1.0, 0.0, 50.0, car.profile)
	print("driving2: the PV-1 0-60 km/h in %.1f s (pumper %.1f s), stops from 50 km/h in %.1f m (pumper %.1f m), a tap at 50 km/h asks %.2f" % [car_launch, truck_launch, car_stop, stop_new, car_tap])
	_check(car_launch < truck_launch * 0.4, "the PV-1 is away far quicker than the pumper")
	_check(car_stop < stop_new * 0.7, "the PV-1 stops in a shorter way than the pumper")
	_check(float(car.profile["topSpeed"]) > float(drive.profile["topSpeed"]) * 1.25, "the PV-1 is well faster than the pumper")
	_check(car_tap > fast + 0.15, "a tap at speed steers the PV-1 more than a truck")


	var truck: = Vehicle.named("Fire Truck")
	var station: = Game.station
	var bay: Dictionary = station.record["bays"][int(Config.Station.PumperBay) - 1]
	if station.door_open(int(Config.Station.PumperBay)):
		station.set_door(int(Config.Station.PumperBay), false)
		await _wait(float(Config.Station.DoorTime) + 0.3)
	Alarm.forced = 1
	Alarm.begin()
	Game.incident = {"pos": Vector3(600, 0, 600), "kind": "fire"}
	_park(truck, Vector3(bay["x"], 0, station.front + 70.0), 0.0)
	await _wait(0.5)
	truck._board(player, "DoorCabLeft")
	await _wait(0.6)
	_check(truck.driver() == player, "at the pumper's wheel")
	var before: = truck._impact_at
	var most: = 0.0
	var shook: = 0.0
	var bounced: = false
	var hit_at: = -1.0
	Input.action_press("move_forward")
	var deadline: = Game.now() + 12.0
	while Game.now() < deadline:
		await get_tree().physics_frame
		most = maxf(most, absf(truck.forward_speed))
		if truck._impact_at > before and hit_at < 0.0:
			hit_at = Game.now()
			Input.action_release("move_forward")
			shook = player.camera.shake
			await _snap("hit")
		if hit_at > 0.0:
			bounced = bounced or truck.drive.speed < 0.0
			if Game.now() - hit_at > 1.5:
				break
	Input.action_release("move_forward")
	var kmh: = most * float(Config.Hud.MetresPerStud) * 3.6
	print("driving2: at the door at up to %.0f km/h: hit %s, jolt %.2f, bounced back %s, hits on the call %d, clean drive %s, told %s" % [kmh, hit_at > 0.0, shook, bounced, TruckService.current.impacts, Alarm.checks.get("cleanDrive"), _told])
	_check(hit_at > 0.0, "running into the shut door is felt as a hit")
	_check(shook > 0.0 or PlayerCamera.motion_scale() == 0.0, "the view is jolted (%.2f)" % shook)
	_check(bounced, "it bounces back off the door rather than stopping dead")
	_check(TruckService.current.impacts >= 1 and Alarm.checks.get("cleanDrive") == false, "on a call the hit loses the clean drive")
	_check(_told.any( func(line: String) -> bool: return line.begins_with("Hit something")), "the driver is told the clean drive is lost")
	truck.leave(player)
	Alarm.end()


	await _wait(1.0)
	Alarm.begin()
	var near: = truck.global_position + Vector3(0, 0, 40)
	Game.incident = {"pos": near, "kind": "fire"}
	truck._board(player, "DoorCabLeft")
	await _wait(1.5)
	print("driving2: the next call, %.0f studs away: clean drive %s, hits %d" % [truck.global_position.distance_to(near), Alarm.checks.get("cleanDrive"), TruckService.current.impacts])
	_check(Alarm.checks.get("cleanDrive") == true, "arriving with no hit on the way, the call has its clean drive")
	var report: = Alarm.debrief("fire", {"failed": false})
	var listed: = false
	for entry: Array in report["checks"]:
		listed = listed or (entry[0] == "cleanDrive" and entry[1] == true)
	_check(listed and Text.has("report.checks.cleanDrive.name"), "the end-of-call report lists the clean drive")
	truck.leave(player)
	Alarm.end()
	Game.incident = {}
	await _done()



func _stopping(drive: VehicleDrive, kmh: float) -> float:
	drive.speed = kmh / 3.6 / float(Config.Hud.MetresPerStud)
	drive.gear = int(drive.profile["gears"])
	var went: = 0.0
	for step in 2000:
		drive.step({"wheelbase": 14.5, "drive": -1.0}, 1.0 / 60.0)
		if drive.speed <= 0.3 or drive.reverse:
			break
		went += drive.speed / 60.0
	return went * float(Config.Hud.MetresPerStud)



func _to_speed(drive: VehicleDrive, kmh: float) -> float:
	drive.speed = 0.0
	drive.gear = 1
	var goal: = kmh / 3.6 / float(Config.Hud.MetresPerStud)
	for step in 3000:
		drive.step({"wheelbase": 14.5, "drive": 1.0}, 1.0 / 60.0)
		if drive.speed >= goal:
			return step / 60.0
	return 50.0





func _scenario_roles() -> void :
	await _wait(1.0)
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : _told.append(Text.say(text, "en")))
	var settings: Dictionary = Config.Roles
	var station: = Game.station
	var fire: = FireService.current


	var far_building: Building = null
	var far: = 0.0
	var tall: Building = null
	for building in fire.buildings:
		var gap: = VehicleRoles.nearest_hydrant(building.position)
		if gap > far:
			far = gap
			far_building = building
		if building is House and building.has_rooms() and building.height >= float(settings["TallHeight"]) and (tall == null or building.position.distance_to(station.door_position) < tall.position.distance_to(station.door_position)):
			tall = building
	print("roles: the building furthest from a hydrant is %s, %d m off; the nearest tall one with rooms %s (%.0f studs high)" % [far_building.name, VehicleRoles.metres(far), tall.name if tall else "-", tall.height if tall else 0.0])
	_check(far >= float(settings["HydrantFar"]), "somewhere in town is too far from a hydrant for a supply hose (%d m)" % VehicleRoles.metres(far))
	_told.clear()
	Alarm.forced = 1
	Alarm.begin()
	Game.incident = {"pos": far_building.position, "kind": "fire"}
	await _wait(0.8)
	print("roles: far from a hydrant: told %s, tanker bay open %s" % [_told, station.door_open(int(Config.Station.TankerBay))])
	_check(_told.any( func(line: String) -> bool: return line.contains("Take the tanker")), "the dispatcher asks for the tanker")
	_check(station.door_open(int(Config.Station.TankerBay)), "the tanker's bay door goes up")
	Alarm.end()
	Game.incident = {}
	await _wait(0.5)


	_check(tall != null, "a tall building with rooms in town")
	if tall == null:
		await _done()
		return
	_told.clear()
	Alarm.begin()
	fire.run_incident(tall)
	await _wait(1.5)
	print("roles: tall building: told %s, ladder bay open %s" % [_told, station.door_open(int(Config.Station.LadderBay))])
	_check(_told.any( func(line: String) -> bool: return line.contains("Take the ladder")), "the dispatcher asks for the ladder")
	_check(station.door_open(int(Config.Station.LadderBay)), "the ladder's bay door goes up")


	var ladder: = Vehicle.named("Ladder Truck")
	var toward: = (tall.position - station.door_position) * Vector3(1, 0, 1)
	var spot: = _open_spot(tall.position, - toward.normalized(), ladder)
	_park(ladder, tall.position - toward.normalized() * 110.0)
	await _wait(0.4)
	ladder._board(player, "DoorCabLeft")
	await _wait(1.0)
	_told.clear()
	_park(ladder, spot)
	await _wait(3.0)
	print("roles: the ladder at %.0f studs from the building's middle: told %s" % [Vector2(spot.x - tall.position.x, spot.z - tall.position.z).length(), _told])
	_check(_told.any( func(line: String) -> bool: return line.begins_with("Ladder:")), "the ladder's driver is told how the spot is")
	await _snap("ladder")
	ladder.leave(player)
	await _wait(0.5)


	var roles: = VehicleRoles.current
	ladder.global_transform = ladder.spec["spawn"]
	ladder.reset_physics_interpolation()
	await _wait(0.5)
	roles._for = -1.0
	Alarm.begin()
	_told.clear()
	await _wait(0.6)
	var command: = Vehicle.named("Command Vehicle")
	_park(command, _open_spot(tall.position, - toward.normalized(), command))
	await _wait(0.6)
	player.teleport(_ground(command.global_position + command.global_basis.x * 6.0) + Vector3(0, 0.3, 0))
	await _wait(float(settings["SizeUpTime"]) + 1.5)
	print("roles: the command car first: sized up %s, check %s, told %s" % [roles.sized_up, Alarm.checks.get("sizeUp"), _told])
	_check(roles.sized_up and Alarm.checks.get("sizeUp") == true, "the command car's crew sizes the call up")
	_check(_told.any( func(line: String) -> bool: return line.begins_with("📻 Size-up")), "the radio says what the size-up found")
	Alarm.end()
	await _done()
