class_name Training
extends RefCounted








const MOST: = 3



static func skills() -> Array:
	var ids: Array = []
	for skill: Dictionary in Config.Training.Skills:
		ids.append(skill["id"])
	return ids


static func level(player: Player, id: String) -> int:
	if player == null or player.brain != null:
		return 0
	return clampi(int(player.get_attr("Train_" + id, 0)), 0, MOST)



static func factor(player: Player, id: String, at: = -1) -> float:
	var values: Array = _skill(id).get("values", [1.0])
	var index: = level(player, id) if at < 0 else at
	return float(values[clampi(index, 0, values.size() - 1)])



static func price(player: Player, id: String) -> int:
	var next: = level(player, id)
	var prices: Array = Config.Training.Prices
	return int(prices[next]) if next < MOST and next < prices.size() else -1



static func rank_needed(player: Player, id: String) -> int:
	var ranks: Array = Config.Training.Ranks
	var next: = level(player, id)
	return int(ranks[next]) if next < ranks.size() else 0


static func rank_allows(player: Player, id: String) -> bool:
	return Alarm.rank_of(int(player.get_attr("Saved", 0))) >= rank_needed(player, id)



static func buy(player: Player, id: String) -> String:
	if not skills().has(id):
		return "top"
	var cost: = price(player, id)
	if cost < 0:
		return "top"
	if not rank_allows(player, id):
		return "rank"
	if not PlayerData.spend(player, cost):
		return "cash"
	player.set_attr("Train_" + id, level(player, id) + 1)
	PlayerData.save_now(player)
	return ""



static func listen() -> void :
	Net.handle("training.buy", func(player: Player, id: Variant) -> void :
		var why: = buy(player, str(id))
		var named: Variant = Text.m("training.skills.%s.name" % id)
		match why:
			"":
				Game.notify(Text.f("training.bought", [named, level(player, str(id))]), "good", player)
			"rank":
				var sheet: String = Config.Gear.Ranks[rank_needed(player, str(id))]["sheet"]
				Game.notify(Text.f("training.needRank", [Text.named("ranks", sheet)]), "warning", player)
			"cash":
				Game.notify(Text.m("training.noCash"), "warning", player)
	)




static func next_goal(player: Player) -> Dictionary:
	var best: = {}
	for id: String in skills():
		var cost: = price(player, id)
		if cost < 0 or not rank_allows(player, id):
			continue
		if best.is_empty() or cost < int(best["price"]):
			best = {"id": id, "level": level(player, id) + 1, "price": cost}
	return best



static func effect(id: String, at: int) -> Dictionary:
	var value: = factor(null, id, at)
	match id:
		"endurance":
			return Text.f("training.skills.endurance.effect", [_num(float(Config.Move.SprintSeconds) * value)])
		"recovery":
			return Text.f("training.skills.recovery.effect", [_num(float(Config.Move.RecoverSeconds) * value)])
		"heat":
			return Text.f("training.skills.heat.effect", [roundi(float(Config.Gear.HeatProtection) * value * 100.0)])

	var change: = roundi((value - 1.0) * 100.0)
	var signed: = "±0" if change == 0 else (("+%d" % change) if change > 0 else ("−%d" % - change))
	return Text.f("training.skills.%s.effect" % id, [signed])


static func _num(value: float) -> String:
	return String.num(value, 1).trim_suffix(".0")


static func _skill(id: String) -> Dictionary:
	for skill: Dictionary in Config.Training.Skills:
		if skill["id"] == id:
			return skill
	return {}
