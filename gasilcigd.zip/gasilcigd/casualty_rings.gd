class_name CasualtyRings
extends Node3D










const LOOK_EVERY: = 0.2
const HYDRANTS: = 6
const HYDRANT_REACH: = 60.0
const HYDRANT_RING: = 4.2
const HYDRANT_GLOW: = 0.35

static var current: CasualtyRings

var _since: = 0.0
var _rings: Array[Decal] = []
var _hydrant_rings: Array[Decal] = []
var _dropped: Dictionary = {}
static var _picture: ImageTexture
var shown: = 0


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var look: Dictionary = Config.Art.Rings
	for index in int(look["Most"]):
		var decal: = Decal.new()
		decal.texture_albedo = _ring()
		decal.texture_emission = _ring()
		decal.emission_energy = float(look["Glow"])
		decal.modulate = Rbx.rgb(look["Color"])
		decal.size = Vector3(float(look["Size"]), 3.0, float(look["Size"]))
		decal.upper_fade = 0.2
		decal.lower_fade = 0.2
		decal.cull_mask = 1
		decal.visible = false
		add_child(decal)
		_rings.append(decal)
	for index in HYDRANTS:
		var decal: = Decal.new()
		decal.texture_albedo = _ring()
		decal.texture_emission = _ring()
		decal.modulate = Color(Ui.BLUE, 0.55)
		decal.size = Vector3(HYDRANT_RING, 1.2, HYDRANT_RING)
		decal.upper_fade = 0.6
		decal.lower_fade = 0.2
		decal.cull_mask = 1
		decal.visible = false
		add_child(decal)
		_hydrant_rings.append(decal)


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var victims: = VictimService.current
	var player: = Game.local_player
	var used: = 0
	if victims != null and player != null:
		var look: Dictionary = Config.Art.Rings
		var me: = player.root_position()
		for victim: Victim in victims.victims:
			if used >= _rings.size():
				break
			if not victim.state in ["lying", "trapped", "walking"] or not is_instance_valid(victim.figure) or not victim.figure.is_inside_tree():
				continue
			var at: = victim.figure.global_position
			if victim.state != "lying":
				at.y -= Figure.ROOT_HEIGHT
			_drop(victim, at - Vector3(0, 0.5 if victim.state == "lying" else 0.0, 0))
			var far: = at.distance_to(me)
			var indoors: = victim.room != "" and victim.room != "wreck"
			if indoors:
				var same_room: = false
				for house: House in House.all:
					var room: Variant = house.room_at(me)
					if room != null and room["name"] == victim.room and house.position.distance_to(at) < 80.0:
						same_room = true
				if far > float(look["Near"]) and not same_room:
					continue
			elif far > float(look["Far"]):
				continue
			var ring: = _rings[used]
			ring.global_position = Vector3(at.x, at.y, at.z)
			ring.visible = true
			used += 1
	for index in range(used, _rings.size()):
		_rings[index].visible = false
	shown = used
	for victim: Victim in _dropped.keys():
		if victims == null or not victims.victims.has(victim):
			if is_instance_valid(_dropped[victim]):
				_dropped[victim].queue_free()
			_dropped.erase(victim)
	_show_hydrants()



func _drop(victim: Victim, at: Vector3) -> void :
	if _dropped.has(victim):
		return
	var roll: int = rand_from_seed(hash([victim.get_instance_id(), "dropped"]))[0] %6
	var box: = BoxMesh.new()
	var look: = StandardMaterial3D.new()
	look.roughness = 0.8
	if roll < 3:
		box.size = Vector3(0.45, 0.42, 1.15)
		look.albedo_color = [Color8(30, 30, 34), Color8(96, 62, 40), Color8(232, 232, 228)][roll]
	else:
		box.size = Vector3(1.2, 0.85, 0.45)
		look.albedo_color = Figure.BAGS[roll % Figure.BAGS.size()]
	var thing: = MeshInstance3D.new()
	thing.mesh = box
	thing.material_override = look
	add_child(thing)
	var side: = Vector3.RIGHT.rotated(Vector3.UP, float(roll) * 1.1)
	thing.global_transform = Transform3D(Basis(Vector3.UP, float(roll) * 0.9).rotated(side, 0.3 if roll < 3 else 0.0), at + side * 2.6 + Vector3(0, box.size.y * 0.5 - 0.1, 0))
	_dropped[victim] = thing



func _show_hydrants() -> void :
	var near: Array = []
	var hoses: = HoseService.current
	if hoses != null and Game.incident.has("pos") and Settings.quality >= Graphics.MEDIUM:
		var call: Vector3 = Game.incident["pos"]
		for hydrant: Dictionary in hoses.hydrants:
			var at: Vector3 = hydrant["position"]
			var far: = Vector2(at.x - call.x, at.z - call.z).length()
			if far <= HYDRANT_REACH:
				near.append([far, at])
		near.sort_custom( func(a: Array, b: Array) -> bool: return a[0] < b[0])
	var night: = 1.0 - (Sky3D.current.daylight() if Sky3D.current != null else 1.0)
	for index in _hydrant_rings.size():
		var ring: = _hydrant_rings[index]
		ring.visible = index < near.size()
		if ring.visible:

			ring.global_position = near[index][1] - Vector3(0, 1.0, 0)
			ring.emission_energy = HYDRANT_GLOW * night



static func _ring() -> ImageTexture:
	if _picture == null:
		var image: = Image.create(96, 96, false, Image.FORMAT_RGBA8)
		for y in 96:
			for x in 96:
				var r: = Vector2(x + 0.5 - 48.0, y + 0.5 - 48.0).length() / 48.0
				var alpha: = 0.0
				if r < 0.97 and r > 0.8:
					alpha = 1.0
				elif r <= 0.8 and r > 0.74:
					alpha = 0.0
				elif r <= 0.74:
					alpha = 0.18
				image.set_pixel(x, y, Color(1, 1, 1, alpha))
		image.generate_mipmaps()
		_picture = ImageTexture.create_from_image(image)
	return _picture
