extends Node3D


var store: PartStore
var world: World
var sky: Sky3D


func _ready() -> void :
	var started: = Time.get_ticks_msec()
	store = PartStore.new()
	store.load_world()
	Game.store = store
	Game.records = Rbx.decode(Rbx.load_json(Edition.path("world/records.json", "res://data/world/records.json")))

	for entry: Dictionary in Game.records["buildings"]:
		if entry.has("house"):
			House.plan(store, entry)
	TownPolish.apply(store)
	world = World.new()
	world.name = "World"
	add_child(world)
	world.build(store)
	sky = Sky3D.new()
	sky.name = "Sky"
	add_child(sky)
	print("world built in %d ms: %d parts" % [Time.get_ticks_msec() - started, store.count])

	Game.world = world
	for row in store.count:
		if store.name_at(row) == "SpawnLocation":
			Game.spawns.append(store.position(row))

	Game.station = Station.new()
	Game.station.name = "Station"
	add_child(Game.station)
	for spec: Dictionary in Vehicles.specs():
		add_child(Vehicle.make(spec))

	var fire: = FireService.new()
	fire.name = "Fires"
	add_child(fire)
	var house_holder: = Node3D.new()
	house_holder.name = "Houses"
	add_child(house_holder)

	for house in House.all:
		house.finish(house_holder)
		fire.buildings.append(house)
	for entry: Dictionary in Game.records["buildings"]:
		if not entry.has("house"):
			fire.buildings.append(Building.from_record(entry))
	var hoses: = HoseService.new()
	hoses.name = "Hoses"
	add_child(hoses)
	hoses.start()
	var calls: = CallService.new()
	calls.name = "Calls"
	add_child(calls)
	calls.start([fire])

	var hud: = Hud.new()
	hud.name = "Hud"
	add_child(hud)

	var player: = Player.new()
	player.name = "Player"
	add_child(player)
	player.global_position = Game.spawn_point()
	player.rig.rotation.y = PI
	player.camera.yaw = PI

	_start_features()
	Prompt.seal()

	var debug: = DebugTools.new()
	debug.name = "Debug"
	add_child(debug)




func _start_features() -> void :
	var names: = Array(ResourceLoader.list_directory("res://scripts/start"))
	names.sort()
	for file: String in names:
		if file.ends_with(".gd") and not Edition.skips(file):

			var script: GDScript = load("res://scripts/start/" + file)
			if script == null or not script.can_instantiate():
				push_error("could not start " + file)
				continue
			script.start(self)
