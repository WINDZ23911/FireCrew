class_name CallGear
extends Node











const ICONS: = {"Portable pump": "pump", "First aid kit": "heart", "Foam": "drop"}
const LOOKS: = {
	"Portable pump": {"size": Vector3(0.9, 1.1, 0.9), "color": Color8(214, 120, 30)}, 
	"First aid kit": {"size": Vector3(1.0, 0.7, 0.35), "color": Color8(200, 40, 40)}, 
	"Foam": {"size": Vector3(0.9, 1.1, 0.5), "color": Color8(218, 206, 176)}, 
}

static var current: CallGear

var kits: Dictionary = {}
var _drawn: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null



static func ensure(parent: Node) -> CallGear:
	if current == null:
		var gear: = CallGear.new()
		gear.name = "CallGear"
		parent.add_child(gear)
	return current


func _ready() -> void :
	var settings: Dictionary = Config.Incidents.get("Gear", {})
	for kit_name: String in settings:

		if ToolService.current != null and _tool_named(kit_name):
			continue

		if Cordon.RESCUE_KIT.has(kit_name):
			continue
		var kit: = {"pool": 0, "full": 0, "lines": [], "used": 0}
		for place: Dictionary in settings[kit_name]:
			var vehicle: = Vehicle.named(str(place["Vehicle"]))
			var lockers: = Lockers.of(vehicle) if vehicle != null else null
			if lockers == null:
				continue
			kit["full"] += int(place["Count"])
			var line: = lockers.add_line(str(place["Locker"]), Text.m("gear.tools.take"), "", "rescue", "")
			line.chosen.connect( func(player: Player) -> void : _on_line(player, kit_name))
			kit["lines"].append(line)
		kit["pool"] = kit["full"]
		kits[kit_name] = kit
	_update_counts()
	Net.share("callgear", _net_state, _net_apply, 4.0)
	Net.handle("callgear.back", func(player: Player) -> void :
		var had: = carried(player)
		if not had.is_empty():
			_on_line(player, had)
	)
	Text.language_changed.connect( func(_code: String) -> void : _update_counts())
	Game.incident_changed.connect( func() -> void :
		if Game.incident.is_empty() and not Net.is_client():
			restock())


func _tool_named(kit_name: String) -> bool:
	for item: Dictionary in ToolService.current.items:
		if item["name"] == kit_name:
			return true
	return false


func _update_counts() -> void :
	for kit_name: String in kits:
		var kit: Dictionary = kits[kit_name]
		for line: LockerLine in kit["lines"]:
			line.object = Text.f("gear.kit.count", [Text.named("tools", kit_name), int(kit["pool"]), int(kit["full"])])



static func carried(player: Player) -> String:
	if player == null:
		return ""
	var kit: Variant = player.get_attr("Kit")
	return kit if kit is String else ""




static func has(player: Player, kit_name: String) -> bool:
	if carried(player) == kit_name:
		return true
	if Cordon.current != null and player != null and Cordon.current.carries(player, kit_name):
		return true
	if ToolService.current != null and player != null:
		for item: Dictionary in ToolService.current.carried(player):
			if item["name"] == kit_name:
				return true
	return false




func use(player: Player, kit_name: String) -> bool:
	if carried(player) == kit_name:
		player.set_attr("Kit", null)
		if kits.has(kit_name):
			kits[kit_name]["used"] += 1
		return true
	return has(player, kit_name)



func restock() -> void :
	for kit_name: String in kits:
		var kit: Dictionary = kits[kit_name]
		kit["used"] = 0
		var out: = 0
		for player in Game.players:
			if is_instance_valid(player) and carried(player) == kit_name:
				out += 1
		kit["pool"] = int(kit["full"]) - out
	_update_counts()


func _on_line(player: Player, kit_name: String) -> void :
	if Net.is_client() or not kits.has(kit_name):
		return
	var kit: Dictionary = kits[kit_name]
	if carried(player) == kit_name:
		player.set_attr("Kit", null)
		kit["pool"] = mini(int(kit["pool"]) + 1, int(kit["full"]))
		_update_counts()
		Game.notify(Text.f("gear.tools.onTruck", [Text.named("tools", kit_name)]), "", player)
		return
	if int(kit["pool"]) <= 0:
		Game.notify(Text.f("gear.kit.none", [Text.named("tools", kit_name)]), "", player)
		return
	var had: = carried(player)
	if not had.is_empty() and kits.has(had):
		kits[had]["pool"] = mini(int(kits[had]["pool"]) + 1, int(kits[had]["full"]))
	kit["pool"] = int(kit["pool"]) - 1
	player.set_attr("Kit", kit_name)
	_update_counts()
	Game.notify(Text.m("gear.kit.tips." + kit_name.replace(" ", "")), "", player)
	var key: = slot_key(player)
	if not key.is_empty():
		Game.notify(Text.f("gear.kit.putBack", [Controls.key_name(key)]), "", player)



static func slot_key(player: Player) -> String:
	if ToolService.current == null:
		return ""
	var index: = ToolService.current.slots(player).size()
	return MenuKit.KEYS[index] if index < MenuKit.KEYS.size() else ""




func _process(_delta: float) -> void :
	var me: = Game.local_player
	if me != null and not carried(me).is_empty() and me.camera != null and me.camera.captured and not Game.ui_open and me.seat == null:
		var key: = slot_key(me)
		if not key.is_empty() and Input.is_action_just_pressed(key):
			Net.request("callgear.back")
	for known: Variant in _drawn.keys():
		if not is_instance_valid(known):
			_drawn.erase(known)
	for player in Game.players:
		if not is_instance_valid(player) or player.rig == null:
			continue
		var kit: = carried(player)
		if str(_drawn.get(player, "")) == kit:
			continue
		_drawn[player] = kit
		var old: = player.rig.hand_right.get_node_or_null("CallKit")
		if old != null:
			old.queue_free()
		if kit.is_empty() or not LOOKS.has(kit):
			continue
		var look: Dictionary = LOOKS[kit]
		var box: = Node3D.new()
		box.name = "CallKit"
		player.rig.hand_right.add_child(box)
		CallKit.piece(box, CallKit.BLOCK, look["size"], Transform3D(Basis.IDENTITY, Vector3(0, - look["size"].y / 2.0 - 0.2, 0)), look["color"])
		CallKit.piece(box, CallKit.BLOCK, Vector3(look["size"].x * 0.6, 0.12, 0.12), Transform3D(Basis.IDENTITY, Vector3(0, -0.1, 0)), Color8(40, 40, 44))





func _net_state() -> Variant:
	var pools: = {}
	for kit_name: String in kits:
		pools[kit_name] = kits[kit_name]["pool"]
	return pools


func _net_apply(state: Variant) -> void :
	if not Net.is_client() or not state is Dictionary:
		return
	for kit_name: String in state:
		if kits.has(kit_name):
			kits[kit_name]["pool"] = int(state[kit_name])
	_update_counts()
