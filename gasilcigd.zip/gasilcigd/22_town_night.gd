extends RefCounted




static func start(main: Node) -> void :
	for made: Node in ([Dogs.new(), Thunder.new()] + ([] if Edition.skips("train") else [Train.new()])):
		made.name = made.get_script().get_global_name()
		main.add_child(made)
