class_name HydrantCollars
extends RefCounted










const RING: = 0.06
const OVER: = 0.012

static var _sheeting: ShaderMaterial




static func paint() -> int:
	var store: = Game.store
	if store == null or Game.world == null:
		return 0
	var blue: = Rbx.rgb(Config.Art.HydrantCollar)
	var painted: = 0
	for entry: Dictionary in Game.records.get("hydrants", []):
		var row: int = store.row_of.get(int(entry.get("part", -1)), -1)
		if row < 0:
			continue
		for other in store.rows_under.get(store.parent(row), PackedInt32Array()):
			if store.name_at(other) == "Band":
				Game.world.set_color(store.id_at(other), blue)
				painted += 1
	_plates()
	return painted



static func sheeting() -> ShaderMaterial:
	if _sheeting == null:
		_sheeting = ShaderMaterial.new()
		_sheeting.shader = load("res://shaders/retroreflect.gdshader")
		_sheeting.set_shader_parameter("tint", Rbx.rgb(Config.Art.HydrantCollar))
		_sheeting.set_shader_parameter("glow", 0.0)
	return _sheeting





static func mark(parent: Node, hydrants: Array) -> void :
	var store: = Game.store
	var hoops: Array[Transform3D] = []
	var caps: Array[Transform3D] = []
	var lips: Array[Transform3D] = []
	for entry: Array in hydrants:
		var row: int = entry[0]
		var rings: int = entry[1]

		var at: = store.position(row)
		var size: = store.size(row)
		var from: = at.y
		var to: = at.y + size.x / 2.0
		for other in store.rows_under.get(store.parent(row), PackedInt32Array()):
			var other_at: = store.position(other)
			var other_size: = store.size(other)
			match store.name_at(other):
				"Band":
					hoops.append(_hoop(other_at, minf(other_size.y, other_size.z) / 2.0 + OVER, other_size.x + 0.004))
					from = other_at.y + other_size.x / 2.0
				"Collar":
					to = other_at.y - other_size.x / 2.0
				"Head":
					if rings == 0:
						lips.append(_hoop(other_at + Vector3(0, other_size.x / 2.0 - 0.1, 0), minf(other_size.y, other_size.z) / 2.0 + 0.035, 0.24))
				"Cap":
					if rings == 0:
						caps.append(Transform3D(Basis.from_scale(Vector3.ONE * (other_size.x / 2.0 * 1.06)), other_at))

		var step: = (to - from) / 4.0
		for ring in rings:
			hoops.append(_hoop(Vector3(at.x, from + step * (ring + 1), at.z), minf(size.y, size.z) / 2.0 + OVER * 2.0, RING))
	var hoop: = CylinderMesh.new()
	hoop.top_radius = 1.0
	hoop.bottom_radius = 1.0
	hoop.height = 1.0
	hoop.radial_segments = 16
	hoop.rings = 1
	_multi(parent, hoop, hoops, sheeting())
	var black: = StandardMaterial3D.new()
	black.albedo_color = Color(0.09, 0.09, 0.1)
	black.roughness = 0.6
	_multi(parent, hoop, lips, black)
	var cap: = SphereMesh.new()
	cap.radius = 1.0
	cap.height = 2.0
	cap.radial_segments = 16
	cap.rings = 8
	_multi(parent, cap, caps, black)


static func _hoop(middle: Vector3, radius: float, depth: float) -> Transform3D:
	return Transform3D(Basis.from_scale(Vector3(radius, depth, radius)), middle)


static func _multi(parent: Node, mesh: Mesh, places: Array[Transform3D], look: Material) -> void :
	if places.is_empty():
		return
	var multi: = MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	multi.mesh = mesh
	multi.instance_count = places.size()
	for index in places.size():
		multi.set_instance_transform(index, places[index])
	var shown: = MultiMeshInstance3D.new()
	shown.multimesh = multi
	shown.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	shown.material_override = look
	parent.add_child(shown)




static func _plates() -> void :
	var dressing: = Dressing.current
	var picture: = Assets.texture(str(Config.Town.Signs.get("hydrant", "")))
	if dressing == null or picture == null:
		return
	for child in dressing.get_children():
		var shown: = child as MultiMeshInstance3D
		if shown == null or shown.multimesh == null or not shown.multimesh.mesh is QuadMesh:
			continue
		var look: = (shown.multimesh.mesh as QuadMesh).material as StandardMaterial3D
		if look == null or look.albedo_texture != picture:
			continue
		var plate: = ShaderMaterial.new()
		plate.shader = load("res://shaders/retroreflect.gdshader")
		plate.set_shader_parameter("picture", picture)
		plate.set_shader_parameter("cut_out", true)
		plate.set_shader_parameter("roughness", look.roughness)
		shown.material_override = plate
