class_name Noray
extends Node

















signal command(name: String, data: String)

const PORT: = 8890
const REGISTRAR_PORT: = 8809

var address: = ""
var code: = ""
var local_port: = 0

var _tcp: = StreamPeerTCP.new()
var _secret: = ""
var _buffer: = ""


func is_open() -> bool:
	return _tcp.get_status() == StreamPeerTCP.STATUS_CONNECTED and not code.is_empty()




func open(server: String) -> Error:
	close()
	var port: = PORT
	var host: = server
	if server.contains(":"):
		host = server.get_slice(":", 0)
		port = server.get_slice(":", 1).to_int()
	address = IP.resolve_hostname(host, IP.TYPE_IPV4)
	if not address.is_valid_ip_address():
		return ERR_CANT_RESOLVE
	if _tcp.connect_to_host(address, port) != OK:
		return ERR_CANT_CONNECT
	_tcp.set_no_delay(true)
	var waited: = 0.0
	while _tcp.get_status() == StreamPeerTCP.STATUS_CONNECTING and waited < 5.0:
		await get_tree().process_frame
		waited += get_process_delta_time()
		_tcp.poll()
	if _tcp.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		close()
		return ERR_CANT_CONNECT
	_send("register-host")
	waited = 0.0
	while (code.is_empty() or _secret.is_empty()) and waited < 5.0 and is_inside_tree():
		await get_tree().process_frame
		waited += get_process_delta_time()
	if _secret.is_empty():
		close()
		return ERR_TIMEOUT
	return OK


func close() -> void :
	_tcp.disconnect_from_host()
	_tcp = StreamPeerTCP.new()
	code = ""
	_secret = ""
	_buffer = ""
	local_port = 0



func ask(host_code: String, relay: = false) -> void :
	_send(("connect-relay " if relay else "connect ") + host_code)



func registration() -> PackedByteArray:
	return _secret.to_utf8_buffer()




func register_port() -> Error:
	var udp: = PacketPeerUDP.new()
	if udp.bind(0) != OK:
		return ERR_CANT_CREATE
	udp.set_dest_address(address, REGISTRAR_PORT)
	var result: = ERR_TIMEOUT
	var left: = 6.0
	while left > 0.0 and result == ERR_TIMEOUT:
		udp.put_packet(_secret.to_utf8_buffer())
		await get_tree().create_timer(0.15).timeout
		left -= 0.15
		while udp.get_available_packet_count() > 0:
			result = OK if udp.get_packet().get_string_from_utf8() == "OK" else FAILED
	if result == OK:
		local_port = udp.get_local_port()
	udp.close()
	if result != OK:
		close()
	return result


func _send(line: String) -> void :
	if _tcp.get_status() == StreamPeerTCP.STATUS_CONNECTED:
		_tcp.put_data((line + "\n").to_utf8_buffer())


func _process(_delta: float) -> void :
	if _tcp.get_status() == StreamPeerTCP.STATUS_NONE:
		return
	_tcp.poll()
	var available: = _tcp.get_available_bytes()
	if available <= 0:
		return
	_buffer += _tcp.get_utf8_string(available)
	while _buffer.contains("\n"):
		var line: = _buffer.get_slice("\n", 0).strip_edges()
		_buffer = _buffer.substr(_buffer.find("\n") + 1)
		if line.is_empty():
			continue
		var what: = line.get_slice(" ", 0)
		var data: = line.substr(what.length() + 1) if line.contains(" ") else ""
		match what:
			"set-oid":
				code = data
			"set-pid":
				_secret = data
			_:
				command.emit(what, data)
