class_name LawnSurvey
extends Node




func _ready() -> void :
	await get_tree().create_timer(3.0).timeout
	var store: = Game.store
	var found: = {}
	for row in store.count:
		var material: = store.material(row)
		var color: = store.color(row)
		var green: = color.g > color.r * 1.15 and color.g > color.b * 1.15 and color.g > 0.3
		var size: = store.size(row)
		var flat: = size.y < 3.0 and size.x * size.z > 60.0
		if (material == "Grass" or material == "LeafyGrass" or (green and flat)) and flat:
			var key: = "%s/%s" % [store.name_at(row), material]
			var entry: Array = found.get(key, [0, 0.0])
			entry[0] += 1
			entry[1] += size.x * size.z
			found[key] = entry
	var keys: = found.keys()
	keys.sort_custom( func(a: String, b: String) -> bool: return found[a][1] > found[b][1])
	for key: String in keys.slice(0, 30):
		var part_name: String = key.split("/")[0]
		print("lawn: %-28s %5d parts %9.0f sq studs  grass grows: %s" % [key, found[key][0], found[key][1], part_name in Grass.GRASS_UNDER])
	get_tree().quit()
