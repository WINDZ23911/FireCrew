class_name Soundtrack
extends Node







const FOLDER: = "res://assets/audio/music"
const BUS: = "Music"
const LEVEL: = {"calm": 0.85, "call": 0.9}
const FIRST_WAIT: = Vector2(6.0, 12.0)
const CALL_GAP: = Vector2(3.0, 8.0)
const SIREN_DUCK: = 0.55

static var current: Soundtrack

var muted: = false
var _tracks: = {"calm": [], "call": []}
var _last: = {}
var _player: AudioStreamPlayer
var _kind: = ""
var _level: = 0.0
var _leaving: Array[AudioStreamPlayer] = []
var _next: = 0.0
var _voice: AudioStreamPlayer
var _ducked: = 1.0


func _ready() -> void :
	current = self
	process_mode = Node.PROCESS_MODE_ALWAYS
	if AudioServer.get_bus_index(BUS) < 0:
		var index: = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, BUS)
		AudioServer.set_bus_send(index, "Master")
	Settings.apply_music()
	for file in ResourceLoader.list_directory(FOLDER):
		var kind: = file.get_slice("_", 0)
		if _tracks.has(kind) and file.get_extension() in ["mp3", "ogg"]:
			_tracks[kind].append(FOLDER + "/" + file)
	if OS.get_cmdline_user_args().has("--no-music"):
		muted = true
	_next = Game.now() + randf_range(FIRST_WAIT.x, FIRST_WAIT.y)



static func under(voice: AudioStreamPlayer) -> void :
	if current and voice:
		current._voice = voice


func mood() -> String:
	return "calm" if Game.incident.is_empty() else "call"


func toggle() -> void :
	muted = not muted
	Game.notify(Text.m("ui.music.off" if muted else "ui.music.on"), "", Game.local_player)


func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("music") and not Game.ui_open:
		toggle()
		get_viewport().set_input_as_handled()


func _process(delta: float) -> void :
	var now: = Game.now()
	var wanted: = mood()
	if _player != null:
		var length: = _player.stream.get_length()
		var ending: = length > 0.0 and _player.get_playback_position() > length - float(Config.Music.Fade)
		if muted or _kind != wanted or ending or not _player.playing:
			_let_go()
			if wanted == "call" and _kind != "call":

				_next = now + float(Config.Voice.Delay) + 4.0
			elif wanted == "calm":
				var gap: Array = Config.Music.CalmGap
				_next = now + (randf_range(float(gap[0]), float(gap[1])) if ending else randf_range(5.0, 10.0))
			else:
				_next = now + randf_range(CALL_GAP.x, CALL_GAP.y)
	elif not muted and now >= _next and not _tracks[wanted].is_empty():
		_start(wanted)
	elif muted:
		_next = maxf(_next, now + 2.0)


	var fade: = float(Config.Music.Fade)
	if _player != null:
		_level = minf(1.0, _level + delta / fade)
		_player.volume_db = linear_to_db(maxf(LEVEL[_kind] * _level * _duck(delta), 0.0001))
	for leaving in _leaving.duplicate():
		var volume: = db_to_linear(leaving.volume_db) - delta / fade * LEVEL["call"]
		if volume <= 0.002 or not leaving.playing:
			_leaving.erase(leaving)
			leaving.queue_free()
		else:
			leaving.volume_db = linear_to_db(volume)


func _duck(delta: float) -> float:
	if _voice != null and ( not is_instance_valid(_voice) or not _voice.playing):
		_voice = null
	var under_it: = 1.0
	if _voice != null:
		under_it = float(Config.Music.Duck)
	elif _siren_on():
		under_it = SIREN_DUCK
	_ducked = move_toward(_ducked, under_it, delta * (2.5 if under_it < _ducked else 0.6))
	return _ducked



static func _siren_on() -> bool:
	var player: = Game.local_player
	if player == null:
		return false
	var vehicle: Variant = player.get_attr("Vehicle")
	return vehicle is Vehicle and is_instance_valid(vehicle) and vehicle.siren != 0


func _start(kind: String) -> void :
	var choices: Array = _tracks[kind].duplicate()
	if choices.size() > 1:
		choices.erase(_last.get(kind, ""))
	var path: String = choices.pick_random()
	_last[kind] = path
	var stream: = load(path) as AudioStream
	if stream == null:
		_next = Game.now() + 10.0
		return
	_player = AudioStreamPlayer.new()
	_player.stream = stream
	_player.bus = BUS
	_player.volume_db = -80.0
	add_child(_player)
	_player.play()
	_kind = kind
	_level = 0.0


func _let_go() -> void :
	if _player != null:
		_leaving.append(_player)
		_player = null
	_kind = ""
