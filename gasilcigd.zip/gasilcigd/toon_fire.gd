class_name ToonFire
extends RefCounted








const LIGHT_SHARE: = 11.0
const MAX_LIGHTS: = 6
const LOOK_EVERY: = 0.4
const SMOKE_SHARE: = 7.0

static var _flame: ShaderMaterial
static var _puff: ShaderMaterial
static var _steam: ShaderMaterial
static var _fireball: ShaderMaterial
static var _fog: ShaderMaterial
static var _room_smoke: ShaderMaterial
static var _plume: ShaderMaterial
static var _puff_mesh: SphereMesh
static var _card: QuadMesh
static var _next_look: = 0.0


static func flame_material() -> ShaderMaterial:
	if _flame == null:
		_flame = ShaderMaterial.new()
		_flame.shader = load("res://shaders/toon_flame.gdshader")
		_flame.set_shader_parameter("noise", Ground.noise())
		_flame.set_shader_parameter("wind", World.WIND * 0.08)
	return _flame



static func card() -> QuadMesh:
	if _card == null:
		_card = QuadMesh.new()
		_card.size = Vector2.ONE
		_card.center_offset = Vector3(0, 0.5, 0)
	return _card




static func puff_mesh() -> SphereMesh:
	if _puff_mesh == null:
		_puff_mesh = SphereMesh.new()
		_puff_mesh.radius = 0.5
		_puff_mesh.height = 1.0
		set_level(Settings.quality)
	return _puff_mesh



static func set_level(level: int) -> void :
	var sides: Array = Config.Art.Smoke.Sides[clampi(level, Graphics.LOW, Graphics.HIGH)]
	if _puff_mesh != null:
		_puff_mesh.radial_segments = int(sides[0])
		_puff_mesh.rings = int(sides[1])
	if FirePlume.current != null:
		FirePlume.current.set_level(level)




static func _style(material: ShaderMaterial) -> ShaderMaterial:
	var look: Dictionary = Config.Art.Smoke
	material.set_shader_parameter("wobble", float(look["Wobble"]))
	var tones: Array = look["Tones"]
	material.set_shader_parameter("tones", Vector3(tones[0], tones[1], tones[2]))
	material.set_shader_parameter("rim", float(look["Rim"]))
	var ages: Array = look["AgeTone"]
	material.set_shader_parameter("age_tone", Vector2(ages[0], ages[1]))
	return material


static func _style_new(path: String) -> ShaderMaterial:
	var material: = ShaderMaterial.new()
	material.shader = load(path)
	return _style(material)




static func fuel_color(fuel: String) -> Color:
	var fuels: Dictionary = Config.Art.Smoke.Fuel
	var rgb: Array = fuels.get(fuel, fuels["building"])
	return Color(rgb[0], rgb[1], rgb[2])



static func puff_material(steam: = false) -> ShaderMaterial:
	if steam:
		if _steam == null:
			_steam = _style_new("res://shaders/toon_puff.gdshader")
			_steam.set_shader_parameter("firelit", 0.0)
		return _steam
	if _puff == null:
		_puff = _style_new("res://shaders/toon_puff.gdshader")
	return _puff




static func plume_material() -> ShaderMaterial:
	if _plume == null:
		_plume = _style_new("res://shaders/toon_puff.gdshader")
		_plume.set_shader_parameter("night_glow", float(Config.Art.Smoke.PlumeGlow))
	return _plume



static func fireball_material() -> ShaderMaterial:
	if _fireball == null:
		_fireball = _style_new("res://shaders/toon_fireball.gdshader")
		_fireball.set_shader_parameter("firelit", 0.0)
		_fireball.set_shader_parameter("glow", 1.5)
	return _fireball



static func fog_material() -> ShaderMaterial:
	if _fog == null:
		_fog = _style_new("res://shaders/toon_puff.gdshader")
		_fog.set_shader_parameter("firelit", 0.0)
		_fog.set_shader_parameter("thin", 0.45)
	return _fog



static func room_smoke_material() -> ShaderMaterial:
	if _room_smoke == null:
		_room_smoke = _style_new("res://shaders/toon_puff.gdshader")
		_room_smoke.set_shader_parameter("firelit", 0.0)
		_room_smoke.set_shader_parameter("thin", 0.55)
	return _room_smoke



static func puffs(parent: Node3D, props: Dictionary, steam: = false) -> RbxEmitter:
	var made: = props.duplicate()
	made["Mesh"] = puff_mesh()
	if not made.has("Material"):
		made["Material"] = puff_material(steam)
	return RbxEmitter.make(parent, made)



static func look(now: float) -> void :
	if now < _next_look:
		return
	_next_look = now + LOOK_EVERY
	var daylight: float = Sky3D.current.daylight() if Sky3D.current else 1.0
	puff_material().set_shader_parameter("daylight", daylight)
	puff_material(true).set_shader_parameter("daylight", lerpf(0.55, 1.0, daylight))
	fog_material().set_shader_parameter("daylight", lerpf(0.55, 1.0, daylight))
	room_smoke_material().set_shader_parameter("daylight", daylight)
	plume_material().set_shader_parameter("daylight", daylight)
	var flames: Array[Flame] = []
	for flame in Flame.all:
		if is_instance_valid(flame) and flame.is_inside_tree():
			flames.append(flame)
	flames.sort_custom( func(a: Flame, b: Flame) -> bool: return a.intensity > b.intensity)
	var lit: Array[Flame] = []
	var shares: Dictionary = {}
	for flame in flames:
		var near: Flame = null
		for other in lit:
			if other.global_position.distance_to(flame.global_position) < LIGHT_SHARE:
				near = other
				break
		if near != null:
			shares[near] = int(shares.get(near, 1)) + 1
		elif lit.size() < MAX_LIGHTS:
			lit.append(flame)
			shares[flame] = 1
	var smoking: Array[Flame] = []
	for flame in flames:
		flame.share_light(int(shares.get(flame, 0)))
		var leads: = true
		for other in smoking:
			if other.global_position.distance_to(flame.global_position) < SMOKE_SHARE:
				leads = false
				break
		if leads:
			smoking.append(flame)
		flame.share_smoke(leads)
