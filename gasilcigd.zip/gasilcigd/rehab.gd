class_name Rehab
extends Node






static var current: Rehab

var _clock: = 0.0
var _last: Dictionary = {}
var _hurt_at: Dictionary = {}
var _resting: Dictionary = {}
var _told_at: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _physics_process(delta: float) -> void :
	_clock -= delta
	if _clock > 0.0:
		return
	var settings: Dictionary = Config.Rehab
	var tick: float = settings["Tick"]
	_clock = tick
	if Net.is_client():
		return
	var now: = Game.now()
	for player: Player in Game.players:
		if not is_instance_valid(player) or player.brain != null:
			continue
		var before: float = _last.get(player, player.health)
		_last[player] = player.health
		if player.health < before:
			_hurt_at[player] = now
		var where: = place(player)
		var resting: = false
		if player.health > 0.0 and player.health < player.max_health and where != "":
			resting = true
			if where == "station":
				player.heal(player.max_health)
				_tell(player, "world.rehab.station", now)
			else:
				player.heal(float(settings["Rate"]) * tick)
				if not _resting.get(player, false):
					_tell(player, "world.rehab.resting", now)
		_resting[player] = resting
		_last[player] = player.health



func place(player: Player) -> String:
	var settings: Dictionary = Config.Rehab
	var at: = player.root_position()
	if Game.station != null and Game.station.inside(at):
		return "station"
	if Game.now() - float(_hurt_at.get(player, -1000.0)) < float(settings["QuietAfterHurt"]):
		return ""
	if player.get_attr("Mask", false) == true or float(player.get_attr("Smoke", 0.0)) > 0.0:
		return ""
	var ambulance: = AmbulanceService.current.car() if AmbulanceService.current != null else null
	if ambulance != null and AmbulanceService.current.arrived() and ambulance.global_position.distance_to(at) < float(settings["AmbulanceReach"]):
		return "ambulance"
	for vehicle: Vehicle in Vehicle.all:
		if is_instance_valid(vehicle) and vehicle.global_position.distance_to(at) < float(settings["TruckReach"]):
			return "truck"
	return ""


func _tell(player: Player, key: String, now: float) -> void :
	if now - float(_told_at.get(player, -1000.0)) < float(Config.Rehab.TellEvery):
		return
	_told_at[player] = now
	Game.notify(Text.m(key), "good", player)
