class_name StanceService
extends RefCounted




const WALK: = 20.0
const WATCHED: Array[String] = ["Scba", "Carrying", "Dragging"]



static func watch(player: Player) -> void :
	player.attribute_changed.connect( func(key: String, _value: Variant) -> void :
		if key in WATCHED:
			refresh_speed(player)
	)
	refresh_speed(player)



static func refresh_speed(player: Player) -> void :
	if Net.is_client():
		return
	var speed: float = float(Config.Air.WalkSpeed) if player.get_attr("Scba", false) else WALK
	if player.get_attr("Carrying"):
		speed = minf(speed, float(Config.Victims.CarrySpeed))

	var dragging: Variant = player.get_attr("Dragging")
	if dragging is float or dragging is int:
		speed = minf(speed, float(dragging))
	player.walk_speed = speed
