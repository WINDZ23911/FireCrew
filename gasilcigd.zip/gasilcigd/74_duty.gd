extends RefCounted




static func start(main: Node) -> void :
	if CallService.current == null:
		return
	var duty: = Duty.new()
	duty.name = "Duty"
	main.add_child(duty)
