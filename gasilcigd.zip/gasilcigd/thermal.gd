class_name Thermal
extends Control









const TOOL_NAME: = "Thermal camera"
const HOT: = Color(1.0, 250 / 255.0, 225 / 255.0)
const WARM: = Color(1.0, 170 / 255.0, 60 / 255.0)
const BODY: = Color(165 / 255.0, 232 / 255.0, 1.0)
const BODY_SIZE: = 3.0

const FILTER: = "\nshader_type canvas_item;\nuniform sampler2D screen : hint_screen_texture, filter_linear;\nvoid fragment() {\n\t// No colour, more contrast, and the cold blue of the camera's screen.\n\tvec3 seen = texture(screen, SCREEN_UV).rgb;\n\tfloat grey = dot(seen, vec3(0.299, 0.587, 0.114));\n\tgrey = clamp((grey - 0.5) * 1.25 + 0.5, 0.0, 1.0);\n\tCOLOR = vec4(vec3(grey) * vec3(0.745, 0.804, 0.922), 1.0);\n}\n"











var on: = false
var _filter: ColorRect
var _caption: Label
var _seen: Array = []
var _next_look: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_filter = ColorRect.new()
	_filter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_filter.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var material: = ShaderMaterial.new()
	var shader: = Shader.new()
	shader.code = FILTER
	material.shader = shader
	_filter.material = material
	_filter.show_behind_parent = true
	add_child(_filter)
	_caption = Ui.label("", 16, HOT)
	_caption.add_theme_constant_override("outline_size", 4)
	_caption.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
	_caption.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_caption.position.y = 190
	_caption.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_caption)
	visible = false

	( func() -> void : get_parent().move_child(self, 0)).call_deferred()


func _process(_delta: float) -> void :
	var player: = Game.local_player
	on = player != null and player.get_attr("Tool") == TOOL_NAME
	visible = on
	House.set_thermal_view(on)
	if on:
		_caption.text = Text.say(Text.m("hud.thermal.caption"))
		var now: = Time.get_ticks_msec() / 1000.0
		if now >= _next_look:
			_next_look = now + float(Config.Tools.Thermal.Every)
			_look()
		queue_redraw()



static func hidden_from(eye: Vector3, at: Vector3, slack: = -1.0) -> bool:
	var leeway: float = float(Config.Fire.Sight.Slack) if slack < 0.0 else slack
	for house in House.all:
		if house.position.distance_to(at) < 90.0 and house.blocks(eye, at, leeway):
			return true
	return false




func _look() -> void :
	_seen.clear()
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var eye: = camera.global_position
	var reach: = float(Config.Tools.ThermalRange)
	var wanted: Array = []

	for flame in Flame.all:
		if flame.intensity > 0.01:
			wanted.append([flame.global_position, 1.5 + 5.0 * flame.intensity, Color(WARM.lerp(HOT, flame.intensity), 0.65 + 0.2 * flame.intensity), false])
	for ember in Ember.all:
		if ember.intensity > 0.01:
			wanted.append([ember.global_position, 1.5 + 5.0 * ember.intensity, Color(WARM.lerp(HOT, ember.intensity), 0.65 + 0.2 * ember.intensity), false])

	var fire: = FireService.current
	if fire != null:
		for key: int in fire._warm_shown:
			var warm: Warming = fire._warm_shown[key]
			if is_instance_valid(warm):
				var close: = clampf((warm.heat - FireService.WARN_HEAT) / (1.0 - FireService.WARN_HEAT), 0.0, 1.0)
				wanted.append([warm.global_position, float(Config.Tools.Thermal.WarmSize) * (0.7 + 0.6 * close), Color(WARM.darkened(0.35 - 0.3 * close), 0.45 + 0.3 * close), false])
	for body in get_tree().get_nodes_in_group("Victim"):
		if body is Node3D:
			wanted.append([(body as Node3D).global_position, BODY_SIZE, Color(BODY, 0.7), false])

	for house in House.all:
		if house.position.distance_to(eye) > reach + 40.0:
			continue
		for opening: Dictionary in house.openings:
			var door: Variant = opening.get("door")
			if not door is Dictionary or door["open"] or door["burnt"]:
				continue
			var heat: = 0.0
			for side: Variant in [opening["a"], opening["b"]]:
				if house.rooms.has(side):
					heat = maxf(heat, float(house.rooms[side].get("heat", 0.0)))
			if heat >= float(Config.Tools.Thermal.DoorHeat):
				var glow: = clampf(heat / 4.0, 0.25, 1.0)
				wanted.append([House.door_middle(door), float(door["width"]), Color(WARM.lerp(HOT, glow * 0.5), 0.35 + 0.35 * glow), true])
	var fade: = float(Config.Tools.Thermal.get("WallFade", 1.0))
	for each: Array in wanted:
		var at: Vector3 = each[0]
		if at.distance_to(eye) > reach:
			continue
		if fade < 1.0 and hidden_from(eye, at):
			var color: Color = each[2]
			each = [at, each[1], Color(color, color.a * fade), each[3]]
		_seen.append(each)




func _spot(camera: Camera3D, at: Vector3, size: float, color: Color, door: = false) -> void :
	var offset: = at - camera.global_position
	var depth: = offset.dot( - camera.global_basis.z)
	if depth < 0.5:
		return
	var view: = get_viewport_rect().size
	var radius: = size / 2.0 * view.y / (2.0 * tan(deg_to_rad(camera.fov) / 2.0) * depth)
	var middle: = camera.unproject_position(at)
	if door:
		draw_rect(Rect2(middle - Vector2(radius, radius * 1.7), Vector2(radius * 2.0, radius * 3.4)), color)
	else:
		draw_circle(middle, maxf(radius, 2.0), color)


func _draw() -> void :
	var camera: = get_viewport().get_camera_3d()
	if not on or camera == null:
		return
	for each: Array in _seen:
		_spot(camera, each[0], each[1], each[2], each[3])
