class_name Roads
extends RefCounted






static func on_road(road: Dictionary, x: float, z: float) -> Dictionary:
	var best: = {}
	var run: = 0.0
	var points: Array = road["points"]
	for index in points.size() - 1:
		var ax: float = points[index][0]
		var az: float = points[index][1]
		var dx: float = points[index + 1][0] - ax
		var dz: float = points[index + 1][1] - az
		var length: = sqrt(dx * dx + dz * dz)
		if length > 0.01:
			var t: = clampf(((x - ax) * dx + (z - az) * dz) / (length * length), 0.0, 1.0)
			var px: = ax + dx * t
			var pz: = az + dz * t
			var distance: = sqrt((x - px) ** 2 + (z - pz) ** 2)
			if best.is_empty() or distance < best["distance"]:
				best = {"distance": distance, "x": px, "z": pz, "along": run + length * t}
			run += length
	if not best.is_empty():
		best["length"] = run
	return best




static func at(road: Dictionary, along: float) -> Array:
	var points: Array = road["points"]
	for index in points.size() - 1:
		var ax: float = points[index][0]
		var az: float = points[index][1]
		var dx: float = points[index + 1][0] - ax
		var dz: float = points[index + 1][1] - az
		var length: = sqrt(dx * dx + dz * dz)
		if length > 0.01:
			if along <= length or index == points.size() - 2:
				var t: = clampf(along / length, 0.0, 1.0)
				return [ax + dx * t, az + dz * t, dx / length, dz / length]
			along -= length
	return [points[0][0], points[0][1], 0.0, 1.0]



static func length(road: Dictionary) -> float:
	var total: = 0.0
	var points: Array = road["points"]
	for index in points.size() - 1:
		total += Vector2(points[index + 1][0] - points[index][0], points[index + 1][1] - points[index][1]).length()
	return total



static func nearest(layout: Dictionary, x: float, z: float) -> Array:
	var nearest_found: = {}
	var street: = {}
	for road: Dictionary in layout["roads"]:
		if float(road["rank"]) >= 1.0:
			var found: = on_road(road, x, z)
			if not found.is_empty() and (nearest_found.is_empty() or found["distance"] < nearest_found["distance"]):
				nearest_found = found
				street = road
	return [nearest_found, street]



static func name_of(road: Dictionary) -> Variant:
	var road_name: Variant = road.get("name")
	return road_name if road_name is String and not road_name.is_empty() else Text.m("calls.town")
