class_name Ambulance
extends Node3D















static var KIT: = "res://assets/models/%s.glb" % str(Edition.data().get("vehicles", {}).get("Ambulance", {}).get("kit", "ambulance2_kit"))
static var DATA: = "res://data/godot/%s.json" % str(Edition.data().get("vehicles", {}).get("Ambulance", {}).get("data", "AmbulanceData"))
const OLD_KIT: = "res://assets/models/ambulance_kit.glb"
const OLD_DATA: = "res://data/modules/AmbulanceData.json"

const GLASS: = Color(40 / 255.0, 52 / 255.0, 62 / 255.0, 0.4)
const BLUE_OFF: = Color8(24, 44, 110)
const BLUE_ON: = Color8(90, 150, 255)
const DOOR_ANGLE: = deg_to_rad(72)
const BACK_DOOR_ANGLE: = deg_to_rad(165)
const DOOR_SWING: = 0.5

static var _data: Dictionary
static var _kit: PackedScene


var siren: = 0
var linear_velocity: = Vector3.ZERO
var forward_speed: = 0.0
var cancelled: = false

var chassis: Node3D
var doors: Dictionary = {}
var door_angles: Dictionary = {}
var wheels: Array = []
var _blue: Array = []
var _body: StaticBody3D
var _siren_player: AudioStreamPlayer3D
var _engine: AudioStreamPlayer3D
var _road: AudioStreamPlayer3D
var _last: Vector3
var _placed: = false



static func data() -> Dictionary:
	if _data.is_empty():
		var own: = ResourceLoader.exists(KIT) and FileAccess.file_exists(DATA)
		_data = Rbx.load_json(DATA if own else OLD_DATA)
	return _data



static func half_width() -> float:
	return data()["halfWidth"]


static func front() -> float:
	return data()["front"]


static func rear() -> float:
	return float(data()["rear"]) + 0.6


static func top() -> float:
	return float(data()["top"]) - float(data()["ground"])


static func _v(list: Array) -> Vector3:
	return Vector3(list[0], list[1], list[2])


func _init() -> void :
	name = "Ambulance"

	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	var layout: = data()
	chassis = Node3D.new()
	chassis.name = "Chassis"
	chassis.position = Vector3(0, - float(layout["ground"]), 0)
	add_child(chassis)
	_build_kit(layout)
	_build_lights(layout)
	_build_body(layout)
	VehicleLook.contact_shadow(self, Vector3(0, 0, (float(layout["front"]) + float(layout["rear"])) / 2.0), float(layout["halfWidth"]) * 2.0, float(layout["rear"]) - float(layout["front"]))


func _ready() -> void :
	_build_sounds()
	_last = global_position


func _build_kit(layout: Dictionary) -> void :
	if _kit == null:
		_kit = load(KIT if ResourceLoader.exists(KIT) and FileAccess.file_exists(DATA) else OLD_KIT)
	var source: = _kit.instantiate()
	var glass: = VehicleLook.glass(GLASS)
	var objects: Dictionary = {}
	for child in source.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() != 2 or bits[0] == "Marker":
			continue
		mesh.owner = null
		source.remove_child(mesh)
		if bits[1] == "glass":
			mesh.material_override = glass
			mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		else:
			VehicleLook.coat(mesh, "Ambulance")
		if not objects.has(bits[0]):
			objects[bits[0]] = []
		objects[bits[0]].append(mesh)
	source.free()

	var wheel_objects: Dictionary = {}
	for info: Dictionary in layout["wheels"]:
		wheel_objects[info["object"]] = true

		var drawn_at: = Vector3(info["x"], layout["axleY"], 0)
		for side: float in [-1.0, 1.0]:
			var hub: = Node3D.new()
			hub.name = "Wheel"
			chassis.add_child(hub)
			hub.position = Vector3( - side * float(info["x"]), layout["axleY"], info["z"])
			if side > 0:
				hub.rotation.y = PI
			var spinner: = Node3D.new()
			hub.add_child(spinner)
			for mesh: MeshInstance3D in objects.get(info["object"], []):
				var copy: = mesh.duplicate() as MeshInstance3D
				spinner.add_child(copy)
				copy.position = mesh.position - drawn_at
			wheels.append({"spinner": spinner, "flipped": side > 0, "angle": 0.0})

	for object: String in objects:
		if wheel_objects.has(object):
			for mesh: MeshInstance3D in objects[object]:
				mesh.free()
			continue
		var parent: = chassis
		if layout["doors"].has(object):
			var info: Dictionary = layout["doors"][object]
			var hinge: = Node3D.new()
			hinge.name = object
			hinge.position = _v(info["hinge"])
			chassis.add_child(hinge)
			doors[object] = {"info": info, "node": hinge}
			parent = hinge
		for mesh: MeshInstance3D in objects[object]:
			var at: = mesh.transform
			parent.add_child(mesh)
			mesh.transform = parent.transform.affine_inverse() * at if parent != chassis else at


func _build_lights(layout: Dictionary) -> void :
	for info: Dictionary in layout["blueLamps"]:
		var size: = _v(info["size"])
		var at: = _v(info["pos"])
		var beacon: = VehicleLook.beacon(chassis, at, size)

		var tint: Variant = info.get("color")
		var shade: = Color(tint[0], tint[1], tint[2]) if tint is Array and tint.size() >= 3 else Color()
		if tint is Array:
			_tint_beacon(beacon, shade)

		var light: OmniLight3D = null
		if info.get("light", true):
			light = OmniLight3D.new()
			light.light_color = shade if tint is Array else Color(70 / 255.0, 120 / 255.0, 1.0)
			light.omni_range = 46.0 if size.z > 0.15 else 26.0
			light.light_energy = 6.0 if size.z > 0.15 else 3.0
			light.visible = false
			chassis.add_child(light)
			light.position = at + Vector3(0, 0.6, 0)
		var glare: = VehicleLook.flare(chassis, at, shade if tint is Array else Vehicle.BLUE_GLARE, float(info.get("glare", 4.0 if size.z > 0.15 else 2.4)))
		_blue.append({"beacon": beacon, "light": light, "phase": int(info["phase"]), "on": false, "flare": glare})
	var head_size: Vector3 = _v(layout["headlightSize"]) if layout.has("headlightSize") else Vector3(0.9, 0.7, 0.08)
	var tail_size: Vector3 = _v(layout["tailLightSize"]) if layout.has("tailLightSize") else Vector3(1.2, 0.32, 0.06)
	for at: Array in layout["headlights"]:
		AmbulanceBuilder.part(chassis, "Headlight", head_size, Transform3D(Basis.IDENTITY, _v(at)), Color8(250, 248, 235), {"neon": true})
	for at: Array in layout["tailLights"]:
		AmbulanceBuilder.part(chassis, "TailLight", tail_size, Transform3D(Basis.IDENTITY, _v(at)), Color8(220, 30, 30), {"neon": true})




static func _tint_beacon(beacon: Dictionary, shade: Color) -> void :
	var lens: = beacon["lens"] as StandardMaterial3D
	var core: = beacon["core"] as StandardMaterial3D
	var white: = shade.s < 0.3
	lens.albedo_color = Color(0.92, 0.92, 0.94, lens.albedo_color.a) if white else Color(shade.r * 0.85, shade.g * 0.6, shade.b * 0.6, lens.albedo_color.a)
	lens.emission = shade
	core.albedo_color = Color(0.3, 0.3, 0.32) if white else shade.darkened(0.7)
	core.emission = shade.lightened(0.2)



func _build_body(layout: Dictionary) -> void :
	_body = StaticBody3D.new()
	_body.name = "Collider"
	_body.collision_layer = 0
	_body.collision_mask = 0
	chassis.add_child(_body)
	for corners: Array in layout["colliders"]:
		var a: = _v(corners[0])
		var b: = _v(corners[1])
		var box: = BoxShape3D.new()
		box.size = (b - a).abs()
		var shape: = CollisionShape3D.new()
		shape.shape = box
		shape.position = (a + b) / 2.0
		_body.add_child(shape)


func _build_sounds() -> void :
	var bar: = Node3D.new()
	chassis.add_child(bar)
	bar.position = Vector3(0, float(data()["top"]), -2.0)
	var pattern: Dictionary = Config.Siren.Patterns[0]
	_siren_player = Sounds.emitter(bar, Sounds.loop(pattern["soundId"]), float(Config.Siren.Volume), 30.0, 500.0)

	_engine = Sounds.emitter(chassis, Sounds.loop("four_low"), 0.0, 8.0, 160.0)
	_road = Sounds.emitter(chassis, Sounds.loop("road"), 0.0, 8.0, 160.0)






func set_siren(on: bool) -> void :
	siren = 1 if on else 0
	Emergency.watch(self, on)
	if _siren_player == null or _siren_player.stream == null:
		return
	if on and not _siren_player.playing:
		_siren_player.play()
	elif not on and _siren_player.playing:
		_siren_player.stop()



func set_solid(solid: bool) -> void :
	_body.collision_layer = World.LAYER_VEHICLE if solid else 0


func is_solid() -> bool:
	return _body.collision_layer != 0


func is_placed() -> bool:
	return _placed



func swing(door_name: String, angle: float) -> void :
	if not doors.has(door_name):
		return
	door_angles[door_name] = angle
	var door: Dictionary = doors[door_name]
	var node: Node3D = door["node"]
	if not is_inside_tree():
		node.rotation.y = float(door["info"]["side"]) * angle
		return
	if door.get("tween") is Tween and door["tween"].is_valid():
		door["tween"].kill()
	var tween: = create_tween()
	tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(node, "rotation:y", float(door["info"]["side"]) * angle, DOOR_SWING)
	door["tween"] = tween



func back_doors(open: bool) -> void :
	for door_name: String in ["DoorBackLeft", "DoorBackRight"]:
		swing(door_name, BACK_DOOR_ANGLE if open else 0.0)





func crew_door(side: int) -> Dictionary:
	var door_name: = "DoorCabLeft" if side < 0 else "DoorCabRight"
	var seat: Array = doors[door_name]["info"]["seat"]
	return {
		"inside": Vector3(side * 2.0, 0.5, seat[2]), 
		"outside": Vector3(seat[0], data()["ground"], seat[2]), 
		"open": func(on: bool) -> void : swing(door_name, DOOR_ANGLE if on else 0.0), 
	}



func place(base: Transform3D) -> void :
	global_transform = base
	if not _placed:
		_placed = true
		_last = base.origin


func _process(delta: float) -> void :
	if delta <= 0.0:
		return

	var here: = global_position
	linear_velocity = (here - _last) / delta if _placed else Vector3.ZERO
	_last = here
	forward_speed = linear_velocity.dot( - global_basis.z)
	if absf(forward_speed) > 0.2:

		var turn: = forward_speed / float(data()["wheelRadius"]) * delta
		for wheel: Dictionary in wheels:
			wheel["angle"] = fposmod(wheel["angle"] + (turn if wheel["flipped"] else - turn), TAU)
			wheel["spinner"].rotation.x = wheel["angle"]

	var now: = Game.now()
	for lamp: Dictionary in _blue:
		var on: = Vehicle.blue_lit(lamp["phase"], now)
		if on != lamp["on"]:
			lamp["on"] = on
			if lamp["light"] != null:
				lamp["light"].visible = on
			VehicleLook.beacon_lit(lamp["beacon"], on)
			VehicleLook.shine(lamp["flare"], (0.55 + 0.45 * VehicleLook.glare_now()) if on else 0.0)

	var pace: = clampf(absf(forward_speed) / 40.0, 0.0, 1.0)
	_note(_engine, 0.7 * (0.15 + 0.85 * pace) if _placed else 0.0, 0.7 + 0.6 * pace)
	_note(_road, 0.5 * pace, 0.8 + 0.4 * pace)


static func _note(player: AudioStreamPlayer3D, volume: float, pitch: float) -> void :
	if player == null or player.stream == null:
		return
	player.volume_db = linear_to_db(maxf(volume, 0.0001))
	player.pitch_scale = pitch
	if volume > 0.001 and not player.playing:
		player.play()
	elif volume <= 0.001 and player.playing:
		player.stop()


func _exit_tree() -> void :
	Emergency.watch(self, false)
