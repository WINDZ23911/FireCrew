class_name CallMarker
extends Node3D


static var all: Array[CallMarker] = []
static var _made: = 0
static var _mirrors: Dictionary = {}

var label: Label3D
var net_id: = 0
var mirror: = false
var own: = false
var _color: = Color.WHITE


static func make(at: Vector3, text: Variant, color: Color) -> CallMarker:
	var marker: = CallMarker.new()
	Game.world.add_child(marker)
	marker.global_position = at
	marker.label = Label3D.new()
	marker.label.text = " %s " % Text.say(text)
	marker.label.font = Ui.world_label_font()
	marker.label.font_size = 40
	marker.label.outline_size = 14
	marker.label.outline_modulate = color.darkened(0.2)
	marker.label.modulate = Color.WHITE
	marker.label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	marker.label.no_depth_test = true
	marker.label.fixed_size = true
	marker.label.pixel_size = 0.0011
	marker.label.render_priority = 6
	marker.add_child(marker.label)
	marker._pin(color)
	marker.set_meta("text", text)
	marker._color = color
	_made += 1
	marker.net_id = _made
	return marker





func _pin(color: Color) -> void :
	var door: = CallAddress.door_near(global_position)
	var top: = global_position - Vector3(0, 1.2, 0)
	var foot: = door + Vector3(0, 1.0, 0)

	if door == global_position or top.y - foot.y < 14.0 or Vector2(top.x - foot.x, top.z - foot.z).length() > 30.0:
		return
	var rod: = CylinderMesh.new()
	rod.top_radius = 0.12
	rod.bottom_radius = 0.12
	rod.height = top.distance_to(foot)
	rod.radial_segments = 6
	rod.rings = 1
	var look: = StandardMaterial3D.new()
	look.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	look.albedo_color = color
	var pin: = MeshInstance3D.new()
	pin.name = "Pin"
	pin.mesh = rod
	pin.material_override = look
	pin.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(pin)
	var along: = (foot - top).normalized()
	var side: = along.cross(Vector3.FORWARD if absf(along.z) < 0.9 else Vector3.RIGHT).normalized()
	pin.global_transform = Transform3D(Basis(side, - along, side.cross( - along)).orthonormalized(), (top + foot) / 2.0)



func recolor(text: Variant, color: Color) -> void :
	set_meta("text", text)
	_color = color
	label.text = " %s " % Text.say(text)
	label.outline_modulate = color.darkened(0.2)
	var pin: = get_node_or_null("Pin") as MeshInstance3D
	if pin != null:
		(pin.material_override as StandardMaterial3D).albedo_color = color











static func net_state() -> Variant:
	var list: Array = []
	for marker in all:
		if not marker.mirror and not marker.own and not marker.is_queued_for_deletion():
			var text: Variant = marker.get_meta("text", "")
			list.append([marker.net_id, marker.global_position, text if (text is String or text is Dictionary) else "", marker._color])
	return list


static func net_apply(list: Variant) -> void :
	if not Net.is_client():
		return
	var told: = {}
	for entry: Array in list:
		told[entry[0]] = true
		var marker: CallMarker = _mirrors.get(entry[0])
		if marker == null or not is_instance_valid(marker):
			marker = make(entry[1], entry[2], entry[3])
			marker.mirror = true
			_mirrors[entry[0]] = marker
		marker.global_position = entry[1]
		if hash(marker.get_meta("text", "")) != hash(entry[2]):
			CallKit.set_marker(marker, entry[2])
		if entry.size() > 3 and entry[3] is Color and marker._color != entry[3]:
			marker.recolor(marker.get_meta("text", ""), entry[3])
	for id: int in _mirrors.keys():
		if not told.has(id):
			if is_instance_valid(_mirrors[id]):
				_mirrors[id].queue_free()
			_mirrors.erase(id)



static func net_clear() -> void :
	for id: int in _mirrors:
		if is_instance_valid(_mirrors[id]):
			_mirrors[id].queue_free()
	_mirrors.clear()


func _enter_tree() -> void :
	all.append(self)


func _exit_tree() -> void :
	all.erase(self)
