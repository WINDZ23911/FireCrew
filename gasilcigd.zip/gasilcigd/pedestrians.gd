class_name Pedestrians
extends Node













signal person_added(person: Person)
signal person_removed(person: Person)

const TICK: = 0.2

const HEIGHTS: = {"pavement": 0.5, "corner": 0.5, "crossing": 0.2, "roadside": 0.2, "parkpath": 0.1, "path": 0.1}
const KEEP: = {"pavement": 1.0, "corner": 1.0, "crossing": 0.6, "roadside": 0.5, "parkpath": 0.35, "path": 0.2}

const WEIGHTS: = {"door": 4.0, "spot": 6.0, "bus_stop": 12.0, "bench": 2.0, "exit": 1.0}
const SEATS: Array[float] = [-1.5, 1.5]


const NET_LOTS: = 16
const NET_HZ: = 10.0
const NET_STATES: Array[String] = ["idle", "walk", "wait", "sit", "talk", "watch", "leave"]



const WINTER_BY_HOUR: Array[Vector2] = [
	Vector2(0, 0.06), Vector2(6.5, 0.06), Vector2(7.6, 0.5), Vector2(9.0, 0.4), Vector2(12.0, 0.55), 
	Vector2(15.0, 0.62), Vector2(16.6, 0.66), Vector2(18.0, 0.38), Vector2(20.0, 0.18), Vector2(22.0, 0.08), 
	Vector2(24, 0.06), 
]
const OUT_BY_HOUR: Array[Vector2] = [
	Vector2(0, 0.14), Vector2(4.5, 0.06), Vector2(6.3, 0.4), Vector2(7.4, 0.95), Vector2(9, 0.7), 
	Vector2(12, 0.85), Vector2(14.5, 0.7), Vector2(16.5, 0.9), Vector2(18, 1.15), Vector2(19.5, 1.35), 
	Vector2(21, 1.15), Vector2(22.5, 0.55), Vector2(24, 0.14), 
]

static var current: Pedestrians


class Person:
	extends RefCounted
	var id: = 0
	var seed: = 0
	var speed: = 6.0
	var keep: = 2.0
	var node: = 0
	var at: = 0
	var position: = Vector3.ZERO
	var state: = "idle"
	var duration: = 0.0
	var to: = Vector3.ZERO
	var t0: = 0.0
	var arrive: = 0.0
	var resume: = 0.0
	var route: Array[int] = []
	var index: = 0
	var goal: Dictionary = {}
	var errand: Dictionary = {}
	var crossing: Dictionary = {}
	var cleared: = false
	var on: = -1
	var hurried: = false
	var aside: Dictionary = {}
	var final: = false
	var waiting_bus: = false
	var linger_until: = 0.0
	var gone: = false

	var shown_from: = Vector3.ZERO
	var shown_to: = Vector3.ZERO
	var shown_t0: = 0.0
	var shown_speed: = 0.0
	var shown_state: = "idle"
	var shown_face: Variant = null
	var mood: = ""
	var say: Variant = null
	var say_at: = -1.0


var graph: NavGraph
var walk: Array
var people: Dictionary = {}
var count: = 0
var hazard: Dictionary = {}

var _rng: = RandomNumberGenerator.new()
var _next_id: = 0
var _arrivals: Array[float] = []
var _destinations: Array = []
var _sirens: Array = []
var _bus_seen: = -1
var _alighting: Array = []
var _small_talk: = 0
var _elapsed: = 0.0
var _running: = false
var _mirroring: = false


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _in_hazard(x: float, z: float) -> bool:
	if hazard.is_empty():
		return false
	var dx: float = x - hazard["x"]
	var dz: float = z - hazard["z"]
	return dx * dx + dz * dz < hazard["radius"] * hazard["radius"]



func _way_cost(link: Dictionary) -> Variant:
	var node: Dictionary = walk[link["to"]]
	if _in_hazard(node["x"], node["z"]):
		return null
	return link["length"]


func _between(span: Vector2) -> float:
	return _rng.randf_range(span.x, span.y)


static func _is_way_in(place: Dictionary) -> bool:
	return place["kind"] == "door" or place["kind"] == "exit"



func _pick_place(accept: = Callable()) -> Dictionary:
	var total: = 0.0
	var allowed: Array = []
	for place: Dictionary in _destinations:
		if not accept.is_valid() or accept.call(place):
			allowed.append(place)
			total += WEIGHTS[place["kind"]]
	var roll: = _rng.randf_range(0.0, total)
	for place: Dictionary in allowed:
		roll -= WEIGHTS[place["kind"]]
		if roll <= 0.0:
			return place
	return {}


func _target() -> int:
	var settings: Dictionary = Config.Life
	if Sky3D.current == null:
		if Game.night:
			return floori(settings["Pedestrians"] * settings["NightShare"] + 0.5)
		return int(settings["Pedestrians"])
	return floori(settings["Pedestrians"] * share_of_hour(Sky3D.current.hour) + 0.5)




static func share_of_hour(hour: float) -> float:
	var at: = fposmod(hour, 24.0)
	var curve: = WINTER_BY_HOUR if Style.winter() else OUT_BY_HOUR
	for i in range(1, curve.size()):
		var to: Vector2 = curve[i]
		if at <= to.x:
			var from: Vector2 = curve[i - 1]
			return lerpf(from.y, to.y, (at - from.x) / (to.x - from.x))
	return curve[0].y



func _most() -> int:
	return maxi(_target(), int(Config.Life.Pedestrians)) + int(Config.Life.CrowdMax)



func _position_of(person: Person, now: float) -> Vector3:
	if person.state != "walk" or person.duration <= 0.0:
		return person.position
	return person.position.lerp(person.to, clampf((now - person.t0) / person.duration, 0.0, 1.0))



func _set_leg(person: Person, to: Vector3, speed: float) -> void :
	var now: = Game.now()
	person.to = to
	person.t0 = now
	person.duration = person.position.distance_to(to) / speed if speed > 0.0 else 0.0
	person.arrive = now + person.duration
	person.shown_from = person.position
	person.shown_to = to
	person.shown_t0 = now
	person.shown_speed = speed


func _set_state(person: Person, state: String, face: Variant = null) -> void :
	person.state = state
	person.shown_state = state
	person.shown_face = face




func _may_cross(link: Dictionary, person: Person) -> bool:

	if Emergency.near(_sirens, person.position.x, person.position.z, Config.Life.PedSirenRange, Config.Life.SirenPassed):
		return false
	if link["crossing"] >= 0 and graph.crossings[link["crossing"]]["cars"] > 0:
		return false
	if link["phase"] == 0:
		return true
	return TrafficLights.current == null or TrafficLights.phase(link["phase"]) == "red"



func _start_leg(person: Person) -> void :
	var a: = person.route[person.index]
	var b: = person.route[person.index + 1]
	var link: = graph.find_link(a, b)
	var from: Dictionary = walk[a]
	var to: Dictionary = walk[b]
	var kind: String = link.get("kind", "path")
	var height: float = HEIGHTS.get(kind, 0.2)

	if kind == "crossing" and not person.cleared:
		person.crossing = link
		person.resume = Game.now() + _between(Config.Life.KerbWait)
		_set_leg(person, person.position, 0.0)
		_set_state(person, "wait", Vector3(to["x"], height, to["z"]))
		return
	person.cleared = false
	if not link.is_empty() and link["crossing"] >= 0 and person.on < 0:

		person.on = link["crossing"]
		graph.crossings[person.on]["walkers"] += 1

	var goal: = Vector3(to["x"], height, to["z"])
	var dx: float = to["x"] - from["x"]
	var dz: float = to["z"] - from["z"]
	var length: = sqrt(dx * dx + dz * dz)
	var last: = person.index + 1 == person.route.size() - 1
	if last:
		if not person.goal.is_empty() and not _is_way_in(person.goal):

			goal += Vector3(_rng.randf_range(-2.5, 2.5), 0, _rng.randf_range(-2.5, 2.5))
	elif length > 0.01:

		goal += Vector3( - dz / length, 0, dx / length) * person.keep * KEEP.get(kind, 0.0)
	_set_leg(person, goal, person.speed * (Config.Life.CrossingHurry if kind == "crossing" else 1.0))
	_set_state(person, "walk")



func _choose_route(person: Person) -> bool:

	var home: = count > _target()
	for attempt in 6:
		var goal: = _pick_place( func(place: Dictionary) -> bool:
			var room: bool = place["kind"] != "bench" or not (place["seats"][0] and place["seats"][1])
			return room and place["node"] != person.node and ( not home or _is_way_in(place)) and not _in_hazard(place["x"], place["z"])
		)
		if goal.is_empty():
			continue
		var route: = graph.walk_route(person.node, goal["node"], _way_cost if not hazard.is_empty() else Callable())
		if route.size() >= 2:
			person.goal = goal
			person.route = route
			person.index = 0
			if goal["kind"] == "bench":

				var seats: Array = goal["seats"]
				var seat: = 1 if seats[0] else 0
				seats[seat] = true
				var yaw: = deg_to_rad(goal.get("yaw", 0.0))
				var look: = Vector3( - sin(yaw), 0, - cos(yaw))
				var along: = Vector3(cos(yaw), 0, - sin(yaw))
				var spot: = Vector3(goal["x"], HEIGHTS["path"], goal["z"]) + along * SEATS[seat] + look * 0.15
				person.errand = {
					"own": true, 
					"state": "sit", 
					"spot": spot, 
					"face": spot + look * 10.0, 
					"time": _between(Config.Life.SitTime), 
					"cancel": func() -> void : seats[seat] = false, 
				}
			return true
	return false


func _send_off(person: Person) -> void :
	person.waiting_bus = false
	if _choose_route(person):
		_start_leg(person)
	else:
		person.resume = Game.now() + 5.0
		_set_state(person, "idle")



func _final_leg(person: Person) -> void :
	person.final = true
	_set_leg(person, person.errand["spot"], person.speed)
	_set_state(person, "walk")



func _settle(person: Person) -> void :
	var errand: = person.errand
	_set_leg(person, person.position, 0.0)
	person.resume = Game.now() + errand["time"] if errand.has("time") else INF
	_set_state(person, errand.get("state", "watch"), errand.get("face"))



func _drop_errand(person: Person) -> void :
	if person.errand.has("cancel"):
		person.errand["cancel"].call()
	person.errand = {}



func _pair_up(person: Person, now: float) -> void :
	var settings: Dictionary = Config.Life
	for other: Person in people.values():
		if other != person and other.state == "idle" and other.errand.is_empty() and other.position.distance_to(person.position) < settings["TalkRange"]:
			var done: = now + _between(settings["TalkTime"])
			person.resume = done
			other.resume = done
			_set_state(person, "talk", other.position)
			_set_state(other, "talk", person.position)
			return


func _arrive(person: Person) -> void :
	var now: = Game.now()
	var node: = person.route[person.route.size() - 1]
	person.node = node
	person.at = node
	if not person.errand.is_empty():
		_final_leg(person)
		return
	var goal: = person.goal
	if goal.is_empty():
		_send_off(person)
		return
	_set_leg(person, person.position, 0.0)
	if _is_way_in(goal):

		person.resume = now + Config.Life.FadeTime
		_set_state(person, "leave")
		_arrivals.append(now + _between(Config.Life.IndoorTime))
	else:

		person.waiting_bus = goal["kind"] == "bus_stop"
		person.resume = now + _between(Config.Life.BusWait if person.waiting_bus else Config.Life.LingerTime)
		person.linger_until = person.resume
		_set_state(person, "idle", Vector3(goal["x"], person.position.y, goal["z"]))
		_pair_up(person, now)


func _off_crossing(person: Person) -> void :
	if person.on >= 0:
		graph.crossings[person.on]["walkers"] -= 1
		person.on = -1
		person.hurried = false


func _remove(person: Person) -> void :
	_off_crossing(person)
	_drop_errand(person)
	person.gone = true
	people.erase(person.id)
	count -= 1
	person_removed.emit(person)


func _clear_of_players(place: Dictionary) -> bool:
	for player in Game.players:
		var pivot: = player.global_position
		if Vector2(place["x"], place["z"]).distance_to(Vector2(pivot.x, pivot.z)) < Config.Life.SpawnClear:
			return false
	return true



func _create(start_place: Dictionary) -> Person:
	_next_id += 1
	var person: = Person.new()
	person.id = _next_id
	person.seed = _rng.randi_range(1, 1000000)

	person.speed = _between(Config.Life.WalkSpeed) * float(Figure.GAITS[Figure.age_of(person.seed)]["speed"])
	person.keep = _between(Config.Life.KeepRight)
	person.node = start_place["node"]
	person.at = start_place["node"]
	person.position = Vector3(walk[person.node]["x"], HEIGHTS["path"], walk[person.node]["z"])
	people[person.id] = person
	count += 1
	return person




func _spawn(scattered: bool) -> void :
	var start_place: = _pick_place( func(place: Dictionary) -> bool:
		return _is_way_in(place) and (scattered or _clear_of_players(place)) and not _in_hazard(place["x"], place["z"])
	)
	if start_place.is_empty():
		start_place = _pick_place(_is_way_in)
	if start_place.is_empty():
		return
	var person: = _create(start_place)

	if _choose_route(person):
		if scattered and person.route.size() > 2:
			person.index = _rng.randi_range(0, person.route.size() - 2)
			person.at = person.route[person.index]
			var at: Dictionary = walk[person.at]
			person.position = Vector3(at["x"], HEIGHTS["pavement"], at["z"])
			person.cleared = true
		_start_leg(person)
	else:
		person.resume = Game.now() + 5.0
		_set_leg(person, person.position, 0.0)
		_set_state(person, "idle")
	person_added.emit(person)






func _step_aside(person: Person, now: float) -> void :
	var settings: Dictionary = Config.Life
	var at: = _position_of(person, now)
	if not Emergency.near(_sirens, at.x, at.z, settings["PedSirenRange"], settings["SirenPassed"]):
		return
	var run: float = person.speed * settings["CrossingHurry"]
	if person.on >= 0:
		if person.hurried:
			return
		person.hurried = true
		var done: = clampf((now - person.t0) / person.duration, 0.0, 1.0) if person.duration > 0.0 else 1.0
		person.position = at
		if done < 0.45:
			var kerb: Dictionary = walk[person.route[person.index]]
			person.aside = {"back": true}
			_set_leg(person, Vector3(kerb["x"], HEIGHTS["pavement"], kerb["z"]), run * settings["CrossingPanic"])
		else:
			_set_leg(person, person.to, run * settings["CrossingPanic"])
		return
	var link: = graph.find_link(person.route[person.index], person.route[person.index + 1])
	if link.get("kind") != "roadside":
		return

	var road: int = link["road"]
	var found: = graph.nearest_lane(at.x, at.z, func(lane: Dictionary) -> bool: return lane["road"] == road)
	if found[0] < 0:
		return
	var point: = NavGraph.sample(graph.segments[found[0]], found[1])
	var out: = Vector2(at.x - point.x, at.z - point.y)
	if out.length() < 0.1:
		return
	out = out.normalized() * float(settings.get("PedStepAside", 3.5))
	person.position = at
	person.aside = {"back": false}
	_set_leg(person, Vector3(at.x + out.x, HEIGHTS["path"], at.z + out.y), run)



func _siren_face(person: Person) -> Variant:
	var siren: = Emergency.nearest(_sirens, person.position.x, person.position.z)
	if siren.is_empty():
		return null
	return Vector3(siren["x"], person.position.y, siren["z"])


func _step(person: Person, now: float) -> void :
	if not _sirens.is_empty() and person.state == "walk" and person.aside.is_empty() and not person.final:
		_step_aside(person, now)
	if person.state == "walk":
		if now >= person.arrive:
			person.position = person.to
			_off_crossing(person)
			if not person.aside.is_empty():

				_set_leg(person, person.position, 0.0)
				person.resume = now + 0.5
				_set_state(person, "wait", _siren_face(person))
				return
			if person.final:
				person.final = false
				_settle(person)
				return
			person.index += 1
			person.at = person.route[person.index]
			if person.index >= person.route.size() - 1:
				_arrive(person)
			else:
				_start_leg(person)
	elif now >= person.resume:
		match person.state:
			"wait":
				if not person.aside.is_empty():


					var at: = person.position
					if Emergency.near(_sirens, at.x, at.z, Config.Life.PedSirenRange, Config.Life.SirenPassed):
						person.resume = now + 0.5
						person.shown_face = _siren_face(person)
					else:
						person.cleared = not person.aside["back"]
						person.aside = {}
						_start_leg(person)
				elif _may_cross(person.crossing, person):
					person.cleared = true
					_start_leg(person)
			"idle":
				_send_off(person)
			"talk":

				var goal: = person.goal
				if not goal.is_empty() and now < person.linger_until - 1.0:
					person.resume = person.linger_until
					_set_state(person, "idle", Vector3(goal["x"], person.position.y, goal["z"]))
				else:
					_send_off(person)
			"sit":
				_drop_errand(person)
				_send_off(person)
			"leave":
				_remove(person)


func start(nav_graph: NavGraph) -> void :
	graph = nav_graph
	walk = graph.walk
	_rng.randomize()
	var words: Variant = Rbx.load_json("res://data/modules/TextSl.json")
	if words is Dictionary and words.get("calls") is Dictionary and words["calls"].get("smallTalk") is Array:
		_small_talk = words["calls"]["smallTalk"].size()


	var sizes: = {}
	for place: Dictionary in graph.places:
		sizes[place["island"]] = sizes.get(place["island"], 0) + 1
	var main: = -1
	for island: int in sizes:
		if main < 0 or sizes[island] > sizes[main]:
			main = island
	for place: Dictionary in graph.places:
		if place["island"] == main and WEIGHTS.has(place["kind"]):
			if place["kind"] == "bench":
				place["seats"] = [false, false]
			_destinations.append(place)
	if _pick_place(_is_way_in).is_empty():
		push_warning("Pedestrians: the town has no doors or ways in to walk between")
		return

	for index in _target():
		_spawn(true)
	_running = true
	for lot in NET_LOTS:
		Net.share("life.people.%d" % lot, _net_lot.bind(lot), _net_apply_lot.bind(lot), NET_HZ)







func _net_lot(lot: int) -> Variant:
	var list: Array = []
	for person: Person in people.values():
		if person.id % NET_LOTS == lot:
			list.append([
				person.id, person.seed, person.shown_from, person.shown_to, person.shown_t0, person.shown_speed, 
				maxi(NET_STATES.find(person.shown_state), 0), person.shown_face, person.mood, person.say, person.say_at, 
			])
	return list




func _net_apply_lot(list: Variant, lot: int) -> void :
	if not Net.is_client() or not list is Array:
		return
	_set_mirroring(true)
	var told: = {}
	for row: Array in list:
		var id: int = row[0]
		told[id] = true
		var person: Person = people.get(id)
		var fresh: = person == null
		if fresh:
			person = Person.new()
			person.id = id
			person.seed = row[1]
			people[id] = person
			count += 1
		person.shown_from = row[2]
		person.shown_to = row[3]
		person.shown_t0 = row[4]
		person.shown_speed = row[5]
		person.shown_state = NET_STATES[row[6]]
		person.shown_face = row[7]
		person.mood = row[8]
		person.say = row[9]
		person.say_at = row[10]
		person.state = person.shown_state
		person.position = person.shown_from
		person.to = person.shown_to
		if fresh:
			person_added.emit(person)
	for person: Person in people.values():
		if person.id % NET_LOTS == lot and not told.has(person.id):
			_remove(person)




func _set_mirroring(on: bool) -> void :
	if on == _mirroring:
		return
	for person: Person in people.values():
		_remove(person)
	_mirroring = on
	_arrivals.clear()
	_alighting.clear()
	_bus_seen = -1
	hazard = {}
	if not on and _running:
		for index in _target():
			_spawn(true)


func _process(delta: float) -> void :
	if not _running:
		return
	if Net.is_client() != _mirroring:
		_set_mirroring(Net.is_client())
	if _mirroring:
		return
	_elapsed += delta
	if _elapsed < TICK:
		return
	_elapsed = 0.0
	var now: = Game.now()
	var settings: Dictionary = Config.Life
	_sirens = Emergency.sirens()


	var bus: = graph.bus
	var bus_id: int = bus.get("id", -1)
	if bus_id != _bus_seen:
		_bus_seen = bus_id
		if not bus.is_empty():
			var door: = Vector3(bus["x"], HEIGHTS["pavement"], bus["z"])
			var stop: Dictionary = {}
			var nearest: = INF
			for place: Dictionary in _destinations:
				var gap: float = (place["x"] - bus["x"]) ** 2 + (place["z"] - bus["z"]) ** 2
				if place["kind"] == "bus_stop" and gap < nearest:
					stop = place
					nearest = gap
			for person: Person in people.values():
				if person.waiting_bus and (person.state == "idle" or person.state == "talk") and person.errand.is_empty():
					person.waiting_bus = false
					person.errand = {"own": true, "state": "leave", "spot": door, "time": settings["FadeTime"]}
					_final_leg(person)
			if not stop.is_empty():
				for i in range(1, _rng.randi_range(0, int(settings["Alighting"])) + 1):
					_alighting.append({"at": now + 1.0 + i * 0.9, "stop": stop, "door": door})
	for i in range(_alighting.size() - 1, -1, -1):
		var due: Dictionary = _alighting[i]
		if now >= due["at"]:
			_alighting.remove_at(i)
			if not graph.bus.is_empty() and count < _most():
				var person: = _create(due["stop"])
				person.position = due["door"]
				if _choose_route(person):
					_start_leg(person)
				else:
					person.resume = now + 5.0
					_set_leg(person, person.position, 0.0)
					_set_state(person, "idle")
				person_added.emit(person)

	for person: Person in people.values():
		if person.state == "talk" and _small_talk > 0 and _rng.randf() < settings["TalkChance"] * TICK:
			say(person, Text.m("calls.smallTalk.%d" % _rng.randi_range(1, _small_talk)))
		_step(person, now)


	var wanted: = _target()
	for i in range(_arrivals.size() - 1, -1, -1):
		if now >= _arrivals[i]:
			_arrivals.remove_at(i)
			if count < wanted:
				_spawn(false)

	if count + _arrivals.size() < wanted:
		_arrivals.append(now + _rng.randf_range(1.0, 20.0))






func where(person: Person) -> Vector3:
	if _mirroring:
		var span: = person.shown_from.distance_to(person.shown_to)
		if span < 0.01 or person.shown_speed <= 0.0:
			return person.shown_from
		return person.shown_from.lerp(person.shown_to, clampf((HostClock.now() - person.shown_t0) * person.shown_speed / span, 0.0, 1.0))
	return _position_of(person, Game.now())





func send_to(person: Person, node: int, spot: Vector3, face: Vector3) -> bool:
	if _mirroring or person.gone or person.state == "leave" or person.final:
		return false
	var route: Array[int] = []
	if person.state == "walk":


		var behind: = person.route[person.index]
		var ahead: = person.route[person.index + 1]
		var at: = _position_of(person, Game.now())
		var by: = func(first: int, other: int) -> Array:
			var way: = graph.walk_route(first, node)
			if way.is_empty():
				return [way, INF]
			var length: = graph.route_length
			way.push_front(other)
			return [way, length + Vector2(walk[first]["x"], walk[first]["z"]).distance_to(Vector2(at.x, at.z))]
		var onward: Array = by.call(ahead, behind)
		var none: Array[int] = []
		var back: Array = [none, INF]
		if person.on < 0:
			back = by.call(behind, ahead)
		route = back[0] if back[1] < onward[1] else onward[0]
		if route.is_empty():
			return false
		person.position = at
		person.cleared = true
	else:
		route = graph.walk_route(person.at, node)
		if route.is_empty():
			return false

	_drop_errand(person)
	person.aside = {}
	person.errand = {"spot": spot, "face": face}
	person.goal = {}
	person.route = route
	person.index = 0
	if route.size() >= 2:
		_start_leg(person)
	else:
		person.node = node
		_final_leg(person)
	return true





func come_out(x: float, z: float, reach: float) -> Person:
	if _mirroring or count >= _most():
		return null
	var door: = _pick_place( func(place: Dictionary) -> bool:
		return place["kind"] == "door" and (place["x"] - x) ** 2 + (place["z"] - z) ** 2 < reach * reach and not _in_hazard(place["x"], place["z"])
	)
	if door.is_empty():
		return null
	var person: = _create(door)
	person.resume = Game.now() + 2.0
	_set_leg(person, person.position, 0.0)
	_set_state(person, "idle")
	person_added.emit(person)
	return person




func shoo(person: Person, from: Vector3) -> bool:
	if _mirroring or person.gone or ( not person.errand.is_empty() and not person.errand.get("own", false)) or person.final or person.on >= 0:
		return false
	if person.state == "walk":
		var behind: = person.route[person.index]
		var ahead: = person.route[person.index + 1]
		var gap: = func(id: int) -> float:
			return (walk[id]["x"] - from.x) ** 2 + (walk[id]["z"] - from.z) ** 2
		if gap.call(ahead) >= gap.call(behind):
			return false
		_drop_errand(person)
		person.aside = {}
		person.position = _position_of(person, Game.now())
		person.goal = {}
		person.route = [ahead, behind]
		person.index = 0
		person.cleared = true
		_start_leg(person)
		return true
	elif person.state in ["idle", "wait", "talk", "sit"]:
		_drop_errand(person)
		person.aside = {}
		person.node = person.at
		_send_off(person)
		return person.state == "walk"
	return false



func say(person: Person, text: Variant) -> void :
	if not person.gone and not _mirroring:
		person.say = text
		person.say_at = Game.now()



func set_mood(person: Person, mood: String) -> void :
	if not person.gone and not _mirroring:
		person.mood = mood



func release(person: Person) -> void :
	if _mirroring or person.gone or person.errand.is_empty() or person.errand.get("own", false):
		return
	person.errand = {}
	person.mood = ""
	if person.state == "watch":
		_send_off(person)
	elif person.final:
		person.final = false
		person.position = _position_of(person, Game.now())
		_send_off(person)




func set_hazard(area: Dictionary) -> void :
	if not _mirroring:
		hazard = area
