class_name WardrobeMenu
extends Control







const WIDTH: = 420.0
const ROW: = 52.0
const HEADER: = 44.0
const HELMET_ROWS: = 6

var _plate: Control
var _rows: Control
var _player: Player
var _stall: Variant = null
var _confirming: Variant = null
var _page: = "suits"
var _choices: Array[Callable] = []
var _check: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 80)
	var title: = Ui.caps("", 18)
	title.name = "Title"
	title.position = Vector2(16, 12)
	_plate.add_child(title)
	_rows = Control.new()
	_rows.position = Vector2(8, HEADER)
	_rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_rows)
	GearService.current.choosing_began.connect(_open)
	Text.language_changed.connect( func(_code: String) -> void :
		if _stall != null:
			_draw_page()
	)


func is_open() -> bool:
	return _stall != null


func _open(player: Player, stall: Dictionary) -> void :
	if not player.is_local:
		return
	_player = player
	_stall = stall
	_confirming = null
	_page = "suits"
	_draw_page()
	_plate.visible = true
	MenuKit.take_mouse(player, true)

	if not player.attribute_changed.is_connected(_on_attribute):
		player.attribute_changed.connect(_on_attribute)


func close() -> void :
	if _stall == null:
		return
	_stall = null
	_confirming = null
	_page = "suits"
	_plate.visible = false
	Net.request("gear.choose.stop")
	MenuKit.take_mouse(_player, false)


func _on_attribute(key: String, _value: Variant) -> void :
	if _stall != null and (key == "Helmet" or key == "Cash" or key == "Wear" or key == "HelmetWear" or key.begins_with("Owns_")):
		_draw_page.call_deferred()


static func _say(key: String, args: Array = []) -> String:
	return Text.say(Text.f("hud.wardrobe." + key, args) if not args.is_empty() else Text.m("hud.wardrobe." + key))



func _row(index: int, text: String, detail: String, color: Color, choose: Callable, columns: = 1) -> void :

	var column: = 0
	var line: = index - 1
	if columns > 1:
		column = (index - 1) / HELMET_ROWS
		line = (index - 1) % HELMET_ROWS
	var width: = (_plate.size.x - 16.0) / columns
	var button: = MenuKit.row(Vector2(width - (3 if columns > 1 else 0), ROW - 4), text, detail, color, choose, str(index) if index <= 9 else "", "", 21)
	button.position = Vector2(column * width + (3 if column > 0 else 0), line * ROW)
	_rows.add_child(button)
	_choices.append(choose)


func _wear(suit_id: Variant) -> void :
	Net.request("gear.suit", [suit_id if suit_id != null else ""])
	close()




func _helmets() -> Array:
	var list: Array = []
	var ranks: Array = Config.Gear.Ranks
	for index in range(1, ranks.size()):
		var sheet: = GearService.rank_helmet_of(ranks[index])
		if GearService.current.has_sheet(sheet) and not list.any( func(entry: Dictionary) -> bool: return entry["sheet"] == sheet):
			list.append({"sheet": sheet, "color": "", "saved": int(ranks[index]["saved"])})
	for helmet: Dictionary in Config.Gear.Helmets:
		if not list.any( func(entry: Dictionary) -> bool: return entry["sheet"] == helmet["sheet"]):
			list.append({"sheet": helmet["sheet"], "color": helmet["color"], "saved": INF})
	return list


func _pick(sheet: Variant) -> void :
	Net.request("gear.helmet", [sheet if sheet != null else ""])
	_confirming = null
	_page = "suits"
	_draw_page()


func _draw_helmets(have: int) -> void :
	var saved: = int(_player.get_attr("Saved", 0))
	var picked: Variant = _player.get_attr("Helmet")
	var price: = Ui.money(Config.Gear.HelmetPrice)
	_row(1, _say("rankHelmet"), _say("wearing") if picked == null else _say("rankColor"), Ui.GREEN if picked == null else Ui.TEXT, _pick.bind(null), 2)
	var list: = _helmets()
	for index in list.size():
		var helmet: Dictionary = list[index]
		var sheet: String = helmet["sheet"]
		var helmet_name: = Text.say(Text.upper(Text.named("colors", sheet)))
		var earned: bool = saved >= helmet["saved"]
		var choose: = _pick.bind(sheet)
		if picked == sheet:
			_row(index + 2, helmet_name, _say("wearing"), Ui.GREEN, choose, 2)
		elif earned or PlayerData.owns(_player, sheet):
			_row(index + 2, helmet_name, _say("earned") if earned else _say("owned"), Ui.TEXT, choose, 2)
		elif have < int(Config.Gear.HelmetPrice):
			_row(index + 2, helmet_name, price, Ui.DIM, func() -> void : pass, 2)
		elif _confirming == sheet:
			_row(index + 2, _say("pay", [price]), _say("againHelmet"), Ui.AMBER, choose, 2)
		else:
			_row(index + 2, helmet_name, _say("buyFor", [price]), Ui.TEXT, func() -> void :
				_confirming = sheet
				_draw_page()
			, 2)
	_row(list.size() + 2, _say("back"), "", Ui.AMBER, func() -> void :
		_confirming = null
		_page = "suits"
		_draw_page()
	, 2)


func _draw_page() -> void :
	for child in _rows.get_children():
		_rows.remove_child(child)
		child.queue_free()
	_choices.clear()
	_plate.get_node("Title").text = _say("title")
	var have: = int(_player.get_attr("Cash", 0))
	if _page == "helmets":
		_fit_plate(Vector2(WIDTH * 1.5, HEADER + HELMET_ROWS * ROW + 6))
		_draw_helmets(have)
		return

	var suits: Array = Config.Gear.Suits
	var helmets: = _helmets()

	var wear: = maxf(float(_player.get_attr("Wear", 0.0)), float(_player.get_attr("HelmetWear", 0.0)))
	var worn: = wear >= float(Config.Gear.WearShowFrom)
	var last: = suits.size() + (3 if not helmets.is_empty() else 2) + (1 if worn else 0)
	_fit_plate(Vector2(WIDTH, HEADER + last * ROW + 6))
	_row(1, _say("standardSuit"), _say("issued"), Ui.TEXT, _wear.bind(null))
	for index in suits.size():
		var suit: Dictionary = suits[index]
		var id: String = suit["id"]
		var price: = Ui.money(suit["price"])
		var suit_name: = Text.say(Text.upper(Text.named("suits", id)))
		if PlayerData.owns(_player, id):
			_row(index + 2, suit_name, _say("owned"), Ui.TEXT, _wear.bind(id))
		elif have < int(suit["price"]):
			_row(index + 2, suit_name, _say("tooDear", [price, have]), Ui.DIM, func() -> void : pass)
		elif _confirming == id:
			_row(index + 2, _say("pay", [price]), _say("againSuit"), Ui.AMBER, _wear.bind(id))
		else:
			_row(index + 2, suit_name, _say("buyFor", [price]), Ui.TEXT, func() -> void :
				_confirming = id
				_draw_page()
			)
	if not helmets.is_empty():
		var helmet_name: = _say("rankColor")
		for helmet: Dictionary in helmets:
			if helmet["sheet"] == _player.get_attr("Helmet"):
				helmet_name = Text.say(Text.upper(Text.named("colors", helmet["sheet"])))
		_row(last - 1 - (1 if worn else 0), _say("changeHelmet"), helmet_name, Ui.TEXT, func() -> void :
			_confirming = null
			_page = "helmets"
			_draw_page()
		)
	if worn:
		var price: = int(Config.Gear.RenewPrice)
		var worn_line: = _say("worn", [int(round(wear * 100.0))])
		if have < price:
			_row(last - 1 - (1 if not helmets.is_empty() else 0), _say("renew"), worn_line + "  ·  " + _say("tooDear", [Ui.money(price), have]), Ui.DIM, func() -> void : pass)
		elif _confirming == "renew":
			_row(last - 1 - (1 if not helmets.is_empty() else 0), _say("pay", [Ui.money(price)]), _say("againRenew"), Ui.AMBER, func() -> void :
				Net.request("gear.renew")
				_confirming = null
				_draw_page()
			)
		else:
			_row(last - 1 - (1 if not helmets.is_empty() else 0), _say("renew"), worn_line + "  ·  " + _say("buyFor", [Ui.money(price)]), Ui.TEXT, func() -> void :
				_confirming = "renew"
				_draw_page()
			)
	_row(last, _say("close"), "", Ui.AMBER, close)


func _fit_plate(size: Vector2) -> void :
	_plate.custom_minimum_size = size
	_plate.size = size
	_plate.position = ((get_viewport_rect().size - size) / 2.0).round()


func _input(event: InputEvent) -> void :
	if _stall == null:
		return
	if event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
		return
	var number: = MenuKit.number_key(event)
	if number > 0 and number <= _choices.size():
		get_viewport().set_input_as_handled()
		_choices[number - 1].call()


func _process(delta: float) -> void :
	if _stall == null:
		return

	_check += delta
	if _check < 0.2:
		return
	_check = 0.0
	if _player.health <= 0.0 or _player.seat != null or _player.root_position().distance_to(_stall["position"]) > float(Config.Gear.StallReach):
		close()
