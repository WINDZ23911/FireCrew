extends RefCounted



const GLASS: = Color8(64, 82, 100)
const FRAME: = Color8(236, 234, 228)
const DOOR: = Color8(104, 74, 54)
const STOREY: = 13.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var parent: = kit.own_folder("Backdrop")
	var rng: = kit.rng("backdrop")
	var rows: = kit.rows_under("Map/Backdrop")
	var roofs: Array[int] = []
	for row in rows:
		if store.name_at(row) == "FarRoof":
			roofs.append(row)
	var done: = 0
	for row in rows:
		if store.name_at(row) != "FarHouse":
			continue
		var place: = store.transform(row)
		var size: = store.size(row)
		var wall: = store.color(row)
		var foot: = place.origin - place.basis.y * size.y / 2.0
		var frame: = Transform3D(place.basis.orthonormalized(), foot)

		var rise: = size.z * 0.42
		var roof_color: = Color8(150, 74, 54)
		for roof in roofs:
			var at: = store.position(roof)
			if Vector2(at.x - place.origin.x, at.z - place.origin.z).length() < size.z:
				rise = store.size(roof).y
				roof_color = store.color(roof)
				break
		var run: = size.z / 2.0 + 1.5

		for side: float in [-1.0, 1.0]:
			for flip: float in [0.0, PI]:
				var turn: = Basis(Vector3.UP, flip)
				var at: = frame * (turn * Vector3(side * (size.x / 2.0 + 1.58), size.y + (rise - 0.4) / 2.0, - (run - 0.6) / 2.0))
				kit.wedge(parent, Transform3D(frame.basis * turn, at), Vector3(0.15, rise - 0.4, run - 0.6), wall, "Plaster", "FarGable")

		var across: = maxi(2, int(size.x / 9.5))
		var floors: = maxi(1, int(size.y / STOREY))
		for face: float in [-1.0, 1.0]:
			var door_at: = rng.randi_range(0, across - 1) if face < 0.0 else -1
			for storey in floors:
				for index in across:
					var x: = (index + 0.5 - across / 2.0) * (size.x / across)
					if storey == 0 and index == door_at:
						_hole(kit, parent, frame, Vector3(x, 0.0, face * size.z / 2.0), Vector2(4.4, 8.0), face, DOOR)
						continue
					_hole(kit, parent, frame, Vector3(x, storey * STOREY + 4.0, face * size.z / 2.0), Vector2(4.2, 5.4), face, GLASS)
		for end: float in [-1.0, 1.0]:
			for storey in floors:
				_hole(kit, parent, frame.rotated_local(Vector3.UP, PI / 2.0), Vector3(0.0, storey * STOREY + 4.0, end * size.x / 2.0), Vector2(4.2, 5.4), end, GLASS)

		var chimney: = frame * Vector3(size.x * rng.randf_range(-0.3, 0.3), size.y + rise * 0.55, run * 0.35)
		kit.box(parent, Transform3D(frame.basis, chimney), Vector3(2.6, rise * 0.9, 2.6), Color8(150, 92, 74), "Brick", "FarChimney")
		done += 1
	return "%d far houses finished" % done




static func _hole(kit: PolishKit, parent: int, frame: Transform3D, bottom: Vector3, size: Vector2, face: float, fill: Color) -> void :
	var out: = Vector3(0, 0, face)
	var middle: = bottom + Vector3(0, size.y / 2.0, 0)
	kit.box(parent, Transform3D(frame.basis, frame * (middle + out * 0.06)), Vector3(size.x + 0.8, size.y + 0.8, 0.12), FRAME, "SmoothPlastic", "FarFrame")
	kit.box(parent, Transform3D(frame.basis, frame * (middle + out * 0.14)), Vector3(size.x, size.y, 0.12), fill, "Glass" if fill == GLASS else "Wood", "FarWindow")
