extends Node
























signal started
signal stopped
signal peer_joined(player: Player)
signal peer_left(player: Player)
signal join_failed
signal online(code: String)
signal router_opened(address: String)
signal listed(ok: bool)


signal join_status(text: Variant)

enum {OFF, HOST, CLIENT}
const PORT: = 24565
const MAX_CREW: = 6
const PLAYER_HZ: = 20.0

const NORAY_SERVER: = "foxssake.studio:8890"

const PUNCH_SECONDS: = 6.0

const AUTH_SECONDS: = 10.0

const OWN_ATTRIBUTES: Array[String] = ["Flow", "Pattern", "Language"]

const VOICE_CHANNEL: = 1
const VOICE_MOST: = 1024

var mode: = OFF
var players: Dictionary = {}
var _handlers: Dictionary = {}
var _shares: Dictionary = {}
var _player_clock: = 0.0
var _prompt_clock: = 0.0
var _prompt_states: Dictionary = {}
var _applying_attribute: = false
var _hello_sent: = false
var noray_server: = NORAY_SERVER
var noray: Noray
var _joining_code: = ""
var _relayed: = false
var _upnp: UPNP
var _upnp_port: = 0
var _router_tasks: Array[int] = []
var _stats_clock: = 0.0

var status: Variant = null
var refusal: Variant = null

var left_by_choice: = false
var turned_away: = 0
var _port: = PORT
var _version: = ""
var crew_list: CrewList


var crew_name: = ""
var max_crew: = MAX_CREW
var _password: = ""
var _listing: = true
var _join_password: = ""
var _nonces: Dictionary = {}
var _wrong: Dictionary = {}


func is_host() -> bool:
	return mode != CLIENT


func is_client() -> bool:
	return mode == CLIENT


func active() -> bool:
	return mode != OFF


func my_id() -> int:
	return multiplayer.get_unique_id() if mode != OFF else 1


func player_of(peer: int) -> Player:
	return players.get(peer)


func peer_of(player: Player) -> int:
	for peer: int in players:
		if players[peer] == player:
			return peer
	return 0


func _ready() -> void :

	var configured: Variant = Config.get("Net").get("NorayServer") if Config.get("Net") is Dictionary else null
	if configured is String and not configured.is_empty():
		noray_server = configured
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--noray="):
			noray_server = arg.substr(8)
		elif arg.begins_with("--net-version="):
			_version = arg.substr(14)
		elif arg.begins_with("--crew-password="):
			_join_password = arg.substr(16)
	noray = Noray.new()
	noray.name = "Noray"
	add_child(noray)
	noray.command.connect(_on_noray)
	crew_list = CrewList.new()
	crew_list.name = "CrewList"
	add_child(crew_list)
	crew_list.set_up(noray_server)
	crew_list.published.connect( func(ok: bool) -> void : listed.emit(ok))


	var scene: = multiplayer as SceneMultiplayer
	scene.auth_callback = _on_auth
	scene.auth_timeout = AUTH_SECONDS
	scene.peer_authenticating.connect(_on_authenticating)
	scene.peer_authentication_failed.connect( func(peer: int) -> void :
		_nonces.erase(peer)
		_wrong.erase(peer)
	)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)
	handle("prompt", _on_prompt_request)
	handle("attr", _on_attribute_request)
	handle("hello", _on_hello)






func host(port: = PORT, open_router: = false) -> bool:
	var peer: = ENetMultiplayerPeer.new()
	if peer.create_server(port, MAX_CREW - 1) != OK:
		return false
	peer.host.compress(ENetConnection.COMPRESS_RANGE_CODER)
	multiplayer.multiplayer_peer = peer
	mode = HOST
	_port = port
	left_by_choice = false
	players = {1: Game.local_player}
	_watch(Game.local_player)
	Game.local_player.set_attr("Colour", 0)
	if open_router:
		_open_router(port)
	started.emit()
	return true






func host_online(port: = PORT, shown_name: = "", password: = "", most: = MAX_CREW, listed_too: = true) -> bool:
	crew_name = shown_name.strip_edges().left(32)
	if crew_name.is_empty():
		crew_name = default_crew_name()
	_password = password
	max_crew = clampi(most, 2, MAX_CREW)
	_listing = listed_too

	if not host(port, not OS.get_cmdline_user_args().has("--no-upnp")):
		return false
	_go_online.call_deferred(port)
	return true



static func default_crew_name() -> String:
	var who: = Game.local_player.display_name if Game.local_player else ""
	return Text.say(Text.f("ui.title.defaultName", [who if not who.is_empty() else "Firefighter"]))


func is_locked() -> bool:
	return not _password.is_empty()


func _go_online(port: int) -> void :
	if await noray.open(noray_server) != OK or mode != HOST:
		noray.close()
		if mode == HOST:
			online.emit("")
		return
	_register_host()
	online.emit(noray.code)
	if _listing:
		crew_list.publish({
			"name": crew_name, "map": Edition.id(), "version": base_version(), "players": players.size(), 
			"max": max_crew, "locked": is_locked(), "code": noray.code, 
		})






func _register_host() -> void :
	var peer: = multiplayer.multiplayer_peer as ENetMultiplayerPeer
	var sent: = 0
	while mode == HOST and multiplayer.multiplayer_peer == peer and noray.is_open():
		peer.host.socket_send(noray.address, Noray.REGISTRAR_PORT, noray.registration())
		sent += 1
		await get_tree().create_timer(0.2 if sent < 15 else 15.0).timeout



func join(address: String, port: = PORT, local_port: = 0) -> bool:
	var peer: = ENetMultiplayerPeer.new()
	if peer.create_client(address, port, 0, 0, 0, local_port) != OK:
		return false
	peer.host.compress(ENetConnection.COMPRESS_RANGE_CODER)
	multiplayer.multiplayer_peer = peer
	mode = CLIENT
	_hello_sent = false
	left_by_choice = false
	refusal = null
	_say_status(Text.m("talk.join.reaching"))
	return true




func join_code(code: String, password: Variant = null) -> void :
	if password != null:
		_join_password = str(password)
	_joining_code = code.strip_edges()
	refusal = null
	_say_status(Text.m("talk.join.server"))
	if await noray.open(noray_server) != OK or await noray.register_port() != OK:
		_give_up_joining(Text.m("talk.join.noServer"))
		return

	_relayed = OS.get_cmdline_user_args().has("--noray-relay")
	_say_status(Text.f("talk.join.asking", [_joining_code]))
	noray.ask(_joining_code, _relayed)



static func is_code(text: String) -> bool:
	return not text.is_empty() and not text.contains(".") and not text.contains(":") and text != "localhost"



func _on_noray(what: String, data: String) -> void :
	if refusal != null and mode != HOST:
		return
	if what != "connect" and what != "connect-relay":
		return
	var relay: = what == "connect-relay"
	var at: = noray.address if relay else data.get_slice(":", 0)
	var port: = data.to_int() if relay else data.get_slice(":", 1).to_int()
	var understood: = at.is_valid_ip_address() and port > 0 and (relay or data.count(":") == 1)
	if mode == HOST:
		if understood:
			_punch(at, port)
	elif not _joining_code.is_empty():
		if not understood:
			push_warning("Net: noray says '%s %s'" % [what, data])
			_give_up_joining(Text.f("talk.join.noCode", [_joining_code]))
		elif not join(at, port, noray.local_port):
			push_warning("Net: could not set out for %s:%d" % [at, port])
			_give_up_joining(Text.m("talk.join.noAnswer"))
		elif not relay:
			_relay_if_slow.call_deferred()



func _punch(at: String, port: int) -> void :
	var peer: = multiplayer.multiplayer_peer as ENetMultiplayerPeer
	var left: = PUNCH_SECONDS
	while left > 0.0 and mode == HOST and multiplayer.multiplayer_peer == peer:
		peer.host.socket_send(at, port, "$rwx".to_ascii_buffer())
		await get_tree().create_timer(0.1).timeout
		left -= 0.1


func _relay_if_slow() -> void :
	var peer: = multiplayer.multiplayer_peer
	await get_tree().create_timer(PUNCH_SECONDS).timeout
	if mode == CLIENT and multiplayer.multiplayer_peer == peer and peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTING:
		_try_relay()



func _try_relay() -> void :
	if _relayed or _joining_code.is_empty():
		_give_up_joining()
		return
	_relayed = true
	print("Net: no way straight through to the host; going through the noray relay")
	_say_status(Text.m("talk.join.relay"))

	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	mode = OFF
	noray.ask(_joining_code, true)


func _give_up_joining(why: Variant = null) -> void :
	_joining_code = ""
	noray.close()
	multiplayer.multiplayer_peer = null
	mode = OFF
	print("Net: could not join")
	_say_status(why if why != null else Text.m("talk.join.noAnswer"), true)
	join_failed.emit()




func _say_status(text: Variant, failed: = false) -> void :
	status = text
	print("Net: %s" % Text.say(text, "en"))
	join_status.emit(text)
	if failed:
		Game.notify(text, "danger", Game.local_player)



func version() -> String:
	if not _version.is_empty():
		return _version

	var number: = base_version()
	return number if Edition.is_metlika() else number + "-" + Edition.id()




func base_version() -> String:
	if not _version.is_empty():
		return _version.get_slice("-" + Edition.id(), 0) if not Edition.is_metlika() else _version
	var settings: Variant = Config.get("Net")
	return str(settings.get("Version", "dev")) if settings is Dictionary else "dev"


func _print_stats(delta: float) -> void :
	_stats_clock += delta
	if _stats_clock < 5.0 or not multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		return
	var connection: ENetConnection = (multiplayer.multiplayer_peer as ENetMultiplayerPeer).host
	var sent: = connection.pop_statistic(ENetConnection.HOST_TOTAL_SENT_DATA)
	var received: = connection.pop_statistic(ENetConnection.HOST_TOTAL_RECEIVED_DATA)
	print("net stats: %.1f kB/s out, %.1f kB/s in, %d players" % [sent / _stats_clock / 1000.0, received / _stats_clock / 1000.0, players.size()])
	_stats_clock = 0.0




func _open_router(port: int) -> void :
	var upnp: = UPNP.new()
	_router_task( func() -> void :
		if upnp.discover(2000, 2, "InternetGatewayDevice") != UPNP.UPNP_RESULT_SUCCESS:
			return
		if upnp.get_gateway() == null or not upnp.get_gateway().is_valid_gateway():
			return
		if upnp.add_port_mapping(port, port, "Fire crew", "UDP") != UPNP.UPNP_RESULT_SUCCESS:
			return
		_router_opened.call_deferred(upnp, port, upnp.query_external_address())
	)


func _router_opened(upnp: UPNP, port: int, address: String) -> void :
	if mode != HOST or (multiplayer.multiplayer_peer as ENetMultiplayerPeer) == null:
		_router_task(upnp.delete_port_mapping.bind(port, "UDP"))
		return
	_close_router()
	_upnp = upnp
	_upnp_port = port
	router_opened.emit(address)


func _close_router(now: = false) -> void :
	if _upnp == null:
		return
	if now:
		_upnp.delete_port_mapping(_upnp_port, "UDP")
	else:
		_router_task(_upnp.delete_port_mapping.bind(_upnp_port, "UDP"))
	_upnp = null


func _router_task(work: Callable) -> void :
	_router_tasks = _router_tasks.filter( func(task: int) -> bool: return not _claimed(task))
	_router_tasks.append(WorkerThreadPool.add_task(work))



func _claimed(task: int) -> bool:
	if not WorkerThreadPool.is_task_completed(task):
		return false
	WorkerThreadPool.wait_for_task_completion(task)
	return true




func finish_router() -> void :
	while not _router_tasks.is_empty():
		await get_tree().process_frame
		_router_tasks = _router_tasks.filter( func(task: int) -> bool: return not _claimed(task))
		if _router_tasks.is_empty():


			await get_tree().process_frame


func _notification(what: int) -> void :
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_PREDELETE:
		_close_router(true)


func leave() -> void :
	if mode == OFF:
		return

	for peer: int in players.keys():
		var player: Player = players[peer]
		if player != Game.local_player and is_instance_valid(player):
			peer_left.emit(player)
			player.queue_free()
	players.clear()
	multiplayer.multiplayer_peer = null
	mode = OFF
	_joining_code = ""
	_nonces.clear()
	_wrong.clear()
	noray.close()
	crew_list.withdraw()
	_close_router()
	stopped.emit()


func _on_connected() -> void :
	print("Net: joined the host%s" % (" (through the relay)" if _relayed else ""))
	_joining_code = ""
	players[my_id()] = Game.local_player
	var me: = Game.local_player
	request("hello", [{
		"name": me.display_name, "cash": int(me.get_attr("Cash", 0)), "saved": int(me.get_attr("Saved", 0)), 
		"pending": int(me.get_attr("Pending", 0)), "wear": float(me.get_attr("Wear", 0.0)), 
		"helmet_wear": float(me.get_attr("HelmetWear", 0.0)), 
		"helmet": me.get_attr("Helmet"), "owns": _owned(me), "language": Text.language, "best": _best(me), 
		"training": _training(me), "version": version(), 
	}])
	_say_status(Text.m("talk.join.joined"))
	started.emit()



func _training(player: Player) -> Dictionary:
	var levels: = {}
	for key: String in player.attributes:
		if key.begins_with("Train_"):
			levels[key] = int(player.attributes[key])
	return levels


func _owned(player: Player) -> Array:
	var owned: Array = []
	for key: String in player.attributes:
		if key.begins_with("Owns_"):
			owned.append(key)
	return owned



func _best(player: Player) -> Dictionary:
	var best: = {}
	for key: String in player.attributes:
		if key.begins_with("Best_"):
			best[key] = player.attributes[key]
	return best


func _on_failed() -> void :
	if refusal != null:
		return
	if not _joining_code.is_empty() and not _relayed:
		_try_relay()
		return
	_joining_code = ""
	noray.close()
	multiplayer.multiplayer_peer = null
	mode = OFF
	_say_status(Text.m("talk.join.noAnswer"), true)
	join_failed.emit()


func _on_server_gone() -> void :
	leave()
	if refusal == null:
		Game.notify(Text.m("talk.net.hostLeft"), "danger")




@rpc("authority", "call_remote", "reliable")
func _rpc_refused(key: String, args: Array) -> void :
	refusal = Text.f(key, args)
	print("Net: the host turned us away: %s" % Text.say(refusal, "en"))
	_say_status(refusal, true)
	left_by_choice = true
	leave.call_deferred()



func _refuse(peer: int, key: String, args: Array) -> void :
	print("Net: turned peer %d away: %s" % [peer, Text.say(Text.f(key, args), "en")])
	turned_away += 1
	_rpc_refused.rpc_id(peer, key, args)
	var peer_now: = multiplayer.multiplayer_peer
	get_tree().create_timer(1.0).timeout.connect( func() -> void :
		if mode == HOST and multiplayer.multiplayer_peer == peer_now and peer_now is ENetMultiplayerPeer:
			(peer_now as ENetMultiplayerPeer).disconnect_peer(peer)
	)





func open_to_crew() -> bool:
	if mode != OFF:
		return false
	if not host_online(_port, crew_name, _password, max_crew):
		Game.notify(Text.m("talk.open.failed"), "danger")
		return false
	Game.notify(Text.f("talk.open.hosting", [", ".join(TitleScreen.local_addresses())]), "good")
	online.connect(said_code, CONNECT_ONE_SHOT)
	return true



func said_code(code: String) -> void :
	if code.is_empty():
		Game.notify(Text.m("talk.open.noCode"), "warning")
		return
	listed.connect(say_listed, CONNECT_ONE_SHOT)



func say_listed(ok: bool) -> void :
	if ok:
		Game.notify(Text.f("talk.open.listed", [crew_name]), "good")
	else:
		Game.notify(Text.m("talk.open.notListed"), "warning")




func leave_crew() -> void :
	if mode == OFF:
		return
	var was_host: = mode == HOST
	left_by_choice = true
	leave()
	Game.notify(Text.m("talk.leave.closed" if was_host else "talk.leave.left"), "good")


func _on_peer_connected(_peer: int) -> void :
	pass


func _on_peer_disconnected(peer: int) -> void :
	_nonces.erase(peer)
	var player: Player = players.get(peer)
	if player == null:
		return
	players.erase(peer)
	peer_left.emit(player)
	if is_instance_valid(player) and player != Game.local_player:
		player.queue_free()
	if mode == HOST:
		_send_roster()
		crew_list.set_players(players.size())









func _on_authenticating(peer: int) -> void :
	if mode != HOST:
		return
	var nonce: = Crypto.new().generate_random_bytes(16).hex_encode()
	_nonces[peer] = nonce
	(multiplayer as SceneMultiplayer).send_auth(peer, JSON.stringify({"nonce": nonce, "locked": is_locked()}).to_utf8_buffer())




func _on_auth(peer: int, data: PackedByteArray) -> void :
	var said: Variant = JSON.parse_string(data.get_string_from_utf8())
	var scene: = multiplayer as SceneMultiplayer
	if mode == HOST:
		var nonce: String = _nonces.get(peer, "")
		var proof: = str(said.get("proof", "")) if said is Dictionary else ""
		_nonces.erase(peer)
		if not nonce.is_empty() and (_password.is_empty() or proof == password_proof(nonce, _password)):
			scene.send_auth(peer, JSON.stringify({"answer": "ok"}).to_utf8_buffer())
			scene.complete_auth(peer)
			return
		print("Net: peer %d gave the wrong password" % peer)
		turned_away += 1
		scene.send_auth(peer, JSON.stringify({"answer": "wrong"}).to_utf8_buffer())
		_wrong[peer] = true
		var peer_now: = multiplayer.multiplayer_peer

		get_tree().create_timer(0.5).timeout.connect( func() -> void :
			if _wrong.has(peer) and mode == HOST and multiplayer.multiplayer_peer == peer_now and peer_now is ENetMultiplayerPeer:
				_wrong.erase(peer)
				(peer_now as ENetMultiplayerPeer).disconnect_peer(peer)
		)
		return
	if peer != 1 or not said is Dictionary:
		return
	if said.has("nonce"):
		scene.send_auth(1, JSON.stringify({"proof": password_proof(str(said["nonce"]), _join_password)}).to_utf8_buffer())
	elif said.get("answer") == "ok":
		scene.complete_auth(1)
	elif said.get("answer") == "wrong":
		_turned_away_at_door(Text.m("talk.join.password" if not _join_password.is_empty() else "talk.join.needPassword"))



static func password_proof(nonce: String, password: String) -> String:
	var hashing: = HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update((nonce + ":" + password).to_utf8_buffer())
	return hashing.finish().hex_encode()



func _turned_away_at_door(why: Variant) -> void :
	refusal = why
	_joining_code = ""
	noray.close()
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	mode = OFF
	print("Net: the host turned us away: %s" % Text.say(why, "en"))
	_say_status(why, true)
	join_failed.emit()



func _on_hello(_from: Player, who: Dictionary, peer: = 0) -> void :
	if mode != HOST or peer == 0 or players.has(peer):
		return

	var theirs: = str(who.get("version", "?"))
	if theirs != version():
		_refuse(peer, "talk.join.version", [version(), theirs])
		return
	if players.size() >= max_crew:
		_refuse(peer, "talk.join.full", [max_crew])
		return
	var player: = _make_player(peer, who.get("name", "Firefighter"))
	player.set_attr("Colour", _free_colour())
	player.set_attr("Cash", int(who.get("cash", 0)))
	player.set_attr("Pending", int(who.get("pending", 0)))
	player.set_attr("Wear", clampf(float(who.get("wear", 0.0)), 0.0, 1.0))
	player.set_attr("HelmetWear", clampf(float(who.get("helmet_wear", 0.0)), 0.0, 1.0))
	player.set_attr("Saved", int(who.get("saved", 0)))
	if who.get("helmet") is String:
		player.set_attr("Helmet", who["helmet"])
	for key: String in who.get("owns", []):
		player.set_attr(key, true)
	var best: Variant = who.get("best", {})
	if best is Dictionary:
		for key: String in best:
			if key.begins_with("Best_") and best[key] is String:
				player.set_attr(key, best[key])
	var training: Variant = who.get("training", {})
	if training is Dictionary:
		for key: String in training:
			if key.begins_with("Train_"):
				player.set_attr(key, clampi(int(training[key]), 0, Training.MOST))
	player.set_attr("Language", who.get("language", "en"))
	player.global_position = Game.spawn_point()
	_send_roster()
	_rpc_teleport.rpc_id(peer, player.global_position)
	for key: String in _shares:
		var share_of: Dictionary = _shares[key]
		_rpc_share.rpc_id(peer, key, share_of["provider"].call())
	for other_peer: int in players:
		_rpc_attributes.rpc_id(peer, other_peer, _encode_all(players[other_peer]))
	_prompt_states.clear()
	peer_joined.emit(player)
	crew_list.set_players(players.size())
	print("Net: %s joined" % player.display_name)
	Game.notify(Text.f("world.net.joined", [player.display_name]), "good")



func _free_colour() -> int:
	var taken: = {}
	for peer: int in players:
		var player: Variant = players[peer]
		if player != null and is_instance_valid(player):
			taken[int(player.get_attr("Colour", -1))] = true
	var count: int = (Config.Talk.Colours as Array).size()
	for index in count:
		if not taken.has(index):
			return index
	return players.size() % count


func _make_player(peer: int, shown_name: String) -> Player:
	var player: = Player.new()
	player.is_local = false
	player.name = "Player_%d" % peer
	player.display_name = shown_name
	get_tree().current_scene.add_child(player)
	players[peer] = player
	if mode == HOST:
		_watch(player)
	return player


func _send_roster() -> void :
	var roster: = {}
	for peer: int in players:
		roster[peer] = players[peer].display_name
	_rpc_roster.rpc(roster)


@rpc("authority", "call_remote", "reliable")
func _rpc_roster(roster: Dictionary) -> void :
	for peer: int in roster:
		if not players.has(peer):
			_make_player(peer, roster[peer])
			peer_joined.emit(players[peer])
		players[peer].display_name = roster[peer]
	for peer: int in players.keys():
		if not roster.has(peer):
			_on_peer_disconnected(peer)






func handle(event: String, handler: Callable) -> void :
	_handlers[event] = handler



func broadcast(event: String, args: Array = []) -> void :
	if mode == HOST:
		_rpc_event.rpc(event, args)



func send_to(player: Player, event: String, args: Array = []) -> void :
	if mode == CLIENT:
		return
	var peer: = peer_of(player)
	if player == Game.local_player or mode == OFF:
		if _handlers.has(event):
			_handlers[event].callv(args)
	elif peer != 0:
		_rpc_event.rpc_id(peer, event, args)





func _joined() -> bool:
	return multiplayer.multiplayer_peer != null and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED\
	and multiplayer.get_peers().has(1)



func request(event: String, args: Array = []) -> void :
	if mode == CLIENT:
		if _joined():
			_rpc_event.rpc_id(1, event, args)
	elif _handlers.has(event):
		_handlers[event].callv([Game.local_player] + args)



func push(event: String, args: Array = []) -> void :
	if mode == CLIENT:
		if _joined():
			_rpc_event_fast.rpc_id(1, event, args)
	elif _handlers.has(event):
		_handlers[event].callv([Game.local_player] + args)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func _rpc_event_fast(event: String, args: Array) -> void :
	_rpc_event(event, args)


@rpc("any_peer", "call_remote", "reliable")
func _rpc_event(event: String, args: Array) -> void :
	var handler: Variant = _handlers.get(event)
	if handler == null:
		push_warning("Net: nothing handles '%s'" % event)
		return
	var sender: = multiplayer.get_remote_sender_id()
	if mode == HOST:
		if event == "hello":
			handler.callv([null] + args + [sender])
			return
		var player: Player = players.get(sender)
		if player != null:
			handler.callv([player] + args)
	elif sender == 1:
		handler.callv(args)








func send_voice(data: PackedByteArray) -> void :
	if mode == CLIENT:
		if _joined():
			_rpc_voice.rpc_id(1, 0, data)
	elif mode == HOST:
		_rpc_voice.rpc(1, data)


@rpc("any_peer", "call_remote", "unreliable_ordered", VOICE_CHANNEL)
func _rpc_voice(peer: int, data: PackedByteArray) -> void :
	var handler: Variant = _handlers.get("voice")
	var sender: = multiplayer.get_remote_sender_id()
	if handler == null or data.size() > VOICE_MOST:
		return
	if mode == HOST:
		if not players.has(sender) or not handler.call(sender, data):
			return
		for other: int in multiplayer.get_peers():
			if other != sender and players.has(other):
				_rpc_voice.rpc_id(other, sender, data)
	elif sender == 1:
		handler.call(peer, data)








func share(key: String, provider: Callable, applier: Callable, hz: = 5.0, fast: = false) -> void :
	_shares[key] = {"provider": provider, "applier": applier, "every": 1.0 / hz, "clock": randf() / hz, "last": null, "fast": fast}


@rpc("authority", "call_remote", "reliable")
func _rpc_share(key: String, state: Variant) -> void :
	if _shares.has(key) and _shares[key]["applier"].is_valid():
		_shares[key]["applier"].call(state)


@rpc("authority", "call_remote", "unreliable_ordered")
func _rpc_share_fast(key: String, state: Variant) -> void :
	if _shares.has(key) and _shares[key]["applier"].is_valid():
		_shares[key]["applier"].call(state)


func _process(delta: float) -> void :
	if mode == OFF or get_tree().current_scene == null or get_tree().current_scene.is_queued_for_deletion():
		return
	if multiplayer.multiplayer_peer == null or multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	if mode == CLIENT and not _joined():
		return
	_player_clock += delta
	if OS.get_cmdline_user_args().has("--net-stats"):
		_print_stats(delta)
	if _player_clock >= 1.0 / PLAYER_HZ:
		_player_clock = 0.0
		_send_players()
	if mode != HOST:
		return
	if players.size() > 1:
		for key: String in _shares:
			var share_of: Dictionary = _shares[key]
			share_of["clock"] += delta
			if share_of["clock"] < share_of["every"]:
				continue
			share_of["clock"] = 0.0
			if not share_of["provider"].is_valid():
				continue
			var state: Variant = share_of["provider"].call()
			if share_of["fast"]:
				_rpc_share_fast.rpc(key, state)
			else:

				var mark: = hash(state)
				if share_of["last"] == null or mark != share_of["last"]:
					share_of["last"] = mark
					_rpc_share.rpc(key, state)
		_prompt_clock += delta
		if _prompt_clock >= 0.2:
			_prompt_clock = 0.0
			_send_prompts()






func _send_players() -> void :
	var me: = Game.local_player
	if me == null:
		return
	if mode == CLIENT:
		_rpc_player.rpc_id(1, me.net_state())
	else:

		var all: = {}
		for peer: int in players:
			var player: Player = players[peer]
			if is_instance_valid(player):
				all[peer] = [player.net_state(), player.net_host_state()]
		_rpc_players.rpc(all)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func _rpc_player(state: Array) -> void :
	var player: Player = players.get(multiplayer.get_remote_sender_id())
	if mode == HOST and player != null:
		player.net_apply(state)


@rpc("authority", "call_remote", "unreliable_ordered")
func _rpc_players(all: Dictionary) -> void :
	var mine: = my_id()
	for peer: int in all:
		var player: Variant = players.get(peer)
		if player == null or not is_instance_valid(player):
			continue
		if peer != mine:
			player.net_apply(all[peer][0])
		player.net_apply_host(all[peer][1])


@rpc("authority", "call_remote", "reliable")
func _rpc_teleport(to: Vector3) -> void :


	var me: = Game.local_player
	if me.seat != null:
		me.leave_seat()
		me.seat_changed.emit(null)
	me.seat_hold_until = Game.now() + 0.6
	me.teleport(to)



func teleport(player: Player, to: Vector3) -> void :
	player.teleport(to)
	var peer: = peer_of(player)
	if mode == HOST and peer > 1:
		_rpc_teleport.rpc_id(peer, to)



func _watch(player: Player) -> void :
	player.attribute_changed.connect( func(key: String, value: Variant) -> void :
		if mode == HOST and not _applying_attribute:
			_rpc_attribute.rpc(peer_of(player), key, encode(value))
	)
	player.rewarded.connect( func(amount: int, why: String) -> void :
		var peer: = peer_of(player)
		if mode == HOST and peer > 1:
			_rpc_reward.rpc_id(peer, amount, why)
	)


@rpc("authority", "call_remote", "reliable")
func _rpc_reward(amount: int, why: String) -> void :
	Game.local_player.rewarded.emit(amount, why)


@rpc("authority", "call_remote", "reliable")
func _rpc_attribute(peer: int, key: String, value: Variant) -> void :
	var player: Player = players.get(peer)
	if player != null:

		if player == Game.local_player and key in OWN_ATTRIBUTES:
			return
		player.set_attr(key, decode(value))


@rpc("authority", "call_remote", "reliable")
func _rpc_attributes(peer: int, values: Dictionary) -> void :
	var player: Player = players.get(peer)
	if player != null:
		for key: String in values:
			if not (player == Game.local_player and key in OWN_ATTRIBUTES):
				player.set_attr(key, decode(values[key]))


func _encode_all(player: Player) -> Dictionary:
	var values: = {}
	for key: String in player.attributes:
		values[key] = encode(player.attributes[key])
	return values



func own_attribute_changed(key: String, value: Variant) -> void :
	if mode == CLIENT and key in OWN_ATTRIBUTES:
		request("attr", [key, encode(value)])


func _on_attribute_request(player: Player, key: String, value: Variant) -> void :
	if key in OWN_ATTRIBUTES:
		player.set_attr(key, decode(value))




func encode(value: Variant) -> Variant:
	if value is Node:
		return {"$node": String(value.get_path())} if value.is_inside_tree() else true
	if value is Object or value is Callable or value is RID:
		return true
	if value is Dictionary:
		for key: Variant in value:
			var inner: Variant = value[key]
			if inner is Object or inner is Callable or inner is RID or inner is Dictionary or inner is Array:
				return true
		return value
	if value is Array:
		for inner: Variant in value:
			if inner is Object or inner is Callable or inner is RID:
				return true
	return value


func decode(value: Variant) -> Variant:
	if value is Dictionary and value.size() == 1 and value.has("$node"):
		return get_node_or_null(NodePath(value["$node"]))
	return value






func _on_prompt_request(player: Player, id: String, phase: String) -> void :
	var prompt: Prompt = Prompt.by_id.get(id)
	if prompt == null or not is_instance_valid(prompt) or not prompt.enabled:
		return
	if prompt.global_position.distance_to(player.root_position()) > prompt.reach + 8.0:
		return
	match phase:
		"tap":
			prompt.triggered.emit(player)
		"begin":
			prompt.hold_began.emit(player)
		"end":
			prompt.hold_ended.emit(player)



func _send_prompts() -> void :
	var changed: = {}
	for id: String in Prompt.by_id:
		var prompt: Prompt = Prompt.by_id[id]
		if not is_instance_valid(prompt):
			continue
		var state: = [prompt.enabled, prompt.action, prompt.object, prompt.hold]
		var before: Variant = _prompt_states.get(id)
		if before == null or hash(before) != hash(state):
			_prompt_states[id] = state
			changed[id] = state
	if not changed.is_empty():
		_rpc_prompts.rpc(changed)


@rpc("authority", "call_remote", "reliable")
func _rpc_prompts(changed: Dictionary) -> void :
	for id: String in changed:
		_prompt_states[id] = changed[id]
		_apply_prompt(id)


func _apply_prompt(id: String) -> bool:
	var prompt: Variant = Prompt.by_id.get(id)
	if prompt == null or not is_instance_valid(prompt):
		return false
	var state: Array = _prompt_states[id]
	prompt.enabled = state[0]
	prompt.action = state[1]
	prompt.object = state[2]
	prompt.hold = state[3]
	return true



func prompt_made(prompt: Prompt) -> void :
	if mode == CLIENT and _prompt_states.has(prompt.net_id):
		_apply_prompt.call_deferred(prompt.net_id)
