class_name VehicleDrive
extends RefCounted




const PROFILES: = {

	"Command Vehicle": {
		"topSpeed": 85.0, "reverseSpeed": 24.0, "launch": 48.0, "braking": 55.0, "brakeLag": 0.04, 
		"engineBrake": 3.0, "rolling": 1.2, "grip": 60.0, "maxSteer": 38.0, "steerRate": 120.0, "gears": 6, 
		"shiftTime": 0.2, "revRate": 9.0, "idleRpm": 800.0, "limitRpm": 4000.0, "cylinders": 4, 
		"emptyMass": 0.92, "lean": 0.6, "sound": "car", "starter": "car_starter", "turbo": 0.5, "airBrakes": false, "reverseBeep": false, 
	}, 

	"Fire Truck": {
		"topSpeed": 64.0, "reverseSpeed": 20.0, "launch": 24.0, "braking": 40.0, "brakeLag": 0.15, 
		"engineBrake": 5.0, "rolling": 1.0, "grip": 42.0, "maxSteer": 40.0, "steerRate": 65.0, "gears": 6, 
		"shiftTime": 0.35, "revRate": 5.0, "idleRpm": 600.0, "limitRpm": 2300.0, "cylinders": 6, 
		"emptyMass": 0.82, "lean": 1.0, "sound": "six", "turbo": 1.0, "airBrakes": true, 
	}, 

	"Tanker": {
		"topSpeed": 58.0, "reverseSpeed": 18.0, "launch": 17.5, "braking": 32.0, "brakeLag": 0.18, 
		"engineBrake": 5.0, "rolling": 1.0, "grip": 36.0, "maxSteer": 40.0, "steerRate": 55.0, "gears": 6, 
		"shiftTime": 0.4, "revRate": 4.0, "idleRpm": 600.0, "limitRpm": 2200.0, "cylinders": 6, 
		"emptyMass": 0.74, "lean": 1.15, "sound": "six", "pitch": 0.9, "turbo": 0.8, "airBrakes": true, 
	}, 



	"Ladder Truck": {
		"topSpeed": 58.0, "reverseSpeed": 18.0, "launch": 16.0, "braking": 32.0, "brakeLag": 0.18, 
		"engineBrake": 5.0, "rolling": 1.0, "grip": 36.0, "maxSteer": 40.0, "steerRate": 60.0, "gears": 6, 
		"shiftTime": 0.4, "revRate": 4.0, "idleRpm": 600.0, "limitRpm": 2300.0, "cylinders": 6, 
		"emptyMass": 0.85, "lean": 1.15, "bodyLean": 0.5, "sound": "six", "pitch": 0.95, "turbo": 0.8, 
		"airBrakes": true, 
	}, 

	"Ambulance": {
		"topSpeed": 70.0, "reverseSpeed": 22.0, "launch": 34.0, "braking": 48.0, "brakeLag": 0.06, 
		"engineBrake": 3.0, "rolling": 1.1, "grip": 52.0, "maxSteer": 38.0, "steerRate": 100.0, "gears": 5, 
		"shiftTime": 0.25, "revRate": 8.0, "idleRpm": 800.0, "limitRpm": 3800.0, "cylinders": 4, 
		"emptyMass": 0.9, "lean": 0.8, "sound": "four", "turbo": 0.5, "airBrakes": false, 
	}, 
}

const FIRST_GEAR: = 0.2
const TOP_GEAR_REVS: = 0.93
const GEAR_FALL: = 0.45
const PULL_AWAY: = 0.3
const REVERSE_AFTER: = 0.3
const STALL_SLACK: = 6.0
const OVERSTEER: = 1.25
const SCRUB: = 14.0
const HILL: = 0.12
const HILL_LIMIT: = 5.0

static var _prepared: Dictionary = {}

var profile: Dictionary
var speed: = 0.0
var steer: = 0.0
var path: = 0.0
var slip: = 0.0
var grip_use: = 0.0
var gear: = 1
var reverse: = false
var shift: = 0.0
var since_shift: = 1.0
var shifts: = 0
var rpm: = 600.0
var revs: = 0.0
var throttle: = 0.0
var brake: = 0.0
var load: = 0.0
var braked: = false
var held: = 0.0
var standing: = 0.0
var accel: = 0.0


func _init(vehicle_name: String) -> void :
	profile = _prepare(vehicle_name)
	rpm = profile["idleRpm"]



static func _settings() -> Dictionary:
	var found: Variant = Config.Drive
	return found if found is Dictionary else {}







static func steer_curve(raw: float, held: float, along: float, profile: Dictionary = {}) -> float:
	var settings: = _settings()
	if absf(raw) < 0.999 or settings.is_empty():
		return raw
	var kmh: = absf(along) * float(Config.Hud.MetresPerStud) * 3.6
	var from: = float(settings.get("SteerFrom", 15.0))
	var full: = float(settings.get("SteerFull", 40.0))
	var tap_share: = float(profile.get("steerTap", settings.get("SteerTap", 0.35)))
	var tap: = lerpf(1.0, tap_share, clampf((kmh - from) / maxf(full - from, 1.0), 0.0, 1.0))
	var ramp: = clampf(held / maxf(float(profile.get("steerRamp", settings.get("SteerRamp", 0.6))), 0.01), 0.0, 1.0)
	return raw * lerpf(tap, 1.0, ramp * ramp)


static func _torque(r: float) -> float:
	if r < 0.3:
		return 0.7 + r
	elif r < 0.75:
		return 1.0
	return maxf(0.0, 1.0 - (r - 0.75) * 0.8)



static func _prepare(vehicle_name: String) -> Dictionary:
	if _prepared.has(vehicle_name):
		return _prepared[vehicle_name]
	var p: Dictionary = PROFILES.get(vehicle_name, PROFILES["Fire Truck"]).duplicate()

	var own: Variant = _settings().get("Profiles", {}).get(vehicle_name)
	if own is Dictionary:
		for key: String in own:
			p[key] = own[key]
	var top: float = p["topSpeed"] / TOP_GEAR_REVS
	var first: float = p["topSpeed"] * FIRST_GEAR
	var tops: Array[float] = []
	for g in range(1, int(p["gears"]) + 1):
		tops.append(first * pow(top / first, float(g - 1) / (p["gears"] - 1)))
	p["gearTop"] = tops
	p["reverseTop"] = p["reverseSpeed"]
	p["revRange"] = p["limitRpm"] - p["idleRpm"]
	var full: = pull(p, int(p["gears"]), p["limitRpm"] * TOP_GEAR_REVS)
	p["drag"] = (full - p["rolling"]) / (p["topSpeed"] * p["topSpeed"])
	_prepared[vehicle_name] = p
	return p



static func pull(p: Dictionary, in_gear: int, at_rpm: float) -> float:
	var top: float = p["reverseTop"] if in_gear == 0 else p["gearTop"][in_gear - 1]
	var r: float = (at_rpm - p["idleRpm"]) / (p["limitRpm"] - p["idleRpm"])
	if r >= 1.0:
		return 0.0
	return p["launch"] * _torque(r) * pow(p["gearTop"][0] / top, GEAR_FALL)


func _gear_top() -> float:
	return profile["reverseTop"] if reverse else profile["gearTop"][gear - 1]



func _gearbox(dt: float) -> void :
	var along: = absf(speed)
	var wheel_rpm: float = along / _gear_top() * profile["limitRpm"]
	var wheel_revs: float = (wheel_rpm - profile["idleRpm"]) / profile["revRange"]
	since_shift += dt
	shift = maxf(0.0, shift - dt)
	if not reverse and shift == 0.0 and since_shift > 0.5:

		if gear < int(profile["gears"]) and wheel_revs > 0.5 + 0.38 * throttle:
			gear += 1
			shift = profile["shiftTime"]
			since_shift = 0.0
			shifts += 1
		elif gear > 1 and wheel_revs < 0.12 + 0.2 * throttle:
			gear -= 1
			shift = profile["shiftTime"] * 0.4
			since_shift = 0.0
	var pulling: = throttle if shift == 0.0 else 0.0
	var target: float = maxf(wheel_rpm, profile["idleRpm"] + pulling * PULL_AWAY * profile["revRange"])
	target = minf(target, profile["limitRpm"])
	rpm += (target - rpm) * minf(1.0, dt * profile["revRate"])
	revs = clampf((rpm - profile["idleRpm"]) / profile["revRange"], 0.0, 1.0)
	load += (pulling - load) * minf(1.0, dt * 8.0)


static func _approach(value: float, target: float, rate: float) -> float:
	return value + clampf(target - value, - rate, rate)















func step(input: Dictionary, dt: float) -> void :
	var axis: = clampf(input.get("drive", 0.0), -1.0, 1.0)
	var before: = speed


	if input.has("actual") and absf(speed - input["actual"]) > STALL_SLACK:
		speed = input["actual"] + signf(speed - input["actual"]) * STALL_SLACK


	var gas: = 0.0
	var pedal: = 0.0
	if reverse:
		gas = maxf( - axis, 0.0)
		pedal = maxf(axis, 0.0)
	else:
		gas = maxf(axis, 0.0)
		pedal = maxf( - axis, 0.0)
	var at_rest: = absf(speed) < 0.5
	var park: bool = input.get("park", false)
	if park:
		gas = 0.0
		pedal = 0.6
		braked = false
		held = 0.0
	elif pedal > 0.0 and not at_rest:
		braked = true
	elif pedal == 0.0:
		braked = false
		held = 0.0
	if pedal > 0.0 and at_rest and not park:
		held += dt
		if not braked or held > REVERSE_AFTER:
			reverse = not reverse
			gear = 1
			shift = 0.0
			braked = false
			held = 0.0
			gas = pedal
			pedal = 0.0

	throttle = _approach(throttle, gas, dt * (6.0 if gas > throttle else 12.0))
	brake = _approach(brake, pedal, dt / maxf(profile["brakeLag"], 0.01))


	var direction: = -1.0 if reverse else 1.0
	var along: = speed * direction
	var mass: float = profile["emptyMass"] + (1.0 - profile["emptyMass"]) * input.get("fill", 1.0)

	_gearbox(dt)
	var drive_pull: = 0.0
	if shift == 0.0:
		var wheel_rpm: float = absf(along) / _gear_top() * profile["limitRpm"]
		drive_pull = throttle * pull(profile, 0 if reverse else gear, maxf(wheel_rpm, profile["idleRpm"])) / mass
	var hold: float = input.get("grip", 1.0)
	drive_pull *= input.get("pull", 1.0)
	var slowing: float = (
		profile["rolling"] + profile["drag"] * along * along
		+ (1.0 - throttle) * profile["engineBrake"] * revs
		+ brake * (maxf(profile["braking"], float(_settings().get("ParkBraking", 0.0))) if park else profile["braking"] * hold) / sqrt(mass)
		+ slip * SCRUB
		+ float(input.get("drag", 0.0))
	)
	if input.has("limit") and absf(along) > input["limit"]:
		drive_pull = 0.0
		slowing += 6.0
	var hill: = clampf( - input.get("slope", 0.0) * HILL * 196.2, - HILL_LIMIT, HILL_LIMIT) * direction

	if gas == 0.0 and absf(along) < 0.3:

		along = 0.0
		standing += dt
	else:
		standing = 0.0
		along += (drive_pull + hill) * dt
		along = maxf(0.0, along - slowing * dt) if along > 0.0 else minf(0.0, along + slowing * dt)
	speed = along * direction
	accel += ((speed - before) / maxf(dt, 0.001) - accel) * minf(1.0, dt * 5.0)




	var wheelbase: float = input["wheelbase"]


	var grip: float = profile["grip"] * hold * (1.0 - float(_settings().get("BrakeGrip", 0.0)) * brake)
	var holds: = atan(grip * wheelbase / maxf(along * along, 1.0))
	var lock: = minf(deg_to_rad(profile["maxSteer"]), holds * OVERSTEER)
	var wanted: = clampf(input.get("steer", 0.0), -1.0, 1.0) * lock
	var rate: float = deg_to_rad(profile["steerRate"]) * (1.0 - 0.5 * minf(1.0, absf(along) / profile["topSpeed"]))
	if absf(wanted) < absf(steer):
		rate *= 1.5
	steer = _approach(steer, wanted, rate * dt)
	path = clampf(steer, - holds, holds)
	grip_use = absf(steer) / maxf(holds, 0.001)
	slip = clampf((absf(steer) - holds) / maxf(holds * (OVERSTEER - 1.0), 0.001), 0.0, 1.0)





func motion(wheelbase: float, rear_axle: float) -> Array[float]:
	var yaw: = - speed * tan(path) / wheelbase
	return [speed, - yaw * rear_axle, yaw]




func observe(seen_speed: float, yaw_rate: float, wheelbase: float, dt: float) -> void :
	accel += ((seen_speed - speed) / maxf(dt, 0.001) - accel) * minf(1.0, dt * 5.0)
	speed = seen_speed
	if absf(speed) > 0.5:
		var backwards: = speed < 0.0
		if backwards != reverse:
			reverse = backwards
			gear = 1
	var along: = absf(speed)
	var gaining: = accel * (-1.0 if reverse else 1.0)
	var wheel_rpm: float = along / _gear_top() * profile["limitRpm"]
	var full: = pull(profile, 0 if reverse else gear, maxf(wheel_rpm, profile["idleRpm"]))
	var needed: float = gaining + profile["rolling"] + profile["drag"] * along * along
	var wanted: = clampf(needed / full, 0.0, 1.0) if (along > 0.5 and full > 0.0) else 0.0
	throttle += (wanted - throttle) * minf(1.0, dt * 6.0)
	brake = clampf( - gaining / profile["braking"], 0.0, 1.0)
	standing = standing + dt if along < 0.3 else 0.0
	_gearbox(dt)
	var seen_steer: = atan( - yaw_rate * wheelbase / speed) if along > 1.0 else 0.0
	steer += (seen_steer - steer) * minf(1.0, dt * 8.0)
	path = steer
	grip_use = absf(steer) / maxf(atan(float(profile["grip"]) * wheelbase / maxf(along * along, 1.0)), 0.001)
