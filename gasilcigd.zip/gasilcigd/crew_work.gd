class_name CrewWork
extends RefCounted



const NEAR_CALL: = 160.0


static func finders() -> Array[Callable]:
	var list: Array[Callable] = [_find_tree, _find_wreck, _find_victim, _find_door, _find_road, _find_crowd]
	list.append_array(CrewWater.finders())
	return list



static func vehicle_orders(vehicle: Vehicle, lead: Player) -> Array:
	return CrewDrive.vehicle_orders(vehicle, lead)



static func ground_orders(at: Vector3) -> Array:
	var options: Array = []
	if Game.incident.is_empty() or at.distance_to(Game.incident.get("pos", at)) > NEAR_CALL:
		return options
	var middle: Vector3 = Game.incident.get("pos", at)
	options.append(CrewTargets.order(Text.m("crew.orders.floodlight"), "floodlight", func() -> CrewJob: return JobStandTool.new("Floodlight", at, middle)))
	if not CrewKit.road_at(at).is_empty():
		options.append(CrewTargets.order(Text.m("crew.orders.cones"), "cone", func() -> CrewJob: return JobCones.new(at)))
	return options






static func _find_tree(view: Dictionary) -> Dictionary:
	var tree: = FallenTree.current
	if tree == null or tree.scene.is_empty():
		return {}
	var point: Vector3 = view["point"]
	var near: = INF
	for ring: Dictionary in tree.scene.get("rings", []):
		if not ring["done"]:
			near = minf(near, JobCutTree._ring_at(ring).distance_to(point))
	var loose: Dictionary = {}
	for piece: Dictionary in tree.scene.get("pieces", []):
		if piece["butt"] or not is_instance_valid(piece["log"]):
			continue
		var distance: float = piece["log"].global_position.distance_to(point) - piece["length"] * 0.4
		if distance < near:
			near = distance
			loose = piece if piece["free"] and not piece.get("cleared", false) else {}
	if near > 8.0:
		return {}
	var at: = tree.position_of_call
	var options: Array = []
	var cuts_left: = false
	for ring: Dictionary in tree.scene["rings"]:
		cuts_left = cuts_left or not ring["done"]
	if not loose.is_empty():
		var piece: = loose
		options.append(CrewTargets.order(Text.m("crew.orders.dragThis"), "arrow", func() -> CrewJob: return JobDrag.new(piece)))
	if cuts_left:
		options.append(CrewTargets.order(Text.m("crew.orders.cutTree"), "saw", func() -> CrewJob: return JobCutTree.new()))
	options.append(CrewTargets.order(Text.m("crew.orders.clearRoad"), "arrow", func() -> CrewJob: return JobDrag.new()))
	options.append(CrewTargets.order(Text.m("crew.orders.cones"), "cone", func() -> CrewJob: return JobCones.new(at)))
	return {"kind": "tree", "position": view["point"] + Vector3(0, 3, 0), "score": near, "label": Text.m("crew.targets.tree"), "options": options}



static func _find_wreck(view: Dictionary) -> Dictionary:
	var crash: = CarCrash.current
	if crash == null or crash.scene.is_empty():
		return {}
	var point: Vector3 = view["point"]
	var near: = INF
	var door: Dictionary = {}
	for each: Dictionary in crash.scene.get("doors", []):
		var distance: float = each["position"].distance_to(point)
		if each["stage"] <= CarCrash.JOBS.size() and distance < near:
			near = distance
			door = each
	for wreck: Variant in crash.scene.get("wrecks", []):
		if wreck is Dictionary and wreck.has("node") and is_instance_valid(wreck["node"]):
			near = minf(near, wreck["node"].global_position.distance_to(point) - 4.0)
	if near > 9.0:
		return {}
	var options: Array = []
	if not door.is_empty():
		var which: = door
		options.append(CrewTargets.order(Text.m("crew.orders.cutOpen"), "spreader", func() -> CrewJob: return JobCutOpen.new(which)))
	var engine: Variant = crash.scene.get("engine")
	if engine is Dictionary and engine["state"] == "smoking" and is_instance_valid(engine["prompt"]):
		var prompt: Prompt = engine["prompt"]
		options.push_front(CrewTargets.order(Text.m("crew.orders.battery"), "warning", func() -> CrewJob: return JobPress.new("battery", prompt, "rescue")))
	if not JobCarry.free_victims().is_empty():
		options.append(CrewTargets.order(Text.m("crew.orders.carry"), "heart", func() -> CrewJob: return JobCarry.new()))
	var at: = crash.position
	options.append(CrewTargets.order(Text.m("crew.orders.cones"), "cone", func() -> CrewJob: return JobCones.new(at)))
	options.append(CrewTargets.order(Text.m("crew.orders.cutAll"), "cutter", func() -> CrewJob: return JobCutOpen.new()))
	return {"kind": "wreck", "position": point + Vector3(0, 4, 0), "score": maxf(near, 0.0), "label": Text.m("crew.targets.wreck"), "options": options}



static func _find_victim(view: Dictionary) -> Dictionary:
	var best: Victim = null
	var best_off: = 4.0
	for person in JobCarry.free_victims():
		var off: = CrewTargets.off_sight(view, person.position())
		if off < best_off:
			best_off = off
			best = person
	if best == null:
		return {}
	var person: = best
	return {
		"kind": "victim", "position": person.position() + Vector3(0, 3, 0), "score": best_off - 4.0, 
		"label": Text.m("crew.targets.victim"), 
		"options": [CrewTargets.order(Text.m("crew.orders.carry"), "heart", func() -> CrewJob: return JobCarry.new(person))], 
	}



static func _find_door(view: Dictionary) -> Dictionary:
	if FireService.current == null:
		return {}
	var point: Vector3 = view["point"]
	var best: Dictionary = {}
	var best_house: House = null
	var best_distance: = 5.0
	for building in FireService.current.buildings:
		if not building is House or building.position.distance_to(point) > 80.0:
			continue
		var house: House = building
		for door_name: String in house.doors:
			var door: Dictionary = house.doors[door_name]
			if door["burnt"] or not is_instance_valid(door["prompt"]):
				continue
			var distance: float = door["prompt"].global_position.distance_to(point)
			if distance < best_distance:
				best_distance = distance
				best = door
				best_house = house
	if best.is_empty():
		return {}
	var door: = best
	var house: = best_house
	var options: Array = []
	if not door["open"]:
		options.append(CrewTargets.order(Text.m("crew.orders.forceDoor" if door["locked"] else "crew.orders.openDoor"), "halligan", func() -> CrewJob: return JobForceDoor.new(house, door)))

	if door["outside"] and CrewSearch.house() == house:
		options.append(CrewTargets.order(Text.m("crew.orders.search"), "search", func() -> CrewJob: return JobSearch.new(house)))
	if door["outside"]:
		var at: Vector3 = door["prompt"].global_position
		var outward: = Vector3(view["from"].x - at.x, 0, view["from"].z - at.z).normalized()
		options.append(CrewTargets.order(Text.m("crew.orders.fan"), "fan", func() -> CrewJob: return JobStandTool.new("Fan", at + outward * 6.0, at)))
	if options.is_empty():
		return {}
	return {
		"kind": "door", "position": door["prompt"].global_position + Vector3(0, 3, 0), "score": best_distance - 1.0, 
		"label": Text.m("crew.targets.lockedDoor" if door["locked"] else "crew.targets.door"), "options": options, 
	}



static func _find_road(view: Dictionary) -> Dictionary:
	if Game.incident.is_empty():
		return {}
	var point: Vector3 = view["point"]
	var middle: Vector3 = Game.incident.get("pos", point)
	if point.distance_to(middle) > NEAR_CALL or view["hit"].is_empty():
		return {}
	var road: = CrewKit.road_at(point)
	if road.is_empty() or Vector3(road[0].x - point.x, 0, road[0].z - point.z).length() > 7.0:
		return {}
	return {
		"kind": "road", "position": point + Vector3(0, 2, 0), "score": 30.0, "label": Text.m("crew.targets.road"), 
		"options": [
			CrewTargets.order(Text.m("crew.orders.cones"), "cone", func() -> CrewJob: return JobCones.new(point)), 
			CrewTargets.order(Text.m("crew.orders.floodlight"), "floodlight", func() -> CrewJob: return JobStandTool.new("Floodlight", point, middle)), 
		], 
	}



static func _find_crowd(view: Dictionary) -> Dictionary:
	if Game.incident.is_empty() or Bystanders.current == null or Bystanders.current.people == null:
		return {}
	var point: Vector3 = view["point"]
	var near: = 0
	for person: Pedestrians.Person in Bystanders.current.people.people.values():
		if not person.gone and person.position.distance_to(point) < 10.0:
			near += 1
	if near == 0:
		return {}
	var at: = point
	return {
		"kind": "crowd", "position": point + Vector3(0, 6, 0), "score": 12.0, "label": Text.m("crew.targets.crowd"), 
		"options": [CrewTargets.order(Text.m("crew.orders.bystanders"), "shield", func() -> CrewJob: return JobBystanders.new(at))], 
	}
