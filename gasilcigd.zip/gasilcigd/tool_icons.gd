class_name ToolIcons
extends RefCounted



const ICONS: = {
	"Axe": "axe", 
	"Halligan bar": "halligan", 
	"Crowbar": "crowbar", 
	"Bolt cutters": "boltCutters", 
	"Spreader": "spreader", 
	"Cutter": "cutter", 
	"Chainsaw": "saw", 
	"Extinguisher": "extinguisher", 
	"Floodlight": "floodlight", 
	"Fan": "fan", 
	"Thermal camera": "camera", 
	"Cones": "cone", 
	"Barrier tape": "tape", 
	"Divider": "hydrant", 
	"Nozzle": "nozzle", 
}


static func of(tool_name: String) -> String:
	return ICONS.get(tool_name, "")
