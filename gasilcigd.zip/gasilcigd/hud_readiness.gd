class_name HudReadiness
extends Control




const WIDTH: = 270.0
const PAD: = 8.0
const LINE: = 21.0

var _plate: Control
var _title: Label
var _rows: Array[Label] = []
var _hint: Label


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, 60))
	_plate.visible = false
	add_child(_plate)
	_title = Ui.display("", 17)
	_title.position = Vector2(PAD, PAD - 2)
	_plate.add_child(_title)
	for index in 4:
		var row: = Ui.label("", 16)
		row.size = Vector2(WIDTH - PAD * 2, LINE * 2.0)
		_plate.add_child(row)
		_rows.append(row)
	_hint = Ui.label("", 15)
	_hint.size = Vector2(WIDTH - PAD * 2, LINE)
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.add_theme_color_override("font_color", Ui.YELLOW)
	_plate.add_child(_hint)



func shown_text() -> String:
	if not _plate.visible:
		return ""
	var parts: PackedStringArray = [_title.text]
	for row in _rows:
		if row.visible:
			parts.append(row.text)
	parts.append(_hint.text)
	return " | ".join(parts)


func _process(_delta: float) -> void :
	var readiness: = Readiness.current
	var player: = Game.local_player
	var shown: bool = readiness != null and player != null and readiness.state.get("due", false)\
	and Game.station != null and Game.station.inside(player.global_position, float(Config.Readiness.ShowReach))
	_plate.visible = shown
	if not shown:
		return
	_title.text = Text.say(Text.m("world.readiness.title"))
	var vehicles: Dictionary = readiness.state.get("vehicles", {})
	var filling: Dictionary = readiness.state.get("filling", {})
	var y: = PAD + LINE + 4.0
	var index: = 0
	var left_any: = false
	for vehicle_name: String in vehicles:
		if index >= _rows.size():
			break
		var items: Dictionary = vehicles[vehicle_name]
		var marks: PackedStringArray = []
		var done_all: = true
		for item: String in items:
			var going: bool = filling.get(vehicle_name, {}).get(item, false)
			marks.append("%s %s" % ["✓" if items[item] else ("…" if going else "□"), Text.say(Text.m("world.readiness.items.%s" % item))])
			done_all = done_all and items[item]
		left_any = left_any or not done_all
		var row: = _rows[index]
		row.visible = true
		row.text = "%s\n   %s" % [Text.say(Text.named("vehicles", vehicle_name)).to_upper(), "  ".join(marks)]
		row.add_theme_color_override("font_color", Ui.GREEN if done_all else Ui.TEXT)
		row.position = Vector2(PAD, y)
		y += LINE * 2.0
		index += 1
	for rest in range(index, _rows.size()):
		_rows[rest].visible = false
	_hint.text = Text.say(Text.f("world.readiness.hint", [Controls.key_name("interact")])) if left_any else ""
	_hint.position = Vector2(PAD, y + 2.0)
	var tall: = maxf(_hint.get_line_count(), 1) * _hint.get_line_height()
	_hint.size = Vector2(WIDTH - PAD * 2, tall)
	_plate.size = Vector2(WIDTH, y + tall + PAD + 4.0)

	var top: = Ui.MARGIN + 210.0 + 12.0
	var duty: Variant = Hud.current.widgets.get("duty") if Hud.current != null else null
	if duty != null and duty.get("_plate") is Control and (duty._plate as Control).visible:
		var plate: Control = duty._plate
		top = plate.position.y + plate.size.y + 10.0
	_plate.position = Vector2(Ui.MARGIN, top)
