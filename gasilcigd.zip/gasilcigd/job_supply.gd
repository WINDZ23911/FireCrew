class_name JobSupply
extends CrewJob



var vehicle: Vehicle
var hydrant: Dictionary


func _init(truck: Vehicle, chosen: Dictionary = {}) -> void :
	kind = "supply"
	role = "pump"
	vehicle = truck
	hydrant = chosen


func place() -> Vector3:
	return vehicle.intake["node"].global_position if not vehicle.intake.is_empty() else vehicle.global_position


func run() -> bool:
	var rig: = CrewWater.rig_of(vehicle)
	if rig.is_empty() or vehicle.intake.is_empty():
		return fail("crew.say.noIntake")
	var supply: Dictionary = rig["supply"]
	if supply["state"] == "connected":
		return true
	if hydrant.is_empty():
		hydrant = CrewWater.hydrant_for(vehicle)
	if hydrant.is_empty():
		return fail("crew.say.noHydrant")
	if hydrant["rig"] != null:
		return fail("crew.say.hydrantTaken")
	var intake: Vector3 = vehicle.intake["node"].global_position
	if intake.distance_to(hydrant["position"]) > float(Config.Hose.SupplyLength) - 5.0:
		return fail("crew.say.hoseShort")
	CrewKit.free_hands(who)
	var held: = who.token()
	if supply["state"] != "carried" or supply["player"] != who.body:
		if supply["state"] != "stowed":
			return fail("crew.say.cannot")
		if not await who.press(supply["prompt"]):
			return fail("crew.say.stuck") if on(held) else false
		await who.wait(0.3, held)
	if HoseService.current.supply_of(who.body) == null:
		return fail("crew.say.cannot")

	if not await who.press(hydrant["prompt"]):
		return fail("crew.say.stuck") if on(held) else false
	await who.wait(0.3, held)
	return supply["state"] == "connected"


func finish(done: bool) -> void :
	if not done:
		var rig: Variant = HoseService.current.supply_of(who.body)
		if rig != null:
			HoseService.current.stow_supply(rig)
