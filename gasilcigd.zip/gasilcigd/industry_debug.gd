class_name IndustryDebug
extends Node













var _kind: = ""
var _opts: Dictionary = {}
var _shots: = ""
var _player: Player
var _checks: Array = []
var _report: Dictionary = {}


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		var bits: = arg.split("=", true, 1)
		if bits[0] == "--industry":
			_kind = bits[1]
		elif bits[0] == "--industry-opt":
			for opt in bits[1].split(","):
				var pair: = opt.split(":", true, 1) if ":" in opt else opt.split("=", true, 1)
				_opts[pair[0]] = pair[1] if pair.size() > 1 else ""
		elif bits[0] == "--industry-shots":
			_shots = bits[1]
		elif bits[0] == "--industry-look":
			_shots = bits[1]
			_look.call_deferred()
			return
	if _kind.is_empty():
		return
	CallService.current.forced = _kind
	if _opts.has("false") and FireAlarm.current != null:
		FireAlarm.current.forced_real = 0
	if _opts.has("source") and HazmatLeak.current != null:
		HazmatLeak.current.forced_source = _opts["source"]
	if _opts.has("site") and WorkAccident.current != null:
		WorkAccident.current.forced_site = _opts["site"]
	_player = Game.local_player
	CallService.current.debriefed.connect( func(report: Dictionary) -> void : _report = report)
	Game.call_started.connect( func(kind: String) -> void :
		if kind == _kind:
			_play.call_deferred())


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false).timeout


func _snap(tag: String, at: Vector3) -> void :
	if _shots.is_empty():
		return
	var before: = get_viewport().get_camera_3d()
	var camera: = Camera3D.new()
	get_tree().root.add_child(camera)
	camera.global_position = at + Vector3(26, 20, 30)
	camera.look_at(at + Vector3(0, 2, 0))
	camera.current = true
	await _wait(0.6)
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])
	print("industry shot: %s_%s.png" % [_shots, tag])
	camera.queue_free()
	if before != null:
		before.make_current()



func _snap_from(tag: String, from: Vector3, at: Vector3) -> void :
	if _shots.is_empty():
		return
	var before: = get_viewport().get_camera_3d()
	var camera: = Camera3D.new()
	camera.near = 0.05
	get_tree().root.add_child(camera)
	camera.look_at_from_position(from, at)
	camera.current = true
	await _wait(0.6)
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])
	print("industry shot: %s_%s.png" % [_shots, tag])
	camera.queue_free()
	if before != null:
		before.make_current()



func _snap_close(tag: String, at: Vector3) -> void :
	if _shots.is_empty():
		return
	var before: = get_viewport().get_camera_3d()
	var camera: = Camera3D.new()
	get_tree().root.add_child(camera)
	camera.global_position = at + Vector3(5, 4, 6)
	camera.look_at(at + Vector3(0, 2.5, 0))
	camera.current = true
	await _wait(0.6)
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])
	print("industry shot: %s_%s.png" % [_shots, tag])
	camera.queue_free()
	if before != null:
		before.make_current()


func _gear_up() -> void :
	GearService.current._gear_up(_player, null, true)
	AirService.current.take_set(_player, "truck")
	await _wait(0.3)
	AirService.current._set_mask(_player, true)
	await _wait(0.3)


func _trigger(net_id: String) -> bool:
	var prompt: Prompt = Prompt.by_id.get(net_id)
	if prompt == null or not prompt.enabled:
		print("industry: no prompt %s to use" % net_id)
		return false
	_player.teleport(prompt.global_position + Vector3(1.5, 0, 1.5))
	await _wait(0.4)
	prompt.triggered.emit(_player)
	return true


func _carry_all() -> void :
	var people: = VictimService.current
	var ambulance: = AmbulanceService.current
	var waited: = 0.0
	while ambulance != null and not ambulance.arrived() and waited < 60.0:
		await _wait(1.0)
		waited += 1.0
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying":
			print("industry: a victim is %s, not lying" % victim.state)
			continue
		_player.teleport(victim.position() + Vector3(2, 0.5, 0))
		await _wait(0.3)
		var lifted: = people.lift(victim, _player)
		await _wait(0.5)
		var zone: Variant = ambulance.zone_position() if ambulance else null
		if zone != null:
			_player.teleport(zone + Vector3(0, 0.5, 0))
		await _wait(1.2)

		var out: = 0
		for one: Victim in people.victims:
			out += int(one.state == "out")
		var total: = people.total if people.total > 0 else int(people.last_counts.get("total", 0))
		if people.total == 0:
			out = int(people.last_counts.get("rescued", 0))
		print("industry: lifted %s, now %s (%d of %d out)" % [lifted, victim.state, out, total])




func _cordon(at: Vector3) -> void :
	var cordon: = Cordon.current
	if cordon == null:
		return
	var item: Dictionary = {}
	for entry: Dictionary in cordon.items:
		if entry["name"] == "Cones" and cordon._cone_stock.get(entry["truck"], 0) >= 2:
			item = entry
			break
	if item.is_empty():
		print("industry: no cones on any truck")
		return
	for side: float in [-1.0, 1.0]:
		var spot: = at + Vector3(side * 30.0, 0, 20.0)
		var cone: = cordon.stand_cone_at(item["truck"], Transform3D(Basis(), CallKit.ground_at(spot + Vector3(0, 3, 0))))
		cone["by"] = _player
	await _wait(0.8)


func _spray_at(target: Vector3, seconds: float) -> void :
	var fire: = FireService.current
	var t: = 0.0
	while t < seconds:
		var from: = _player.head_position()
		fire.spray(_player, PackedVector3Array([from, target]), 0.25 * 1.5, 6.0)
		await _wait(0.25)
		t += 0.25


func _play() -> void :
	await _wait(1.5)
	match _kind:
		"hazmat":
			await _play_hazmat()
		"accident":
			await _play_accident()
		"alarm":
			await _play_alarm()
	await _wait(3.0)
	print("industry: call %s, card %s" % ["over" if Game.incident.is_empty() else "STILL OPEN", Game.incident.get("progress_text", "")])
	if HudDispatch.current != null:
		print("industry: final card: %s" % HudDispatch.current.shown_text())
	if _kind == "alarm":

		_checks.append(["the alarm is reset, or found to be a real fire", Game.incident.is_empty() or Game.incident.get("kind") == "fire"])
	if _kind in ["hazmat", "accident"] and not _opts.has("wait"):
		var people: Array = _report.get("people", [0, 0])
		print("industry: debrief %s, people %s" % [_report.get("grade", "-"), people])
		_checks.append(["the debrief counts everyone the crew carried out (%s)" % [people], int(people[1]) > 0 and int(people[0]) == int(people[1])])
	var failed: Array[String] = []
	for entry: Array in _checks:
		print("%s: %s" % ["check ok" if entry[1] else "CHECK FAILED", entry[0]])
		if not entry[1]:
			failed.append(entry[0])
	if not _checks.is_empty():
		print("PROOF PASS industry-%s (%d checks)" % [_kind, _checks.size()] if failed.is_empty() else "PROOF FAIL industry-%s: %s" % [_kind, "; ".join(failed)])
	if not _shots.is_empty():
		get_tree().quit()


func _play_hazmat() -> void :
	var leak: = HazmatLeak.current
	var state: Dictionary = leak._leak
	var at: Vector3 = state["leak"]
	print("industry: hazmat %s (%s), leak at %s, %d people down" % [state["id"], state["substance"], at, VictimService.current.total])
	if _opts.has("wait"):
		_player.teleport(at + Vector3(0, 0.5, 60))
		await _wait(float(_opts["wait"]))
		print("industry: after waiting, burning %s, cloud %.2f, spill %.2f" % [state["burning"], state["cloud"], state["spill"]])
	await _snap("start", at)
	if _opts.has("nomask"):
		await _trigger("hazmat.valve")
		print("industry: valve without a mask: still leaking %s, health %.0f" % [state["leaking"], _player.health])
	await _gear_up()

	var tasks: Array = Game.incident.get("tasks", [])
	print("industry: card says %s; %d jobs listed" % [Text.say(Game.incident.get("next", "")), tasks.size()])
	_checks.append(["the card lists every job at once", tasks.size() >= 5])
	await _cordon(at)
	await _wait(0.6)
	print("industry: cordon up %s; card says %s" % [state.get("cordon"), Text.say(Game.incident.get("next", ""))])
	_checks.append(["the cones put up after dispatch close the area off", state.get("cordon") == true])

	var sock: Variant = leak._visual.get("sock_cone")
	var wind: Vector3 = leak._wind()
	print("industry: the wind blows to %s (from the %s); windsock %s, plume %s" % [wind, HazmatLeak.compass(wind), sock != null, leak._visual.has("plume")])
	_checks.append(["a windsock and a plume show the wind", sock != null and leak._visual.has("plume")])
	if sock != null:
		var pole: Vector3 = (sock as Node3D).get_parent().global_position
		print("industry: the windsock stands at %s, %.1f above the ground under it" % [pole, pole.y - CallKit.ground_at(pole).y])
		await _snap_from("windsock", pole - (at - pole).normalized() * 12.0 + Vector3(0, 5, 0), pole + Vector3(0, 3, 0))
	if state.get("drain") != null:
		var grate: Vector3 = state["drain"]
		await _snap_from("drain", grate + (at - grate).normalized() * 6.0 + Vector3(0, 4, 0), grate)
	var decon: Vector3 = state["decon"]
	await _snap_from("haze", decon + (decon - at).normalized() * 12.0 + Vector3(0, 9, 0), (decon + at) / 2.0)
	var middle: Vector3 = leak._cloud_middle()
	await _snap_from("plume", middle + Vector3(0, 45, 40), middle)
	_checks.append(["the card says where the wind is from", Text.say(Text.m("calls.hazmat.compass." + HazmatLeak.compass(wind))) in Text.say(Game.incident.get("scene_next", Game.incident.get("next", "")))])

	if state["substance"] == "petrol":
		state["spill"] = maxf(float(state["spill"]), 0.6)
		_player.teleport(at + Vector3(0.5, 0.5, 0.5))
		var before: = _player.health
		await _wait(2.0)
		print("industry: two seconds in the pool: health %.0f -> %.0f (standing at %s, the pool %.1f round %s)" % [before, _player.health, _player.global_position, leak._pool_radius(), at])
		_checks.append(["standing in the pool hurts", _player.health < before - 2.0])
	CallGear.current._on_line(_player, "Foam")
	await _wait(0.2)
	await _trigger("hazmat.foam")
	print("industry: foam on the pool: %s" % state["foamed"])
	_checks.append(["foam from the pumper covers the pool", state["foamed"]])
	if state["substance"] == "petrol":
		_player.teleport(at + Vector3(0.5, 0.5, 0.5))
		var before: = _player.health
		await _wait(2.0)
		_checks.append(["under foam the pool no longer hurts", _player.health >= before - 0.5])
	if state.get("drain") != null:
		await _trigger("hazmat.drain")
		_checks.append(["the drain is covered", state["drain_covered"]])
	if state["substance"] == "ammonia":
		await _trigger("hazmat.valve")
		print("industry: valve without a chemical suit: still leaking %s, health %.0f" % [state["leaking"], _player.health])
		ChemSuit.current._on_line(_player)
		print("industry: chemical suit on %s, %d left" % [ChemSuit.wearing(_player), ChemSuit.current.pool])
		_player.teleport(Game.incident.get("approach", at))
		await _snap_close("suit", _player.root_position())
	print("industry: card says %s" % Text.say(Game.incident.get("next", "")))
	await _trigger("hazmat.valve")
	_checks.append(["the valve shuts", not state["leaking"]])
	print("industry: card says %s" % Text.say(Game.incident.get("next", "")))
	print("industry: valve with a mask: leaking %s, smoke here %.2f, health %.0f" % [state["leaking"], FireService.current.smoke_at(_player.head_position()), _player.health])
	await _snap("mid", at)
	_player.set_attr("Pattern", "Fog")
	var t: = 0.0
	while float(state.get("cloud", 0.0)) > 0.06 and t < 120.0:
		leak._on_water({"position": leak._cloud_middle()}, 0.25, Vector3.DOWN, _player)
		await _wait(0.25)
		t += 0.25
	print("industry: fog for %.0f s, cloud %.2f" % [t, state.get("cloud", 0.0)])
	for made: Dictionary in FireService.current.spots.duplicate():
		await _spray_at(made["position"], 8.0)
	await _carry_all()

	var decon_card: Array = Game.incident.get("tasks", [])
	print("industry: to decontaminate: %d; card says %s" % [leak._decon_left(), Text.say(decon_card[-1]["t"] if decon_card.size() else Game.incident.get("next", ""))])
	await _snap("decon", at)
	_checks.append(["whoever was in the spill is to be decontaminated", leak._decon_left() >= 1 or Game.incident.is_empty()])
	if not leak._leak.is_empty():
		await _trigger("hazmat.decon")
		await _wait(1.0)
	await _snap("end", at)



func _hold_tool(tool_name: String) -> bool:
	if ToolService.current.held(_player) == tool_name:
		return true
	ToolService.current.clear_hands(_player)
	for entry: Dictionary in ToolService.current.items:
		if entry["name"] == tool_name and entry["holder"] == null and not entry["standing"]:
			ToolService.current._on_line(_player, entry)
			await _wait(0.4)
			return ToolService.current.held(_player) == tool_name
	print("industry: no %s on the trucks" % tool_name)
	return false



func _run_tool_at(mark: Vector3, seconds: float) -> void :
	_player.teleport(mark + Vector3(1.4, -1.2, 0.6))
	var toward: Vector3 = mark - _player.head_position()
	_player.camera.yaw = atan2( - toward.x, - toward.z)
	_player.rig.rotation.y = _player.camera.yaw
	await _wait(0.3)

	await get_tree().process_frame
	Input.action_press("fire")
	await _wait(seconds)
	Input.action_release("fire")
	await _wait(0.3)


func _play_accident() -> void :
	var accident: = WorkAccident.current
	var held: = accident._call
	var machine: Vector3 = held["machine"]
	var house: House = held["site"]["house"]
	var jobs: Array = held["jobs"]
	print("industry: accident at %s in %s, isolated at its %s, air %s, jobs %s, level flames %d" % [held["site"]["machine"]["name"], house.name, held["isolate"], held["air"], jobs, held["flames"].size()])
	await _snap("start", machine)
	await _gear_up()
	for made: Dictionary in held["flames"]:
		await _spray_at(made["position"], 10.0)

	_player.teleport(held["foreman"].origin + Vector3(2, 0.5, 2))
	await _wait(1.0)
	_checks.append(["the foreman shouts that the machine is live", held["told_live"]])
	await _snap_close("machine", (held["work_at"] as Vector3) - Vector3(0, 1.2, 0))

	for spot: String in ["isolate_at", "air_at"]:
		if (spot == "air_at" and held["air"]) or (spot == "isolate_at" and held["isolate"] != "main"):
			var at: Vector3 = held[spot]
			var out: = ((held["work_at"] as Vector3) - at) * Vector3(1, 0, 1)
			await _snap_from(spot.trim_suffix("_at"), at + out.normalized() * 3.0 + Vector3(0, 0.6, 0), at - Vector3(0, 0.4, 0))

	if not await _hold_tool(jobs[0] if jobs[0] != "Crib" else "Spreader"):
		return
	var health: = _player.health
	await _run_tool_at(held["work_at"], 1.5)
	print("industry: the tool to the live machine: stage %d, health %.0f -> %.0f" % [held["stage"], health, _player.health])
	_checks.append(["a tool to a live machine shocks its holder, whatever they wear", _player.health <= health - 29.0 and int(held["stage"]) == 0])

	await _trigger("house.%d.control" % house.net_index)
	print("industry: main switch: live %s" % held["live"])
	_checks.append(["the main switch isolates only the machine it feeds", held["live"] == (held["isolate"] != "main")])
	if held["isolate"] != "main":
		await _trigger("accident.isolate")
		print("industry: the machine's own %s: live %s" % [held["isolate"], held["live"]])
	_checks.append(["the machine is isolated at its own source", not held["live"]])
	if held["air"]:
		await _trigger("accident.air")
		_checks.append(["the compressed air is bled", held["bled"]])

	for job: String in jobs:
		var stage: = int(held["stage"])
		if job == "Crib":
			await _trigger("accident.free")
		else:
			if not await _hold_tool(job):
				return
			await _run_tool_at(held["work_at"], float(Config.Incidents.Accident.JobTime) + 1.5)
		print("industry: job %s: stage %d -> %d" % [job, stage, held["stage"]])
	_checks.append(["the worker is freed by the machine's jobs in turn (%s)" % [jobs], held["freed"]])
	await _snap("mid", machine)
	ToolService.current.clear_hands(_player)
	await _carry_all()
	await _snap("end", machine)


func _play_alarm() -> void :
	await _wait(1.0)
	var panel: Dictionary = FireAlarm.current._panel
	if panel.is_empty():
		print("industry: no panel")
		return
	var house: House = panel["house"]
	print("industry: alarm at %s, title %s" % [house.name, Text.say(Game.incident.get("name", ""))])
	var panel_node: Node3D = panel["holder"]
	var face: = panel_node.get_node_or_null("Panel") as Node3D
	if face != null:
		await _wait(4.0)
		var out: Vector3 = face.global_transform.basis.z
		await _snap_from("panel", face.global_position + out * 2.6 + Vector3(0, 0.3, 0), face.global_position + Vector3(0, -0.2, 0))
	await _snap("start", house.position)
	await _trigger("alarm.panel")
	await _wait(0.5)
	print("industry: panel read; card %s" % Text.say(Game.incident.get("name", "")))
	if FireService.current.incident.is_empty():

		for room_name: String in house.rooms:
			var room: Dictionary = house.rooms[room_name]
			_player.teleport(house.lot * (((room["low"] as Vector3) + (room["high"] as Vector3)) / 2.0 * Vector3(1, 0, 1) + Vector3(0, (room["low"] as Vector3).y + 1.0, 0)))
			await _wait(0.6)
		await _trigger("alarm.panel")
	else:
		print("industry: a real fire: %d flames" % int(FireService.current.incident.get("count", 0)))
		await _snap("mid", house.position)



func _look() -> void :
	await _wait(2.0)
	CallService.current.hold = true
	_player = Game.local_player
	for plot: Dictionary in IndustryZone.PLOTS:
		var x: float = plot["x"]
		_player.teleport(Vector3(x, 1, IndustryZone.ROAD_Z + 30))
		await _wait(0.6)
		await _snap_from(plot["name"], Vector3(x + 28, 7, IndustryZone.ROAD_Z + 16), Vector3(x, 8, IndustryZone.LOT_Z))
		await _snap_from(plot["name"] + "_high", Vector3(x + 70, 60, IndustryZone.ROAD_Z + 60), Vector3(x, 0, IndustryZone.LOT_Z))
		await _snap_from(plot["name"] + "_roof", Vector3(x - 50, 55, IndustryZone.LOT_Z - 50), Vector3(x, 20, IndustryZone.LOT_Z))

	if Train.current != null:
		var train: = Train.current

		var trip_t: = Train.FIRST + (-60.0 - (Train.FROM_X - Train.RUN_ON)) / Train.SPEED
		train._shift = 0.0
		train.held = trip_t
		var nose: = Vector3(-60, 0, Train.LINE_Z)
		var loco: = nose - Vector3(Train.CAR_LENGTH * 0.5, 0, 0)
		_player.teleport(nose + Vector3(0, 1, -40))
		await _wait(0.5)
		await _snap_from("train", nose + Vector3(30, 8, -40), nose + Vector3(-90, 3, 0))
		await _snap_from("train_loco", loco + Vector3(30, 7, -28), loco + Vector3(4, 4, 0))
		await _snap_from("train_nose", nose + Vector3(14, 5, -10), nose + Vector3(-2, 4, 0))
		await _snap_from("train_bogie", loco + Vector3(-14, 2.5, -10), loco + Vector3(-18, 1.5, 0))
		await _snap_from("train_coach", loco + Vector3( - Train.CAR_LENGTH - Train.GAP, 6, -22), loco + Vector3( - Train.CAR_LENGTH - Train.GAP, 4, 0))
		train.held = -1.0
	get_tree().quit()
