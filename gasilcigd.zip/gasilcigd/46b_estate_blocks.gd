extends RefCounted









const BOX_COLOURS: = [Color8(222, 220, 214), Color8(196, 192, 184), Color8(150, 146, 140)]
const STAIR_GLASS: = Color8(92, 110, 124)
const LAUNDRY: = [Color8(236, 234, 228), Color8(120, 150, 196), Color8(196, 96, 92), Color8(226, 206, 120), Color8(150, 176, 140), Color8(60, 64, 76)]
const HUNG: = 0.18


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("EstateBlocks")
	var districts: Dictionary = kit.get_meta("districts", {})
	var made: = store.count
	var blocks: = 0
	var boxes: = 0
	var cores: = 0
	var washing: = 0
	for shell: Dictionary in kit.get_meta("shells", []):
		var district: String = districts.get(shell["model"], "")
		if district != "estate" and district != "renovated":
			continue
		blocks += 1
		var rng: = kit.rng("estate:%d" % shell["model"])
		var place: Transform3D = shell["place"]
		var middle: = place.origin
		var box_colour: Color = BOX_COLOURS[rng.randi_range(0, BOX_COLOURS.size() - 1)]
		if district == "renovated":
			box_colour = BOX_COLOURS[0]
		var rows: Dictionary = shell["rows"]
		for row: int in rows.get("Window", []):
			var at: = store.transform(row).orthonormalized()
			var size: = store.size(row)

			var across: = at.basis.x if size.x > size.z else at.basis.z
			var out: = at.basis.z if size.x > size.z else at.basis.x
			if out.dot(at.origin - middle) < 0.0:
				out = - out
			if across.cross(Vector3.UP).dot(out) < 0.0:
				across = - across
			var wide: = maxf(size.x, size.z)
			var top: = at.origin + Vector3(0, size.y / 2.0 + 0.45, 0) + out * 0.3
			kit.box(folder, Transform3D(Basis(across, Vector3.UP, out), top), Vector3(wide + 0.35, 0.8, 0.55), box_colour, "SmoothPlastic", "RollerBox")
			boxes += 1

		for row: int in rows.get("Door", []):
			var at: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			var out: = at.basis.z if size.x > size.z else at.basis.x
			var across: = at.basis.x if size.x > size.z else at.basis.z
			if out.dot(at.origin - middle) < 0.0:
				out = - out
			if across.cross(Vector3.UP).dot(out) < 0.0:
				across = - across
			var from: = at.origin.y + size.y / 2.0 + 2.5
			var to: float = place.origin.y + float(shell["height"]) - 2.5
			if to - from < 8.0:
				continue
			var core: = Vector3(at.origin.x, (from + to) / 2.0, at.origin.z) + out * 0.12
			kit.box(folder, Transform3D(Basis(across, Vector3.UP, out), core), Vector3(3.0, to - from, 0.3), STAIR_GLASS, "Glass", "StairGlass")
			for side: float in [-1.0, 1.0]:
				kit.box(folder, Transform3D(Basis(across, Vector3.UP, out), core + across * side * 1.62), Vector3(0.28, to - from + 0.4, 0.4), box_colour, "Concrete", "StairFrame")
			cores += 1
			break

		for row: int in rows.get("BalconyRail", []):
			if rng.randf() > HUNG:
				continue
			var rail: = store.transform(row).orthonormalized()
			var width: = store.size(row).x
			var top: = store.size(row).y / 2.0
			kit.box(folder, rail * Transform3D(Basis(), Vector3(0, top + 1.6, 1.4)), Vector3(width - 0.6, 0.05, 0.05), Color8(220, 220, 216), "SmoothPlastic", "WashingLine")
			var x: = - width / 2.0 + 0.8
			while x < width / 2.0 - 0.8:
				var cloth: = Vector3(rng.randf_range(0.7, 1.5), rng.randf_range(0.9, 1.6), 0.08)
				var colour: Color = LAUNDRY[rng.randi_range(0, LAUNDRY.size() - 1)]
				kit.box(folder, rail * Transform3D(Basis(), Vector3(x + cloth.x / 2.0, top + 1.6 - cloth.y / 2.0, 1.4)), cloth, colour, "Fabric", "Washing")
				x += cloth.x + rng.randf_range(0.2, 0.8)
			washing += 1
	return "estate blocks: %d blocks, %d roller boxes, %d stair cores, %d balconies with washing (%d parts)" % [blocks, boxes, cores, washing, store.count - made] if blocks > 0 else ""
