class_name DownService
extends Node

















static var current: DownService

var downed: Dictionary = {}
var respawned: = 0
var revived: = 0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	Net.handle("down.mayday", func(player: Player, on: bool) -> void : mayday(player, on))


static func settings() -> Dictionary:
	return Config.Down






func should_go_down(player: Player) -> bool:
	return not Net.is_client() and player.brain == null and Alarm.active and player.seat == null



func go_down(player: Player) -> void :
	if downed.has(player):
		return
	var cause: = _cause(player)
	downed[player] = {"since": Game.now(), "cause": cause, "clean": 0.0}
	player.frozen = true
	player.set_attr("Down", cause)
	_let_go(player)
	Alarm.note(player, "downed")
	Game.notify(Text.f("calls.down.mayday", [player.display_name, Text.m("calls.down.causes." + cause)]), "danger")

	var crew: = CrewService.current
	if crew != null and not crew.members.is_empty():
		crew.order(JobCarry.rescue(player))


static func _cause(player: Player) -> String:
	if player.get_attr("Mask", false) == true and int(player.get_attr("AirBar", 1)) <= 0:
		return "air"
	if float(player.get_attr("Smoke", 0.0)) > 0.2 and player.get_attr("Mask", false) != true:
		return "smoke"
	if FireService.current != null and FireService.current.smoke_at(player.root_position()) > 0.5:
		return "heat"
	return "hurt"



static func _let_go(player: Player) -> void :
	var hoses: = HoseService.current
	if hoses != null:
		var line: Variant = hoses.line_of(player)
		if line != null:
			hoses.disconnect_line(line)
		var supply: Variant = hoses.supply_of(player)
		if supply != null:
			hoses.stow_supply(supply)
	if VictimService.current != null:
		VictimService.current.let_go_of(player)




static func knock(player: Player, air: float) -> void :
	if Net.is_client() or player == null or not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
		return
	_let_go(player)
	if air > 0.0 and AirService.current != null:
		AirService.current.lose_air(player, air)
	player.knock_down(float(settings()["KnockTime"]))
	Game.notify(Text.m("calls.down.knocked"), "danger", player)






func drag(player: Player, rescuer: Player) -> void :
	if not downed.has(player) or rescuer == null or rescuer == player or rescuer.health <= 0.0:
		return
	var by: Variant = player.get_attr("DraggedBy")
	if by == rescuer:
		_release(player)
		return
	if by is Player and is_instance_valid(by):
		return
	if rescuer.get_attr("Carrying") != null:
		return
	_let_go(rescuer)
	player.set_attr("DraggedBy", rescuer)
	rescuer.set_attr("Carrying", true)
	rescuer.set_attr("Dragging", float(settings()["DragSpeed"]))
	Game.notify(Text.f("calls.down.dragging", [rescuer.display_name, player.display_name]), "warning")


func _release(player: Player) -> void :
	var by: Variant = player.get_attr("DraggedBy")
	player.set_attr("DraggedBy", null)
	if by is Player and is_instance_valid(by):
		by.set_attr("Carrying", null)
		by.set_attr("Dragging", null)



static func rescuer_of(player: Player) -> Player:
	var by: Variant = player.get_attr("DraggedBy")
	return by if by is Player and is_instance_valid(by) else null



func _up(player: Player, rescuer: Player) -> void :
	_release(player)
	downed.erase(player)
	player.set_attr("Down", null)
	player.set_attr("Mayday", null)
	player.frozen = false
	if rescuer != null:
		revived += 1
		player.health = float(settings()["ReviveHealth"])
		Alarm.note(rescuer, "rescuedCrew")
		Game.notify(Text.f("calls.down.revived", [rescuer.display_name, player.display_name]), "good")
		return
	respawned += 1
	if bool(settings()["GradeCheck"]):
		Alarm.check("nobodyDown", false)

	player.died.emit()
	player.respawn(_on_scene(player))
	Game.notify(Text.f("calls.down.respawned", [player.display_name]), "warning")




static func _on_scene(player: Player) -> Vector3:
	var best: Variant = null
	var nearest: = 400.0
	for vehicle: Vehicle in Vehicle.all:
		if not is_instance_valid(vehicle) or not vehicle.is_mine():
			continue
		var distance: = vehicle.global_position.distance_to(player.global_position)
		if distance < nearest:
			nearest = distance
			best = vehicle
	if best == null:
		return Game.spawn_point()
	var truck: Vehicle = best
	var side: = truck.global_transform * Vector3(-7.5, 0, 0)
	var ground: = Game.world.raycast(side + Vector3(0, 6, 0), side + Vector3(0, -12, 0), World.LAYER_SOLID)
	return (ground["position"] if not ground.is_empty() else side) + Vector3(0, 0.5, 0)






func mayday(player: Player, on: bool) -> void :
	if player == null or Net.is_client():
		return
	if (player.get_attr("Mayday") != null) == on:
		return
	player.set_attr("Mayday", true if on else null)
	if on:
		Alarm.note(player, "mayday")
		Game.notify(Text.f("calls.down.maydayCalled", [player.display_name]), "danger")
	else:
		Game.notify(Text.f("calls.down.maydayOff", [player.display_name]), "")





func _process(delta: float) -> void :
	if Net.is_client() or downed.is_empty():
		return
	var s: = settings()
	for player: Variant in downed.keys():
		if not is_instance_valid(player) or not player.is_inside_tree():
			downed.erase(player)
			continue
		var state: Dictionary = downed[player]
		var rescuer: = rescuer_of(player)
		if rescuer != null and (rescuer.health <= 0.0 or rescuer.seat != null or rescuer.get_attr("Down") != null\
		or rescuer.global_position.distance_to(player.global_position) > float(s["RescueReach"]) * 2.0):
			_release(player)
			rescuer = null
		if rescuer != null:

			var at: Vector3 = player.root_position()
			var clear: = not _inside(at) and (FireService.current == null or FireService.current.smoke_at(at) < float(s["ReviveSmoke"]))
			if AmbulanceService.current != null and AmbulanceService.current.in_zone(at):
				clear = true
			state["clean"] = float(state["clean"]) + delta if clear else 0.0
			if float(state["clean"]) >= float(s["ReviveTime"]):
				_up(player, rescuer)
			continue
		if Game.now() - float(state["since"]) >= float(s["Time"]):
			_up(player, null)

	if not Alarm.active:
		for player: Variant in downed.keys():
			if is_instance_valid(player):
				_up(player, null)


static func _inside(at: Vector3) -> bool:
	for house: House in House.all:
		if house.position.distance_to(at) < 120.0 and house.room_at(at) != null:
			return true
	return false
