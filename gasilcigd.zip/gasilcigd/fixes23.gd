extends ProofDebug





var _told: Array = []


func _listen() -> void :
	_told.clear()
	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void : _told.append([Text.say(text, "en"), kind]))


func _heard(words: String) -> int:
	return _told.filter( func(entry: Array) -> bool: return String(entry[0]).contains(words)).size()


func _scenario_hoselock() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	var line: Dictionary = hoses.lines.filter( func(l: Dictionary) -> bool: return l["kind"] == "outlet" and l["rig"] != null and l["rig"]["vehicle"] == pumper)[0]
	player.teleport(_ground(line["source"].global_position + pumper.global_basis.x * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	line["prompt"].triggered.emit(player)
	await _wait(0.4)
	_check(is_same(hoses.line_of(player), line), "an outlet's hose in hand")
	player.teleport(player.global_position + pumper.global_basis.x * 6.0)
	await _wait(0.3)
	hoses._put_down(line, player)
	await _wait(0.3)
	_check(line.get("down") != null and hoses.tethered(pumper), "the nozzle put down on the ground, the hose still on the outlet")
	pumper._board(player, "DoorCabLeft")
	await _wait(0.5)
	var start: = pumper.global_position
	pumper.debug_drive = 1.0
	await _wait(3.0)
	pumper.debug_drive = null
	var moved: = pumper.global_position.distance_to(start)
	print("hoselock: with a hose coupled the truck moved %.2f studs in 3 s; told %s" % [moved, _told])
	_check(moved < 1.0, "with a hose on its outlet the truck stays where it is")
	_check(_heard("uncouple") >= 1, "and the driver is told to uncouple first")
	_check(_heard("uncouple") <= 2, "told once, not every tick")
	_view(pumper.global_position + pumper.global_basis.x * 25.0 + Vector3(0, 12, 0), pumper.global_position)
	await _wait(0.3)
	await _snap("held")
	hoses.disconnect_line(line)
	await _wait(0.3)
	_check( not hoses.tethered(pumper), "rolled up, nothing holds it")
	start = pumper.global_position
	pumper.debug_drive = 1.0
	await _wait(3.0)
	pumper.debug_drive = null
	moved = pumper.global_position.distance_to(start)
	print("hoselock: uncoupled, the truck moved %.2f studs in 3 s" % moved)
	_check(moved > 3.0, "uncoupled, it drives off")
	await _done()


func _scenario_ladderreach() -> void :
	await _wait(1.0)
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var away: = Vector3(1, 0, 0)
	_park(truck, _open_spot(Vector3(-12, 0, -22) + away * 10.0, away, truck), PI / 2)
	player.teleport(_ground(truck.global_position + away * 12.0) + Vector3(0, 0.3, 0))
	await _wait(1.5)
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME + 0.6)
	if not _check(ladder.state == "ready", "the stabilisers go down"):
		await _done()
		return
	ladder.sit(player, false)
	await _wait(0.4)
	_view(truck.global_position + Vector3(50, 25, 60), truck.global_position + Vector3(0, 10, 0))

	Input.action_press("move_right")
	await _wait(3.0)
	Input.action_release("move_right")
	await _wait(0.3)
	print("ladderreach: a turn asked for from flat: raised %.1f°, turned %.1f°; blocked '%s'" % [ladder.elevation, ladder.turned, Text.say(ladder.blocked, "en") if ladder.blocked != null else ""])
	_check(ladder.elevation >= LadderService.CLEAR_ELEVATION - 0.1 and absf(ladder.turned) > 2.0, "asked to turn while flat, it lifts itself clear and turns")

	Input.action_press("move_forward")
	while ladder.elevation < 30.0:
		await _wait(0.1)
	Input.action_release("move_forward")
	Input.action_press("ladder_extend")
	await _wait(9.0)
	Input.action_release("ladder_extend")
	await _wait(0.3)
	print("ladderreach: at 30° run out %.1f of %.1f studs: outreach %.1f of %.1f" % [ladder.extension, ladder._slide, ladder.outreach(), ladder.max_outreach()])
	_check(ladder.outreach() > ladder.max_outreach() - 1.5 or ladder.extension >= ladder._slide - 0.1, "run out to its limit (or all the way)")
	var at_limit: = ladder.outreach() > ladder.max_outreach() - 1.5
	await _snap("at_limit")

	var from: = ladder.elevation
	var out_was: = ladder.extension
	var widest: = 0.0
	Input.action_press("move_back")
	var lowering: = 0.0
	while lowering < 3.0:
		await _wait(0.1)
		lowering += 0.1
		widest = maxf(widest, ladder.outreach())
	Input.action_release("move_back")
	await _wait(0.3)
	print("ladderreach: lowered from %.1f° to %.1f°; run out %.1f -> %.1f; widest %.1f of %.1f" % [from, ladder.elevation, out_was, ladder.extension, widest, ladder.max_outreach()])
	_check(ladder.elevation < from - 10.0, "at its limit the ladder still comes down")
	if at_limit:
		_check(ladder.extension < out_was - 1.0, "sliding itself in as it does")
	_check(widest <= ladder.max_outreach() + 0.05, "never past its outreach")
	await _snap("lowered")
	await _done()


func _scenario_lockermark() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.8)
	var lockers: = Lockers.of(pumper)
	var handle: Dictionary = lockers.handles[0]
	var node: Node3D = handle["node"]
	var out: = node.global_position - pumper.global_position
	out = Vector3(out.x, 0, out.z).normalized()
	player.teleport(_ground(node.global_position + out * 4.0) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	lockers.set_open(handle, true)
	await _wait(1.5)
	var taken: LockerLine = null
	for line in lockers.lines_of(handle):
		if Text.say(line.object, "en").begins_with("Axe") or Text.say(line.object, "en").begins_with("Halligan"):
			taken = line
			break
	if not _check(taken != null, "an axe or a halligan in the menu"):
		await _done()
		return
	lockers.use(player, handle, taken)
	await _wait(0.6)
	_check(taken.holder == player, "taken: the line's thing is out with the player")
	var menu: LockerMenu = Hud.current.widgets["locker"]
	menu.open(player, handle, lockers)
	await _wait(0.5)
	var tags: = menu._rows.find_children("*", "Label", true, false).filter( func(label: Label) -> bool: return label.text == Text.say(Text.m("hud.locker.withYou")))
	print("lockermark: '%s %s' held by the player; %d tag(s) in the menu" % [Text.say(taken.action, "en"), Text.say(taken.object, "en"), tags.size()])
	_check(tags.size() == 1, "the one thing the player has out is tagged as with them")
	_view(player.global_position + Vector3(0, 6, 0) - out * 8.0, node.global_position)
	await _wait(0.3)
	await _snap("menu")
	menu.close()
	await _done()



func _scenario_hazmatlook() -> void :
	await _wait(1.0)
	var leak: = HazmatLeak.current
	var source_id: = "tanks"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--hazmat-source="):
			source_id = arg.split("=")[1]
	leak.forced_source = source_id
	CallService.current.run_call("hazmat", leak.run)
	var waited: = 0.0
	while leak._leak.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	if not _check( not leak._leak.is_empty() and leak._leak["id"] == source_id, "a leak at the %s" % source_id):
		await _done()
		return
	await _wait(2.0)
	var valve: Vector3 = leak._leak["at"]
	var spill: Vector3 = leak._leak["leak"]
	var out: = Vector3(spill.x - valve.x, 0, spill.z - valve.z)
	out = out.normalized() if out.length() > 0.5 else Vector3(1, 0, 0)
	print("hazmatlook: %s: valve at %s, spill at %s, decon at %s" % [source_id, valve, spill, leak._leak["decon"]])
	for layer in get_tree().root.find_children("*", "CanvasLayer", true, false):
		(layer as CanvasLayer).visible = false
	_view(valve + out * 6.5 + out.cross(Vector3.UP) * 2.5 + Vector3(0, 2.5, 0), valve + Vector3(0, 0.8, 0), 55.0)
	await _wait(0.5)
	await _snap("valve_" + source_id)
	_view(valve + out * 22.0 + Vector3(0, 9, 0), valve, 60.0)
	await _wait(0.3)
	await _snap("valve_far_" + source_id)
	_view(valve + out * 3.0 + Vector3(0, 7, 0), valve, 60.0)
	await _wait(0.3)
	await _snap("valve_top_" + source_id)
	var decon: Vector3 = leak._leak["decon"]
	var front: Vector3 = (leak._visual["decon"] as Node3D).global_basis.z * -1.0
	_view(decon + front * 15.0 + front.cross(Vector3.UP) * 6.0 + Vector3(0, 6, 0), decon + Vector3(0, 2.8, 0), 55.0)
	await _wait(0.4)
	await _snap("decon_" + source_id)
	_view(decon - front * 15.0 - front.cross(Vector3.UP) * 6.0 + Vector3(0, 6, 0), decon + Vector3(0, 2.8, 0), 55.0)
	await _wait(0.3)
	await _snap("decon_back_" + source_id)
	var clear: = HazmatLeak.decon_clear(decon, 0.5)
	print("hazmatlook: %s: the decon point's square clear from the ground up: %s" % [source_id, clear])
	await _done()
