extends RefCounted





static func start(main: Node) -> void :
	var lights: = TownLights.new()
	lights.name = "TownLights"
	main.add_child(lights)
	var signals: = TrafficLights.new()
	signals.name = "TrafficLights"
	main.add_child(signals)
	var dressing: = Dressing.new()
	dressing.name = "Dressing"
	main.add_child(dressing)


	var knockdowns: = Knockdowns.new()
	knockdowns.name = "Knockdowns"
	main.add_child(knockdowns)
	var sounds: = TownSounds.new()
	sounds.name = "TownSounds"
	main.add_child(sounds)
	var music: = Soundtrack.new()
	music.name = "Soundtrack"
	main.add_child(music)
