class_name NetTalk
extends Node
















static var current: NetTalk


var pings: Dictionary = {}

var heard: Array = []

var _last: Dictionary = {}
var _shout_until: Dictionary = {}
var _bubbles: Dictionary = {}
var _shouts: Array = []
var _together_at: = -100.0
var _keys_told: = false


func _ready() -> void :
	current = self

	Net.handle("talk.ping", _on_ping)
	Net.handle("talk.radio", _on_radio)
	Net.handle("talk.chat", _on_chat)
	Net.handle("talk.shout", _on_shout)

	Net.handle("talk.ping.show", _show_ping)
	Net.handle("talk.radio.show", _show_radio)
	Net.handle("talk.chat.show", _show_chat)
	Net.handle("talk.shout.show", _show_shout)
	if Hud.current:
		Hud.current.add_widget("ping", HudPing.new())
		Hud.current.add_widget("name_tags", HudNameTags.new())
		Hud.current.add_widget("radio_wheel", HudRadioWheel.new())
		Hud.current.add_widget("chat", HudChat.new())

	Net.peer_joined.connect( func(_player: Player) -> void : _tell_keys())
	Net.stopped.connect( func() -> void :
		pings.clear()
		for peer: int in _shout_until.keys():
			_end_shout(peer)
	)






static func peer_of(player: Player) -> int:
	var peer: = Net.peer_of(player)
	return peer if peer > 0 else (1 if player == Game.local_player else 0)


static func player_of(peer: int) -> Player:
	if Net.active():
		var found: Variant = Net.players.get(peer)
		return found if found != null and is_instance_valid(found) else null
	return Game.local_player if peer == 1 else null



static func colour_of(player: Player) -> Color:
	var colours: Array = Config.Talk.Colours
	var index: = int(player.get_attr("Colour", 0)) if player != null else 0
	return colours[posmod(index, colours.size())]




static func status_of(player: Player) -> Array:
	if player.health <= 0.0:
		return [Text.m("talk.status.down"), Ui.RED]
	if player.get_attr("Distress", false) == true:
		return [Text.m("talk.status.mayday"), Ui.RED]
	if TeamRadio.is_on_air(player):
		return [Text.m("talk.status.onRadio"), Ui.YELLOW]
	if player.health < player.max_health * float(Config.Talk.HurtBelow):
		return [Text.f("talk.status.hurt", ["%d %%" % roundi(player.health / player.max_health * 100.0)]), Ui.AMBER]
	if player.get_attr("Mask", false) == true:
		return [Text.f("talk.status.air", [int(AirService.minutes_left(player))]), Ui.BLUE]
	if player.get_attr("Carrying") != null:
		return [Text.m("talk.status.carrying"), Ui.AMBER]
	if player.get_attr("Line") != null:
		return [Text.m("talk.status.nozzle"), Ui.BLUE]
	var vehicle: Variant = player.get_attr("Vehicle")
	if vehicle is Vehicle:
		return [Text.m("talk.status.driving" if vehicle.driver() == player else "talk.status.riding"), Ui.DIM]
	return [Text.m("talk.status.ready"), Ui.DIM]





func _process(_delta: float) -> void :
	_show_shouts()
	var me: = Game.local_player
	if me == null or me.camera == null or not me.camera.captured or Game.ui_open or me.seat != null or me.health <= 0.0:
		return
	if LadderService.current and LadderService.current.controller == me:
		return
	if Input.is_action_just_pressed("ping") or (Input.is_action_just_pressed("crew_order") and not _ordering()):
		ping()
	if Input.is_action_just_pressed("shout"):
		Net.request("talk.shout")


func _input(event: InputEvent) -> void :

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_MIDDLE and not _ordering():
		var me: = Game.local_player
		if me != null and me.camera != null and me.camera.captured and not Game.ui_open and me.seat == null:
			ping()



func _ordering() -> bool:
	return CrewService.current != null and not CrewService.current.members.is_empty()



func ping() -> void :
	var target: = look(Game.local_player)
	if not target.is_empty():
		Net.request("talk.ping", [target["kind"], target["label"], target["position"]])





static func look(me: Player) -> Dictionary:
	if me == null or me.camera == null:
		return {}
	var eye: = me.camera.camera
	var view: = {"from": eye.global_position, "along": - eye.global_basis.z}
	var best: Player = null
	var best_off: = 2.5
	for other in Game.players:
		if other == me or not is_instance_valid(other) or other.brain != null or other.seat != null:
			continue
		var off: = CrewTargets.off_sight(view, other.global_position + Vector3(0, 3, 0))
		if off < best_off and other.global_position.distance_to(view["from"]) < 80.0:
			best_off = off
			best = other
	if best != null:
		return {"kind": "player", "label": best.display_name, "position": best.global_position + Vector3(0, 6.5, 0)}
	var found: Dictionary = CrewTargets.look(me) if CrewService.current != null else {}
	var kind: String = found.get("kind", "")
	if not found.is_empty() and kind != "ground" and kind != "ask":
		var label: Variant = found["label"]
		if kind == "door" and label is Dictionary and label.get("k", "") == "crew.targets.lockedDoor":
			kind = "lockedDoor"
		if Text.has("talk.ping." + kind):
			label = Text.m("talk.ping." + kind)
		return {"kind": kind, "label": label, "position": found["position"]}
	var hit: = Game.world.raycast(view["from"], view["from"] + view["along"] * float(Config.Talk.PingReach), World.LAYER_SOLID | World.LAYER_VEHICLE, [me.get_rid()])
	if hit.is_empty():
		return {}
	return {"kind": "here", "label": Text.m("talk.ping.here"), "position": hit["position"] + Vector3(0, 1.0, 0)}






func _allowed(player: Player, kind: String, every: float) -> bool:
	var key: = "%d:%s" % [player.get_instance_id(), kind]
	if Game.now() - float(_last.get(key, -100.0)) < every:
		return false
	_last[key] = Game.now()
	return true



func _spread(event: String, args: Array, show: Callable) -> void :
	show.callv(args)
	Net.broadcast(event, args)


func _on_ping(player: Player, kind: String, label: Variant, at: Vector3) -> void :
	if not _allowed(player, "ping", float(Config.Talk.PingEvery)):
		return
	if at.distance_to(player.global_position) > float(Config.Talk.PingReach) + 10.0:
		return
	if label is String:
		label = label.left(40)
	elif not label is Dictionary:
		return
	_spread("talk.ping.show", [peer_of(player), kind.left(16), label, at], _show_ping)


func _on_radio(player: Player, line: String) -> void :
	if not line in Config.Talk.RadioLines or not _allowed(player, "radio", float(Config.Talk.RadioEvery)):
		return
	_spread("talk.radio.show", [peer_of(player), line], _show_radio)


func _on_chat(player: Player, text: String) -> void :
	text = text.strip_edges().left(int(Config.Talk.ChatMax))
	if text.is_empty() or not _allowed(player, "chat", float(Config.Talk.ChatEvery)):
		return
	_spread("talk.chat.show", [peer_of(player), text], _show_chat)


func _on_shout(player: Player) -> void :
	if player.health <= 0.0 or not _allowed(player, "shout", float(Config.Talk.ShoutEvery)):
		return
	_spread("talk.shout.show", [peer_of(player)], _show_shout)





func _name(peer: int) -> String:
	var who: = player_of(peer)
	return who.display_name if who != null else "?"


func _hear(kind: String, peer: int, words: Variant) -> void :
	var said: = Text.say(words, "en")
	heard.append([kind, _name(peer), said])
	print("talk [%s] %s: %s" % [kind, _name(peer), said])


func _say(text: Variant, kind: = "info") -> void :
	if Hud.current and Hud.current.messages:
		Hud.current.messages.show_message(text, kind)


func _show_ping(peer: int, kind: String, label: Variant, at: Vector3) -> void :
	var who: = player_of(peer)
	pings[peer] = {
		"kind": kind, "label": label, "at": at, "since": Game.now(), "until": Game.now() + float(Config.Talk.PingTime), 
		"name": _name(peer), "colour": colour_of(who) if who != null else Ui.TEXT, 
	}
	Sounds.ui(str(Config.Talk.PingSound), float(Config.Talk.PingPitch))
	_hear("ping", peer, label)


func _show_radio(peer: int, line: String) -> void :
	var words: = Text.m("talk.radio." + line)
	_say(Text.f("talk.radioSaid", [_name(peer), words]), "warning" if line == "getOut" else "info")
	Sounds.ui("ui_squelch")
	_hear("radio", peer, words)


func _show_chat(peer: int, text: String) -> void :
	_say(Text.f("talk.said", [_name(peer), text]))
	Sounds.ui("ui_tick")
	_hear("chat", peer, text)


func _show_shout(peer: int) -> void :
	var who: = player_of(peer)
	if who == null:
		return
	var now: = Game.now()
	_shout_until[peer] = now + float(Config.Talk.ShoutTime)
	if not _bubbles.has(peer) or not is_instance_valid(_bubbles[peer]):
		var bubble: = Label3D.new()
		bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		bubble.pixel_size = 0.012
		bubble.font = Ui.world_display_font()
		bubble.font_size = 64
		bubble.outline_size = 16
		bubble.outline_modulate = Color(0.08, 0.09, 0.11)
		bubble.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
		add_child(bubble)
		_bubbles[peer] = bubble
	var label: Label3D = _bubbles[peer]
	label.text = Text.say(Text.m("talk.shout"))
	label.modulate = colour_of(who)
	label.visible = true
	_say(Text.f("talk.shoutSaid", [who.display_name]), "good")
	Sounds.ui(str(Config.Talk.ShoutSound), float(Config.Talk.ShoutPitch), float(Config.Talk.ShoutVolume))
	_hear("shout", peer, Text.m("talk.shout"))

	var window: = float(Config.Talk.TogetherWindow)
	_shouts = _shouts.filter( func(entry: Array) -> bool: return now - float(entry[1]) <= window and entry[0] != peer)
	_shouts.append([peer, now])
	if _shouts.size() >= 2 and now - _together_at > window:
		_together_at = now
		_say(Text.m("talk.together"), "good")
		Sounds.ui("ui_fanfare")
		_hear("together", peer, Text.m("talk.together"))



func _show_shouts() -> void :
	if _shout_until.is_empty():
		return
	var now: = Game.now()
	var shown: = float(Config.Talk.ShoutTime)
	for peer: int in _shout_until.keys():
		var who: = player_of(peer)
		var left: float = _shout_until[peer] - now
		if who == null or left <= 0.0:
			_end_shout(peer)
			continue
		var label: Label3D = _bubbles.get(peer)
		if label != null and is_instance_valid(label):
			label.global_position = who.head_position() + Vector3(0, 3.8, 0)
			label.modulate.a = clampf(left * 3.0, 0.0, 1.0)
			label.outline_modulate.a = label.modulate.a
		if who.rig != null:
			var up: = clampf((shown - left) * 6.0, 0.0, 1.0) * clampf(left * 4.0, 0.0, 1.0)
			who.rig.extras["shout"] = {"ShoulderL": Vector3(deg_to_rad(float(Config.Talk.ShoutArm)) * up, 0, 0)}


func _end_shout(peer: int) -> void :
	_shout_until.erase(peer)
	var label: Variant = _bubbles.get(peer)
	if label != null and is_instance_valid(label):
		label.visible = false
	var who: = player_of(peer)
	if who != null and who.rig != null:
		who.rig.extras.erase("shout")



func _tell_keys() -> void :
	if _keys_told or not bool(Config.Talk.KeysHint):
		return
	_keys_told = true
	_say(Text.f("talk.keys", [Controls.key_name("ping"), Controls.key_name("radio"), Controls.key_name("chat"), Controls.key_name("shout"), Controls.key_name("talk")]))
