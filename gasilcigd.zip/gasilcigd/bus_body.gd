class_name BusBody
extends RefCounted










const SIZE: = Vector3(9.6, 12.9, 47)
const FRONT: = -23.5
const BACK: = 23.5

const FRONT_AXLE: = -13.5
const REAR_AXLE: = 10.5
const WHEEL: = 1.95
const ARCH: = 2.8
const SILL: = 1.0
const ARCH_TOP: = 4.7
const BELT: = 5.6
const EAVE: = 10.0
const ROOF: = 11.9


static var RAKE: float = float(Edition.data().get("coach", {}).get("rake", 1.4))


static var TRANSIT: bool = bool(Edition.data().get("coach", {}).get("transit", false))


static var RACK: bool = bool(Edition.data().get("coach", {}).get("rack", TRANSIT))

const GLASS: = Color8(38, 48, 60)
const TYRE: = Color8(26, 26, 28)
const DARK: = Color8(34, 36, 40)
const TRIM: = Color8(150, 154, 160)
const LAMP: = Color8(210, 210, 200)
const TAIL: = Color8(96, 20, 18)
const BLINK: = Color8(120, 84, 20)




const LIVERIES: Array = [
	{"body": Color8(226, 224, 216), "band": Color8(74, 96, 122)}, 
	{"body": Color8(196, 200, 202), "band": Color8(62, 84, 74)}, 
	{"body": Color8(222, 214, 192), "band": Color8(128, 62, 52)}, 
	{"body": Color8(232, 230, 224), "band": Color8(96, 100, 104)}, 
	{"body": Color8(176, 190, 200), "band": Color8(44, 58, 84)}, 
	{"body": Color8(236, 232, 222), "band": Color8(60, 108, 112)}, 
]


static var _liveries: Array = _own_liveries()
static var _bodies: Dictionary = {}
static var _paint: ShaderMaterial


static func _add(list: Array, piece_name: String, size: Vector3, cframe: Transform3D, tint: Color, material: = "Metal", extra: = {}) -> void :
	var piece: = {"name": piece_name, "size": size, "cframe": cframe, "color": tint, "material": material}
	piece.merge(extra)
	list.append(piece)


static func _own_liveries() -> Array:
	var out: Array = []
	for entry: Variant in Edition.data().get("coach", {}).get("liveries", []):
		if entry is Dictionary and entry.has("body") and entry.has("band"):
			var b: Array = entry["body"]
			var n: Array = entry["band"]
			out.append({"body": Color8(int(b[0]), int(b[1]), int(b[2])), "band": Color8(int(n[0]), int(n[1]), int(n[2]))})
	return out if not out.is_empty() else LIVERIES



static func _coach(key: String, index: int, fallback: String) -> String:
	var list: Array = Edition.data().get("coach", {}).get(key, [])
	return fallback if list.is_empty() else str(list[posmod(index, list.size())])



static func pieces(color: = 1, parked: = false) -> Array:
	var index: = posmod(color - 1, _liveries.size())
	var livery: Dictionary = _liveries[index]
	var body: Color = livery["body"]
	var band: Color = livery["band"]
	var plate: = _coach("plates", index, "NM AV-210")
	var to: = _coach("destinations", index, "Novo mesto")
	if parked:
		to = str(Edition.data().get("coach", {}).get("standing", "Metlika"))
	var list: Array = []
	var half: = SIZE.x / 2.0
	var wide: = SIZE.x
	var cab: = FRONT + RAKE



	var cuts: Array = [FRONT, FRONT_AXLE - ARCH, FRONT_AXLE + ARCH, REAR_AXLE - ARCH, REAR_AXLE + ARCH, BACK]
	for i in range(0, cuts.size(), 2):
		var a: float = cuts[i]
		var b: float = cuts[i + 1]
		_add(list, "BusSide", Vector3(wide, ARCH_TOP - SILL, b - a), Rbx.at(0, (SILL + ARCH_TOP) / 2.0, (a + b) / 2.0), body)
		_add(list, "BusRubbing", Vector3(wide + 0.08, 0.6, b - a), Rbx.at(0, SILL + 0.3, (a + b) / 2.0), DARK, "SmoothPlastic")
	_add(list, "BusSide", Vector3(wide, BELT - ARCH_TOP, BACK - FRONT), Rbx.at(0, (ARCH_TOP + BELT) / 2.0, 0), body)
	_add(list, "BusBand", Vector3(wide + 0.06, 0.45, BACK - FRONT - 0.1), Rbx.at(0, BELT - 0.3, 0), band, "SmoothPlastic")
	if TRANSIT:
		for i in range(0, cuts.size(), 2):
			var a: float = cuts[i]
			var b: float = cuts[i + 1]
			_add(list, "BusStripe", Vector3(wide + 0.07, 0.8, b - a - 0.1), Rbx.at(0, ARCH_TOP - 1.3, (a + b) / 2.0), band, "SmoothPlastic")
		_add(list, "BusStripe", Vector3(wide - 0.4, 0.8, 0.08), Rbx.at(0, ARCH_TOP - 1.3, FRONT - 0.02), band, "SmoothPlastic")
	for axle: float in [FRONT_AXLE, REAR_AXLE]:
		_add(list, "BusWell", Vector3(wide - 3.0, ARCH_TOP - SILL, ARCH * 2.0), Rbx.at(0, (SILL + ARCH_TOP) / 2.0, axle), DARK, "SmoothPlastic")
		_add(list, "BusArch", Vector3(wide, 1.4, 1.4), Rbx.at(0, ARCH_TOP - 0.7, axle - ARCH + 0.7) * Rbx.angles(PI, 0, 0), body, "Metal", 
			{"shape": "wedge"})
		_add(list, "BusArch", Vector3(wide, 1.4, 1.4), Rbx.at(0, ARCH_TOP - 0.7, axle + ARCH - 0.7) * Rbx.angles(0, 0, PI), body, "Metal", 
			{"shape": "wedge"})



	_add(list, "BusGlass", Vector3(wide - 0.1, EAVE - BELT, BACK - cab - 0.2), Rbx.at(0, (BELT + EAVE) / 2.0, (cab + BACK - 0.2) / 2.0), GLASS, "Glass")
	for z: float in [-17.6, -12.3, -7.0, -2.2, 2.8, 8.0, 13.2, 18.4, BACK - 0.6]:
		_add(list, "BusPillar", Vector3(wide + 0.02, EAVE - BELT, 0.4 if z < BACK - 1.0 else 1.0), Rbx.at(0, (BELT + EAVE) / 2.0, z), DARK)
	_add(list, "BusRoof", Vector3(wide, ROOF - EAVE, BACK - cab + 0.1), Rbx.at(0, (EAVE + ROOF) / 2.0, (cab - 0.1 + BACK) / 2.0), body)
	_add(list, "BusCrown", Vector3(wide - 1.2, 0.4, BACK - cab - 1.2), Rbx.at(0, ROOF + 0.2, (cab + BACK) / 2.0), body)
	_add(list, "BusCooler", Vector3(7.0, 0.6, 11.0), Rbx.at(0, ROOF + 0.7, -3.0), Color8(208, 210, 208))
	_add(list, "BusCoolerGrille", Vector3(5.6, 0.1, 9.0), Rbx.at(0, ROOF + 1.02, -3.0), DARK, "DiamondPlate")
	for z: float in [-14.5, 9.0]:
		_add(list, "BusHatch", Vector3(2.6, 0.25, 2.6), Rbx.at(0, ROOF + 0.45, z), Color8(196, 198, 196))




	var lean: = atan2(RAKE, EAVE - BELT)
	_add(list, "BusScreen", Vector3(wide - 0.2, EAVE - BELT, RAKE), Rbx.at(0, (BELT + EAVE) / 2.0, FRONT + RAKE / 2.0), GLASS, "Glass", 
		{"shape": "wedge"})
	for side: float in [-1.0, 1.0]:
		_add(list, "BusScreenPost", Vector3(0.3, (EAVE - BELT) / cos(lean), 0.3), Rbx.at(side * (half - 0.15), (BELT + EAVE) / 2.0, FRONT + RAKE / 2.0 - 0.05) * Rbx.angles(lean, 0, 0), DARK)
		_add(list, "BusWiper", Vector3(3.0, 0.12, 0.1), Rbx.at(side * 1.9, BELT + 0.35, FRONT + 0.06) * Rbx.angles(lean, 0, deg_to_rad(side * 7.0)), DARK)
	_add(list, "BusVisor", Vector3(wide, ROOF - EAVE + 0.1, 0.5), Rbx.at(0, (EAVE + ROOF) / 2.0, cab - 0.15), body)
	_add(list, "BusBlind", Vector3(7.4, 1.1, 0.1), Rbx.at(0, EAVE + 0.95, cab - 0.42), Color8(18, 18, 20), "SmoothPlastic", 
		{"text": to, "face": "front"})
	for side: float in [-1.0, 1.0]:
		_add(list, "BusLampSurround", Vector3(3.0, 1.1, 0.08), Rbx.at(side * 2.9, 3.1, FRONT - 0.03), DARK, "SmoothPlastic")
	_add(list, "BusGrille", Vector3(2.4, 0.9, 0.1), Rbx.at(0, 3.1, FRONT - 0.04), DARK, "DiamondPlate")
	_add(list, "BusGrille", Vector3(6.4, 0.3, 0.1), Rbx.at(0, 4.4, FRONT - 0.04), DARK, "DiamondPlate")
	_add(list, "BusBumper", Vector3(wide + 0.2, 1.3, 0.6), Rbx.at(0, SILL + 0.65, FRONT - 0.15), DARK, "SmoothPlastic")
	_add(list, "BusPlate", Vector3(2.2, 0.5, 0.1), Rbx.at(0, SILL + 0.65, FRONT - 0.5), Color8(240, 240, 236), "SmoothPlastic", 
		{"text": plate, "face": "front"})
	if RACK:

		for x: float in [-2.4, 2.4]:
			_add(list, "BusRack", Vector3(0.18, 2.3, 0.18), Rbx.at(x, SILL + 2.05, FRONT - 0.75), DARK)
			_add(list, "BusRack", Vector3(0.18, 0.18, 0.7), Rbx.at(x, SILL + 1.0, FRONT - 0.45), DARK)
		for y: float in [SILL + 1.0, SILL + 3.15]:
			_add(list, "BusRack", Vector3(5.0, 0.16, 0.16), Rbx.at(0, y, FRONT - 0.75), DARK)
	var droop: = atan2(1.0, 2.2)
	for side: float in [-1.0, 1.0]:
		_add(list, "BusMirrorArm", Vector3(0.18, 0.18, 2.5), Rbx.at(side * (half + 0.2), EAVE + 0.3, FRONT + 0.1) * Rbx.angles( - droop, 0, 0), DARK)
		_add(list, "BusMirror", Vector3(0.35, 1.7, 0.8), Rbx.at(side * (half + 0.3), EAVE - 1.0, FRONT - 1.1), DARK, "SmoothPlastic")



	_add(list, "BusRearGlass", Vector3(7.0, 2.2, 0.1), Rbx.at(0, 8.7, BACK + 0.04), GLASS, "Glass")
	_add(list, "BusBlind", Vector3(4.4, 0.8, 0.1), Rbx.at(0, EAVE + 0.95, BACK + 0.04), Color8(18, 18, 20), "SmoothPlastic", 
		{"text": to, "face": "back"})
	_add(list, "BusEngineCover", Vector3(8.0, 4.4, 0.06), Rbx.at(0, 4.9, BACK + 0.03), body.lerp(DARK, 0.18))
	_add(list, "BusEngineGrille", Vector3(6.6, 2.4, 0.08), Rbx.at(0, 5.2, BACK + 0.06), DARK, "DiamondPlate")
	for i in 5:
		_add(list, "BusLouvre", Vector3(6.6, 0.16, 0.16), Rbx.at(0, 4.2 + i * 0.5, BACK + 0.1), body.lerp(DARK, 0.35))
	_add(list, "BusBumper", Vector3(wide + 0.2, 1.4, 0.6), Rbx.at(0, SILL + 0.7, BACK + 0.15), DARK, "SmoothPlastic")
	_add(list, "BusPlate", Vector3(2.2, 0.5, 0.1), Rbx.at(0, SILL + 0.75, BACK + 0.5), Color8(240, 240, 236), "SmoothPlastic", 
		{"text": plate, "face": "back"})
	_add(list, "BusExhaust", Vector3(0.9, 0.35, 0.35), Rbx.at(-3.4, SILL - 0.1, BACK + 0.2) * Rbx.angles(0, deg_to_rad(90.0), 0), TRIM, "Metal", 
		{"shape": "cylinder"})



	for door: Vector2 in [Vector2(-19.9, 4.2), Vector2(0.3, 4.6)]:
		var z: = door.x
		_add(list, "BusDoor", Vector3(0.14, EAVE - SILL - 0.3, door.y), Rbx.at(half + 0.03, (SILL + 0.3 + EAVE) / 2.0, z), DARK, "SmoothPlastic")
		for leaf: float in [-1.0, 1.0]:
			_add(list, "BusDoorGlass", Vector3(0.1, EAVE - SILL - 1.4, door.y / 2.0 - 0.35), Rbx.at(half + 0.09, (SILL + EAVE) / 2.0 + 0.35, z + leaf * door.y / 4.0), Color8(70, 92, 110), "Glass")
		_add(list, "BusStep", Vector3(0.3, 0.2, door.y), Rbx.at(half + 0.1, SILL + 0.3, z), TRIM, "DiamondPlate")
	_add(list, "BusBlind", Vector3(0.1, 0.8, 4.0), Rbx.at(half + 0.04, EAVE - 0.65, -14.9), Color8(18, 18, 20), "SmoothPlastic", 
		{"text": to, "face": "right"})


	_add(list, "BusDriverGlass", Vector3(0.1, EAVE - BELT - 0.6, 3.8), Rbx.at( - half - 0.04, (BELT + EAVE) / 2.0, -19.8), Color8(70, 92, 110), "Glass")
	_add(list, "BusFlap", Vector3(0.08, 0.9, 1.4), Rbx.at( - half - 0.03, 3.4, -5.5), body.lerp(DARK, 0.15))
	for z: float in ([] if TRANSIT else [-8.5, -1.5, 5.5]):
		_add(list, "BusSeam", Vector3(0.06, ARCH_TOP - SILL - 1.0, 0.1), Rbx.at( - half - 0.02, (SILL + ARCH_TOP) / 2.0 + 0.3, z), body.lerp(DARK, 0.5))
	_add(list, "BusIntake", Vector3(0.1, EAVE - BELT - 0.8, 4.6), Rbx.at( - half - 0.04, (BELT + EAVE) / 2.0, 21.0), body.lerp(DARK, 0.55), "DiamondPlate")


	for z: float in [FRONT_AXLE, REAR_AXLE]:
		var twin: = z > 0.0
		for side: float in [-1.0, 1.0]:
			_add(list, "Wheel", Vector3(1.3, WHEEL * 2.0, WHEEL * 2.0), Rbx.at(side * (half - 0.75), WHEEL, z), TYRE, "Rubber", {"shape": "cylinder"})
			_add(list, "WheelRim", Vector3(0.12, 2.4, 2.4), Rbx.at(side * (half - (0.2 if twin else 0.06)), WHEEL, z), TRIM.lerp(DARK, 0.3) if twin else TRIM, "Metal", {"shape": "cylinder"})
			_add(list, "WheelHub", Vector3(0.14, 0.9, 0.9), Rbx.at(side * (half - (0.14 if twin else 0.0)), WHEEL, z), DARK, "Metal", {"shape": "cylinder"})



	for side: float in [-1.0, 1.0]:
		_add(list, "Headlamp", Vector3(1.3, 0.7, 0.2), Rbx.at(side * 3.6, 3.1, FRONT - 0.08), LAMP, "SmoothPlastic", {"lamp": "head", "beam": true})
		_add(list, "Headlamp", Vector3(0.9, 0.7, 0.2), Rbx.at(side * 2.35, 3.1, FRONT - 0.08), LAMP, "SmoothPlastic", {"lamp": "head"})
		_add(list, "TailLamp", Vector3(0.8, 2.4, 0.2), Rbx.at(side * 4.2, 4.3, BACK + 0.08), TAIL, "SmoothPlastic", {"lamp": "tail"})
		_add(list, "TailLamp", Vector3(1.4, 0.3, 0.2), Rbx.at(side * 3.0, EAVE + 1.0, BACK + 0.08), TAIL, "SmoothPlastic", {"lamp": "tail"})
		_add(list, "Indicator", Vector3(0.5, 0.6, 0.2), Rbx.at(side * 4.45, 3.1, FRONT - 0.08), BLINK, "SmoothPlastic", {"lamp": "blink"})
		_add(list, "Indicator", Vector3(0.8, 0.6, 0.2), Rbx.at(side * 4.2, 6.0, BACK + 0.08), BLINK, "SmoothPlastic", {"lamp": "blink"})
		_add(list, "Indicator", Vector3(0.12, 0.35, 0.7), Rbx.at(side * (half + 0.04), 4.1, FRONT_AXLE - ARCH - 1.0), BLINK, "SmoothPlastic", {"lamp": "blink"})
		_add(list, "BusMarker", Vector3(0.5, 0.2, 0.14), Rbx.at(side * 3.9, ROOF - 0.3, cab - 0.42), Color8(240, 200, 120), "SmoothPlastic")
	return list



static func stretch(piece: Dictionary) -> Transform3D:
	var size: Vector3 = piece["size"]
	if piece.get("shape", "") == "cylinder":
		size = Vector3(size.x, minf(size.y, size.z), minf(size.y, size.z))
	return piece["cframe"] * Transform3D(Basis.from_scale(size), Vector3.ZERO)


static func unit(piece: Dictionary) -> Mesh:
	match piece.get("shape", ""):
		"cylinder":
			return World.unit_mesh(PartStore.Shape.CYLINDER)
		"wedge":
			return World.unit_mesh(PartStore.Shape.WEDGE)
	return World.unit_mesh(PartStore.Shape.BLOCK)




static func body_mesh(color: int) -> ArrayMesh:
	var livery: = posmod(color - 1, _liveries.size())
	if _bodies.has(livery):
		return _bodies[livery]
	_bodies[livery] = merged(pieces(color))
	return _bodies[livery]




static func merged(list: Array) -> ArrayMesh:
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var colors: = PackedColorArray()
	var indices: = PackedInt32Array()
	for piece: Dictionary in list:
		if piece.has("lamp") or piece.has("beacon"):
			continue
		var arrays: = unit(piece).surface_get_arrays(0)
		var place: = stretch(piece)
		var normal_basis: = place.basis.inverse().transposed()
		var first: = vertices.size()
		var source: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var source_normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
		for i in source.size():
			vertices.append(place * source[i])
			normals.append((normal_basis * source_normals[i]).normalized())
			var tint: Color = piece["color"]

			var alpha: = 1.0
			if piece["material"] == "Glass":
				alpha = 0.5
			elif piece["material"] in ["Rubber", "Fabric"]:
				alpha = 0.85
			colors.append(Color(tint.r, tint.g, tint.b, alpha))

		if arrays[Mesh.ARRAY_INDEX] == null:
			for i in source.size():
				indices.append(first + i)
		else:
			var source_indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
			for i in source_indices:
				indices.append(first + i)
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


static func paint() -> ShaderMaterial:
	if _paint == null:
		_paint = ShaderMaterial.new()
		_paint.shader = load("res://shaders/bus_paint.gdshader")
	return _paint



static func letter(piece: Dictionary) -> Label3D:
	var size: Vector3 = piece["size"]
	var label: = Label3D.new()
	label.text = piece["text"]
	label.font_size = 64
	label.outline_size = 0
	var blind: bool = piece["name"] == "BusBlind"
	label.modulate = Color8(255, 176, 40) if blind else Color8(24, 24, 28)
	label.shaded = not blind
	label.double_sided = false
	var across: = size.x
	var out: = Vector3.ZERO
	var turn: = Basis.IDENTITY
	match piece["face"]:
		"front":
			out = Vector3(0, 0, - size.z / 2.0 - 0.02)
			turn = Basis(Vector3.UP, PI)
		"back":
			out = Vector3(0, 0, size.z / 2.0 + 0.02)
		"right":
			out = Vector3(size.x / 2.0 + 0.02, 0, 0)
			turn = Basis(Vector3.UP, PI / 2.0)
			across = size.z

	var text: String = piece["text"]
	label.pixel_size = minf(size.y * 0.7 / 64.0, across * 0.92 / (maxf(text.length(), 1.0) * 40.0))
	var cframe: Transform3D = piece["cframe"]
	label.transform = cframe * Transform3D(turn, out)
	return label
