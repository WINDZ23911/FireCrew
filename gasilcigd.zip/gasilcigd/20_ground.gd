extends RefCounted





const SOFT: = ["meadow", "field", "verge", "scrub", "orchard", "park", "forest"]


static func apply(kit: PolishKit) -> String:
	if not Ground.painted():
		return ""
	var store: = kit.store
	var hidden: = 0
	for row in kit.rows_under("Map/Surfaces"):
		if store.name_at(row) in SOFT:
			store.set_transparency(row, 1.0)
			hidden += 1
	var map: = kit.folder("Map")
	for row in store.rows_under.get(map, PackedInt32Array()):
		if store.name_at(row) == "Ground":
			Ground.top = maxf(Ground.top, store.position(row).y + store.size(row).y / 2.0)
			store.set_transparency(row, 1.0)
			hidden += 1
	return "%d ground pieces painted over" % hidden
