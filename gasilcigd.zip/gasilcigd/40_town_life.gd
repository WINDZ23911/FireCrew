extends RefCounted






static func start(main: Node) -> void :
	var began: = Time.get_ticks_msec()
	var layout: Dictionary = Rbx.module("TownLayout")
	var graph: = NavGraph.build(layout)
	NavGraph.current = graph

	var life: = Node3D.new()
	life.name = "TownLife"

	life.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	main.add_child(life)


	var clock: = HostClock.new()
	clock.name = "HostClock"
	life.add_child(clock)

	var debug: = TownLifeDebug.new()
	debug.name = "TownLifeDebug"
	if OS.get_cmdline_user_args().has("--life-off"):

		life.add_child(debug)
		return

	var parked: = ParkedCars.new()
	parked.name = "ParkedCars"
	life.add_child(parked)
	parked.start()


	var pedestrians: = Pedestrians.new()
	pedestrians.name = "Pedestrians"
	life.add_child(pedestrians)
	pedestrians.start(graph)
	var townsfolk: = Townsfolk.new()
	townsfolk.name = "Townsfolk"
	life.add_child(townsfolk)
	townsfolk.start(pedestrians)

	var traffic: = Traffic.new()
	traffic.name = "Traffic"
	life.add_child(traffic)
	traffic.start(graph)
	var view: = TrafficView.new()
	view.name = "TrafficView"
	life.add_child(view)
	view.start(traffic)

	life.add_child(debug)
	print("town life: %d lanes and turns, %d footway points, %d places, %d people, %d vehicles, %d parked cars in %d ms" % [
		graph.segments.size(), graph.walk.size(), graph.places.size(), pedestrians.count, traffic.vehicles.size(), 
		parked.cars.size(), Time.get_ticks_msec() - began, 
	])
