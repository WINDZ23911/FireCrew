class_name Thunder
extends Node3D




const HEAVY: = 0.7
const GAP: = Vector2(14.0, 40.0)
const SOUND_SPEED: = 1200.0
const FLICKER: = [[0.0, 1.0], [0.07, 0.15], [0.13, 0.85], [0.22, 0.1], [0.3, 0.5], [0.45, 0.0]]

var _next: = 0.0
var _flash: DirectionalLight3D
var _flash_started: = -100.0
var _strength: = 0.0
var _trace: = false
var _gap: = GAP


func _ready() -> void :
	_trace = OS.get_cmdline_user_args().has("--sound-trace")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--strike-every="):
			_gap = Vector2.ONE * float(arg.substr(15))

	_flash = DirectionalLight3D.new()
	_flash.light_color = Color(0.82, 0.86, 1.0)
	_flash.light_energy = 0.0
	_flash.shadow_enabled = false
	_flash.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	_flash.rotation = Vector3(deg_to_rad(-70.0), deg_to_rad(30.0), 0.0)
	add_child(_flash)
	_next = Game.now() + randf_range(_gap.x, _gap.y) * 0.5


func _process(_delta: float) -> void :
	var weather: = Weather.current
	var raining: = weather != null and weather.rain >= HEAVY
	var age: = Game.now() - _flash_started
	_flash_light(age)
	if not raining:
		_next = maxf(_next, Game.now() + _gap.x * 0.5)
		return
	if Game.now() < _next:
		return
	_next = Game.now() + randf_range(_gap.x, _gap.y)
	_strike()


func _strike() -> void :
	var camera: = get_viewport().get_camera_3d()
	var from: = camera.global_position if camera else Vector3.ZERO
	var distance: = randf_range(500.0, 3200.0)
	var bearing: = randf() * TAU
	var where: = from + Vector3(sin(bearing), 0.0, cos(bearing)) * distance + Vector3(0, 300.0, 0)
	_strength = clampf(1.4 - distance / 3200.0, 0.35, 1.0)
	_flash_started = Game.now()
	_flash.rotation = Vector3(deg_to_rad(randf_range(-80.0, -50.0)), bearing + PI, 0.0)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--strike-shot="):
			await get_tree().process_frame
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png(arg.substr(14).replace(".png", "_%d.png" % int(Game.now())))
	var delay: = distance / SOUND_SPEED
	var voice: = "thunder_1" if distance < 1200.0 else "thunder_2"
	var volume: = clampf(1.6 - distance / 2600.0, 0.35, 1.3)
	if _trace:
		print("sound: lightning %.0f studs off, thunder in %.1f s (%s)" % [distance, delay, voice])
	await get_tree().create_timer(delay, false).timeout
	if is_inside_tree():
		Sounds.flat(voice, volume)



func _flash_light(age: float) -> void :
	var level: = 0.0
	if age >= 0.0 and age < 0.45:
		for index in FLICKER.size() - 1:
			var a: Array = FLICKER[index]
			var b: Array = FLICKER[index + 1]
			if age >= a[0] and age < b[0]:
				level = lerpf(a[1], b[1], (age - a[0]) / (b[0] - a[0]))
				break
	level *= _strength
	var sky: = Sky3D.current

	var dark: = 1.0 - (sky.daylight() if sky else 1.0)
	_flash.light_energy = (0.9 + 1.8 * dark) * level
	_flash.visible = level > 0.001
	if sky and sky.environment:
		sky.environment.background_energy_multiplier = 1.0 + (1.0 + 2.5 * dark) * level
