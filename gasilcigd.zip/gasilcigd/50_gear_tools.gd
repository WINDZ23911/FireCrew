extends RefCounted




static func start(main: Node) -> void :
	var gear: = GearService.new()
	gear.name = "Gear"
	main.add_child(gear)

	for vehicle in Vehicle.all:
		Lockers.of(vehicle)
	Lockers.share()
	var air: = AirService.new()
	air.name = "Air"
	main.add_child(air)
	var tools: = ToolService.new()
	tools.name = "Tools"
	main.add_child(tools)

	var hud: = Hud.current
	if hud != null:
		hud.add_widget("thermal", Thermal.new())
		hud.add_widget("gear", GearHud.new())
		hud.add_widget("hotbar", Hotbar.new())
		hud.add_widget("wardrobe", WardrobeMenu.new())
		hud.add_widget("training", TrainingBoard.new())
		var menu: = LockerMenu.new()
		hud.add_widget("locker", menu)
		for vehicle in Vehicle.all:
			var lockers: = Lockers.of(vehicle)
			if lockers != null:
				menu.watch(lockers)

	var debug: = GearDebug.new()
	debug.name = "GearDebug"
	main.add_child(debug)
	var tools_debug: = ToolsDebug.new()
	tools_debug.name = "ToolsDebug"
	main.add_child(tools_debug)
