extends RefCounted














const STOREY: = 13.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var shells: Array = []
	for model in kit.models_under("Map/Buildings"):
		var by_name: Dictionary = {}
		for row in store.rows_in(model):
			var part_name: = store.name_at(row)
			if not by_name.has(part_name):
				by_name[part_name] = []
			by_name[part_name].append(row)
		if not by_name.has("Body"):
			continue
		var body: int = by_name["Body"][0]
		var size: = store.size(body)
		var body_place: = store.transform(body)
		var place: = Transform3D(body_place.basis.orthonormalized(), body_place.origin - Vector3(0, size.y / 2.0, 0))
		var slopes: Array = []
		var hipped: = false
		var flat_roof: = -1
		for row: int in by_name.get("Roof", []):
			match store.shape(row):
				PartStore.Shape.WEDGE:
					slopes.append(row)
				PartStore.Shape.CORNER_WEDGE:
					hipped = true
				PartStore.Shape.BLOCK:
					flat_roof = row
		var roof_color: = store.color(slopes[0]) if not slopes.is_empty() else (store.color(flat_roof) if flat_roof >= 0 else Color.GRAY)
		shells.append({
			"model": model, "place": place, "width": size.x, "depth": size.z, "height": size.y, 
			"wall": store.color(body), "roof": roof_color, 
			"pitched": not slopes.is_empty(), "slopes": slopes, "hipped": hipped, "flat_roof": flat_roof, 
			"homely": by_name.has("GlazingBar"), "balconies": by_name.has("BalconyRail"), 
			"rows": by_name, 
		})
	kit.set_meta("shells", shells)
	return ""



static func at(shell: Dictionary, local: Vector3) -> Vector3:
	var place: Transform3D = shell["place"]
	return place * local



static func local_of(shell: Dictionary, world: Transform3D) -> Transform3D:
	var place: Transform3D = shell["place"]
	return place.affine_inverse() * world
