class_name Townsfolk
extends Node3D














const STRIDE: = 1.25
const SWING: = 0.7
const GROUND_EVERY: = 0.3
const ROOM: = 4.0
const BERTH: = 2.5
const HEAD_TURN: = deg_to_rad(75.0)
const ARMS_UP: = 2.5
const SEAT_TOP: = 1.85
const CHATTING: = {"raise": 0.9, "time": 1.5, "every": 4.0}



const POINTING: = {"raise": 1.45, "time": 3.0, "every": 9.0}
const FILMING: = {"raise": 1.9, "time": 7.0, "every": 10.0}
const HAND_TO_MOUTH: = {"raise": 1.9, "time": 4.0, "every": 13.0}
const ARMS_FOLDED: = {"raise": 0.0, "time": 0.0, "every": 1.0, "both": 0.85}
const FOLD_IN: = 0.5
const HANDS_BEHIND: = {"raise": 0.0, "time": 0.0, "every": 1.0, "both": -0.35}
const PHONE: = {"raise": 1.2, "time": 8.0, "every": 10.0}
const GESTURES: = {
	Figure.AGE_TEEN: [PHONE, PHONE, POINTING], 
	Figure.AGE_ADULT: [ARMS_FOLDED, ARMS_FOLDED, POINTING, FILMING, HAND_TO_MOUTH], 
	Figure.AGE_OLDER: [ARMS_FOLDED, HANDS_BEHIND, POINTING, HAND_TO_MOUTH], 
	Figure.AGE_OLD: [HANDS_BEHIND, HANDS_BEHIND, HANDS_BEHIND, POINTING], 
}
const BOXES_EACH: = 64
const DOMES_EACH: = 8
const BREATH_REACH: = 45.0
const BREATH_EVERY: = 3.2
const LOOK_REACH: = 12.0


const MATE_NONE: = 0
const MATE_PARTNER: = 1
const MATE_CHILD: = 2
const MATE_DOG: = 3
const MATE_SHARES: = [[MATE_PARTNER, 20], [MATE_CHILD, 8], [MATE_DOG, 11]]

const MATE_SIDE: = {MATE_PARTNER: Vector3(-3.7, 0, 0.2), MATE_CHILD: Vector3(-3.0, 0, 0.1), MATE_DOG: Vector3(-3.2, 0, -1.8)}
const CHILD_SCALE: = 0.64
const DOGS: Array[Color] = [Color8(70, 52, 38), Color8(196, 160, 112), Color8(30, 30, 32), Color8(236, 230, 218), Color8(140, 96, 60)]
const LEAD: = Color(0.75, 0.12, 0.1)

const ROLE_NONE: = 0
const ROLE_ARM: = 1
const ROLE_HAND: = 2
const ROLE_LEG: = 3
const ROLE_HEAD: = 4

static var current: Townsfolk


class Body:
	extends RefCounted
	var person: Pedestrians.Person
	var built: = false
	var scale: = 1.0
	var pieces: Array = []
	var alpha: = 0.0
	var gait: = 0.0
	var phase: = 0.0
	var push: = Vector3.ZERO
	var ground_at: = 0.0
	var ground: Variant = null
	var height: Variant = null
	var yaw: Variant = null
	var startle: = 0.0
	var gesture: = 0.0
	var both: = 0.0
	var gait_of: Dictionary = {}
	var age: = Figure.AGE_ADULT
	var mate_stoop: = 0.0
	var cheer: = 0.0
	var sit: = 0.0
	var head_turn: = 0.0
	var gaze: = 0.0
	var feel: = 0
	var said_at: = -1.0
	var rig: FirefighterRig = null
	var bubble: Label3D
	var bubble_until: = 0.0
	var head_at: = Vector3.ZERO
	var seen_at: Variant = null
	var mate: = MATE_NONE
	var mate_pieces: Array = []
	var mate_color: = Color.WHITE
	var mate_seat: Variant = null


var pedestrians: Pedestrians
var bodies: Dictionary = {}
var drawn: = 0

var _boxes: MultiMesh
var _heads: MultiMesh
var _domes: MultiMesh
var _capacity: = 0
var _draw_range: = 300.0
var _keep_range: = 325.0
var _surfaces: = -1
var _engines: Array = []
var _engines_at: = -10.0

var _n_boxes: = 0
var _eye: = Vector3.ZERO
var _cold: = false
var _n_heads: = 0
var _n_domes: = 0


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func start(source: Pedestrians) -> void :
	pedestrians = source
	var settings: Dictionary = Config.Life
	_draw_range = settings["DrawRange"]
	_keep_range = _draw_range + 25.0
	_boxes = _multimesh(Figure.BOX, false)
	_heads = _multimesh(Figure.HEAD, true)
	_domes = _multimesh(Figure.DOME, false)
	_reserve(int(settings["Pedestrians"]) + int(settings["CrowdMax"]) + 6)
	for id: int in Game.store.nodes:
		if Game.store.nodes[id]["n"] == "Surfaces" and Game.store.nodes[id]["c"] == "Folder":
			_surfaces = id
			break
	source.person_added.connect(_add)
	source.person_removed.connect(_remove)
	for person: Pedestrians.Person in source.people.values():
		_add(person)

	Style.current.changed.connect( func(_style: int) -> void :
		for body: Body in bodies.values():
			if body.built:
				_build(body)
	)


func _multimesh(shape: int, face: bool) -> MultiMesh:
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = true
	multimesh.use_custom_data = shape == Figure.HEAD
	multimesh.mesh = Figure.mesh_of(shape)

	multimesh.custom_aabb = AABB(Vector3(-1200, -20, -1200), Vector3(2600, 80, 2600))
	var instance: = MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.material_override = Figure.material(Color.WHITE, face)
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(instance)
	return multimesh


func _reserve(people: int) -> void :
	if people <= _capacity:
		return
	_capacity = people
	_boxes.instance_count = people * BOXES_EACH
	_heads.instance_count = people * 2
	_domes.instance_count = people * DOMES_EACH
	_boxes.visible_instance_count = 0
	_heads.visible_instance_count = 0
	_domes.visible_instance_count = 0





func _add(person: Pedestrians.Person) -> void :
	var body: = Body.new()
	body.person = person
	body.phase = person.seed
	bodies[person.id] = body


func _remove(person: Pedestrians.Person) -> void :
	var body: Body = bodies.get(person.id)
	if body:
		_undraw(body)
		bodies.erase(person.id)




func _build(body: Body) -> void :
	var looks: = Figure.looks(body.person.seed)
	body.age = looks["age"]
	body.gait_of = Figure.GAITS[body.age]
	body.scale = looks["scale"]
	body.pieces = scaled(Figure.pieces(looks), body.scale)
	body.mate = mate_of(body.person.seed)
	body.mate_pieces.clear()
	body.mate_seat = null
	if body.mate == MATE_PARTNER or body.mate == MATE_CHILD:
		var mate_looks: = Figure.looks(body.person.seed * 31 + 7, {}, Figure.AGE_CHILD if body.mate == MATE_CHILD else "")
		var mate_scale: float = mate_looks["scale"] * (CHILD_SCALE if body.mate == MATE_CHILD else 1.0)
		body.mate_stoop = Figure.GAITS[mate_looks["age"]]["stoop"]
		body.mate_pieces = scaled(Figure.pieces(mate_looks), mate_scale)
	elif body.mate == MATE_DOG:
		body.mate_color = DOGS[(body.person.seed / 7) % DOGS.size()]
	body.built = true
	body.yaw = null
	body.height = null



static func mate_of(person_seed: int) -> int:
	var roll: = hash(person_seed * 13 + 5) % 100
	for share: Array in MATE_SHARES:
		if roll < share[1]:
			return share[0]
		roll -= share[1]
	return MATE_NONE




static func scaled(pieces: Array, scale: float) -> Array:
	var list: Array = []
	for piece: Dictionary in pieces:
		var role: = ROLE_NONE
		match piece["role"]:
			"arm":
				role = ROLE_HAND if piece["hand"] else ROLE_ARM
			"leg":
				role = ROLE_LEG
			"head":
				role = ROLE_HEAD
		list.append([piece["shape"], role, piece["swing"], piece["pivot"] * scale, piece["rest"] * scale, piece["size"] * scale, piece["color"], piece.get("part", ""), piece.get("face", -1)])
	return list


func _undraw(body: Body) -> void :
	if body.built:
		body.built = false
		body.pieces.clear()
		body.alpha = 0.0
	if body.bubble:
		body.bubble.queue_free()
		body.bubble = null






func _ground_under(position: Vector3) -> Variant:
	var world: = Game.world
	if world == null:
		return null
	var hit: = world.raycast(Vector3(position.x, 8.0, position.z), Vector3(position.x, -4.0, position.z), World.LAYER_SOLID)
	var row: = world.row_hit(hit)
	if row < 0:
		return null
	if Game.store.parent(row) == _surfaces or Game.store.name_at(row) == "Ground":
		return hit["position"].y
	return null





func _find_engines() -> void :
	_engines.clear()
	for vehicle in Vehicle.all:
		if not is_instance_valid(vehicle) or not vehicle.is_inside_tree():
			continue
		var data: = vehicle.data
		var half_width: float = data.get("halfWidth", 5.0)
		var half_length: float = (float(data.get("rear", 14.0)) - float(data.get("front", -14.0))) / 2.0
		_engines.append({"vehicle": vehicle, "half_width": half_width, "half_length": half_length})





static func _flat(vector: Vector3) -> Vector3:
	return Vector3(vector.x, 0, vector.z)


func _process(dt: float) -> void :
	if pedestrians == null:
		return

	var now: = HostClock.now()
	var mirrored: = Net.is_client()
	var settings: Dictionary = Config.Life
	var camera: = get_viewport().get_camera_3d()
	var eye: = camera.global_position if camera else Vector3.ZERO
	_eye = eye
	_cold = Style.winter()

	var players: Array[Vector3] = []
	for player in Game.players:
		players.append(player.global_position)

	if absf(now - _engines_at) > 1.0:
		_engines_at = now
		_find_engines()
	var moving: Array = []
	var wailing: Array[Vector3] = []
	for engine: Dictionary in _engines:
		var vehicle: Vehicle = engine["vehicle"]
		if not is_instance_valid(vehicle):
			continue
		var ahead: = _flat( - vehicle.global_transform.basis.z).normalized()
		var speed: = _flat(vehicle.linear_velocity).dot(ahead)
		if absf(speed) > 2.0:


			var wail: bool = vehicle.siren > 0
			moving.append({"at": vehicle.global_position, "ahead": ahead * signf(speed), "speed": absf(speed) * (1.6 if wail else 1.0), "half_width": engine["half_width"] + (1.5 if wail else 0.0), "half_length": engine["half_length"]})
		if vehicle.siren > 0 and absf(speed) > settings["SirenMoving"]:
			wailing.append(vehicle.global_position)

	_reserve(bodies.size())
	_n_boxes = 0
	_n_heads = 0
	_n_domes = 0
	var shown: = 0
	var fade: float = settings["FadeTime"]
	var siren_range: float = settings["PedSirenRange"]

	for body: Body in bodies.values():
		var person: = body.person
		var from: = person.shown_from
		var to: = person.shown_to
		var state: = person.shown_state


		var span: = from.distance_to(to)
		var done: = 1.0
		if span > 0.01 and person.shown_speed > 0.0:
			done = clampf((now - person.shown_t0) * person.shown_speed / span, 0.0, 1.0)
		var position: = from.lerp(to, done)
		var walking: = state == "walk" and done < 1.0
		if mirrored:

			if body.seen_at != null and position.distance_to(body.seen_at) < 8.0:
				position = body.seen_at.lerp(position, 1.0 - exp( - dt * 14.0))
			body.seen_at = position

		var distance: = position.distance_to(eye)
		if distance > (_keep_range if body.built else _draw_range):
			_undraw(body)
			continue
		if not body.built:
			_build(body)


		var watched: Variant = null
		var watched_gap: = INF
		for siren in wailing:
			var gap: = _flat(siren - position).length()
			if gap < siren_range and gap < watched_gap:
				watched = siren
				watched_gap = gap


		var look: = Vector3.ZERO
		if walking:
			look = _flat(to - from)
		elif watched != null:
			look = _flat(watched - position)
		elif person.shown_face != null:
			look = _flat(person.shown_face - position)
		if look.length() > 0.05:
			var wanted_yaw: = atan2( - look.x, - look.z)
			if body.yaw != null:
				body.yaw += wrapf(wanted_yaw - body.yaw, - PI, PI) * minf(1.0, dt * 8.0)
			else:
				body.yaw = wanted_yaw
		if body.yaw == null:
			body.yaw = 0.0
		var yaw: float = body.yaw



		var head_turn: = 0.0
		var wanted_turn: = 0.0
		if watched != null and walking:
			var toward: = _flat(watched - position)
			wanted_turn = wrapf(atan2( - toward.x, - toward.z) - yaw, - PI, PI)
			head_turn = clampf(wanted_turn, - HEAD_TURN, HEAD_TURN)
		else:
			var nearest: = INF
			for other in players:
				var gap: = _flat(other - position).length()
				if gap < LOOK_REACH and gap < nearest:
					nearest = gap
					var toward: = _flat(other - position)
					wanted_turn = wrapf(atan2( - toward.x, - toward.z) - yaw, - PI, PI)
			if nearest < INF and absf(wanted_turn) < 1.9:
				head_turn = clampf(wanted_turn, - HEAD_TURN, HEAD_TURN)
			else:
				wanted_turn = 0.0
		body.head_turn += (head_turn - body.head_turn) * minf(1.0, dt * 6.0)
		var gaze: = clampf( - (wanted_turn - body.head_turn * 0.6) * 1.4, -1.0, 1.0) if wanted_turn != 0.0 else 0.0
		body.gaze += (gaze - body.gaze) * minf(1.0, dt * 12.0)


		if absf(now - body.ground_at) > GROUND_EVERY:
			body.ground_at = now + (person.id % 7) * 0.01
			body.ground = _ground_under(position)
		var height: float = body.ground if body.ground != null else position.y
		body.height = body.height + (height - body.height) * minf(1.0, dt * 10.0) if body.height != null else height


		var push: = Vector3.ZERO
		for other in players:
			var away: = _flat(position - other)
			var gap: = away.length()
			if gap < ROOM and gap > 0.05:
				push += away / gap * (ROOM - gap) * 0.6


		var dodging: = false
		for engine: Dictionary in moving:
			var offset: = _flat(position - engine["at"])
			var ahead: Vector3 = engine["ahead"]
			var along: = offset.dot(ahead)
			var right: = Vector3( - ahead.z, 0, ahead.x)
			var across: = offset.dot(right)
			var berth: float = engine["half_width"] + BERTH
			if along > - engine["half_length"] and along < engine["half_length"] + engine["speed"] * 0.8 + 6.0 and absf(across) < berth:
				push += right * (1.0 if across >= 0.0 else -1.0) * (berth - absf(across))
				dodging = true
		body.push = body.push.lerp(push, minf(1.0, dt * (12.0 if dodging else 6.0)))
		body.startle += ((1.0 if dodging else 0.0) - body.startle) * minf(1.0, dt * (14.0 if dodging else 3.0))


		body.gait += ((1.0 if walking else 0.0) - body.gait) * minf(1.0, dt * 8.0)
		var gait: = body.gait_of
		if walking:
			body.phase += person.shown_speed * dt * STRIDE * float(gait["stride"])
		var swing: = sin(body.phase) * SWING * body.gait * float(gait["legs"])
		var arm_swing: float = float(gait["arms"]) / float(gait["legs"])
		var bob: = absf(cos(body.phase)) * 0.1 * body.gait * float(gait["legs"])


		var raise: = 0.0
		var habit: Dictionary = {}
		if state == "watch":
			var habits: Array = GESTURES.get(body.age, GESTURES[Figure.AGE_ADULT])
			habit = habits[rand_from_seed(hash([person.seed, "watch"]))[0] %habits.size()]
		elif state == "talk":
			habit = CHATTING
		if not habit.is_empty() and fmod(now + person.seed, habit["every"]) < habit["time"]:
			raise = habit["raise"]
		var held: float = habit.get("both", 0.0)
		body.gesture += (raise - body.gesture) * minf(1.0, dt * 5.0)
		body.both += (held - body.both) * minf(1.0, dt * 4.0)
		var cheering: = state == "watch" and person.mood == "cheer"
		body.cheer += ((1.0 if cheering else 0.0) - body.cheer) * minf(1.0, dt * 6.0)

		body.feel = 1 if body.startle > 0.4 else (4 if body.cheer > 0.4 else (3 if now < body.bubble_until else 0))


		var wanted_alpha: = 0.0 if state == "leave" else 1.0
		if body.alpha != wanted_alpha:
			var change: = dt / fade
			body.alpha = clampf(body.alpha + (change if wanted_alpha > body.alpha else - change), 0.0, 1.0)


		body.sit += ((1.0 if state == "sit" else 0.0) - body.sit) * minf(1.0, dt * 5.0)
		var sit: = body.sit
		var seated: = SEAT_TOP + (0.5 - 2.0) * body.scale
		var stood: float = body.height + (seated - body.height) * sit

		var turn: = Basis(Vector3.UP, yaw)
		var origin: = Vector3(position.x + body.push.x, stood + bob, position.z + body.push.z)
		body.head_at = _put(body.pieces, origin, turn, swing, sit, body.startle, body.gesture, body.cheer, body.head_turn, body.alpha, now, arm_swing, body.both * (1.0 - body.gait), float(gait["stoop"]) * (1.0 - sit), body.gaze, body.feel)
		if body.mate != MATE_NONE:
			_put_mate(body, position, turn, yaw, swing, sit, state, now)
		shown += 1


		if person.say_at != body.said_at:
			body.said_at = person.say_at
			if person.say != null and now - person.say_at < 3.0:
				_say(body, person.say, now)
		if body.bubble:
			if now > body.bubble_until:
				body.bubble.queue_free()
				body.bubble = null
			else:
				body.bubble.position = body.head_at + Vector3(0, 1.6 * body.scale, 0)
				body.bubble.modulate.a = clampf((body.bubble_until - now) * 3.0, 0.0, 1.0)
				body.bubble.outline_modulate.a = body.bubble.modulate.a

	_boxes.visible_instance_count = _n_boxes
	_heads.visible_instance_count = _n_heads
	_domes.visible_instance_count = _n_domes
	drawn = shown






func _put(pieces: Array, origin: Vector3, turn: Basis, swing: float, sit: float, startle: float, gesture: float, cheer: float, head_turn: float, alpha: float, now: float, arm_swing: = 1.0, both: = 0.0, stoop: = 0.0, gaze: = 0.0, feel: = 0) -> Vector3:
	var head_at: = origin

	var hips: Vector3 = Vector3(0, pieces[0][5].y, 0)
	var lean: = turn * Basis(Vector3.RIGHT, - stoop)
	for piece: Array in pieces:
		var role: int = piece[1]
		var upper: = role != ROLE_LEG and stoop != 0.0
		var body_turn: = lean if upper else turn
		var basis: = body_turn
		match role:
			ROLE_ARM, ROLE_HAND:
				var angle: float = piece[2] * swing * arm_swing + both + (gesture if role == ROLE_HAND else 0.0)

				var clap: = 1.25 + sin(now * 14.0 + (PI if role == ROLE_HAND else 0.0)) * 0.2
				angle += (clap - angle) * cheer
				angle += (0.35 - angle) * sit
				basis = body_turn * Basis(Vector3.RIGHT, angle * (1.0 - startle) + ARMS_UP * startle)
				if both > 0.0:

					basis = basis * Basis(Vector3.BACK, piece[2] * both * FOLD_IN * (1.0 - startle) * (1.0 - cheer))
			ROLE_LEG:
				basis = turn * Basis(Vector3.RIGHT, piece[2] * swing * (1.0 - sit) + PI / 2.0 * sit)
			ROLE_HEAD:
				basis = body_turn * Basis(Vector3.UP, head_turn)
		var pivot: Vector3 = piece[3]
		var rest: Vector3 = piece[4]
		var size: Vector3 = piece[5]
		var at: = origin + turn * pivot + basis * rest
		if upper:
			at = origin + turn * hips + lean * (pivot - hips) + basis * rest
		var color: Color = piece[6]
		color.a = alpha
		match piece[0]:
			Figure.HEAD:
				head_at = at
				_heads.set_instance_transform(_n_heads, Transform3D(basis * Basis.from_scale(size), at))
				_heads.set_instance_color(_n_heads, color)
				_heads.set_instance_custom_data(_n_heads, Color(maxi(int(piece[8]), 0) / 255.0, (gaze + 1.0) / 2.0, feel / 8.0, 0))
				_n_heads += 1
			Figure.DOME:
				_domes.set_instance_transform(_n_domes, Transform3D(basis * Basis.from_scale(size), at))
				_domes.set_instance_color(_n_domes, color)
				_n_domes += 1
			_:
				_box(Transform3D(basis * Basis.from_scale(size), at), color)
	if _cold and alpha > 0.5 and head_at.distance_to(_eye) < BREATH_REACH:
		_breath(head_at, turn, now + (pieces[0][6] as Color).r * 7.0)
	return head_at




func _breath(head_at: Vector3, turn: Basis, now: float) -> void :
	var t: = fposmod(now, BREATH_EVERY)
	if t > 1.4 or _n_domes >= _domes.instance_count:
		return
	var k: = t / 1.4
	var size: = lerpf(0.3, 1.2, sqrt(k))
	var at: = head_at + turn * Vector3(0, 0.05 + 0.3 * k, -1.05 - 1.2 * k)
	_domes.set_instance_transform(_n_domes, Transform3D(Basis.from_scale(Vector3(size, size * 0.8, size)), at))
	_domes.set_instance_color(_n_domes, Color(1.0, 1.0, 1.0, 0.4 * (1.0 - k)))
	_n_domes += 1


func _box(place: Transform3D, color: Color) -> void :
	_boxes.set_instance_transform(_n_boxes, place)
	_boxes.set_instance_color(_n_boxes, color)
	_n_boxes += 1




func _put_mate(body: Body, position: Vector3, turn: Basis, yaw: float, swing: float, sit: float, state: String, now: float) -> void :
	if body.mate == MATE_DOG:
		_put_dog(body, position, turn, yaw, swing, sit, now)
		return
	if state == "sit" and body.mate_seat == null:
		body.mate_seat = _seat_beside(body, position, turn)
	elif state != "sit" and sit < 0.01:
		body.mate_seat = null
	var side: Vector3 = MATE_SIDE[body.mate]
	var at: = position + body.push + turn * side
	var mate_sit: = 0.0
	var mate_turn: = turn
	if sit > 0.01:
		if body.mate_seat is Vector3:
			at = at.lerp(body.mate_seat, sit)
			mate_sit = sit
		else:

			at = at.lerp(position + turn * Vector3(-2.8, 0, -3.2), sit)
			mate_turn = Basis(Vector3.UP, yaw + PI * 0.75 * sit)
	var scale: float = body.mate_pieces[0][5].y / 2.0
	var seated: = SEAT_TOP + (0.5 - 2.0) * scale
	var stood: float = body.height + (seated - body.height) * mate_sit
	var stride: = 1.35 if body.mate == MATE_CHILD else 1.0
	var mate_swing: = sin(body.phase * stride + 0.4) * SWING * body.gait * float(body.gait_of["legs"])
	var bob: = absf(cos(body.phase * stride + 0.4)) * 0.1 * body.gait * scale
	var talk: = 0.0
	if state == "talk" or state == "idle" or mate_sit > 0.5:
		talk = CHATTING["raise"] if fmod(now + body.person.seed * 0.37 + 2.0, CHATTING["every"]) < CHATTING["time"] else 0.0
	_put(body.mate_pieces, Vector3(at.x, stood + bob, at.z), mate_turn, mate_swing, mate_sit, body.startle, talk * (1.0 - body.gait), body.cheer, 0.0, body.alpha, now, 1.0, 0.0, body.mate_stoop * (1.0 - mate_sit))



func _seat_beside(body: Body, position: Vector3, turn: Basis) -> Variant:
	var graph: = NavGraph.current
	if graph == null:
		return false
	var along: = turn * Vector3.RIGHT
	for place: Dictionary in graph.places:
		if place["kind"] != "bench":
			continue
		var middle: = Vector3(place["x"], position.y, place["z"])
		var offset: = _flat(position - middle)
		if offset.length() > 3.0:
			continue
		var on: = offset.dot(along)
		var other: = middle - along * (signf(on) if absf(on) > 0.1 else -1.0) * Pedestrians.SEATS[1] + turn * Vector3(0, 0, -0.15)
		for other_body: Body in bodies.values():
			if other_body != body and other_body.person.shown_state == "sit" and _flat(other_body.person.shown_to - other).length() < 1.2:
				return false
		return other
	return false




func _put_dog(body: Body, position: Vector3, turn: Basis, yaw: float, swing: float, sit: float, now: float) -> void :
	var size: = 0.7 + float(body.person.seed % 5) * 0.12
	var down: = clampf((1.0 - body.gait) * 1.3 - 0.3, 0.0, 1.0)
	var side: Vector3 = MATE_SIDE[MATE_DOG] if sit < 0.5 else Vector3(-1.4, 0, -3.0)
	var at: = position + body.push + turn * side
	var dog_turn: = turn if sit < 0.5 else Basis(Vector3.UP, yaw + PI * 0.5)
	var trot: = sin(body.phase * 1.6) * 0.75 * body.gait
	var coat: = body.mate_color
	coat.a = body.alpha
	var dark: = coat.darkened(0.35)
	var legs_high: = 1.0 * size
	var origin: = Vector3(at.x, body.height, at.z)
	var middle: = origin + Vector3(0, legs_high * (1.0 - 0.7 * down) + 0.42 * size, 0)
	_box(Transform3D(dog_turn * Basis.from_scale(Vector3(0.9, 0.85, 2.1) * size), middle), coat)
	var neck: = middle + dog_turn * Vector3(0, 0.45 * size, -1.05 * size)
	var head: = neck + dog_turn * Vector3(0, 0.3 * size, -0.3 * size)
	var nod: = dog_turn * Basis(Vector3.UP, sin(now * 0.7 + body.person.seed) * 0.5 * (1.0 - body.gait))
	_box(Transform3D(nod * Basis.from_scale(Vector3(0.75, 0.7, 0.8) * size), head), coat)
	_box(Transform3D(nod * Basis.from_scale(Vector3(0.45, 0.4, 0.55) * size), head + nod * (Vector3(0, -0.12, -0.6) * size)), dark)
	for x: float in [-0.27, 0.27]:
		_box(Transform3D(nod * Basis.from_scale(Vector3(0.18, 0.4, 0.22) * size), head + nod * (Vector3(x, 0.45, 0.1) * size)), dark)
	var leg_size: = Vector3(0.26 * size, legs_high, 0.26 * size)
	for corner: Vector3 in [Vector3(-0.3, 0, -0.75), Vector3(0.3, 0, -0.75), Vector3(-0.3, 0, 0.75), Vector3(0.3, 0, 0.75)]:
		var front: = corner.z < 0.0
		var angle: = trot * (1.0 if (corner.x < 0.0) == front else -1.0)
		var hip: = middle + dog_turn * Vector3(corner.x * size, -0.35 * size, corner.z * size)

		angle += ((1.45 if front else -1.45) - angle) * down
		var leg_basis: = dog_turn * Basis(Vector3.RIGHT, angle)
		_box(Transform3D(leg_basis * Basis.from_scale(leg_size), hip + leg_basis * Vector3(0, - legs_high / 2.0, 0)), coat)
	var wag: = Basis(Vector3.UP, sin(now * (10.0 if body.gait > 0.5 else 5.0) + body.person.seed) * 0.55)
	var tail_root: = middle + dog_turn * Vector3(0, 0.3 * size, 1.05 * size)
	var tail_basis: = dog_turn * wag * Basis(Vector3.RIGHT, 0.7)
	_box(Transform3D(tail_basis * Basis.from_scale(Vector3(0.16, 0.16, 0.8) * size), tail_root + tail_basis * Vector3(0, 0, 0.4 * size)), coat)

	var hand: = position + body.push + turn * Vector3(-1.6 * body.scale, 0, -0.2) + Vector3(0, body.height + 2.1 * body.scale + absf(swing) * 0.15, 0)
	var span: = hand - neck
	if span.length() > 0.2:
		var up: = Vector3.UP if absf(span.normalized().y) < 0.98 else Vector3.RIGHT
		var lead: = Color(LEAD, body.alpha)
		_box(Transform3D(Basis.looking_at(span.normalized(), up) * Basis.from_scale(Vector3(0.07, 0.07, span.length())), neck + span / 2.0), lead)



func _say(body: Body, text: Variant, now: float) -> void :
	if body.bubble == null:
		var label: = Label3D.new()
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.pixel_size = 0.012
		label.font_size = 64
		label.outline_size = 16
		label.modulate = Color(1, 1, 1)
		label.outline_modulate = Color(0.08, 0.09, 0.11)
		label.no_depth_test = false
		label.fixed_size = false
		add_child(label)
		body.bubble = label
	body.bubble.text = Text.say(text)
	body.bubble_until = now + 2.5
