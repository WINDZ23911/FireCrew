class_name PeopleBench
extends Node








var _shots: = ""
var _camera: Camera3D


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--peoplebench-shots="):
			_shots = arg.substr(20)
	_run.call_deferred()


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false, false, true).timeout


func _look(from: Vector3, at: Vector3) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.fov = 50.0
		_camera.far = 3000.0
		get_tree().root.add_child(_camera)
	_camera.look_at_from_position(from, at)
	_camera.make_current()


func _snap(tag: String) -> void :
	await _wait(0.4)
	await RenderingServer.frame_post_draw
	if not _shots.is_empty():
		get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, tag])
	print("peoplebench shot %s at %.0f fps" % [tag, Engine.get_frames_per_second()])


func _row(at: Vector3, across: Vector3, toward: Vector3) -> Array[Figure]:
	var made: Array[Figure] = []
	for index in 12:
		var figure: = Figure.build(index * 7919 + 13)
		Game.world.add_child(figure)
		figure.global_transform = Figure.standing(at + across * (index - 5.5) * 4.6, toward)
		made.append(figure)
	return made


func _run() -> void :
	await _wait(2.0)
	CallService.current.hold = true

	var middle: Vector3 = FireService.current.buildings[0].position
	for building in FireService.current.buildings:
		if building.name.begins_with("House"):
			middle = building.position
			break
	var out: = FireBench.new()._street_side(middle)
	var at: = middle + out * 34.0
	var ground: = Game.world.raycast(at + Vector3(0, 30, 0), at - Vector3(0, 30, 0), World.LAYER_SOLID)
	at.y = (ground["position"] as Vector3).y if not ground.is_empty() else 0.5
	var across: = out.cross(Vector3.UP).normalized()
	Game.local_player.teleport(at + out * 40.0 + Vector3(0, 1, 0))
	var row: = _row(at, across, out)
	_look(at + out * 28.0 + Vector3(0, 5.0, 0), at + Vector3(0, 2.6, 0))
	await _snap("lineup")
	_look(at + out * 6.5 + Vector3(0, 4.4, 0), at + Vector3(0, 3.6, 0))
	await _snap("faces")
	_look(at + across * 34.0 + out * 6.0 + Vector3(0, 4, 0), at + Vector3(0, 2.6, 0))
	await _snap("side")

	if Pedestrians.current != null and not Pedestrians.current.people.is_empty():
		var best: = Vector3.ZERO
		var most: = -1
		for person: Pedestrians.Person in Pedestrians.current.people.values():
			var here: Vector3 = person.position
			var near: = 0
			for other: Pedestrians.Person in Pedestrians.current.people.values():
				var there: Vector3 = other.position
				near += 1 if here.distance_to(there) < 30.0 else 0
			if near > most:
				most = near
				best = here
		_look(best + Vector3(14, 6, 14), best + Vector3(0, 2, 0))
		await _wait(1.5)
		await _snap("street")

		var folk: = Townsfolk.current
		if folk != null:
			folk.set_process(false)
			var spent: = 0
			var frames: = 0
			var boxes: = 0
			var began: = Time.get_ticks_msec()
			while Time.get_ticks_msec() - began < 2000:
				var dt: = get_process_delta_time()
				var t0: = Time.get_ticks_usec()
				folk._process(dt)
				spent += Time.get_ticks_usec() - t0
				boxes = maxi(boxes, folk._n_boxes)
				frames += 1
				await get_tree().process_frame
			folk.set_process(true)
			print("peoplebench street: townspeople %.3f ms a frame, %d drawn, up to %d boxes" % [spent / 1000.0 / frames, folk.drawn, boxes])

	if TownLocals.current != null:
		if Sky3D.current != null:
			Sky3D.current.set_hour(16.0)
		await _wait(1.5)
		var shown: = 0
		var seen: Array[Vector3] = []
		for spot: Variant in TownLocals.current.spots:
			if shown >= 3:
				break
			var feet: Vector3 = spot.root.origin
			var apart: = true
			for other in seen:
				apart = apart and other.distance_to(feet) > 40.0
			if spot.seed == 0 or not apart:
				continue
			seen.append(feet)
			Game.local_player.teleport(feet + Vector3(0, 1, 30))
			_look(feet - spot.root.basis.z * 9.0 + Vector3(2, 4, 0), feet + Vector3(0, 2, 0))
			await _wait(2.5)
			await _snap("local%d" % shown)
			_look(feet + spot.root.basis.x * 8.0 + Vector3(0, 3, 0), feet + Vector3(0, 2, 0))
			await _snap("local%d_side" % shown)
			shown += 1
		if shown == 0:
			print("peoplebench: no locals out")
	if Sky3D.current != null:
		Sky3D.current.set_hour(21.5)
		_look(at + out * 28.0 + Vector3(0, 5.0, 0), at + Vector3(0, 2.6, 0))
		await _snap("night")
		Sky3D.current.set_hour(12.0)
	for figure in row:
		figure.queue_free()
	Style.choose(Style.WINTER)
	await _wait(1.0)
	_row(at, across, out)
	_look(at + out * 28.0 + Vector3(0, 5.0, 0), at + Vector3(0, 2.6, 0))
	await _snap("winter")
	get_tree().quit()
