class_name JobPress
extends CrewJob



func _init(job_kind: String, prompt: Prompt, job_role: = "") -> void :
	kind = job_kind
	target = prompt
	role = job_role


func place() -> Vector3:
	return target.global_position if is_instance_valid(target) else who.body.global_position


func run() -> bool:
	if not is_instance_valid(target) or not target.enabled:
		return fail("crew.say.nothingThere")
	CrewKit.free_hands(who)
	if not await CrewKit.press_skilled(who, target):
		return fail("crew.say.cannot") if not cancelled else false
	return true
