class_name Ember
extends Node3D


static var all: Array[Ember] = []

var intensity: = 0.25


func _enter_tree() -> void :
	all.append(self)


func _exit_tree() -> void :
	all.erase(self)


func _ready() -> void :
	ToonFire.puffs(self, {
		"Color": Color(0.5, 0.49, 0.48), "Rate": 1.5, "Speed": [1.2, 2], "Lifetime": [2.0, 3.0], "SpreadAngle": 10, 
		"Direction": Vector3.UP, "Acceleration": World.WIND * 0.8, "Rotation": [0, 360], 
		"Size": [[0.0, 0.25], [0.4, 0.8], [1.0, 0.0]], 
	}, true)
