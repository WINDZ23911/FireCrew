extends ProofDebug








func _outlet(vehicle: Vehicle) -> Dictionary:
	var found: Array = HoseService.current.lines.filter( func(l: Dictionary) -> bool: return l["kind"] == "outlet" and l["rig"] != null and l["rig"]["vehicle"] == vehicle)
	return found[0]


func _scenario_foglook() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	var line: = _outlet(pumper)
	player.teleport(_ground(line["source"].global_position + pumper.global_basis.x * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	line["prompt"].triggered.emit(player)
	await _wait(0.3)
	_check(is_same(HoseService.current.line_of(player), line), "a line in hand")
	var out: = pumper.global_basis.x
	for step in 3:
		player.teleport(player.global_position + out * 4.0)
		await _wait(0.2)
	_look_at(player.head_position() + out * 20.0)
	Input.action_press("fire")
	await _wait(float(Config.Water.Charge.Time) + 1.5)
	var side: = out.cross(Vector3.UP).normalized()
	_view(player.global_position + side * 14.0 + Vector3(0, 5, 0) + out * 6.0, player.global_position + out * 6.0 + Vector3(0, 2, 0))
	await _snap("jet")
	player.set_attr("Pattern", "Fog")
	await _wait(1.2)
	var jet: WaterJet = line["jet"]
	_check(jet.fog and jet._fog_body.visible, "the fog cone shows")
	await _snap("fog_side")
	_view(player.global_position - out * 7.0 + Vector3(0, 6, 0) + side * 3.0, player.global_position + out * 8.0)
	await _wait(0.2)
	await _snap("fog_behind")
	Input.action_release("fire")
	await _done()


func _scenario_floodlook() -> void :
	await _wait(1.0)
	Alarm.forced = 1
	Alarm.forced_complications = ["none"]
	var flood: = FloodedCellar.current
	CallService.current.run_call("flood", flood.run)
	var waited: = 0.0
	while flood.source.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	var hatch: Dictionary = flood._hatch
	if not _check( not hatch.is_empty(), "a flooded cellar call starts"):
		await _done()
		return
	var inlet: Node3D = hatch["inlet"]
	var place: Transform3D = hatch["place"]
	var out: = - place.basis.z
	var switch: Node3D = hatch["switch"]

	var into: = place.basis.z
	var behind: = switch.global_position + into * (FloodedCellar.SWITCH_SIZE.z / 2.0 + 0.02)
	var back: = Game.world.raycast(behind, behind + into * 2.0, World.LAYER_SOLID)
	var gap: float = back["position"].distance_to(behind) if not back.is_empty() else INF
	print("floodlook: isolator at %s (from the hatch %s), wall %.2f studs behind its back" % [switch.global_position, hatch["switch_at"], gap])
	_check(gap < 0.3, "the isolator hangs on the building's wall")
	player.teleport(_ground(inlet.global_position + out * 9.0) + Vector3(0, 0.5, 0))
	_view(inlet.global_position + out * 14.0 + place.basis.x * 6.0 + Vector3(0, 7, 0), (inlet.global_position + switch.global_position) / 2.0)
	await _wait(0.6)
	await _snap("isolator")
	hatch["switch_prompt"].triggered.emit(player)
	await _wait(0.3)
	_check( not hatch["power"], "the power is off")


	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, _ground(inlet.global_position + out * 22.0) + Vector3(0, 0.5, 0), atan2(place.basis.x.x, place.basis.x.z))
	await _wait(1.5)
	var rig: Dictionary = {}
	for each: Dictionary in HoseService.current.rigs:
		if each["vehicle"] == pumper:
			rig = each
	player.teleport(pumper.intake["node"].global_position + pumper.global_basis.x * 2.0)
	await _wait(0.3)
	rig["supply"]["prompt"].triggered.emit(player)
	await _wait(0.3)
	player.teleport(_ground(inlet.global_position + out * 3.0) + Vector3(0, 0.5, 0))
	await _wait(0.3)
	hatch["prompt"].triggered.emit(player)
	await _wait(2.0)
	var hose: HoseLine = rig["supply"]["hose"]
	print("floodlook: supply %s, hose width %s, swell %.2f" % [rig["supply"]["state"], hose.width if hose else -1.0, hose.swell if hose else -1.0])
	_check(hose != null and is_equal_approx(hose.width, HoseService.SUCTION_WIDTH), "the supply hose in the hatch is a fat suction hose")
	await _wait(float(Config.Water.Charge.Supply))
	_check(hose != null and hose.swell >= 0.99, "and it fills out round")
	var made: Dictionary = flood.discharge
	print("floodlook: discharge valves %d" % made.get("valves", []).size())
	_check(made.get("valves", []).size() == 2, "the valve is on both sides of the truck")
	if made.get("valves", []).size() == 2:
		var first: Dictionary = made["valves"][0][0]
		var second: Dictionary = made["valves"][1][0]
		var other: Dictionary = second if is_same(made["line"], first) else first
		flood._turn_valve(made, other)
		await _wait(0.5)
		var side: = pumper.to_local(made["spout"].global_position).x
		var other_side: = pumper.to_local((other["source"] as Node3D).global_position).x
		_check(made["open"] and is_same(made["line"], other) and signf(side) == signf(other_side), "opened from the other side, the water comes out there")
		_view(pumper.global_position + pumper.global_basis.z * 26.0 + Vector3(0, 12, 0), pumper.global_position)
		await _wait(0.4)
		await _snap("valve")
		flood._turn_valve(made, other)
		await _wait(0.2)
		_check( not made["open"], "and shut again from there")


	CallGear.current._on_line(player, "Portable pump")
	await _wait(0.3)
	var key: = CallGear.slot_key(player)
	print("floodlook: carrying %s, its key %s" % [CallGear.carried(player), key])
	_check(CallGear.carried(player) == "Portable pump" and not key.is_empty(), "a pump in hand has a hotbar key")
	_view_player()
	await _wait(0.4)
	await _snap("pump_hotbar")
	await _tap(key)
	await _wait(0.3)
	_check(CallGear.carried(player).is_empty(), "its number key puts it back on the truck")


	flood._turn_valve(made, made["line"])
	Config.Incidents.Flood["Flow"] = 2000.0
	waited = 0.0
	while not Game.incident.is_empty() and waited < 30.0:
		await _wait(0.5)
		waited += 0.5
	Config.Incidents.Flood["Flow"] = 60.0
	var debrief: = HudDebrief.current
	debrief.open()
	await _wait(0.5)
	_check(debrief.is_open() and not player.camera.captured, "the report is up and the pointer free for its ✕")
	await _snap("report")
	var escape: = InputEventAction.new()
	escape.action = "pause"
	escape.pressed = true
	Input.parse_input_event(escape)
	await _wait(0.3)
	_check( not debrief.is_open() and player.camera.captured and not HudPause.current.open if HudPause.current else not debrief.is_open(), "Esc closes the report, and not into the pause menu")
	debrief.open()
	await _wait(0.4)
	var close: = debrief._plate.get_node_or_null("Close") as Button
	if _check(close != null, "the report has a ✕"):
		close.pressed.emit()
	await _wait(0.3)
	_check( not debrief.is_open(), "the ✕ closes it")
	await _done()
