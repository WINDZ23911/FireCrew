class_name TeamRadio
extends Node























static var current: TeamRadio

const RATE: = 8000
const PACKET: = 400
const BUS: = "Radio"
const IN_BUS: = "VoiceIn"
const PERMIT: = "talk_permit"
const ROGER: = "talk_roger"


const STEPS: = [
	7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 
	107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 
	876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 
	5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 
	27086, 29794, 32767, 
]
const INDEX_STEPS: = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8]


var on_air: Dictionary = {}

var talking: = false

var level: = 0.0

var monitoring: = false

var mic_dead: = false

var counts: = {"sent": 0, "heard": 0, "permits": 0, "rogers": 0}

var _mic: AudioStreamPlayer
var _capture: AudioEffectCapture
var _since: = 0.0
var _held_out: = false
var _opened_at: = 0.0
var _loudest: = 0.0
var _envelope: = 0.0
var _gain: = 1.0
var _told_no_mic: = false
var _state: Array = [0, 0]
var _pending: = PackedFloat32Array()
var _sum: = 0.0
var _summed: = 0
var _along: = 0.0
var _speakers: Dictionary = {}
var _keyed_at: Dictionary = {}
var _released_at: Dictionary = {}
var _fake_mic: = false
var _fake_phase: = 0.0
var fake_level: = 1.0


func _ready() -> void :
	current = self
	process_mode = Node.PROCESS_MODE_ALWAYS
	_fake_mic = OS.get_cmdline_user_args().has("--voice-test")
	_gain = float(Config.TeamRadio.MicGain)
	_make_buses()
	Net.handle("voice", _on_voice)
	Net.handle("voice.key", _on_key)
	Net.handle("voice.keyed", _keyed)
	Net.peer_left.connect( func(player: Player) -> void :
		var peer: = Net.peer_of(player)
		for found: int in _speakers.keys():
			if NetTalk.player_of(found) == player or found == peer:
				_close(found)
	)
	Net.stopped.connect(_stop_all)
	if Hud.current:
		Hud.current.add_widget("voice", HudVoice.new())



static func is_on_air(player: Player) -> bool:
	if current == null or player == null or not Net.active():
		return false
	var peer: = NetTalk.peer_of(player)
	return current.on_air.has(peer) or (player == Game.local_player and current.talking)





func _make_buses() -> void :
	if AudioServer.get_bus_index(IN_BUS) < 0:
		var index: = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, IN_BUS)
		AudioServer.set_bus_mute(index, true)
		var capture: = AudioEffectCapture.new()
		capture.buffer_length = 0.5
		AudioServer.add_bus_effect(index, capture)
	_capture = AudioServer.get_bus_effect(AudioServer.get_bus_index(IN_BUS), 0) as AudioEffectCapture
	if AudioServer.get_bus_index(BUS) < 0:
		var index: = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, BUS)
		AudioServer.set_bus_send(index, "Master")
		var low: = AudioEffectHighPassFilter.new()
		low.cutoff_hz = float(Config.TeamRadio.BandLow)
		AudioServer.add_bus_effect(index, low)
		var high: = AudioEffectLowPassFilter.new()
		high.cutoff_hz = float(Config.TeamRadio.BandHigh)
		AudioServer.add_bus_effect(index, high)
		var drive: = AudioEffectDistortion.new()
		drive.mode = AudioEffectDistortion.MODE_OVERDRIVE
		drive.drive = float(Config.TeamRadio.Drive)
		drive.pre_gain = 0.0
		drive.post_gain = -2.0
		AudioServer.add_bus_effect(index, drive)

		var limiter: = AudioEffectHardLimiter.new()
		limiter.pre_gain_db = float(Config.TeamRadio.Boost)
		limiter.ceiling_db = float(Config.TeamRadio.Ceiling)
		AudioServer.add_bus_effect(index, limiter)
	apply_volume()



static func hearing() -> bool:
	return current != null and current._speakers.values().any( func(speaker: Dictionary) -> bool: return speaker["started"])



static func apply_volume() -> void :
	var index: = AudioServer.get_bus_index(BUS)
	if index >= 0:
		AudioServer.set_bus_mute(index, Settings.radio_volume <= 0.001)
		AudioServer.set_bus_volume_db(index, linear_to_db(maxf(Settings.radio_volume, 0.001)))



func _tone(sound: String) -> void :
	var stream: = Assets.sound(sound)
	if stream == null:
		return
	var player: = AudioStreamPlayer.new()
	player.stream = stream
	player.bus = BUS
	player.volume_db = linear_to_db(float(Config.TeamRadio.ToneVolume))
	player.finished.connect(player.queue_free)
	add_child(player)
	player.play()
	counts["permits" if sound == PERMIT else "rogers"] += 1





func _process(delta: float) -> void :
	if not Net.active():
		if talking or not _speakers.is_empty():
			_stop_all()
		if monitoring:
			_open_mic()
			_take(false)
		elif _mic != null:
			_close_mic()
		return
	var want: = Input.is_action_pressed("talk") and _may_talk()
	if not want:
		_held_out = false
		if talking:
			_key_up()
	elif not talking and not _held_out:
		_key_down()
	if talking:
		if _clock() - _since > float(Config.TeamRadio.MaxTalk):
			_key_up()
			_held_out = true
		else:
			_take(true)
	elif monitoring:
		_open_mic()
		_take(false)
	else:
		level = maxf(0.0, level - delta * 4.0)
	_listen()


func _may_talk() -> bool:
	var me: = Game.local_player
	if me == null or not is_instance_valid(me) or Game.ui_open:
		return false
	return not (Hud.current and Hud.current.widgets.has("chat") and (Hud.current.widgets["chat"] as HudChat).is_open())


static func _clock() -> float:
	return Time.get_ticks_msec() / 1000.0


func _key_down() -> void :
	talking = true
	_since = _clock()
	if mic_dead:
		_close_mic()
	_open_mic()
	_capture.clear_buffer()
	_state = [0, 0]
	_pending.clear()
	_sum = 0.0
	_summed = 0
	_along = 0.0
	_tone(PERMIT)
	Net.request("voice.key", [true])


func _key_up() -> void :
	talking = false
	_flush()
	_tone(ROGER)
	Net.request("voice.key", [false])


func _open_mic() -> void :
	if _mic != null:
		return
	Settings.apply_mic()
	print("TeamRadio: microphone %s (of %s), heard at %d Hz" % [AudioServer.input_device, AudioServer.get_input_device_list(), int(AudioServer.get_input_mix_rate())])
	_mic = AudioStreamPlayer.new()
	_mic.name = "Microphone"
	_mic.bus = IN_BUS
	if _fake_mic:
		var tone: = AudioStreamGenerator.new()
		tone.mix_rate = AudioServer.get_mix_rate()
		_mic.stream = tone
	else:
		_mic.stream = AudioStreamMicrophone.new()
	add_child(_mic)
	_mic.play()
	_capture.clear_buffer()
	_opened_at = _clock()
	_loudest = 0.0
	mic_dead = false
	_told_no_mic = false


func _close_mic() -> void :
	if _mic != null:
		_mic.stop()
		_mic.queue_free()
		_mic = null




func _take(sending: bool) -> void :
	if _fake_mic:
		_feed_fake()
	var settings: Dictionary = Config.TeamRadio
	var frames: = _capture.get_frames_available()
	var buffer: = _capture.get_buffer(frames) if frames > 0 else PackedVector2Array()
	var heard: = 0.0
	for frame in buffer:
		heard = maxf(heard, maxf(absf(frame.x), absf(frame.y)))
	_loudest = maxf(_loudest, heard)
	var dead: bool = _loudest < float(settings.Silent) and _clock() - _opened_at > float(settings.DeadAfter)
	if dead and not mic_dead and sending and not _told_no_mic:
		_told_no_mic = true
		Game.notified.emit(Text.m("talk.voice.noMic"), "warning", Game.local_player)
		push_warning("TeamRadio: the microphone (%s) gives only silence" % AudioServer.input_device)
	mic_dead = dead


	_envelope = maxf(heard, _envelope * 0.92)
	if _envelope > float(settings.Gate):
		var wanted: = clampf(float(settings.Target) / _envelope, 1.0, float(settings.MaxGain))
		_gain = wanted if wanted < _gain else move_toward(_gain, wanted, float(settings.GainRise) * get_process_delta_time())
	var gain: = _gain * Settings.mic_gain * 2.0
	var every: = AudioServer.get_mix_rate() / RATE
	var peak: = 0.0
	for frame in buffer:
		_sum += (frame.x + frame.y) * 0.5
		_summed += 1
		_along += 1.0
		if _along >= every:
			_along -= every
			var sample: = clampf(_sum / _summed * gain, -1.0, 1.0)
			if sending:
				_pending.append(sample)
			peak = maxf(peak, absf(sample))
			_sum = 0.0
			_summed = 0
	level = maxf(peak, level * 0.85)
	while _pending.size() >= PACKET:
		_send_packet(_pending.slice(0, PACKET))
		_pending = _pending.slice(PACKET)



func _flush() -> void :
	if _pending.size() >= 2:
		_send_packet(_pending.slice(0, _pending.size() & ~ 1))
	_pending.clear()


func _send_packet(samples: PackedFloat32Array) -> void :
	Net.send_voice(encode(samples, _state))
	counts["sent"] += 1



func _feed_fake() -> void :
	var playback: = _mic.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null:
		return
	var rate: = AudioServer.get_mix_rate()
	var frames: = playback.get_frames_available()
	var out: = PackedVector2Array()
	out.resize(frames)
	for index in frames:
		_fake_phase += 1.0 / rate
		var pitch: = 180.0 + 40.0 * sin(TAU * 3.0 * _fake_phase)
		var value: = 0.35 * sin(TAU * pitch * _fake_phase) + 0.15 * sin(TAU * pitch * 3.0 * _fake_phase)
		out[index] = Vector2(value, value) * fake_level
	playback.push_buffer(out)





func _on_key(player: Player, on: Variant) -> void :
	if not on is bool or player == null:
		return
	var peer: = NetTalk.peer_of(player)
	if peer <= 0:
		return
	if on:

		if _keyed_at.has(peer) or _clock() - float(_released_at.get(peer, -100.0)) < 0.1:
			return
		_keyed_at[peer] = _clock()
	else:
		if not _keyed_at.has(peer):
			return
		_keyed_at.erase(peer)
		_released_at[peer] = _clock()
	_keyed(peer, on)
	Net.broadcast("voice.keyed", [peer, on])



func _on_voice(peer: int, data: PackedByteArray) -> bool:
	if Net.is_host():
		var keyed: Variant = _keyed_at.get(peer)
		if keyed == null:
			return false
		if _clock() - float(keyed) > float(Config.TeamRadio.MaxTalk) + 2.0:
			return false
	_hear(peer, data)
	return true





func _keyed(peer: int, on: bool) -> void :
	if on:
		on_air[peer] = true
	else:
		on_air.erase(peer)
	if peer == NetTalk.peer_of(Game.local_player):
		return
	if on:
		_speaker(peer)["open"] = true
	elif _speakers.has(peer):
		_speakers[peer]["open"] = false



func _speaker(peer: int) -> Dictionary:
	if _speakers.has(peer):
		return _speakers[peer]
	var stream: = AudioStreamGenerator.new()
	stream.mix_rate = RATE
	stream.buffer_length = 1.0
	var player: = AudioStreamPlayer.new()
	player.stream = stream
	player.bus = BUS
	player.volume_db = linear_to_db(float(Config.TeamRadio.VoiceVolume))
	add_child(player)
	var now: = _clock()
	var speaker: = {
		"player": player, "playback": null, "queue": [], "queued": 0, "started": false, "open": true, 
		"since": now, "last": now, "ends": now, "noise": 0.0, 
	}
	_speakers[peer] = speaker
	_tone(PERMIT)
	return speaker


func _hear(peer: int, data: PackedByteArray) -> void :
	if peer == NetTalk.peer_of(Game.local_player) or data.size() < 4:
		return
	var speaker: = _speaker(peer)
	var samples: = decode(data)
	var frames: = PackedVector2Array()
	frames.resize(samples.size())
	var hiss: = float(Config.TeamRadio.Static)
	for index in samples.size():
		var value: = samples[index] + randf_range( - hiss, hiss)
		frames[index] = Vector2(value, value)
	(speaker["queue"] as Array).append(frames)
	speaker["queued"] += frames.size()
	speaker["last"] = _clock()
	counts["heard"] += 1




func _listen() -> void :
	var now: = _clock()
	var hold: = int(float(Config.TeamRadio.Buffer) * RATE)
	for peer: int in _speakers.keys():
		var speaker: Dictionary = _speakers[peer]
		var player: AudioStreamPlayer = speaker["player"]
		if not speaker["started"]:

			var ready: bool = int(speaker["queued"]) >= hold or ( not speaker["open"] and int(speaker["queued"]) > 0)
			if now - float(speaker["since"]) >= float(Config.TeamRadio.PermitLength) and ready:
				speaker["started"] = true
				player.play()
				speaker["playback"] = player.get_stream_playback()
				speaker["ends"] = now
		var playback: = speaker["playback"] as AudioStreamGeneratorPlayback
		var queue: Array = speaker["queue"]
		if playback != null:
			while not queue.is_empty() and playback.get_frames_available() >= (queue[0] as PackedVector2Array).size():
				var frames: PackedVector2Array = queue.pop_front()
				playback.push_buffer(frames)
				speaker["queued"] -= frames.size()
				speaker["ends"] = maxf(float(speaker["ends"]), now) + frames.size() / float(RATE)
		var quiet: = now - float(speaker["last"])
		var gone: bool = quiet > float(Config.TeamRadio.LostAfter) and now - float(speaker["since"]) > float(Config.TeamRadio.LostAfter)
		if ( not speaker["open"] or gone) and queue.is_empty() and quiet > 0.12 and now >= float(speaker["ends"]):
			_close(peer)



func _close(peer: int) -> void :
	var speaker: Variant = _speakers.get(peer)
	if speaker == null:
		return
	_speakers.erase(peer)
	(speaker["player"] as Node).queue_free()
	_tone(ROGER)
	if on_air.has(peer) and not _keyed_at.has(peer):
		on_air.erase(peer)


func _stop_all() -> void :
	talking = false
	_held_out = false
	level = 0.0
	for peer: int in _speakers.keys():
		(_speakers[peer]["player"] as Node).queue_free()
	_speakers.clear()
	on_air.clear()
	_keyed_at.clear()
	_released_at.clear()
	_close_mic()







static func encode(samples: PackedFloat32Array, state: Array) -> PackedByteArray:
	var predicted: int = state[0]
	var index: int = state[1]
	var out: = PackedByteArray()
	out.resize(3 + ((samples.size() + 1) >> 1))
	out.encode_s16(0, predicted)
	out[2] = index
	for at in samples.size():
		var sample: = clampi(int(samples[at] * 32767.0), -32768, 32767)
		var step: int = STEPS[index]
		var difference: = sample - predicted
		var nibble: = 0
		if difference < 0:
			nibble = 8
			difference = - difference
		var delta: = step >> 3
		if difference >= step:
			nibble |= 4
			difference -= step
			delta += step
		if difference >= step >> 1:
			nibble |= 2
			difference -= step >> 1
			delta += step >> 1
		if difference >= step >> 2:
			nibble |= 1
			delta += step >> 2
		predicted = clampi(predicted - delta if nibble & 8 else predicted + delta, -32768, 32767)
		index = clampi(index + INDEX_STEPS[nibble], 0, 88)
		if at & 1 == 0:
			out[3 + (at >> 1)] = nibble
		else:
			out[3 + (at >> 1)] |= nibble << 4
	state[0] = predicted
	state[1] = index
	return out


static func decode(data: PackedByteArray) -> PackedFloat32Array:
	var out: = PackedFloat32Array()
	if data.size() < 4:
		return out
	var predicted: = data.decode_s16(0)
	var index: = clampi(data[2], 0, 88)
	out.resize((data.size() - 3) * 2)
	for at in out.size():
		var nibble: int = (data[3 + (at >> 1)] >> (4 * (at & 1))) & 15
		var step: int = STEPS[index]
		var delta: = step >> 3
		if nibble & 4:
			delta += step
		if nibble & 2:
			delta += step >> 1
		if nibble & 1:
			delta += step >> 2
		predicted = clampi(predicted - delta if nibble & 8 else predicted + delta, -32768, 32767)
		index = clampi(index + INDEX_STEPS[nibble], 0, 88)
		out[at] = predicted / 32768.0
	return out
