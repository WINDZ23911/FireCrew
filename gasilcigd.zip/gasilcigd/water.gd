extends ProofDebug




var _told: Array = []


func _listen() -> void :
	_told.clear()
	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void : _told.append([Text.say(text, "en"), kind]))


func _heard(words: String) -> int:
	return _told.filter( func(entry: Array) -> bool: return String(entry[0]).contains(words)).size()


func _rig(vehicle: Vehicle) -> Dictionary:
	for rig: Dictionary in HoseService.current.rigs:
		if rig["vehicle"] == vehicle:
			return rig
	return {}


func _outlet(vehicle: Vehicle, index: = 0) -> Dictionary:
	var found: Array = HoseService.current.lines.filter( func(l: Dictionary) -> bool: return l["kind"] == "outlet" and l["rig"] != null and l["rig"]["vehicle"] == vehicle)
	return found[index]



func _at_pumper() -> Vehicle:
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	var line: = _outlet(pumper)
	player.teleport(_ground(line["source"].global_position + pumper.global_basis.x * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	return pumper





func _scenario_pressure() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: Vehicle = await _at_pumper()
	var rig: = _rig(pumper)
	var line: = _outlet(pumper)
	var rolls_before: = int(rig["rolls"]["attack"])
	print("pressure: outlet says '%s' with %d rolls aboard" % [Text.say(line["prompt"].action, "en"), rolls_before])
	_check(Text.say(line["prompt"].action, "en") == Text.say(Text.m("gear.hose.kinds.outlet.take"), "en"), "a free outlet with rolls aboard offers to take the hose")
	line["prompt"].triggered.emit(player)
	await _wait(0.3)
	print("pressure: after one press: holding %s, roll in hand %s, rolls %d -> %d, told %s" % [hoses.line_of(player) != null, player.get_attr("HoseRoll"), rolls_before, int(rig["rolls"]["attack"]), _told])
	_check(is_same(hoses.line_of(player), line) and player.get_attr("HoseRoll") == null and int(rig["rolls"]["attack"]) == rolls_before - 1, "one press at the outlet takes a roll off the truck and couples it")
	_check(_heard("lockers first") == 0, "no 'take it from the lockers first' refusal")
	var hose: HoseLine = line["hose"]
	_check(hose.swell < 0.01 and not line.get("charged", true), "the new line lies flat, not charged")


	for step in 3:
		player.teleport(player.global_position + pumper.global_basis.x * 4.0)
		await _wait(0.2)
	_look_at(player.head_position() + pumper.global_basis.x * 20.0)
	var before: = pumper.water
	Input.action_press("fire")
	await _wait(0.6)
	var charging: bool = player.get_attr("Charging") == true
	var mid_swell: = hose.swell
	var water_mid: = pumper.water
	var nozzle: Nozzle = line["nozzle"]
	_view(player.global_position + Vector3(-6, 5, 8), player.global_position + Vector3(0, 2, 0))
	await _snap("charging")
	print("pressure: 0.6 s in: charging %s, swell %.2f, tank %.0f -> %.0f, bale %.2f" % [charging, mid_swell, before, water_mid, nozzle._bale.get_parent().rotation.x])
	_check(charging and mid_swell > 0.1 and mid_swell < 0.9 and water_mid >= before - 0.5, "charging: the hose swells and no water comes yet")
	_check(nozzle._bale.get_parent().rotation.x > 0.3, "the bale is thrown back while the nozzle is open")
	await _wait(float(Config.Water.Charge.Time) + 0.6)
	print("pressure: charged %s, swell %.2f, spraying %s, tank %.0f, pressure %s pump %s" % [line.get("charged"), hose.swell, player.get_attr("Spraying"), pumper.water, player.get_attr("Pressure"), player.get_attr("PumpShare")])
	_check(line.get("charged", false) and hose.swell >= 0.99 and player.get_attr("Spraying") == true and pumper.water < water_mid - 1.0, "charged, the water comes")
	var near: = float(player.get_attr("Pressure", 0.0))
	_check(near >= 0.9, "close to the truck the nozzle has nearly all the pressure")
	await _snap("flowing")

	var ring_before: float = nozzle._ring.get_parent().rotation.z
	await _tap("flow")
	await _tap("pattern")
	await _wait(0.6)
	print("pressure: ring %.2f -> %.2f, sleeve %.2f" % [ring_before, nozzle._ring.get_parent().rotation.z, nozzle._sleeve.get_parent().rotation.z])
	_check(absf(nozzle._ring.get_parent().rotation.z - ring_before) > 0.2 and absf(nozzle._sleeve.get_parent().rotation.z) > 0.3, "the flow ring and the pattern sleeve turn")
	await _tap("pattern")
	player.set_attr("Flow", 2)

	var plate: HudWater = _find_plate()
	var said: = plate._pressure.text if plate != null else ""
	print("pressure: water plate: '%s'" % said)
	_check(said.contains("BAR"), "the water plate shows the pump's and the nozzle's pressure")
	Input.action_release("fire")
	await _wait(0.3)


	var length: = float(hoses.kind_of("outlet")["length"])
	var out: = pumper.global_basis.x
	var walked: = 0.0
	while float(player.get_attr("HoseLength", 0.0)) < length * 0.8 and walked < length * 1.2:
		player.teleport(player.global_position + out * 3.0)
		walked += 3.0
		await _wait(0.12)
	Input.action_press("fire")
	await _wait(1.0)
	var far: = float(player.get_attr("Pressure", 1.0))
	print("pressure: %.0f of %.0f studs paid out: pressure %.2f (near %.2f); jet speed %.1f -> %.1f" % [float(player.get_attr("HoseLength", 0.0)), length, far, near, HoseService.stream_speed(near), HoseService.stream_speed(far)])
	_check(far < near - 0.05 and far >= 1.0 - float(Config.Water.Pressure.LengthLoss) - 0.06, "a long line loses a little pressure (about LengthLoss at full length)")
	_check(HoseService.stream_speed(far) < HoseService.stream_speed(near), "and its jet leaves slower, so it reaches less far")
	Input.action_release("fire")
	await _wait(0.3)

	var starved: = minf(1.0, float(Config.Hose.PumpRate) / (float(Config.Hose.WaterUse) * 1.6 * 4.0))
	_check(HoseService.stream_speed(starved) < HoseService.stream_speed(1.0) * 0.9, "four HIGH lines on one pump throw visibly shorter (share %.2f)" % starved)
	await _done()


func _find_plate() -> HudWater:
	var found: = get_tree().root.find_children("*", "HudWater", true, false)
	return found[0] if not found.is_empty() else null




func _scenario_tether() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: Vehicle = await _at_pumper()
	var line: Dictionary = hoses.lines.filter( func(l: Dictionary) -> bool: return l["kind"] == "outlet" and l["rig"] != null and l["rig"]["vehicle"] == pumper)[0]
	player.teleport(_ground(line["source"].global_position + line["source"].global_position.direction_to(pumper.global_position).slide(Vector3.UP).normalized() * -3.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	line["prompt"].triggered.emit(player)
	await _wait(0.3)
	_check(is_same(hoses.line_of(player), line), "an outlet's hose in hand")
	var length: = float(hoses.kind_of("outlet")["length"])
	print("tether: an attack line is tuned for %.0f studs (Config.Hose.AttackLength)" % length)
	var out: = pumper.global_basis.z
	var steps: = 0
	var start_at: = player.global_position
	while steps < int(length * 1.6 / 2.0):
		player.teleport(player.global_position + out * 2.0)
		steps += 1
		await get_tree().physics_frame
		await get_tree().physics_frame
		if steps % 10 == 0:
			await _wait(0.1)
	await _wait(0.5)
	var paid: = float(player.get_attr("HoseLength", 0.0))
	var gone: = player.global_position.distance_to(start_at)
	print("hoselong: walked %.0f studs away (%.0f as the crow flies); paid %.1f of a %.0f stud line; still holding %s; told %s" % [steps * 2.0, gone, paid, length, is_same(hoses.line_of(player), line), _told])
	_check(is_same(hoses.line_of(player), line), "walking on past the hose's length does not pull it off")
	_check(paid > length + 20.0 and gone > length, "nothing holds the holder back: the hose is as long as it is walked")
	_check(player.get_attr("HoseMax") == null, "no most length is read off it any more")
	var plate: = _find_plate()
	if plate:
		await _wait(0.3)
		print("hoselong: the plate says '%s'" % plate._hose.text)
		_check(plate._hose.text.contains(str(int(paid))) and not plate._hose.text.contains("/"), "the plate counts the hose out with no end to it")
	await _done()




func _scenario_oneroll() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: Vehicle = await _at_pumper()
	var rig: = _rig(pumper)
	rig["rolls"]["attack"] = 0
	hoses._add_rolls(rig, "attack", 0)
	var line: = _outlet(pumper)
	var label: = Text.say(line["prompt"].action, "en")
	line["prompt"].triggered.emit(player)
	await _wait(0.4)
	print("oneroll: no rolls aboard: label '%s'; told %s" % [label, _told])
	_check(label == Text.say(Text.m("water.rolls.attackCouple"), "en"), "with no rolls aboard the outlet offers to couple one, not to take one")
	_check(_told.size() == 1 and hoses.line_of(player) == null, "one refusal, one message")

	var tanker: = Vehicle.named("Tanker")
	_park(tanker, pumper.global_position + Vector3(-30, 0, 0))
	await _wait(0.5)
	_check( await _take_roll(tanker, "attack"), "a roll from the tanker's lockers")
	await _wait(1.1)
	line["prompt"].triggered.emit(player)
	await _wait(0.3)
	_check(is_same(hoses.line_of(player), line) and is_same(line.get("roll"), _rig(tanker)), "the carried roll is coupled at the pumper's outlet and goes back to the tanker")

	hoses.disconnect_line(line)
	await _wait(1.1)
	_told.clear()
	var supply: Dictionary = rig["supply"]
	supply["prompt"].triggered.emit(player)
	await _wait(0.3)
	print("oneroll: at the intake: supply %s, told %s" % [supply["state"], _told])
	_check(supply["state"] == "carried" and supply["player"] == player, "one press at the intake takes the supply hose")
	await _done()




func _scenario_tankwarn() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: Vehicle = await _at_pumper()
	var line: = _outlet(pumper)
	line["prompt"].triggered.emit(player)
	await _wait(0.3)
	for step in 3:
		player.teleport(player.global_position + pumper.global_basis.x * 4.0)
		await _wait(0.2)
	_look_at(player.head_position() + pumper.global_basis.x * 20.0)
	Input.action_press("fire")
	await _wait(float(Config.Water.Charge.Time) + 0.5)
	var capacity: = pumper.capacity
	for share: float in [0.5, 0.25, 0.0]:
		pumper.water = capacity * share + 12.0
		await _wait(1.6)
		if share == 0.25:
			pumper.water = capacity * 0.04
			await _wait(0.3)
			print("tankwarn: at 4 %%: sputter %s" % [line["jet"].sputter])
			_check(line["jet"].sputter, "the jet sputters in the tank's last litres")
			await _snap("sputter")
	await _wait(1.0)
	Input.action_release("fire")
	var half: = _heard("tank at 50")
	var quarter: = _heard("tank at 25")
	var empty: = _heard("tank is empty!")
	print("tankwarn: heard half %d, quarter %d, empty %d; told %s" % [half, quarter, empty, _told])
	_check(half == 1 and quarter == 1 and empty == 1, "the tank called out once each at half, a quarter and empty")
	_check(_told.any( func(e: Array) -> bool: return String(e[0]).contains("tank at 25") and e[1] == "warning"), "as a warning")

	pumper.water = capacity
	await _wait(0.5)
	_check(int(hoses._tank_said.get(pumper, -1)) == 0, "filled again, the calls are ready to be said again")
	await _done()




func _scenario_hydrants() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var counts: = {}
	for hydrant: Dictionary in hoses.hydrants + hoses.broken_hydrants:
		counts[hydrant["kind"]] = int(counts.get(hydrant["kind"], 0)) + 1
	print("hydrants: %s working, %s out of order: %s" % [hoses.hydrants.size(), hoses.broken_hydrants.size(), counts])
	_check(counts.size() >= 4, "every kind of hydrant is in the town")
	_check(hoses.broken_hydrants.all( func(h: Dictionary) -> bool: return not hoses.hydrants.has(h)), "out-of-order hydrants are not among those anything chooses")
	var rings: = {}
	for kind: Dictionary in Config.Water.Hydrants.Kinds:
		rings[HoseService.hydrant_rings(kind["Name"])] = true
	_check(rings.size() == 4 and hoses.hydrant_kind_at(hoses.hydrants[0]["position"]) == hoses.hydrants[0]["kind"], "each kind has its own number of rings, and the radar finds a hydrant's kind")

	var weak: Dictionary = {}
	for hydrant: Dictionary in hoses.hydrants:
		if hydrant["kind"] == "weak" and (weak.is_empty() or hydrant["position"].distance_to(Vector3(0, 0, 0)) < weak["position"].distance_to(Vector3(0, 0, 0))):
			weak = hydrant
	var pumper: = Vehicle.named("Fire Truck")
	var at: = _open_spot(weak["position"], Vector3(1, 0, 0), pumper)
	_park(pumper, at)
	await _wait(0.8)
	var rig: = _rig(pumper)
	player.teleport(_ground(pumper.intake["node"].global_position + pumper.global_basis.z * 2.5) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	rig["supply"]["prompt"].triggered.emit(player)
	await _wait(0.3)
	player.teleport(_ground(weak["position"] + Vector3(2.5, 0, 0)) + Vector3(0, 0.3, 0))
	await _wait(0.5)
	weak["prompt"].triggered.emit(player)
	await _wait(0.3)
	pumper.water = pumper.capacity * 0.5
	var start: = pumper.water
	await _wait(2.0)
	var charging_fill: = pumper.water - start
	_view(weak["position"] + Vector3(8, 6, 8), weak["position"])
	await _snap("charging")
	await _wait(float(Config.Water.Charge.Supply))
	var from: = pumper.water
	await _wait(2.0)
	var rate: = (pumper.water - from) / 2.0
	print("hydrants: weak hydrant (%s L/s): %.0f L in the first 2 s (charging), then %.1f L/s; supply %s" % [weak["flow"], charging_fill, rate, rig["supply"]["state"]])
	_check(rig["supply"]["state"] == "connected" and charging_fill < 1.0, "the supply hose charges before the tank fills")
	_check(absf(rate - float(weak["flow"])) < float(weak["flow"]) * 0.25, "a weak hydrant fills at its own flow")
	await _snap("filling")

	if not hoses.broken_hydrants.is_empty():
		hoses.stow_supply(rig)
		await _wait(1.1)
		var broken: Dictionary = hoses.broken_hydrants[0]
		player.teleport(_ground(pumper.intake["node"].global_position + pumper.global_basis.z * 2.5) + Vector3(0, 0.3, 0))
		await _wait(0.3)
		rig["supply"]["prompt"].triggered.emit(player)
		await _wait(0.3)
		_told.clear()
		var shown_to: bool = broken["prompt"].shown_to(player)
		broken["prompt"].triggered.emit(player)
		await _wait(0.3)
		print("hydrants: out of order: offered to a supply carrier %s; told %s; label '%s'" % [shown_to, _told, Text.say(broken["prompt"].action, "en")])
		_check(shown_to and _heard("out of order") == 1 and Text.say(broken["prompt"].action, "en") == "Out of order", "an out-of-order hydrant says so")
		hoses.stow_supply(rig)

	var small: = HoseService.powder_power(PackedVector3Array([Vector3(1000, 0, 1000), Vector3(1001, 0, 1000)]), 4.0)
	_check(is_equal_approx(small, float(Config.Water.Powder.Small)) and float(Config.Water.Powder.Full) < small, "the extinguisher hits hard only on small flames")
	await _done()




func _scenario_glass() -> void :
	await _wait(1.0)
	var hoses: = HoseService.current
	var house: = _house("Family house")
	var panes: Array = []
	for room_name: String in house.rooms:
		for pane: Dictionary in house.rooms[room_name]["panes"]:
			if not pane["broken"] and int(house.rooms[room_name]["floor"]) == 0:
				panes.append(pane)
	if not _check(panes.size() >= 2, "a house with two whole panes"):
		await _done()
		return
	var hits: Array = []
	var aimed: Array = []
	for pane: Dictionary in panes:
		var hit: = _hit_on(house, pane)
		if not hit.is_empty():
			hits.append(hit)
			aimed.append(pane)
		if hits.size() == 2:
			break
	panes = aimed
	print("glass: %d panes a jet can be aimed at" % hits.size())
	if not _check(hits.size() == 2, "a jet can be aimed at two panes"):
		await _done()
		return

	var wall: = Game.world.raycast(house.position + Vector3(0, 60, 0), house.position, World.LAYER_SOLID)
	hits.append(wall)
	var holder: = {}

	for tick in 40:
		holder["glass_seen"] = false
		if tick % 3 != 2:
			hoses._landed(holder, hits[tick % 3], 0.1, Vector3.FORWARD, player, true, 1.0)
		if not holder["glass_seen"]:
			HoseService._glass_off(holder, 0.1)
	print("glass: after a 4 s sweep: %s" % [panes.slice(0, 2).map( func(p: Dictionary) -> String: return "broken" if p["broken"] else ("cracked" if p["cracked"] else "whole"))])
	_check( not panes[0]["broken"] and not panes[1]["broken"], "a jet swept across the panes breaks none")

	holder = {}
	for tick in 40:
		hoses._landed(holder, hits[0], 0.1, Vector3.FORWARD, player, false, 1.0)
	_check( not panes[0]["broken"], "fog held on a pane does not break it")

	holder = {}
	var cracked_at: = -1.0
	var broke_at: = -1.0
	for tick in 30:
		holder["glass_seen"] = false
		hoses._landed(holder, hits[0], 0.1, Vector3.FORWARD, player, true, 1.0)
		if panes[0]["cracked"] and cracked_at < 0.0:
			cracked_at = (tick + 1) * 0.1
		if panes[0]["broken"]:
			broke_at = (tick + 1) * 0.1
			break
	print("glass: held jet: cracked at %.1f s, broken at %.1f s (Hold %s)" % [cracked_at, broke_at, Config.Water.Glass.Hold])
	_check(cracked_at > 0.0 and cracked_at < broke_at, "a jet held on a pane cracks it first")
	_check(absf(broke_at - float(Config.Water.Glass.Hold)) < 0.15, "and breaks it after Water.Glass.Hold seconds of a full line")
	_view(panes[0]["position"] + _out(house, panes[0]) * 12.0 + Vector3(0, 3, 0), panes[0]["position"])
	await _snap("broken")
	await _done()



func _out(house: House, pane: Dictionary) -> Vector3:
	var size: Vector3 = pane["size"]
	var basis: Basis = (pane["node"] as Node3D).global_basis
	var normal: = basis.z if size.z <= size.x and size.z <= size.y else (basis.x if size.x <= size.y else basis.y)
	normal = Vector3(normal.x, 0, normal.z).normalized()
	if normal.dot(pane["position"] - house.position) < 0.0:
		normal = - normal
	return normal



func _hit_on(house: House, pane: Dictionary) -> Dictionary:
	var at: Vector3 = pane["position"]
	var out: = _out(house, pane)
	var across: = out.cross(Vector3.UP)

	for way: float in [1.0, -1.0]:
		for off: Vector2 in [Vector2(0.6, 0.5), Vector2(-0.6, 0.5), Vector2(0.6, -0.5), Vector2(-0.6, -0.5), Vector2(1.0, 0.0), Vector2(0.0, 1.0)]:
			var target: = at + across * off.x + Vector3(0, off.y, 0)
			var hit: = Game.world.raycast(target + out * way * 6.0, target - out * way * 0.5, World.LAYER_QUERY | World.LAYER_SOLID)
			if not hit.is_empty() and HoseService._pane_of(hit) != null and HoseService._pane_of(hit)["id"] == pane["id"]:
				return hit
	return {}




func _scenario_waterdamage() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var fire: = FireService.current
	var house: = _house("Family house")
	VictimService.current.forced = 0
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	Alarm.begin()
	fire.run_incident(house)
	await _wait(1.0)
	var nodes: Array = fire.incident["group"]["nodes"]
	var burning: Dictionary = {}
	for node: Dictionary in nodes:
		if node["burning"] and node["room"] != null:
			burning[node["room"]] = true
	var dry_room: = ""
	var wet_room: = ""
	for room_name: String in house.rooms:
		if burning.has(room_name):
			wet_room = room_name
		elif dry_room == "" and nodes.any( func(n: Dictionary) -> bool: return n["room"] == room_name):
			dry_room = room_name
	if not _check(dry_room != "" and wet_room != "", "a burning room and one with no fire"):
		await _done()
		return
	var dry_at: = _middle(house, house.rooms[dry_room])
	var wet_at: = _middle(house, house.rooms[wet_room])
	var nothing: = {"hits": 0, "progress": -1.0, "kills": 0}

	hoses._water_damage(player, wet_at, 200.0, nothing)
	_check(hoses.water_damage() == 0.0, "water where the fire is costs nothing")


	var health_before: = _health(nodes)
	for tick in 20:
		hoses._water_damage(player, dry_at, 25.0, nothing)
	var damage: = hoses.water_damage()
	var health_after: = _health(nodes)
	print("waterdamage: 500 L in the %s (no fire): damage %.1f %%, health %.1f -> %.1f; check %s; told %s" % [dry_room, damage, health_before, health_after, Alarm.checks.get("water"), _told])
	_check(damage > 1.0 and health_after < health_before - 1.0, "water in a room with no fire costs the building's health")
	_check(Alarm.checks.has("water") and Alarm.checks["water"] == (damage < float(Config.Water.Damage.CheckBelow)), "the report has the water-damage check")
	_check(_heard("Water damage") >= 1, "the one spraying is told")
	for tick in 400:
		hoses._water_damage(player, dry_at, 25.0, nothing)
	_check(hoses.water_damage() <= float(Config.Water.Damage.Most) + 0.01, "it stops at Water.Damage.Most")
	Alarm.end()
	await _done()



func _health(nodes: Array) -> float:
	var burnt: = 0.0
	for node: Dictionary in nodes:
		burnt += 1.0 - node["fuel"] / float(node["material"]["burn"])
	return 100.0 * (1.0 - burnt / (nodes.size() * float(FireService.current.settings()["LossShare"])))


func _middle(house: House, room: Dictionary) -> Vector3:
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	return house.lot * ((low + high) / 2.0)




func _scenario_dispatch() -> void :
	await _wait(1.0)
	var house: = _house("Family house")
	var at: Vector3 = house.position
	var address: = Radio.address_of(at)
	print("dispatch: the address at the family house: %s (piece %s)" % address)
	_check(String(address[0]).length() > 4 and address[1] != "", "a call's place has a street address")
	var kinds: = ["fire", "alarm", "crash", "tree", "flood", "hazmat", "rescue", "medical", "accident"]
	var missing: Array = []
	for kind: String in kinds:
		var said: = Radio.dispatch_line({"kind": kind, "pos": at, "alarm": 2, "victims": 1})
		var en: = Text.say(said[0], "en")
		var sl: = Text.say(said[0], "sl")
		print("dispatch: %s: %s | %s" % [kind, en, sl])
		if not (en.contains(String(address[0])) and en.contains("level II") and sl.contains("II") and not en.contains("radio.kinds") and not sl.contains("radio.kinds")):
			missing.append(kind + " words")
		for language: String in ["sl", "en"]:
			for piece: String in said[1]:
				var name: = ("radio_" + piece) if piece.begins_with("street_") else "radio_%s_%s" % [language, piece]
				if Assets.sound(name) == null:
					missing.append(name)
	print("dispatch: missing %s" % [missing])
	_check(missing.is_empty(), "every kind's call-out says the kind, the address and the level, with its voice, in both languages")
	for key: String in ["radio.arrived", "radio.underControl", "radio.allClear"]:
		_check(Text.has(key), "the crew's line %s" % key)

	var told: Array = []
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : told.append(Text.say(text, "en")))
	Game.set_incident({"kind": "tree", "pos": at, "name": "Tree", "alarm": 1})
	await _wait(float(Config.Dispatch.Delay) + 0.8)
	print("dispatch: heard %s" % [told])

	var opener: = Text.say(Text.m("radio.dispatch"), "en").get_slice(" ", 0)
	_check(told.any( func(t: String) -> bool: return t.begins_with(opener) and t.contains(String(address[0]))), "a call coming in is called out")
	Game.set_incident({})
	await _done()




func _scenario_supplyfirst() -> void :
	await _wait(1.0)
	_listen()
	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	var rig: Dictionary = hoses.rigs.filter( func(r: Dictionary) -> bool: return r["vehicle"] == pumper)[0]
	var hydrant: Dictionary = hoses.hydrants[0]
	var best: = INF
	for other: Dictionary in hoses.hydrants:
		var distance: float = other["position"].distance_to(Vector3(-12, 0, -22))
		if distance < best:
			best = distance
			hydrant = other
	var at: Vector3 = hydrant["position"]
	_park(pumper, at + Vector3(24, 0, 30))
	await _wait(1.0)
	if rig["supply"]["state"] != "stowed":
		hoses.stow_supply(rig)
	pumper.water = 0.0
	_check( await _take_roll(pumper, "supply"), "the pumper's supply roll in hand")

	player.teleport(_ground(pumper.intake["node"].global_position + pumper.global_basis.z * 4.0) + Vector3(0, 0.3, 0))
	await _wait(0.6)
	var marks: = CouplingMarks.current
	_check(marks != null, "the coupling marks are there")
	if marks:
		var kinds: = marks.shown_kinds()
		print("supplyfirst: with a supply roll in hand the marks are on %s" % [kinds])
		_check(kinds.has("intake") and kinds.has("hydrant") and not kinds.has("outlet"), "a supply roll marks the intake and the hydrants, not the outlets")
	await _snap("marks_supply")

	player.teleport(_ground(at + Vector3(0, 0, 4)) + Vector3(0, 0.3, 0))
	await _wait(0.6)
	_check(hydrant["prompt"].shown_to(player), "the hydrant offers the roll in hand its coupling")
	hoses._on_hydrant(hydrant, player)
	await _wait(0.5)
	print("supplyfirst: at the hydrant: loose %s, roll in hand %s, holding '%s', told %s" % [hoses._loose.has(player), player.get_attr("HoseRoll"), player.holding, _told])
	_check(hoses._loose.has(player) and player.get_attr("HoseRoll") == null, "the hose is on the hydrant, its end in hand")

	var intake: Vector3 = pumper.intake["node"].global_position
	var steps: = 0
	while player.global_position.distance_to(intake) > 5.0 and steps < 60:
		var way: = (intake - player.global_position)
		way.y = 0.0
		player.teleport(player.global_position + way.normalized() * 2.0)
		steps += 1
		await get_tree().physics_frame
		await get_tree().physics_frame
	await _wait(0.5)
	var laid: int = hoses._loose[player]["hose"].points.size() if hoses._loose.has(player) else -1
	print("supplyfirst: at the intake after %d steps, %d points laid, length %.0f" % [steps, laid, float(player.get_attr("HoseLength", 0.0))])
	_check(laid >= 3, "the hose lies along the way walked from the hydrant")
	if marks:
		var kinds: = marks.shown_kinds()
		print("supplyfirst: carrying from the hydrant the marks are on %s" % [kinds])
		_check(kinds.has("intake") and not kinds.has("hydrant"), "carrying the hose from the hydrant marks the intake alone")
	await _snap("marks_carry")
	hoses._on_intake(rig, player)
	await _wait(0.5)
	var supply: Dictionary = rig["supply"]
	print("supplyfirst: connected: state %s, hydrant feeds %s, points %d, loose %s, told %s" % [supply["state"], hydrant["rig"] != null, supply["hose"].points.size() if is_instance_valid(supply["hose"]) else -1, hoses._loose.has(player), _told])
	_check(supply["state"] == "connected" and is_same(hydrant["rig"], rig) and not hoses._loose.has(player), "on the intake the hose becomes the truck's supply from that hydrant")
	_check(is_instance_valid(supply["hose"]) and supply["hose"].points.size() >= laid - 1 and supply["hose"].start == pumper.intake["node"], "the line runs from the intake along the way it was laid")
	await _wait(float(Config.Water.Charge.Supply) + 2.0)
	print("supplyfirst: tank %.0f L after the charge" % pumper.water)
	_check(pumper.water > 10.0, "the hydrant fills the tank")
	await _snap("fed")

	var rolls_before: = int(rig["rolls"]["supply"])
	hoses._on_hydrant(hydrant, player)
	await _wait(0.3)
	print("supplyfirst: disconnected: state %s, rolls %d -> %d" % [supply["state"], rolls_before, int(rig["rolls"]["supply"])])
	_check(supply["state"] == "stowed" and int(rig["rolls"]["supply"]) == rolls_before + 1, "the hydrant's prompt takes it off and the roll goes back in the truck")
	await _done()
