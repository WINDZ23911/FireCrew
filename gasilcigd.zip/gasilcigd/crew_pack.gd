class_name CrewPack
extends RefCounted








const REACH: = 260.0


const FAR: = 150.0

static var _claimed: Dictionary = {}



static func left_out() -> Array:
	var found: Array = []
	var cordon: = Cordon.current
	if cordon != null:
		for cone: Dictionary in cordon.cordon["cones"]:
			var model: Node3D = cone["model"]
			if cone["truck"] == null or not is_instance_valid(model):
				continue
			found.append(_piece("cone", model.get_meta("prompt"), cone["truck"], cone, func() -> bool: return cordon.cordon["cones"].any( func(other: Dictionary) -> bool: return is_same(other, cone))))
		for tape: Dictionary in cordon.cordon["tapes"]:
			var model: Node3D = tape["model"]
			if tape["truck"] == null or not is_instance_valid(model):
				continue
			found.append(_piece("tape", model.get_meta("prompts")[0], tape["truck"], tape, func() -> bool: return cordon.cordon["tapes"].any( func(other: Dictionary) -> bool: return is_same(other, tape))))
	var tools: = ToolService.current
	if tools != null:
		for item: Dictionary in tools.items:
			if item["standing"] and item.get("pick_up") != null and is_instance_valid(item["pick_up"]):
				var pick_up: Prompt = item["pick_up"]
				found.append(_piece("tool", pick_up, item["vehicle"], item, func() -> bool: return item["standing"] and is_same(item["pick_up"], pick_up)))
	var hoses: = HoseService.current
	if hoses != null:
		for rig: Dictionary in hoses.rigs:
			var supply: Dictionary = rig["supply"]
			if supply["state"] != "connected":
				continue

			var end: Variant = supply["hydrant"] if supply["hydrant"] != null else supply["donor"]
			if end is Dictionary and end.get("prompt") is Prompt:
				found.append(_piece("supply", end["prompt"], rig["vehicle"], rig, func() -> bool: return supply["state"] == "connected"))
		var divider: Dictionary = hoses.divider
		if divider["state"] == "placed":
			var in_use: = false
			for branch: Dictionary in divider["lines"]:
				in_use = in_use or branch["player"] != null
			var feed: Variant = divider["feed"]

			if feed != null and not in_use:
				found.append(_piece("feed", feed["prompt"], feed["rig"]["vehicle"], feed, func() -> bool: return feed.get("feeding", false)))
			elif feed == null and not in_use and is_instance_valid(divider["pickup"]):
				found.append(_piece("divider", divider["pickup"], divider["vehicle"], divider, func() -> bool: return divider["state"] == "placed"))
	return found


static func _piece(kind: String, prompt: Prompt, truck: Variant, item: Dictionary, out: Callable) -> Dictionary:
	return {"kind": kind, "prompt": prompt, "at": prompt.global_position, "truck": truck, "item": item, "out": out}



static func carries_kit(mind: Crewman) -> bool:
	var body: = mind.body
	if ToolService.current and not ToolService.current.carried(body).is_empty():
		return true
	if Cordon.current and Cordon.current.items.any( func(item: Dictionary) -> bool: return item["holder"] == body):
		return true
	if HoseService.current and HoseService.current.divider["state"] == "carried" and HoseService.current.divider["player"] == body:
		return true
	return AirService.current != null and AirService.current.sets.has(body)



static func has_work(mind: Crewman) -> bool:
	if carries_kit(mind):
		return true
	var from: = mind.body.global_position
	return left_out().any( func(piece: Dictionary) -> bool: return piece["at"].distance_to(from) < REACH)



static func anything(service: CrewService) -> bool:
	return service.members.any( func(mind: Crewman) -> bool: return has_work(mind))




static func claim(mind: Crewman, skipped: Array) -> Dictionary:
	var from: = mind.body.global_position
	var best: Dictionary = {}
	var best_distance: = REACH
	for piece: Dictionary in left_out():
		var prompt: Prompt = piece["prompt"]
		if prompt in skipped or _taken(prompt, mind):
			continue
		var distance: float = piece["at"].distance_to(from)
		if distance < best_distance:
			best_distance = distance
			best = piece
	if not best.is_empty():
		_claimed[best["prompt"]] = mind
	return best



static func at_hand(mind: Crewman, truck: Variant) -> bool:
	return truck is Vehicle and is_instance_valid(truck) and truck.global_position.distance_to(mind.body.global_position) < FAR


static func release(piece: Dictionary) -> void :
	_claimed.erase(piece["prompt"])



static func _taken(prompt: Prompt, mind: Crewman) -> bool:
	var other: Variant = _claimed.get(prompt)
	if other == null or other == mind:
		return false
	if not is_instance_valid(other) or not other.job is JobPackUp:
		_claimed.erase(prompt)
		return false
	return true
