class_name Flame
extends Node3D






const HOT: = Color(1.0, 150 / 255.0, 40 / 255.0)
const COOL: = Color(205 / 255.0, 235 / 255.0, 1.0)
const GLOW: = Color(1.0, 140 / 255.0, 40 / 255.0)
const RESIZE_STEP: = 0.06
const WIND: = World.WIND


const SMOKE_DARK: = Color(0.2, 0.19, 0.19)
const SMOKE_LIT: = [[0.0, 0.0], [0.25, 1.0], [1.0, 1.0]]
const FLARE_OVER: = 0.4
const FLARE_LEAP: = 0.15

static var all: Array[Flame] = []

var intensity: = 0.0
var progress: = 0.0
var _cards: Array[MeshInstance3D] = []
var _seed: = randf() * 10.0
var _smoke: RbxEmitter
var _sparks: RbxEmitter
var _steam: RbxEmitter
var _hiss: AudioStreamPlayer3D
var _crackle: AudioStreamPlayer3D
var _glow: OmniLight3D
var _bar: Sprite3D
var _bar_image: Image
var _last_progress: = 0.0
var _hit: = 0.0
var _smoke_tone: = -1
var _shown: = 0.0
var _power: = 0.0
var _sized: = -1.0
var _flicker: = randf() * 100.0
var _shares: = 1
var _smoke_share: = 1.0
var _was_intensity: = -1.0
var _was_at: = 0.0
var _flare: = 0.0
var fuel: = "building"
var _smoke_from: = SMOKE_DARK
var _smoke_to: = SMOKE_DARK
var _fuel_known: = false


func _enter_tree() -> void :
	all.append(self)


func _exit_tree() -> void :
	all.erase(self)


func _ready() -> void :
	var low: = Settings.quality <= Graphics.LOW
	for index in 2:
		var card: = MeshInstance3D.new()
		card.mesh = ToonFire.card()
		card.material_override = ToonFire.flame_material()
		card.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

		card.custom_aabb = AABB(Vector3(-6, -1, -6), Vector3(12, 12, 12))
		card.set_instance_shader_parameter("seed", _seed + index * 3.7)
		card.set_instance_shader_parameter("pull", 1.8 - 0.05 * index)
		add_child(card)
		_cards.append(card)

	_smoke_from = ToonFire.fuel_color(fuel)
	var winning: Array = Config.Art.Smoke.Winning
	_smoke_to = Color(winning[0], winning[1], winning[2])
	_smoke = ToonFire.puffs(self, {
		"Color": _smoke_from, "Transparency": SMOKE_LIT, "Speed": [2.5, 4.5], "Lifetime": [2.6, 3.6], 
		"SpreadAngle": 14, "Direction": Vector3.UP, "Acceleration": Vector3(0, 1.0, 0) + WIND * 1.6, 
		"Drag": 0.3, "Rotation": [0, 360], "Rate": 2, "MaxRate": 3.0 if low else 5.0, "Sphere": 0.6, 
	})
	_sparks = RbxEmitter.make(self, {
		"Texture": "fire_ember", "LightEmission": 1.0, "LightInfluence": 0.0, "Brightness": 3.0, 
		"Speed": [5, 11], "Lifetime": [0.8, 1.6], "SpreadAngle": 40, "Direction": Vector3.UP, 
		"Acceleration": Vector3(0, -4, 0) + WIND * 2.0, "Drag": 0.8, "Size": [0.3, 0.1], "Transparency": [0.0, 1.0], 
		"Rate": 0, "MaxRate": 30, 
	})

	_steam = ToonFire.puffs(self, {
		"Color": Color(0.93, 0.95, 0.97), "Speed": [5, 9], "Lifetime": [0.9, 1.6], "SpreadAngle": 40, 
		"Direction": Vector3.UP, "Acceleration": Vector3(0, 4, 0) + WIND * 2.5, "Drag": 0.6, "Rotation": [0, 360], 
		"Size": [[0.0, 0.6], [0.35, 2.2], [1.0, 0.0]], "Rate": 0, "MaxRate": 8.0 if low else 14.0, "Sphere": 1.0, 
	}, true)
	_glow = OmniLight3D.new()
	_glow.light_color = GLOW
	_glow.shadow_enabled = false
	_glow.omni_attenuation = 1.2
	_glow.visible = false
	add_child(_glow)
	_glow.position.y = 1.5


	_bar_image = Image.create(64, 8, false, Image.FORMAT_RGBA8)
	_bar = Sprite3D.new()
	_bar.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_bar.no_depth_test = true
	_bar.fixed_size = true
	_bar.pixel_size = 0.0016
	_bar.render_priority = 5
	_bar.position.y = 4.5
	_bar.visible = false
	add_child(_bar)
	_crackle = Sounds.emitter(self, Sounds.loop("fire_crackle"), 0.0, 14.0, 220.0, true)
	_hiss = Sounds.emitter(self, Sounds.loop("steam_hiss"), 0.0001, 12.0, 200.0, true)



func share_light(count: int) -> void :
	_shares = count
	_glow.visible = count > 0



func share_smoke(leads: bool) -> void :
	var share: = 1.0 if leads else 0.25
	if share != _smoke_share:
		_smoke_share = share
		_sized = -1.0





func _pick_fuel() -> void :
	if fuel != "building" or FireService.current == null:
		return
	var at: = global_position
	for building: Building in FireService.current.buildings:
		if building.position.distance_to(at) > 120.0:
			continue
		for node: Dictionary in building.fuel:
			if (node["position"] as Vector3).distance_to(at) < 1.5:
				return
		for spot: Vector3 in building.spots:
			if spot.distance_to(at) < 1.5:
				return
	set_fuel("black")



func set_fuel(kind: String) -> void :
	fuel = kind
	_smoke_from = ToonFire.fuel_color(kind)
	_smoke_tone = -1



func _resize(power: float) -> void :
	var tall: = 2.2 + 5.6 * power
	var wide: = 1.7 + 2.1 * power
	_cards[0].set_instance_shader_parameter("height", tall)
	_cards[0].set_instance_shader_parameter("width", wide)
	_cards[0].set_instance_shader_parameter("speed", power)

	_cards[1].visible = power > 0.3
	_cards[1].set_instance_shader_parameter("height", tall * 0.62)
	_cards[1].set_instance_shader_parameter("width", wide * 0.7)
	_cards[1].set_instance_shader_parameter("side", wide * (0.32 if int(_seed * 10.0) % 2 == 0 else -0.32))
	_cards[1].set_instance_shader_parameter("speed", power)

	var puff: = 0.7 + 1.0 * power
	_smoke.position.y = tall * 0.8

	var sizes: Array = []
	for key: Array in Config.Art.Smoke.FlameSize:
		sizes.append([float(key[0]), snappedf(float(key[1]) * puff, 0.05)])
	_smoke.set_size(sizes)
	_steam.position.y = tall * 0.4
	_smoke.set_rate(_smoke._full_rate * (0.35 + 0.65 * power) * _smoke_share)
	_bar.position.y = tall + 0.8
	_sized = power


func _process(delta: float) -> void :
	var now: = Game.now()
	ToonFire.look(now)
	if not _fuel_known:
		_fuel_known = true
		_pick_fuel()

	_shown += (progress - _shown) * minf(1.0, delta * 10.0)



	if now - _was_at >= FLARE_OVER:
		if _was_intensity >= 0.0 and intensity - _was_intensity > FLARE_LEAP:
			_flare = 1.0
		_was_intensity = intensity
		_was_at = now
	_flare = maxf(_flare - delta * 1.8, 0.0)
	var power: = (0.25 + 0.75 * intensity) * (1.0 - 0.65 * _shown) + 0.35 * _flare
	_power += (power - _power) * minf(1.0, delta * 6.0)
	if absf(_power - _sized) > RESIZE_STEP:
		_resize(_power)


	if progress > _last_progress + 0.001:
		_hit = 1.0
	_last_progress = progress
	var was_hit: = _hit
	_hit = maxf(_hit - delta * 1.6, 0.0)
	if _hit > 0.0 or was_hit > 0.0:
		for card in _cards:
			card.set_instance_shader_parameter("hit", _hit)
		_steam.set_rate(_steam._full_rate * _hit * (0.4 + 0.6 * _power))
		if _hiss.stream:
			_hiss.volume_db = linear_to_db(maxf(_hit * (0.35 + 0.65 * _power) * 0.9, 0.0001))
	_sparks.set_rate(5.0 * _power * _power + 25.0 * maxf(_hit, _flare) * _power)
	var tone: = int(clampf(_shown, 0.0, 1.0) * 4.0)
	if tone != _smoke_tone:
		_smoke_tone = tone
		_smoke.set_color(_smoke_from.lerp(_smoke_to, tone / 4.0), SMOKE_LIT)
	if _glow.visible:

		var t: = now + _flicker
		var waver: = 0.8 + 0.12 * sin(t * 9.0) + 0.08 * sin(t * 23.0) + 0.05 * sin(t * 41.0)
		if _hit > 0.0:
			waver *= 1.0 - 0.35 * _hit * absf(sin(t * 17.0))
		var many: = sqrt(float(_shares))
		_glow.light_energy = (0.3 + 0.8 * _power) * waver * 6.0 * many
		_glow.omni_range = (10.0 + 14.0 * _power) * 1.6 * (1.0 + 0.25 * (many - 1.0))
	if _crackle.stream:
		_crackle.volume_db = linear_to_db(0.25 + 0.6 * _power)
	var showing: = _shown > 0.02
	if showing != _bar.visible:
		_bar.visible = showing
	if showing:
		var filled: = int(clampf(_shown, 0.0, 1.0) * 64.0)
		if filled != _bar.get_meta("filled", -1):
			_bar.set_meta("filled", filled)
			_bar_image.fill(Color(25 / 255.0, 25 / 255.0, 30 / 255.0, 0.75))
			_bar_image.fill_rect(Rect2i(0, 0, filled, 8), HOT.lerp(COOL, _shown * _shown))
			_bar.texture = ImageTexture.create_from_image(_bar_image)
