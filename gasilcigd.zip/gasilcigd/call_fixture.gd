class_name CallFixture
extends RefCounted












const SWITCH_SIZE: = Vector3(2.2, 2.8, 0.6)
const GREY: = Color8(196, 199, 202)
const PLATE: = Color8(242, 196, 24)
const HANDLE: = Color8(200, 36, 30)
const AMBER: = Color(1.0, 0.62, 0.1)
const RED: = Color(1.0, 0.12, 0.08)
const GREEN: = Color(0.2, 1.0, 0.35)
const FLASH: = 1.1
const PANEL_SIZE: = Vector3(2.4, 3.0, 0.5)
const INK: = Color(0.06, 0.06, 0.07)
const LCD: = Color(0.42, 0.86, 0.55)



class Beacon:
	extends Node3D
	var color: = AMBER
	var finished: = false
	var lens: MeshInstance3D
	var glow: OmniLight3D
	var glare: MeshInstance3D
	var glare_done: MeshInstance3D
	var _material: StandardMaterial3D

	func _ready() -> void :
		var foot: = MeshInstance3D.new()
		var base: = CylinderMesh.new()
		base.top_radius = 0.32
		base.bottom_radius = 0.38
		base.height = 0.25
		foot.mesh = base
		var black: = StandardMaterial3D.new()
		black.albedo_color = Color(0.08, 0.08, 0.09)
		foot.material_override = black
		add_child(foot)
		lens = MeshInstance3D.new()
		var dome: = SphereMesh.new()
		dome.radius = 0.3
		dome.height = 0.6
		dome.is_hemisphere = false
		lens.mesh = dome
		lens.position = Vector3(0, 0.3, 0)
		lens.scale = Vector3(1, 1.3, 1)
		_material = StandardMaterial3D.new()
		_material.emission_enabled = true
		lens.material_override = _material
		lens.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(lens)
		glow = OmniLight3D.new()
		glow.position = Vector3(0, 0.4, 0.6)
		glow.omni_range = 9.0
		glow.shadow_enabled = false
		add_child(glow)
		glare = VehicleLook.flare(self, Vector3(0, 0.35, 0), color, 3.4)
		glare_done = VehicleLook.flare(self, Vector3(0, 0.35, 0), GREEN, 1.0)
		_paint(0.0)

	func _paint(on: float) -> void :
		var lamp: = GREEN if finished else color
		_material.albedo_color = lamp.darkened(0.55).lerp(lamp, on)
		_material.emission = lamp
		_material.emission_energy_multiplier = 0.15 + 5.0 * on
		glow.light_color = lamp
		glow.light_energy = 2.5 * on
		VehicleLook.shine(glare, 0.0 if finished else on)
		VehicleLook.shine(glare_done, on * 0.6 if finished else 0.0)

	func _process(_delta: float) -> void :
		if finished:
			_paint(0.55)
			return

		var t: = fposmod(Time.get_ticks_msec() / 1000.0, FLASH) / FLASH
		var on: = 1.0 if (t < 0.2 or (t > 0.32 and t < 0.52)) else 0.0
		_paint(on)


static func _box(parent: Node3D, size: Vector3, at: Vector3, color: Color, emission: = 0.0) -> MeshInstance3D:
	var box: = MeshInstance3D.new()
	var mesh: = BoxMesh.new()
	mesh.size = size
	box.mesh = mesh
	var material: = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.6
	if emission > 0.0:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = emission
	box.material_override = material
	box.position = at
	parent.add_child(box)
	return box



static func _bolt(parent: Node3D, at: Vector3) -> void :
	var holder: = Node3D.new()
	holder.position = at
	parent.add_child(holder)
	var triangle: = MeshInstance3D.new()
	var prism: = PrismMesh.new()
	prism.size = Vector3(0.9, 0.8, 0.04)
	triangle.mesh = prism
	var yellow: = StandardMaterial3D.new()
	yellow.albedo_color = PLATE
	triangle.material_override = yellow
	holder.add_child(triangle)
	var bolt: = _box(holder, Vector3(0.1, 0.42, 0.02), Vector3(0, -0.06, -0.03), Color(0.05, 0.05, 0.05))
	bolt.rotation.z = 0.45



static func dress_switch(part: Node3D) -> void :
	if part is PartNode:
		(part as PartNode).set_color(GREY)
	var front: = - SWITCH_SIZE.z / 2.0

	_box(part, Vector3(0.12, SWITCH_SIZE.y - 0.4, 0.1), Vector3( - SWITCH_SIZE.x / 2.0 + 0.15, 0, front - 0.03), GREY.darkened(0.3))
	_box(part, Vector3(1.1, 1.1, 0.06), Vector3(0, -0.2, front - 0.04), PLATE)
	var handle: = Node3D.new()
	handle.name = "Handle"
	handle.position = Vector3(0, -0.2, front - 0.15)
	handle.rotation.z = - PI / 4.0
	part.add_child(handle)
	_box(handle, Vector3(0.55, 0.55, 0.12), Vector3.ZERO, HANDLE)
	_box(handle, Vector3(0.22, 1.0, 0.24), Vector3(0, 0, -0.12), HANDLE)

	_box(part, Vector3(0.06, 0.2, 0.02), Vector3(0.38, 0.3, front - 0.08), Color(0.05, 0.05, 0.05))
	_bolt(part, Vector3(0, SWITCH_SIZE.y / 2.0 - 0.6, front - 0.05))
	mark(part, Vector3(0, SWITCH_SIZE.y / 2.0 + 0.3, front + 0.1), Vector3(0, 0, -1), "switch")



static func dress_valve(part: Node3D) -> void :

	var pipe: = MeshInstance3D.new()
	var tube: = CylinderMesh.new()
	tube.top_radius = 0.22
	tube.bottom_radius = 0.22
	tube.height = 1.2
	pipe.mesh = tube
	var yellow: = StandardMaterial3D.new()
	yellow.albedo_color = PLATE
	pipe.material_override = yellow
	pipe.rotation.z = PI / 2.0
	pipe.position = Vector3(-0.6, 0, 0)
	part.add_child(pipe)
	mark(part, Vector3(-0.3, 1.5, 0), Vector3(1, 0, 0), "valve")




static func mark(parent: Node3D, at: Vector3, out: Vector3, kind: String) -> Node3D:
	var beacon: = Beacon.new()
	beacon.name = "CallBeacon"
	beacon.color = RED if kind == "panel" else AMBER
	beacon.position = at + out.normalized() * 0.4
	parent.add_child(beacon)
	return beacon



static func done(node: Node3D) -> void :
	var beacon: = node.get_node_or_null("CallBeacon") as Beacon
	if beacon:
		beacon.finished = true
	var handle: = node.get_node_or_null("Handle") as Node3D
	if handle:
		handle.rotation.z = 0.0




static func panel(holder: Node3D, house: House) -> void :
	var store: = Game.store
	var at: = holder.global_position
	var body: = -1
	var display: = -1
	for row in store.rows_under.get(house.model, PackedInt32Array()):
		var named: = store.name_at(row)
		if named == "AlarmPanel" and store.position(row).distance_to(at) < 6.0:
			body = row
		elif named == "AlarmDisplay" and store.position(row).distance_to(at) < 6.0:
			display = row
	var out: = Vector3.ZERO
	if body >= 0 and display >= 0:
		out = (store.position(display) - store.position(body)) * Vector3(1, 0, 1)
		at = store.position(body)
	else:
		var door: Variant = house.outside_door()
		if door is Dictionary:
			out = ((door["shut"] as Transform3D).origin - at) * Vector3(1, 0, 1)
	if out.length() < 0.01:
		out = Vector3(0, 0, 1)
	out = out.normalized()
	var place: = Node3D.new()
	place.name = "Panel"
	holder.add_child(place)
	place.global_transform = Rbx.look_at(at, at - out)
	if body < 0:

		_box(place, PANEL_SIZE, Vector3.ZERO, GREY)
		_box(place, Vector3(2.42, 0.6, 0.52), Vector3(0, 1.2, 0), HANDLE)
		_box(place, Vector3(1.6, 0.8, 0.04), Vector3(0, 0.2, 0.27), LCD, 1.5)
	_dress_panel(place)

	mark(place, Vector3(0, 1.8, 0.1), Vector3(0, 0, 1), "panel")


	var door: Variant = house.outside_door()
	if door is Dictionary:
		var shut: Transform3D = door["shut"]
		var outward: = - shut.basis.z
		if outward.dot(shut.origin - house.position) < 0.0:
			outward = - outward
		outward = (outward * Vector3(1, 0, 1)).normalized()
		var entry: = Node3D.new()
		entry.name = "Entry"
		holder.add_child(entry)
		entry.global_transform = Rbx.look_at(shut.origin, shut.origin - outward)

		mark(entry, Vector3(float(door["width"]) / 2.0 + 1.6, 2.4, 0.3), Vector3(0, 0, 1), "panel")






static func _dress_panel(place: Node3D) -> void :
	var half: = PANEL_SIZE / 2.0
	var front: = half.z + 0.03

	for y: float in [half.y - 0.66, - half.y + 0.06]:
		_box(place, Vector3(PANEL_SIZE.x - 0.16, 0.04, 0.02), Vector3(0, y, front), GREY.darkened(0.45))
	for x: float in [ - half.x + 0.08, half.x - 0.08]:
		_box(place, Vector3(0.04, PANEL_SIZE.y - 0.72, 0.02), Vector3(x, -0.3, front), GREY.darkened(0.45))
	for y: float in [0.5, -1.1]:
		_box(place, Vector3(0.08, 0.3, 0.08), Vector3( - half.x - 0.02, y, half.z - 0.05), GREY.darkened(0.3))
	_box(place, Vector3(0.12, 0.12, 0.05), Vector3(half.x - 0.24, -0.2, front + 0.02), Color(0.7, 0.7, 0.72))

	_box(place, Vector3(1.72, 0.92, 0.03), Vector3(0, 0.2, front - 0.005), INK)
	_box(place, Vector3(1.6, 0.8, 0.01), Vector3(0, 0.2, front + 0.015), LCD, 1.2)

	for index in 8:
		var lamp: = _box(place, Vector3(0.13, 0.13, 0.05), Vector3(-0.77 + index * 0.22, -0.48, front + 0.01), RED if index == 0 else Color(0.32, 0.12, 0.1), 3.0 if index == 0 else 0.0)
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	for index in 3:
		var color: Color = [GREEN, AMBER, PLATE][index]
		_box(place, Vector3(0.11, 0.11, 0.05), Vector3(half.x - 0.32, 0.5 - index * 0.2, front + 0.01), color, 2.5 if index == 0 else 0.0)

	for row in 4:
		for column in 3:
			_box(place, Vector3(0.18, 0.13, 0.06), Vector3(-0.55 + column * 0.24, -0.82 - row * 0.18, front + 0.01), Color(0.88, 0.88, 0.86))
	_box(place, Vector3(0.36, 0.2, 0.07), Vector3(0.35, -0.86, front + 0.015), HANDLE)
	_box(place, Vector3(0.36, 0.2, 0.07), Vector3(0.35, -1.14, front + 0.015), Color(0.2, 0.6, 0.3))

	var barrel: = MeshInstance3D.new()
	var cylinder: = CylinderMesh.new()
	cylinder.top_radius = 0.09
	cylinder.bottom_radius = 0.09
	cylinder.height = 0.08
	barrel.mesh = cylinder
	var chrome: = StandardMaterial3D.new()
	chrome.albedo_color = Color(0.78, 0.79, 0.8)
	chrome.metallic = 0.8
	chrome.roughness = 0.25
	barrel.material_override = chrome
	barrel.rotation.x = PI / 2.0
	barrel.position = Vector3(0.8, -0.88, front + 0.02)
	place.add_child(barrel)
	_box(place, Vector3(0.025, 0.1, 0.02), Vector3(0.8, -0.88, front + 0.065), INK)

	for index in 4:
		_box(place, Vector3(0.3, 0.035, 0.02), Vector3(0.8, -1.12 - index * 0.06, front + 0.005), INK)

	_box(place, Vector3(0.7, 0.18, 0.02), Vector3(-0.7, half.y - 0.3, front + 0.01), Color(0.92, 0.92, 0.9))

	var top: = place.global_transform * Vector3(0, half.y + 0.05, - half.z + 0.1)
	var rise: = 6.0
	if Game.world != null:
		var hit: = Game.world.raycast(top, top + Vector3(0, 6, 0), World.LAYER_SOLID)
		if not hit.is_empty():
			rise = (hit["position"] as Vector3).y - top.y
	if rise > 0.3:
		for x: float in [half.x - 0.45, - half.x + 0.45]:
			_box(place, Vector3(0.22, rise, 0.16), Vector3(x, half.y + rise / 2.0, - half.z + 0.1), Color(0.9, 0.9, 0.88))
