class_name Weather
extends Node3D










const SPELL: = 330.0
const CHANGE: = 45.0

const SPELLS: = ["clear", "clear", "cloudy", "rain", "cloudy", "clear", "clear", "cloudy", "clear", "rain", "rain", "cloudy"]
const LOOKS: = {
	"clear": [0.0, 0.0], 
	"cloudy": [0.62, 0.0], 
	"rain": [0.95, 1.0], 
}
const WETS_IN: = 50.0
const DRIES_IN: = 240.0
const CLOUD_WIND: = Vector2(0.0042, 0.0026)
const FLURRIES: = 0.35
const RAIN_BOX: = Vector3(110.0, 40.0, 110.0)

static var current: Weather

var overcast: = 0.0
var rain: = 0.0
var wet: = 0.0
var _held: = ""
var _rain: GPUParticles3D
var _splashes: GPUParticles3D
var _catch: GPUParticlesCollisionHeightField3D
var _sound: AudioStreamPlayer
var _drops: = 0
var _next_ground: = 0.0
var _covered: = false
var _ground_y: = 0.0
var _snowing: = false
var _falling: ParticleProcessMaterial
var _streak: QuadMesh
var _look: StandardMaterial3D


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
	RenderingServer.global_shader_parameter_set("wetness", 0.0)
	RenderingServer.global_shader_parameter_set("cloud_shadow", 0.0)


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--weather="):
			_held = arg.substr(10)
	RenderingServer.global_shader_parameter_set("cloud_noise", _cloud_noise())
	_drops = [300, 600, 1600, 3200][clampi(Settings.quality + 1, 0, 3)]
	_make_rain()
	_sound = AudioStreamPlayer.new()
	_sound.stream = Sounds.loop("rain")
	_sound.volume_db = -80.0
	add_child(_sound)
	if _held != "":
		var look: Array = LOOKS.get(_held, LOOKS["clear"])
		overcast = look[0]
		rain = look[1]
		wet = 1.0 if rain > 0.0 else 0.0



func kind() -> String:
	return "rain" if rain > 0.5 else ("cloudy" if overcast > 0.4 else "clear")


func _process(delta: float) -> void :
	if _held == "":
		var t: = HostClock.now()
		var spell: = floori(t / SPELL)
		var into: = fmod(t, SPELL)
		var before: Array = LOOKS[SPELLS[posmod(spell - 1, SPELLS.size())]]
		var now: Array = LOOKS[SPELLS[posmod(spell, SPELLS.size())]]
		var blend: = smoothstep(0.0, CHANGE, into) if spell > 0 else 1.0
		overcast = lerpf(before[0], now[0], blend)

		rain = clampf(lerpf(before[1], now[1], smoothstep(0.25, 1.0, blend)), 0.0, 1.0)
	if rain > 0.2:
		wet = minf(wet + delta / WETS_IN * rain, 1.0)
	else:
		wet = maxf(wet - delta / DRIES_IN, 0.0)
	var sky: = Sky3D.current
	var daylight: = 1.0
	if sky:
		sky.overcast = overcast
		daylight = sky.daylight()


	var winter: = Style.winter()
	if winter != _snowing:
		_snowing = winter
		_dress_fall()
	RenderingServer.global_shader_parameter_set("wetness", 0.0 if winter else wet)
	RenderingServer.global_shader_parameter_set("cloud_shadow", 0.0 if winter else 0.42 * daylight * clampf(1.0 - overcast * 1.6, 0.0, 1.0))
	RenderingServer.global_shader_parameter_set("cloud_offset", CLOUD_WIND * HostClock.now())
	_follow_camera()

	var falling: = maxf(rain, FLURRIES) if winter else rain
	_rain.amount_ratio = falling
	_rain.emitting = falling > 0.01
	_splashes.amount_ratio = rain
	_sound.volume_db = linear_to_db(maxf(rain * 0.7, 0.0001))

	_splashes.emitting = rain > 0.01 and not winter and not _covered
	if winter:
		_sound.volume_db = -80.0
	if rain > 0.01 and not _sound.playing:
		_sound.play()
	elif rain <= 0.01 and _sound.playing:
		_sound.stop()
	if sky and sky.environment:



		sky.environment.ssr_enabled = wet > 0.25 and Graphics.reflections_on() and not winter


func _follow_camera() -> void :
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var at: = camera.global_position
	_rain.global_position = Vector3(at.x, at.y + RAIN_BOX.y * 0.5, at.z)


	if Game.now() >= _next_ground and Game.world:
		_next_ground = Game.now() + 0.3
		var below: = Game.world.raycast(at, at - Vector3(0, 300, 0), World.LAYER_SOLID)
		_ground_y = below["position"].y if not below.is_empty() else 0.0
		_covered = not Game.world.raycast(at, at + Vector3(0, 120, 0), World.LAYER_SOLID).is_empty()
	_splashes.global_position = Vector3(at.x, _ground_y + 0.2, at.z)

	var caught: = _catch.global_position
	if Vector2(caught.x - at.x, caught.z - at.z).length() > 12.0 or absf(caught.y - at.y) > 20.0:
		_catch.global_position = Vector3(at.x, at.y, at.z)


func _make_rain() -> void :
	_catch = GPUParticlesCollisionHeightField3D.new()
	_catch.size = Vector3(RAIN_BOX.x + 20.0, 140.0, RAIN_BOX.z + 20.0)
	_catch.resolution = GPUParticlesCollisionHeightField3D.RESOLUTION_256
	_catch.update_mode = GPUParticlesCollisionHeightField3D.UPDATE_MODE_WHEN_MOVED
	_catch.follow_camera_enabled = false
	add_child(_catch)


	_rain = GPUParticles3D.new()
	_rain.amount = _drops
	_rain.lifetime = 0.9
	_rain.local_coords = false
	_rain.visibility_aabb = AABB( - RAIN_BOX, RAIN_BOX * 2.0)
	_rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var falling: = ParticleProcessMaterial.new()
	falling.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	falling.emission_box_extents = Vector3(RAIN_BOX.x * 0.5, 2.0, RAIN_BOX.z * 0.5)
	falling.direction = Vector3(0.12, -1.0, 0.08)
	falling.spread = 2.0
	falling.initial_velocity_min = 95.0
	falling.initial_velocity_max = 120.0
	falling.gravity = Vector3(0, -30, 0)
	falling.collision_mode = ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT
	_rain.process_material = falling
	_falling = falling
	var streak: = QuadMesh.new()
	streak.size = Vector2(0.05, 2.4)
	_streak = streak
	var look: = StandardMaterial3D.new()
	_look = look
	look.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	look.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	look.albedo_color = Color(0.78, 0.82, 0.88, 0.32)
	look.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	look.billboard_keep_scale = true
	look.disable_receive_shadows = true
	streak.material = look
	_rain.draw_pass_1 = streak
	add_child(_rain)


	_splashes = GPUParticles3D.new()
	_splashes.amount = _drops / 4
	_splashes.lifetime = 0.35
	_splashes.local_coords = false
	_splashes.visibility_aabb = AABB( - RAIN_BOX, RAIN_BOX * 2.0)
	_splashes.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var splashing: = ParticleProcessMaterial.new()
	splashing.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	splashing.emission_box_extents = Vector3(35.0, 0.0, 35.0)
	splashing.direction = Vector3.UP
	splashing.spread = 40.0
	splashing.initial_velocity_min = 2.0
	splashing.initial_velocity_max = 5.0
	splashing.gravity = Vector3(0, -40, 0)
	splashing.scale_min = 0.25
	splashing.scale_max = 0.55
	_splashes.process_material = splashing
	var dot: = QuadMesh.new()
	dot.size = Vector2(0.5, 0.5)
	var spray: = StandardMaterial3D.new()
	spray.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spray.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	spray.albedo_texture = Assets.texture("water_droplet")
	spray.albedo_color = Color(0.85, 0.88, 0.92, 0.5)
	spray.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	spray.billboard_keep_scale = true
	dot.material = spray
	_splashes.draw_pass_1 = dot
	add_child(_splashes)



func _dress_fall() -> void :
	if _snowing:

		_falling.direction = Vector3(0.2, -1.0, 0.12)
		_falling.spread = 14.0
		_falling.initial_velocity_min = 8.0
		_falling.initial_velocity_max = 11.0
		_falling.gravity = Vector3(0, -1.0, 0)
		_rain.lifetime = 6.0
		_streak.size = Vector2(0.3, 0.3)
		_look.albedo_color = Color(0.95, 0.96, 1.0, 0.9)
		_look.albedo_texture = _flake()
		_look.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	else:
		_falling.direction = Vector3(0.12, -1.0, 0.08)
		_falling.initial_velocity_min = 95.0
		_falling.initial_velocity_max = 120.0
		_falling.gravity = Vector3(0, -30, 0)
		_falling.spread = 2.0
		_rain.lifetime = 0.9
		_streak.size = Vector2(0.05, 2.4)
		_look.albedo_color = Color(0.78, 0.82, 0.88, 0.32)
		_look.albedo_texture = null
		_look.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y



static func _flake() -> GradientTexture2D:
	var dot: = GradientTexture2D.new()
	dot.width = 32
	dot.height = 32
	dot.fill = GradientTexture2D.FILL_RADIAL
	dot.fill_from = Vector2(0.5, 0.5)
	dot.fill_to = Vector2(1.0, 0.5)
	var edge: = Gradient.new()
	edge.set_color(0, Color(1, 1, 1, 1))
	edge.set_color(1, Color(1, 1, 1, 0))
	edge.add_point(0.45, Color(1, 1, 1, 0.85))
	dot.gradient = edge
	return dot



static func _cloud_noise() -> NoiseTexture2D:
	var source: = FastNoiseLite.new()
	source.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	source.frequency = 0.008
	source.fractal_octaves = 3
	source.seed = 77
	var texture: = NoiseTexture2D.new()
	texture.width = 256
	texture.height = 256
	texture.seamless = true
	texture.generate_mipmaps = true
	texture.noise = source
	return texture
