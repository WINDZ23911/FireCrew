class_name JobCones
extends CrewJob




const NEAR: = 16.0
const PER_SIDE: = 3

var around: = false


func _init(at: Vector3) -> void :
	kind = "cones"
	role = "safety"
	target = at



static func ring(at: Vector3) -> JobCones:
	var job: = JobCones.new(at)
	job.around = true
	return job


func place() -> Vector3:
	return target


func run() -> bool:
	var road: = CrewKit.road_at(target)
	if around or road.is_empty():
		if not around:
			return fail("crew.say.noRoad")
		return await _ring()
	var middle: Vector3 = road[0]
	var along: Vector3 = road[1]
	var across: = Vector3(along.z, 0, - along.x)
	var item: = await CrewKit.take_cordon(who, "Cones", who.service.home_vehicle(who.commander()))
	if item.is_empty():
		return fail("crew.say.noTool", [Text.named("tools", "Cones")])
	var held: = who.token()
	var stood: = 0

	var sides: Array[float] = [-1.0, 1.0]
	if (who.body.global_position - middle).dot(along) > 0.0:
		sides = [1.0, -1.0]
	for side in sides:
		for index in PER_SIDE:
			if Cordon.current._cone_stock.get(item["truck"], 0) <= 0:
				return stood > 0
			var spot: = middle + along * side * (NEAR + index * 2.0) + across * (float(index) - 1.0) * 3.2
			var ground: = who.service.ground(spot + Vector3(0, 3, 0))


			var from: = ground + along * side * 4.0
			if not await who.go(who.service.ground(from + Vector3(0, 2, 0)), 1.0, 40.0):
				return fail("crew.say.stuck")
			who.look = ground
			if not await who.wait(0.45, held):
				return false
			if Cordon.current.held(who.body) == null or not is_same(Cordon.current.held(who.body), item):
				ToolService.current.toggle_slot(who.body, item["entry"])
			Cordon.current.activate(who.body)
			stood += 1
			if not await who.wait(0.3, held):
				return false
	return true


func _ring() -> bool:
	var item: = await CrewKit.take_cordon(who, "Cones", who.service.home_vehicle(who.commander()))
	if item.is_empty():
		return fail("crew.say.noTool", [Text.named("tools", "Cones")])
	var held: = who.token()
	var count: = int(Config.Crew.Hazmat.Cones)
	var radius: = float(Config.Crew.Hazmat.ConeRing)
	var centre: Vector3 = target

	var truck: Variant = who.service.home_vehicle(who.commander())
	var start: Vector3 = ((truck as Vehicle).global_position if truck is Vehicle else who.body.global_position) - centre
	var first: = atan2(start.z, start.x)
	var stood: = 0
	for index in count:
		if Cordon.current._cone_stock.get(item["truck"], 0) <= 0:
			break

		var turn: = first + (PI / 2.0 + floorf(index / 2.0) * 0.35) * (1.0 if index % 2 == 0 else -1.0)
		var spot: = centre + Vector3(cos(turn), 0, sin(turn)) * radius
		var ground: = who.service.ground(spot + Vector3(0, 6, 0))
		var outward: = Vector3(cos(turn), 0, sin(turn))
		if not await who.go(who.service.ground(ground + outward * 4.0 + Vector3(0, 3, 0)), 1.5, 40.0):
			continue
		who.look = ground
		if not await who.wait(0.45, held):
			return false
		if Cordon.current.held(who.body) == null or not is_same(Cordon.current.held(who.body), item):
			ToolService.current.toggle_slot(who.body, item["entry"])
		Cordon.current.activate(who.body)
		stood += 1
		if not await who.wait(0.3, held):
			return false
	return stood > 0 if stood > 0 else fail("crew.say.stuck")


func finish(_done: bool) -> void :

	var cordon: = Cordon.current
	if cordon:
		for item: Dictionary in cordon.items:
			if item["holder"] == who.body:
				cordon.put_back(item)
