class_name ArmReach
extends RefCounted








const UPPER: = 0.74
const LOWER: = 0.68
const FIST: = 0.34
const STRETCH: = 0.38





static func solve(shoulder: Vector3, target: Transform3D, pole: Vector3, scale: = 1.0) -> Array:
	var upper: = UPPER * scale
	var lower: = LOWER * scale
	var turn: = target.basis.orthonormalized()
	var wrist: = target.origin + turn.y * FIST * scale
	var to: = wrist - shoulder

	var short: = to.length() - (upper + lower) * 0.995
	if short > 0.0:
		shoulder += to.normalized() * minf(short, STRETCH * scale)
		to = wrist - shoulder
	var distance: = clampf(to.length(), absf(upper - lower) + 0.02 * scale, (upper + lower) * 0.9995)
	var along: = to.normalized() if to.length() > 1e-05 else Vector3.DOWN

	var out: = pole - along * pole.dot(along)
	if out.length() < 0.0001:
		out = along.cross(Vector3.RIGHT if absf(along.x) < 0.9 else Vector3.FORWARD)
	out = out.normalized()
	var cos_at: = clampf((upper * upper + distance * distance - lower * lower) / (2.0 * upper * distance), -1.0, 1.0)
	var at: = acos(cos_at)
	var elbow: = shoulder + (along * cos(at) + out * sin(at)) * upper
	var reached: = shoulder + along * distance
	var up_arm: = (elbow - shoulder).normalized()
	var forearm: = (reached - elbow).normalized()


	var y: = - up_arm
	var z: = out - up_arm * out.dot(up_arm)
	z = z.normalized() if z.length() > 0.0001 else Vector3.BACK
	var x: = y.cross(z).normalized()
	var shoulder_basis: = Basis(x, y, x.cross(y))
	var bend: = acos(clampf(up_arm.dot(forearm), -1.0, 1.0))
	return [shoulder, shoulder_basis, bend, turn, maxf(0.0, (wrist - reached).length())]




static func grip(point: Vector3, thumb: Vector3, wrist: Vector3) -> Transform3D:
	var gy: = thumb.normalized()
	var gz: = wrist - gy * wrist.dot(gy)
	gz = gz.normalized() if gz.length() > 1e-05 else gy.cross(Vector3.RIGHT).normalized()
	var gx: = gy.cross(gz)
	return Transform3D(Basis(gx, gz, - gy), point)



static func facing(up: Vector3, ahead: Vector3) -> Basis:
	var y: = up.normalized()
	var z: = - (ahead - y * ahead.dot(y))
	z = z.normalized() if z.length() > 1e-05 else y.cross(Vector3.RIGHT).normalized()
	return Basis(y.cross(z), y, z)



static func aiming(ahead: Vector3, up: = Vector3.UP) -> Basis:
	var z: = - ahead.normalized()
	var x: = up.cross(z)
	x = x.normalized() if x.length() > 1e-05 else Vector3.RIGHT
	return Basis(x, z.cross(x), z)



static func place(basis: Basis, point: Vector3, at: Vector3) -> Transform3D:
	return Transform3D(basis, at - basis * point)



static func about(pivot: Vector3, turn: Basis) -> Transform3D:
	return Transform3D(Basis.IDENTITY, pivot) * Transform3D(turn, Vector3.ZERO) * Transform3D(Basis.IDENTITY, - pivot)
