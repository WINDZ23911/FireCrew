class_name CallsDebug
extends Node


















var _args: Dictionary = {}
var _camera: Camera3D
var _view: = Vector3(40, 22, 30)
var _shots: = ""
var _busy: = false
var _began: = -1.0
var _timed: Array = []


func _ready() -> void :

	Net.handle("calls.debug.look", func(at: Vector3, view: Vector3) -> void :
		if not _args.is_empty():
			look(at, view)
	)


	Net.handle("calls.debug.saw", func(player: Player) -> void :
		if _args.is_empty():
			return
		for tick in 60:
			if FallenTree.current == null or not FallenTree.current.saw(player, player.root_position(), player.facing(), 0.5):
				break
			await _wait(0.05)
	)
	Net.handle("calls.debug.take", func(player: Player, index: int) -> void :
		if _args.is_empty():
			return
		var lines: Array = []
		for line in Lockers.of(Vehicle.named("Fire Truck")).lines:
			if line.category == "cordon":
				lines.append(line)
		lines[index].chosen.emit(player)
	)
	Net.handle("calls.debug.board", func(player: Player, door_name: String) -> void :
		if _args.is_empty():
			return
		var truck: = Vehicle.named("Fire Truck")
		Game.station.set_door(int(truck.spec["bay"]), true)
		truck._board(player, door_name)
	)
	Net.share("calls.debug", func() -> Variant: return _began, func(began: Variant) -> void : _began = began, 4.0)
	for arg in OS.get_cmdline_user_args():
		var bits: = arg.split("=", true, 1)
		if bits[0] == "--call-shot":
			_timed.append([float(bits[1].get_slice(",", 0)), bits[1].get_slice(",", 1)])
		if bits[0].begins_with("--call"):
			_args[bits[0].substr(2)] = bits[1] if bits.size() > 1 else ""
	if _args.is_empty():
		set_process(false)
		return
	if _args.has("call") and CallService.current:
		CallService.current.forced = _args["call"]
	if _args.has("call-variant"):
		var wanted: String = _args["call-variant"]
		Config.Incidents["Tree"]["Variant"] = wanted
		Config.Incidents["Crash"]["Layout"] = wanted
		if wanted in ["roof", "cat"]:
			Config.Incidents["Rescue"]["Who"] = wanted
	if _args.has("call-view"):
		var n: PackedFloat64Array = _args["call-view"].split_floats(",")
		_view = Vector3(n[0], n[1], n[2] if n.size() > 2 else 30.0)
	_shots = _args.get("call-shots", "")
	Game.incident_changed.connect(_on_incident)
	if _args.has("call-cones"):
		_cones.call_deferred()
	if _args.has("call-crowd"):
		_crowd()
	if _args.has("call-guide"):
		_guide.call_deferred(_args["call-guide"])
	if _args.has("call-yard"):
		look.call_deferred(Vector3(-6, 2, -18), Vector3(22, 10, 25))
	if String(_args.get("call-client", "")).begins_with("cones"):
		_client_cones.call_deferred(float(_args["call-client"].get_slice(",", 1)))


func _process(_delta: float) -> void :
	if _args.has("call-crew") and CallService.current and Net.is_host():
		CallService.current.hold = Net.active() and Net.players.size() < 2
	if not _timed.is_empty() and _began >= 0.0 and (Net.is_host() or HostClock.synced) and HostClock.now() - _began >= _timed[0][0]:
		var shot: Array = _timed.pop_front()
		get_viewport().get_texture().get_image().save_png(shot[1])
		print("call shot at %.2f s: %s" % [HostClock.now() - _began, shot[1]])




func _cones() -> void :
	await _wait(2.0)
	var cordon: = Cordon.current
	var player: = Game.local_player
	var truck: = Vehicle.named("Fire Truck")
	var lockers: = Lockers.of(truck)
	var lines: Array = []
	for line in lockers.lines:
		if line.category == "cordon":
			lines.append(line)
	print("cones: %d lines in the pumper's locker menu under 'cordon', %d stacks and reels in all" % [lines.size(), cordon.items.size()])
	player.teleport(Vector3(-12, 0.6, -20))
	player.rig.global_basis = Basis.looking_at(Vector3(0, 0, 1))
	await _wait(0.3)
	lines[0].chosen.emit(player)
	await _wait(0.4)
	look(player.global_position + Vector3(0, 2, 0), Vector3(9, 3, 25))
	await _wait(0.3)
	await _snap("hand")
	for step in 3:
		cordon.activate(player)
		player.teleport(player.global_position + Vector3(4, 0, 0))
		await _wait(0.2)
	print("cones: %d standing, holding '%s', the line says '%s' and is held by %s" % [cordon.cordon["cones"].size(), player.get_attr("Tool", ""), Text.say(lines[0].action, "en"), lines[0].holder != null])
	lines[1].chosen.emit(player)
	await _wait(0.3)
	print("cones: with the tape taken the cones are %s; holding '%s'" % ["back in the locker" if lines[0].holder == null else "on the belt", player.get_attr("Tool", "")])
	cordon.activate(player)
	player.teleport(player.global_position + Vector3(-14, 0, 3))
	await _wait(0.2)
	cordon.activate(player)
	await _wait(0.2)
	lines[1].chosen.emit(player)
	await _wait(0.3)
	print("cones: %d cones and %d tapes out, version %d; hands now '%s'" % [cordon.cordon["cones"].size(), cordon.cordon["tapes"].size(), cordon.cordon["version"], player.holding])
	await _snap("set")
	if not _shots.is_empty() and not _args.has("call"):
		get_tree().quit()



func _crowd() -> void :
	while is_inside_tree():
		await _wait(4.0)
		var crowd: = Bystanders.current
		if crowd != null and not crowd.scene.is_empty():
			var watching: = 0
			for person: Pedestrians.Person in crowd.scene["crowd"]:
				if person.state == "watch":
					watching += 1
			print("crowd: %d sent, %d watching, %d places, a %s, closure %.0f, hazard %s" % [crowd.scene["crowd"].size(), watching, crowd.scene["spots"].size(), "fire" if crowd.scene["fire"] else "small thing", NavGraph.current.closure.get("radius", 0.0), Pedestrians.current.hazard.get("radius", 0.0) if Pedestrians.current else "-"])


func _on_incident() -> void :
	var incident: = Game.incident
	if _busy or incident.is_empty() or incident.get("kind", "fire") == "fire":
		return
	_busy = true
	if Net.is_host():
		_began = Game.now()
	var at: Vector3 = incident["pos"]
	print("call: %s '%s' at %s, %d to do" % [incident["kind"], Text.say(incident["name"], "en"), at, int(incident.get("total", 0))])
	if _args.has("call-view") or not _shots.is_empty():
		look(at)
	if _args.has("call-client") and Net.is_client():
		match _args["call-client"]:
			"carry":
				_client_carry()
			"tree":
				_client_tree()
	_play(incident["kind"], at)




func _guide(door_name: String) -> void :
	while Net.active() and (Net.players.size() < 2 or (Net.is_client() and not HostClock.synced)):
		await get_tree().process_frame
	await _wait(3.0)
	Net.request("calls.debug.board", [door_name])
	while is_inside_tree():
		await _wait(3.0)
		var player: = Game.local_player
		var vehicle: Variant = player.get_attr("Vehicle")
		var guide: = Guide.current
		print("guide: in %s (%s), %d points of a way %s, %d chevrons laid; the call is at %s" % [
			vehicle.name if vehicle is Vehicle else "nothing", ("driving" if vehicle.driver() == player else "riding, driven by %s" % (vehicle.driver() != null)) if vehicle is Vehicle else "-", 
			guide.points.size(), guide.kind, guide._count, Game.incident.get("pos"), 
		])






func _until(seconds: float) -> void :
	while _began < 0.0 or HostClock.now() - _began < seconds:
		await get_tree().process_frame



func _use(prompt: Prompt) -> void :
	Net.request("prompt", [prompt.net_id, "tap"])


func _client_carry() -> void :
	var player: = Game.local_player
	var people: = VictimService.current
	await _until(4.0)
	var victim: Victim = null
	for one: Victim in people.victims:
		if one.state == "lying":
			victim = one
	if victim == null:
		print("client: nobody lying free, of %d" % people.victims.size())
		return
	_stand_by(player, victim.position(), Vector3(2, 0, 0))
	await _until(5.0)
	print("client: the prompt says '%s %s', on offer %s" % [Text.say(victim.prompt.action, "en"), Text.say(victim.prompt.object, "en"), victim.prompt.shown_to(player)])
	_use(victim.prompt)
	await _until(7.0)
	print("client: carrying %s; holding '%s', walking at %s, Carrying %s" % [people.carried_by(player) == victim, player.holding, player.walk_speed, player.get_attr("Carrying")])
	await _until(9.0)
	var zone: Variant = AmbulanceService.current.zone_position()
	if zone != null:
		player.teleport(zone + Vector3(0, 0.5, 0))
	await _until(12.0)
	print("client: in the box at %s; %d still waiting; holding '%s'; cash %d, saved %d" % [zone, people.victims.size(), player.holding, int(player.get_attr("Cash", 0)), int(player.get_attr("Saved", 0))])


func _client_tree() -> void :
	var player: = Game.local_player
	var tree: = FallenTree.current
	await _until(3.0)
	var held: = tree.scene
	if held.is_empty():
		print("client: no tree here")
		return
	print("client: %d rings and %d pieces here" % [held["rings"].size(), held["pieces"].size()])
	var at: = 4.0
	for ring: Dictionary in held["rings"]:
		_stand_by(player, ring["position"], Vector3(0.5, 0, 2.2))
		at += 1.0
		await _until(at)
		Net.request("calls.debug.saw")
		at += 1.5
		await _until(at)
	var cut: = 0
	for ring: Dictionary in held["rings"]:
		cut += 1 if ring["done"] else 0
	print("client: %d of %d rings cut; cash %d" % [cut, held["rings"].size(), int(player.get_attr("Cash", 0))])

	for piece: Dictionary in held["pieces"]:
		if piece["butt"] or not piece["free"] or piece["prompts"].is_empty():
			continue
		var log_part: PartNode = piece["log"]
		var toward: Vector3 = held["trees"][0]["candidate"]["toward"]
		var end: = log_part.global_transform * Vector3( - (piece["length"] / 2.0 - 0.4), 0, 0)
		player.teleport(CallKit.ground_at(end - toward * 2.0) + Vector3(0, 0.3, 0))
		at += 1.0
		await _until(at)
		print("client: the prompt says '%s %s'" % [Text.say(piece["prompts"][0].action, "en"), Text.say(piece["prompts"][0].object, "en")])
		_use(piece["prompts"][0])
		at += 1.0
		await _until(at)
		print("client: has hold of it %s; walking at %s; the prompt now says '%s'" % [piece["holders"].has(player), player.walk_speed, Text.say(piece["prompts"][0].action, "en")])
		var from: = log_part.global_position
		var goal: Vector3 = held["trees"][0]["candidate"]["position"] - toward * (18.0 + piece["length"])
		for step in 240:
			var here: = player.global_position
			var way: = Vector3(goal.x - here.x, 0, goal.z - here.z)
			if way.length() < 1.0:
				break
			player.teleport(CallKit.ground_at(here + way.normalized() * 0.25 + Vector3(0, 1, 0)) + Vector3(0, 0.3, 0))
			await get_tree().physics_frame
		at += 5.5
		await _until(at)
		print("client: the length has come %.1f studs after them; %s of %s done on the card; cash %d" % [log_part.global_position.distance_to(from), Game.incident.get("done"), Game.incident.get("total"), int(player.get_attr("Cash", 0))])
		_use(piece["prompts"][0])
		at += 1.0
		await _until(at)
		print("client: let go: %s" % ( not piece["holders"].has(player)))
		break


func _client_cones(at_time: float) -> void :
	while not Net.is_client() or not HostClock.synced or HostClock.now() < at_time:
		await get_tree().process_frame
	var player: = Game.local_player
	var cordon: = Cordon.current
	player.teleport(Vector3(-12, 0.6, -20))
	player.rig.global_basis = Basis.looking_at(Vector3(0, 0, 1))
	await _wait(1.0)
	Net.request("calls.debug.take", [0])
	await _wait(1.0)
	var mine: Variant = cordon.held(player)
	print("client cones: in hand '%s' (Tool '%s', carried %s), hands '%s'" % [mine["name"] if mine != null else "", player.get_attr("Tool", ""), player.get_attr("CordonCarried"), player.holding])
	for step in 3:
		Net.request("cordon.use")
		await _wait(0.5)
		player.teleport(player.global_position + Vector3(4, 0, 0))
		await _wait(0.5)
	print("client cones: %d standing here" % cordon.cordon["cones"].size())
	await _wait(2.0)
	if not cordon.cordon["cones"].is_empty():
		var cone: Dictionary = cordon.cordon["cones"][0]
		player.teleport(Vector3(cone["x"] + 2.0, 0.6, cone["z"]))
		await _wait(0.8)
		_use(cone["model"].get_meta("prompt"))
		await _wait(1.0)
		print("client cones: one taken up, %d standing here" % cordon.cordon["cones"].size())
	Net.request("calls.debug.take", [0])
	await _wait(1.0)
	print("client cones: put back; in hand %s, carried %s" % [cordon.held(player) != null, player.get_attr("CordonCarried")])



func look(at: Vector3, view: = Vector3.ZERO) -> void :
	if view == Vector3.ZERO:
		view = _view
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 6000.0
		_camera.fov = 60.0
		add_child(_camera)
	var bearing: = deg_to_rad(view.z)
	_camera.look_at_from_position(at + Vector3(sin(bearing) * view.x, view.y, cos(bearing) * view.x), at + Vector3(0, 1.5, 0))
	_camera.make_current()
	if Net.is_host():
		Net.broadcast("calls.debug.look", [at, view])


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false).timeout


func _snap(stage: String) -> void :

	if stage == "mid" and _args.has("call-hold-mid"):
		print("call: held half way")
		await _wait(float(_args["call-hold-mid"]))
	if _shots.is_empty():
		return
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, stage])
	print("shot: %s_%s.png" % [_shots, stage])


func _play(kind: String, at: Vector3) -> void :
	var player: = Game.local_player
	if _args.has("call-cordon"):
		_cordon(at)
	if _args.has("call-order"):
		_order(at, float(_args["call-order"]))
	await _wait(2.5)
	await _snap("start")
	if _args.has("call-auto"):
		player.teleport(CallKit.ground_at(at + Vector3(6, 0, 6)) + Vector3(0, 0.5, 0))
		await _wait(0.3)
		match kind:
			"tree":
				await _play_tree(player)
			"crash":
				await _play_crash(player)
			"flood":
				await _play_flood(player)
			"medical":
				await _play_medical(player)
			"rescue":
				await _play_rescue(player)

		var waited: = 0.0
		while not Game.incident.is_empty() and waited < 30.0:
			await _wait(0.25)
			waited += 0.25
		print("call over: %s after %.1f s more; cash %d, saved %d" % ["closed" if Game.incident.is_empty() else "STILL OPEN", waited, int(player.get_attr("Cash", 0)), int(player.get_attr("Saved", 0))])
		await _wait(1.0)
	else:
		await _wait(float(_args.get("call-wait", "6")))
	await _snap("end")
	if not _shots.is_empty():
		get_tree().quit()





func _cordon(at: Vector3) -> void :
	var cordon: = Cordon.current
	var pickup: = Vehicle.named("Command Vehicle")
	if cordon == null or pickup == null:
		return

	var along: = Vector3.RIGHT
	if CarCrash.current and not CarCrash.current.scene.is_empty():
		along = CarCrash.current.scene["along"]
	elif NavGraph.current:
		var found: = Roads.nearest(NavGraph.current.layout, at.x, at.z)
		if not found[0].is_empty():
			var way: = Roads.at(found[1], found[0]["along"])
			along = Vector3(way[2], 0, way[3])
	var across: = along.cross(Vector3.UP)
	var beside: = CallKit.ground_at(at + along * 34.0 + across * 3.0)
	pickup.global_transform = Transform3D(Basis.looking_at( - along), beside + Vector3(0, 2.2, 0))
	pickup.linear_velocity = Vector3.ZERO
	for side: float in [-1.0, 1.0]:
		for step: float in [-5.0, 0.0, 5.0]:
			var spot: = CallKit.ground_at(at + along * side * 24.0 + across * step)
			cordon.stand_cone_at(pickup, Transform3D(Basis.IDENTITY, spot))
	var from: = CallKit.ground_at(at + along * 20.0 + across * 14.0)
	var to: = CallKit.ground_at(at - along * 20.0 + across * 14.0)
	cordon.stretch_between(pickup, from, to)
	print("cordon: %d cones and %d tapes out, version %d" % [cordon.cordon["cones"].size(), cordon.cordon["tapes"].size(), cordon.cordon["version"]])


func _order(at: Vector3, after: float) -> void :
	await _wait(after)
	var crowd: = Bystanders.current
	if crowd == null:
		return
	var player: = Game.local_player
	print("bystanders: %d watching of %d places to stand, closure %s" % [crowd.scene.get("crowd", {}).size(), crowd.scene.get("spots", []).size(), NavGraph.current.closure])
	if Net.is_client():

		_stand_by(player, at, Vector3(5, 0, 5))
		await _wait(0.8)
	Net.request("bystanders.command")
	await _wait(1.0)
	await _snap("order")






func _stand_by(player: Player, point: Vector3, off: Vector3) -> Vector3:
	var at: = CallKit.ground_at(Vector3(point.x, point.y, point.z) + off)
	player.teleport(at + Vector3(0, 0.3, 0))
	var look: = Vector3(point.x - at.x, 0, point.z - at.z).normalized()
	player.rig.global_basis = Basis.looking_at(look)
	return look


func _play_tree(player: Player) -> void :
	var tree: = FallenTree.current
	var held: = tree.scene
	print("tree: %d trees, %d rings, %d pieces; the saw is %s" % [held["trees"].size(), held["rings"].size(), held["pieces"].size(), "the tree's" if ToolService.current and ToolService.current.saw.is_valid() else "NOT SET"])

	for pass_limbs: bool in [true, false]:
		for ring: Dictionary in held["rings"].duplicate():
			if ring.has("limb") != pass_limbs:
				continue
			var where: Vector3 = ring["position"]
			var look: = _stand_by(player, where, Vector3(0.5, 0, 2.2))
			var tries: = 0
			while not ring["done"] and tries < 200:
				var sawing: = tree.saw(player, player.root_position(), look, 0.5)
				if not sawing and tries == 0:
					print("tree: the saw found nothing at ", where)
				tries += 1
				await _wait(0.05)
	await _snap("mid")

	for piece: Dictionary in held["pieces"]:
		if piece["butt"] or not piece["free"]:
			if not piece["butt"]:
				print("tree: a length was never cut free")
			continue
		var log_part: PartNode = piece["log"]
		var candidate: Dictionary = {}
		for one: Dictionary in held["trees"]:
			if piece in one["pieces"]:
				candidate = one["candidate"]
		var toward: Vector3 = candidate["toward"]
		var goal: Vector3 = candidate["position"] - toward * (18.0 + piece["length"]) + toward.cross(Vector3.UP) * randf_range(-6, 6)
		var end: = log_part.global_transform * Vector3( - (piece["length"] / 2.0 - 0.4), 0, 0)
		player.teleport(CallKit.ground_at(end - toward * 2.0) + Vector3(0, 0.3, 0))
		await _wait(0.1)
		tree.take(piece, player, -1.0)
		var steps: = 0
		while not piece["cleared"] and steps < 400:
			var here: = player.global_position
			var way: = Vector3(goal.x - here.x, 0, goal.z - here.z)
			if way.length() < 1.0:
				break
			player.teleport(CallKit.ground_at(here + way.normalized() * 0.5 + Vector3(0, 1, 0)) + Vector3(0, 0.3, 0))
			steps += 1
			await get_tree().physics_frame
		await _wait(0.3)
		print("tree: a %s dragged %d steps, %s; walking at %s" % ["crown" if piece["crown"] else ("heavy log" if piece["heavy"] else "log"), steps, "clear" if piece["cleared"] else "NOT CLEAR", player.walk_speed])
		tree.release(piece, player)
	var crash: Variant = held.get("crash")
	if crash != null:
		await _force_doors(player, crash)
		await _carry_all(player)


func _force_doors(player: Player, held: Dictionary) -> void :
	var crash: = CarCrash.current
	print("crash: %d doors, %d hazard lamps; the tools are %s" % [held["doors"].size(), held["hazards"].size(), "the crash's" if ToolService.current and ToolService.current.hydraulic.is_valid() else "NOT SET"])
	var first: = true
	for door: Dictionary in held["doors"]:
		var where: Vector3 = door["position"]
		var out: Vector3 = door["car"]["place"].basis.x * door["outward"]
		var look: = _stand_by(player, where, out * 3.0)

		var refused: = crash.work(player, "Cutter", player.root_position(), look, 0.5)
		for tool: String in ["Spreader", "Cutter"]:
			var tries: = 0
			var stage: int = door["stage"]
			while door["stage"] == stage and tries < 100:
				crash.work(player, tool, player.root_position(), look, 0.5)
				tries += 1
				await _wait(0.05)
			if first and tool == "Spreader":
				await _snap("mid")
				first = false
		print("crash: a door at stage %d (3 is off); the wrong tool was %s; its casualty is %s" % [door["stage"], "refused" if not refused[0] else "TAKEN", door["victim"].state if door["victim"] != null else "nobody"])



func _carry_all(player: Player) -> void :
	var people: = VictimService.current
	var ambulance: = AmbulanceService.current
	if people == null:
		return
	for victim: Victim in people.victims.duplicate():
		if victim.state != "lying":
			continue
		_stand_by(player, victim.position(), Vector3(2, 0, 0))
		await _wait(0.2)
		var lifted: = people.lift(victim, player)
		await _wait(0.5)
		var zone: Variant = ambulance.zone_position() if ambulance else null
		if zone != null:
			player.teleport(zone + Vector3(0, 0.5, 0))
		await _wait(1.0)
		print("victims: lifted %s, the box at %s, now %s (%d of %d out)" % [lifted, zone, victim.state, people.out, people.total])


func _play_crash(player: Player) -> void :
	var held: = CarCrash.current.scene
	if held["engine"] != null:
		print("crash: an engine is smoking")
	await _force_doors(player, held)
	if held["doors"].is_empty():
		await _snap("mid")
	await _carry_all(player)


func _play_medical(player: Player) -> void :
	var house: = LockedIn.current.house
	var locked: = 0
	for door_name: String in house.doors:
		if house.doors[door_name]["locked"]:
			locked += 1
	var people: = VictimService.current
	print("medical: %s, %d doors locked, %d inside in the %s" % [house.name, locked, people.total, people.victims[0].room if not people.victims.is_empty() else "?"])
	if not people.victims.is_empty():
		look(people.victims[0].position(), Vector3(7, 6, 40))
		await _wait(0.5)
		await _snap("mid")
	await _carry_all(player)


func _play_flood(player: Player) -> void :
	var flood: = FloodedCellar.current
	var hoses: = HoseService.current
	var truck: = Vehicle.named("Fire Truck")
	var source: = flood.source
	var inlet: Node3D = source["node"]

	var out: = - inlet.global_basis.z
	var across: = out.cross(Vector3.UP)
	truck.global_transform = Transform3D(Basis.looking_at(across), CallKit.ground_at(inlet.global_position + out * 16.0) + Vector3(0, 3.0, 0))
	truck.linear_velocity = Vector3.ZERO
	Config.Incidents["Flood"]["Flow"] = 900.0
	await _wait(1.5)
	var rig: Dictionary = {}
	for one: Dictionary in hoses.rigs:
		if one["vehicle"] == truck:
			rig = one
	_stand_by(player, truck.intake["node"].global_position, out * 3.0)
	hoses._on_intake(rig, player)
	await _wait(0.5)
	_stand_by(player, inlet.global_position, out * 3.0)
	await _wait(0.3)
	hoses._on_hydrant(source, player)
	await _wait(1.0)
	print("flood: the hose is %s; the valve is %s" % [rig["supply"]["state"], "fitted" if not flood.discharge.is_empty() else "NOT FITTED"])
	if flood.discharge.is_empty():
		return
	var line: Dictionary = flood.discharge["line"]
	print("flood: the outlet's prompt says '%s'" % Text.say(line["prompt"].action, "en"))
	hoses._last_use.clear()
	hoses._on_outlet(line, player)
	await _wait(2.0)
	print("flood: the valve is %s, %d of %d litres out, tank %d" % ["open" if flood.discharge.get("open", false) else "SHUT", int(Game.incident.get("done", 0)), int(Game.incident.get("total", 0)), int(truck.water)])
	var seen: = out * 1.6 - across
	look(inlet.global_position + out * 12.0, Vector3(34, 13, rad_to_deg(atan2(seen.x, seen.z))))
	await _wait(0.5)
	await _snap("mid")


func _play_rescue(player: Player) -> void :
	var rescue: = HeightRescue.current
	var ladder: = LadderService.current
	var root: Node3D = rescue.stranded["root"]
	var feet: = root.global_position - Vector3(0, rescue.stranded["rise"], 0)
	print("rescue: %s, %.1f studs up; the ladder is %s" % [root.name, root.global_position.y, "stowed" if ladder.is_stowed() else "up"])
	look(root.global_position, Vector3(14, 5, _view.z))
	await _wait(0.5)
	await _snap("mid")


	var truck: = ladder.vehicle
	var found: = Roads.nearest(NavGraph.current.layout, feet.x, feet.z)
	var way: = Roads.at(found[1], found[0]["along"])
	var along: = Vector3(way[2], 0, way[3])
	var middle: = Vector3(found[0]["x"], 0, found[0]["z"])
	var kerb: = (Vector3(feet.x, 0, feet.z) - middle).normalized() * (float(found[1]["width"]) / 2.0 - 5.0)
	truck.global_transform = Transform3D(Basis.looking_at(along), CallKit.ground_at(middle + kerb) + Vector3(0, 3.0, 0))
	truck.linear_velocity = Vector3.ZERO
	truck.reset_physics_interpolation()
	await _wait(1.5)
	ladder._jacks_down()
	var best: = Vector3.ZERO
	var best_gap: = INF
	for turn in range(-180, 180, 6):
		for raise in range(10, 76, 5):
			for slide in range(0, int(ladder._slide) + 1, 4):
				if ladder.reach_of(raise, slide) > ladder.max_outreach():
					continue
				ladder.turned = turn
				ladder.elevation = raise
				ladder.extension = slide
				ladder._place()
				var gap: = ladder.basket_position().distance_to(feet)
				if gap < best_gap:
					best_gap = gap
					best = Vector3(turn, raise, slide)
	ladder.turned = best.x
	ladder.elevation = best.y
	ladder.extension = best.z
	ladder._place()
	print("rescue: the truck at %s, the ladder turned %d, raised %d, out %d: the basket %.1f studs from their feet" % [truck.global_position, best.x, best.y, best.z, best_gap])
	player.teleport(CallKit.ground_at(truck.global_transform * Vector3(-9, 0, 0)) + Vector3(0, 0.5, 0))
	var between: = (ladder.basket_position() + truck.global_position) / 2.0
	look(between, Vector3(52, 16, rad_to_deg(atan2(along.x - kerb.normalized().x, along.z - kerb.normalized().z))))
	if best_gap > 8.0:
		rescue.pretend_near = true
	await _wait(3.2)
	print("rescue: aboard %s, at %s (the basket is at %s)" % [ladder.is_aboard(root), root.global_position, ladder.basket_position()])
	await _snap("aboard")

	ladder.turned = 0.0
	ladder.elevation = 0.0
	ladder.extension = 0.0
	ladder._place()
	await _wait(1.0)
	if is_instance_valid(root):
		print("rescue: down at %s, the ladder %s" % [root.global_position, "stowed" if ladder.is_stowed() else "NOT STOWED"])
		look(root.global_position, Vector3(20, 8, rad_to_deg(atan2(along.x, along.z)) + 150.0))
