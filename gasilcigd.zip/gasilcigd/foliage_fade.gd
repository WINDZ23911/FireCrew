class_name FoliageFade
extends Node










static var current: FoliageFade
static var amount: = 0.0
static var point: = Vector3.ZERO


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
	_apply_fade(0.0, point)


func _process(_delta: float) -> void :
	var player: = Game.local_player
	var drawn: = get_viewport().get_camera_3d()
	var on: = player != null and player.camera != null and drawn == player.camera.camera and bool(Config.Art.FoliageFade.On)
	if not on or player.camera.first_person() or player.camera.seated_view():
		_apply_fade(0.0, point)
		return
	var view: PlayerCamera = player.camera
	var focus: Vector3
	if view.subject != null and is_instance_valid(view.subject):
		focus = view.subject.global_position + Vector3(0, view.subject_height, 0)
	else:
		focus = player.head_position() + Vector3(0, 0.6, 0)
	_apply_fade(1.0, focus)


func _apply_fade(value: float, at: Vector3) -> void :
	if value == amount and at == point:
		return
	amount = value
	point = at
	var radius: = float(Config.Art.FoliageFade.Radius) * value
	RenderingServer.global_shader_parameter_set("focus_point", Vector4(at.x, at.y, at.z, radius))
