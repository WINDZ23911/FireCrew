class_name InteriorGrade
extends Node






const LOOK_EVERY: = 0.15

static var current: InteriorGrade

var inside: = 0.0
var _wanted: = 0.0
var _since: = 0.0
var _attributes: CameraAttributesPractical
var _warm: GradientTexture1D
var _warm_color: = Color.WHITE
var _station_box: = AABB()


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var look: Dictionary = Config.Art.Interior
	_attributes = CameraAttributesPractical.new()
	var gradient: = Gradient.new()
	var warm: Array = look["Warm"]
	_warm_color = Color(warm[0], warm[1], warm[2])
	gradient.set_color(0, Color.BLACK)
	gradient.set_color(1, Color.WHITE)
	_warm = GradientTexture1D.new()
	_warm.gradient = gradient
	_warm.width = 64



func _station() -> AABB:
	if _station_box.size == Vector3.ZERO and Game.station != null:
		var store: = Game.store
		for row in Game.station._plan_rows:
			if store.name_at(row) in ["GarageFloor", "AlleyFloor", "WingFloor"]:
				var box: = AABB(store.position(row) - store.size(row) / 2.0, store.size(row))
				_station_box = box if _station_box.size == Vector3.ZERO else _station_box.merge(box)
		_station_box.size.y = 34.0
	return _station_box


func _process(delta: float) -> void :
	_since += delta
	if _since >= LOOK_EVERY:
		_since = 0.0
		_wanted = 1.0 if _camera_inside() else 0.0
	var was: = inside
	inside = move_toward(inside, _wanted, delta / maxf(float(Config.Art.Interior.Ease), 0.01))
	if inside != was or (inside > 0.0 and Sky3D.current != null and Sky3D.current.world_environment.camera_attributes != _attributes):
		_apply()


func _camera_inside() -> bool:
	if not bool(Config.Art.Interior.On):
		return false
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return false
	var at: = camera.global_position
	if _station().has_point(at):
		return true
	for house: House in House.all:
		if house.position.distance_to(at) < 60.0 and house.room_at(at) != null:
			return true
	return false


func _apply() -> void :
	if Sky3D.current == null or Sky3D.current.world_environment == null:
		return
	var look: Dictionary = Config.Art.Interior
	var holder: = Sky3D.current.world_environment
	if inside <= 0.0:
		if holder.camera_attributes == _attributes:
			holder.camera_attributes = null
	else:
		_attributes.exposure_multiplier = lerpf(1.0, float(look["Exposure"]), inside)
		if holder.camera_attributes != _attributes:
			holder.camera_attributes = _attributes


	if inside > 0.0:
		_warm.gradient.set_color(1, Color.WHITE.lerp(_warm_color, inside))
	var wanted: Texture = _warm if inside > 0.0 else null
	if holder.environment.adjustment_color_correction != wanted:
		holder.environment.adjustment_color_correction = wanted
