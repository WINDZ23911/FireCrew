extends RefCounted







const AREA: = Rect2(-90, -140, 180, 120)
const INSET: = 0.1
const ROOFS: = ["MainRoofFront", "MainRoofBack", "MainRoofSlab", "MainRidgeFront", "MainRidgeBack", 
	"WingRoofFront", "WingRoofBack", "WingRoofSlab", "WingRidgeFront", "WingRidgeBack"]
const PROUD: = ["Pillar", "Lintel"]


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var changed: = 0
	for part_name: String in ROOFS + PROUD:
		for row in store.rows_named(part_name):
			var at: = store.position(row)
			if not AREA.has_point(Vector2(at.x, at.z)):
				continue
			var size: = store.size(row)
			if part_name in ROOFS:
				size.x -= INSET * 2.0
			else:
				size.x += 0.08
			store.set_size(row, size)
			changed += 1
	return "%d station seams closed" % changed
