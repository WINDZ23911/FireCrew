extends RefCounted



static func start(main: Node) -> void :
	if OS.get_cmdline_user_args().has("--lawn-survey"):
		var survey: = LawnSurvey.new()
		survey.name = "LawnSurvey"
		main.add_child(survey)
