class_name CrewReports
extends RefCounted






static var _next: = 0.0
static var _burning: Dictionary = {}
static var _found: Dictionary = {}


static func tick(service: CrewService) -> void :
	if Game.now() < _next:
		return
	_next = Game.now() + float(Config.Crew.Reports.Every)
	var fire: = FireService.current
	if Game.incident.is_empty():
		_burning.clear()
		_found.clear()
		return
	_finds(service)
	if fire == null or fire.incident.is_empty() or not fire.incident["group"]["building"] is House:
		return
	var house: House = fire.incident["group"]["building"]
	var rules: Dictionary = Config.Crew.Reports

	var alight: Dictionary = {}
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"] and node["room"] != null:
			alight[node["room"]] = true
	for room_name: String in alight:
		_burning[room_name] = true
	for room_name: String in _burning:
		if not alight.has(room_name):
			var near: = _nearest(service, CrewSearch.middle(house, room_name), float(rules["Near"]))
			if near != null:
				near.report("crew.say.report.knockedDown", [CrewSearch.room_words(room_name)], "good")

	var flash: = float(Config.Fire.FlashoverHeat)
	for mind in service.members:
		if mind.body.health <= 0.0 or mind.body.seat != null:
			continue
		var inside: Variant = house.room_at(mind.body.root_position())
		if inside == null:
			continue
		var room_name: String = inside["name"]
		var state: Dictionary = fire.incident["rooms"].get(room_name, {})
		var words: Variant = CrewSearch.room_words(room_name, true)
		if state.get("flash_at") != null:
			mind.report("crew.say.report.flashover", [words], "danger")
		elif float(state.get("warmth", 0.0)) >= flash * float(rules["Heat"]):
			mind.report("crew.say.report.heat", [words], "warning")
		elif fire.smoke_at(mind.body.root_position() + Vector3(0, float(rules["BankHeight"]), 0)) > float(rules["Bank"]):
			mind.report("crew.say.report.smoke", [words], "info")



static func _finds(service: CrewService) -> void :
	var people: = VictimService.current
	if people == null:
		return
	for victim: Victim in people.victims:
		var was: bool = _found.get(victim.id, victim.found)
		_found[victim.id] = victim.found
		if was or not victim.found or victim.room.is_empty() or victim.room == "wreck":
			continue
		var near: = _nearest(service, victim.position(), float(Config.Victims.Search.FindRange) + 2.0)
		if near != null:
			near.report("crew.say.report.found", [CrewSearch.room_words(victim.room, true)], "warning")


static func _nearest(service: CrewService, at: Vector3, within: float) -> Crewman:
	var best: Crewman = null
	var best_distance: = within
	for mind in service.members:
		var distance: = mind.body.global_position.distance_to(at)
		if mind.body.health > 0.0 and distance < best_distance:
			best_distance = distance
			best = mind
	return best
