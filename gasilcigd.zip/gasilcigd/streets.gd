extends ProofDebug





func _scenario_streets() -> void :
	await _wait(2.0)
	var traffic: = Traffic.current
	_check(traffic != null and not traffic.segments.is_empty(), "the town has roads")
	if traffic == null:
		_done()
		return
	var count: = 10
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--count="):
			count = int(arg.substr(8))

	var by_square: Dictionary = {}
	for segment: Dictionary in traffic.segments:
		if segment.get("kind") != "lane":
			continue
		var points: PackedVector2Array = segment["points"]
		if points.size() < 2:
			continue
		var length: = 0.0
		for index in points.size() - 1:
			length += points[index].distance_to(points[index + 1])
		if length < 40.0:
			continue
		var middle: = points[points.size() / 2]
		var key: = Vector2i(floori(middle.x / 160.0), floori(middle.y / 160.0))
		if not by_square.has(key) or length > float(by_square[key]["length"]):
			by_square[key] = {"length": length, "points": points, "road": segment.get("road", "")}
	var squares: Array = by_square.keys()
	squares.sort_custom( func(a: Vector2i, b: Vector2i) -> bool: return a.y < b.y if a.y != b.y else a.x < b.x)
	var step: = maxf(1.0, float(squares.size()) / count)
	var shown: = 0
	var index: = 0.0
	while index < squares.size() and shown < count:
		var lane: Dictionary = by_square[squares[int(index)]]
		var points: PackedVector2Array = lane["points"]
		var a: = points[points.size() / 2 - 1] if points.size() > 2 else points[0]
		var b: = points[points.size() / 2] if points.size() > 2 else points[1]
		var along: = Vector3(b.x - a.x, 0, b.y - a.y).normalized()
		var right: = along.cross(Vector3.UP)
		var at: = _ground(Vector3(a.x, 0, a.y))
		player.teleport(_ground(at - along * 40.0 + right * 6.0) + Vector3(0, 0.2, 0))
		await _wait(0.4)

		_view(at + right * 6.0 + Vector3(0, 4.8, 0) - along * 4.0, at + along * 30.0 + Vector3(0, 2.0, 0), 62.0)
		await _wait(0.3)
		await _snap("along%02d" % shown)

		_view(at - right * 8.0 + Vector3(0, 2.2, 0) + along * 6.0, at + right * 6.0 + Vector3(0, 0.5, 0), 60.0)
		await _wait(0.3)
		await _snap("across%02d" % shown)
		print("streets: %d at (%.0f, %.0f) along %s, road %s" % [shown, a.x, a.y, str(along), str(lane["road"])])
		shown += 1
		index += step
	_done()
