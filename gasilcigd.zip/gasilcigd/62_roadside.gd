extends RefCounted






const POST_EVERY: = 100.0
const POST_OFF: = 2.6
const SHRINES: = 3
const ROADS: = ["primary", "secondary", "tertiary", "residential"]

const WHITE: = Color(0.93, 0.93, 0.9)
const BLACK: = Color(0.08, 0.08, 0.09)
const RED: = Color(0.78, 0.1, 0.08)
const REFLECTOR_WHITE: = Color(0.96, 0.96, 0.94)


static func apply(kit: PolishKit) -> String:
	var parent: = kit.own_folder("Roadside")
	var roads: Array = kit.layout()["roads"]
	var posts: = 0
	for road: Dictionary in roads:
		if ROADS.has(road["class"]):
			posts += _posts(kit, parent, road)
	var shrines: = _shrines(kit, parent)
	return "%d marker posts, %d shrines" % [posts, shrines]


static func _posts(kit: PolishKit, parent: int, road: Dictionary) -> int:
	var half: = float(road["width"]) / 2.0
	var made: = 0
	for spot: Array in PolishKit.along_road(road["points"], POST_EVERY, POST_EVERY / 2.0):
		var on_road: Vector3 = spot[0]
		var way: Vector3 = spot[1]
		if not kit.country_road(on_road, way, half) or _kerbed(kit, on_road, way, half):
			continue
		var across: = Vector3( - way.z, 0, way.x)
		for side: float in [-1.0, 1.0]:
			var foot: = on_road + across * side * (half + POST_OFF)
			if not kit.open_ground(foot, 0.8):
				continue

			var toward: = - way * side
			var place: = PolishKit.facing(foot, toward)
			kit.box(parent, place.translated_local(Vector3(0, 1.8, 0)), Vector3(0.55, 3.6, 0.4), WHITE, "SmoothPlastic", "MarkerPost")
			kit.box(parent, place.translated_local(Vector3(0, 2.75, 0)), Vector3(0.57, 0.85, 0.42), BLACK, "SmoothPlastic", "MarkerBand")
			kit.box(parent, place.translated_local(Vector3(0, 2.75, -0.22)), Vector3(0.32, 0.5, 0.04), RED, "SmoothPlastic", "MarkerReflector")
			kit.box(parent, place.translated_local(Vector3(0, 2.75, 0.22)), Vector3(0.22, 0.22, 0.04), REFLECTOR_WHITE, "SmoothPlastic", "MarkerReflector")
			made += 1
	return made



static func _kerbed(kit: PolishKit, on_road: Vector3, way: Vector3, half: float) -> bool:
	var across: = Vector3( - way.z, 0, way.x)
	for side: float in [-1.0, 1.0]:
		for out: float in [half, half + 1.0, half + 2.0]:
			var surface: = kit.surface_at(on_road + across * side * out)
			if surface == "kerb" or surface == "kerbstone":
				return true
	return false



static func _shrines(kit: PolishKit, parent: int) -> int:
	var rng: = kit.rng("shrines")
	var nodes: Array = kit.layout()["nodes"].duplicate()
	var made: = 0
	var placed: Array = []

	for index in range(nodes.size() - 1, 0, -1):
		var other: = rng.randi_range(0, index)
		var keep: Variant = nodes[index]
		nodes[index] = nodes[other]
		nodes[other] = keep
	for node: Dictionary in nodes:
		if made >= SHRINES or node["kind"] != "junction":
			continue
		var middle: = Vector3(float(node["x"]), 0, float(node["z"]))
		if kit.building_distance(middle, 110.0) < 110.0:
			continue
		var far: = true
		for other: Vector3 in placed:
			if other.distance_to(middle) < 500.0:
				far = false
		if not far:
			continue
		for angle: float in [PI / 4, 3 * PI / 4, 5 * PI / 4, 7 * PI / 4]:
			var foot: = middle + Vector3(cos(angle), 0, sin(angle)) * 34.0
			if kit.open_ground(foot, 4.5) and not kit.paved_street(middle, Vector3.RIGHT, 24.0):
				_shrine(kit, parent, PolishKit.facing(foot, middle - foot))
				placed.append(middle)
				made += 1
				break
	return made


static func _shrine(kit: PolishKit, parent: int, place: Transform3D) -> void :
	var white: = Color8(244, 242, 234)
	kit.box(parent, place.translated_local(Vector3(0, 0.3, 0)), Vector3(5, 0.6, 5), Color8(176, 172, 164), "Concrete", "ShrineStep", PolishKit.SOLID)
	kit.box(parent, place.translated_local(Vector3(0, 5.1, 0)), Vector3(3.4, 9, 3.4), white, "Plaster", "Shrine", PolishKit.SOLID)
	kit.box(parent, place.translated_local(Vector3(0, 7.2, -1.74)), Vector3(1.8, 2.8, 0.12), Color8(56, 84, 150), "SmoothPlastic", "Niche")
	kit.box(parent, place.translated_local(Vector3(0, 6.4, -1.95)), Vector3(0.3, 0.9, 0.3), Color8(200, 40, 44), "SmoothPlastic", "Candle")
	for turn: float in [0.0, PI]:
		var roof: = Transform3D(place.basis * Basis(Vector3.UP, PI / 2 + turn), place.origin)
		kit.wedge(parent, roof.translated_local(Vector3(0, 10.7, -1.2)), Vector3(4.8, 2.2, 2.4), Color8(150, 70, 52), "ClayRoofTiles", "ShrineRoof")
	kit.box(parent, place.translated_local(Vector3(0, 12.6, 0)), Vector3(0.25, 1.8, 0.25), Color8(44, 48, 52), "Metal", "Cross")
	kit.box(parent, place.translated_local(Vector3(0, 12.9, 0)), Vector3(1, 0.25, 0.25), Color8(44, 48, 52), "Metal", "Cross")
