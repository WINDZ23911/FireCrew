class_name HudDuty
extends Control






const WIDTH: = 210.0
const LINE: = 22.0
const PAD: = 8.0
const SHIFT_LINE: = 18.0
const RADAR: = 210.0
const STATUS_COLORS: = {"available": Ui.GREEN, "returning": Ui.AMBER, "out": Ui.RED}

var _plate: Control
var _lamp: ColorRect
var _status: Label
var _shift: Label
var _lines: Array[Label] = []


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, PAD * 2 + LINE))
	add_child(_plate)
	_lamp = ColorRect.new()
	_lamp.size = Vector2(10, 10)
	_lamp.position = Vector2(PAD, PAD + 6)
	_lamp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_lamp)
	_status = Ui.display("", 17)
	_status.position = Vector2(PAD + 16, PAD - 2)
	_plate.add_child(_status)
	_shift = Ui.caps("", 14)
	_shift.position = Vector2(PAD, PAD + LINE - 2)
	_shift.size = Vector2(WIDTH - PAD * 2, SHIFT_LINE)
	_shift.clip_text = true
	_plate.add_child(_shift)
	for index in 2:
		var line: = Ui.label("", 16)
		line.size = Vector2(WIDTH - PAD * 2, LINE)
		line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		line.add_theme_constant_override("outline_size", 4)
		line.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
		_plate.add_child(line)
		_lines.append(line)



static func clock(seconds: float) -> String:
	var whole: = maxi(ceili(seconds), 0)
	return "%d:%02d" % [floori(whole / 60.0), whole % 60]



func shown_text() -> String:
	var parts: PackedStringArray = [_status.text]
	if _shift.visible:
		parts.append(_shift.text)
	for line in _lines:
		if line.visible and not line.text.is_empty():
			parts.append(line.text)
	return " | ".join(parts)


func _process(_delta: float) -> void :
	var duty: = Duty.current
	if duty == null or Game.local_player == null:
		_plate.visible = false
		return
	_plate.visible = true
	var state: Dictionary = duty.state
	var status: = String(state.get("status", "available"))
	_lamp.color = Ui.state(STATUS_COLORS.get(status, Ui.DIM))
	_status.text = Text.say(Text.m("hud.duty." + status))
	_shift.text = Text.say(Shift.words(String(state.get("shift", Shift.current())))).to_upper()
	var said: Array = []
	var incident: = Game.incident
	if status == "out":
		if incident.has("ignite_in"):
			var left: = float(incident["ignite_in"])
			match String(incident.get("ignite_state", "run")):
				"held":
					said.append([Text.say(Text.f("hud.duty.ignitePaused", [clock(left)])), Ui.BLUE])
				"wait":
					said.append([Text.say(Text.f("hud.duty.igniteFrom", [clock(left)])), Ui.AMBER])
				_:
					said.append([Text.say(Text.f("hud.duty.igniteIn", [clock(left)])), Ui.RED if left <= 15.0 else Ui.AMBER])
		if incident.has("closes_in"):
			said.append([Text.say(Text.f("hud.duty.closesIn", [clock(float(incident["closes_in"]))])), Ui.AMBER])
	else:
		var next: = int(state.get("next", -1))
		if next >= 0:
			said.append([Text.say(Text.f("hud.duty.nextIn", [clock(next)])), Ui.TEXT])
		elif state.get("settling", false):
			said.append([Text.say(Text.m("hud.duty.backFirst")), Ui.TEXT])
		if status == "available" and not state.get("reported", false):
			said.append([Text.say(Text.f("hud.duty.report", [Controls.key_name(Duty.ACTION)])), Ui.YELLOW])

	_shift.visible = status != "out"
	var y: = PAD + LINE + (SHIFT_LINE if _shift.visible else 0.0)
	for index in _lines.size():
		var line: = _lines[index]
		line.visible = index < said.size()
		if line.visible:
			line.text = said[index][0]
			line.add_theme_color_override("font_color", said[index][1])
			line.position = Vector2(PAD, y)
			var tall: = maxf(line.get_line_count(), 1) * line.get_line_height()
			line.size = Vector2(WIDTH - PAD * 2, tall)
			y += tall + 2.0
	_plate.size = Vector2(WIDTH, y + PAD - 2.0)

	var top: = Ui.MARGIN + RADAR + 12
	var card: Variant = HudDispatch.current.get("_card") if HudDispatch.current != null else null
	if card is Control and (card as Control).visible:
		top = (card as Control).position.y + (card as Control).size.y + 18
	_plate.position = Vector2(Ui.MARGIN, top)
