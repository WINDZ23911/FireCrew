extends RefCounted



static func start(main: Node) -> void :
	if Ground.top == - INF:
		return
	var ground: = Ground.new()
	ground.name = "Ground"
	main.add_child(ground)
