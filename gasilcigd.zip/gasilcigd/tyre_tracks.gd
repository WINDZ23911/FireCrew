class_name TyreTracks
extends Node3D





const STRIPS: = 3000
const STEP: = 1.6
const LIFE: = 240.0
const LIFT: = 0.05
const TYRE: = 1.5

var _mesh: MultiMesh
var _material: ShaderMaterial
var _next: = 0
var _laid: = 0
var _last: Dictionary = {}


func _ready() -> void :
	_mesh = MultiMesh.new()
	_mesh.transform_format = MultiMesh.TRANSFORM_3D
	_mesh.use_custom_data = true
	var plane: = PlaneMesh.new()
	plane.size = Vector2.ONE
	_mesh.mesh = plane
	_mesh.instance_count = STRIPS
	_mesh.visible_instance_count = 0
	_material = ShaderMaterial.new()
	_material.shader = load("res://shaders/tyre_track.gdshader")
	_material.set_shader_parameter("life", LIFE)
	var drawn: = MultiMeshInstance3D.new()
	drawn.name = "Tracks"
	drawn.multimesh = _mesh
	drawn.material_override = _material
	drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	drawn.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	drawn.extra_cull_margin = 4000.0
	add_child(drawn)


func _process(_delta: float) -> void :
	if not Style.winter():
		if _laid > 0:
			_laid = 0
			_next = 0
			_last.clear()
			_mesh.visible_instance_count = 0
		return
	_material.set_shader_parameter("now", Game.now())
	for vehicle: Vehicle in Vehicle.all:
		if not is_instance_valid(vehicle) or not vehicle.is_inside_tree():
			continue
		var place: = vehicle.global_transform
		var foot: = float(vehicle.data["axleY"]) - float(vehicle.data["wheelRadius"])
		for side: float in [-1.0, 1.0]:
			var wheel: Vector3 = place * Vector3(side * vehicle.track, foot, vehicle.rear_axle)
			var key: = [vehicle.get_instance_id(), side]
			var from: Variant = _last.get(key)
			if from == null:
				_last[key] = wheel
				continue
			var gone: = Vector2(wheel.x - from.x, wheel.z - from.z).length()
			if gone < STEP:
				continue
			_last[key] = wheel
			if gone > STEP * 6.0:
				continue
			_lay(from, wheel, vehicle)



func _lay(from: Vector3, to: Vector3, vehicle: Vehicle) -> void :
	var middle: = (from + to) / 2.0
	var hit: = Game.world.raycast(middle + Vector3(0, 3, 0), middle + Vector3(0, -4, 0), World.LAYER_SOLID, [vehicle.get_rid()])
	if hit.is_empty():
		return
	var row: = Game.world.row_hit(hit)
	if row < 0:
		return
	var depth: = 1.0
	if Game.store.material(row) in World.FAR_HARD:
		depth = RoadSnow.current.depth_at(hit["position"]) if RoadSnow.current else 1.0
		if depth < 0.15:
			return
	var normal: Vector3 = hit["normal"]
	if normal.y < 0.6:
		return
	var along: = Vector3(to.x - from.x, 0, to.z - from.z)
	var length: = along.length()
	along = (along - normal * along.dot(normal)).normalized()
	var across: = normal.cross(along).normalized()
	var basis: = Basis(across * TYRE, normal, along * (length + 0.1))
	_mesh.set_instance_transform(_next, Transform3D(basis, hit["position"] + normal * LIFT))
	_mesh.set_instance_custom_data(_next, Color(Game.now(), length, clampf(depth, 0.0, 1.0), 0.0))
	_next = (_next + 1) % STRIPS
	_laid = mini(_laid + 1, STRIPS)
	_mesh.visible_instance_count = _laid
