extends ProofDebug






var _shot: = {}


func _scenario_stairsall() -> void :
	proof_name = "stairsall"
	await _wait(1.0)
	var done: = {}
	for house: House in House.all:
		var module: String = house.record.get("house", house.name)
		if done.has(module):
			continue
		done[module] = true
		for flight: Dictionary in _flights(house.data["parts"]):
			await _climb(house, module, flight)
	_check(done.size() > 10, "%d kinds of house looked at" % done.size())
	await _done()





func _flights(parts: Array) -> Array:
	var strips: = {}
	for row: Array in parts:
		if row[1] != "Step" and row[1] != "OutsideStep":
			continue
		var key: = "%s %.1f %.1f" % [row[1], float(row[5]) - float(row[2]) / 2.0, float(row[5]) + float(row[2]) / 2.0]
		if not strips.has(key):
			strips[key] = []
		strips[key].append(row)
	var flights: Array = []
	for key: String in strips:
		var rows: Array = strips[key]
		rows.sort_custom( func(a: Array, b: Array) -> bool: return float(a[6]) + float(a[3]) / 2.0 < float(b[6]) + float(b[3]) / 2.0)

		var runs: Array = [[rows[0]]]
		for i in range(1, rows.size()):
			var previous: Array = runs[-1][-1]
			if absf(float(rows[i][7]) - float(previous[7])) > float(previous[4]) * 1.5:
				runs.append([])
			runs[-1].append(rows[i])
		for steps: Array in runs:
			if steps.size() < 4:
				continue
			var low: Array = steps[0]
			var high: Array = steps[-1]
			var way: = signf(float(high[7]) - float(low[7]))
			var bottom: = float(low[6]) - float(low[3]) / 2.0
			flights.append({
				"kind": String(low[1]), "way": way, "bottom": bottom, "top": float(high[6]) + float(high[3]) / 2.0, 
				"foot": Vector3(float(low[5]), bottom, float(low[7]) - way * (float(low[4]) / 2.0 + 2.2)), 
				"head": Vector3(float(high[5]), float(high[6]) + float(high[3]) / 2.0, float(high[7])), 
			})
	return flights



func _climb(house: House, module: String, flight: Dictionary) -> void :
	var lot: = house.lot
	var foot: Vector3 = lot * flight["foot"]
	var top_y: float = (lot * Vector3(0, flight["top"], 0)).y
	var ahead: Vector3 = lot.basis * Vector3(0, 0, flight["way"])
	player.teleport(foot + Vector3(0, 0.4, 0))
	player.camera.yaw = atan2( - ahead.x, - ahead.z)
	player.camera.pitch = 0.0
	player.rig.rotation.y = player.camera.yaw
	await _wait(0.5)
	var start: = player.global_position
	Input.action_press("move_forward")
	var began: = Game.now()
	while player.global_position.y < top_y - 0.4 and Game.now() - began < 9.0:
		await _wait(0.05)
	var took: = Game.now() - began

	await _wait(0.5)
	Input.action_release("move_forward")
	await _wait(0.4)
	var at: = player.global_position
	var what: = "%s, %s from %.1f up to %.1f" % [module, flight["kind"], foot.y, top_y]
	print("stairsall: %s: started at %s, %.1f s to the top, now %.1f studs up (%.1f studs on)" % [what, start, took, at.y - foot.y, ((at - start) * Vector3(1, 0, 1)).length()])
	if flight["kind"] == "Step":

		_shot[module] = _shot.get(module, 0) + 1
		var middle: Vector3 = lot * ((flight["foot"] + flight["head"]) / 2.0)
		player.teleport(foot + Vector3(0, 0.4, 0) - ahead * 3.0)
		await _wait(0.3)
		_view(foot - ahead * 2.0 + Vector3(0, 5.5, 0), middle + Vector3(0, 2, 0), 75.0)
		await _wait(0.4)
		await _snap("stairs_%s%d" % [module, _shot[module]])
		_view_player()
	_check(at.y >= top_y - 0.6, "%s: walked on to the stairs from in front and up to the floor above" % what)





func _scenario_roomlook() -> void :
	proof_name = "roomlook"
	await _wait(1.0)
	var wanted: Array = []
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--rooms="):
			wanted = Array(arg.substr(8).split(","))
	var done: = {}
	var taken: = 0
	for house: House in House.all:
		var module: String = house.record.get("house", house.name)
		if done.has(module) or ( not wanted.is_empty() and not wanted.has(module)):
			continue
		done[module] = true
		for room_name: String in house.rooms:
			var room: Dictionary = house.rooms[room_name]
			var low: Vector3 = room["low"]
			var high: Vector3 = room["high"]
			var from: = house.lot * Vector3(low.x + 1.2, low.y + 5.6, low.z + 1.2)
			var to: = house.lot * Vector3(high.x - 1.0, low.y + 2.0, high.z - 1.0)
			player.teleport(house.lot * Vector3((low.x + high.x) / 2.0, low.y + 0.4, (low.z + high.z) / 2.0))
			_view(from, to, 80.0)
			await _wait(0.5)
			await _snap("%s_%s" % [module, room_name.replace(" ", "").replace("'", "")])
			taken += 1
	_check(taken > 0, "%d rooms pictured" % taken)
	await _done()
