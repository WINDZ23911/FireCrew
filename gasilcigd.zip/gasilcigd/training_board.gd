class_name TrainingBoard
extends Control









const WIDTH: = 940.0
const CARD: = Vector2(452.0, 112.0)
const HEADER: = 70.0
const GAP: = 8.0
const REACH: = 20.0
const WOOD: = Color(0.42, 0.3, 0.2)
const STEEL: = Color(0.2, 0.21, 0.23)
const PAPER: = Color(0.97, 0.97, 0.95)

static var current: TrainingBoard

var _plate: Control
var _rows: Control
var _title: Label
var _cash: Label
var _open: = false
var _confirming: = ""
var _choices: Array[Callable] = []
var _board: Node3D
var _labels: Array = []


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 90)
	_title = Ui.display("", 30)
	_title.position = Vector2(24, 16)
	_plate.add_child(_title)
	_cash = Ui.display("", 26, Ui.AMBER)
	_cash.position = Vector2(WIDTH - 244, 18)
	_cash.size = Vector2(220, 32)
	_cash.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_cash)
	_rows = Control.new()
	_rows.position = Vector2(16, HEADER)
	_rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_rows)
	Net.handle("training.open", open)
	Text.language_changed.connect( func(_code: String) -> void :
		if _open:
			_draw()
	)
	_build_board.call_deferred()


func _exit_tree() -> void :
	if current == self:
		current = null




func _build_board() -> void :
	if Game.store == null or Game.world == null:
		return
	var table: Variant = Config.Training.get("Table")
	if table is Dictionary:
		_build_table(table)
		return
	var row: = -1
	for index in Game.store.count:
		if Game.store.name_at(index) == "TrainingPlan":
			row = index
			break
	if row < 0:
		return
	var place: = Game.store.transform(row)
	var size: = Game.store.size(row)

	var axis: = place.basis.x if size.x < size.y and size.x < size.z else (place.basis.y if size.y < size.z else place.basis.z)
	axis = axis.normalized()
	var behind: = Game.world.raycast(place.origin, place.origin - axis * 4.0, World.LAYER_SOLID)
	if behind.is_empty():
		axis = - axis
	_board = Node3D.new()
	_board.name = "TrainingBoard"
	get_tree().current_scene.add_child(_board)
	_board.global_position = place.origin + axis * 1.0
	var under: = Label3D.new()
	under.text = Text.say(Text.m("training.under"))
	under.font_size = 36
	under.pixel_size = 0.01
	under.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	under.modulate = Ui.YELLOW
	under.outline_size = 8
	under.position = Vector3(0, - minf(size.y, 4.0) / 2.0 - 0.6, 0)
	_board.add_child(under)
	Text.language_changed.connect( func(_code: String) -> void : under.text = Text.say(Text.m("training.under")))
	_prompt(Vector3(0, -1.0, 0))






func _build_table(table: Dictionary) -> void :
	var at: Vector3 = Rbx.decode(table["at"]) if not table["at"] is Vector3 else table["at"]
	var out: Vector3 = (Rbx.decode(table["out"]) if not table["out"] is Vector3 else table["out"]).normalized()
	_board = Node3D.new()
	_board.name = "TrainingTable"
	get_tree().current_scene.add_child(_board)
	_board.global_transform = Transform3D(Basis.looking_at( - out), at)


	var top_y: = 3.1
	_box(Vector3(4.2, 0.28, 2.4), Vector3(0, top_y, 1.6), WOOD)
	_box(Vector3(4.0, 0.12, 2.2), Vector3(0, top_y - 0.2, 1.6), STEEL)
	for side: float in [-1.8, 1.8]:
		_box(Vector3(0.22, top_y - 0.3, 0.22), Vector3(side, (top_y - 0.3) / 2.0, 0.7), STEEL)
		_box(Vector3(0.22, top_y - 0.3, 0.22), Vector3(side, (top_y - 0.3) / 2.0, 2.5), STEEL)
		_box(Vector3(0.22, 0.22, 2.0), Vector3(side, 0.5, 1.6), STEEL)

	_box(Vector3(1.8, 0.1, 1.2), Vector3(-0.7, top_y + 0.19, 1.5), STEEL)
	var screen: = _box(Vector3(1.8, 1.2, 0.08), Vector3(-0.7, top_y + 0.78, 0.92), STEEL)
	screen.rotation.x = deg_to_rad(-12.0)
	_box(Vector3(1.6, 1.0, 0.02), Vector3(0, 0.0, 0.06), Color(0.55, 0.9, 0.3), 1.6, screen)

	_box(Vector3(0.9, 0.06, 1.3), Vector3(0.9, top_y + 0.17, 1.8), PAPER)
	_box(Vector3(0.9, 0.04, 0.18), Vector3(0.9, top_y + 0.22, 1.22), STEEL)
	_box(Vector3(0.38, 0.46, 0.38), Vector3(1.65, top_y + 0.37, 1.0), Color(0.84, 1.0, 0.24))

	var board_y: = 7.0
	_box(Vector3(4.6, 4.2, 0.12), Vector3(0, board_y, 0.1), Color(0.16, 0.16, 0.18))
	_box(Vector3(4.3, 3.9, 0.04), Vector3(0, board_y, 0.18), PAPER)
	_box(Vector3(4.3, 1.15, 0.02), Vector3(0, board_y + 1.3, 0.21), Ui.YELLOW)
	_words("sign", Vector3(0, board_y + 1.3, 0.24), 52, Ui.DARK, 4.2)
	_words("signLine", Vector3(0, board_y - 0.5, 0.24), 30, Color(0.12, 0.12, 0.14), 3.9)

	_box(Vector3(4.6, 0.14, 0.5), Vector3(0, board_y + 2.4, 0.45), Color(0.95, 0.95, 0.9), 2.2)

	for piece: Array in [[Vector3(6.0, 0.02, 0.18), Vector3(0, 0.03, 0.3)], [Vector3(6.0, 0.02, 0.18), Vector3(0, 0.03, 4.8)], [Vector3(0.18, 0.02, 4.6), Vector3(-3.0, 0.03, 2.55)], [Vector3(0.18, 0.02, 4.6), Vector3(3.0, 0.03, 2.55)]]:
		_box(piece[0], piece[1], Color(0.9, 0.78, 0.2))

	var body: = StaticBody3D.new()
	body.collision_layer = World.LAYER_SOLID
	body.collision_mask = 0
	var shape: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = Vector3(4.2, top_y + 0.3, 2.4)
	shape.shape = box
	shape.position = Vector3(0, (top_y + 0.3) / 2.0, 1.6)
	body.add_child(shape)
	_board.add_child(body)
	_prompt(Vector3(0, 2.6, 3.2))
	Text.language_changed.connect(_say)
	_say()


func _box(size: Vector3, at: Vector3, color: Color, emission: = 0.0, parent: Node3D = null) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	var box: = BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var material: = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.75
	if emission > 0.0:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = emission
	mesh.material_override = material
	mesh.position = at
	(parent if parent != null else _board).add_child(mesh)
	return mesh


func _words(key: String, at: Vector3, size: int, color: Color, width: float) -> void :
	var label: = Label3D.new()
	label.font = Ui.display_font() if size > 60 else Ui.label_font()
	label.font_size = size
	label.pixel_size = 0.01
	label.modulate = color
	label.outline_size = 0
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if size <= 60 else TextServer.AUTOWRAP_OFF
	label.width = width / label.pixel_size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.position = at
	_board.add_child(label)
	_labels.append([label, key])


func _say(_code: = "") -> void :
	for entry: Array in _labels:
		(entry[0] as Label3D).text = Text.say(Text.m("training." + String(entry[1])))




func _prompt(at: Vector3) -> void :
	var prompt: = Prompt.new()
	prompt.net_id = "training.board"
	prompt.action = Text.m("training.action")
	prompt.object = Text.m("training.object")
	prompt.reach = 10.0
	prompt.position = at
	prompt.condition = func(player: Player) -> bool: return player.brain == null
	_board.add_child(prompt)
	prompt.triggered.connect( func(player: Player) -> void :
		Net.send_to(player, "training.open")
	)



func board_position() -> Vector3:
	return _board.global_position if _board != null else Vector3.INF


func is_open() -> bool:
	return _open


func open() -> void :
	var player: = Game.local_player
	if player == null or _open:
		return
	_open = true
	_confirming = ""
	_draw()
	_plate.visible = true
	MenuKit.take_mouse(player, true)
	if not player.attribute_changed.is_connected(_on_attribute):
		player.attribute_changed.connect(_on_attribute)


func close() -> void :
	if not _open:
		return
	_open = false
	_confirming = ""
	_plate.visible = false
	MenuKit.take_mouse(Game.local_player, false)


func _on_attribute(key: String, _value: Variant) -> void :
	if _open and (key == "Cash" or key == "Saved" or key.begins_with("Train_")):
		_draw.call_deferred()


func _draw() -> void :
	for child in _rows.get_children():
		child.queue_free()
	_choices.clear()
	var player: = Game.local_player
	var cash: = int(player.get_attr("Cash", 0))
	_title.text = Text.say(Text.m("training.title")).to_upper()
	_cash.text = Ui.money(cash)
	var index: = 0
	var skills: Array = Training.skills()
	for id: String in skills:
		index += 1
		var level: = Training.level(player, id)
		var price: = Training.price(player, id)
		var now: = Text.say(Training.effect(id, level))
		var after: = Text.say(Training.effect(id, level + 1)) if level < Training.MOST else ""
		var card: = {"name": Text.say(Text.m("training.skills.%s.name" % id)), "level": level, "now": now, "after": after, "state": "buy", "button": "", "line": ""}
		if price < 0:
			card["state"] = "top"
			card["line"] = Text.say(Text.f("training.top", [now]))
			card["button"] = Text.say(Text.m("training.max"))
		elif not Training.rank_allows(player, id):
			var sheet: String = Config.Gear.Ranks[Training.rank_needed(player, id)]["sheet"]
			card["state"] = "rank"
			card["line"] = "%s  →  %s" % [now, after]
			card["button"] = Text.say(Text.f("training.rankButton", [Text.named("ranks", sheet)]))
		elif _confirming == id:
			card["state"] = "confirm"
			card["line"] = ("%s  →  %s" % [now, after]) if level > 0 else after
			card["button"] = Text.say(Text.f("training.again", [Ui.money(price)]))
		else:
			card["state"] = "buy" if cash >= price else "poor"
			card["line"] = ("%s  →  %s" % [now, after]) if level > 0 else after
			card["button"] = Ui.money(price)
		var skill: = id
		_card(index, card, func() -> void : _choose(skill))
	var rows: = ceili(skills.size() / 2.0)
	var close_y: = rows * (CARD.y + GAP) + 6
	var closer: = MenuKit.row(Vector2(CARD.x, 48), Text.say(Text.m("training.close")), Text.say(Text.m("training.closeDetail")), Ui.DIM, close, str(index + 1), "", 20)
	closer.position = Vector2(CARD.x + GAP, close_y)
	_rows.add_child(closer)
	_choices.append(close)
	_plate.size = Vector2(WIDTH, HEADER + close_y + 48 + 16)
	_plate.position = ((get_viewport_rect().size - _plate.size) / 2.0).round()





func _card(index: int, card: Dictionary, choose: Callable) -> void :
	var state: String = card["state"]
	var enabled: = state in ["buy", "confirm"]
	var column: = (index - 1) % 2
	var row: = (index - 1) / 2
	var button: = Button.new()
	button.size = CARD
	button.custom_minimum_size = CARD
	button.focus_mode = Control.FOCUS_NONE
	button.position = Vector2(column * (CARD.x + GAP), row * (CARD.y + GAP))
	var face: = Color(Ui.INSET, 0.55)
	button.add_theme_stylebox_override("normal", _box_style(face))
	button.add_theme_stylebox_override("hover", _box_style(Color(Ui.INSET.lightened(0.12), 0.8)))
	button.add_theme_stylebox_override("pressed", _box_style(Color(Ui.INSET.lightened(0.2), 0.9)))
	button.add_theme_stylebox_override("disabled", _box_style(Color(Ui.INSET, 0.35)))
	button.disabled = not enabled
	button.pressed.connect(choose)
	_rows.add_child(button)
	var cap: = Ui.key(str(index))
	cap.position = Vector2(12, 14)
	button.add_child(cap)
	var name: = Ui.display(card["name"], 23, Ui.TEXT if state != "rank" else Ui.DIM)
	name.position = Vector2(54, 8)
	name.size = Vector2(CARD.x - 54 - 150, 30)
	name.clip_text = true
	button.add_child(name)

	for star in Training.MOST:
		var had: bool = star < int(card["level"])
		var glyph: = Ui.label("★", 24, Ui.YELLOW if had else Color(Ui.DIM, 0.45))
		glyph.position = Vector2(54 + star * 24, 38)
		button.add_child(glyph)
	var line: = Ui.caps(card["line"], 13)
	line.add_theme_color_override("font_color", Ui.GREEN if state == "top" else Ui.TEXT)
	line.position = Vector2(54, 76)
	line.size = Vector2(CARD.x - 54 - 150, 20)
	line.clip_text = true
	line.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	button.add_child(line)

	var price: = Label.new()
	price.text = card["button"]
	price.add_theme_font_override("font", Ui.display_font())
	price.add_theme_font_size_override("font_size", 18 if state in ["rank"] else 22)
	price.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	price.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	price.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	price.size = Vector2(134, 52)
	price.position = Vector2(CARD.x - 134 - 12, (CARD.y - 52) / 2.0)
	var tint: = Ui.YELLOW
	var ink: = Ui.DARK
	match state:
		"confirm":
			tint = Ui.AMBER
		"poor":
			tint = Color(Ui.INSET, 0.9)
			ink = Ui.DIM
		"rank":
			tint = Color(Ui.INSET, 0.9)
			ink = Ui.DIM
		"top":
			tint = Color(Ui.GREEN, 0.25)
			ink = Ui.GREEN
	price.add_theme_stylebox_override("normal", _box_style(tint))
	price.add_theme_color_override("font_color", ink)
	price.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(price)
	_choices.append(choose if enabled else Callable())


static func _box_style(color: Color) -> StyleBoxFlat:
	var style: = StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(6)
	style.content_margin_left = 10
	style.content_margin_right = 10
	return style



func _choose(id: String) -> void :
	var player: = Game.local_player
	if int(player.get_attr("Cash", 0)) < Training.price(player, id):
		Game.notify(Text.m("training.noCash"), "warning", player)
		_confirming = ""
	elif _confirming != id:
		_confirming = id
	else:
		_confirming = ""
		Net.request("training.buy", [id])
	_draw()


func _unhandled_input(event: InputEvent) -> void :
	if not _open:
		return
	if event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
		return
	var number: = MenuKit.number_key(event)
	if number > 0 and number <= _choices.size():
		var chosen: Callable = _choices[number - 1]
		if chosen.is_valid():
			chosen.call()
		get_viewport().set_input_as_handled()


func _process(_delta: float) -> void :
	if _open and (Game.local_player == null or Game.local_player.health <= 0.0 or (_board != null and Game.local_player.global_position.distance_to(_board.global_position) > REACH)):
		close()
