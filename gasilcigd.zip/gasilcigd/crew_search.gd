class_name CrewSearch
extends RefCounted











static func house() -> House:
	var people: = VictimService.current
	if people != null and people._house is House:
		return people._house
	var fire: = FireService.current
	if fire != null and not fire.incident.is_empty() and fire.incident["group"]["building"] is House:
		return fire.incident["group"]["building"]
	return null




static func open(service: CrewService) -> bool:
	var people: = VictimService.current
	var building: = house()
	if people == null or building == null or people.searched_all:
		return false
	if not people.report in ["maybe", "child", "count", "sure"] and not service.done_here.has("heard"):
		return false

	if people.report == "count" or people.report == "sure":
		var missing: = false
		for victim: Victim in people.victims:
			missing = missing or (victim.waiting() and not victim.found)
		if not missing:
			return false
	return next_room(service, null, building, []) != ""



static func rooms(building: House) -> Array:
	var found: Array = []
	for room_name: String in building.rooms:
		if not building.rooms[room_name].get("open", false):
			found.append(room_name)
	return found


static func searched(service: CrewService, building: House, room_name: String) -> bool:
	return building.rooms[room_name].get("searched", false) or (service.done_here.get("visited", {}) as Dictionary).has(room_name)



static func middle(building: House, room_name: String) -> Vector3:
	var room: Dictionary = building.rooms[room_name]
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	return building.lot * Vector3((low.x + high.x) / 2.0, low.y + 2.0, (low.z + high.z) / 2.0)




static func next_room(service: CrewService, mind: Crewman, building: House, skipped: Array) -> String:
	var heard: Dictionary = service.done_here.get("heard", {})
	var claims: Dictionary = service.done_here.get("claims", {})
	var from: Vector3 = mind.body.global_position if mind != null else building.position
	var hot: = hot_rooms(building)
	var best: = ""
	var best_score: = INF
	for room_name: String in rooms(building):

		if room_name in skipped or hot.has(room_name):
			continue
		var claimed: Variant = claims.get(room_name)
		if claimed != null and claimed != mind and is_instance_valid(claimed) and claimed.job is JobSearch:
			continue
		var score: = from.distance_to(middle(building, room_name)) + float(building.rooms[room_name].get("floor", 0)) * float(Config.Crew.Search.FloorCost)
		if heard.has(room_name) and not _found_in(room_name):
			score -= 1000.0
		elif searched(service, building, room_name):
			continue
		if score < best_score:
			best_score = score
			best = room_name
	return best



static func hot_rooms(building: House) -> Dictionary:
	var hot: Dictionary = {}
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty() or fire.incident["group"]["building"] != building:
		return hot
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"] and node["room"] != null:
			hot[node["room"]] = true
	var heat: = float(Config.Fire.FlashoverHeat) * float(Config.Crew.Search.Hot)
	for room_name: Variant in fire.incident["rooms"]:
		if float((fire.incident["rooms"][room_name] as Dictionary).get("warmth", 0.0)) >= heat:
			hot[room_name] = true
	return hot


static func _found_in(room_name: String) -> bool:
	var people: = VictimService.current
	if people == null:
		return true
	for victim: Victim in people.victims:
		if victim.room == room_name and victim.waiting() and not victim.found:
			return false
	return true


static func claim(service: CrewService, mind: Crewman, room_name: String) -> void :
	if not service.done_here.has("claims"):
		service.done_here["claims"] = {}
	service.done_here["claims"][room_name] = mind


static func visited(service: CrewService, room_name: String) -> void :
	if not service.done_here.has("visited"):
		service.done_here["visited"] = {}
	service.done_here["visited"][room_name] = true

	(service.done_here.get("heard", {}) as Dictionary).erase(room_name)





static var _cues: = -1
static var _next_cue: Dictionary = {}





static func listen(service: CrewService) -> void :
	var people: = VictimService.current
	if people == null or Game.incident.is_empty():
		_cues = -1
		return
	var changed: = people.cues != _cues and _cues >= 0
	_cues = people.cues
	var building: = house()
	for victim: Victim in people.victims:
		var before: float = _next_cue.get(victim.id, victim.next_cue)
		_next_cue[victim.id] = victim.next_cue
		if not changed or victim.found or before == victim.next_cue or building == null or not building.rooms.has(victim.room):
			continue
		var at: = victim.position()
		var hearer: Crewman = null
		var nearest: = float(Config.Victims.Search.CueRange)
		for mind in service.members:
			var distance: = mind.body.global_position.distance_to(at)
			if mind.body.health > 0.0 and distance < nearest:
				nearest = distance
				hearer = mind
		var lead: = Game.local_player
		var lead_heard: = lead != null and lead.global_position.distance_to(at) < float(Config.Victims.Search.CueRange)
		if hearer == null and not lead_heard:
			continue
		if not service.done_here.has("heard"):
			service.done_here["heard"] = {}
		if not service.done_here.has("heard_said"):
			service.done_here["heard_said"] = {}
		var fresh: bool = not (service.done_here["heard_said"] as Dictionary).has(victim.room)
		service.done_here["heard_said"][victim.room] = true
		service.done_here["heard"][victim.room] = Game.now()
		if fresh and hearer != null:
			hearer.report("crew.say.report.heard", [room_words(victim.room, true)], "warning")



static func room_words(room_name: String, inside: = false) -> Variant:
	var key: = "calls.rooms.%s.%s" % [room_name, "inside" if inside else "name"]
	return Text.m(key) if Text.has(key) else room_name






static func house_of(door: Dictionary) -> House:
	var places: Array = []
	if FireService.current != null:
		places.append_array(FireService.current.buildings)
	if LockedIn.current != null and LockedIn.current.house != null:
		places.append(LockedIn.current.house)
	for building: Variant in places:
		if building is House:
			for each: Dictionary in (building as House).doors.values():
				if is_same(each, door):
					return building
	return null




static func force_way(mind: Crewman, door: Dictionary, held: int) -> bool:
	var building: = house_of(door)
	if building == null:
		return false
	mind.report("crew.say.lockedHere", [], "warning")
	if mind.body.get_attr("Line") == null and mind.body.get_attr("Supply") == null:
		var job: = JobForceDoor.new(building, door)
		job.who = mind
		var done: bool = await job.run()
		job.finish(done)
		return done and mind.alive(held)
	var helper: Crewman = null
	var force: = JobForceDoor.new(building, door)
	for other in mind.service.members:
		if other.job is JobForceDoor and is_same((other.job as JobForceDoor).door, door):
			helper = other
	if helper == null:
		helper = mind.service.choose(force, [mind])
		if helper == null:
			return false
		force.ordered = false
		helper.give(force)
	var until: = Game.now() + float(Config.Crew.Search.DoorWait)
	while door["locked"] and Game.now() < until:
		if not await mind.wait(0.5, held):
			return false
	return not door["locked"]
