class_name HudPeople
extends Control






const ACTION: = "mayday"

static var current: HudPeople

var _own: Label
var _others: Label
var _held: = 0.0
var _down_since: = -1.0


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not InputMap.has_action(ACTION):
		InputMap.add_action(ACTION)
		var event: = InputEventKey.new()
		event.physical_keycode = OS.find_keycode_from_string(String(Config.Down.MaydayKey))
		InputMap.action_add_event(ACTION, event)
	_own = Ui.display("", 30, Color(1.0, 0.45, 0.38))
	_own.add_theme_constant_override("outline_size", 8)
	_own.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.75))
	_own.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_own.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_own)
	_others = Ui.display("", 20, Color(1.0, 0.5, 0.42))
	_others.add_theme_constant_override("outline_size", 6)
	_others.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_others.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_others.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_others)


func _exit_tree() -> void :
	if current == self:
		current = null



func own_text() -> String:
	return _own.text if _own.visible else ""


func others_text() -> String:
	return _others.text if _others.visible else ""


func _process(delta: float) -> void :
	var me: = Game.local_player
	var view: = get_viewport_rect().size
	_own.visible = false
	_others.visible = false
	if me == null or not is_instance_valid(me):
		return
	_mayday_key(me, delta)


	var lines: Array[String] = []
	var cause: Variant = me.get_attr("Down")
	if cause != null:
		if _down_since < 0.0:
			_down_since = Game.now()
		lines.append(Text.say(Text.f("calls.down.youDown", [Text.m("calls.down.causes.%s" % str(cause))])).to_upper())
		var by: = DownService.rescuer_of(me)
		if by != null:
			lines.append(Text.say(Text.f("calls.down.beingDragged", [by.display_name])))
		else:
			var left: = maxf(0.0, float(Config.Down.Time) - (Game.now() - _down_since))
			lines.append(Text.say(Text.f("calls.down.waiting", [ceili(left), Controls.key_name(ACTION)])))
	else:
		_down_since = -1.0
		if me.get_attr("Knocked") != null:
			lines.append(Text.say(Text.m("calls.down.knockedFlat")).to_upper())
		elif me.get_attr("Mayday") != null:
			lines.append(Text.say(Text.m("calls.down.maydayOn")).to_upper())
	if _held > 0.0:
		lines.append(Text.say(Text.m("calls.down.maydayHolding")) + " " + "▮".repeat(int(clampf(_held / float(Config.Down.MaydayHold), 0.0, 1.0) * 8.0)))
	if not lines.is_empty():
		_own.text = "\n".join(lines)
		_own.visible = true
		_own.size = Vector2(view.x, 0)
		_own.position = Vector2(0, view.y * 0.71)


	var others: Array[String] = []
	for player in Game.players:
		if player == me or not is_instance_valid(player):
			continue
		var down: bool = player.get_attr("Down") != null
		if not down and player.get_attr("Mayday") == null:
			continue
		var far: = Ui.metres(player.global_position.distance_to(me.global_position))
		others.append(Text.say(Text.f("calls.down.otherDown" if down else "calls.down.otherMayday", [player.display_name, far[0] + " " + far[1]])).to_upper())
	if not others.is_empty():
		_others.text = "\n".join(others)
		_others.visible = fmod(Game.now(), 1.0) < 0.75 or others.size() > 0
		_others.modulate.a = 1.0 if fmod(Game.now(), 1.0) < 0.7 else 0.55
		_others.size = Vector2(view.x, 0)
		_others.position = Vector2(0, view.y * 0.16)



func _mayday_key(me: Player, delta: float) -> void :
	if Game.ui_open or not Input.is_action_pressed(ACTION):
		_held = 0.0
		return
	if _held < 0.0:
		return
	_held += delta
	if _held >= float(Config.Down.MaydayHold):
		_held = -1.0
		Net.request("down.mayday", [me.get_attr("Mayday") == null])
