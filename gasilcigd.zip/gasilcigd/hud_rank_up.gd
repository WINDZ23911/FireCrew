class_name HudRankUp
extends Control




static var current: HudRankUp

var _plate: Control
var _back: Panel
var _shield: TextureRect
var _helmet: TextureRect
var _title: Label
var _line: Label
var _waiting: Variant = null
var _until: = -1.0
var _began: = 0.0

var last_shown: = ""


func _init() -> void :
	current = self


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Control.new()
	_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.visible = false
	add_child(_plate)
	_back = Panel.new()
	var box: = StyleBoxFlat.new()
	box.bg_color = Color(Ui.PANEL, 0.7)
	box.set_corner_radius_all(14)
	_back.add_theme_stylebox_override("panel", box)
	_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_back)
	_shield = Ui.icon("shield", 150, Ui.YELLOW)
	_plate.add_child(_shield)
	_helmet = Ui.icon("helmet", 80, Ui.DARK)
	_plate.add_child(_helmet)
	_title = Ui.display("", 60, Ui.YELLOW)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.add_theme_constant_override("outline_size", 10)
	_title.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_plate.add_child(_title)
	_line = Ui.label("", 24)
	_line.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_line.add_theme_constant_override("outline_size", 6)
	_line.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_plate.add_child(_line)


func _exit_tree() -> void :
	if current == self:
		current = null



func promote(rank: Dictionary) -> void :
	_waiting = rank



func showing() -> bool:
	return _plate.visible


func _process(_delta: float) -> void :
	if _waiting != null and not HudFireOut.holding():
		var rank: Dictionary = _waiting
		_waiting = null
		var color: Color = Ui.RANK_COLORS.get(rank["sheet"], Ui.YELLOW)
		_shield.modulate = color
		_title.text = Text.say(Text.m("onboarding.rankUp.title"))
		_title.add_theme_color_override("font_color", color.lightened(0.15))
		_line.text = Text.say(Text.f("onboarding.rankUp.line", [Text.named("ranks", rank["sheet"])]))
		last_shown = String(rank["sheet"])
		_began = Game.now()
		_until = _began + float(Config.Onboarding.RankUp["Time"])
		Sounds.ui("ui_fanfare")
	var now: = Game.now()
	_plate.visible = now < _until
	if not _plate.visible:
		return
	var view: = get_parent_area_size()
	var top: = view.y * 0.22
	_shield.position = Vector2(view.x / 2.0 - 75.0, top)
	_helmet.position = Vector2(view.x / 2.0 - 40.0, top + 30.0)
	_title.position = Vector2(0, top + 150.0)
	_title.size = Vector2(view.x, 84)
	_line.position = Vector2(0, top + 238.0)
	_line.size = Vector2(view.x, 34)
	var wide: = maxf(_title.get_theme_font("font").get_string_size(_title.text, HORIZONTAL_ALIGNMENT_LEFT, -1, _title.get_theme_font_size("font_size")).x, _line.get_theme_font("font").get_string_size(_line.text, HORIZONTAL_ALIGNMENT_LEFT, -1, _line.get_theme_font_size("font_size")).x) + 80.0
	_back.position = Vector2((view.x - wide) / 2.0, top + 146.0)
	_back.size = Vector2(wide, 136.0)

	var age: = now - _began
	var left: = _until - now
	var grow: = 1.0 + 0.25 * maxf(0.0, 1.0 - age / 0.25) * sin(clampf(age / 0.25, 0.0, 1.0) * PI)
	_shield.pivot_offset = _shield.size / 2.0
	_shield.scale = Vector2(grow, grow)
	_plate.modulate.a = clampf(age / 0.2, 0.0, 1.0) * clampf(left / 0.4, 0.0, 1.0)
