class_name CrewList
extends Node






const BEAT_SECONDS: = 15.0
const PORT: = 8892

signal published(ok: bool)



var url: = ""
var _id: = ""
var _token: = ""
var _players: = 0
var _beats: = 0


func set_up(noray_server: String) -> void :
	var configured: Variant = Config.get("Net").get("CrewList") if Config.get("Net") is Dictionary else null
	if configured is String and not configured.is_empty():
		url = configured
	else:
		url = "http://%s:%d" % [noray_server.get_slice(":", 0), PORT]
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--crew-list="):
			url = arg.substr(12)
	url = url.trim_suffix("/")


func is_listed() -> bool:
	return not _id.is_empty()




func fetch(version: String) -> Dictionary:
	var answer: = await _call(HTTPClient.METHOD_GET, "/crews?version=" + version.uri_encode())
	if answer["status"] != 200 or not answer["body"] is Dictionary:
		return {"ok": false, "crews": []}
	var crews: Array = []
	for crew: Variant in answer["body"].get("crews", []):
		if crew is Dictionary and crew.get("code") is String and crew.get("name") is String:
			crews.append(crew)
	return {"ok": true, "crews": crews}



func publish(info: Dictionary) -> void :
	await withdraw()
	var answer: = await _call(HTTPClient.METHOD_POST, "/crews", info)
	var body: Variant = answer["body"]
	if answer["status"] != 200 or not body is Dictionary or not body.get("id") is String:
		push_warning("CrewList: could not put the crew on the list (%d): %s" % [answer["status"], body])
		published.emit(false)
		return
	_id = body["id"]
	_token = body.get("token", "")
	_players = int(info.get("players", 1))
	print("CrewList: on the list as %s" % _id)
	published.emit(true)
	_keep(info)



func set_players(count: int) -> void :
	if count == _players or _id.is_empty():
		return
	_players = count
	_call(HTTPClient.METHOD_POST, "/crews/%s/beat" % _id, {"token": _token, "players": _players})


func withdraw() -> void :
	_beats += 1
	if _id.is_empty():
		return
	var id: = _id
	var token: = _token
	_id = ""
	_token = ""
	await _call(HTTPClient.METHOD_DELETE, "/crews/" + id, {"token": token})




func _keep(info: Dictionary) -> void :
	_beats += 1
	var mine: = _beats
	while is_inside_tree():
		await get_tree().create_timer(BEAT_SECONDS).timeout
		if mine != _beats or _id.is_empty():
			return
		var answer: = await _call(HTTPClient.METHOD_POST, "/crews/%s/beat" % _id, {"token": _token, "players": _players})
		if mine != _beats:
			return
		if answer["status"] == 404:
			_id = ""
			info["players"] = _players
			publish(info)
			return



func _call(method: int, path: String, body: Variant = null) -> Dictionary:
	if url.is_empty():
		return {"status": 0, "body": null}
	var request: = HTTPRequest.new()
	request.timeout = 6.0
	add_child(request)
	var headers: = PackedStringArray(["Content-Type: application/json"])
	var sent: = request.request(url + path, headers, method, "" if body == null else JSON.stringify(body))
	if sent != OK:
		request.queue_free()
		return {"status": 0, "body": null}
	var result: Array = await request.request_completed
	request.queue_free()
	if result[0] != HTTPRequest.RESULT_SUCCESS:
		return {"status": 0, "body": null}
	return {"status": result[1], "body": JSON.parse_string((result[3] as PackedByteArray).get_string_from_utf8())}
