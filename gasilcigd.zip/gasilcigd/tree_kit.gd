class_name TreeKit
extends Node3D











const SPECIES: = ["birch", "lime", "walnut", "fruit", "poplar", "spruce"]
const CHUNK: = 480.0


const FIT: = {
	"birch": [0.85, 1.25, -1.0], "lime": [1.05, 1.15, 0.0], "walnut": [1.25, 0.95, -0.5], "fruit": [0.85, 0.85, 0.0], 
	"poplar": [0.55, 2.3, 0.0], "spruce": [1.0, 1.1, -1.0], 
}
const BRANCHES: = Color8(214, 210, 200)
const LEAF: = {
	"birch": Color8(127, 163, 90), "lime": Color8(94, 140, 74), "walnut": Color8(85, 127, 66), "fruit": Color8(108, 148, 80), 
	"poplar": Color8(79, 122, 68), "spruce": Color8(52, 88, 64), 
}

const TWIGS: = {
	"birch": Color(0.78, 0.76, 0.72), "lime": Color(0.25, 0.21, 0.19), "walnut": Color(0.38, 0.33, 0.29), 
	"fruit": Color(0.42, 0.36, 0.31), "poplar": Color(0.4, 0.36, 0.3), 
}

static var trees: Array = []
static var current: TreeKit

var _where: Dictionary = {}
var _summer: Array[MultiMeshInstance3D] = []
var _winter: Array[MultiMeshInstance3D] = []


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var groups: Dictionary = {}
	for tree: Dictionary in trees:
		var foot: Vector3 = tree["foot"]
		var key: = [tree["species"], floori(foot.x / CHUNK), floori(foot.z / CHUNK)]
		if not groups.has(key):
			groups[key] = []
		groups[key].append(tree)
	var meshes: = {}
	for species: String in SPECIES:
		meshes[species] = crown_mesh(species)
	for key: Array in groups:
		var species: String = key[0]
		var list: Array = groups[key]
		var multimesh: = MultiMesh.new()
		multimesh.transform_format = MultiMesh.TRANSFORM_3D
		multimesh.use_colors = true
		multimesh.mesh = meshes[species]
		multimesh.instance_count = list.size()
		for index in list.size():
			var tree: Dictionary = list[index]
			var place: = placement(tree)
			multimesh.set_instance_transform(index, place)
			multimesh.set_instance_color(index, colour(tree))
			_where[tree["model"]] = [multimesh, index, place]
		var drawn: = MultiMeshInstance3D.new()
		drawn.name = "%s_%d_%d" % key
		drawn.multimesh = multimesh
		drawn.material_override = material(species)
		drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		add_child(drawn)
		if species == "birch":

			_summer.append(drawn)
			var bare: = MultiMeshInstance3D.new()
			bare.name = "birch_branches_%d_%d" % [key[1], key[2]]
			var branches: = MultiMesh.new()
			branches.transform_format = MultiMesh.TRANSFORM_3D
			branches.use_colors = true
			branches.mesh = branches_mesh()
			branches.instance_count = list.size()
			for index in list.size():
				branches.set_instance_transform(index, multimesh.get_instance_transform(index))
				branches.set_instance_color(index, BRANCHES)
				(_where[list[index]["model"]] as Array).append(branches)
			bare.multimesh = branches
			bare.material_override = WorldMaterials.of("SmoothPlastic")
			add_child(bare)
			_winter.append(bare)
	Style.current.changed.connect( func(_style: int) -> void : _season())
	_season()


func _season() -> void :
	var winter: = Style.winter()
	for drawn in _summer:
		drawn.visible = not winter
	for drawn in _winter:
		drawn.visible = winter




static func placement(tree: Dictionary) -> Transform3D:
	var low: Vector3 = tree["low"]
	var high: Vector3 = tree["high"]
	var fit: Array = FIT[tree["species"]]
	var width: = maxf(high.x - low.x, high.z - low.z) * float(fit[0])
	var height: = (high.y - low.y) * float(fit[1])
	if tree["species"] == "poplar":
		height = maxf(height, 30.0)
	var foot: Vector3 = tree["foot"]
	var basis: = Basis(Vector3.UP, deg_to_rad(float(tree["turn"]))).scaled(Vector3(width, height, width))
	return Transform3D(basis, Vector3(foot.x, low.y + float(fit[2]), foot.z))




static func colour(tree: Dictionary) -> Color:
	var base: Color = LEAF[tree["species"]]
	var foot: Vector3 = tree["foot"]
	var shade: = 0.92 + 0.16 * float(int(rand_from_seed(hash([int(foot.x), int(foot.z), "leaf"]))[0]) % 100) / 100.0
	var mixed: = base.lerp(tree["tint"], 0.3)
	return Color(mixed.r * shade, mixed.g * shade, mixed.b * shade)


static func material(species: String) -> ShaderMaterial:
	var sway: = 0.4 if species == "spruce" else (1.6 if species == "poplar" else 1.1)
	return WorldMaterials.crown("tree:" + species, sway, 0.0 if species == "spruce" else 1.0, TWIGS.get(species, Color(0.48, 0.42, 0.37)))



func set_standing(model: int, standing: bool) -> void :
	if not _where.has(model):
		return
	var entry: Array = _where[model]
	var place: Transform3D = entry[2] if standing else Transform3D(Basis().scaled(Vector3.ONE * 0.0001), entry[2].origin)
	(entry[0] as MultiMesh).set_instance_transform(entry[1], place)
	if entry.size() > 3:
		(entry[3] as MultiMesh).set_instance_transform(entry[1], place)






static func crown_mesh(species: String) -> ArrayMesh:


	var made_outside: = "res://assets/models/crowns/%s.glb" % species
	if ResourceLoader.exists(made_outside):
		var scene: = load(made_outside) as PackedScene
		if scene != null:
			var node: = scene.instantiate()
			for mesh_node in node.find_children("*", "MeshInstance3D", true, false):
				var mesh: = (mesh_node as MeshInstance3D).mesh as ArrayMesh
				if mesh != null:
					node.free()
					return mesh
			node.free()
	var tool: = SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	match species:
		"spruce":
			for tier: Array in [[0.0, 0.42, 0.5], [0.22, 0.36, 0.42], [0.42, 0.3, 0.33], [0.6, 0.24, 0.24], [0.76, 0.24, 0.15]]:
				_cone(tool, float(tier[0]), float(tier[1]), float(tier[2]))
		_:
			var lobes: Array = LOBES[species]
			for index in lobes.size():
				var lobe: Array = lobes[index]
				_lobe(tool, Vector3(lobe[0], lobe[1], lobe[2]), Vector3(lobe[3], lobe[4], lobe[5]), index * 7 + species.length())
	tool.index()
	tool.generate_normals()
	var made: = tool.commit()
	return made



static func branches_mesh() -> ArrayMesh:
	var tool: = SurfaceTool.new()
	tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for index in 9:
		var turn: = TAU * index / 9.0 + 0.4 * sin(index * 2.3)
		var out: = Vector3(cos(turn), 0, sin(turn))
		var start: = Vector3(0, 0.05 + 0.08 * (index % 3), 0)
		var bend: = out * (0.22 + 0.06 * (index % 2)) + Vector3(0, 0.55 + 0.1 * (index % 3), 0)
		var tip: = out * 0.4 + Vector3(0, 0.75 + 0.15 * ((index + 1) % 3), 0)
		_rod(tool, start, bend, 0.022)
		_rod(tool, bend, tip, 0.012)
		_rod(tool, tip, tip + out * 0.08 - Vector3(0, 0.12, 0), 0.008)
	_rod(tool, Vector3.ZERO, Vector3(0, 1.0, 0), 0.03)
	tool.index()
	tool.generate_normals()
	return tool.commit()



static func _rod(tool: SurfaceTool, from: Vector3, to: Vector3, half: float) -> void :
	var along: = (to - from).normalized()
	var side: = along.cross(Vector3.FORWARD if absf(along.y) > 0.9 else Vector3.UP).normalized() * half
	var other: = along.cross(side).normalized() * half
	var ring: = [side + other, side - other, - side - other, - side + other]
	var middle: = (from + to) / 2.0
	for corner in 4:
		var a: Vector3 = from + ring[corner]
		var b: Vector3 = from + ring[(corner + 1) % 4]
		var c: Vector3 = to + ring[(corner + 1) % 4]
		var d: Vector3 = to + ring[corner]
		_face(tool, a, c, b, middle)
		_face(tool, a, d, c, middle)



const LOBES: = {
	"lime": [[0.0, 0.5, 0.0, 0.42, 0.42, 0.42], [0.2, 0.38, 0.1, 0.27, 0.25, 0.27], [-0.19, 0.4, -0.12, 0.28, 0.26, 0.28], 
		[0.04, 0.74, -0.04, 0.3, 0.26, 0.3], [-0.1, 0.3, 0.2, 0.26, 0.24, 0.26], [0.14, 0.33, -0.21, 0.26, 0.24, 0.26]], 
	"walnut": [[0.0, 0.45, 0.0, 0.4, 0.34, 0.4], [0.29, 0.42, 0.05, 0.22, 0.22, 0.22], [-0.29, 0.44, -0.05, 0.22, 0.23, 0.22], 
		[0.05, 0.45, 0.29, 0.21, 0.21, 0.21], [-0.05, 0.4, -0.29, 0.22, 0.22, 0.22], [0.0, 0.72, 0.0, 0.28, 0.26, 0.28]], 
	"fruit": [[0.0, 0.42, 0.0, 0.36, 0.36, 0.36], [0.24, 0.52, 0.14, 0.24, 0.24, 0.24], [-0.22, 0.5, -0.1, 0.25, 0.25, 0.25], 
		[0.02, 0.64, -0.2, 0.23, 0.22, 0.23]], 
	"poplar": [[0.0, 0.18, 0.0, 0.3, 0.2, 0.3], [0.0, 0.4, 0.0, 0.38, 0.24, 0.38], [0.0, 0.63, 0.0, 0.32, 0.22, 0.32], [0.0, 0.84, 0.0, 0.2, 0.16, 0.2]], 


	"birch": [[0.0, 0.3, 0.0, 0.2, 0.26, 0.2], [0.0, 0.56, 0.0, 0.26, 0.28, 0.26], [0.25, 0.4, 0.1, 0.2, 0.22, 0.2], [-0.25, 0.45, -0.12, 0.2, 0.22, 0.2], 
		[0.1, 0.78, -0.1, 0.19, 0.2, 0.19], [-0.12, 0.28, 0.25, 0.17, 0.2, 0.17], [0.2, 0.66, 0.25, 0.16, 0.18, 0.16], 
		[-0.25, 0.7, 0.15, 0.15, 0.18, 0.15]], 
}




static func _lobe(tool: SurfaceTool, middle: Vector3, radii: Vector3, seed_of: int) -> void :
	const RINGS: = 6
	const SEGMENTS: = 9
	var points: Array = []
	for ring in RINGS + 1:
		var row: Array = []
		var v: = float(ring) / RINGS
		var lat: = PI * (v - 0.5)
		for segment in SEGMENTS + 1:
			var u: = float(segment % SEGMENTS) / SEGMENTS
			var lon: = TAU * u
			var out: = Vector3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon))
			var bump: = 1.0
			if ring > 0 and ring < RINGS:
				bump = 0.86 + 0.28 * float(int(rand_from_seed(hash([seed_of, ring, segment % SEGMENTS]))[0]) % 100) / 100.0
			row.append(middle + out * radii * bump)
		points.append(row)
	for ring in RINGS:
		for segment in SEGMENTS:
			var a: Vector3 = points[ring][segment]
			var b: Vector3 = points[ring][segment + 1]
			var c: Vector3 = points[ring + 1][segment + 1]
			var d: Vector3 = points[ring + 1][segment]
			_face(tool, a, c, b, middle)
			_face(tool, a, d, c, middle)



static func _cone(tool: SurfaceTool, foot: float, height: float, radius: float) -> void :
	const SEGMENTS: = 12
	var top: = Vector3(0, foot + height, 0)
	var under: = Vector3(0, foot + height * 0.18, 0)
	for segment in SEGMENTS:
		var a_angle: = TAU * segment / SEGMENTS
		var b_angle: = TAU * (segment + 1) / SEGMENTS
		var a_out: = radius * (1.0 if segment % 2 == 0 else 0.8)
		var b_out: = radius * (1.0 if (segment + 1) % 2 == 0 else 0.8)
		var a: = Vector3(cos(a_angle) * a_out, foot, sin(a_angle) * a_out)
		var b: = Vector3(cos(b_angle) * b_out, foot, sin(b_angle) * b_out)
		_face(tool, a, top, b, Vector3(0, foot + height * 0.4, 0))
		_face(tool, a, b, under, Vector3(0, foot + height * 0.1, 0))




static func _face(tool: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, inside: Vector3) -> void :
	var normal: = (c - a).cross(b - a)
	if normal.length_squared() < 1e-12:
		return
	if normal.dot((a + b + c) / 3.0 - inside) < 0.0:
		var swap: = b
		b = c
		c = swap
	for point: Vector3 in [a, b, c]:
		var out: = clampf(Vector2(point.x, point.z).length() / 0.5, 0.0, 1.0)
		var shade: = lerpf(0.62, 1.0, clampf(point.y * 0.55 + out * 0.55, 0.0, 1.0))
		tool.set_color(Color(shade, shade, shade))
		tool.add_vertex(point)
