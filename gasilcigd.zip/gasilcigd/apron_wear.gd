class_name ApronWear
extends Node3D





static var bays: Array = []

const TRACK: = 3.9
const LANE: = Vector2(2.6, 62.0)
const OIL: = 7.0


func _ready() -> void :
	var lane: = _lane_texture()
	var oil: = _oil_texture()
	for door: Transform3D in bays:

		var out: = door.basis.z.normalized()
		if out.dot(Vector3(0, 0, 1)) < 0.0:
			out = - out
		var across: = Vector3( - out.z, 0, out.x)
		var foot: = Vector3(door.origin.x, 0.0, door.origin.z)
		for side: float in [-1.0, 1.0]:
			var middle: = foot + across * side * TRACK + out * (LANE.y / 2.0 + 1.0)
			_decal(Transform3D(Basis.looking_at(out, Vector3.UP), middle), Vector3(LANE.x, 3.0, LANE.y), lane, 0.55)
		var drip: = foot + out * 7.0 + across * 1.5
		_decal(Transform3D(Basis(Vector3.UP, float(int(drip.x * 7.0) % 6)), drip), Vector3(OIL, 3.0, OIL * 0.8), oil, 0.85)


func _decal(place: Transform3D, size: Vector3, texture: Texture2D, strength: float) -> void :
	var decal: = Decal.new()
	decal.size = size
	decal.texture_albedo = texture
	decal.modulate = Color(1, 1, 1, strength)
	decal.albedo_mix = 1.0
	decal.cull_mask = 1
	add_child(decal)
	decal.global_transform = place



static func _lane_texture() -> ImageTexture:
	var image: = Image.create(32, 256, false, Image.FORMAT_RGBA8)
	var noise: = FastNoiseLite.new()
	noise.seed = 31
	noise.frequency = 0.08
	for y in 256:
		for x in 32:
			var across: = absf(x - 15.5) / 16.0
			var edge: = 1.0 - smoothstep(0.45, 1.0, across)
			var streak: = 0.75 + 0.25 * noise.get_noise_2d(x * 3.0, y * 0.25)
			var reach: = 1.0 - smoothstep(0.5, 1.0, float(255 - y) / 255.0)
			image.set_pixel(x, y, Color(0.06, 0.06, 0.065, clampf(edge * streak * reach, 0.0, 1.0)))
	return ImageTexture.create_from_image(image)



static func _oil_texture() -> ImageTexture:
	var image: = Image.create(96, 96, false, Image.FORMAT_RGBA8)
	var noise: = FastNoiseLite.new()
	noise.seed = 77
	noise.frequency = 0.07
	for y in 96:
		for x in 96:
			var from: = Vector2(x - 47.5, y - 47.5) / 48.0
			var ragged: = from.length() + 0.25 * noise.get_noise_2d(x, y)
			var blot: = 1.0 - smoothstep(0.35, 0.75, ragged)
			image.set_pixel(x, y, Color(0.04, 0.035, 0.03, blot * (0.6 + 0.4 * (1.0 - smoothstep(0.0, 0.5, ragged)))))
	return ImageTexture.create_from_image(image)
