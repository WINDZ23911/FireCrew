class_name HoseService
extends Node




























const ATTACK_COLOR: = Color(232 / 255.0, 226 / 255.0, 200 / 255.0)
const REEL_COLOR: = Color(40 / 255.0, 40 / 255.0, 44 / 255.0)
const SUPPLY_COLOR: = Color(225 / 255.0, 190 / 255.0, 70 / 255.0)
const SUPPLY_WIDTH: = 0.6
const SUCTION_WIDTH: = 1.0

const HAND_DROP: = 2.1
const NOZZLE_DROP: = 3.0
const HYDRANT_DROP: = 1.7
const DIVIDER_DROP: = 0.5
const DIVIDER_TOOL: = "Divider"
const DIVIDER_LOCKER: = "R3"
const RED: = Color(190 / 255.0, 30 / 255.0, 30 / 255.0)
const BRASS: = Color(190 / 255.0, 160 / 255.0, 80 / 255.0)
const AGAIN: = 1.0
const OVER_LENGTH_TIME: = 0.6
const AIM_FAR: = 500.0

static var current: HoseService




var rigs: Array = []




var lines: Array = []

var divider: = {"state": "stowed", "vehicle": null, "line": null, "player": null, "tool": null, "entry": null, "model": null, "body": null, "inlet": null, "pickup": null, "lines": [], "feed": null}
var hydrants: Array = []
var monitors: Array = []
var _clock: = 0.0
var _last_use: Dictionary = {}
var _refusals: Dictionary = {}
var _watched: Dictionary = {}

var _net_hoses: Dictionary = {}
var _net_last: Variant = null
var _net_monitor_jets: Dictionary = {}
var _rolls_shown: Dictionary = {}
const ROLL_KINDS: = ["attack", "supply"]

var broken_hydrants: Array = []
var _hydrant_kinds: Dictionary = {}
var _tank_said: Dictionary = {}
var _damage: Dictionary = {"for": null, "litres": 0.0, "applied": 0.0, "told": 0.0}


var _loose: Dictionary = {}
var _opened_shown: Dictionary = {}


func _init() -> void :
	current = self


func _ready() -> void :

	process_physics_priority = 10
	Net.handle("hose.sound", func(sound: String, at: Vector3, volume: float) -> void : Sounds.once_at(at, sound, volume, 8.0, 80.0))
	Net.handle("hose.crack", func(id: int) -> void :
		var pane: Variant = House._panes.get(id)
		if pane is Dictionary:
			pane["crack"].call()
	)

	Net.share("hose.state", _net_state, _net_apply, 5.0)
	Net.share("hose.monitors", _net_monitors, _net_apply_monitors, 10.0)
	Net.handle("hose.divider.place", func(player: Player) -> void :
		if divider["state"] == "carried" and divider["player"] == player and is_instance_valid(divider["tool"]) and divider["tool"].visible:
			_place_divider(player)
	)
	Net.handle("hose.divider.hand", func(player: Player, on: bool) -> void :
		if divider["state"] == "carried" and divider["player"] == player:
			_show_divider(on)
			if ToolService.current:
				ToolService.current.carried_changed.emit(player)
	)
	Net.started.connect(_on_net_started)
	Net.stopped.connect(_net_clear)
	Net.peer_joined.connect( func(_player: Player) -> void :
		if Net.is_client() and _net_last != null:
			_net_apply(_net_last)
	)
	Net.peer_left.connect(_on_peer_left)




func kind_of(kind: String) -> Dictionary:
	var hose: Dictionary = Config.Hose
	match kind:
		"reel":
			return {"length": float(hose["Reel"]["Length"]), "use": float(hose["Reel"]["WaterUse"]), "power": float(hose["Reel"]["Power"]), "width": 0.28, "color": REEL_COLOR, "words": "gear.hose.kinds.reel"}
		"divider":
			return {"length": float(hose["Divider"]["Length"]), "use": float(hose["WaterUse"]), "power": 1.0, "width": 0.4, "color": ATTACK_COLOR, "words": "gear.hose.kinds.divider"}
	return {"length": float(hose["AttackLength"]), "use": float(hose["WaterUse"]), "power": 1.0, "width": 0.4, "color": ATTACK_COLOR, "words": "gear.hose.kinds.outlet"}


func start() -> void :
	for vehicle in Vehicle.all:
		if not vehicle.spec.get("hoses", false):
			continue
		var rig: = {"vehicle": vehicle, "supply": {"state": "stowed", "player": null, "hose": null, "hydrant": null, "donor": null, "limit": null}}
		rigs.append(rig)
		for outlet: Dictionary in vehicle.outlets:
			var prompt: = Prompt.make(outlet["node"], Text.m("gear.hose.kinds.outlet.take"), Text.f("gear.hose.outlet", [outlet["index"]]), 0.3, 9.0)
			prompt.key = "coupling"
			var line: = {"kind": "outlet", "rig": rig, "source": outlet["node"], "prompt": prompt, "player": null, "hose": null, "jet": null, "over_for": 0.0, "spraying": false, "feeding": false, "relay": null}
			prompt.triggered.connect( func(player: Player) -> void : _on_outlet(line, player))
			lines.append(line)
		if not vehicle.intake.is_empty():
			var prompt: = Prompt.make(vehicle.intake["node"], Text.m("gear.hose.supplyTake"), Text.m("gear.hose.intake"), 0.3, 9.0)
			prompt.key = "coupling"
			rig["supply"]["prompt"] = prompt
			prompt.triggered.connect( func(player: Player) -> void : _on_intake(rig, player))
		_stock_rolls(rig)
		if vehicle.spec.get("pumper", false):
			if vehicle.data.has("reel"):
				_create_reel(rig)
			_stock_divider(vehicle)

	if GearService.current:
		GearService.current.on_removed( func(player: Player) -> void : _return_roll(player))
	var marks: Array = []
	for entry: Dictionary in Game.records.get("hydrants", []):
		var row: int = Game.store.row_of.get(int(entry["part"]), -1)
		if row < 0:
			continue
		var node: = Node3D.new()
		add_child(node)

		node.global_transform = Game.store.transform(row) * Transform3D(Basis.IDENTITY, Vector3(0, 1.0, -1.4))
		var at: = Game.store.position(row)
		var kind: = hydrant_kind_for(at)
		_hydrant_kinds[Vector2i(roundi(at.x), roundi(at.z))] = kind["Name"]
		marks.append([row, int(kind["Rings"])])
		var hydrant: = {"position": at, "node": node, "rig": null, "flow": float(kind["Flow"]), "kind": kind["Name"]}

		if float(kind["Flow"]) <= 0.0:

			var dead: = Prompt.make(node, Text.m("water.hydrant.broken"), Text.m("gear.hose.hydrant"), 0.3, 10.0)
			dead.key = "coupling"
			dead.condition = func(player: Player) -> bool: return supply_of(player) != null
			dead.triggered.connect( func(player: Player) -> void :
				if _meant(dead, player):
					_refuse(Text.m("water.hydrant.brokenSaid"), player)
			)
			hydrant["prompt"] = dead
			broken_hydrants.append(hydrant)
			continue
		var prompt: = Prompt.make(node, Text.m("gear.hose.supplyConnect"), Text.f("water.hydrant.object", [int(kind["Flow"])]), 0.3, 10.0)
		prompt.key = "coupling"
		prompt.condition = func(player: Player) -> bool: return supply_of(player) != null or hydrant["rig"] != null or player.get_attr("HoseRoll") == "supply" or _loose.has(player)
		prompt.triggered.connect( func(player: Player) -> void : _on_hydrant(hydrant, player))
		hydrant["prompt"] = prompt
		hydrants.append(hydrant)
	HydrantCollars.mark(self, marks)





static func hydrant_kind_for(at: Vector3) -> Dictionary:
	var settings: Dictionary = Config.Water.Hydrants
	var kinds: Array = settings["Kinds"]
	if Game.station != null and Game.station.door_position.distance_to(at) < float(settings["StationSure"]):
		return kinds[0]
	var roll: = float(rand_from_seed(hash([roundi(at.x), roundi(at.z), "hydrant"]))[0] %100000) / 100000.0
	for kind: Dictionary in kinds:
		roll -= float(kind["Chance"])
		if roll <= 0.0:
			return kind
	return kinds[kinds.size() - 1]



func hydrant_kind_at(at: Vector3) -> String:
	return _hydrant_kinds.get(Vector2i(roundi(at.x), roundi(at.z)), "")




static func hydrant_rings(kind_name: String) -> int:
	for kind: Dictionary in Config.Water.Hydrants.Kinds:
		if kind["Name"] == kind_name:
			return int(kind["Rings"])
	return 1




func _create_reel(rig: Dictionary) -> void :
	var vehicle: Vehicle = rig["vehicle"]
	var at: Vector3 = vehicle.v(vehicle.data["reel"])


	var red: = Color(190 / 255.0, 30 / 255.0, 30 / 255.0)
	var steel: = Color(150 / 255.0, 154 / 255.0, 160 / 255.0)
	var wall: float = vehicle.data["rear"]
	vehicle.add_part("ReelHose", Vector3(0.74, 1.3, 1.3), Transform3D(Basis.IDENTITY, at), REEL_COLOR, PartStore.Shape.CYLINDER, "Fabric")
	for side: float in [-1.0, 1.0]:
		vehicle.add_part("ReelFlange", Vector3(0.07, 1.62, 1.62), Transform3D(Basis.IDENTITY, at + Vector3(side * 0.41, 0, 0)), red, PartStore.Shape.CYLINDER, "Metal")
		var arm_length: = at.z - wall + 0.1
		vehicle.add_part("ReelArm", Vector3(0.1, 0.22, arm_length), Transform3D(Basis.IDENTITY, Vector3(at.x + side * 0.5, at.y, wall + arm_length / 2.0 - 0.1)), steel, PartStore.Shape.BLOCK, "Metal")
	vehicle.add_part("ReelHub", Vector3(1.12, 0.3, 0.3), Transform3D(Basis.IDENTITY, at), steel, PartStore.Shape.CYLINDER, "Metal")
	var outer: = signf(at.x)
	vehicle.add_part("ReelCrank", Vector3(0.06, 0.5, 0.08), Transform3D(Basis.IDENTITY, at + Vector3(outer * 0.6, 0.22, 0)), steel, PartStore.Shape.BLOCK, "Metal")
	vehicle.add_part("ReelGrip", Vector3(0.22, 0.09, 0.09), Transform3D(Basis.IDENTITY, at + Vector3(outer * 0.7, 0.45, 0)), Color(0.1, 0.1, 0.11), PartStore.Shape.CYLINDER, "Plastic")
	var node: = Node3D.new()
	vehicle.body.add_child(node)
	node.position = at + Vector3(0, 0, 0.5)
	var prompt: = Prompt.make(node, Text.m("gear.hose.kinds.reel.take"), Text.m("gear.hose.reel"), 0.3, 8.0)
	prompt.key = "coupling"
	var line: = {"kind": "reel", "rig": rig, "source": node, "prompt": prompt, "player": null, "hose": null, "jet": null, "over_for": 0.0, "spraying": false, "feeding": false, "relay": null}
	prompt.triggered.connect( func(player: Player) -> void : _on_outlet(line, player))
	lines.append(line)




func _meant(prompt: Prompt, player: Player) -> bool:
	var key: = [prompt, player]
	if Game.now() - _last_use.get(key, -100.0) < AGAIN:
		return false
	_last_use[key] = Game.now()
	return true



func _geared(player: Player) -> bool:
	if player.get_attr("Geared", false):
		return true
	_refuse(Text.m("gear.suitFirst"), player)
	return false




func _refuse(message: Variant, player: Player) -> void :
	_refusals[player] = [message, Game.now()]
	Game.notify(message, "", player)



func refusal_for(player: Player) -> Variant:
	var told: Variant = _refusals.get(player)
	if told is Array and Game.now() - float(told[1]) < 3.0:
		return told[0]
	return null


func line_of(player: Player) -> Variant:
	for line: Dictionary in lines:
		if line["player"] == player:
			return line
	return null



func supply_of(player: Player) -> Variant:
	for rig: Dictionary in rigs:
		if rig["supply"]["state"] == "carried" and rig["supply"]["player"] == player:
			return rig
	return null



func rig_of(line: Dictionary) -> Variant:
	if line["rig"] != null:
		return line["rig"]
	return divider["feed"]["rig"] if divider["feed"] != null else null





func supplied_by(vehicle: Vehicle) -> Variant:
	for rig: Dictionary in rigs:
		if rig["vehicle"] == vehicle and rig["supply"]["state"] == "connected":
			var donor: Variant = rig["supply"]["donor"]
			if donor != null:
				return donor["rig"]["vehicle"]
			var source: Variant = rig["supply"]["hydrant"]
			if source is Dictionary and (source.has("pump") or source.has("elsewhere")):
				return "cellar"
			return "hydrant"
	return null



func feeding(vehicle: Vehicle) -> Vehicle:
	for line: Dictionary in lines:
		if line["rig"] != null and line["rig"]["vehicle"] == vehicle and line.get("relay") != null:
			return line["relay"]["vehicle"]
	return null





func tethered(vehicle: Vehicle) -> bool:
	for line: Dictionary in lines:
		if line["rig"] == null or line["rig"]["vehicle"] != vehicle:
			continue
		if line["player"] != null or line.get("down") != null or line.get("relay") != null or line.get("feeding", false):
			return true
	for rig: Dictionary in rigs:
		if rig["vehicle"] == vehicle and rig["supply"]["state"] != "stowed":
			return true
	return false





func _watch(player: Player) -> void :
	if _watched.has(player):
		return
	_watched[player] = true
	player.died.connect( func() -> void :
		var line: Variant = line_of(player)
		if line != null:
			disconnect_line(line)
			_refresh_divider()
		var carrying: Variant = supply_of(player)
		if carrying != null:
			stow_supply(carrying)
		if divider["state"] == "carried" and divider["player"] == player:
			_stow_divider()
		_return_roll(player)
	)





func _on_outlet(line: Dictionary, player: Player) -> void :
	if not _meant(line["prompt"], player):
		return

	var divert: Variant = line.get("divert")
	if divert is Callable and divert.is_valid():
		divert.call(player)
		return
	var carrying: Variant = supply_of(player)
	if line.get("feeding", false):
		_unfeed(line)
	elif line.get("relay") != null:
		stow_supply(line["relay"])
	elif line["player"] == player:
		disconnect_line(line)
		_refresh_divider()
	elif line["player"] != null:
		_refusals[player] = [Text.m("gear.hose.lineInUse"), Game.now()]
		return
	elif line.get("down") != null:

		disconnect_line(line)
		_refresh_divider()
	elif line_of(player) != null:
		_refuse(Text.m("gear.hose.alreadyHolding"), player)
	elif carrying != null and line["kind"] != "outlet":
		Game.notify(Text.m("gear.hose.supplyWhere"), "", player)
	elif carrying != null and is_same(carrying, line["rig"]):
		Game.notify(Text.m("gear.hose.supplySelf"), "", player)
	elif carrying != null and _feeds_back(line["rig"], carrying):
		Game.notify(Text.m("gear.hose.feedLoop"), "", player)
	elif carrying != null:

		if _geared(player):
			_connect_relay(carrying, line, player)
	elif _geared(player) and _uses_roll(line, player, "attack"):
		_connect_line(line, player)
		_refresh_divider()








func _uses_roll(line: Dictionary, player: Player, kind: String) -> bool:
	if rig_of(line) == null:
		return false
	if line.get("kind", "") == "reel" or player.brain != null:
		return true
	if player.get_attr("HoseRoll") == null and line.get("kind", "") == "outlet" and line["rig"] != null:
		var rig: Dictionary = line["rig"]
		if int(rig.get("rolls", {}).get(kind, 0)) <= 0:
			_refuse(Text.m("water.rolls.noneHere"), player)
			return false
		if ToolService.current:
			ToolService.current.clear_hands(player)
		_add_rolls(rig, kind, -1)
		line["roll"] = rig
		return true
	if player.get_attr("HoseRoll") != kind:
		_refuse(Text.m("water.rolls.%sFirst" % kind), player)
		return false
	var from: Variant = _roll_rig(player)
	_clear_roll(player)
	line["roll"] = from
	return true


func _connect_line(line: Dictionary, player: Player) -> void :
	var kind: = kind_of(line["kind"])
	var rig: Variant = rig_of(line)
	if rig == null:
		return
	var vehicle: Vehicle = rig["vehicle"]
	_watch(player)
	var passes: Array[RID] = [vehicle.get_rid(), player.get_rid()]
	if is_instance_valid(divider["body"]):
		passes.append(divider["body"].get_rid())
	var hose: = HoseLine.make(line["source"], kind["width"], kind["color"], passes)

	hose.swell = 0.0
	line["charged"] = false
	line.erase("charge_at")
	_take_hold(line, player, hose)
	Game.notify(Text.m("gear.hose.nozzleTip"), "", player)
	_sound(line["source"].global_position, "storz_couple", 0.8)



func _sound(at: Vector3, sound: String, volume: = 0.8) -> void :
	Sounds.once_at(at, sound, volume, 8.0, 80.0)
	if Net.is_host():
		Net.broadcast("hose.sound", [sound, at, volume])



func _take_hold(line: Dictionary, player: Player, hose: HoseLine) -> void :
	var kind: = kind_of(line["kind"])
	var rig: Variant = rig_of(line)
	_watch(player)
	_hand_nozzle(line, player)
	hose.set_end(line["nozzle"].hose_in, NOZZLE_DROP)
	line["hose"] = hose
	line["over_for"] = 0.0


	if player.brain == null and ToolService.current:
		var entry: = {"name": "Nozzle", 
			"in_hand": func() -> bool: return line["player"] == player, 
			"set_in_hand": func(on: bool) -> void :
				if not on and line["player"] == player:
					_put_down(line, player)}
		line["entry"] = entry
		ToolService.current.carry_other(player, entry)
	line["prompt"].action = Text.m(kind["words"] + ".back")
	player.holding = "nozzle"
	player.set_attr("Line", line)
	player.set_attr("HoseTruck", rig["vehicle"] if rig != null else null)
	if player.get_attr("Flow") == null:
		player.set_attr("Flow", int(Config.Hose.StartFlow))
	if player.get_attr("Pattern") == null:
		player.set_attr("Pattern", "Jet")



func _hand_nozzle(line: Dictionary, player: Player) -> void :
	var nozzle: = Nozzle.new()
	player.rig.hand_right.add_child(nozzle)
	var jet: = WaterJet.new()
	jet.exclude = [player.get_rid()]
	add_child(jet)
	line["player"] = player
	line["nozzle"] = nozzle
	line["jet"] = jet
	line.erase("aim")


func disconnect_line(line: Dictionary, reason: Variant = null) -> void :
	var player: Player = line["player"]
	if player == null:
		if line.get("down") == null:
			return

		_clear_down(line)
		if is_instance_valid(line["hose"]):
			line["hose"].queue_free()
		line["hose"] = null
		_restock(line)
		line["prompt"].action = Text.m(kind_of(line["kind"])["words"] + ".take")
		_show_outlet(line)
		return
	var hose: HoseLine = _let_go(line)
	if is_instance_valid(hose):
		hose.queue_free()
	_restock(line)
	line["prompt"].action = Text.m(kind_of(line["kind"])["words"] + ".take")
	_show_outlet(line)
	if is_instance_valid(line["source"]) and line["source"].is_inside_tree():
		_sound(line["source"].global_position, "storz_uncouple", 0.7)
	if is_instance_valid(player) and reason != null:
		Game.notify(reason, "warning", player)



func _restock(line: Dictionary) -> void :
	var from: Variant = line.get("roll")
	line.erase("roll")
	if from is Dictionary:
		_add_rolls(from, "attack", 1)




func _let_go(line: Dictionary) -> HoseLine:
	var player: Player = line["player"]
	var hose: HoseLine = line["hose"]
	var entry: Variant = line.get("entry")
	line.erase("entry")
	if entry is Dictionary and ToolService.current and is_instance_valid(player):
		ToolService.current.drop_other(player, entry)
	_set_spraying(line, false, 0, -1.0)
	if is_instance_valid(line["nozzle"]):
		line["nozzle"].queue_free()
	line["jet"].spraying = false
	var jet: WaterJet = line["jet"]
	get_tree().create_timer(3.0).timeout.connect(jet.queue_free)
	line["player"] = null
	line["hose"] = null
	line["nozzle"] = null
	line["jet"] = null
	line["over_for"] = 0.0
	if is_instance_valid(player):
		player.holding = ""
		player.set_attr("Line", null)
		player.set_attr("HoseLength", null)
		player.set_attr("HoseMax", null)
		player.set_attr("HoseTruck", null)
		player.set_attr("Pressure", null)
		player.set_attr("PumpShare", null)
		player.set_attr("Charging", null)
		if player.is_local and player.camera != null:
			player.camera.sway = 0.0
	return hose




func _set_spraying(line: Dictionary, spraying: bool, hits: int, flame_progress: float, cooling: = false) -> void :
	line["spraying"] = spraying
	var player: Player = line["player"]
	if player == null or not is_instance_valid(player):
		return
	player.set_attr("Spraying", spraying)
	player.set_attr("HittingFire", spraying and hits > 0)
	player.set_attr("FlameProgress", flame_progress if flame_progress >= 0.0 else null)
	player.set_attr("Cooling", true if (spraying and cooling) else null)

	player.set_attr("FogShield", true if (spraying and player.get_attr("Pattern") == "Fog") else null)


func flow_of(player: Player) -> Dictionary:
	var flows: Array = Config.Hose.Flows
	var index: = clampi(int(player.get_attr("Flow", int(Config.Hose.StartFlow))), 1, flows.size())
	return flows[index - 1]



func aim_of(player: Player) -> Vector3:
	if not player.is_local or player.camera == null:
		return player.get_attr("Aim", player.root_position() + player.facing() * 30.0)
	var camera: = player.camera.camera
	var from: = camera.global_position
	var along: = - camera.global_basis.z

	var start_at: = from + along * (player.camera.distance + 1.0)
	var hit: = Game.world.raycast(start_at, from + along * AIM_FAR, World.LAYER_QUERY | World.LAYER_VEHICLE, [player.get_rid()])
	return hit["position"] if not hit.is_empty() else from + along * AIM_FAR


func nozzle_tip(player: Player) -> Vector3:
	var line: Variant = line_of(player)
	if line != null and is_instance_valid(line["nozzle"]):
		return line["nozzle"].tip.global_position
	return player.root_position() + player.facing() * 2.0


func _is_open(line: Dictionary) -> bool:
	var player: Player = line["player"]
	if player == null or player.seat != null or player.health <= 0.0:
		return false
	if player.is_local:
		return Input.is_action_pressed("fire") and player.camera.captured and not Game.ui_open
	return player.get_attr("Trigger", false)




func _spray(player: Player, line: Dictionary, dt: float, pressure: float) -> void :
	var glass_was: Variant = line.get("glass")
	line["glass_seen"] = false
	_spray_once(player, line, dt, pressure)
	if glass_was != null and not line["glass_seen"]:
		_glass_off(line, dt)




static func _glass_off(holder: Dictionary, dt: float) -> void :
	var held: Variant = holder.get("glass")
	if not (held is Array):
		return
	held[1] = float(held[1]) - dt * float(Config.Water.Glass.Decay)
	if float(held[1]) <= 0.0:
		holder.erase("glass")


func _spray_once(player: Player, line: Dictionary, dt: float, pressure: float) -> void :
	if not _is_open(line):
		_set_spraying(line, false, 0, -1.0)
		return
	var vehicle: Vehicle = rig_of(line)["vehicle"]
	if not _charged(line, player, vehicle):
		_set_spraying(line, false, 0, -1.0)
		return
	var kind: = kind_of(line["kind"])
	var flow: = flow_of(player)
	var origin: = nozzle_tip(player)
	var aim: = aim_of(player)
	var offset: = aim - origin
	var wanted: float = kind["use"] * float(flow["use"]) * pressure * dt
	var taken: = vehicle.draw_water(wanted) if offset.length() >= 0.5 else 0.0
	vehicle.fuel = maxf(0.0, vehicle.fuel - taken * float(Config.Truck.Fuel.PerLitrePumped))
	if taken <= 0.0:
		_set_spraying(line, false, 0, -1.0)
		if vehicle.water <= 0.0:
			Game.tell(player, Text.f("hud.water.tankEmpty", [Text.named("vehicles", vehicle.spec["name"])]))
		return

	var hose: Dictionary = Config.Hose


	var strength: float = dt * kind["power"] * float(flow["power"]) * pressure * taken / wanted
	var hard: float = strength / dt
	var exclude: Array[RID] = [player.get_rid()]
	var fire: = FireService.current

	if player.get_attr("Pattern") == "Fog":

		var fog: Dictionary = hose["Fog"]
		var reach: = offset.normalized() * float(fog["Reach"])
		var hit: = Game.world.raycast(origin, origin + reach, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
		var landing: Vector3 = hit["position"] if not hit.is_empty() else origin + reach
		if not hit.is_empty():
			_landed(line, hit, dt, reach.normalized(), player, false, hard)
		var fogged: = PackedVector3Array([origin, landing])
		var result: = fire.spray(player, fogged, strength * float(fog["Power"]), float(fog["Radius"]))
		fire.fog(landing, strength, player, dt)
		_set_spraying(line, true, result["hits"], result["progress"], _cooling(result, fogged, float(fog["Radius"])))
		_count_kills(player, result["kills"])
		_water_damage(player, landing, taken, result)
		return



	var velocity: = Ballistics.launch_toward(origin, aim, stream_speed(pressure), float(hose["StreamGravity"]))
	var cast: = func(from: Vector3, to: Vector3) -> Variant:
		var hit: = Game.world.raycast(from, to, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
		if hit.is_empty():
			return null

		_landed(line, hit, dt, (to - from).normalized(), player, true, hard)
		return hit["position"]
	var traced: = Ballistics.trace(origin, velocity, float(hose["StreamGravity"]), float(hose["StreamTime"]), int(hose["StreamSteps"]), cast)
	var result: = fire.spray(player, traced["path"], strength)
	_set_spraying(line, true, result["hits"], result["progress"], _cooling(result, traced["path"], float(hose["HitRadius"])))
	_count_kills(player, result["kills"])
	if traced["hit"]:
		var path: PackedVector3Array = traced["path"]
		_water_damage(player, path[path.size() - 1], taken, result)



static func stream_speed(pressure: float) -> float:
	var least: = float(Config.Water.Pressure.SpeedLeast)
	return float(Config.Hose.StreamSpeed) * lerpf(least, 1.0, clampf(pressure, 0.0, 1.0))



static func stream_speed_of(player: Player) -> float:
	return stream_speed(float(player.get_attr("Pressure", 1.0)) if player != null else 1.0)






func _landed(holder: Dictionary, hit: Dictionary, dt: float, direction: Vector3, player: Player, jet: bool, hard: float) -> void :
	var pane: Variant = _pane_of(hit)
	if pane == null:
		Game.water_landed.emit(hit, dt, direction, player)
		return
	if not jet or pane["broken"]:
		return
	holder["glass_seen"] = true
	var held: Variant = holder.get("glass")
	if not (held is Array) or held[0] != pane["id"]:
		held = [pane["id"], 0.0]
	held[1] = float(held[1]) + dt * hard
	holder["glass"] = held
	var need: = float(Config.Water.Glass.Hold)
	if float(held[1]) >= need * float(Config.Water.Glass.CrackAt) and not pane["cracked"]:
		pane["crack"].call()
		_sound(pane["position"], "glass_crack", 0.9)
		if Net.is_host():
			Net.broadcast("hose.crack", [pane["id"]])
	if float(held[1]) >= need:
		holder.erase("glass")
		pane["shatter"].call(direction)
		if player != null and is_instance_valid(player) and player.is_local and player.camera != null:
			player.camera.hit_stop()



static func _pane_of(hit: Dictionary) -> Variant:
	var row: = Game.world.row_hit(hit)
	if row < 0:
		return null
	return House._panes.get(Game.store.id_at(row))






func _water_damage(player: Player, at: Vector3, litres: float, result: Dictionary) -> void :
	var fire: = FireService.current
	if fire == null or fire.incident.is_empty() or int(result["hits"]) > 0 or litres <= 0.0:
		return
	var group: Dictionary = fire.incident["group"]
	var building: Variant = group["building"]
	if not building.has_rooms():
		return
	var room: Variant = building.room_at(at)
	if not (room is Dictionary):
		return
	var room_name: String = room["name"]
	for node: Dictionary in group["nodes"]:
		if node["burning"] and node["room"] == room_name:
			return
	var settings: Dictionary = Config.Water.Damage
	if not is_same(_damage["for"], fire.incident):
		_damage = {"for": fire.incident, "litres": 0.0, "applied": 0.0, "told": 0.0}
	_damage["litres"] = float(_damage["litres"]) + litres
	var share: = minf(float(_damage["litres"]) * float(settings["PerLitre"]), float(settings["Most"]))
	var more: = share - float(_damage["applied"])
	if more < 0.05:
		return
	_damage["applied"] = share

	var nodes: Array = group["nodes"]
	var spoilt: Array = nodes.filter( func(node: Dictionary) -> bool: return node["room"] == room_name and not node["burning"])
	if spoilt.is_empty():
		spoilt = nodes.filter( func(node: Dictionary) -> bool: return not node["burning"])
	if spoilt.is_empty():
		return
	var loss_share: = float(fire.settings()["LossShare"])
	var each: = more / 100.0 * nodes.size() * loss_share / spoilt.size()
	for node: Dictionary in spoilt:
		var burn: = float(node["material"]["burn"])
		node["fuel"] = maxf(burn * float(settings["LeastFuel"]), float(node["fuel"]) - each * burn)
	if int(fire.incident["count"]) <= 0:

		var burnt: = 0.0
		for node: Dictionary in nodes:
			burnt += 1.0 - node["fuel"] / float(node["material"]["burn"])
		fire.incident["health"] = minf(fire.incident["health"], 100.0 * (1.0 - burnt / (nodes.size() * loss_share)))
	Alarm.check("water", share < float(settings["CheckBelow"]))
	if share - float(_damage["told"]) >= float(settings["TellEvery"]):
		_damage["told"] = share
		Game.tell(player, Text.f("water.damage", [snappedf(share, 0.1)]))



func water_damage() -> float:
	var fire: = FireService.current
	if fire == null or not is_same(_damage["for"], fire.incident):
		return 0.0
	return float(_damage["applied"])





func _cooling(result: Dictionary, path: PackedVector3Array, reach: float) -> bool:
	var fire: = FireService.current
	if int(result["hits"]) <= 0 or float(result["progress"]) >= 0.0 or fire == null or fire.incident.is_empty():
		return false
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if not node["burning"] and float(node["heat"]) > 0.0 and float(node["fuel"]) > 0.0\
		and FireService.distance_to_path(node["position"], path) <= reach:
			return true
	return false





func pump_load(vehicle: Vehicle) -> float:
	var litres: = 0.0
	for line: Dictionary in lines:
		var rig: Variant = rig_of(line)
		if rig == null or rig["vehicle"] != vehicle:
			continue
		var player: Variant = line["player"]
		if player != null and is_instance_valid(player) and player.get_attr("Spraying", false) == true:
			litres += float(kind_of(line["kind"])["use"]) * float(flow_of(player)["use"])
		elif line.get("relay") != null:
			litres += float(Config.Hose.RelayFlow)
	if litres <= 0.0:
		return 0.0
	var rate: float = vehicle.spec.get("pumpRate", float(Config.Hose.PumpRate))
	return clampf(litres / rate, float(Config.Water.Pump.Least), 1.0)





static func powder_power(path: PackedVector3Array, radius: float) -> float:
	var settings: Dictionary = Config.Water.Powder
	var biggest: = 0.0
	for flame in Flame.all:
		if is_instance_valid(flame) and flame.intensity > 0.0 and FireService.distance_to_path(flame.global_position, path) <= radius + 1.0:
			biggest = maxf(biggest, flame.intensity)
	return lerpf(float(settings["Small"]), float(settings["Full"]), clampf(biggest, 0.0, 1.0))


func _count_kills(player: Player, kills: int) -> void :
	if kills > 0:
		player.set_attr("FlamesOut", int(player.get_attr("FlamesOut", 0)) + kills)











func add_monitor(monitor: Dictionary) -> void :
	var jet: = WaterJet.new()
	jet.speed = float(monitor["speed"])
	jet.flow = 1.0
	var passes: Array[RID] = []
	passes.assign(monitor.get("exclude", []))
	jet.exclude = passes
	add_child(jet)
	monitor["jet"] = jet
	monitor["spraying"] = false
	monitor["on_fire"] = false
	monitor["aim"] = Vector3.ZERO
	monitors.append(monitor)


func _step_monitors(dt: float) -> void :
	var hose: Dictionary = Config.Hose
	for monitor: Dictionary in monitors:
		var opened: Variant = monitor["state"].call()
		var node: Node3D = monitor["node"]
		var flowing: = false
		var hits: = 0
		if opened != null and is_instance_valid(node):
			var player: Player = opened[0]
			var aim: Vector3 = opened[1]
			var origin: = node.global_position
			var vehicle: Vehicle = monitor["vehicle"]
			var wanted: float = float(monitor["use"]) * dt
			var taken: = vehicle.draw_water(wanted)
			if taken > 0.0:
				flowing = true
				var exclude: Array[RID] = []
				exclude.assign(monitor.get("exclude", []))
				exclude.append(player.get_rid())
				var velocity: = Ballistics.launch_toward(origin, aim, float(monitor["speed"]), float(hose["StreamGravity"]))
				var cast: = func(from: Vector3, to: Vector3) -> Variant:
					var hit: = Game.world.raycast(from, to, World.LAYER_QUERY | World.LAYER_VEHICLE, exclude)
					if hit.is_empty():
						return null
					_landed(monitor, hit, dt, (to - from).normalized(), player, true, float(monitor["power"]))
					return hit["position"]
				monitor["glass_seen"] = false
				var traced: = Ballistics.trace(origin, velocity, float(hose["StreamGravity"]), float(hose["StreamTime"]), int(hose["StreamSteps"]), cast)
				var result: = FireService.current.spray(player, traced["path"], dt * float(monitor["power"]) * taken / wanted)
				hits = result["hits"]
				_count_kills(player, result["kills"])
				monitor["aim"] = aim
				if not monitor["glass_seen"]:
					_glass_off(monitor, dt)
		monitor["spraying"] = flowing
		monitor["on_fire"] = flowing and hits > 0





func _on_intake(rig: Dictionary, player: Player) -> void :
	var supply: Dictionary = rig["supply"]
	if not _meant(supply["prompt"], player):
		return
	var held: Variant = line_of(player)
	if supply["state"] == "stowed" and held != null and held["kind"] == "outlet" and not is_same(held["rig"], rig):

		if _feeds_back(held["rig"], rig):
			Game.notify(Text.m("gear.hose.feedLoop"), "", player)
		elif _geared(player):
			_connect_feed(held, rig)
		return
	if supply["state"] != "stowed":
		if supply["state"] == "carried" and supply["player"] != player:
			return
		stow_supply(rig)
		return
	if not _geared(player):
		return
	if line_of(player) != null:
		Game.notify(Text.m("gear.hose.returnAttackFirst"), "", player)
		return
	if supply_of(player) != null:
		Game.notify(Text.m("gear.hose.supplyAlready"), "", player)
		return
	if _loose.has(player):
		_connect_loose(rig, player)
		return
	if player.brain == null:
		if player.get_attr("HoseRoll") == "supply":
			supply["roll"] = _roll_rig(player)
			_clear_roll(player)
		elif player.get_attr("HoseRoll") == null and int(rig.get("rolls", {}).get("supply", 0)) > 0:

			if ToolService.current:
				ToolService.current.clear_hands(player)
			_add_rolls(rig, "supply", -1)
			supply["roll"] = rig
		else:
			_refuse(Text.m("water.rolls.supplyFirst" if player.get_attr("HoseRoll") != null else "water.rolls.noneHere"), player)
			return
	var vehicle: Vehicle = rig["vehicle"]
	_watch(player)
	var hose: = HoseLine.make(vehicle.intake["node"], SUPPLY_WIDTH, SUPPLY_COLOR, [vehicle.get_rid(), player.get_rid()])
	hose.swell = 0.0
	hose.set_end(player.rig.hand_right, HAND_DROP)
	supply["state"] = "carried"
	supply["player"] = player
	supply["hose"] = hose
	supply["prompt"].action = Text.m("gear.hose.supplyStow")
	player.holding = "tool"
	player.set_attr("Supply", rig)
	Game.notify(Text.m("gear.hose.supplyCarry"), "", player)
	_sound(vehicle.intake["node"].global_position, "storz_couple", 0.8)


func stow_supply(rig: Dictionary, reason: Variant = null) -> void :
	var supply: Dictionary = rig["supply"]
	if supply["state"] == "stowed":
		return
	var player: Player = supply["player"]
	if supply["hydrant"] != null:
		supply["hydrant"]["rig"] = null
		supply["hydrant"]["prompt"].action = supply["hydrant"].get("connect_text", Text.m("gear.hose.supplyConnect"))
	var donor: Variant = supply["donor"]
	if donor != null:
		donor["relay"] = null
		donor["prompt"].action = Text.m("gear.hose.kinds.outlet.take")
		_restock(donor)
		_show_outlet(donor)
	if is_instance_valid(supply["hose"]):
		_sound(supply["hose"].start.global_position if is_instance_valid(supply["hose"].start) else rig["vehicle"].global_position, "storz_uncouple", 0.7)
		supply["hose"].queue_free()
	supply.erase("charge_at")
	if supply.get("roll") is Dictionary:
		_add_rolls(supply["roll"], "supply", 1)
	supply.erase("roll")
	supply["state"] = "stowed"
	supply["hose"] = null
	supply["hydrant"] = null
	supply["donor"] = null
	supply["limit"] = null
	supply["player"] = null
	supply["prompt"].action = Text.m("gear.hose.supplyTake")
	if player != null and is_instance_valid(player):
		if player.get_attr("Supply") == rig:
			_drop_supply_attrs(player)
			if player.holding == "tool":
				player.holding = ""
		if reason != null:
			Game.notify(reason, "warning", player)
	elif reason != null:
		Game.notify(reason, "warning")



func _drop_supply_attrs(player: Player) -> void :
	player.set_attr("Supply", null)
	player.set_attr("HoseLength", null)


func _on_hydrant(hydrant: Dictionary, player: Player) -> void :
	if not _meant(hydrant["prompt"], player):
		return
	if hydrant.get("loose") != null:

		if hydrant["loose"] == player:
			_drop_loose(player, true)
		return
	if hydrant["rig"] == null and supply_of(player) == null and _loose.has(player):
		Game.notify(Text.m("gear.hose.supplyAlready"), "", player)
		return
	if hydrant["rig"] == null and supply_of(player) == null and player.get_attr("HoseRoll") == "supply":
		_take_loose(hydrant, player)
		return
	if hydrant["rig"] != null:
		if supply_of(player) != null:
			Game.notify(Text.m("gear.hose.hydrantTaken"), "", player)
		else:

			stow_supply(hydrant["rig"])
		return
	var rig: Variant = supply_of(player)
	if rig == null:
		Game.notify(Text.m("gear.hose.supplyTakeFirst"), "", player)
		return
	var supply: Dictionary = rig["supply"]
	var vehicle: Vehicle = rig["vehicle"]
	if hydrant.has("pump") and vehicle.outlets.is_empty():
		Game.notify(Text.m("gear.hose.noPump"), "", player)
		return
	supply["state"] = "connected"
	supply["hydrant"] = hydrant
	if hydrant.has("pump"):
		supply["hose"].width = SUCTION_WIDTH
	supply["hose"].set_end(hydrant["node"], HYDRANT_DROP)
	supply["player"] = null

	supply["charge_at"] = Game.now()
	supply["charge_for"] = float(Config.Water.Charge.Supply)
	hydrant["rig"] = rig
	hydrant["prompt"].action = Text.m("gear.hose.supplyDisconnect")
	_drop_supply_attrs(player)
	if player.holding == "tool":
		player.holding = ""
	_sound(hydrant["node"].global_position, "storz_couple", 0.8)
	_sound(hydrant["node"].global_position, "hydrant_valve", 0.9)




func _take_loose(hydrant: Dictionary, player: Player) -> void :
	if not _geared(player):
		return
	if hydrant.has("pump"):
		Game.notify(Text.m("gear.hose.supplyWhere"), "", player)
		return
	var roll: Variant = _roll_rig(player)
	_clear_roll(player)
	_watch(player)
	var hose: = HoseLine.make(hydrant["node"], SUPPLY_WIDTH, SUPPLY_COLOR, [player.get_rid()])
	hose.swell = 0.0
	hose.start_drop = HYDRANT_DROP
	hose.set_end(player.rig.hand_right, HAND_DROP)
	_loose[player] = {"hose": hose, "hydrant": hydrant, "roll": roll}
	hydrant["loose"] = player
	hydrant["prompt"].action = Text.m("gear.hose.supplyDisconnect")
	player.holding = "tool"
	player.set_attr("SupplyLoose", true)
	Game.notify(Text.m("gear.hose.supplyToTruck"), "", player)
	_sound(hydrant["node"].global_position, "storz_couple", 0.8)



func _drop_loose(player: Player, to_hand: bool) -> void :
	var loose: Dictionary = _loose[player]
	_loose.erase(player)
	var hydrant: Dictionary = loose["hydrant"]
	hydrant.erase("loose")
	hydrant["prompt"].action = hydrant.get("connect_text", Text.m("gear.hose.supplyConnect"))
	if is_instance_valid(loose["hose"]):
		_sound(hydrant["node"].global_position, "storz_uncouple", 0.7)
		loose["hose"].queue_free()
	player.set_attr("SupplyLoose", null)
	player.set_attr("HoseLength", null)
	if player.holding == "tool":
		player.holding = ""
	var roll: Variant = loose["roll"]
	if to_hand and is_instance_valid(player) and player.health > 0.0 and roll is Dictionary:
		player.set_attr("HoseRoll", "supply")
		player.set_attr("HoseRollRig", _rig_index(roll))
		player.holding = "tool"
		if ToolService.current:
			ToolService.current.carried_changed.emit(player)
		Game.notify(Text.m("gear.hose.rolls.supplyTaken"), "", player)
	elif roll is Dictionary:
		_add_rolls(roll, "supply", 1)




func _connect_loose(rig: Dictionary, player: Player) -> void :
	var loose: Dictionary = _loose[player]
	var hydrant: Dictionary = loose["hydrant"]
	var vehicle: Vehicle = rig["vehicle"]
	if hydrant.has("pump") and vehicle.outlets.is_empty():
		Game.notify(Text.m("gear.hose.noPump"), "", player)
		return
	var laid: PackedVector3Array = loose["hose"].points.duplicate()
	laid.reverse()
	_loose.erase(player)
	hydrant.erase("loose")
	if is_instance_valid(loose["hose"]):
		loose["hose"].queue_free()
	player.set_attr("SupplyLoose", null)
	player.set_attr("HoseLength", null)
	if player.holding == "tool":
		player.holding = ""
	var supply: Dictionary = rig["supply"]
	var hose: = HoseLine.make(vehicle.intake["node"], SUPPLY_WIDTH, SUPPLY_COLOR, [vehicle.get_rid(), player.get_rid()])
	hose.swell = 0.0
	hose.points = laid
	hose.set_end(hydrant["node"], HYDRANT_DROP)
	supply["roll"] = loose["roll"]
	supply["hose"] = hose
	supply["state"] = "connected"
	supply["hydrant"] = hydrant
	supply["player"] = null
	supply["charge_at"] = Game.now()
	supply["charge_for"] = float(Config.Water.Charge.Supply)
	supply["prompt"].action = Text.m("gear.hose.supplyStow")
	hydrant["rig"] = rig
	hydrant["prompt"].action = Text.m("gear.hose.supplyDisconnect")
	_sound(vehicle.intake["node"].global_position, "storz_couple", 0.8)
	_sound(hydrant["node"].global_position, "hydrant_valve", 0.9)









func _stock_rolls(rig: Dictionary) -> void :
	var vehicle: Vehicle = rig["vehicle"]
	var spare: int = int(Config.Hose.get("DividerRolls", 0)) if vehicle.spec.get("pumper", false) else 0
	rig["rolls"] = {"attack": vehicle.outlets.size() + spare, "supply": 0 if vehicle.intake.is_empty() else 1}
	rig["roll_full"] = rig["rolls"].duplicate()
	rig["roll_lines"] = {}
	var lockers: = Lockers.of(vehicle)
	if lockers == null:
		return
	for kind: String in ROLL_KINDS:
		if int(rig["rolls"][kind]) <= 0:
			continue
		var line: = lockers.add_line("L1", Text.m("gear.tools.take"), "", "fire", "nozzle" if kind == "attack" else "hydrant")
		line.chosen.connect( func(player: Player) -> void : _on_roll_line(rig, kind, player))
		rig["roll_lines"][kind] = line
	_show_rolls(rig)


func _show_rolls(rig: Dictionary) -> void :
	for kind: String in rig.get("roll_lines", {}):
		var line: LockerLine = rig["roll_lines"][kind]
		line.object = Text.f("gear.hose.rolls.%sCount" % kind, [int(rig["rolls"][kind]), int(rig["roll_full"][kind])])
	for line: Dictionary in lines:
		if is_same(line["rig"], rig):
			_show_outlet(line)
	var supply: Dictionary = rig["supply"]
	if supply["state"] == "stowed" and supply.get("prompt") != null:
		supply["prompt"].action = Text.m("gear.hose.supplyTake" if int(rig["rolls"].get("supply", 0)) > 0 else "water.rolls.supplyCouple")




func _show_outlet(line: Dictionary) -> void :
	if line.get("kind", "") != "outlet" or line["rig"] == null or line["player"] != null or line.get("feeding", false)\
	or line.get("relay") != null or line.get("down") != null or line.get("divert") != null:
		return
	var left: = int(line["rig"].get("rolls", {}).get("attack", 0))
	line["prompt"].action = Text.m("gear.hose.kinds.outlet.take" if left > 0 else "water.rolls.attackCouple")


func _add_rolls(rig: Dictionary, kind: String, count: int) -> void :
	if not rig.has("rolls"):
		return
	rig["rolls"][kind] = clampi(int(rig["rolls"][kind]) + count, 0, int(rig["roll_full"][kind]))
	_show_rolls(rig)



func _roll_rig(player: Player) -> Variant:
	var index: = int(player.get_attr("HoseRollRig", -1))
	return rigs[index] if index >= 0 and index < rigs.size() else null


func _clear_roll(player: Player) -> void :
	player.set_attr("HoseRoll", null)
	player.set_attr("HoseRollRig", null)
	if player.holding == "tool" and player.get_attr("Supply") == null and player.get_attr("Tool") == null:
		player.holding = ""
	if ToolService.current:
		ToolService.current.carried_changed.emit(player)



func _return_roll(player: Player) -> void :
	if _loose.has(player):
		_drop_loose(player, false)
	var kind: Variant = player.get_attr("HoseRoll")
	if kind == null:
		return
	var from: Variant = _roll_rig(player)
	_clear_roll(player)
	if from is Dictionary:
		_add_rolls(from, kind, 1)



func _on_roll_line(rig: Dictionary, kind: String, player: Player) -> void :
	if Net.is_client():
		return
	if player.get_attr("HoseRoll") == kind and is_same(_roll_rig(player), rig):
		_return_roll(player)
		Game.notify(Text.m("gear.hose.rolls.back"), "", player)
		return
	if not _geared(player):
		return
	if player.get_attr("HoseRoll") != null or line_of(player) != null or supply_of(player) != null or _loose.has(player) or player.get_attr("Carrying", false) == true:
		Game.notify(Text.m("gear.hose.rolls.handsFull"), "", player)
		return
	if int(rig["rolls"][kind]) <= 0:
		Game.notify(Text.m("gear.hose.rolls.none"), "", player)
		return
	if ToolService.current:
		ToolService.current.clear_hands(player)
	_add_rolls(rig, kind, -1)
	_watch(player)
	player.set_attr("HoseRoll", kind)
	player.set_attr("HoseRollRig", _rig_index(rig))
	player.holding = "tool"
	if ToolService.current:
		ToolService.current.carried_changed.emit(player)
	Game.notify(Text.m("gear.hose.rolls.%sTaken" % kind), "", player)
	Sounds.once(rig["vehicle"].body, "tool_clunk", 0.6, 8.0, 80.0)



func _draw_rolls() -> void :
	for player: Variant in _rolls_shown.keys():
		var kind: Variant = player.get_attr("HoseRoll") if is_instance_valid(player) else null
		var shown: Node3D = _rolls_shown[player]
		if kind == null or not is_instance_valid(shown) or shown.get_meta("kind") != kind:
			if is_instance_valid(shown):
				shown.queue_free()
			_rolls_shown.erase(player)
	for player in Game.players:
		var kind: Variant = player.get_attr("HoseRoll")
		if kind == null or _rolls_shown.has(player) or player.rig == null:
			continue
		var roll: = Node3D.new()
		roll.set_meta("kind", kind)
		var model: = MeshInstance3D.new()
		model.mesh = ToolModels.of("Supply roll" if kind == "supply" else "Attack roll")["body"]
		roll.add_child(model)
		roll.set_meta("hold", "roll")
		player.rig.hand_right.add_child(roll)
		_rolls_shown[player] = roll







func _put_down(line: Dictionary, player: Player) -> void :
	if line["player"] != player or player.seat != null:
		return
	var look: = player.camera.forward() if player.camera != null else - player.global_transform.basis.z
	if player.brain != null or not player.is_local:
		look = - player.global_transform.basis.z
	var flat: = Vector3(look.x, 0, look.z)
	flat = flat.normalized() if flat.length() > 0.01 else Vector3.FORWARD
	var ahead: = player.root_position() + flat * 1.8
	var ground: = Game.world.raycast(ahead + Vector3(0, 3, 0), ahead + Vector3(0, -9, 0), World.LAYER_SOLID, [player.get_rid()])
	if ground.is_empty():
		Game.notify(Text.m("gear.tools.nowhere"), "", player)
		return
	var hose: HoseLine = _let_go(line)
	line["hose"] = hose
	var at: Vector3 = ground["position"]
	var place: = Transform3D(Basis.looking_at(flat, Vector3.UP), at)
	_build_down(line, place)
	hose.set_end(line["down"]["nozzle"].hose_in, 0.3)
	if player.brain == null:
		Game.notify(Text.m("water.putDown"), "", player)
	Sounds.once(line["down"]["node"], "tool_clunk", 0.5, 8.0, 60.0)




func _build_down(line: Dictionary, place: Transform3D) -> void :
	_clear_down(line)
	var node: = Node3D.new()
	add_child(node)
	node.global_transform = place
	var nozzle: = Nozzle.new()
	node.add_child(nozzle)
	nozzle.position = Vector3(0, 0.3, 0)
	nozzle.rotation = Vector3(0, 0, PI / 2.0)
	var index: = _line_index(line)
	var prompt: = _named_prompt(node, "hose.pick.%d" % index, Text.m("gear.hose.rolls.pickUp"), Text.m("gear.hose.rolls.nozzle"), 0.3)
	prompt.key = "coupling"
	prompt.triggered.connect( func(player: Player) -> void : _pick_up(line, player))
	line["down"] = {"node": node, "nozzle": nozzle, "place": place}


func _clear_down(line: Dictionary) -> void :
	var down: Variant = line.get("down")
	if down is Dictionary and is_instance_valid(down["node"]):
		down["node"].queue_free()
	line["down"] = null



func _pick_up(line: Dictionary, player: Player) -> void :
	if Net.is_client() or line.get("down") == null or line["player"] != null:
		return
	if not _geared(player):
		return
	if line_of(player) != null or supply_of(player) != null or player.get_attr("HoseRoll") != null or player.get_attr("Carrying", false) == true:
		Game.notify(Text.m("gear.hose.rolls.handsFull"), "", player)
		return
	var hose: HoseLine = line["hose"]
	if ToolService.current:
		ToolService.current.clear_hands(player)
	_clear_down(line)
	_take_hold(line, player, hose)
	Sounds.once(hose, "tool_clunk", 0.5, 8.0, 60.0)






func _feeds_back(giver: Dictionary, taker: Dictionary) -> bool:
	var donor: Variant = giver["supply"]["donor"]
	return donor != null and is_same(donor["rig"], taker)




func _connect_relay(rig: Dictionary, donor: Dictionary, player: Player) -> void :
	var supply: Dictionary = rig["supply"]
	supply["hose"].set_end(donor["source"], HYDRANT_DROP)
	supply["state"] = "connected"
	supply["donor"] = donor
	supply["player"] = null
	donor["relay"] = rig
	donor["prompt"].action = Text.m("gear.hose.supplyDisconnect")
	supply["charge_at"] = Game.now()
	supply["charge_for"] = float(Config.Water.Charge.Time)
	_drop_supply_attrs(player)
	if player.holding == "tool":
		player.holding = ""
	_sound(donor["source"].global_position, "storz_couple", 0.9)





func _connect_feed(line: Dictionary, rig: Dictionary) -> void :
	var player: Player = line["player"]
	var vehicle: Vehicle = rig["vehicle"]
	var hose: = _let_go(line)
	hose.set_end(vehicle.intake["node"], HYDRANT_DROP)
	var supply: Dictionary = rig["supply"]
	supply["state"] = "connected"
	supply["donor"] = line
	supply["hose"] = hose
	supply["limit"] = kind_of(line["kind"])["length"]
	supply["player"] = null
	line["relay"] = rig
	line["prompt"].action = Text.m("gear.hose.supplyDisconnect")
	supply["prompt"].action = Text.m("gear.hose.supplyStow")
	Game.notify(Text.m("gear.hose.feedConnected"), "", player)
	_sound(vehicle.intake["node"].global_position, "storz_couple", 0.9)






func _stock_divider(vehicle: Vehicle) -> void :
	var lockers: = Lockers.of(vehicle)
	if lockers == null or not vehicle.shutters.has(DIVIDER_LOCKER):
		return
	divider["vehicle"] = vehicle
	var line: = lockers.add_line(DIVIDER_LOCKER, Text.m("gear.hose.dividerTake"), Text.named("tools", DIVIDER_TOOL), "fire", ToolIcons.of(DIVIDER_TOOL))
	divider["line"] = line
	line.chosen.connect( func(player: Player) -> void :
		if divider["state"] == "carried" and divider["player"] == player:

			_stow_divider()
			Game.notify(Text.f("gear.tools.onTruck", [Text.named("tools", DIVIDER_TOOL)]), "", player)
		elif divider["state"] != "stowed":
			Game.notify(Text.m("gear.hose.dividerAlreadyOut"), "", player)
		elif line_of(player) != null:
			Game.notify(Text.m("gear.hose.returnAttackFirst"), "", player)
		elif player.health > 0.0 and _geared(player):
			_carry_divider(player)
	)



func _refresh_divider() -> void :
	var line: LockerLine = divider["line"]
	if line == null:
		return
	line.action = Text.m("gear.hose.dividerTake" if divider["state"] == "stowed" else "gear.hose.dividerOut")
	line.holder = divider["player"] if divider["state"] == "carried" else null
	var vehicle: Vehicle = divider["vehicle"]
	if vehicle.props.has("Divider"):
		vehicle.props["Divider"]["node"].visible = divider["state"] == "stowed"
	if divider["state"] != "placed":
		return
	var fed: bool = divider["feed"] != null
	divider["inlet"]["prompt"].enabled = not fed
	var in_use: = false
	for branch: Dictionary in divider["lines"]:
		branch["prompt"].enabled = fed
		in_use = in_use or branch["player"] != null
	divider["pickup"].enabled = not fed and not in_use



func _unfeed(line: Dictionary, reason: Variant = null) -> void :
	for branch: Dictionary in divider["lines"]:
		disconnect_line(branch, reason if reason != null else Text.m("gear.hose.feedLost"))
	if is_instance_valid(line["hose"]):
		line["hose"].queue_free()
	line["hose"] = null
	line["feeding"] = false
	_restock(line)
	line["prompt"].action = Text.m("gear.hose.kinds.outlet.take")
	_show_outlet(line)
	divider["feed"] = null
	_refresh_divider()




func _feed_divider(player: Player) -> void :
	var line: Variant = line_of(player)
	if line == null or line["kind"] != "outlet":
		Game.notify(Text.m("gear.hose.feedNeeded"), "", player)
		return
	var hose: = _let_go(line)
	hose.set_end(divider["inlet"]["node"], DIVIDER_DROP)
	line["hose"] = hose
	line["feeding"] = true
	line["prompt"].action = Text.m("gear.hose.feedTakeOff")
	divider["feed"] = line
	_refresh_divider()
	Game.notify(Text.m("gear.hose.dividerFed"), "", player)
	_sound(divider["inlet"]["node"].global_position, "storz_couple", 0.9)



func _stow_divider() -> void :
	if divider["feed"] != null:
		_unfeed(divider["feed"])
	for index in range(lines.size() - 1, -1, -1):
		if lines[index]["kind"] == "divider":
			disconnect_line(lines[index])
			lines.remove_at(index)
	if is_instance_valid(divider["model"]):
		divider["model"].queue_free()
	if is_instance_valid(divider["tool"]):
		divider["tool"].queue_free()
	var carrier: Variant = divider["player"]
	if carrier != null and is_instance_valid(carrier):
		_show_divider(false)
		if ToolService.current and divider["entry"] != null:
			ToolService.current.drop_other(carrier, divider["entry"])
	divider["state"] = "stowed"
	divider["model"] = null
	divider["body"] = null
	divider["tool"] = null
	divider["entry"] = null
	divider["player"] = null
	divider["inlet"] = null
	divider["pickup"] = null
	divider["lines"] = []
	_refresh_divider()




func _create_coupling(model: Node3D, coupling_name: String, place: Transform3D, size: Vector3, action: Variant, object: Variant) -> Dictionary:
	CallKit.part(model, CallKit.CYLINDER, size, place, BRASS, "Metal", false, 0.0, "Coupling")
	var node: = Node3D.new()
	model.add_child(node)
	node.global_position = place.origin
	var prompt: = _named_prompt(node, "divider_" + coupling_name, action, object, 0.3)
	prompt.key = "coupling"
	return {"node": node, "prompt": prompt}



func _named_prompt(parent: Node3D, net_id: String, action: Variant, object: Variant, hold: float) -> Prompt:
	var prompt: = Prompt.new()
	prompt.net_id = net_id
	prompt.action = action
	prompt.object = object
	prompt.hold = hold
	prompt.reach = 9.0
	parent.add_child(prompt)
	return prompt



func _place_divider(player: Player) -> void :
	if player.health <= 0.0 or player.seat != null:
		return
	var look: = player.facing()
	var flat: = Vector3(look.x, 0, look.z).normalized()
	var ahead: = player.root_position() + flat * 4.0
	var ground: = Game.world.raycast(ahead + Vector3(0, 3, 0), ahead + Vector3(0, -9, 0), World.LAYER_SOLID, [player.get_rid()])
	if ground.is_empty():
		Game.notify(Text.m("gear.hose.dividerNoGround"), "", player)
		return
	var at: Vector3 = ground["position"]
	var place: = Rbx.look_at(at, at + flat) * Transform3D(Basis.IDENTITY, Vector3(0, 0.7, 0))

	_show_divider(false)
	if ToolService.current and divider["entry"] != null:
		ToolService.current.drop_other(player, divider["entry"])
	if is_instance_valid(divider["tool"]):
		divider["tool"].queue_free()
	_build_divider(place)
	divider["player"] = null
	divider["tool"] = null
	divider["entry"] = null
	_refresh_divider()
	Sounds.once(divider["body"], "tool_clunk", 0.9, 8.0, 80.0)
	Game.notify(Text.m("gear.hose.dividerSetDown"), "", player)





func _build_divider(place: Transform3D) -> void :
	var model: = CallKit.model("Divider")
	var body: = CallKit.part(model, CallKit.BLOCK, Vector3(2.2, 1.2, 1.6), place, RED, "Metal", true, 0.0, "Body")

	var stub: = Vector3(0.9, 0.8, 0.8)
	var quarter: = Rbx.angles(0, PI / 2, 0)
	var inlet: = _create_coupling(model, "inlet", place * Transform3D(Basis.IDENTITY, Vector3(0, 0, 1.2)) * quarter, stub, Text.m("gear.hose.feedConnect"), Text.m("gear.hose.dividerInlet"))
	inlet["prompt"].triggered.connect( func(feeder: Player) -> void :
		if _meant(inlet["prompt"], feeder) and _geared(feeder):
			_feed_divider(feeder)
	)
	var branches: Array = []
	var turns: Array[float] = [45.0, 0.0, -45.0]
	for index in turns.size():
		var out: = place * Rbx.angles(0, deg_to_rad(turns[index]), 0) * Transform3D(Basis.IDENTITY, Vector3(0, 0, -1.3)) * quarter
		var coupling: = _create_coupling(model, "outlet%d" % (index + 1), out, stub, Text.m("gear.hose.kinds.divider.take"), Text.f("gear.hose.dividerOutlet", [index + 1]))
		var line: = {"kind": "divider", "rig": null, "source": coupling["node"], "prompt": coupling["prompt"], "player": null, "hose": null, "jet": null, "over_for": 0.0, "spraying": false, "feeding": false, "relay": null}

		coupling["prompt"].condition = func(taker: Player) -> bool:
			var held: Variant = line_of(taker)
			return held == null or is_same(held, line)
		coupling["prompt"].triggered.connect( func(taker: Player) -> void : _on_outlet(line, taker))
		branches.append(line)
		lines.append(line)

	var pickup: = _named_prompt(body, "divider_pickup", Text.m("gear.hose.dividerBack"), Text.named("tools", DIVIDER_TOOL), 0.6)
	pickup.position = Vector3(0, 0.9, 0)
	pickup.triggered.connect( func(_taker: Player) -> void : _stow_divider())

	divider["state"] = "placed"
	divider["place"] = place
	divider["model"] = model
	divider["body"] = body
	divider["inlet"] = inlet
	divider["lines"] = branches
	divider["pickup"] = pickup



func _show_divider(on: bool) -> void :
	var carrier: Variant = divider["player"]
	if carrier == null or not is_instance_valid(carrier):
		return
	var tool: Variant = divider["tool"]
	if is_instance_valid(tool):
		tool.visible = on
	if on:
		carrier.holding = "tool"
		carrier.set_attr("Tool", DIVIDER_TOOL)
	elif carrier.get_attr("Tool") == DIVIDER_TOOL:
		carrier.set_attr("Tool", null)
		if carrier.holding == "tool" and carrier.get_attr("Supply") == null:
			carrier.holding = ""



func _carry_divider(player: Player) -> void :
	_watch(player)
	if ToolService.current:
		ToolService.current.clear_hands(player)
	var tool: = _divider_in_hand(player)
	divider["state"] = "carried"
	divider["player"] = player
	divider["tool"] = tool

	divider["entry"] = {
		"name": DIVIDER_TOOL, 
		"in_hand": func() -> bool: return is_instance_valid(tool) and tool.visible, 
		"set_in_hand": func(on: bool) -> void : _show_divider(on), 
	}
	_show_divider(true)
	if ToolService.current:
		ToolService.current.carry_other(player, divider["entry"])
	_refresh_divider()
	Game.notify(Text.m("gear.hose.dividerCarry"), "", player)



func _divider_in_hand(player: Player) -> Node3D:
	var tool: = Node3D.new()
	tool.name = DIVIDER_TOOL
	player.rig.hand_right.add_child(tool)

	tool.set_meta("hold", "divider")
	tool.add_child(ToolModels.instance("Divider"))
	return tool



func _carried_divider() -> void :
	if divider["state"] != "carried":
		return
	if Net.is_client():

		var mine: Variant = divider["tool"]
		var me: = Game.local_player
		if divider["player"] == me and is_instance_valid(mine) and mine.visible and me.camera != null and me.camera.captured and not Game.ui_open and Input.is_action_just_pressed("fire"):
			me.set_down_ahead(3.0)
			Net.request("hose.divider.place")
		return
	var carrier: Variant = divider["player"]
	if carrier == null or not is_instance_valid(carrier):
		_stow_divider()
		return
	var tool: Node3D = divider["tool"]
	if not tool.visible:
		return
	var taken: bool = carrier.get_attr("Line") != null or carrier.get_attr("Supply") != null or carrier.get_attr("Carrying", false) == true or carrier.seat != null
	if taken:
		_show_divider(false)
		if ToolService.current:
			ToolService.current.carried_changed.emit(carrier)
	elif carrier.is_local and carrier.camera != null and carrier.camera.captured and not Game.ui_open and Input.is_action_just_pressed("fire"):
		carrier.set_down_ahead(3.0)
		Net.request("hose.divider.place")









func add_source(source: Dictionary) -> void :
	source["rig"] = null
	var prompt: Prompt = source["prompt"]
	prompt.key = "coupling"
	prompt.triggered.connect( func(player: Player) -> void : _on_hydrant(source, player))



func remove_source(source: Dictionary, reason: Variant = null) -> void :
	if source.get("rig") != null:
		stow_supply(source["rig"], reason)





func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_clock += delta
	var tick: float = Config.Hose.Tick
	while _clock >= tick:
		_clock -= tick
		_step(tick)


func _step(dt: float) -> void :


	var demand: Dictionary = {}
	for line: Dictionary in lines:
		if line["player"] != null and _is_open(line) and line.get("charged", true):
			var asks: float = kind_of(line["kind"])["use"] * float(flow_of(line["player"])["use"])
			var from: Vehicle = rig_of(line)["vehicle"]
			demand[from] = demand.get(from, 0.0) + asks
		elif line.get("relay") != null and line["relay"]["vehicle"].capacity - line["relay"]["vehicle"].water > 1.0:

			var from: Vehicle = line["rig"]["vehicle"]
			demand[from] = demand.get(from, 0.0) + float(Config.Hose.RelayFlow)
	for line: Dictionary in lines.duplicate():
		var player: Player = line["player"]
		if player == null:
			continue
		if not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
			disconnect_line(line)
			continue
		var kind: = kind_of(line["kind"])
		var hose: HoseLine = line["hose"]
		hose.follow(player.global_position + Vector3(0, 1, 0))
		var paid: = hose.length()
		player.set_attr("HoseLength", paid)


		line["over_for"] = line["over_for"] + dt if hose.stretched() else 0.0
		if line["over_for"] > OVER_LENGTH_TIME:
			disconnect_line(line, Text.m(kind["words"] + ".lost"))
			_refresh_divider()
			continue
		var rig: Dictionary = rig_of(line)
		var rate: float = rig["vehicle"].spec.get("pumpRate", float(Config.Hose.PumpRate))
		var asked: float = demand.get(rig["vehicle"], 0.0)
		var share: = minf(1.0, rate / asked) if asked > 0.0 else 1.0
		var pressure: = share * _loss(line, player, paid)
		var step: = float(Config.Water.Pressure.Step)
		player.set_attr("Pressure", snappedf(pressure, step))
		player.set_attr("PumpShare", snappedf(share, step))
		_charge_step(line, player)
		_spray(player, line, dt, pressure)


	var feed: Variant = divider["feed"]
	if feed != null and feed["hose"].stretched():
		_unfeed(feed, Text.m("gear.hose.feedPulled"))

	_step_monitors(dt)

	for rig: Dictionary in rigs:
		var supply: Dictionary = rig["supply"]
		var vehicle: Vehicle = rig["vehicle"]
		if supply["state"] == "carried":
			var player: Player = supply["player"]
			if not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
				stow_supply(rig)
				continue
			supply["hose"].follow(player.global_position + Vector3(0, 1, 0))
			player.set_attr("HoseLength", supply["hose"].length())
			if supply["hose"].stretched():
				stow_supply(rig, Text.m("gear.hose.supplyPulledTruck"))
		elif supply["state"] == "connected" and supply["donor"] != null:
			if supply["hose"].stretched():
				stow_supply(rig, Text.m("gear.hose.supplyPulledTruck"))
				continue
			if not _supply_charged(supply):
				continue

			var donor_rig: Dictionary = supply["donor"]["rig"]
			var giver: Vehicle = donor_rig["vehicle"]
			var rate: float = giver.spec.get("pumpRate", float(Config.Hose.PumpRate))
			var asked: float = demand.get(giver, 0.0)
			var share: = minf(1.0, rate / asked) if asked > 0.0 else 1.0
			var moved: = giver.draw_water(minf(float(Config.Hose.RelayFlow) * share * dt, vehicle.capacity - vehicle.water))
			giver.fuel = maxf(0.0, giver.fuel - moved * float(Config.Truck.Fuel.PerLitrePumped))
			vehicle.fill_water(moved)
		elif supply["state"] == "connected":

			if supply["hose"].stretched():
				stow_supply(rig, Text.m("gear.hose.supplyPulledHydrant"))
				continue
			if supply["hydrant"].has("pump"):


				_supply_charged(supply)
				supply["hydrant"]["pump"].call(dt)
			elif _supply_charged(supply):

				vehicle.fill_water(float(supply["hydrant"].get("flow", Config.Hose.HydrantFlow)) * dt)
	for player: Player in _loose.keys():
		if not is_instance_valid(player) or player.health <= 0.0 or player.seat != null:
			_drop_loose(player, false)
			continue
		var hose: HoseLine = _loose[player]["hose"]
		hose.follow(player.global_position + Vector3(0, 1, 0))
		player.set_attr("HoseLength", hose.length())
	_tank_calls()




func _loss(line: Dictionary, player: Player, paid: float) -> float:
	var settings: Dictionary = Config.Water.Pressure
	var length: float = kind_of(line["kind"])["length"]
	var loss: = float(settings["LengthLoss"]) * clampf(paid / maxf(length, 1.0), 0.0, 1.0)
	if is_instance_valid(line["source"]):
		var rise: float = nozzle_tip(player).y - line["source"].global_position.y
		loss += float(settings["RiseLoss"]) * maxf(rise, 0.0) / float(settings["RisePer"])
	return clampf(1.0 - loss, float(settings["Least"]), 1.0)





func _charge_step(line: Dictionary, player: Player) -> void :
	if line.get("charged", true):
		return
	var vehicle: Vehicle = rig_of(line)["vehicle"]
	var hose: HoseLine = line["hose"]
	if line.get("charge_at") == null:
		if not _is_open(line) or vehicle.water <= 0.0:
			return
		line["charge_at"] = Game.now()
		player.set_attr("Charging", true)
		_sound(nozzle_tip(player), "line_charge", 0.9)
	var share: = clampf((Game.now() - float(line["charge_at"])) / float(Config.Water.Charge.Time), 0.0, 1.0)
	if is_instance_valid(hose):
		hose.swell = share
	if share >= 1.0:
		line["charged"] = true
		line.erase("charge_at")
		player.set_attr("Charging", null)



func _charged(line: Dictionary, _player: Player, vehicle: Vehicle) -> bool:
	return line.get("charged", true) or vehicle.water <= 0.0




func _supply_charged(supply: Dictionary) -> bool:
	var since: Variant = supply.get("charge_at")
	var hose: Variant = supply["hose"]
	if since == null:
		if is_instance_valid(hose):
			hose.swell = 1.0
		return true
	var share: = clampf((Game.now() - float(since)) / float(supply.get("charge_for", Config.Water.Charge.Supply)), 0.0, 1.0)
	if is_instance_valid(hose):
		hose.swell = share
	if share >= 1.0:
		supply.erase("charge_at")
		supply.erase("charge_for")
		return true
	return false




func _tank_calls() -> void :
	var marks: Array = Config.Water.Tank.Warn
	for rig: Dictionary in rigs:
		var vehicle: Vehicle = rig["vehicle"]
		if vehicle.capacity <= 0.0:
			continue
		var share: = vehicle.water / vehicle.capacity
		var reached: = 0
		for mark: Variant in marks:
			if share <= float(mark):
				reached += 1
		if share <= 0.0:
			reached = marks.size() + 1
		var said: int = _tank_said.get(vehicle, reached)
		if reached > said and _drawn_on(vehicle):
			var name_said: Variant = Text.named("vehicles", vehicle.spec["name"])
			var pieces: Array = Config.Water.Tank.Pieces
			if reached > marks.size():
				Radio.say(Text.f("water.tank.empty", [name_said]), "danger", "tank_empty")
			else:
				Radio.say(Text.f("water.tank.low", [name_said, roundi(float(marks[reached - 1]) * 100.0)]), "warning", str(pieces[mini(reached - 1, pieces.size() - 1)]))
		_tank_said[vehicle] = reached



func _drawn_on(vehicle: Vehicle) -> bool:
	for line: Dictionary in lines:
		if line["player"] != null and line["spraying"]:
			var rig: Variant = rig_of(line)
			if rig != null and rig["vehicle"] == vehicle:
				return true
	return false





func _process(delta: float) -> void :
	_carried_divider()
	_draw_rolls()
	var mirrored: = Net.is_client()
	for index in monitors.size():
		var monitor: Dictionary = monitors[index]
		var jet: WaterJet = monitor["jet"]
		if is_instance_valid(monitor["node"]):
			if mirrored and monitor.has("aim_told"):

				monitor["aim"] = monitor["aim"].lerp(monitor["aim_told"], 1.0 - exp( - delta * 14.0)) if monitor["spraying"] else monitor["aim_told"]
			jet.spraying = monitor["spraying"]
			jet.origin = monitor["node"].global_position
			jet.aim = monitor["aim"]
		else:
			jet.spraying = false
	for line: Dictionary in lines:
		var player: Player = line["player"]
		if player == null or not is_instance_valid(player) or not is_instance_valid(line["jet"]):
			continue
		var jet: WaterJet = line["jet"]
		var shown: = _shown_spraying(line, player)
		jet.spraying = shown
		jet.fog = player.get_attr("Pattern") == "Fog"
		jet.origin = nozzle_tip(player)
		jet.aim = _shown_aim(line, player, delta)
		jet.flow = float(flow_of(player)["use"]) / 1.6

		var pressure: = float(player.get_attr("Pressure", 1.0))
		jet.speed = stream_speed(pressure)
		jet.pressure = pressure

		var rig: Variant = rig_of(line)
		var tank: Vehicle = rig["vehicle"] if rig != null else null
		jet.sputter = tank != null and tank.capacity > 0.0 and tank.water / tank.capacity < float(Config.Water.Tank.Sputter)
		_feel(line, player, shown, delta)
		if player.is_local and not Game.ui_open:
			if Input.is_action_just_pressed("flow"):
				var flows: Array = Config.Hose.Flows
				player.set_attr("Flow", int(player.get_attr("Flow", 2)) % flows.size() + 1)
			if Input.is_action_just_pressed("pattern"):
				player.set_attr("Pattern", "Jet" if player.get_attr("Pattern") == "Fog" else "Fog")





func _feel(line: Dictionary, player: Player, shown: bool, _delta: float) -> void :
	var nozzle: Variant = line.get("nozzle")
	if is_instance_valid(nozzle):
		nozzle.open = _is_open(line) if player.is_local else shown
		nozzle.flow_step = int(player.get_attr("Flow", int(Config.Hose.StartFlow)))
		nozzle.fog = player.get_attr("Pattern") == "Fog"
		nozzle.flowing = shown
	var index: = _line_index(line)
	var was: bool = _opened_shown.get(index, false)
	_opened_shown[index] = shown
	if not player.is_local or player.camera == null:
		return
	var kick: Dictionary = Config.Water.Kick
	var flow: = float(flow_of(player)["use"]) * float(player.get_attr("Pressure", 1.0))
	if shown and not was:
		player.camera.push(float(kick["Push"]) * flow, float(kick["Time"]))
	player.camera.sway = float(kick["Sway"]) * flow if shown else 0.0





func _shown_spraying(line: Dictionary, player: Player) -> bool:
	if Net.is_host():
		return line["spraying"]
	var told: bool = player.get_attr("Spraying", false) == true
	if not player.is_local:
		return told
	if not _is_open(line) or not line.get("charged", true):
		line.erase("opened")
		return false
	if not line.has("opened"):
		line["opened"] = Game.now()
	return told or Game.now() - float(line["opened"]) < 0.5




func _shown_aim(line: Dictionary, player: Player, delta: float) -> Vector3:
	var aim: = aim_of(player)
	if player.is_local:
		return aim
	var shown: Vector3 = line.get("aim", aim)
	shown = aim if shown.distance_to(aim) > 40.0 else shown.lerp(aim, 1.0 - exp( - delta * 18.0))
	line["aim"] = shown
	return shown
















func _peer(player: Variant) -> int:
	return Net.peer_of(player) if (player != null and is_instance_valid(player)) else 0


func _line_index(line: Variant) -> int:
	if line != null:
		for index in lines.size():
			if is_same(lines[index], line):
				return index
	return -1


func _rig_index(rig: Variant) -> int:
	if rig != null:
		for index in rigs.size():
			if is_same(rigs[index], rig):
				return index
	return -1





func _end_name(node: Node3D) -> Array:
	for index in lines.size():
		var line: Dictionary = lines[index]
		if line["source"] == node:
			return ["l", index]
		if is_instance_valid(line.get("nozzle")) and line["nozzle"].hose_in == node:
			return ["n", _peer(line["player"])]
	for index in rigs.size():
		var vehicle: Vehicle = rigs[index]["vehicle"]
		if not vehicle.intake.is_empty() and vehicle.intake["node"] == node:
			return ["i", index]
	for index in hydrants.size():
		if hydrants[index]["node"] == node:
			return ["h", index]
	if divider["inlet"] != null and divider["inlet"]["node"] == node:
		return ["d"]
	for peer: int in Net.players:
		var player: Player = Net.players[peer]
		if is_instance_valid(player) and player.rig.hand_right == node:
			return ["p", peer]
	return ["at", node.global_position]


func _end_node(told: Array, hose: Node3D) -> Node3D:
	match told[0]:
		"l":
			return lines[told[1]]["source"] if told[1] < lines.size() else null
		"n", "p":
			var player: Player = Net.player_of(told[1])
			if player == null or not is_instance_valid(player):
				return null
			var line: Variant = line_of(player)
			if told[0] == "n" and line != null and is_instance_valid(line.get("nozzle")):
				return line["nozzle"].hose_in
			return player.rig.hand_right
		"i":
			return rigs[told[1]]["vehicle"].intake["node"] if told[1] < rigs.size() else null
		"h":
			return hydrants[told[1]]["node"] if told[1] < hydrants.size() else null
		"d":
			return divider["inlet"]["node"] if divider["inlet"] != null else null

	var parent: Node = hose if hose != null else self
	var mark: = Node3D.new()
	parent.add_child(mark)
	mark.global_position = told[1]
	return mark


func _hose_state(hose: HoseLine) -> Array:
	return [_end_name(hose.start), _end_name(hose.finish), hose.finish_drop, hose.width, hose.color, hose.points.duplicate(), snappedf(hose.swell, 0.1)]


func _net_state() -> Variant:
	var held: Array = []
	var hoses: = {}
	for index in lines.size():
		var line: Dictionary = lines[index]
		var down: Variant = line.get("down")
		held.append([_peer(line["player"]), line["feeding"], _rig_index(line.get("relay")), down["place"] if down is Dictionary else null, line.get("charged", true)])
		var hose: Variant = line["hose"]
		if is_instance_valid(hose) and is_instance_valid(hose.finish) and is_instance_valid(hose.start):
			hoses["L%d" % index] = _hose_state(hose)
	var supplies: Array = []
	for index in rigs.size():
		var supply: Dictionary = rigs[index]["supply"]
		var source: Variant = supply["hydrant"]
		var where: = -1
		if source != null:
			where = -2
			for at in hydrants.size():
				if is_same(hydrants[at], source):
					where = at
		supplies.append([supply["state"], _peer(supply["player"]), where, _line_index(supply["donor"])])
		var hose: Variant = supply["hose"]
		if is_instance_valid(hose) and is_instance_valid(hose.finish) and is_instance_valid(hose.start):
			hoses["S%d" % index] = _hose_state(hose)
	for player: Player in _loose:
		var hose: Variant = _loose[player]["hose"]
		if is_instance_valid(player) and is_instance_valid(hose) and is_instance_valid(hose.finish) and is_instance_valid(hose.start):
			hoses["X%d" % _peer(player)] = _hose_state(hose)
	var in_hand: bool = is_instance_valid(divider["tool"]) and divider["tool"].visible
	return {
		"lines": held, "rigs": supplies, "hoses": hoses, 
		"divider": [divider["state"], _peer(divider["player"]), divider.get("place", Transform3D.IDENTITY), _line_index(divider["feed"]), in_hand], 
	}


func _net_apply(state: Variant) -> void :
	if not Net.is_client():
		return
	_net_last = state
	_net_apply_divider(state["divider"])
	var held: Array = state["lines"]
	for index in mini(lines.size(), held.size()):
		var line: Dictionary = lines[index]
		var player: Player = Net.player_of(held[index][0]) if held[index][0] != 0 else null
		if line["player"] != player:
			_net_let_go(line)
			if player != null:
				_hand_nozzle(line, player)
		line["feeding"] = held[index][1]
		line["relay"] = rigs[held[index][2]] if held[index][2] >= 0 else null
		line["charged"] = held[index][4] if held[index].size() > 4 else true

		var told_down: Variant = held[index][3] if held[index].size() > 3 else null
		var down: Variant = line.get("down")
		if told_down is Transform3D:
			if not (down is Dictionary) or not (down["place"] as Transform3D).is_equal_approx(told_down):
				_build_down(line, told_down)
		elif down != null:
			_clear_down(line)
	for hydrant: Dictionary in hydrants:
		hydrant["rig"] = null
	var supplies: Array = state["rigs"]
	for index in mini(rigs.size(), supplies.size()):
		var supply: Dictionary = rigs[index]["supply"]
		var told: Array = supplies[index]
		supply["state"] = told[0]
		supply["player"] = Net.player_of(told[1]) if told[1] != 0 else null
		supply["hydrant"] = null
		if told[2] >= 0 and told[2] < hydrants.size():
			supply["hydrant"] = hydrants[told[2]]
			hydrants[told[2]]["rig"] = rigs[index]
		elif told[2] == -2:
			supply["hydrant"] = {"elsewhere": true}
		supply["donor"] = lines[told[3]] if (told[3] >= 0 and told[3] < lines.size()) else null
	divider["feed"] = lines[state["divider"][3]] if (state["divider"][3] >= 0 and state["divider"][3] < lines.size()) else null
	_refresh_divider()

	var hoses: Dictionary = state["hoses"]
	for key: String in _net_hoses.keys():
		if not hoses.has(key) or not is_instance_valid(_net_hoses[key]):
			if is_instance_valid(_net_hoses[key]):
				_net_hoses[key].queue_free()
			_net_hoses.erase(key)
	for key: String in hoses:
		var told: Array = hoses[key]
		var hose: HoseLine = _net_hoses.get(key)
		if hose != null and hose.get_meta("from") != told[0]:
			hose.queue_free()
			hose = null
		if hose == null:
			var from: = _end_node(told[0], null)
			if from == null:
				continue
			var passes: Array[RID] = []
			for rig: Dictionary in rigs:
				passes.append(rig["vehicle"].get_rid())
			for player in Game.players:
				passes.append(player.get_rid())
			if is_instance_valid(divider["body"]):
				passes.append(divider["body"].get_rid())
			hose = HoseLine.make(from, told[3], told[4], passes)
			hose.set_meta("from", told[0])
			_net_hoses[key] = hose
		if not hose.has_meta("to") or hose.get_meta("to") != told[1] or not is_instance_valid(hose.finish) or hose.finish.is_queued_for_deletion():
			var to: = _end_node(told[1], hose)
			if to == null:
				continue
			hose.set_meta("to", told[1])
			hose.set_end(to, told[2])
		if hose.points != told[5]:
			hose.points = told[5]
			hose.set_end(hose.finish, told[2])
		if not is_equal_approx(hose.width, float(told[3])):
			hose.width = float(told[3])
			hose.set_end(hose.finish, told[2])
		if told.size() > 6:
			hose.swell = float(told[6])



func _net_let_go(line: Dictionary) -> void :
	if line["player"] == null:
		return
	if is_instance_valid(line["player"]) and line["player"].is_local and line["player"].camera != null:
		line["player"].camera.sway = 0.0
	if is_instance_valid(line.get("nozzle")):
		line["nozzle"].queue_free()
	var jet: Variant = line.get("jet")
	if is_instance_valid(jet):
		jet.spraying = false
		get_tree().create_timer(3.0).timeout.connect(jet.queue_free)
	line["player"] = null
	line["nozzle"] = null
	line["jet"] = null
	line.erase("opened")



func _net_apply_divider(told: Array) -> void :
	var carrier: Player = Net.player_of(told[1]) if told[1] != 0 else null
	var moved: bool = told[0] == "placed" and divider["state"] == "placed" and not divider.get("place", Transform3D.IDENTITY).is_equal_approx(told[2])
	if told[0] != divider["state"] or carrier != divider["player"] or moved:
		_net_clear_divider()
		if told[0] == "carried" and carrier != null:
			var tool: = _divider_in_hand(carrier)
			divider["state"] = "carried"
			divider["player"] = carrier
			divider["tool"] = tool
			if carrier.is_local and ToolService.current:

				divider["entry"] = {
					"name": DIVIDER_TOOL, 
					"in_hand": func() -> bool: return is_instance_valid(tool) and tool.visible, 
					"set_in_hand": func(on: bool) -> void : Net.request("hose.divider.hand", [on]), 
				}
				ToolService.current.carry_other(carrier, divider["entry"])
		elif told[0] == "placed":
			_build_divider(told[2])
	if is_instance_valid(divider["tool"]):
		divider["tool"].visible = told[4]



func _net_clear_divider() -> void :
	for index in range(lines.size() - 1, -1, -1):
		if lines[index]["kind"] == "divider":
			_net_let_go(lines[index])
			lines.remove_at(index)
	if is_instance_valid(divider["model"]):
		divider["model"].queue_free()
	if is_instance_valid(divider["tool"]):
		divider["tool"].queue_free()
	if divider["entry"] != null and ToolService.current and is_instance_valid(divider["player"]):
		ToolService.current.drop_other(divider["player"], divider["entry"])
	for key: String in ["model", "body", "tool", "entry", "player", "inlet", "pickup", "feed"]:
		divider[key] = null
	divider["lines"] = []
	divider["state"] = "stowed"



func _net_monitors() -> Variant:
	var list: Array = []
	for monitor: Dictionary in monitors:
		var node: Variant = monitor["node"]
		list.append([monitor["spraying"], node.global_position if is_instance_valid(node) else Vector3.ZERO, monitor["aim"], float(monitor["speed"])])
	return list


func _net_apply_monitors(list: Variant) -> void :
	if not Net.is_client():
		return
	for index in list.size():
		var told: Array = list[index]
		if index < monitors.size():
			monitors[index]["spraying"] = told[0]
			monitors[index]["aim_told"] = told[2]
			continue

		var jet: WaterJet = _net_monitor_jets.get(index)
		if jet == null:
			jet = WaterJet.new()
			jet.speed = told[3]
			add_child(jet)
			_net_monitor_jets[index] = jet
		jet.spraying = told[0]
		jet.origin = told[1]
		jet.aim = told[2]



func _on_net_started() -> void :
	if not Net.is_client():
		return
	for line: Dictionary in lines.duplicate():
		disconnect_line(line)
		if line.get("feeding", false):
			_unfeed(line)
	for rig: Dictionary in rigs:
		stow_supply(rig)
	if divider["state"] != "stowed":
		_stow_divider()
	if Game.local_player != null:
		Game.local_player.set_attr("HoseRoll", null)
		Game.local_player.set_attr("HoseRollRig", null)
	_net_last = null



func _net_clear() -> void :
	for key: String in _net_hoses:
		if is_instance_valid(_net_hoses[key]):
			_net_hoses[key].queue_free()
	_net_hoses.clear()
	for index: int in _net_monitor_jets:
		_net_monitor_jets[index].queue_free()
	_net_monitor_jets.clear()
	if _net_last == null:
		return
	_net_last = null
	_net_clear_divider()
	for line: Dictionary in lines:
		_net_let_go(line)
		_clear_down(line)
		line["feeding"] = false
		line["relay"] = null
	for hydrant: Dictionary in hydrants:
		hydrant["rig"] = null
	for rig: Dictionary in rigs:
		var supply: Dictionary = rig["supply"]
		supply["state"] = "stowed"
		for key: String in ["player", "hydrant", "donor"]:
			supply[key] = null
	for monitor: Dictionary in monitors:
		monitor["spraying"] = false
		monitor.erase("aim_told")
	_refresh_divider()



func _on_peer_left(player: Player) -> void :
	if not Net.is_host():
		return
	var line: Variant = line_of(player)
	if line != null:
		disconnect_line(line)
		_refresh_divider()
	var carrying: Variant = supply_of(player)
	if carrying != null:
		stow_supply(carrying)
	if divider["state"] == "carried" and divider["player"] == player:
		_stow_divider()
	_return_roll(player)
