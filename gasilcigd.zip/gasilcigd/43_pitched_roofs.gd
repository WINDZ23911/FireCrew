extends RefCounted




const GUTTERS: = [Color8(214, 214, 210), Color8(122, 86, 60), Color8(84, 86, 90), Color8(150, 104, 70)]
const DARK: = Color8(58, 60, 64)
const OVERHANG: = 1.5
const SHARED: = 3.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("Roofs")
	var made: = store.count
	var houses: = 0
	var pipes: Array[Vector3] = []
	for shell: Dictionary in kit.get_meta("shells"):
		if not shell["pitched"]:
			continue
		houses += 1
		var rng: = kit.rng("pitched:%d" % shell["model"])
		var place: Transform3D = shell["place"]
		var color: Color = GUTTERS[rng.randi_range(0, GUTTERS.size() - 1)]
		var ground: = place.origin.y + 1.2
		for row: int in shell["slopes"]:
			var at: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			var length: = size.x
			var rise: = size.y
			var run: = size.z

			var along: = place.basis.inverse() * at.basis.x
			var walls: float = shell["width"] if absf(along.x) > 0.7 else shell["depth"]
			if shell["hipped"]:
				length += run * 2.0
			var side_overhang: = maxf((length - walls) / 2.0, 0.0)
			var eave_y: = - rise / 2.0

			kit.box(folder, at * Transform3D(Basis(), Vector3(0, eave_y - 0.15, - run / 2.0 - 0.2)), Vector3(length, 0.42, 0.5), color, "Metal", "Gutter")


			var ends: Array = [-1.0, 1.0]
			if side_overhang < 0.2 or walls < 26.0:
				ends = [-1.0 if rng.randf() < 0.5 else 1.0]
			var wall_z: = - run / 2.0 + OVERHANG - 0.32
			for side: float in ends:
				var x: = side * (walls / 2.0 - 0.7)
				var top: = at * Vector3(x, eave_y - 0.3, - run / 2.0 - 0.15)
				var bend: = at * Vector3(x, eave_y - 1.2, wall_z)
				var foot: = at * Vector3(x, 0, wall_z)
				foot.y = ground - 0.6

				if pipes.any( func(other: Vector3) -> bool: return Vector2(other.x - foot.x, other.z - foot.z).length() < SHARED):
					continue
				pipes.append(foot)
				kit.rod(folder, top, bend, 0.36, color, "Metal", "Downpipe")
				kit.rod(folder, bend, foot + Vector3(0, 0.6, 0), 0.4, color, "Metal", "Downpipe")
				var out: = (at.basis * Vector3(0, 0, -1)).normalized()
				kit.rod(folder, foot + Vector3(0, 0.75, 0), foot + Vector3(0, 0.25, 0) + out * 0.7, 0.4, color, "Metal", "DownpipeShoe")

				var high: = bend.y
				var steps: = int((high - foot.y) / 6.0)
				for i in range(1, steps + 1):
					var y: = foot.y + i * (high - foot.y) / (steps + 1)
					kit.box(folder, Transform3D(at.basis, Vector3(bend.x, y, bend.z)), Vector3(0.6, 0.15, 0.5), DARK, "Metal", "PipeClip")


		for row: int in shell["rows"].get("Chimney", []):
			if rng.randf() > 0.4:
				continue
			var chimney: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			var foot: = chimney * Vector3(size.x / 2.0 + 0.15, size.y / 2.0 - 2.5, 0)
			var tall: = rng.randf_range(5.0, 8.0)
			kit.post(folder, foot, tall, 0.18, DARK, "Metal", "AerialMast")
			var dir: = (chimney.basis * Vector3(0, 0, 1)).rotated(Vector3.UP, rng.randf_range(-0.7, 0.7))
			for i in 3:
				var y: = tall - 0.3 - i * 1.1
				var reach: = 1.9 - i * 0.35
				kit.rod(folder, foot + Vector3(0, y, 0) - dir * reach, foot + Vector3(0, y, 0) + dir * reach, 0.09, DARK, "Metal", "AerialArm")
			for i in 2:
				kit.box(folder, chimney * Transform3D(Basis(), Vector3(0, size.y / 2.0 - 1.6 - i * 1.0, 0)), Vector3(size.x + 0.12, 0.12, size.z + 0.12), DARK, "Metal", "AerialStrap")


		if not shell["hipped"] and rng.randf() < 0.22:
			var row: int = shell["slopes"][0]
			var at: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			var side: = -1.0 if rng.randf() < 0.5 else 1.0
			var along: = place.basis.inverse() * at.basis.x
			var walls: float = shell["width"] if absf(along.x) > 0.7 else shell["depth"]
			var gable_x: = walls / 2.0 + (size.x - walls) / 2.0 + 0.1
			if size.x - walls > 1.0:
				var mount: = at * Vector3(side * gable_x, - size.y / 2.0 + size.y * 0.3, - size.z * 0.15)
				var out: = (at.basis * Vector3(side, 0, 0)).normalized()
				var look: = (out + Vector3(0, 0.55, 0)).normalized()
				var middle: = mount + out * 0.9
				kit.rod(folder, mount, middle, 0.18, DARK, "Metal", "DishBracket")
				kit.rod(folder, middle - look * 0.1, middle + look * 0.1, 1.9, Color8(234, 234, 230), "SmoothPlastic", "Dish")
				kit.rod(folder, middle, middle + look * 1.1, 0.09, DARK, "Metal", "DishArm")
	return "%d sloping roofs guttered (%d parts)" % [houses, store.count - made]
