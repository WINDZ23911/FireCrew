extends ProofDebug














func _scenario_roadopen() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 0.0)
	if not _check( not held.is_empty(), "a crash came"):
		await _done()
		return
	var graph: = NavGraph.current
	var at: Vector3 = CarCrash.current.position
	var along: Vector3 = held["along"]
	await _wait(1.6)
	var closure: Dictionary = graph.closure
	print("roadopen: closure %s, %d bodies in the road" % [{"x": closure.get("x"), "radius": closure.get("radius"), "open": closure.get("open")}, closure.get("bodies", []).size()])
	_check(closure.get("open", false) and closure.get("bodies", []).size() >= 2, "the road is not closed for the crew: open to traffic, which stops short of the wrecks")
	var said: Variant = Game.incident.get("scene_next", Game.incident.get("next"))
	_check(said != null and Text.say(said, "en") == Text.say(Text.m("calls.crash.next.cones"), "en"), "the card asks for the road to be closed")

	if OS.get_cmdline_user_args().has("--traffic"):
		for look in 12:
			await _wait(2.5)
			var near: Array = []
			for car in Traffic.current.vehicles:
				var gap: = Vector2(car.x - at.x, car.z - at.z).length()
				if gap < 60.0:
					near.append("%.0f studs at %.1f (%s)" % [gap, car.v, car.waiting_for])
			print("roadopen: cars near %s" % [near])
		_view(at + along * 40.0 + Vector3(14, 22, 0), at)
		await _wait(0.4)
		await _snap("open")

	var truck: = Vehicle.named("Fire Truck")
	var near_end: = CallKit.ground_at(at - along * 22.0 + Vector3(0, 3, 0))
	Cordon.current.stand_cone_at(truck, Transform3D(Basis.IDENTITY, near_end))
	await _wait(1.0)
	_check(graph.closure.get("open", false), "a cone at one end is not enough: still open")

	_park(truck, at + along * 34.0, atan2(along.x, along.z))
	await _wait(2.0)
	var ends: = Cordon.road_ends(at, along, CarCrash.CONE_ROOM, float(Config.Incidents.Crash.Safety.Range))
	print("roadopen: ends closed %s; closure now %s" % [ends, {"radius": graph.closure.get("radius"), "open": graph.closure.get("open", false)}])
	_check(ends[0] and ends[1], "a cone at one end and the pumper in the road at the other close it")
	_check( not graph.closure.is_empty() and not graph.closure.get("open", false), "closed by the crew: the streets round it are closed to traffic")
	said = Game.incident.get("scene_next", Game.incident.get("next"))
	_check(said == null or Text.say(said, "en") != Text.say(Text.m("calls.crash.next.cones"), "en"), "the card moves on from closing the road")
	_view(at + along * 50.0 + Vector3(18, 26, 0), at)
	await _wait(0.5)
	await _snap("closed")

	_check(ScenePolice.KINDS.has("tree") and ScenePolice.KINDS.has("hazmat") and ScenePolice.KINDS.has("accident"), "police come to trees, leaks and workplace accidents as well (CA-02)")
	await _done()


func _scenario_cabin() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 1.0)
	var engine: Variant = held.get("engine") if not held.is_empty() else null
	if not _check(engine != null, "a wreck with a smoking engine"):
		await _done()
		return
	var at: Vector3 = engine["car"]["engine"].global_position
	var side: Vector3 = engine["car"]["place"].basis.x
	player.teleport(_ground(at + side * 12.0) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	engine["left"] = 0.3
	await _wait(1.2)
	_check(engine["state"] == "burning", "left alone, the engine catches")
	var trapped: Array = engine["trapped"]
	var pace: = 100.0 / float(Config.Incidents.Crash.TrappedTime)
	var fire: Dictionary = Config.Incidents.Crash.EngineFire
	_check( not trapped.is_empty() and is_equal_approx(trapped[0].drain, pace * float(fire["Drain"])), "while it burns the casualty in that car weakens Drain times as fast")
	var hurt_before: = Alarm.injuries

	engine["burnt"] = float(fire["CabinAfter"]) - 0.5
	await _wait(1.5)
	print("cabin: %s; flames %d; drain %.3f; injuries %.0f -> %.0f; checks %s" % [engine["state"], FireService.current.spots.size(), trapped[0].drain, hurt_before, Alarm.injuries, Alarm.checks])
	_check(engine["state"] == "cabin" and engine.get("cabin_flame") != null, "left burning, the fire reaches the cabin: a second flame")
	_check(is_equal_approx(trapped[0].drain, pace * float(fire["Drain"]) * float(fire["CabinDrain"])), "with the cabin alight the casualty weakens faster still")
	_check(Alarm.injuries - hurt_before >= float(fire["SafetyCost"]) - 0.01, "it costs the call's safety")
	_check(Alarm.checks.get("engine") == false, "and it is named on the report: engine fire not fought before the cabin")
	_view(at + side * 16.0 + Vector3(0, 7, 6), at)
	await _wait(0.6)
	await _snap("cabin")

	_take_tool("Extinguisher")
	for flame: String in ["flame", "cabin_flame"]:
		var spot: Dictionary = engine[flame]
		player.teleport(_ground(spot["position"] + side * 6.0) + Vector3(0, 0.3, 0))
		await _wait(0.3)
		_look_at(spot["position"])
		await get_tree().process_frame
		Input.action_press("fire")
		var sprayed: = 0.0
		while spot["burning"] and sprayed < 12.0:
			await _wait(0.1)
			sprayed += 0.1
		Input.action_release("fire")
		await _wait(0.4)
	_check(engine["state"] == "out", "both put out, the engine is out (%s)" % engine["state"])
	var report: = Alarm.debrief("crash", {"failed": false})
	var listed: Dictionary = {}
	for entry: Array in report["checks"]:
		listed[entry[0]] = entry[1]
	_check(listed.get("engine") == false, "the report still names the cabin fire")
	await _done()


func _start_tree(variant: String) -> Dictionary:
	Config.Incidents["Tree"]["Variant"] = variant
	var tree: = FallenTree.current
	CallService.current.run_call("tree", tree.run)
	var waited: = 0.0
	while tree.scene.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(0.5)
	return tree.scene


func _scenario_tension() -> void :
	await _wait(1.0)
	Config.Incidents["Tree"]["Tension"]["Chance"] = 1.0
	var held: = await _start_tree("plain")
	if not _check( not held.is_empty(), "a tree came down"):
		await _done()
		return
	var ring: Dictionary = {}
	for one: Dictionary in held["rings"]:
		if one.has("tension"):
			ring = one
	if not _check( not ring.is_empty(), "one of its rings is under tension"):
		await _done()
		return
	var side: Vector3 = FallenTree.cut_side(ring)
	var where: Vector3 = ring["position"]
	_take_tool("Chainsaw")
	await _wait(0.5)

	_stand_by(where, - side * 2.2)
	await _wait(0.3)
	await _hold("fire", float(Config.Tools.Chainsaw.CutTime) + 1.5)
	var share: float = ring["progress"] / float(Config.Tools.Chainsaw.CutTime)
	print("tension: from the wrong side %.0f %% through, bound %s, hint %s, done %s" % [share * 100.0, ring.get("bound", false), is_instance_valid(ring.get("hint")), ring["done"]])
	_check( not ring["done"] and ring.get("bound", false), "cut from the wrong side the bar is pinched and the cut stops")
	_check(is_instance_valid(ring.get("hint")), "after the pinch the ring shows which side to cut from")
	_check(Alarm.checks.get("tension") == false, "the report's tension check is failed")
	_view(where - side * 9.0 + Vector3(0, 6, 4), where)
	await _wait(0.3)
	await _snap("pinched")

	_stand_by(where, side * 2.2)
	await _wait(0.3)
	await _hold("fire", float(Config.Tools.Chainsaw.CutTime) + 0.8)
	_check(ring["done"], "from the side shown it goes through")
	await _done()


func _scenario_powerline() -> void :
	await _wait(1.0)
	Config.Incidents["Tree"]["Line"]["UtilityWait"] = [30, 30]
	var held: = await _start_tree("line")
	if not _check( not held.is_empty() and held.has("line"), "a tree came down on a power line"):
		await _done()
		return
	var tree: = FallenTree.current
	var said: Variant = Game.incident.get("scene_next", Game.incident.get("next"))
	_check(said != null and Text.say(said, "en") == Text.say(Text.m("calls.tree.next.utility"), "en"), "the card says to keep clear and call Elektro")
	var ring: Dictionary = held["rings"][0]
	var where: Vector3 = ring["position"]
	var side: = FallenTree.cut_side(ring)
	_take_tool("Chainsaw")
	await _wait(0.5)
	var hp: = player.health
	_stand_by(where, (side * 2.2) if not side.is_zero_approx() else Vector3(0.5, 0, 2.2))
	await _wait(0.3)
	await _hold("fire", 1.5)
	print("powerline: sawing by the live line: progress %.2f; %.0f m from the line; health %.0f -> %.0f" % [ring["progress"], tree.line_distance(player.root_position()) * float(Config.Hud.MetresPerStud), hp, player.health])
	_check(is_zero_approx(ring["progress"]), "no sawing near the live line")
	_check(Alarm.checks.get("line") == false, "coming near it fails the report's line check")
	_view(where + Vector3(26, 22, 26), where)
	await _wait(0.4)
	await _snap("live")

	var board: Prompt = held["line"]["prompts"][0]
	player.teleport(_ground(board.global_position + Vector3(2.5, 0, 0)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	_look_at(board.global_position)
	await _hold("interact", board.hold + 0.5)
	_check(float(held["line"]["isolate_at"]) > Game.now(), "Elektro called from the warning board")
	said = Game.incident.get("scene_next", Game.incident.get("next"))
	print("powerline: the card now: %s" % Text.say(said, "en"))
	_check(said != null and Text.say(said, "en").begins_with("Keep clear"), "the card counts down to the line being isolated")
	var sign: Label3D = held["line"]["boards"][0][1]
	var foot: Vector3 = board.get_parent().global_position
	var under: = _ground(foot)
	print("powerline: the board stands %.2f m off the ground; it says: %s" % [foot.y - under.y, sign.text])
	_check(absf(foot.y - under.y) < 0.5, "the board stands on the ground")
	_check(sign.text != Text.say(Text.m("calls.tree.line.sign")), "the board counts down to Elektro switching the line off")
	_view(foot + Vector3(9, 4, 9), foot + Vector3(0, 3, 0))
	await _wait(0.4)
	await _snap("called")
	held["line"]["isolate_at"] = Game.now() + 0.5
	await _wait(1.2)
	_check( not tree.line_live(), "a while later the line is dead")
	_check(sign.text == Text.say(Text.m("calls.tree.line.signDead")), "the board says the line is switched off")
	await _snap("dead")
	_stand_by(where, (side * 2.2) if not side.is_zero_approx() else Vector3(0.5, 0, 2.2))
	await _wait(0.3)
	await _hold("fire", float(Config.Tools.Chainsaw.CutTime) + 0.8)
	_check(ring["done"], "with the line dead the saw cuts")
	await _done()




func _scenario_roadkit() -> void :
	await _wait(1.0)
	var truck: = Vehicle.named("Fire Truck")
	var lockers: = Lockers.of(truck)
	var cones: Dictionary = truck.spec["cones"]
	for handle: Dictionary in lockers.handles:
		if cones["locker"] in handle.get("shutters", handle.get("names", [])):
			lockers.set_open(handle, true)
	for handle: Dictionary in lockers.handles:
		lockers.set_open(handle, true)
	await _wait(2.0)
	var listed: Array = []
	for line in lockers.lines:
		if line.locker == cones["locker"]:
			listed.append(Text.say(line.object, "en"))
	print("roadkit: the %s locker's lines: %s" % [cones["locker"], listed])
	_check(listed.has("Step blocks") and listed.has("First aid kit") and listed.has("Spinal board"), "the rescue kit is in the pumper's rear locker, by the cones")
	var back: = truck.global_transform * Vector3(0, 3.0, 22.0)
	_view(back + Vector3(0, 2, 0), truck.global_transform * Vector3(0, 2.6, 12.0), 50.0)
	await _wait(0.5)
	await _snap("locker")
	for kit: String in ["Step blocks", "First aid kit", "Spinal board"]:
		_take_kit(kit)
		await _wait(0.4)
		var item: Variant = Cordon.current.held(player)
		if item != null and item["name"] != kit:
			Cordon.current._set_in_hand(item, false)
		for other: Dictionary in Cordon.current.items:
			if other["name"] == kit and other["holder"] == player:
				Cordon.current._set_in_hand(other, true)
		await _wait(0.3)
		var at: = player.root_position()
		var face: = player.facing()
		var right: = face.cross(Vector3.UP).normalized()
		_view(at + right * 7.0 + face * 3.0 + Vector3(0, 2.5, 0), at + Vector3(0, 0.5, 0), 50.0)
		await _wait(0.4)
		await _snap("hand_" + kit.replace(" ", "_").to_lower())
	await _done()


func _scenario_treecar() -> void :
	await _wait(1.0)
	var held: = await _start_tree("car")
	var crash: Variant = held.get("crash") if not held.is_empty() else null
	if not _check(crash is Dictionary and not crash["doors"].is_empty(), "a tree came down on a car with its driver in it"):
		await _done()
		return
	var door: Dictionary = crash["doors"][0]
	var victim: Victim = door["victim"]
	await _wait(1.0)
	var pace: = 100.0 / float(Config.Incidents.Crash.TrappedTime)
	_check(victim.state == "trapped" and is_equal_approx(victim.drain, pace), "the driver weakens at the trapped pace (tended by the tree's call)")
	_check(door["prompt"] != null and not door["prompt"].enabled, "the door's kit prompt waits for the door to come off")

	door["stage"] = 3
	CarCrash.current._show_job(door)
	await _wait(0.6)
	_check(door["prompt"].enabled and is_equal_approx(victim.drain, pace * float(Config.Incidents.Crash.FreedDrain)), "with the door off: first aid offered, the driver still weakening")
	var out: Vector3 = door["car"]["place"].basis.x * door["outward"]
	_take_kit("First aid kit")
	_check( await _hold_prompt(door["prompt"], out * 3.0, func() -> bool: return door["stage"] == 4), "first aid at the car under the tree")
	_take_kit("Spinal board")
	_check( await _hold_prompt(door["prompt"], out * 3.0, func() -> bool: return door["stage"] == 5 and victim.state == "lying"), "the driver boarded and free to be carried")
	await _done()


func _scenario_treelook() -> void :
	await _wait(1.0)
	var held: = await _start_tree("conifer")
	if not _check( not held.is_empty(), "a conifer came down"):
		await _done()
		return
	var tree: Dictionary = held["trees"][0]
	var model: Node3D = tree["model"]
	var cones: = model.find_children("NeedleCone*", "MeshInstance3D", true, false).filter( func(made: MeshInstance3D) -> bool: return made.mesh is CylinderMesh)
	print("treelook: %d cones of needles, %d pieces in the model; %s" % [cones.size(), model.find_children("*", "MeshInstance3D", true, false).size(), model.find_children("*Needles*", "", true, false).map( func(n: Node) -> String: return "%s:%s" % [n.name, n.get_class()])])
	_check(cones.size() >= 4, "the conifer's needles are cones along the trunk")
	var foot: Vector3 = tree["candidate"]["position"]
	var middle: Vector3 = tree["middle"]
	var toward: Vector3 = tree["candidate"]["toward"]
	_view(middle - toward * 10.0 + toward.cross(Vector3.UP) * 34.0 + Vector3(0, 30, 0), middle)
	await _wait(7.0)
	await _snap("conifer")
	_view(foot + toward.cross(Vector3.UP) * 7.0 - toward * 3.0 + Vector3(0, 5, 0), foot + Vector3(0, 1.5, 0))
	await _wait(0.5)
	await _snap("stump")
	await _done()
