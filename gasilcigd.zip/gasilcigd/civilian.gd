class_name Civilian
extends RefCounted






const SHEET: = "civil"
const SKIN: = Color(0.87, 0.68, 0.55)
const SHIRT: = Color(0.16, 0.2, 0.34)
const TROUSERS: = Color(0.2, 0.21, 0.24)
const BOOTS: = Color(0.08, 0.08, 0.09)
const HAIR: = Color(0.24, 0.17, 0.12)
const POLICE_SHEET: = "police"
const GLOVE: = Color(0.05, 0.05, 0.06)

const PARTS: = {
	"UpperTorso": [Vector3(2.0, 1.65, 1.02), SHIRT], 
	"LowerTorso": [Vector3(1.96, 0.5, 1.0), TROUSERS], 
	"UpperArm": [Vector3(0.92, 1.25, 0.92), SHIRT], 
	"LowerArm": [Vector3(0.82, 1.05, 0.82), SKIN], 
	"Hand": [Vector3(0.8, 0.36, 0.8), SKIN], 
	"UpperLeg": [Vector3(0.96, 1.3, 0.96), TROUSERS], 
	"LowerLeg": [Vector3(0.9, 1.3, 0.9), TROUSERS], 
	"Foot": [Vector3(0.94, 0.34, 1.2), BOOTS], 
}



static func build(rig: FirefighterRig) -> void :
	if rig.pieces.has(SHEET):
		return
	var made: Array = []
	var body: Dictionary = Config.Gear.Body
	var dress: = Edition.look("uniform")
	var swap: = {SHIRT: Edition.color(dress, "shirt", SHIRT), TROUSERS: Edition.color(dress, "trousers", TROUSERS), 
		BOOTS: Edition.color(dress, "boots", BOOTS)}
	for part: String in PARTS:
		var centre: Array = body[part]
		var sided: bool = float(centre[0]) != 0.0
		for side: String in (["Left", "Right"] if sided else [""]):
			var x: float = float(centre[0]) * (-1.0 if side == "Left" else 1.0)
			var at: = Vector3(x, float(centre[1]), 0.12 if part == "Foot" else 0.0) * Vector3(1, 1, -1)
			var block: = _block(rig, side + part, at, PARTS[part][0], swap.get(PARTS[part][1], PARTS[part][1]))
			made.append(block)
			if part == "UpperTorso" and not dress.is_empty():
				_shirt_print(block, dress)

	made.append(_block(rig, "Head", Vector3.ZERO, Vector3(1.2, 1.2, 1.2), SKIN))
	made.append(_block(rig, "Head", Vector3(0, 0.5, 0.06), Vector3(1.28, 0.36, 1.26), HAIR))
	made.append(_block(rig, "Head", Vector3(0, 0.1, 0.5), Vector3(1.28, 0.6, 0.3), HAIR))
	for side: float in [-1.0, 1.0]:
		made.append(_block(rig, "Head", Vector3(side * 0.26, 0.08, -0.6), Vector3(0.16, 0.2, 0.04), Color(0.1, 0.1, 0.12)))
	made.append(_block(rig, "Head", Vector3(0, -0.3, -0.6), Vector3(0.4, 0.07, 0.04), Color(0.55, 0.3, 0.27)))
	rig.pieces[SHEET] = made




static func _shirt_print(chest: MeshInstance3D, dress: Dictionary) -> void :
	var ink: = Edition.color(dress, "emblem", Color.WHITE)
	var front: float = - (PARTS["UpperTorso"][0] as Vector3).z / 2.0
	var over_heart: = String(dress.get("chest", ""))
	if over_heart.is_empty():
		var cross: = maltese(0.17, ink)
		chest.add_child(cross)
		cross.position = Vector3(-0.48, 0.38, front - 0.006)
	else:
		var small: = _word(over_heart, ink, 52, 0.0017)
		chest.add_child(small)
		small.position = Vector3(-0.48, 0.38, front - 0.006)
		small.rotation.y = PI
	var word: = String(dress.get("back", ""))
	if not word.is_empty():
		var label: = _word(word, ink, 52, 0.0042)
		chest.add_child(label)
		label.position = Vector3(0, 0.36, - front + 0.006)




static func maltese(radius: float, color: Color) -> MeshInstance3D:
	var points: = PackedVector3Array()
	for arm in 4:
		var turn: = arm * PI / 2.0
		var outer: Array[Vector3] = []
		for corner: Vector2 in [Vector2(-0.46, 1.0), Vector2(0.0, 0.66), Vector2(0.46, 1.0)]:
			var p: = corner.rotated(turn) * radius
			outer.append(Vector3(p.x, p.y, 0))
		points.append_array([Vector3.ZERO, outer[0], outer[1], Vector3.ZERO, outer[1], outer[2]])
	var normals: = PackedVector3Array()
	normals.resize(points.size())
	normals.fill(Vector3(0, 0, -1))
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = points
	arrays[Mesh.ARRAY_NORMAL] = normals
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var look: = StandardMaterial3D.new()
	look.albedo_color = color
	look.roughness = 0.8
	look.cull_mode = BaseMaterial3D.CULL_DISABLED
	var cross: = MeshInstance3D.new()
	cross.name = "Cross"
	cross.mesh = mesh
	cross.material_override = look
	cross.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return cross


static func _word(text: String, color: Color, size: int, pixel: float) -> Label3D:
	var word: = Label3D.new()
	word.text = text
	word.font_size = size
	word.pixel_size = pixel
	word.modulate = color
	word.outline_size = 0
	word.double_sided = false
	word.shaded = true
	return word










const POLICE_JACKET: = Color8(28, 37, 64)
const POLICE_SHIRT: = Color8(150, 186, 222)
const POLICE_TROUSERS: = Color8(58, 61, 66)
const POLICE_GOLD: = Color8(206, 168, 72)
const POLICE_SKINS: = [0, 1, 3, 4]


static func build_police(rig: FirefighterRig) -> void :
	if rig.pieces.has(POLICE_SHEET):
		return
	var made: Array = []
	var body: Dictionary = Config.Gear.Body
	var theirs: = Edition.look("police")
	var jacket: = Edition.color(theirs, "shirt", POLICE_JACKET)
	var trousers: = Edition.color(theirs, "trousers", POLICE_TROUSERS)
	var colours: = {"UpperTorso": jacket, "LowerTorso": trousers, "UpperArm": jacket, "LowerArm": POLICE_JACKET if theirs.is_empty() else SKIN, 
		"Hand": GLOVE if theirs.is_empty() else SKIN, "UpperLeg": trousers, "LowerLeg": trousers, "Foot": BOOTS}
	for part: String in PARTS:
		var centre: Array = body[part]
		var sided: bool = float(centre[0]) != 0.0
		for side: String in (["Left", "Right"] if sided else [""]):
			var x: float = float(centre[0]) * (-1.0 if side == "Left" else 1.0)
			var at: = Vector3(x, float(centre[1]), 0.12 if part == "Foot" else 0.0) * Vector3(1, 1, -1)
			made.append(_block(rig, side + part, at, PARTS[part][0], colours[part]))
	var chest: Array = body["UpperTorso"]
	if theirs.is_empty():
		_police_marks_metlika(rig, made, chest)
	else:
		_police_marks(rig, made, theirs, chest)

	var tone: = 0
	for key: String in rig.outfit:
		if key.begins_with("face"):
			tone = int(key.substr(4))
	var skin: Color = Figure.SKIN[POLICE_SKINS[clampi(tone, 0, POLICE_SKINS.size() - 1)]]
	var head: = MeshInstance3D.new()
	head.name = "Head_civil"
	head.mesh = Figure.mesh_of(Figure.HEAD)
	head.material_override = Figure.material(skin, true)
	head.set_instance_shader_parameter("face_style", float((tone * 7 + 3) % 16))
	rig.joints["Neck"].add_child(head, true)
	head.position = - FirefighterRig.JOINTS["Neck"]
	head.visible = false
	made.append(head)
	var cap: = Edition.color(theirs, "cap", POLICE_JACKET)
	made.append(_block(rig, "Head", Vector3(0, 0.58, 0.04), Vector3(1.36, 0.36, 1.36), cap))
	made.append(_block(rig, "Head", Vector3(0, 0.44, 0.0), Vector3(1.4, 0.12, 1.4), cap.darkened(0.25)))
	made.append(_block(rig, "Head", Vector3(0, 0.38, -0.8), Vector3(1.0, 0.08, 0.45), Color(0.04, 0.04, 0.05)))
	if not theirs.is_empty():

		made.append(_block(rig, "Head", Vector3(0, 0.6, -0.69), Vector3(0.2, 0.22, 0.03), Edition.color(theirs, "badge", Color.SILVER)))
	rig.pieces[POLICE_SHEET] = made




static func _police_marks_metlika(rig: FirefighterRig, made: Array, chest: Array) -> void :
	var top: = float(chest[1]) + 0.82
	made.append(_block(rig, "UpperTorso", Vector3(0, top - 0.08, -0.32), Vector3(0.9, 0.2, 0.42), POLICE_SHIRT))
	made.append(_block(rig, "UpperTorso", Vector3(0, top - 0.3, -0.5), Vector3(0.3, 0.45, 0.04), POLICE_SHIRT))
	var patch: = _block(rig, "UpperTorso", Vector3(-0.52, float(chest[1]) + 0.32, -0.52), Vector3(0.62, 0.2, 0.03), POLICE_GOLD)
	made.append(patch)
	var word: = _word("POLICIJA", POLICE_JACKET, 36, 0.0022)
	word.position = Vector3(0, 0, -0.017)
	word.rotation.y = PI
	patch.add_child(word)




static func _police_marks(rig: FirefighterRig, made: Array, theirs: Dictionary, chest: Array) -> void :
	var silver: = Edition.color(theirs, "badge", Color.SILVER)
	var shirt: = Edition.color(theirs, "shirt", POLICE_JACKET)
	var y: = float(chest[1])
	var front: = -0.515
	made.append(_block(rig, "UpperTorso", Vector3(-0.5, y + 0.36, front), Vector3(0.24, 0.3, 0.035), silver))
	made.append(_block(rig, "UpperTorso", Vector3(-0.5, y + 0.34, front - 0.02), Vector3(0.09, 0.09, 0.02), silver.darkened(0.35)))
	made.append(_block(rig, "UpperTorso", Vector3(0.5, y + 0.3, front), Vector3(0.36, 0.08, 0.03), silver))
	for side: float in [-1.0, 1.0]:
		made.append(_block(rig, "UpperTorso", Vector3(side * 0.5, y + 0.12, front - 0.004), Vector3(0.44, 0.1, 0.03), shirt.darkened(0.3)))
	var lower: Array = Config.Gear.Body["LowerTorso"]
	made.append(_block(rig, "LowerTorso", Vector3(0, float(lower[1]) + 0.12, 0), Vector3(2.04, 0.22, 1.06), Color(0.05, 0.05, 0.055)))
	made.append(_block(rig, "LowerTorso", Vector3(0, float(lower[1]) + 0.12, -0.535), Vector3(0.2, 0.15, 0.02), silver))
	var arm: Array = Config.Gear.Body["UpperArm"]
	for side: String in ["Left", "Right"]:
		var sign: = -1.0 if side == "Left" else 1.0
		var outside: = float(arm[0]) * sign + sign * 0.465
		made.append(_block(rig, side + "UpperArm", Vector3(outside, float(arm[1]) + 0.28, 0), Vector3(0.025, 0.36, 0.32), Edition.color(theirs, "patch", POLICE_GOLD)))
		made.append(_block(rig, side + "UpperArm", Vector3(outside + sign * 0.006, float(arm[1]) + 0.28, 0), Vector3(0.02, 0.28, 0.24), Edition.color(theirs, "patch_field", POLICE_JACKET)))
	var word: = String(theirs.get("word", ""))
	if not word.is_empty():
		var label: = _word(word, Edition.color(theirs, "word_color", Color.WHITE), 64, 0.0052)
		var back: = _block(rig, "UpperTorso", Vector3(0, y + 0.3, 0.505), Vector3(0.05, 0.05, 0.01), shirt)
		back.add_child(label)
		label.position = Vector3(0, 0, 0.012)
		made.append(back)


static func _block(rig: FirefighterRig, part: String, centre: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var joint_name: String = FirefighterRig.CARRIED_BY[part]
	var mesh: = MeshInstance3D.new()
	mesh.name = part + "_civil"
	var box: = BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var material: = StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.85
	mesh.material_override = material
	rig.joints[joint_name].add_child(mesh, true)
	mesh.position = centre - FirefighterRig.JOINTS[joint_name]
	mesh.visible = false
	return mesh
