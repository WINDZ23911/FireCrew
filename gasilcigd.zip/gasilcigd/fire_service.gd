class_name FireService
extends Node



















const TICK: = 0.25
const STOREY: = 7.0
const CHAR_STEPS: = 5
const BOTTLES: = "Gas bottles"
const SPOT_GROW: = 60.0
const SPOT_FULL: = 0.5

const GAS_ORIGINS: = ["Pan on the cooker", "Fryer", "Oven", "Boiler"]
const LIVE_ORIGINS: = ["Television", "Washing machine", "Coffee machine", "Chiller", "Cash machine", "Bottling line", 
	"Battery charger", "Compressor", "CNC machine", "Saw line", "Planer"]


const STIRRED: = {"Dust extractor": "dust", "Paint store": "solvent"}
const DUST_BLAST: = {"Radius": 12.0, "Damage": 35.0, "Every": 8.0}
const SCORCH_TIME: = 90.0
const UNDER_SMOKE: = 0.3
const BOX_HOUSE_REACH: = 20.0
const WARN_HEAT: = 0.45
const COOLING_WATER: = 1.5

static var current: FireService

var kind: = "fire"

var buildings: Array[Building] = []
var incident: Dictionary = {}
var spots: Array = []


var hazards: Array = []
var _groups: Dictionary = {}
var _spots_made: = 0
var _runs: = 0

var _net_shown: Dictionary = {}
var _net_embers: Dictionary = {}
var _warm_shown: Dictionary = {}
var _net_building: = -1
var _net_touched: Dictionary = {}
var _net_fresh: = false


func _init() -> void :
	current = self


func _ready() -> void :


	Net.share("fire.flames", _net_flames, _net_apply_flames, 10.0)
	Net.share("fire.buildings", _net_buildings, _net_apply_buildings, 4.0)
	Net.share("call.markers", CallMarker.net_state, CallMarker.net_apply, 4.0)
	Net.handle("fire.steam", _show_steam)
	Net.handle("fire.flash", func(index: int, room_name: String) -> void :
		if index >= 0 and index < House.all.size():
			_show_flash(House.all[index], room_name))
	Net.handle("fx.blast", Blast.show)
	Net.handle("house.fx", House.net_fx)
	Net.handle("fire.evacuate", Escalation.sound_evacuation)
	Net.handle("fire.collapse", func(index: int, on: bool) -> void :
		if index >= 0 and index < buildings.size():
			buildings[index].show_collapse(on))
	Net.started.connect(_on_net_started)
	Net.stopped.connect(_on_net_stopped)
	if OS.get_cmdline_user_args().has("--crew-debug"):
		var debug: Node = load("res://scripts/fire/crew_debug.gd").new()
		debug.name = "CrewDebug"
		add_child.call_deferred(debug)


func settings() -> Dictionary:
	return Config.Fire







func _passage(building: Building, a: Variant, b: Variant, vertical: bool) -> float:
	var s: = settings()
	if a == b and not vertical:
		return 1.0
	var best: float = s["FloorCoupling"] if vertical else 0.0
	for opening: Dictionary in building.openings:
		if (opening["a"] == a and opening["b"] == b) or (opening["a"] == b and opening["b"] == a):
			var open: float = s["StairCoupling"] if vertical else s["OpenCoupling"]
			best = maxf(best, open if opening["passes"].call() else s["ClosedCoupling"])
	return best




func _group_of(building: Building) -> Dictionary:
	if _groups.has(building):
		return _groups[building]
	var reach: float = building.reach if building.reach > 0.0 else float(settings()["SpreadRadius"])
	var fuel: = building.fuel
	if fuel.is_empty():
		reach = BOX_HOUSE_REACH
		fuel = []
		for at: Vector3 in building.spots:
			fuel.append({"name": "Wall", "position": at, "kind": "wood"})
	var nodes: Array = []
	for entry: Dictionary in fuel:
		nodes.append({
			"name": entry["name"], 
			"position": entry["position"], 

			"kind": "cylinder" if entry["name"] == BOTTLES else entry["kind"], 
			"material": settings()["Materials"]["cylinder" if entry["name"] == BOTTLES else entry["kind"]], 
			"room": entry.get("room"), 
			"parts": entry.get("parts", []), 
			"lit": entry.get("lit"), 
			"burnt": entry.get("burnt"), 
			"links": [], 
			"burning": false, 
			"index": nodes.size(), 
		})
	for a: Dictionary in nodes:
		for b: Dictionary in nodes:
			if is_same(a, b):
				continue
			var offset: Vector3 = b["position"] - a["position"]
			var level: = Vector2(offset.x, offset.z).length()
			var rise: = absf(offset.y)
			if level <= reach and rise < STOREY * 2.5:
				a["links"].append({"node": b, "nearness": maxf(1.0 - level / reach, 0.15), "vertical": rise > STOREY})
	var group: = {"building": building, "nodes": nodes}
	_groups[building] = group
	return group



func _reset_group(group: Dictionary) -> void :
	for node: Dictionary in group["nodes"]:
		node["fuel"] = float(node["material"]["burn"])
		node["heat"] = 0.0
		node["wet_until"] = 0.0
		node["burning"] = false
		node["shade"] = 0
		node["cooked"] = 0.0
		node["warned"] = false
		node["warmed"] = 0.0



func _char(group: Dictionary, node: Dictionary) -> void :
	var shade: = int(floor((1.0 - node["fuel"] / float(node["material"]["burn"])) * CHAR_STEPS + 0.5))
	if shade == node["shade"]:
		return
	node["shade"] = shade
	var building: Building = group["building"]
	if building.node_shades.size() != group["nodes"].size():
		building.node_shades.resize(group["nodes"].size())
	building.node_shades[node["index"]] = shade
	for part in node["parts"]:
		building.shade(int(part), 0.9 * shade / CHAR_STEPS)







const RADIO_KINDS: = {
	"Car fire": "fire_vehicle", "Vehicle fire": "fire_vehicle", "Tractor fire": "fire_vehicle", 
	"Bench fire": "fire_open", "Bin fire": "fire_open", "Container fire": "fire_open", "Fence fire": "fire_open", 
	"Hedge fire": "fire_open", "Woodpile fire": "fire_open", 
}


func _publish() -> void :
	_show_warming(_warming())
	if incident.is_empty():
		Game.set_incident({})
		return
	var building: Building = incident["group"]["building"]
	var shown: = {
		"kind": "fire", 
		"name": incident.get("title", ""), 
		"health": maxf(incident["health"], 0.0), 
		"pos": building.position, 
		"flames": incident["count"], 
		"flames_out": incident["out"], 
	}
	if building.approach != null:
		shown["approach"] = building.approach
	if incident.get("ladder", false):
		shown["ladder"] = true
	if RADIO_KINDS.has(incident.get("scenario_name", "")):
		shown["radio"] = RADIO_KINDS[incident["scenario_name"]]
	shown.merge(Victims.shown())
	shown.merge(Escalation.shown)
	var next: Variant = _next_step()
	if next != null:
		shown["next"] = next
	Game.set_incident(shown)





func _next_step() -> Variant:
	if incident.get("automatic", false) and not incident.get("panel_read", false):
		return Text.m("calls.fire.next.panel")
	var embers: Array = incident.get("embers", [])
	if not embers.is_empty():
		return Text.f("calls.fire.next.embers", [embers.size()])
	var nodes: Array = incident["group"]["nodes"]
	for node: Dictionary in nodes:
		if node["burning"] and node["name"] == BOTTLES:
			return Text.m("calls.fire.next.bottles")
	if incident.get("fed") != null:
		return Text.m("calls.fire.next.gas")
	if incident.get("live") != null:
		return Text.m("calls.fire.next.power")

	var people: Variant = Victims.next_words()
	if people != null:
		return people
	if incident.get("ladder", false) and int(incident["count"]) > 0 and not _ladder_there():
		return Text.m("calls.fire.next.ladder")
	if int(incident["count"]) > 0:

		var door: Variant = _door_to_shut()
		if door != null:
			return Text.f("calls.fire.next.flamesShut", [int(incident["count"]), Text.named("calls.doors", door["info"]["label"])])
		return Text.f("calls.fire.next.flames", [int(incident["count"])]) if _warm_shown.is_empty() else Text.f("calls.fire.next.flamesWarm", [int(incident["count"])])
	return null



func _ladder_there() -> bool:
	var ladder: = LadderService.current
	if ladder == null or not is_instance_valid(ladder.vehicle):
		return false
	var at: = ladder.vehicle.global_position
	var building: Building = incident["group"]["building"]
	return Vector2(at.x - building.position.x, at.z - building.position.z).length() < ladder.max_outreach() + 25.0



func _door_to_shut() -> Variant:
	var building: Building = incident["group"]["building"]
	if not building.has_rooms():
		return null
	var burning: = {}
	for node: Dictionary in incident["group"]["nodes"]:
		if node["burning"] and node["room"] != null:
			burning[node["room"]] = true
	for opening: Dictionary in building.openings:
		var door: Variant = opening.get("door")
		if not door is Dictionary or not door["open"] or door["burnt"] or door["moving"]:
			continue
		var a_burns: bool = burning.has(opening["a"])
		var b_burns: bool = burning.has(opening["b"])
		if a_burns == b_burns:
			continue

		var also_open: = false
		for other: Dictionary in building.openings:
			if not is_same(other, opening) and other["passes"].call() and not (other.get("door") is Dictionary and is_same(other["door"], door))\
			and ((other["a"] == opening["a"] and other["b"] == opening["b"]) or (other["a"] == opening["b"] and other["b"] == opening["a"])):
				also_open = true
		if not also_open:
			return door
	return null



func _warming() -> Dictionary:
	var found: = {}
	if incident.is_empty():
		return found
	var nodes: Array = incident["group"]["nodes"]
	for at in nodes.size():
		var node: Dictionary = nodes[at]
		if not node["burning"] and float(node["heat"]) >= WARN_HEAT and float(node["fuel"]) > 0.0:
			found[at] = [node["position"], float(node["heat"])]
	return found



func _show_warming(found: Dictionary) -> void :
	for key: int in _warm_shown.keys():
		if not found.has(key):
			if is_instance_valid(_warm_shown[key]):
				_warm_shown[key].queue_free()
			_warm_shown.erase(key)
	for key: int in found:
		var marker: Warming = _warm_shown.get(key)
		if marker == null or not is_instance_valid(marker):
			marker = Warming.new()
			add_child(marker)
			_warm_shown[key] = marker
		marker.global_position = found[key][0]
		marker.heat = found[key][1]



func _max_health(node: Dictionary) -> float:
	var s: = settings()
	return float(s["NewHealth"]) + (float(s["FullHealth"]) - float(s["NewHealth"])) * node["intensity"]



func _progress(node: Dictionary) -> float:
	return clampf(node["damage"] / _max_health(node), 0.0, 1.0)




func _heat_of(node: Dictionary) -> float:
	return float(node["intensity"]) * (1.0 - float(settings()["KnockdownHeat"]) * _progress(node))







func _flame_cap() -> int:
	return _base_cap() + int(incident.get("cap_extra", 0.0))


func _base_cap() -> int:
	var crews: Array = settings()["Crew"]
	return int(crews[clampi(Alarm.crew(), 1, crews.size()) - 1]["flames"])





func _light_event(lit: Array, intensity: float) -> void :
	var room: = maxi(0, _base_cap() + int(settings()["EventOver"]) - int(incident["count"]))
	lit.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return float(a["heat"]) > float(b["heat"]))
	for node: Dictionary in lit:
		if room > 0:
			room -= 1
			node["wet_until"] = 0.0
			_ignite(node, intensity)
		else:
			node["heat"] = maxf(float(node["heat"]), float(settings()["HeatClamp"]))
	incident["cap_extra"] = maxf(float(incident.get("cap_extra", 0.0)), float(int(incident["count"]) - _base_cap()))


func _show(node: Dictionary) -> void :
	var flame: Flame = node["flame"]
	flame.intensity = node["intensity"]
	flame.progress = _progress(node)


func _make_flame(at: Vector3) -> Flame:
	var flame: = Flame.new()
	add_child(flame)
	flame.global_position = at
	return flame


func _ignite(node: Dictionary, intensity: float) -> void :
	if not node.get("reachable", true):
		return
	node["flame"] = _make_flame(node["position"])
	node["burning"] = true
	node["intensity"] = intensity
	node["damage"] = 0.0
	node["last_sprayed"] = 0.0
	node["heat"] = 0.0
	_show(node)
	incident["count"] += 1
	if node["room"] != null and incident.has("rooms_lit"):
		incident["rooms_lit"][node["room"]] = true
	if node["lit"] is Callable:
		node["lit"].call()



func _douse(node: Dictionary) -> void :
	if is_instance_valid(node.get("flame")):
		node["flame"].queue_free()
	node["flame"] = null
	node["burning"] = false
	incident["count"] -= 1



func steam_puff(at: Vector3) -> void :
	_show_steam(at)
	Net.broadcast("fire.steam", [at])


func _show_steam(at: Vector3) -> void :
	Smoulder.at(at)



func _show_flash(building: Building, room_name: String) -> void :
	if building is House and (building as House).rooms.has(room_name):
		(building as House).show_flash(room_name)



func _extinguish(node: Dictionary, player: Player) -> void :
	steam_puff(node["position"])
	_douse(node)
	node["wet_until"] = Game.now() + float(settings()["WetTime"])
	incident["out"] += 1
	if player:
		Alarm.note(player, "flames")


		var paid: Dictionary = incident.get("paid", {})
		if not paid.has(node["index"]):
			paid[node["index"]] = true
			incident["paid"] = paid
			player.add_cash(int(Config.Rewards.PerNode), "flameOut")




func _burst(group: Dictionary, node: Dictionary) -> void :
	var s: Dictionary = settings()["Bottles"]
	var at: Vector3 = node["position"]
	Blast.at(at, float(s["Radius"]), float(s["Volume"]))
	node["fuel"] = 0.0
	_char(group, node)
	_douse(node)
	if node["burnt"] is Callable:
		node["burnt"].call()
	for player in Game.players:
		var distance: = player.root_position().distance_to(at)
		if distance < float(s["Radius"]):

			player.take_damage(float(s["Damage"]) * (1.0 - distance / float(s["Radius"])) * (1.0 - 0.5 * player.heat_protection()))
	var building: Building = group["building"]
	for room_name: String in building.rooms:
		for pane: Dictionary in building.rooms[room_name]["panes"]:
			var offset: Vector3 = pane["position"] - at
			if offset.length() < float(s["Radius"]):
				pane["shatter"].call(offset.normalized())
	var near: Array = []
	for other: Dictionary in group["nodes"]:
		if not other["burning"] and other["fuel"] > 0.0 and other["position"].distance_to(at) <= float(s["Ignite"]):
			near.append(other)
	_light_event(near, float(s["Intensity"]))
	Game.notify(Text.m("calls.fire.bottlesBurst"), "danger")



func _burn(dt: float) -> void :
	var s: = settings()
	var group: Dictionary = incident["group"]
	var now: = Game.now()

	var crews: Array = s["Crew"]
	var crew: Dictionary = crews[clampi(Alarm.crew(), 1, crews.size()) - 1]
	var regrow_delay: float = s["RegrowDelay"]

	var building: Building = group["building"]
	var ways: = _air_ways(building)
	incident["ways"] = ways
	var fed: = {}
	for room_name: String in ways:
		fed[room_name] = _fed(room_name, int(ways[room_name]), now)

	for node: Dictionary in group["nodes"]:
		if node["burning"] and node["name"] == BOTTLES:

			var bottles: Dictionary = s["Bottles"]
			if now - node["last_sprayed"] <= regrow_delay:
				node["cooked"] = maxf(0.0, node["cooked"] - float(bottles["Cooling"]) * dt)
			else:
				node["cooked"] += (0.3 + 0.7 * node["intensity"]) * dt
			if node["cooked"] >= float(bottles["WarnAfter"]) and not node["warned"]:
				node["warned"] = true
				Game.notify(Text.m("calls.fire.bottlesSoon"), "danger")
			if node["cooked"] >= float(bottles["BurstAfter"]):
				_burst(group, node)
		if node["burning"]:

			if now - node["last_sprayed"] > regrow_delay:

				var cap: = _air_cap(node, ways)
				var faster: float = fed.get(node["room"], 1.0)
				if node["intensity"] < cap:
					node["intensity"] = minf(cap, node["intensity"] + dt * faster / float(node["material"]["grow"]))
				else:
					node["intensity"] = maxf(cap, node["intensity"] - dt / float(s["Flow"]["Starve"]))
				node["damage"] = maxf(0.0, node["damage"] - float(s["Regrow"]) * (0.25 + 0.75 * node["intensity"]) * dt)
			var eats: = 1.0
			if is_same(node, incident.get("fed")):

				node["intensity"] = maxf(node["intensity"], float(s["Traits"]["Gas"]["Intensity"]))
				eats = 0.0
			elif incident.get("sealed") != null and node["room"] == incident["sealed"]:

				node["intensity"] = minf(node["intensity"], float(s["Traits"]["Sealed"]["Cap"]))
				eats = float(s["Traits"]["Sealed"]["Starve"])
			node["fuel"] -= (0.3 + 0.7 * node["intensity"]) * eats * dt
			_char(group, node)
			if node["fuel"] <= 0.0:
				node["fuel"] = 0.0
				_douse(node)
				if node["burnt"] is Callable:
					node["burnt"].call()
			else:
				_show(node)

	for node: Dictionary in group["nodes"]:

		if node["burning"] and not (incident.get("sealed") != null and node["room"] == incident["sealed"]):
			var spread: float = lerpf(1.0, float(s["Flow"]["FedSpread"]), clampf(float(fed.get(node["room"], 1.0)) - 1.0, 0.0, 1.0))
			for link: Dictionary in node["links"]:
				var other: Dictionary = link["node"]
				if not other["burning"] and other["fuel"] > 0.0 and other["wet_until"] < now:
					var through: = _passage(building, node["room"], other["room"], link["vertical"])
					other["warmed"] += link["nearness"] * through * _heat_of(node) * spread


	var ready: Array = []
	for node: Dictionary in group["nodes"]:
		if node["warmed"] > 0.0:
			node["heat"] = minf(float(s["HeatClamp"]), node["heat"] + node["warmed"] * float(node["material"]["ease"]) * float(crew["pace"]) * dt / float(s["HeatTime"]))
			node["warmed"] = 0.0
			if node["heat"] >= 1.0:
				ready.append(node)
		elif node["heat"] > 0.0:
			node["heat"] = maxf(0.0, node["heat"] - float(s["Cooling"]) * dt)
	incident["cap_extra"] = maxf(0.0, float(incident.get("cap_extra", 0.0)) - float(s["CapDecay"]) * dt)
	if not ready.is_empty():
		ready.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return float(a["heat"]) > float(b["heat"]))
		for node: Dictionary in ready:
			if incident["count"] >= _flame_cap():
				break
			_ignite(node, 0.0)


	var burnt: = 0.0
	for node: Dictionary in group["nodes"]:
		burnt += 1.0 - node["fuel"] / float(node["material"]["burn"])
	incident["health"] = 100.0 * (1.0 - burnt / (group["nodes"].size() * float(s["LossShare"])))

	incident["health"] = minf(incident["health"], _room_health(building))








func _air_ways(building: Building) -> Dictionary:
	var found: = {}
	if not building.has_rooms():
		return found
	var zone_of: = {}
	for start: String in building.rooms:
		if zone_of.has(start):
			continue
		var members: Array = [start]
		zone_of[start] = true
		var at: = 0
		while at < members.size():
			var here: String = members[at]
			at += 1
			for other: String in _open_neighbours(building, here):
				if not zone_of.has(other):
					zone_of[other] = true
					members.append(other)
		var ways: = 0
		for member: String in members:
			ways += building.ways_out(member)
		for member: String in members:
			found[member] = ways
	return found



func _open_neighbours(building: Building, room_name: String) -> Array:
	var found: Array = []
	for opening: Dictionary in building.openings:
		var other: Variant = null
		if opening["a"] == room_name:
			other = opening["b"]
		elif opening["b"] == room_name:
			other = opening["a"]
		if other != null and building.rooms.has(other) and opening["passes"].call():
			found.append(other)
	return found




func _air_cap(node: Dictionary, ways: Dictionary) -> float:
	var room_name: Variant = node.get("room")
	if room_name == null or not ways.has(room_name):
		return 1.0
	var flow: Dictionary = settings()["Flow"]
	return minf(1.0, float(flow["ClosedCap"]) + float(flow["PerWay"]) * int(ways[room_name]))





func _fed(room_name: String, ways: int, now: float) -> float:
	var flow: Dictionary = settings()["Flow"]
	var state: Dictionary = incident["rooms"].get(room_name, {})
	if now - float(state.get("watered_at", -1000.0)) <= float(flow["WaterGrace"]):
		return 1.0
	var faster: = float(flow["FedGrow"]) if ways > 0 else 1.0
	if now < float(state.get("fanned_until", -1.0)):
		faster *= float(Config.Tools.Fan.FeedPace)
	return faster








func fan(place: Transform3D, dt: float) -> String:
	if incident.is_empty() or Net.is_client():
		return ""
	var building: Building = incident["group"]["building"]
	if not building.has_rooms():
		return ""
	var settings_fan: Dictionary = Config.Tools.Fan
	var forward: = Vector3( - place.basis.z.x, 0, - place.basis.z.z).normalized()
	var inlet: Variant = null
	var best: = INF
	for door: Dictionary in building.open_outside_doors():
		var middle: = House.door_middle(door)
		var offset: = Vector3(middle.x - place.origin.x, 0, middle.z - place.origin.z)
		var facing: = offset.length() < 1.0 or offset.normalized().dot(forward) > 0.5
		if offset.length() <= float(settings_fan["DoorReach"]) and offset.length() < best and facing:
			best = offset.length()
			inlet = door
	if inlet == null:
		return ""
	var start: String = inlet["room"]


	var came_from: = {start: ""}
	var queue: Array = [start]
	var exhaust: = ""
	while not queue.is_empty():
		var here: String = queue.pop_front()
		if building.ways_out(here) - (1 if here == start else 0) > 0:
			exhaust = here
			break
		for other: String in _open_neighbours(building, here):
			if not came_from.has(other):
				came_from[other] = here
				queue.append(other)
	var now: = Game.now()
	var along: Array = []
	if exhaust.is_empty():
		along = [start]
	else:
		var here: = exhaust
		while not here.is_empty():
			along.append(here)
			here = came_from[here]
	for room_name: String in along:
		var state: Dictionary = incident["rooms"][room_name]
		if not exhaust.is_empty():
			state["smoke"] = maxf(0.0, float(state["smoke"]) - float(settings_fan["Smoke"]) * dt)
		state["fanned_until"] = now + 1.0



	if not exhaust.is_empty():
		for room_name: String in came_from:
			if room_name in along:
				continue
			var state: Dictionary = incident["rooms"][room_name]
			state["smoke"] = maxf(0.0, float(state["smoke"]) - float(settings_fan["Smoke"]) * 0.5 * dt)
			state["fanned_until"] = now + 1.0
	incident["fan_path"] = along
	return "noexhaust" if exhaust.is_empty() else "clearing"


func _burn_players(dt: float) -> void :
	var s: = settings()
	var building: Building = incident["group"]["building"]
	for player in Game.players:
		if player.health <= 0.0:
			continue
		var at: = player.root_position()
		if building is House:
			_heat_stress(building as House, player, dt)
		for node: Dictionary in incident["group"]["nodes"]:
			if not node["burning"]:
				continue

			var reach: float = float(s["BurnRadius"]) * (0.5 + 0.5 * _heat_of(node))
			if node["position"].distance_to(at) <= reach:

				var shield: float = float(Config.Hose.Fog.Shield) if player.get_attr("FogShield", false) else 0.0
				player.take_damage(float(s["BurnDamage"]) * (1.0 - player.heat_protection()) * (1.0 - shield) * dt)
				break





func _heat_stress(house: House, player: Player, dt: float) -> void :
	var stress: Dictionary = settings()["HeatStress"]
	var head: = player.head_position()
	var room: Variant = house.room_at(head)
	if room == null or not incident["rooms"].has(room["name"]):
		return
	var over: = minf(float(incident["rooms"][room["name"]].get("warmth", 0.0)) - float(stress["From"]), float(stress["Most"]))
	if over <= 0.0:
		return
	var share: = float(stress["Crouched"]) if house.below_smoke(room, head) else 1.0
	var shield: float = float(Config.Hose.Fog.Shield) if player.get_attr("FogShield", false) else 0.0
	player.take_damage(float(stress["Rate"]) * over * share * (1.0 - player.heat_protection()) * (1.0 - shield) * dt)



func _crew_arrived(at: Vector3) -> bool:
	for player in Game.players:
		if player.root_position().distance_to(at) <= float(settings()["ArriveRange"]):
			return true
	return false




func _start(group: Dictionary) -> Array:
	var s: = settings()
	var building: Building = group["building"]
	var nodes: Array = group["nodes"]
	var scenario: Variant = null
	if not building.scenarios.is_empty():
		scenario = building.scenarios[randi() % building.scenarios.size()]
	var origin: Variant = null
	if scenario != null:
		var matches: Array = []
		for node: Dictionary in nodes:
			if node["name"] == scenario.get("origin") and node["room"] == scenario.get("room"):
				matches.append(node)
		if not matches.is_empty():
			origin = matches[randi() % matches.size()]
	if origin == null:
		var reachable: = nodes.filter( func(node: Dictionary) -> bool: return node.get("reachable", true))
		origin = (reachable if not reachable.is_empty() else nodes).pick_random()
	_ignite(origin, float(s["StartIntensity"]))

	var nearest: Array = origin["links"].duplicate()
	var strength: = func(link: Dictionary) -> float:
		return link["nearness"] * _passage(building, origin["room"], link["node"]["room"], link["vertical"])
	nearest.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return strength.call(a) > strength.call(b))
	var wanted: int = building.start_nodes if building.start_nodes > 0 else int(s["StartNodes"])
	if Alarm.active:
		wanted += int(Alarm.pick("StartNodes"))
		wanted += int(Alarm.crowd() * float(Alarm.settings()["Crowd"]["StartNodes"]))
	for index in mini(wanted - 1, nearest.size()):
		_ignite(nearest[index]["node"], float(s["StartIntensity"]))
	return [scenario, origin]






func _shut_in(building: Building, room_name: String) -> bool:
	var room: Variant = building.rooms.get(room_name)
	if room == null or room.get("open", false) or room["panes"].is_empty():
		return false
	var ways: = 0
	for opening: Dictionary in building.openings:
		if opening["a"] == room_name or opening["b"] == room_name:
			if opening["passes"].call():
				return false
			ways += 1
	return ways > 0





func _shut_origin(building: Building, origin: Dictionary) -> void :
	var room_name: Variant = origin.get("room")
	var forced: Variant = settings()["Traits"].get("Force")
	if not building is House or room_name == null or float(settings()["Traits"]["Chance"]) <= 0.0 or (forced is String and not forced.is_empty()):
		return
	var roll: = float(rand_from_seed(hash([(building as House).net_index, room_name, Time.get_ticks_usec()]))[0] %10000) / 10000.0
	if roll >= float(settings()["Flow"]["ShutChance"]):
		return
	for opening: Dictionary in building.openings:
		var door: Variant = opening.get("door")
		if door is Dictionary and (opening["a"] == room_name or opening["b"] == room_name) and door["open"]:
			door["open"] = false
			door["amount"] = 0.0
			(building as House)._place_door(door)




func _draw_traits(building: Building, scenario: Variant, origin: Dictionary) -> Array[String]:
	var drawn: Array[String] = []
	if not building.has_rooms() or scenario == null:
		return drawn
	var s: Dictionary = settings()["Traits"]
	var door: Variant = building.outside_door()
	var can: Array[String] = []
	if origin["kind"] == "grease":
		can.append("grease")
	if door != null and scenario.get("origin") in GAS_ORIGINS:
		can.append("gas")
	if door != null and (scenario.get("name") == "Electrical fire" or scenario.get("origin") in LIVE_ORIGINS):
		can.append("live")
	if scenario.get("room") != null and _shut_in(building, scenario["room"]):
		can.append("sealed")
	var force: Variant = s.get("Force")
	if force is String and not force.is_empty():
		if force in can:
			drawn.append(force)
		return drawn
	var chance: float = float(Alarm.pick("TraitChance")) if Alarm.active else float(s["Chance"])
	if can.is_empty() or randf() >= chance:
		return drawn
	drawn.append(can[randi() % can.size()])
	if Alarm.active and randf() < float(Alarm.pick("SecondTrait")):
		var others: Array[String] = []
		for other in can:
			if other != drawn[0] and not (other in ["gas", "live"] and drawn[0] in ["gas", "live"]):
				others.append(other)
		if not others.is_empty():
			drawn.append(others[randi() % others.size()])
	return drawn




func _apply_traits(group: Dictionary, scenario: Variant, origin: Dictionary) -> Array[String]:
	var drawn: = _draw_traits(group["building"], scenario, origin)
	incident["traits"] = drawn
	incident["trait"] = drawn[0] if not drawn.is_empty() else ""
	incident["stirred"] = STIRRED.get(origin["name"], "grease")
	for one in drawn:
		_apply_trait(group, scenario, origin, one)
	return drawn



func has_trait(which: String) -> bool:
	return which in incident.get("traits", [])


func _apply_trait(group: Dictionary, scenario: Variant, origin: Dictionary, drawn: String) -> void :
	var building: Building = group["building"]
	var s: Dictionary = settings()["Traits"]
	if drawn == "gas":
		incident["fed"] = origin
		incident["control"] = building.fit_control("calls.fire.valve", float(s["Gas"]["Hold"]), Color(240 / 255.0, 196 / 255.0, 30 / 255.0), true, func(player: Player) -> void :
			if not incident.is_empty() and is_same(incident.get("fed"), origin):
				incident["fed"] = null
				incident["contributors"][player] = true
				Game.notify(Text.f("calls.fire.traits.gasOff", [player.display_name]), "good")
		)
	elif drawn == "live":
		incident["live"] = scenario["room"]
		incident["control"] = building.fit_control("calls.fire.switch", float(s["Live"]["Hold"]), Color(200 / 255.0, 40 / 255.0, 34 / 255.0), false, func(player: Player) -> void :
			if not incident.is_empty() and incident.get("live") != null:
				incident["live"] = null
				incident["contributors"][player] = true
				Game.notify(Text.f("calls.fire.traits.liveOff", [player.display_name]), "good")
		)
	elif drawn == "sealed":
		incident["sealed"] = scenario["room"]

		for node: Dictionary in group["nodes"]:
			if node["burning"] and node["room"] != scenario["room"]:
				_douse(node)
		for pane: Dictionary in building.rooms[scenario["room"]]["panes"]:
			pane["crack"].call()



func _watch_sealed() -> void :
	var room_name: Variant = incident.get("sealed")
	if room_name == null:
		return
	var group: Dictionary = incident["group"]
	var building: Building = group["building"]
	var room: Dictionary = building.rooms[room_name]
	for pane: Dictionary in room["panes"]:
		if pane["broken"]:
			incident["sealed"] = null
			Game.notify(Text.m("calls.fire.traits.vented"), "good")
			return
	var opened: = false
	for opening: Dictionary in building.openings:
		opened = opened or ((opening["a"] == room_name or opening["b"] == room_name) and opening["passes"].call())
	if not opened:
		return

	incident["sealed"] = null
	var s: Dictionary = settings()["Traits"]["Sealed"]
	var middle: Vector3 = room["smoke_position"] - Vector3(0, 3, 0)
	Blast.at(middle, 12.0, 1.0, 1.3)
	var lit: Array = []
	for node: Dictionary in group["nodes"]:
		if node["room"] == room_name and node["fuel"] > 0.0:
			if node["burning"]:
				node["intensity"] = maxf(node["intensity"], float(settings()["FlashoverIntensity"]))
			else:
				lit.append(node)
	_light_event(lit, float(settings()["FlashoverIntensity"]))
	for pane: Dictionary in room["panes"]:
		pane["shatter"].call(Vector3.ZERO)
	incident["rooms"][room_name]["flashed"] = true
	incident["flashovers"] = int(incident.get("flashovers", 0)) + 1
	_room_lost(building, room_name)
	Game.notify(Text.m("calls.fire.traits.backdraught"), "danger")






func _burn_rooms(dt: float) -> void :
	var s: = settings()
	var group: Dictionary = incident["group"]
	var building: Building = group["building"]
	var now: = Game.now()



	var heat: Dictionary = {}
	for node: Dictionary in group["nodes"]:
		if node["burning"] and node["room"] != null:
			heat[node["room"]] = heat.get(node["room"], 0.0) + _heat_of(node)
	var gas: Dictionary = s["GasCooling"]
	var ways: = _air_ways(building)
	incident["ways"] = ways


	var occupied: Dictionary = {}
	for player in Game.players:
		var inside: Variant = building.room_at(player.root_position())
		if inside != null:
			building.set_read(inside["name"], "searched", true)
			occupied[inside["name"]] = true
	for room_name: String in building.rooms:
		if building.rooms[room_name].get("searched", false) and not occupied.has(room_name):
			building.set_read(room_name, "cleared", true)

	for room_name: String in building.rooms:
		var room: Dictionary = building.rooms[room_name]
		var state: Dictionary = incident["rooms"][room_name]
		var alight: bool = heat.has(room_name)
		state["cooled"] = maxf(0.0, float(state.get("cooled", 0.0)) - float(gas["Recover"]) * dt)
		var warmth: float = maxf(0.0, float(heat.get(room_name, 0.0)) - float(state["cooled"]))
		state["warmth"] = warmth

		building.set_read(room_name, "water", now - float(state.get("watered_at", -1000.0)) <= float(s["Smoke"]["Look"]["WaterFor"]))
		building.set_read(room_name, "breathing", incident.get("sealed") == room_name)


		if alight and not state.get("dark", false):
			state["dark"] = true
			building.set_room_lights(room_name, false)


		for pane: Dictionary in room["panes"]:
			if warmth >= float(s["CrackHeat"]):
				pane["crack"].call()

		var vented: bool = int(ways.get(room_name, 0)) > 0
		if warmth >= float(s["BreakHeat"]) and now >= state["next_break"]:
			for pane: Dictionary in room["panes"]:
				if not pane["broken"]:
					pane["shatter"].call(Vector3.ZERO)
					state["next_break"] = now + float(s["BreakInterval"])
					break


		var wanted: float = minf(warmth / float(s["SmokeFull"]), 1.0) * (float(s["VentedSmoke"]) if vented else 1.0)
		if incident.get("sealed") == room_name:
			wanted = 1.0
		if room.get("open", false):
			wanted *= float(s["OpenSmoke"])

		var fanned: bool = now < float(state.get("fanned_until", 0.0))
		if fanned:
			wanted *= float(Config.Tools.Fan.get("Makes", 1.0))
		for opening: Dictionary in building.openings:
			var other: Variant = null
			if opening["a"] == room_name:
				other = opening["b"]
			elif opening["b"] == room_name:
				other = opening["a"]
			if other != null and incident["rooms"].has(other) and opening["passes"].call():
				wanted = maxf(wanted, incident["rooms"][other]["smoke"] * float(s["SmokeLeak"]) * (float(Config.Tools.Fan.get("Makes", 1.0)) if fanned else 1.0))
		state["smoke"] += (wanted - state["smoke"]) * minf(1.0, dt / float(s["SmokeTime"]) * 3.0)
		var shown: float = floor(state["smoke"] * 20.0 + 0.5) / 20.0
		if shown != state.get("shown_smoke", -1.0):
			state["shown_smoke"] = shown
			building.show_smoke(room_name, shown)


		if warmth > 0.0:
			state["scorch"] = minf(float(state.get("scorch", 0.0)) + warmth * dt / SCORCH_TIME, 1.0)
			var scorch_shown: float = floor(state["scorch"] * 10.0) / 10.0
			if scorch_shown != state.get("shown_scorch", 0.0):
				state["shown_scorch"] = scorch_shown
				building.show_scorch(room_name, scorch_shown)

		if float(state.get("scorch", 0.0)) >= float(s["Rooms"]["LostScorch"]) - 0.001:
			_room_lost(building, room_name)
		if building is House:
			_room_events(building as House, room_name, state, dt)


		if not state.get("flashed", false) and not room.get("open", false):
			state["hot_for"] = state["hot_for"] + dt if warmth >= float(s["FlashoverHeat"]) else 0.0
			if state.get("flash_at") == null and state["hot_for"] >= float(s["FlashoverTime"]):
				state["flash_at"] = now + float(s["FlashoverWarning"])
				building.show_flashover(room_name, true)

			if state.get("flash_at") != null and warmth < float(s["FlashoverCancel"]) * float(s["FlashoverHeat"]):
				state["flash_at"] = null
				state["hot_for"] = 0.0
				building.show_flashover(room_name, false)
				var cooled_where: Variant = Text.m("calls.rooms.%s.inside" % room_name) if Text.has("calls.rooms.%s.inside" % room_name) else room_name
				Game.notify(Text.f("calls.fire.flashoverStopped", [cooled_where]), "good")
			if state.get("flash_at") != null and now >= state["flash_at"]:
				state["flashed"] = true
				building.show_flashover(room_name, false)
				_show_flash(building, room_name)
				if building is House:
					Net.broadcast("fire.flash", [(building as House).net_index, room_name])
				var lit: Array = []
				for node: Dictionary in group["nodes"]:
					if node["room"] == room_name and not node["burning"] and node["fuel"] > 0.0:
						lit.append(node)
				_light_event(lit, float(s["FlashoverIntensity"]))
				for pane: Dictionary in room["panes"]:
					pane["shatter"].call(Vector3.ZERO)
				incident["flashovers"] = int(incident.get("flashovers", 0)) + 1
				_room_lost(building, room_name)
				var where: Variant = Text.m("calls.rooms.%s.inside" % room_name) if Text.has("calls.rooms.%s.inside" % room_name) else room_name
				Game.notify(Text.f("calls.fire.flashover", [where]))





func _inside_words(room_name: String) -> Variant:
	var key: = "calls.rooms.%s.inside" % room_name
	return Text.m(key) if Text.has(key) else room_name



func _room_lost(building: Building, room_name: String) -> void :
	var state: Dictionary = incident["rooms"].get(room_name, {})
	if state.is_empty() or state.get("lost", false):
		return
	state["lost"] = true
	if building is House:
		(building as House).set_read(room_name, "lost", true)
	Game.notify(Text.f("calls.fire.events.roomLost", [_inside_words(room_name)]), "warning")




func _room_health(building: Building) -> float:
	if not building.has_rooms() or incident.is_empty():
		return 100.0
	var rooms: = 0
	var lost: = 0
	for room_name: String in building.rooms:
		if building.rooms[room_name].get("open", false) or not incident["rooms"].has(room_name):
			continue
		rooms += 1
		lost += 1 if incident["rooms"][room_name].get("lost", false) else 0
	if rooms < 2:
		return 100.0
	return 100.0 * float(rooms - lost) / rooms



func _tell_rooms(building: Building) -> void :
	if not building.has_rooms():
		return
	var rooms: = 0
	var lost: Array = []
	for room_name: String in building.rooms:
		if building.rooms[room_name].get("open", false) or not incident["rooms"].has(room_name):
			continue
		rooms += 1
		if incident["rooms"][room_name].get("lost", false):
			lost.append(_inside_words(room_name))
	incident["rooms_saved"] = rooms - lost.size()
	incident["rooms_total"] = rooms
	if rooms < 2:
		return
	if lost.is_empty():
		Game.notify(Text.f("calls.fire.events.roomsAllSaved", [rooms, rooms]), "good")
	else:
		var named: Array = []
		for index in lost.size():
			if index > 0:
				named.append(", ")
			named.append(lost[index])
		Game.notify(Text.f("calls.fire.events.roomsSaved", [rooms - lost.size(), rooms, Text.join(named)]), "warning")




func _room_events(house: House, room_name: String, state: Dictionary, _dt: float) -> void :
	var events: Dictionary = settings()["Events"]
	if Alarm.level < int(events["From"]) and not incident.get("events_forced", false):
		return
	if Alarm.arrived_at < 0.0 and not incident.get("events_forced", false):
		return
	var scorch: = float(state.get("scorch", 0.0))
	var ceiling: Dictionary = events["Ceiling"]
	if scorch >= float(ceiling["Scorch"]) and not state.get("ceiling_drawn", false) and not incident.get("ceiling_done", false):
		state["ceiling_drawn"] = true
		if randf() < float(ceiling["Chance"]):
			ceiling_down(house, room_name)
	var floor: Dictionary = events["Floor"]
	if scorch >= float(floor["Scorch"]) and not state.get("floor_drawn", false):
		state["floor_drawn"] = true
		if randf() < float(floor["Chance"]):
			house.set_read(room_name, "weak", true)
			Game.notify(Text.f("calls.fire.events.floorSoft", [_inside_words(room_name)]), "danger")




func ceiling_down(house: House, room_name: String) -> bool:
	var ceiling: Dictionary = settings()["Events"]["Ceiling"]
	var best: Variant = null
	for opening: Dictionary in house.openings:
		if not opening["door"] is Dictionary or not (opening["a"] == room_name or opening["b"] == room_name):
			continue
		var door: Dictionary = opening["door"]
		if door.get("debris", false):
			continue

		if best == null or ((door["open"] or door["burnt"]) and not (best["door"]["open"] or best["door"]["burnt"])):
			best = opening
	if best == null:
		return false
	var door: Dictionary = best["door"]
	house.block_door(door["name"], true)
	incident["ceiling_done"] = true
	var at: = (door["shut"] as Transform3D).origin
	Blast.at(at, 10.0, 0.6, 0.8)
	Sounds.once_at(at, "collapse", 1.0, 20.0, 200.0)
	Game.notify(Text.f("calls.fire.events.ceiling", [_inside_words(room_name)]), "danger")
	return true








func _smoulder(group: Dictionary) -> bool:
	var s: Dictionary = settings()["Embers"]
	var pool: Array = []
	for node: Dictionary in group["nodes"]:
		if node["room"] != null and node["wet_until"] > 0.0 and node["fuel"] > 0.0:
			pool.append(node)
	var count: Vector2 = s["Count"]
	var wanted: = mini(randi_range(int(count.x), int(count.y)), pool.size())
	if wanted == 0:
		return false
	var embers: Array = []
	for index in wanted:
		var node: Dictionary = pool.pop_at(randi() % pool.size())
		var marker: = Ember.new()
		add_child(marker)
		marker.global_position = node["position"]
		embers.append({"node": node, "position": node["position"], "marker": marker, "wet": 0.0})
	incident["embers"] = embers
	Game.notify(Text.f("calls.fire.embers.start", [embers.size()]), "warning")

	var left: float = s["Time"]
	while not embers.is_empty() and left > 0.0:
		var dt: float = await _tick()
		if incident.is_empty():
			return false
		left -= dt
		_burn_rooms(dt)
		Victims.step(dt, smoke_at, false)
		incident["count"] = embers.size()
		_publish()
	incident.erase("embers")
	incident["count"] = 0
	if embers.is_empty():
		Game.notify(Text.m("calls.fire.embers.done"), "good")
		return false
	var relit: Array = []
	for ember: Dictionary in embers:
		ember["marker"].queue_free()
		relit.append(ember["node"])
	_light_event(relit, float(s["Relight"]))
	Game.notify(Text.m("calls.fire.embers.relit"), "danger")
	return true


func _tick() -> float:
	var before: = Game.now()
	await get_tree().create_timer(TICK, false).timeout
	return Game.now() - before


func _fight(group: Dictionary, waiting: Array) -> void :
	var building: Building = group["building"]
	while incident["count"] > 0 and incident["health"] > 0.0:
		var dt: float = await _tick()
		if incident.is_empty():
			return
		var waited: bool = waiting[0]
		waiting[0] = waiting[0] and Game.now() < waiting[1] and not _crew_arrived(building.position)

		if waited and not waiting[0] and incident.get("sealed") != null and Alarm.level < int(settings()["Smoke"]["SealedToldBelow"]):
			Game.notify(Text.m("calls.fire.traits.sealed"), "warning")
		if not waiting[0]:
			_burn(dt)
		if building.has_rooms():
			_burn_rooms(dt)
			_watch_sealed()
		_burn_players(dt)
		Victims.step(dt, smoke_at, true)
		Escalation.fire_step(self, group, dt)
		_publish()
		_keep_for_report()





func _contained(building: Building, people: Dictionary) -> void :
	if not building.counts_as_save:
		return
	var grading: Dictionary = Alarm.settings()["Grade"]
	var pays: Dictionary = grading["Containment"]
	var amount: = 0.0
	var origin: Variant = incident.get("origin_room")
	var lit: Dictionary = incident.get("rooms_lit", {})
	var spared: = 0
	if building.has_rooms() and origin != null:
		var held: = lit.size() <= 1
		for room_name: String in building.rooms:
			if not lit.has(room_name):
				spared += 1
		if held:
			amount += float(pays["OriginHeld"])
		amount += float(pays["PerRoom"]) * spared
		Alarm.check("origin", held)
		Alarm.check("mask", Alarm.smoke_hp <= float(grading["Procedure"]["SmokeHp"]))
	if Alarm.job_par > 0.0 and Alarm.job_done_at >= 0.0 and Alarm.arrived_at >= 0.0 and Alarm.job_done_at - Alarm.arrived_at <= Alarm.job_par:
		amount += float(pays["Quick"])
	Alarm.check("hydrant", incident["hydrant"])
	var pay: = int(floor(amount * building.reward_share))
	if pay <= 0:
		return
	var helpers: Dictionary = incident["contributors"].duplicate()
	helpers.merge(people.get("rescuers", {}))
	CallKit.pay_helpers(helpers, pay, "bonus", "containment")
	Game.notify(Text.f("calls.fire.contained", [spared, building.rooms.size(), Alarm.pay(pay)]) if building.has_rooms() else Text.f("calls.fire.containedQuick", [Alarm.pay(pay)]), "good")




func _keep_for_report() -> void :
	if not Alarm.active:
		return
	if not incident.has("arrival_count") and Alarm.arrived_at >= 0.0:
		incident["arrival_count"] = maxi(int(incident["count"]), 1)
		var par: Dictionary = Alarm.settings()["Grade"]["Job"]["fire"]
		Alarm.par(float(par["Base"]) + float(par["PerFlame"]) * int(incident["arrival_count"]))
	if not incident["hydrant"] and HoseService.current != null:
		for rig: Dictionary in HoseService.current.rigs:
			var source: Variant = HoseService.current.supplied_by(rig["vehicle"])
			if source is String and source == "hydrant":
				incident["hydrant"] = true




func run_incident(building: Building, options: = {}) -> void :
	if Net.is_client():
		return
	var run: = _runs
	var group: = _group_of(building)
	_reset_group(group)
	for node: Dictionary in group["nodes"]:
		node["reachable"] = FireAccess.catches(building, node["index"])
	building.lock_up()
	incident = {
		"group": group, 
		"count": 0, 
		"out": 0, 
		"health": 100.0, 
		"contributors": {}, 
		"rooms": {}, 


		"rooms_lit": {}, 
		"paid": {}, 
		"hydrant": false, 
	}
	for room_name: String in building.rooms:
		incident["rooms"][room_name] = {"smoke": 0.0, "next_break": 0.0, "hot_for": 0.0}
	var started: = _start(group)
	var scenario: Variant = started[0]
	var origin: Dictionary = started[1]
	incident["origin_room"] = origin["room"]
	incident["scenario_name"] = scenario["name"] if scenario != null else ""



	incident["ladder"] = LadderService.current != null and FireAccess.ladder_only(building, [origin["index"]])
	incident["ladder_height"] = (origin["position"] as Vector3).y - float(FireAccess.of(building)["ground_y"]) if incident["ladder"] else 0.0
	_shut_origin(building, origin)
	var drawn: = _apply_traits(group, scenario, origin)
	Escalation.fire_begin(building)



	var shown_name: Variant = building.shown_name if building.shown_name != null else Text.named("calls.buildings", building.name)
	var number: = RegEx.create_from_string("^House (\\d+)$").search(building.name)
	if number:
		shown_name = Text.f("calls.houseNumber", [int(number.get_string(1))])
	var title: Variant = shown_name
	if scenario != null:
		var parts: Array = [Text.named("calls.scenarios", scenario["name"]), Text.m("calls.separator"), shown_name]
		if scenario.get("room") != null and building.rooms.has(scenario["room"]):
			var floor_number: = int(building.rooms[scenario["room"]]["floor"])
			parts.append(Text.m("calls.separator"))
			parts.append(Text.m("calls.floors.ground" if floor_number == 0 else ("calls.floors.first" if floor_number == 1 else "calls.floors.upper")))
		title = Text.join(parts)
	incident["title"] = title
	var automatic: bool = options.get("alarm", false) and FireAlarm.current != null
	incident["automatic"] = automatic
	if automatic:
		var full: Variant = title
		incident["title"] = Text.join([Text.m("calls.alarm.title"), Text.m("calls.separator"), shown_name])
		var room_name: Variant = scenario.get("room") if scenario != null else null
		FireAlarm.current.put_panel(building as House, func(_player: Player, first: bool) -> void :
			if not first or incident.is_empty():
				return
			incident["panel_read"] = true
			incident["title"] = full
			if room_name != null and building.rooms.has(room_name):
				Game.notify(FireAlarm.zone_words(building as House, room_name), "danger")
			_publish()
		)


	Victims.begin(building, scenario)
	var marker: = CallMarker.make(building.position + Vector3(0, building.height / 2.0 + 10.0, 0), Text.m("calls.markers.fire"), Color(200 / 255.0, 50 / 255.0, 30 / 255.0))
	incident["marker"] = marker
	_publish()
	if automatic:
		Game.notify(Text.f("calls.alarm.alarm", [incident["title"]]), "warning")
		Game.notify(Text.m("calls.alarm.brief"), "")
	else:
		Game.notify(Text.f("calls.fire.alarm" if scenario != null else "calls.fire.alarmPlain", [title]))


	var report: Variant = Victims.report_words()
	if report != null and not automatic:
		Game.notify(report, "warning")

	for told in drawn:
		if told != "sealed" and not automatic:
			var words: String = incident["stirred"] if told == "grease" else told
			Game.notify(Text.m("calls.fire.traits." + words), "warning")



	var waiting: = [bool(Alarm.pick("Waits")) if Alarm.active else true, Game.now() + float(settings()["ArriveWait"])]
	await _fight(group, waiting)
	if run != _runs:
		return


	if incident["health"] > 0.0:
		Alarm.done()
	Escalation.calm()

	if incident["health"] > 0.0 and building.has_rooms() and randf() < (float(Alarm.pick("EmberChance")) if Alarm.active else float(settings()["Embers"]["Chance"])):
		if await _smoulder(group):
			await _fight(group, waiting)
	if run != _runs:
		return

	var saved: bool = incident["health"] > 0.0
	if is_instance_valid(incident.get("control")):
		incident["control"].queue_free()
	incident["fed"] = null
	incident["live"] = null
	incident["sealed"] = null
	for node: Dictionary in group["nodes"]:
		if node["burning"]:
			_douse(node)
	for room_name: String in building.rooms:
		building.set_read(room_name, "breathing", false)
	marker.queue_free()
	if not saved:
		Victims.building_lost()

	var stars: = 0
	if saved:


		var bonus: = int(floor(float(Config.Rewards.SaveBonus) * building.reward_share * incident["health"] / 100.0))
		if building.counts_as_save:
			var rating: Dictionary = settings()["Stars"]
			stars = 3 if incident["health"] >= float(rating["Three"]) else (2 if incident["health"] >= float(rating["Two"]) else 1)
			bonus += int(floor(float(Config.Rewards.SaveBonus) * building.reward_share * float(rating["Bonus"][stars - 1])))


		var helpers: Dictionary = incident["contributors"].duplicate()
		if Victims.service:
			helpers.merge(Victims.service.rescuers())
		CallKit.pay_helpers(helpers, bonus, "bonus")
		Game.notify(Text.f("calls.fire.out", [title, Alarm.pay(bonus)]), "good")
	else:
		building.set_charred(true)
		Game.notify(Text.fill(building.lost_text if building.lost_text != null else Text.m("calls.fire.lost"), [title]), "danger")



	if Victims.waiting():
		if saved:
			Game.notify(Text.m("calls.fire.bringOut"))
		for room_name: String in incident["rooms"]:
			var state: Dictionary = incident["rooms"][room_name]
			state["flashed"] = true
			state["flash_at"] = null
			building.show_flashover(room_name, false)
			if not saved:
				state["smoke"] = 0.0
		var waited: = 0.0
		while Victims.waiting() and waited < float(Config.Victims.AfterFire):
			var dt: float = await _tick()
			if run != _runs:
				return
			waited += dt
			if saved and building.has_rooms():
				_burn_rooms(dt)
			Victims.step(dt, smoke_at, false)
			_publish()
	var people: = Victims.finish()
	VictimService.tally(people)



	if stars > 0 and (people["lost"] > 0 or int(incident.get("flashovers", 0)) > 0):
		stars = mini(stars, 2)
	_tell_rooms(building)
	Alarm.stars = stars
	if saved:
		_contained(building, people)


	building.ruined = true
	get_tree().create_timer(float(settings()["RepairTime"]), false).timeout.connect( func() -> void :
		building.restore_colors()
		if not saved:
			building.set_charred(false)

		building.show_collapse(false)
		var index: = buildings.find(building)
		if index >= 0:
			Net.broadcast("fire.collapse", [index, false])
		building.restore()
		building.ruined = false
	)
	Game.incident["failed"] = not saved

	Game.incident.merge(VictimService.card(people), true)
	if incident.has("rooms_total"):
		Game.incident["rooms_saved"] = incident["rooms_saved"]
		Game.incident["rooms_total"] = incident["rooms_total"]
	Game.incident.erase("next")
	Escalation.reset()
	for room_name: String in building.rooms:
		for key: String in ["water", "breathing", "searched", "cleared"]:
			building.set_read(room_name, key, false)

	incident = {}
	_publish()






func smoke_at(at: Vector3) -> float:
	var vapour: = 0.0
	for hazard: Dictionary in hazards:
		var distance: float = (hazard["position"] as Vector3).distance_to(at)
		vapour = maxf(vapour, float(hazard["level"]) * clampf((float(hazard["radius"]) - distance) / (float(hazard["radius"]) * 0.5), 0.0, 1.0))
	if Net.is_client():
		return maxf(vapour, _net_smoke_at(at))
	if incident.is_empty():
		return vapour
	var radius: float = settings()["SmokeRadius"]
	var level: = 0.0

	var building: Building = incident["group"]["building"]
	var room: Variant = building.room_at(at)
	if room != null:
		level = incident["rooms"][room["name"]]["smoke"]
	for node: Dictionary in incident["group"]["nodes"]:
		if node["burning"]:
			var distance: float = node["position"].distance_to(at)
			level = maxf(level, clampf((radius - distance) / (radius * 0.6), 0.0, 1.0))
	return maxf(level, vapour)





func breathed_at(head: Vector3) -> float:
	var level: = smoke_at(head)
	if level <= 0.0:
		return level
	for house in House.all:
		if house.position.distance_to(head) > 90.0:
			continue
		var room: Variant = house.room_at(head)
		if room == null or float(room.get("level", 0.0)) <= 0.0:
			continue
		if house.below_smoke(room, head):
			level *= UNDER_SMOKE
		break
	return level



static func nearest_on_path(at: Vector3, path: PackedVector3Array) -> Array:
	var best: = [path[0], Vector3.FORWARD]
	var nearest: = INF
	for index in path.size() - 1:
		var from: = path[index]
		var piece: = path[index + 1] - from
		var length_squared: = piece.length_squared()
		var t: = clampf((at - from).dot(piece) / length_squared, 0.0, 1.0) if length_squared > 0.0001 else 0.0
		var point: = from + piece * t
		if at.distance_to(point) < nearest:
			nearest = at.distance_to(point)
			best = [point, piece.normalized() if length_squared > 0.0001 else best[1]]
	return best






func _reaches(node: Dictionary, path: PackedVector3Array) -> bool:
	if node.get("room") == null or incident.is_empty() or path.size() < 2:
		return true
	var building: Building = incident["group"]["building"]
	if not building.has_rooms():
		return true
	var sight: Dictionary = settings()["Sight"]
	var at: Vector3 = node["position"]
	var near: = nearest_on_path(at, path)
	var point: Vector3 = near[0] - (near[1] as Vector3) * float(sight["PullBack"])
	var room: Variant = building.room_at(point)
	if room != null and room["name"] == node["room"]:
		return true
	return not building.blocks(point, at, float(sight["Slack"]))




func _watered(node: Dictionary, now: float) -> void :
	var room_name: Variant = node.get("room")
	if room_name == null or incident.is_empty() or not incident["rooms"].has(room_name):
		return
	incident["rooms"][room_name]["watered_at"] = now



static func distance_to_path(at: Vector3, path: PackedVector3Array) -> float:
	var nearest: = INF
	for index in path.size() - 1:
		var from: = path[index]
		var piece: = path[index + 1] - from
		var length_squared: = piece.length_squared()
		var t: = clampf((at - from).dot(piece) / length_squared, 0.0, 1.0) if length_squared > 0.0001 else 0.0
		nearest = minf(nearest, at.distance_to(from + piece * t))
	return nearest





func spray(player: Player, path: PackedVector3Array, dt: float, radius: = -1.0) -> Dictionary:
	var result: = {"hits": 0, "progress": -1.0, "kills": 0}
	if Net.is_client() or path.size() < 2 or (incident.is_empty() and spots.is_empty()):
		return result
	var landing: = path[path.size() - 1]
	var now: = Game.now()
	var jet: = radius < 0.0
	var reach: float = float(Config.Hose.HitRadius) if jet else radius
	var nearest: = {"node": null, "distance": INF}

	var wet: = func(node: Dictionary) -> Array:
		if not node["burning"] or distance_to_path(node["position"], path) > reach or not _reaches(node, path):
			return [false, false]
		result["hits"] += 1
		_watered(node, now)
		node["damage"] += float(Config.Hose.Damage) * dt
		node["last_sprayed"] = now
		if node["damage"] >= _max_health(node):
			result["kills"] += 1
			return [true, true]

		_show(node)
		var distance: float = node["position"].distance_to(landing)
		if distance < nearest["distance"]:
			nearest["node"] = node
			nearest["distance"] = distance
		return [true, false]

	if not incident.is_empty():
		var traits: Dictionary = settings()["Traits"]
		for node: Dictionary in incident["group"]["nodes"]:

			if has_trait("grease") and jet and node["burning"] and node["kind"] == "grease":
				if distance_to_path(node["position"], path) <= float(Config.Hose.HitRadius) and _reaches(node, path):
					result["hits"] += 1
					node["intensity"] = minf(1.0, node["intensity"] + float(traits["Grease"]["Flare"]) * dt)
					for link: Dictionary in node["links"]:
						var other: Dictionary = link["node"]
						if not other["burning"] and other["fuel"] > 0.0:
							other["heat"] = minf(other["heat"] + float(traits["Grease"]["Heat"]) * link["nearness"] * dt, float(settings()["HeatClamp"]))
					_show(node)
					Game.tell(player, Text.m("calls.fire.traits.flare"))

					if incident.get("stirred") == "dust" and now - float(incident.get("dust_at", -100.0)) > DUST_BLAST["Every"]:
						incident["dust_at"] = now
						Blast.at(node["position"] + Vector3(0, 2, 0), DUST_BLAST["Radius"], 1.0, 0.9)
						for someone in Game.players:
							var away: = someone.root_position().distance_to(node["position"])
							if away < DUST_BLAST["Radius"]:
								someone.take_damage(DUST_BLAST["Damage"] * (1.0 - away / DUST_BLAST["Radius"]) * (1.0 - someone.heat_protection()))
						Game.notify(Text.m("calls.fire.traits.dustBlast"), "danger")
				continue
			var wetted: Array = wet.call(node)
			if wetted[0]:
				incident["contributors"][player] = true

				if incident.get("live") != null and jet and node["room"] == incident["live"] and path[0].distance_to(node["position"]) <= float(traits["Live"]["Reach"]):
					if now - player.get_attr("Shocked", -100.0) >= float(traits["Live"]["Every"]):
						player.set_attr("Shocked", now)
						player.take_damage(float(traits["Live"]["Damage"]))
					Game.tell(player, Text.m("calls.fire.traits.shock"))
			if not node["burning"] and float(node["heat"]) > 0.0 and node["fuel"] > 0.0 and distance_to_path(node["position"], path) <= reach and _reaches(node, path):

				node["heat"] = maxf(0.0, float(node["heat"]) - COOLING_WATER * dt)
				node["wet_until"] = now + float(settings()["WetTime"])
				result["hits"] += 1
				incident["contributors"][player] = true
			if wetted[1] and is_same(node, incident.get("fed")):

				result["kills"] -= 1
				node["damage"] = _max_health(node) * 0.9
				_show(node)
				Game.tell(player, Text.m("calls.fire.traits.gasFed"))
			elif wetted[1]:
				_extinguish(node, player)

		var embers: Array = incident.get("embers", [])
		for index in range(embers.size() - 1, -1, -1):
			var ember: Dictionary = embers[index]
			if distance_to_path(ember["position"], path) <= reach and _reaches(ember["node"], path):
				result["hits"] += 1
				ember["wet"] += dt
				incident["contributors"][player] = true
				if ember["wet"] >= float(settings()["Embers"]["Water"]):
					steam_puff(ember["position"])
					ember["marker"].queue_free()
					embers.remove_at(index)
					incident["out"] += 1
					result["kills"] += 1
					Alarm.note(player, "flames")
					player.add_cash(int(Config.Rewards.PerNode), "flameOut")
	for index in range(spots.size() - 1, -1, -1):
		var spot: Dictionary = spots[index]
		var wetted: Array = wet.call(spot)
		if wetted[1]:
			steam_puff(spot["position"])
			end_spot(spot)
			Alarm.note(player, "flames")
			player.add_cash(int(Config.Rewards.PerNode), "flameOut")
			if spot["out"] is Callable:
				spot["out"].call(player)
	if nearest["node"] != null and nearest["node"]["burning"]:
		result["progress"] = _progress(nearest["node"])
	return result







func spot(at: Vector3, out: Variant = null) -> Dictionary:
	if Net.is_client():
		return {"position": at, "flame": null, "burning": false, "intensity": 0.0, "damage": 0.0, "last_sprayed": 0.0, "out": null}
	_spots_made += 1
	var made: = {
		"position": at, "flame": _make_flame(at), "burning": true, "intensity": 0.15, "damage": 0.0, 
		"last_sprayed": 0.0, "out": out, "id": _spots_made, 
	}
	_show(made)
	spots.append(made)
	return made



func end_spot(made: Dictionary) -> void :
	if made["burning"]:
		made["burning"] = false
		if is_instance_valid(made["flame"]):
			made["flame"].queue_free()
		spots.erase(made)


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	FireAccess.warm(buildings)
	var now: = Game.now()
	for made: Dictionary in spots:
		if now - made["last_sprayed"] > float(settings()["RegrowDelay"]):
			made["intensity"] = minf(made["intensity"] + delta / SPOT_GROW, SPOT_FULL)
			made["damage"] = maxf(made["damage"] - float(settings()["Regrow"]) * (0.25 + 0.75 * made["intensity"]) * delta, 0.0)
			_show(made)




func clear_smoke(at: Vector3, share: float) -> String:
	if incident.is_empty() or Net.is_client():
		return ""
	var building: Building = incident["group"]["building"]
	var room: Variant = building.room_at(at)
	if room == null:
		return ""
	var state: Dictionary = incident["rooms"][room["name"]]
	state["smoke"] = maxf(0.0, state["smoke"] - share)
	return room["name"]





func fog(at: Vector3, amount: float, player: Player = null, dt: = 0.0) -> void :
	clear_smoke(at, float(Config.Hose.Fog.Smoke) * amount)
	cool_gas(at, amount)
	if player != null and dt > 0.0:
		_steam(at, player, dt)


func _steam(at: Vector3, player: Player, dt: float) -> void :
	if incident.is_empty() or Net.is_client():
		return
	var building: Building = incident["group"]["building"]
	var room: Variant = building.room_at(at - Vector3(0, 0.6, 0))
	if room == null or not incident["rooms"].has(room["name"]):
		return
	var state: Dictionary = incident["rooms"][room["name"]]
	var steam: Dictionary = settings()["Steam"]
	var now: = Game.now()
	var gas: Dictionary = settings()["GasCooling"]
	if now - float(state.get("steam_last", -100.0)) > float(gas["PulseGap"]):
		state["steam_from"] = now
	state["steam_last"] = now
	var held: = now - float(state["steam_from"])
	if held <= float(gas["PulseLength"]) or float(state.get("warmth", 0.0)) < float(steam["MinHeat"]):
		return
	if int(incident.get("ways", {}).get(room["name"], 0)) > 0:
		return
	player.take_damage(float(steam["Damage"]) * (1.0 - float(steam["Gear"]) * player.heat_protection()) * dt)
	if now - float(player.get_attr("SteamTold", -100.0)) > float(steam["TellEvery"]):
		player.set_attr("SteamTold", now)
		Game.tell(player, Text.m("calls.fire.read.steam"))






func cool_gas(at: Vector3, amount: float) -> float:
	if incident.is_empty() or Net.is_client() or amount <= 0.0:
		return 0.0
	var building: Building = incident["group"]["building"]
	if not building is House:
		return 0.0
	var house: = building as House

	var inside: = at - Vector3(0, 0.6, 0)
	var room: Variant = house.room_at(inside)
	if room == null or not incident["rooms"].has(room["name"]) or house.below_smoke(room, inside):
		return 0.0
	var gas: Dictionary = settings()["GasCooling"]
	var state: Dictionary = incident["rooms"][room["name"]]
	var now: = Game.now()
	if now - float(state.get("fog_last", -100.0)) > float(gas["PulseGap"]):
		state["fog_from"] = now
	state["fog_last"] = now
	var share: float = 1.0 if now - float(state["fog_from"]) <= float(gas["PulseLength"]) else float(gas["LongShare"])
	var before: = float(state.get("cooled", 0.0))
	state["cooled"] = minf(float(gas["Most"]), before + float(gas["Rate"]) * amount * share)
	return float(state["cooled"]) - before





func available() -> bool:
	for building in buildings:
		if not building.ruined:
			return true
	return false



func run() -> bool:
	if Net.is_client():
		return false
	var candidates: Array[Building] = []
	var tickets: = 0.0
	for building in buildings:
		if not building.ruined:
			candidates.append(building)
			tickets += building.weight

	while not candidates.is_empty():
		var drawn: = randf() * tickets
		var chosen: Building = candidates[candidates.size() - 1]
		for building in candidates:
			drawn -= building.weight
			if drawn <= 0.0:
				chosen = building
				break
		if FireAccess.fightable(chosen):
			await run_incident(chosen)
			return true
		candidates.erase(chosen)
		tickets -= chosen.weight
	return false














func _net_flames() -> Variant:
	var burning: = PackedByteArray()
	var embers: = PackedInt32Array()
	var lone: Array = []
	var index: = -1
	if not incident.is_empty():
		var nodes: Array = incident["group"]["nodes"]
		index = buildings.find(incident["group"]["building"])
		if index >= 0:
			burning.resize(nodes.size() * 2)
		for at in nodes.size():
			var node: Dictionary = nodes[at]
			if not node["burning"]:
				continue
			if index >= 0:
				burning[at * 2] = 1 + int(round(clampf(node["intensity"], 0.0, 1.0) * 254.0))
				burning[at * 2 + 1] = int(round(_progress(node) * 255.0))
			else:

				lone.append([1000000 + at, node["position"], snappedf(node["intensity"], 0.01), snappedf(_progress(node), 0.01)])
		if index >= 0:
			for ember: Dictionary in incident.get("embers", []):
				embers.append(int(ember["node"]["index"]))
	for made: Dictionary in spots:
		lone.append([made["id"], made["position"], snappedf(made["intensity"], 0.01), snappedf(_progress(made), 0.01)])
	var warm: = PackedByteArray()
	if index >= 0:
		var found: = _warming()
		for at: int in found:
			if at < 65536:
				warm.append_array([at >> 8, at & 255, int(clampf(found[at][1], 0.0, 1.0) * 255.0)])
	return {"b": index, "n": burning, "e": embers, "s": lone, "w": warm}


func _net_apply_flames(state: Variant) -> void :
	if not Net.is_client():
		return
	var flames: = {}
	var hot: = {}
	var index: int = state["b"]
	_net_building = index
	if index >= 0 and index < buildings.size():
		var nodes: Array = _group_of(buildings[index])["nodes"]
		var burning: PackedByteArray = state["n"]
		for at in mini(nodes.size(), burning.size() / 2):
			if burning[at * 2] > 0:
				flames[index * 10000 + at] = [nodes[at]["position"], (burning[at * 2] - 1) / 254.0, burning[at * 2 + 1] / 255.0]
		for at: int in state["e"]:
			if at < nodes.size():
				hot[index * 10000 + at] = nodes[at]["position"]
	for entry: Array in state["s"]:
		flames[ - int(entry[0])] = [entry[1], entry[2], entry[3]]
	for key: int in _net_shown.keys():
		if not flames.has(key):
			if is_instance_valid(_net_shown[key]):
				_net_shown[key].queue_free()
			_net_shown.erase(key)
	for key: int in flames:
		var flame: Flame = _net_shown.get(key)
		if flame == null or not is_instance_valid(flame):
			flame = _make_flame(flames[key][0])
			_net_shown[key] = flame
		flame.intensity = flames[key][1]
		flame.progress = flames[key][2]
	var warm: = {}
	if index >= 0 and index < buildings.size():
		var nodes: Array = _group_of(buildings[index])["nodes"]
		var told: PackedByteArray = state.get("w", PackedByteArray())
		for at in range(0, told.size() - 2, 3):
			var node_at: = (told[at] << 8) | told[at + 1]
			if node_at < nodes.size():
				warm[node_at] = [nodes[node_at]["position"], told[at + 2] / 255.0]
	_show_warming(warm)
	for key: int in _net_embers.keys():
		if not hot.has(key):
			if is_instance_valid(_net_embers[key]):
				_net_embers[key].queue_free()
			_net_embers.erase(key)
	for key: int in hot:
		if not is_instance_valid(_net_embers.get(key)):
			var marker: = Ember.new()
			add_child(marker)
			marker.global_position = hot[key]
			_net_embers[key] = marker



func _net_buildings() -> Variant:
	var all: = {}
	for index in buildings.size():
		var state: = buildings[index].net_state()
		if not state.is_empty():
			all[index] = state
	return all


func _net_apply_buildings(all: Variant) -> void :
	if not Net.is_client():
		return
	var quiet: = _net_fresh
	_net_fresh = false
	for index: int in all:
		if index >= 0 and index < buildings.size():
			_net_touched[index] = true
			buildings[index].net_apply(all[index], _group_of(buildings[index])["nodes"], quiet)
	for index: int in _net_touched.keys():
		if not all.has(index):
			_net_touched.erase(index)
			buildings[index].net_apply({}, _group_of(buildings[index])["nodes"], quiet)



func _net_smoke_at(at: Vector3) -> float:
	if _net_building < 0 or _net_building >= buildings.size():
		return 0.0
	var radius: float = settings()["SmokeRadius"]
	var level: = 0.0
	var room: Variant = buildings[_net_building].room_at(at)
	if room != null:
		level = room.get("level", 0.0)
	for key: int in _net_shown:
		if key >= 0 and is_instance_valid(_net_shown[key]):
			var distance: float = _net_shown[key].global_position.distance_to(at)
			level = maxf(level, clampf((radius - distance) / (radius * 0.6), 0.0, 1.0))
	return level



func _on_net_started() -> void :
	if not Net.is_client():
		return
	_net_fresh = true
	_runs += 1
	_show_warming({})
	if not incident.is_empty():
		var building: Building = incident["group"]["building"]
		for node: Dictionary in incident["group"]["nodes"]:
			if node["burning"]:
				_douse(node)
		for ember: Dictionary in incident.get("embers", []):
			if is_instance_valid(ember["marker"]):
				ember["marker"].queue_free()
		for key: String in ["control", "marker"]:
			if is_instance_valid(incident.get(key)):
				incident[key].queue_free()
		Victims.finish()
		Escalation.reset()
		incident = {}
		building.restore_colors()
		building.restore()
	for made: Dictionary in spots.duplicate():
		end_spot(made)



func _on_net_stopped() -> void :
	_show_warming({})
	for shown: Dictionary in [_net_shown, _net_embers]:
		for key: int in shown:
			if is_instance_valid(shown[key]):
				shown[key].queue_free()
		shown.clear()
	_net_building = -1
	for index: int in _net_touched:
		buildings[index].net_apply({}, _group_of(buildings[index])["nodes"], true)
	_net_touched.clear()
	CallMarker.net_clear()
