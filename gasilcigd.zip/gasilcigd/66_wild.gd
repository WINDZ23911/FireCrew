extends RefCounted













const TREE_SCALE: = 1.9
const AWAY_FROM_BUILDINGS: = 30.0
const WAYS: = ["road", "lane", "path", "driveway", "parking", "crossover", "pavement", "paving", "forecourt", "bus_station", "plaza", "kerbstone", "court", "playground"]
const HEDGE_STEP: = 7.0
const HEDGE_OUT: = 3.0
const HEDGED: = 0.45
const SCRUB_AREA: = 900.0
const FARM_ALONE: = 110.0

const BARK: = Color8(98, 72, 52)
const STONES: = [Color8(150, 148, 142), Color8(128, 126, 122), Color8(166, 160, 150)]


static func apply(kit: PolishKit) -> String:
	var parent: = kit.own_folder("Wild")
	var rng: = kit.rng("wild")
	var counts: = {"shrubs": 0, "trees": 0, "stones": 0}
	var store: = kit.store
	var fields: Array = []
	var scrub: Array = []
	for row in kit.rows_under("Map/Surfaces"):
		match store.name_at(row):
			"field":
				fields.append(row)
			"scrub":
				scrub.append(row)
	for row: int in fields:
		_hedges(kit, parent, row, rng, counts)
	for row: int in scrub:
		_scrub(kit, parent, row, rng, counts)
	_railway(kit, parent, rng, counts)
	_farms(kit, parent, rng, counts)
	return "wild: %d shrubs, %d trees, %d stone heaps by field edges, scrub, the railway and farms" % [counts["shrubs"], counts["trees"], counts["stones"]]



static func _free(kit: PolishKit, at: Vector3, room: float) -> bool:
	if kit.building_distance(at, AWAY_FROM_BUILDINGS) < AWAY_FROM_BUILDINGS:
		return false
	return kit.open_ground(at, room) and not _near_way(kit, at, room + 5.0)



static func _hedges(kit: PolishKit, parent: int, row: int, rng: RandomNumberGenerator, counts: Dictionary) -> void :
	var store: = kit.store
	var place: = store.transform(row).orthonormalized()
	var half: = store.size(row) / 2.0
	for side in 4:
		var normal: Vector3 = [Vector3.RIGHT, Vector3.LEFT, Vector3.BACK, Vector3.FORWARD][side]
		var along: = Vector3(normal.z, 0, - normal.x)
		var reach: float = half.z if side < 2 else half.x
		var out: float = half.x if side < 2 else half.z
		var middle: = place * (normal * (out + HEDGE_OUT))
		if reach < 10.0 or kit.surface_at(middle) == "field":
			continue
		var roll: = rng.randf()
		if roll > HEDGED:
			continue
		var trees_only: = roll < HEDGED * 0.2
		var s: = - reach + 2.0
		while s < reach - 2.0:
			var at: = place * (normal * (out + HEDGE_OUT) + along * s)
			at.y = 0.0
			s += HEDGE_STEP * (3.0 if trees_only else 1.0)
			var gap: = rng.randf()
			if gap < 0.32:
				continue
			if (trees_only or gap > 0.86) and _free(kit, at, 6.0):
				_tree(kit, parent, at, rng, rng.randf() < 0.15)
				counts["trees"] += 1
			elif not trees_only and _free(kit, at, 2.5):
				_shrub(kit, parent, at, rng)
				counts["shrubs"] += 1

		if not trees_only and rng.randf() < 0.5:
			var corner: = place * (normal * (out - 7.0) + along * (reach - 8.0) * (1.0 if rng.randf() < 0.5 else -1.0))
			corner.y = 0.0
			if kit.open_ground(corner, 2.5):
				_stones(kit, parent, corner, rng)
				counts["stones"] += 1



static func _scrub(kit: PolishKit, parent: int, row: int, rng: RandomNumberGenerator, counts: Dictionary) -> void :
	var store: = kit.store
	var place: = store.transform(row).orthonormalized()
	var half: = store.size(row) / 2.0
	var area: = half.x * half.z * 4.0
	var clumps: = floori(area / SCRUB_AREA + rng.randf())
	for clump in clumps:
		var middle: = place * Vector3(rng.randf_range( - half.x, half.x) * 0.8, 0, rng.randf_range( - half.z, half.z) * 0.8)
		middle.y = 0.0
		if not _free(kit, middle, 2.5):
			continue
		if rng.randf() < 0.5 and _free(kit, middle, 5.0):
			_tree(kit, parent, middle, rng, false)
			counts["trees"] += 1
		for more in rng.randi_range(2, 4):
			var at: = middle + Vector3.FORWARD.rotated(Vector3.UP, rng.randf_range(0.0, TAU)) * rng.randf_range(4.0, 8.0)
			if _free(kit, at, 2.5):
				_shrub(kit, parent, at, rng)
				counts["shrubs"] += 1



static func _railway(kit: PolishKit, parent: int, rng: RandomNumberGenerator, counts: Dictionary) -> void :
	var noise: = FastNoiseLite.new()
	noise.seed = 4243
	noise.frequency = 1.0 / 180.0
	for side: float in [-1.0, 1.0]:
		var x: = Train.FROM_X + 60.0
		while x < Train.TO_X - 60.0:
			x += rng.randf_range(20.0, 32.0)
			if noise.get_noise_2d(x, side * 100.0) < 0.05:
				continue
			var at: = Vector3(x, 0, Train.LINE_Z + side * rng.randf_range(15.0, 22.0))
			if rng.randf() < 0.3 and _free(kit, at, 6.0):
				_tree(kit, parent, at, rng, false)
				counts["trees"] += 1
			elif _free(kit, at, 2.5):
				_shrub(kit, parent, at, rng)
				counts["shrubs"] += 1



static func _farms(kit: PolishKit, parent: int, rng: RandomNumberGenerator, counts: Dictionary) -> void :
	var buildings: Array = kit.layout()["buildings"]
	for building: Dictionary in buildings:
		if not building["kind"] in ["house", "outbuilding"]:
			continue
		var spot: = Vector2(float(building["x"]), float(building["z"]))
		var near: = 0
		for other: Dictionary in buildings:
			if spot.distance_to(Vector2(float(other["x"]), float(other["z"]))) < FARM_ALONE:
				near += 1
		if near > 2:
			continue
		var turn: = Basis(Vector3.UP, deg_to_rad(float(building.get("yaw", 0.0))))
		var behind: = turn * Vector3(0, 0, float(building.get("depth", 30.0)) / 2.0 + 16.0)
		for index in rng.randi_range(1, 2):
			var at: = Vector3(spot.x, 0, spot.y) + behind + turn * Vector3(rng.randf_range(-14.0, 14.0), 0, rng.randf_range(0.0, 10.0))
			if kit.open_ground(at, 6.0) and not _near_way(kit, at, 8.0):
				_tree(kit, parent, at, rng, false)
				counts["trees"] += 1
		var bush: = Vector3(spot.x, 0, spot.y) + behind + turn * Vector3(rng.randf_range(-18.0, 18.0), 0, -6.0)
		if kit.open_ground(bush, 2.5) and not _near_way(kit, bush, 6.0):
			_shrub(kit, parent, bush, rng)
			counts["shrubs"] += 1




static func _near_way(kit: PolishKit, at: Vector3, reach: float) -> bool:
	for index in 8:
		var angle: = index * TAU / 8.0
		for out: float in [reach * 0.5, reach]:
			if WAYS.has(kit.surface_at(at + Vector3(cos(angle), 0, sin(angle)) * out)):
				return true
	return WAYS.has(kit.surface_at(at))


static func _shrub(kit: PolishKit, parent: int, at: Vector3, rng: RandomNumberGenerator) -> void :
	var green: = Color8(58, 104, 56).lerp(Color8(102, 140, 66), rng.randf())
	var size: = rng.randf_range(0.8, 1.5)
	var turn: = rng.randf_range(0.0, TAU)
	var balls: = [[0.0, 1.8, 0.0, 5.0], [1.8, 1.4, 0.6, 3.6], [-1.5, 1.2, -1.0, 3.2]]
	for index in rng.randi_range(2, 3):
		var ball: Array = balls[index]
		var offset: = Vector3(ball[0], 0, ball[2]).rotated(Vector3.UP, turn) * size
		kit.ball(parent, at + offset + Vector3(0, float(ball[1]) * size, 0), Vector3.ONE * float(ball[3]) * size, green.darkened(index * 0.05), "LeafyGrass", "WildShrub")



static func _tree(kit: PolishKit, folder: int, at: Vector3, rng: RandomNumberGenerator, conifer: bool) -> void :
	var parent: = kit.store.add_node(folder, "Model", "WildTree")
	var size: = rng.randf_range(0.8, 1.3) * TREE_SCALE
	var trunk: = (5.0 if conifer else 9.0) * size
	kit.post(parent, at + Vector3(0, -0.5, 0), trunk + 0.5, 1.5 * size, BARK, "Wood", "Trunk", PolishKit.SOLID)
	var turn: = rng.randf_range(0.0, TAU)
	if conifer:
		var green: = Color8(46, 92, 60).lerp(Color8(60, 110, 70), rng.randf())
		for tier in 4:
			var width: = (11.0 - tier * 2.6) * size
			kit.post(parent, at + Vector3(0, trunk + (1.6 + tier * 3.6) * size - 2.1 * size, 0), 4.2 * size, width, green, "LeafyGrass", "Needles")
		return
	var leaf: = Color8(74, 124, 62).lerp(Color8(104, 148, 70), rng.randf())
	for ball: Array in [[0.0, 3.0, 0.0, 13.0], [3.0, 6.5, 1.5, 9.0], [-2.5, 6.0, -2.0, 8.5]]:
		var offset: = Vector3(float(ball[0]) + rng.randf_range(-0.6, 0.6), 0, float(ball[2]) + rng.randf_range(-0.6, 0.6)).rotated(Vector3.UP, turn) * size
		kit.ball(parent, at + offset + Vector3(0, trunk + float(ball[1]) * size, 0), Vector3.ONE * float(ball[3]) * size * rng.randf_range(0.92, 1.08), leaf, "LeafyGrass", "Leaves")



static func _stones(kit: PolishKit, parent: int, at: Vector3, rng: RandomNumberGenerator) -> void :
	for index in rng.randi_range(1, 3):
		var size: = Vector3(rng.randf_range(1.6, 4.2), rng.randf_range(1.0, 2.4), rng.randf_range(1.4, 3.6))
		if index > 0:
			size *= 0.6
		var spot: = at + Vector3(rng.randf_range(-2.5, 2.5), size.y * 0.15, rng.randf_range(-2.5, 2.5))
		var place: = Transform3D(Basis(Vector3.UP, rng.randf_range(0.0, TAU)).rotated(Vector3.RIGHT, rng.randf_range(-0.2, 0.2)), spot)
		var color: Color = STONES[rng.randi_range(0, STONES.size() - 1)]
		var flags: = PolishKit.SOLID if size.x > 3.0 else PolishKit.LOOK
		kit._made(kit.store.add(PartStore.Shape.ELLIPSOID, place, size, color, "Concrete", "WildStone", parent, flags))
