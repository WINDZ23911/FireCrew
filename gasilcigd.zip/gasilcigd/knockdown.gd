extends ProofDebug





func _scenario_signdump() -> void :
	await _wait(1.0)
	var store: = Game.store
	var count: = 0
	for part_name: String in ["SignPost", "SignalPost", "Sign", "StreetSignPost"]:
		var rows: = store.rows_named(part_name)
		print("signdump: %d parts named %s" % [rows.size(), part_name])
		for row in rows.slice(0, 3):
			var parent: = store.parent(row)
			var node: Variant = store.nodes.get(parent)
			print("signdump:  row %d id %d at %s size %s flags %d material %s parent %d (%s '%s')" % [row, store.id_at(row), store.position(row), store.size(row), store.flags(row), store.material(row), parent, node["c"] if node else "?", node["n"] if node else "?"])
			var siblings: PackedInt32Array = store.rows_under.get(parent, PackedInt32Array())
			for other in siblings.slice(0, 8):
				print("signdump:     sibling row %d '%s' at %s size %s flags %d" % [other, store.name_at(other), store.position(other), store.size(other), store.flags(other)])
			for child_id: int in store.nodes_under.get(store.id_at(row), []):
				var child: Dictionary = store.nodes[child_id]
				print("signdump:     child node %s '%s' %s" % [child["c"], child["n"], str(child.get("v", {})).left(80)])
			count += 1
	await _done()


func _scenario_knockdown() -> void :
	await _wait(1.0)
	var service: = Knockdowns.current
	if not _check(service != null and service.posts.size() > 200, "the sign posts are knockdowns"):
		await _done()
		return
	Config.Signs["Down"] = 4.0
	var pumper: = Vehicle.named("Fire Truck")


	var here: = Vector3(-12, 0, -22)
	var sorted: = service.posts.duplicate()
	sorted.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return (a["foot"] as Vector3).distance_to(here) < (b["foot"] as Vector3).distance_to(here))
	var post: Dictionary = {}
	var toward: = Vector3.FORWARD
	var start: = Vector3.ZERO
	for candidate: Dictionary in sorted:
		var foot_at: Vector3 = candidate["foot"]

		if Array(candidate["plates"]).any( func(row: int) -> bool: return Game.store.name_at(row) == "hydrant"):
			continue
		for angle in 8:
			var way: = Vector3(cos(angle * TAU / 8.0), 0.0, sin(angle * TAU / 8.0))
			var from: = foot_at + way * 26.0
			var ground: = Game.world.raycast(from + Vector3(0, 3, 0), from + Vector3(0, -12, 0), World.LAYER_SOLID)
			if ground.is_empty() or Game.store.material(Game.world.row_hit(ground)) not in World.FAR_HARD:
				continue
			var beyond: = foot_at - way * 24.0
			var far_ground: = Game.world.raycast(beyond + Vector3(0, 3, 0), beyond + Vector3(0, -12, 0), World.LAYER_SOLID)
			if far_ground.is_empty() or Game.store.material(Game.world.row_hit(far_ground)) not in World.FAR_HARD:
				continue


			var side: = way.cross(Vector3.UP)
			var clear: = true
			for lateral: float in [-6.5, -3.0, 0.0, 3.0, 6.5]:
				for height: float in [0.6, 1.5, 4.0, 7.5]:
					var a: = from + side * lateral + Vector3(0, height, 0)
					var b: = beyond + side * lateral + Vector3(0, height, 0)

					if not Game.world.raycast(a, foot_at + way * 1.2 + side * lateral + Vector3(0, height, 0), World.LAYER_SOLID).is_empty():
						clear = false
					if not Game.world.raycast(foot_at - way * 1.2 + side * lateral + Vector3(0, height, 0), b, World.LAYER_SOLID).is_empty():
						clear = false
			if not clear:
				continue
			if not Game.world.raycast(ground["position"] + Vector3(0, 1, 0), ground["position"] + Vector3(0, 40, 0), World.LAYER_SOLID).is_empty():
				continue
			if not Game.world.raycast(far_ground["position"] + Vector3(0, 1, 0), far_ground["position"] + Vector3(0, 40, 0), World.LAYER_SOLID).is_empty():
				continue
			post = candidate
			toward = way
			start = ground["position"]
			break
		if not post.is_empty():
			break
	if not _check( not post.is_empty(), "a post with a road before it"):
		await _done()
		return
	var foot: Vector3 = post["foot"]
	_park(pumper, start + Vector3(0, 0.5, 0))
	await _wait(0.5)
	pumper.look_at(Vector3(foot.x, pumper.global_position.y, foot.z), Vector3.UP)
	await _wait(0.8)
	print("knockdown: post %d (%s) at %s, %d plates; pumper at %s facing it" % [post["id"], post["kind"], foot, post["plates"].size(), pumper.global_position])
	var cash_before: = int(player.get_attr("Cash", 0))
	pumper._board(player, "DoorCabLeft")
	await _wait(0.3)
	_check(pumper.driver() == player, "the player drives the pumper")
	_view(foot + toward * 12.0 + toward.cross(Vector3.UP) * 9.0 + Vector3(0, 6, 0), foot + Vector3(0, 4, 0))

	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void : print("knockdown: told '%s' (%s)" % [Text.say(text, "en"), kind]))
	player.set_attr("Cash", 500)
	cash_before = 500
	pumper.drive.speed = 20.0
	var waited: = 0.0
	while not post["down"] and waited < 6.0:
		pumper.drive.speed = maxf(pumper.drive.speed, 16.0)
		await get_tree().physics_frame
		waited += 1.0 / 60.0
	await _wait(0.8)
	var pivot: Node3D = post["pivot"]
	print("knockdown: down %s after %.1f s; tilt %.2f; cash %d -> %d; pumper speed %.1f at %s" % [post["down"], waited, service._tilt_of(pivot) if pivot else -1.0, cash_before, int(player.get_attr("Cash", 0)), pumper.forward_speed, pumper.global_position])
	_check(post["down"], "driven at, the post is knocked down")
	_check(pivot != null and service._tilt_of(pivot) > 0.8, "it lies over")
	_check(int(player.get_attr("Cash", 0)) == cash_before - int(Config.Signs.Fine), "the driver pays the fine")
	_check(pumper.global_position.distance_to(start) > 20.0, "the pumper drove on through it")
	await _snap("down")

	pumper.drive.speed = 16.0
	await _wait(1.5)
	await _wait(float(Config.Signs.Down) + 2.5)
	print("knockdown: down %s, tilt %.2f, shape disabled %s" % [post["down"], service._tilt_of(pivot) if pivot else -1.0, (post["shape"] as CollisionShape3D).disabled])
	_check( not post["down"] and pivot != null and service._tilt_of(pivot) < 0.05, "it stands again after its time")
	_check( not (post["shape"] as CollisionShape3D).disabled, "and is solid again")
	await _snap("up")
	await _done()


func _scenario_signground() -> void :
	await _wait(1.0)
	var service: = Knockdowns.current
	var here: = Vector3(-12, 0, -22)
	var sorted: = service.posts.duplicate()
	sorted.sort_custom( func(a: Dictionary, b: Dictionary) -> bool: return (a["foot"] as Vector3).distance_to(here) < (b["foot"] as Vector3).distance_to(here))
	for candidate: Dictionary in sorted.slice(0, 4):
		var foot_at: Vector3 = candidate["foot"]
		var said: Array = []
		for angle in 8:
			var way: = Vector3(cos(angle * TAU / 8.0), 0.0, sin(angle * TAU / 8.0))
			var from: = foot_at + way * 26.0
			var ground: = Game.world.raycast(from + Vector3(0, 12, 0), from + Vector3(0, -12, 0), World.LAYER_SOLID)
			var row: = Game.world.row_hit(ground) if not ground.is_empty() else -2
			said.append("%d:%s/%s" % [angle, Game.store.material(row) if row >= 0 else str(row), Game.store.name_at(row) if row >= 0 else "-"])
		print("signground: post %d at %s: %s" % [candidate["id"], foot_at, " ".join(said)])
	await _done()
