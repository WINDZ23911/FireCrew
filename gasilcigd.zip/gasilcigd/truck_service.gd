class_name TruckService
extends Node





const SECURE_SPEED: = 5.0
const GARAGE_DEPTH: = 48.8
const GARAGE_MARGIN: = 2.0
const STOWED: = 1.5
const ARROW_REACH: = 90.0
const ARROW_EVERY: = 1.0

var _fuel_state: Dictionary = {}
var _masts: Dictionary = {}
var _clock: = 0.0
var _arrow_clock: = 0.0


var impacts: = 0
var _impacts_call: = -1.0

static var current: TruckService


func _init() -> void :
	current = self


func _ready() -> void :
	for vehicle in Vehicle.all:
		vehicle.driver_changed.connect( func(driver: Player) -> void : _on_driver(vehicle, driver))
		if vehicle.data.has("mast"):
			_build_mast(vehicle)

	Net.share("truck.masts", func() -> Variant:
		var up: = {}
		for vehicle: Vehicle in _masts:
			up[String(vehicle.get_path())] = _masts[vehicle]["up"]
		return up
	, func(up: Variant) -> void :
		for path: String in up:
			var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
			if vehicle != null and _masts.has(vehicle):
				set_mast(vehicle, up[path])
	, 4.0)
	Net.handle("truck.mast", func(player: Player, path: String) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null and vehicle.driver() == player:
			toggle_mast(vehicle, player)
	)

	Net.handle("vehicle.impact", func(player: Player, path: String, kmh: float) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null:
			impact(vehicle, player, kmh)
	)
	Net.handle("vehicle.thud", func(path: String, kmh: float) -> void :
		var vehicle: = get_node_or_null(NodePath(path)) as Vehicle
		if vehicle != null and not vehicle.is_mine():
			vehicle.thud(kmh)
	)
	var roles: = VehicleRoles.new()
	roles.name = "VehicleRoles"
	add_child(roles)
	_debug.call_deferred()




func impact(vehicle: Vehicle, player: Player, kmh: float) -> void :
	var driver: = vehicle.driver()
	if driver == null or not (player == driver or (driver.brain != null and player == Game.local_player)):
		return
	Net.broadcast("vehicle.thud", [String(vehicle.get_path()), kmh])
	if player != Game.local_player:
		vehicle.thud(kmh)
	if OS.get_cmdline_user_args().has("--drive-trace"):
		print("drive: %s hit something at %.0f km/h, %s at the wheel" % [vehicle.name, kmh, driver.display_name])
	if driver.brain != null or kmh < float(Config.Drive.CleanKmh) or not _on_call():
		return
	impacts += 1
	if impacts == 1:
		Game.notify(Text.f("gear.truck.impact", [Ui.speed(kmh)]), "warning", driver)
	Alarm.check("cleanDrive", false)
	Alarm.note(driver, "impacts")



func _on_call() -> bool:
	if not Alarm.active or not Game.incident.has("pos"):
		return false
	if _impacts_call != Alarm.started_at:
		_impacts_call = Alarm.started_at
		impacts = 0
	return true




func _clean_drive() -> void :
	if not _on_call() or Alarm.checks.has("cleanDrive"):
		return
	var reach: = float(Config.Fire.ArriveRange)
	for vehicle in Vehicle.all:
		var driver: = vehicle.driver()
		if driver != null and driver.brain == null and vehicle.global_position.distance_to(Game.incident["pos"]) <= reach:
			Alarm.check("cleanDrive", impacts == 0)
			return




func _arrows_turn_traffic() -> void :
	if Traffic.current == null:
		return
	for vehicle in Vehicle.all:
		if vehicle.arrows == 0 or absf(vehicle.forward_speed) > SECURE_SPEED:
			continue
		var tail: = vehicle.global_transform * Vector3(0, 0, float(vehicle.data["rear"]))
		var went: = Traffic.current.wave_off(tail, vehicle.global_basis.z, ARROW_REACH)
		if went > 0 and OS.get_cmdline_user_args().has("--drive-trace"):
			print("arrows: %d cars turned off behind %s" % [went, vehicle.name])




func _on_driver(vehicle: Vehicle, driver: Player) -> void :
	if driver != null or vehicle.locked or Net.is_client():
		return
	var station: = Game.station
	var at: = vehicle.global_position
	if at.z > station.front or at.z < station.front - GARAGE_DEPTH:
		return
	for bay: Dictionary in station.record["bays"]:
		if absf(at.x - bay["x"]) < bay["width"] / 2.0:
			var out: = - vehicle.global_basis.z.z > 0.0
			var nose: float = - vehicle.data["front"]
			var tail: float = vehicle.data["rear"]
			var ahead: = nose if out else tail
			var behind: = tail if out else nose
			var z: = clampf(at.z, station.front - GARAGE_DEPTH + behind + GARAGE_MARGIN, station.front - ahead - GARAGE_MARGIN)
			var spawn: Transform3D = vehicle.spec["spawn"]
			_stand(vehicle, Transform3D(Basis(Vector3.UP, PI if out else 0.0), Vector3(bay["x"], spawn.origin.y, z)))


			vehicle.blue_on = false
			vehicle.headlights_on = false
			return


func _stand(vehicle: Vehicle, place: Transform3D) -> void :
	vehicle.global_transform = place
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.angular_velocity = Vector3.ZERO
	vehicle.drive.speed = 0.0
	vehicle.drive.steer = 0.0
	vehicle.reset_physics_interpolation()


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_clock += delta
	for vehicle in Vehicle.all:
		if vehicle.global_position.y < -30.0:
			_stand(vehicle, vehicle.spec["spawn"])
		if absf(vehicle.forward_speed) > SECURE_SPEED:
			for door_name: String in vehicle.doors:
				if vehicle.doors[door_name]["open"]:
					vehicle.set_door(door_name, false)
			if vehicle.lockers_open():
				vehicle.set_lockers(false)
			if _masts.has(vehicle) and _masts[vehicle]["up"]:
				set_mast(vehicle, false)
		if vehicle.driver() == null and vehicle.siren != 0:
			vehicle.siren = 0
	if _clock < 0.25:
		return
	_clock = 0.0
	_clean_drive()
	_arrow_clock += 0.25
	if _arrow_clock >= ARROW_EVERY:
		_arrow_clock = 0.0
		_arrows_turn_traffic()
	for vehicle in Vehicle.all:


		var state: Dictionary = _fuel_state.get(vehicle, {"warned": false, "out": false})
		_fuel_state[vehicle] = state
		var low: bool = vehicle.fuel / vehicle.fuel_capacity < float(Config.Truck.Fuel.Low)
		var driver: = vehicle.driver()
		if not low:
			state["warned"] = false
			state["out"] = false
		elif driver != null:
			if vehicle.fuel <= 0.0 and not state["out"]:
				state["out"] = true
				state["warned"] = true
				Game.notify(Text.m("gear.truck.fuelOut"), "danger", driver)
			elif not state["warned"]:
				state["warned"] = true
				Game.notify(Text.m("gear.truck.fuelLowStation"), "warning", driver)





func _build_mast(vehicle: Vehicle) -> void :
	var settings: Dictionary = Config.Truck.Mast
	var foot: = vehicle.v(vehicle.data["mast"])
	var pole: = vehicle.add_part("MastPole", Vector3(0.26, 1.0, 0.26), Transform3D(Basis.IDENTITY, foot), Color(170 / 255.0, 174 / 255.0, 180 / 255.0), PartStore.Shape.BLOCK, "Metal")
	var head: = Node3D.new()
	vehicle.body.add_child(head)
	vehicle.add_part("MastHead", Vector3(0.8, 0.6, 1.5), Transform3D.IDENTITY, Color(25 / 255.0, 25 / 255.0, 28 / 255.0), PartStore.Shape.BLOCK, "SmoothPlastic", head)
	var lenses: Array = []
	var lights: Array = []
	var glares: Array = []
	var tilt: = deg_to_rad(float(settings["Tilt"]))
	for side in [-1.0, 1.0]:
		var lens: = vehicle.add_part("MastLens", Vector3(0.06, 0.44, 1.3), Transform3D(Basis.IDENTITY, Vector3(side * 0.41, 0, 0)), Vehicle.LAMP_OFF, PartStore.Shape.BLOCK, "SmoothPlastic", head)
		lenses.append(lens)
		var glare: = VehicleLook.flare(head, Vector3(side * 0.5, 0, 0), Vehicle.HEAD_GLARE, 3.2, 1.0)
		glare.rotation.y = - side * PI / 2.0
		glares.append(glare)

		var beam: = SpotLight3D.new()
		beam.spot_range = float(settings["Range"]) * 1.6
		beam.spot_angle = float(settings["Angle"]) / 2.0

		beam.light_energy = float(settings["Brightness"]) * 9.0
		beam.spot_attenuation = 0.7
		Graphics.lamp_shadow(beam, side < 0.0)
		beam.visible = false
		head.add_child(beam)
		var from: = Vector3(side * 0.5, 0, 0)
		beam.transform = Rbx.look_at(from, from + Vector3(side * cos(tilt), - sin(tilt), 0))
		lights.append(beam)
	var handle: = Node3D.new()
	vehicle.add_child(handle)

	handle.position = Vector3((1.0 if foot.x > 0.0 else -1.0) * (float(vehicle.data["halfWidth"]) + 0.3), 2.6, foot.z)
	var prompt: = Prompt.make(handle, Text.m("gear.truck.mastUp"), Text.m("gear.truck.mast"), 0.0, 9.0)
	prompt.key = "mast"
	prompt.triggered.connect( func(player: Player) -> void : toggle_mast(vehicle, player))
	_masts[vehicle] = {"up": false, "amount": 0.0, "pole": pole, "head": head, "lights": lights, "lenses": lenses, "glares": glares, "prompt": prompt, "foot": foot}
	_place_mast(vehicle)


func _place_mast(vehicle: Vehicle) -> void :
	var mast: Dictionary = _masts[vehicle]
	var foot: Vector3 = mast["foot"]
	var height: float = STOWED + float(Config.Truck.Mast.Rise) * mast["amount"]
	mast["pole"].transform = Transform3D(Basis.from_scale(Vector3(0.26, height, 0.26)), foot + Vector3(0, height / 2.0, 0))
	mast["head"].position = foot + Vector3(0, height + 0.25, 0)


func _light_mast(vehicle: Vehicle, on: bool) -> void :
	var mast: Dictionary = _masts[vehicle]
	for beam: SpotLight3D in mast["lights"]:
		beam.visible = on
	for lens: MeshInstance3D in mast["lenses"]:
		var material: StandardMaterial3D = lens.material_override
		material.albedo_color = Color(1.0, 250 / 255.0, 235 / 255.0) if on else Vehicle.LAMP_OFF
		material.emission_enabled = on
		material.emission = Color(1.0, 250 / 255.0, 235 / 255.0)
		material.emission_energy_multiplier = 4.0
	for glare: MeshInstance3D in mast["glares"]:
		VehicleLook.shine(glare, VehicleLook.glare_now() if on else 0.0)



func toggle_mast(vehicle: Vehicle, player: Player) -> void :
	if not _masts.has(vehicle):
		Game.notify(Text.m("gear.truck.noMast"), "", player)
	elif absf(vehicle.forward_speed) > SECURE_SPEED:
		Game.notify(Text.m("gear.truck.mastMoving"), "", player)
	else:
		set_mast(vehicle, not _masts[vehicle]["up"])



func set_mast(vehicle: Vehicle, raise: bool) -> void :
	var mast: Dictionary = _masts[vehicle]
	if mast["up"] == raise:
		return
	mast["up"] = raise
	mast["prompt"].action = Text.m("gear.truck.mastDown" if raise else "gear.truck.mastUp")
	if not raise:
		_light_mast(vehicle, false)
	var to: = 1.0 if raise else 0.0
	var tween: = create_tween()
	tween.tween_method( func(amount: float) -> void :
		mast["amount"] = amount
		_place_mast(vehicle)
	, mast["amount"], to, maxf(0.05, float(Config.Truck.Mast.Time) * absf(to - mast["amount"])))
	tween.tween_callback( func() -> void :
		if raise and mast["up"]:
			_light_mast(vehicle, true)
	)


func _process(_delta: float) -> void :

	var player: = Game.local_player
	if player == null or Game.ui_open:
		return
	var vehicle: Variant = player.get_attr("Vehicle")
	if vehicle is Vehicle and vehicle.driver() == player and Input.is_action_just_pressed("mast"):
		Net.request("truck.mast", [String(vehicle.get_path())])











func _debug() -> void :
	var args: = OS.get_cmdline_user_args()
	var joining: = false
	for arg in args:
		joining = joining or arg.begins_with("--join=")
	for arg in args:
		if arg == "--mast=up" and not joining:
			for vehicle: Vehicle in _masts:
				set_mast(vehicle, true)
		elif arg == "--mast=key":
			_debug_key()
		elif arg == "--mast=crew" and not joining:

			Net.peer_joined.connect( func(joined: Player) -> void :
				await get_tree().create_timer(2.0).timeout
				Vehicle.named("Fire Truck")._board(joined, "DoorCabLeft")
			)
		elif arg == "--mast-trace":
			_debug_trace()
		elif arg == "--arrows-test":
			_debug_arrows()


func _debug_key() -> void :
	var player: = Game.local_player
	var sat_in: Variant = null
	while not (sat_in is Vehicle and sat_in.driver() == player):
		await get_tree().create_timer(0.2).timeout
		sat_in = player.get_attr("Vehicle")
	await get_tree().create_timer(1.0).timeout
	Net.request("truck.mast", [String(sat_in.get_path())])


func _debug_trace() -> void :
	var at: = -1
	while true:
		await get_tree().create_timer(0.1).timeout
		if (Net.is_client() and not HostClock.synced) or floori(HostClock.now() / 2.0) == at:
			continue
		at = floori(HostClock.now() / 2.0)
		for vehicle: Vehicle in _masts:
			var mast: Dictionary = _masts[vehicle]
			print("mast %d s: %s up %s amount %.2f lamps %s prompt '%s'" % [at * 2, vehicle.name, mast["up"], mast["amount"], mast["lights"][0].visible, Text.say(mast["prompt"].action, "en")])


func _debug_arrows() -> void :
	await get_tree().create_timer(8.0).timeout
	var traffic: = Traffic.current
	if traffic == null:
		print("arrows: no traffic")
		return
	var counts: = {}
	for car in traffic.vehicles:
		var id: int = car.route[car.index]
		if traffic.segments[id]["kind"] == "lane" and float(traffic.segments[id]["length"]) > 120.0:
			counts[id] = counts.get(id, 0) + 1
	var best: = -1
	for id: int in counts:
		if best < 0 or counts[id] > counts[best]:
			best = id
	if best < 0:
		print("arrows: no long lane with cars")
		return
	var segment: Dictionary = traffic.segments[best]
	var along: = float(segment["length"]) * 0.7
	var here: = NavGraph.sample(segment, along)
	var ahead: = NavGraph.sample(segment, along + 1.0)
	var way: = Vector2(ahead.x - here.x, ahead.y - here.y).normalized()
	var truck: = Vehicle.named("Fire Truck")
	truck.global_transform = Transform3D(Basis(Vector3.UP, atan2( - way.x, - way.y)), Vector3(here.x, 3.2, here.y))
	truck.linear_velocity = Vector3.ZERO
	truck.reset_physics_interpolation()
	truck.arrows = 2
	print("arrows: the pumper in lane %d at %.0f,%.0f" % [best, here.x, here.y])
	for step in 10:
		await get_tree().create_timer(5.0).timeout
		var behind: = 0
		var queued: = 0
		for car in traffic.vehicles:
			var local: = truck.global_transform.affine_inverse() * Vector3(car.x, truck.global_position.y, car.z)
			if local.z > 0.0 and local.z < 100.0 and absf(local.x) < 8.0:
				behind += 1
				if absf(car.v) < 0.5:
					queued += 1
		print("arrows %d s: %d cars behind the pumper, %d of them standing" % [(step + 1) * 5, behind, queued])
