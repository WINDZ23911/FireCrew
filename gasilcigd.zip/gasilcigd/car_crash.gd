class_name CarCrash
extends Node






























const TICK: = 0.25
const ROAD_ROOM: = 40.0
const PLAYER_ROOM: = 90.0
const STATION_ROOM: = 150.0
const TRIES: = 25
const DOOR_AJAR: = deg_to_rad(28)
const DOOR_YIELD: = 0.45
const DOOR_SHUDDER: = deg_to_rad(0.8)
const BONNET_SPRUNG: = deg_to_rad(24)
const FADE: = 2.5




const JOBS: Array[Dictionary] = [
	{"tool": "Spreader", "color": Ui.TEXT}, 
	{"tool": "Cutter", "color": Ui.TEXT}, 
	{"tool": "First aid kit", "mark": "Aid", "color": Ui.GREEN, "time": "AidTime"}, 
	{"tool": "Spinal board", "mark": "Board", "color": Ui.GREEN, "time": "BoardTime"}, 
]


const WRECK_LONGEST: = 16.8
const WRECK_PAINTS: Array[Color] = [
	Color8(92, 36, 32), Color8(36, 46, 70), Color8(44, 46, 48), 
	Color8(96, 86, 68), Color8(56, 70, 56), Color8(66, 72, 82), 
	Color8(104, 66, 40), Color8(30, 31, 33), 
]
const HYDRAULIC: = 2
const BLOCK_WOOD: = Color8(214, 168, 72)
const BOARD_ORANGE: = Color8(236, 112, 30)
const ROAD_KINDS: = ["crash", "tree"]
const HAZARD_OFF: = Color8(120, 84, 20)
const HAZARD_ON: = Color8(255, 170, 30)
const STEAM: = Color8(232, 232, 232)
const SMOKE: = Color8(70, 68, 66)
const TREE_NEAR: = 4.0
const TREE_FAR: = 12.0
const CONE_ROOM: = 6.0






const LAYOUTS: = {
	"headOn": {
		"length": 34.0, 
		"cars": [[1.3, 7.2, 15.0], [-1.1, -7.3, 176.0]], "steaming": 0, "unsprung": [], 
		"people": [[0, "L"], [1, "L"], [0, "R"]], 
		"impacts": [0.0], 
	}, 

	"side": {
		"length": 30.0, 
		"cars": [[0.0, -7.5, 98.0], [0.6, 3.5, -5.0]], "steaming": 1, "unsprung": [], 
		"people": [[1, "L"], [0, "L", "R"], [1, "R"]], 
		"impacts": [-4.0], 
	}, 
	"tail": {
		"length": 50.0, 
		"cars": [[3.0, -15.4, 3.0], [3.4, 0.0, -6.0], [2.6, 15.3, 4.0]], "steaming": 1, "unsprung": [0], 
		"people": [[1, "L"], [2, "L"], [0, "L"]], 
		"impacts": [-7.7, 7.6], 
	}, 
	"cyclist": {
		"length": 30.0, 
		"cars": [[2.6, -6.0, 6.0]], "steaming": -1, "unsprung": [0], 
		"people": [], 
		"impacts": [], 
		"bicycle": [5.2, 4.0, 40.0], 
		"thrown": [[1.4, 9.0, 70.0]], 
	}, 
}

static var current: CarCrash

var kind: = "crash"
var scene: Dictionary = {}
var position: = Vector3.ZERO
var _streets: Array = []
var _trees: Array = []
var _avoid: = Vector3.ZERO
var _last_hint: Dictionary = {}
var _serial: = 0
var _shown: Array = []
var _mirrors: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func _vector(list: Array) -> Vector3:
	return Vector3(list[0], list[1], list[2])








func wreck(into: Dictionary, place: Transform3D, look: = {}) -> Dictionary:
	var model: Node3D = into["model"]

	var shape_drawn: int = look["shape"] if look.has("shape") else randi_range(1, 1000)
	var shape: = CarKit.pick(shape_drawn, WRECK_LONGEST)
	if shape.is_empty():
		return {}
	var measures: = CarKit.data(shape)
	var paint_drawn: int = look["paint"] if look.has("paint") else randi_range(1, WRECK_PAINTS.size())
	var node: = CarKit.build(shape, WRECK_PAINTS[posmod(paint_drawn - 1, WRECK_PAINTS.size())], shape_drawn)
	model.add_child(node)
	node.global_transform = place

	var head: Array = measures["lamps"]["head"][0]
	var tail: Array = measures["lamps"]["tail"][0]
	var half_width: = absf(float(measures["doors"]["R"]["hinge"][0]))
	var roof: float = measures["roof"]
	var shell: = StaticBody3D.new()
	shell.collision_layer = World.LAYER_SOLID | World.LAYER_QUERY
	shell.collision_mask = 0
	var collider: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = Vector3(half_width * 2.0, roof - 0.8, float(tail[2]) - float(head[2]))
	collider.shape = box
	collider.position = Vector3(0, 0.8 + (roof - 0.8) / 2.0, (float(tail[2]) + float(head[2])) / 2.0)
	shell.add_child(collider)
	node.add_child(shell)


	if look.get("sprung", true):
		var bonnet: = node.get_node_or_null("Bonnet") as Node3D
		if bonnet:
			var hinge: = _vector(measures["bonnet"]["hinge"])
			bonnet.transform = Transform3D(Basis(Vector3.RIGHT, BONNET_SPRUNG), hinge) * Transform3D(Basis.IDENTITY, - hinge)
	var engine: = Node3D.new()
	engine.name = "Engine"
	node.add_child(engine)
	engine.position = _vector(measures["bonnet"]["middle"])



	for lamp: Array in [measures["lamps"]["head"][0], measures["lamps"]["head"][1], measures["lamps"]["tail"][0], measures["lamps"]["tail"][1]]:
		var outward: = -0.1 if lamp[2] < 0.0 else 0.1

		var tall: bool = lamp[2] > 0.0 and absf(lamp[0]) > 2.5
		var at: = Vector3(lamp[0] + (0.0 if tall else (-0.3 if lamp[0] < 0.0 else 0.3)), lamp[1] - (0.5 if tall else 0.0), lamp[2] + outward)
		var made: = CallKit.piece(node, CallKit.BLOCK, Vector3(0.4, 0.4, 0.2), Transform3D(Basis.IDENTITY, at), HAZARD_OFF)
		made.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		into["hazards"].append(made)

	var car: = {"place": place, "measures": measures, "node": node, "engine": engine, "steam": null, "steaming": 0, "prep": -1, "stable": false, "glass": false, "prompt": null, "index": into["wrecks"].size()}
	_set_steam(car, 1 if look.get("steaming", false) else 0)
	into["wrecks"].append({"car": car, "place": place, "shape": shape_drawn, "paint": paint_drawn, "sprung": look.get("sprung", true)})
	return car




func _set_steam(car: Dictionary, how: int) -> void :
	if car["steaming"] == how:
		return
	car["steaming"] = how
	if how == 4:
		if is_instance_valid(car["steam"]):
			car["steam"].emitting = false
		return
	if is_instance_valid(car["steam"]):
		car["steam"].queue_free()
	car["steam"] = null
	if how > 0:
		car["steam"] = RbxEmitter.make(car["engine"], _steam_look(SMOKE if how == 2 else STEAM, [0.0, 7.0, 14.0, 4.0][how]))


static func _steam_look(color: Color, rate: float) -> Dictionary:

	var smoke: = color == SMOKE
	return {
		"Mesh": ToonFire.puff_mesh(), 
		"Material": ToonFire.puff_material( not smoke), 
		"Color": ToonFire.fuel_color("black") if smoke else Color(0.86, 0.87, 0.88), 
		"Rate": rate, 
		"MaxRate": 14, 
		"Speed": [2, 4], 
		"Lifetime": [2.0, 3.2], 
		"SpreadAngle": 18, 
		"Acceleration": Vector3(0.6, 2.5, 0.3), 
		"Rotation": [0, 360], 
		"Size": [[0.0, 0.4], [0.35, 1.4], [1.0, 0.0]], 
		"Transparency": [[0.0, 1.0], [1.0, 1.0]], 
		"Direction": Vector3.UP, 
	}



func blink(of: Dictionary, waited: float) -> void :
	_light(of, fmod(waited, 1.0) < 0.5)


func _light(of: Dictionary, on: bool) -> void :
	if on != of.get("lit", false):
		of["lit"] = on
		for lamp: Variant in of["hazards"]:
			if is_instance_valid(lamp):
				lamp.material_override = CallKit.plain(HAZARD_ON, 2.5) if on else CallKit.plain(HAZARD_OFF)



func _litter(into: Dictionary, middle: Vector3, bits: = 9, drawn_from: = -1) -> void :
	var model: Node3D = into["model"]

	if drawn_from < 0:
		drawn_from = randi() & 2147483647
	into["litter"].append([middle, bits, drawn_from])
	var rng: = RandomNumberGenerator.new()
	rng.seed = drawn_from
	for index in bits:
		var glass: = rng.randf() < 0.5
		var size: = Vector3(rng.randf_range(0.3, 0.9), 0.12, rng.randf_range(0.3, 0.9))
		var at: = middle + Vector3(rng.randf_range(-7, 7), 0.2, rng.randf_range(-7, 7))
		CallKit.piece(model, CallKit.BLOCK, size, Transform3D(Basis(Vector3.UP, rng.randf() * PI), CallKit.ground_at(at) + Vector3(0, 0.06, 0)), Color8(150, 190, 200) if glass else Color8(30, 31, 34))
	var pool_at: = CallKit.ground_at(middle + Vector3(1.5, 0.16, -1)) + Vector3(0, 0.04, 0)
	var pool: = CallKit.piece(model, CallKit.CYLINDER, Vector3(0.06, 6.2, 6.2), Transform3D(Basis(Vector3.BACK, PI / 2), pool_at), Color8(26, 26, 30))
	pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF







func _prepare(of: Dictionary, car: Dictionary) -> void :
	if car["prompt"] != null:
		return
	if car["prep"] < 0:
		car["prep"] = 0
	var tail: Array = car["measures"]["lamps"]["tail"][0]
	var spot: = Node3D.new()
	spot.name = "PrepMark"
	car["node"].add_child(spot)
	spot.position = Vector3(0, 2.4, float(tail[2]) + 1.4)
	var prompt: = CallKit.prompt(spot, "crash.%d.car.%d" % [of["serial"], car["index"]], Text.m("calls.crash.prep.stabilise"), Text.m("calls.crash.prep.object"), float(Config.Incidents.Crash.StabiliseTime), 9.0)
	car["prompt"] = prompt
	prompt.triggered.connect( func(player: Player) -> void : _prep_done(of, car, player))
	_show_prep(car, of.get("closed", false))



func _prep_done(of: Dictionary, car: Dictionary, player: Player) -> void :
	if Net.is_client() or of.get("closed", false):
		return
	var settings: Dictionary = Config.Incidents.Crash
	if car["prep"] < 0:
		return
	if not car["stable"]:
		if Cordon.current == null or not Cordon.current.carries(player, "Step blocks"):
			Game.notify(Text.m("calls.crash.needBlocks"), "", player)
			return
		car["stable"] = true
		Game.notify(Text.f("calls.crash.stabilised", [player.display_name]), "good")
	elif not car["glass"]:
		car["glass"] = true
		Game.notify(Text.m("calls.crash.glassOut"), "good", player)
	else:
		return
	Sounds.once(car["prompt"], Config.Tools.Sounds.MetalGive, 1.3, 10.0, 120.0)
	of["helpers"][player] = true
	player.add_cash(int(settings["PrepReward"]))
	_show_prep(car, false)




func _show_prep(car: Dictionary, closed: bool) -> void :
	var stable: bool = car["stable"]
	var prompt: Prompt = car["prompt"]
	if prompt != null and is_instance_valid(prompt):
		prompt.action = Text.m("calls.crash.prep.stabilise" if not stable else "calls.crash.prep.glass")
		prompt.hold = float(Config.Incidents.Crash.StabiliseTime if not stable else Config.Incidents.Crash.GlassTime)
		prompt.enabled = car["prep"] >= 0 and not (stable and car["glass"]) and not closed
	var node: Node3D = car["node"]
	if not is_instance_valid(node):
		return
	if stable and not car.has("blocks"):
		car["blocks"] = true
		var half: = absf(float(car["measures"]["doors"]["R"]["hinge"][0])) - 0.5
		var head: float = car["measures"]["lamps"]["head"][0][2]
		var tail: float = car["measures"]["lamps"]["tail"][0][2]

		for x: float in [ - half, half]:
			for z: float in [head * 0.42, tail * 0.42]:
				CallKit.piece(node, CallKit.BLOCK, Vector3(1.0, 0.45, 1.8), Transform3D(Basis.IDENTITY, Vector3(x, 0.25, z)), BLOCK_WOOD)
				CallKit.piece(node, CallKit.BLOCK, Vector3(1.0, 0.45, 1.0), Transform3D(Basis.IDENTITY, Vector3(x, 0.7, z + 0.35 * signf(z))), BLOCK_WOOD.darkened(0.12))
	if car["glass"] and not car.has("glass_out"):
		car["glass_out"] = true
		var glass: = node.get_node_or_null("Glass") as Node3D
		if glass != null:
			glass.visible = false

		var rng: = RandomNumberGenerator.new()
		rng.seed = int(car["index"]) * 7919 + 17
		var half_width: = absf(float(car["measures"]["doors"]["R"]["hinge"][0]))
		for index in 8:
			var side: = -1.0 if index % 2 == 0 else 1.0
			var at: = Vector3(side * (half_width + rng.randf_range(0.4, 1.6)), 0.08, rng.randf_range(-3.0, 3.0))
			var bit: = CallKit.piece(node, CallKit.BLOCK, Vector3(rng.randf_range(0.25, 0.6), 0.08, rng.randf_range(0.25, 0.6)), Transform3D(Basis(Vector3.UP, rng.randf() * PI), at), Color8(150, 190, 200))
			bit.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF



static func unready(car: Dictionary) -> Array[bool]:
	var has: bool = int(car.get("prep", -1)) >= 0
	return [has and not car["stable"], has and not car["glass"]]



func _hurt_inside(car: Dictionary, amount: float) -> void :
	for door: Dictionary in scene.get("doors", []):
		if is_same(door["car"], car) and door["victim"] is Victim and door["stage"] <= JOBS.size():
			var victim: Victim = door["victim"]
			victim.condition = maxf(victim.condition - amount, 0.5)






func _show_job(door: Dictionary) -> void :
	var stage: int = door["stage"]
	var prompt: Prompt = door.get("prompt")
	if stage > JOBS.size():
		door["label"].visible = false
		door["bar"].visible = false
		IconChip.show_icon(door.get("chip"), "", Color.WHITE)
		if prompt != null:
			prompt.enabled = false
		return
	var job: Dictionary = JOBS[stage - 1]
	var label: Label3D = door["label"]
	label.visible = true
	door["bar"].visible = true
	label.text = Text.say(Text.m("calls.crash.marks." + job.get("mark", job["tool"])))
	label.modulate = job["color"]
	CallKit.set_bar(door["bar"], 0.0, job["color"])
	var icon: = ToolIcons.of(job["tool"])
	IconChip.show_icon(door.get("chip"), icon if not icon.is_empty() else "heart", job["color"])

	if prompt != null:
		prompt.enabled = stage > HYDRAULIC and not door.get("closed", false)
		if stage > HYDRAULIC:
			prompt.action = Text.m("calls.crash.aid.action" if job["mark"] == "Aid" else "calls.crash.aid.board")
			prompt.hold = float(Config.Incidents.Crash[job["time"]])




func _swing_door(door: Dictionary, angle: float) -> void :
	var leaf: Node3D = door["leaf"]
	if is_instance_valid(leaf):
		var hinge: Vector3 = door["hinge"]
		leaf.transform = Transform3D(Basis(Vector3.UP, door["outward"] * angle), hinge) * Transform3D(Basis.IDENTITY, - hinge)



func _drop_door(door: Dictionary) -> void :
	var leaf: Node3D = door["leaf"]
	if not is_instance_valid(leaf):
		return
	var outward: float = door["outward"]
	var hinge: Vector3 = door["hinge"]
	var foot: = Vector3(hinge.x, 1.0, 0.0)
	var tween: = leaf.create_tween()
	tween.tween_method( func(t: float) -> void :
		var swung: = Transform3D(Basis(Vector3.UP, outward * DOOR_AJAR * (1.0 - t)), hinge) * Transform3D(Basis.IDENTITY, - hinge)
		var fallen: = Transform3D(Basis(Vector3.BACK, - outward * PI / 2.0 * t), foot + Vector3(outward * 0.9, -0.85, 0) * t) * Transform3D(Basis.IDENTITY, - foot)
		leaf.transform = fallen * swung
	, 0.0, 1.0, 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)





func jam(into: Dictionary, car: Dictionary, side: String, victim: Variant, blocked: = Callable()) -> Dictionary:
	var measures: Dictionary = car["measures"]["doors"][side]
	var outward: = -1.0 if side == "L" else 1.0
	var node: Node3D = car["node"]
	var mark: = Node3D.new()
	mark.name = "DoorMark"
	node.add_child(mark)
	mark.position = _vector(measures["middle"]) + Vector3(outward * 0.6, 0.6, 0)
	var label: = CallKit.words(mark, "", Color.WHITE, 4.3)
	var chip: = IconChip.attach(mark, label, 4.3)
	var bar: = CallKit.bar(mark, 3.4, Color.WHITE, 80.0, Vector2(110, 10))
	var door: = {
		"leaf": node.get_node_or_null("DoorL" if side == "L" else "DoorR"), 
		"hinge": _vector(measures["hinge"]), 
		"outward": outward, 
		"position": mark.global_position, 
		"mark": mark, 
		"label": label, 
		"bar": bar, 
		"chip": chip, 
		"victim": victim, 
		"car": car, 
		"side": side, 
		"blocked": blocked, 
		"stage": 1, 
		"progress": 0.0, 
		"board": null, 
	}


	var prompt: = CallKit.prompt(mark, "crash.%d.door.%d" % [into["serial"], into["doors"].size()], Text.m("calls.crash.aid.action"), Text.m("calls.crash.aid.object"), float(Config.Incidents.Crash.AidTime), 9.0)
	prompt.enabled = false
	door["prompt"] = prompt
	prompt.triggered.connect( func(player: Player) -> void : _kit_job(into, door, player))
	_show_job(door)
	into["doors"].append(door)
	return door



func _kit_job(of: Dictionary, door: Dictionary, player: Player) -> void :
	var stage: int = door["stage"]
	if Net.is_client() or of.get("closed", false) or stage <= HYDRAULIC or stage > JOBS.size():
		return
	var job: Dictionary = JOBS[stage - 1]
	if Cordon.current == null or not Cordon.current.carries(player, job["tool"]):
		Game.notify(Text.m("calls.crash.needKit" if job["mark"] == "Aid" else "calls.crash.needBoard"), "", player)
		return
	of["helpers"][player] = true
	player.add_cash(int(Config.Incidents.Crash.AidReward))
	door["stage"] = stage + 1
	door["progress"] = 0.0
	if job["mark"] == "Aid":
		Game.notify(Text.f("calls.crash.aided", [player.display_name]), "good")
	else:
		_board(door)
		Game.notify(Text.m("calls.crash.boarded"), "good", player)
		of["boarded_at"] = Game.now()
	_show_job(door)



func _board(door: Dictionary) -> void :
	var victim: Variant = door["victim"]
	if not victim is Victim or VictimService.current == null or not is_instance_valid(victim.figure):
		return
	var car: Dictionary = door["car"]
	var basis: Basis = (car["place"] as Transform3D).basis
	var out: Vector3 = basis.x * float(door["outward"])


	var ground: = CallKit.floor_at(door["position"] + out * 5.0 + Vector3(0, 2, 0))
	var ambulance: = AmbulanceService.current
	for reach: float in [5.0, 4.0, 3.2]:
		for along: float in [0.0, -4.0, 4.0]:
			var spot: = CallKit.floor_at(door["position"] + out * reach + basis.z * along + Vector3(0, 2, 0))
			if ambulance == null or not ambulance.in_zone(spot + Vector3(0, 1, 0)):
				ground = spot
				break
		if ambulance == null or not ambulance.in_zone(ground + Vector3(0, 1, 0)):
			break
	VictimService.current.release(victim)
	victim.on_board = true
	victim.figure.pose("lying")
	victim.figure.global_transform = Figure.lying(ground, basis.z, 0.36)
	victim.figure.reset_physics_interpolation()
	_show_board(door, victim.figure)



func _show_board(door: Dictionary, figure: Node3D) -> void :
	if door["board"] != null and is_instance_valid(door["board"]):
		return


	var board: = CallKit.piece(figure, CallKit.BLOCK, Vector3(1.7, 6.2, 0.22), Transform3D(Basis.IDENTITY, Vector3(0, 0.6, 0.75)), BOARD_ORANGE)
	board.name = "SpinalBoard"
	door["board"] = board





func next_step(of: Dictionary, closed: bool) -> Variant:
	var engine: Variant = of.get("engine")
	var waiting: = VictimService.current != null and VictimService.current.waiting()
	if engine != null and engine["state"] in ["burning", "cabin"] and waiting:
		return Text.m("calls.crash.next.fire")
	if engine != null and engine["state"] == "smoking" and engine["left"] >= 0.0 and waiting:
		return Text.m("calls.crash.next.battery")
	if not closed and waiting:
		return Text.m("calls.crash.next.cones")
	for made: Dictionary in of["wrecks"]:
		if unready(made["car"])[0] and _anyone_in(of, made["car"]):
			return Text.m("calls.crash.next.stabilise")
	for made: Dictionary in of["wrecks"]:
		if unready(made["car"])[1] and _anyone_in(of, made["car"]):
			return Text.m("calls.crash.next.glass")
	for stage: int in range(1, JOBS.size() + 1):
		for door: Dictionary in of["doors"]:
			if door["stage"] == stage:
				return Text.m(["calls.crash.next.spreader", "calls.crash.next.cutter", "calls.crash.next.aid", "calls.crash.next.board"][stage - 1])
	if waiting:
		return Text.m("calls.crash.next.carry")
	return null



func _anyone_in(of: Dictionary, car: Dictionary) -> bool:
	for door: Dictionary in of["doors"]:
		if is_same(door["car"], car) and door["stage"] <= HYDRAULIC:
			return true
	return false



func jobs_done(of: Dictionary) -> int:
	var done: = 0
	for door: Dictionary in of["doors"]:
		done += int(door["stage"]) - 1
	for made: Dictionary in of["wrecks"]:
		if int(made["car"]["prep"]) >= 0:
			done += int(made["car"]["stable"]) + int(made["car"]["glass"])
	return done



func jobs_total(of: Dictionary) -> int:
	var total: int = of["doors"].size() * JOBS.size()
	for made: Dictionary in of["wrecks"]:
		if int(made["car"]["prep"]) >= 0:
			total += 2
	return total



func _finish_job(door: Dictionary, player: Player) -> void :
	Sounds.once(door["mark"], Config.Tools.Sounds.MetalGive, 1.0, 10.0, 140.0)
	scene["helpers"][player] = true
	player.add_cash(int(Config.Incidents.Crash.JobReward))
	if door["stage"] == 1:
		_swing_door(door, DOOR_AJAR)
		door["stage"] = 2
		door["progress"] = 0.0
		_show_job(door)
		Alarm.note(player, "doors")
		Game.notify(Text.m("calls.crash.forced"), "", player)
	else:

		door["stage"] = 3
		door["progress"] = 0.0
		_drop_door(door)
		_show_job(door)
		Game.notify(Text.m("calls.crash.doorOffAid"), "", player)





func work(player: Player, tool: String, at: Vector3, look: Vector3, dt: float) -> Array:
	if scene.is_empty() or Net.is_client():
		return [false]
	var settings: Dictionary = Config.Incidents.Crash
	var nearest: Dictionary = {}
	var nearest_distance: = INF
	for door: Dictionary in scene["doors"]:
		if door["stage"] <= HYDRAULIC:
			var offset: = Vector3(door["position"].x - at.x, 0, door["position"].z - at.z)
			var distance: = offset.length()
			var ahead: = distance < 2.5 or offset.normalized().dot(look) > 0.2
			if distance <= float(settings["Reach"]) and ahead and distance < nearest_distance:
				nearest = door
				nearest_distance = distance
	if nearest.is_empty():
		return [false]
	var job: Dictionary = JOBS[nearest["stage"] - 1]
	var blocked: Callable = nearest["blocked"]
	var in_the_way: Variant = blocked.call() if blocked.is_valid() else null
	if in_the_way != null or job["tool"] != tool:

		var now: = Game.now()
		if now - _last_hint.get(player, -100.0) > 4.0:
			_last_hint[player] = now
			if in_the_way != null:
				Game.notify(in_the_way, "", player)
			else:
				Game.notify(Text.f("calls.crash.needFirst" if nearest["stage"] == 1 else "calls.crash.needNow", [Text.named("tools", job["tool"])]), "", player)
		return [false]

	if float(scene.get("cut_at", -1.0)) < 0.0:
		scene["cut_at"] = Game.now()


	var car: Dictionary = nearest["car"]
	var unsafe: = unready(car)
	var rate: = 1.0
	if unsafe[1]:
		car["shards"] = true
		car["glass"] = true
		_hurt_inside(car, float(settings["GlassHurt"]))
		Game.notify(Text.m("calls.crash.shards"), "warning", player)
		_show_prep(car, false)
	if unsafe[0]:
		car["shaken"] = true
		rate = float(settings["Unstable"])
		_hurt_inside(car, float(settings["UnstableDrain"]) * dt)
		var now: = Game.now()
		if now - float(car.get("rocked_told", -100.0)) > 8.0:
			car["rocked_told"] = now
			Game.notify(Text.m("calls.crash.unstable"), "warning", player)
	nearest["progress"] += dt * rate
	var job_time: float = settings["JobTime"]
	var done: = minf(nearest["progress"] / job_time, 1.0)
	CallKit.set_bar(nearest["bar"], done)
	if nearest["progress"] >= job_time:
		_finish_job(nearest, player)
	else:

		var given: float = DOOR_AJAR * DOOR_YIELD * nearest["progress"] / job_time if nearest["stage"] == 1 else DOOR_AJAR
		_swing_door(nearest, given + randf_range(-1, 1) * DOOR_SHUDDER)
	return [true, done]






func open(model: Node3D) -> Dictionary:
	_serial += 1
	scene = _blank(model, _serial)
	_shown.append(scene)
	return scene


func _blank(model: Node3D, serial: int) -> Dictionary:
	return {
		"model": model, "doors": [], "helpers": {}, "hazards": [], "lit": false, "engine": null, 
		"serial": serial, "wrecks": [], "litter": [], "bicycle": null, "closed": false, 
	}



func close(of: Dictionary) -> void :
	of["closed"] = true
	for door: Dictionary in of["doors"]:
		door["closed"] = true
		if is_instance_valid(door["label"]):
			door["label"].visible = false
			door["bar"].visible = false
		IconChip.show_icon(door.get("chip"), "", Color.WHITE)
		if door.get("prompt") != null and is_instance_valid(door["prompt"]):
			door["prompt"].enabled = false
	for made: Dictionary in of["wrecks"]:
		if made["car"]["prompt"] != null and is_instance_valid(made["car"]["prompt"]):
			made["car"]["prompt"].enabled = false
	if is_same(scene, of):
		scene = {}





func tend(of: Dictionary) -> void :
	var settings: Dictionary = Config.Incidents.Crash
	var pace: = 100.0 / float(settings["TrappedTime"])
	var engine: Variant = of.get("engine")
	for door: Dictionary in of["doors"]:
		var victim: Variant = door["victim"]
		if not victim is Victim:
			continue
		var stage: int = door["stage"]
		var share: = 1.0 if stage <= HYDRAULIC else (float(settings["FreedDrain"]) if stage == HYDRAULIC + 1 else 0.0)
		if engine != null and engine.get("trapped", []).has(victim):
			if engine["state"] == "burning":
				share *= float(settings["EngineFire"]["Drain"])
			elif engine["state"] == "cabin":
				share *= float(settings["EngineFire"]["Drain"]) * float(settings["EngineFire"]["CabinDrain"])
		victim.drain = pace * share
		if door["board"] != null and is_instance_valid(door["board"]):
			door["board"].visible = true



func seat(car: Dictionary, seat_name: String) -> Transform3D:
	var place: Transform3D = car["place"]
	return place * Transform3D(Basis.IDENTITY, _vector(car["measures"]["seats"][seat_name]) + Vector3(0, Figure.ROOT_HEIGHT - 2.0, 0))







func _threaten(of: Dictionary, car: Dictionary, trapped: Array) -> void :
	var settings: Dictionary = Config.Incidents.Crash.EngineFire
	_set_steam(car, 2)
	var prompt: = _battery_prompt(of, car)
	var engine: = {"car": car, "prompt": prompt, "trapped": trapped, "state": "smoking", "left": -1.0, "flame": null}
	prompt.triggered.connect( func(player: Player) -> void :
		if engine["state"] != "smoking":
			return
		engine["state"] = "safe"
		engine["safe_at"] = Game.now()
		prompt.enabled = false
		_set_steam(car, 3)
		Escalation.show("leak", null)
		of["helpers"][player] = true
		player.add_cash(int(settings["Reward"]))
		Game.notify(Text.f("calls.crash.battery.done", [player.display_name]), "good")
	)
	of["engine"] = engine



func _puddle(car: Dictionary) -> void :
	var pool: = MeshInstance3D.new()
	var disc: = CylinderMesh.new()
	disc.top_radius = 1.0
	disc.bottom_radius = 1.0
	disc.height = 0.04
	disc.radial_segments = 24
	pool.mesh = disc
	var look: = StandardMaterial3D.new()
	look.albedo_color = Color(0.035, 0.03, 0.025, 0.8)
	look.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	look.metallic = 0.25
	look.roughness = 0.12
	pool.material_override = look
	pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	car["node"].add_child(pool)


	var under: Vector3 = car["engine"].global_position
	pool.global_position = Vector3(under.x, (car["place"] as Transform3D).origin.y + 0.06, under.z)
	pool.scale = Vector3(1.5, 1.0, 1.5)
	pool.create_tween().tween_property(pool, "scale", Vector3(5.0, 1.0, 4.0), 40.0)


func _battery_prompt(of: Dictionary, car: Dictionary) -> Prompt:
	return CallKit.prompt(car["engine"], "crash.%d.battery" % of["serial"], Text.m("calls.crash.battery.action"), Text.m("calls.crash.battery.object"), float(Config.Incidents.Crash.EngineFire.BatteryTime), 9.0)




func _step_engine(of: Dictionary, dt: float) -> void :
	var engine: Variant = of["engine"]
	if engine == null:
		return
	var settings: Dictionary = Config.Incidents.Crash.EngineFire
	if engine["state"] == "burning" and engine["flame"] != null and FireService.current != null:
		engine["burnt"] = float(engine.get("burnt", 0.0)) + dt
		if engine["burnt"] >= float(settings["CabinAfter"]) and engine.get("cabin_flame") == null:
			_into_cabin(of, engine)
		return
	if engine["state"] != "smoking":
		return
	var at: Vector3 = engine["car"]["engine"].global_position
	var leak: bool = engine.get("leak", false)
	if engine["left"] < 0.0:
		if CallKit.player_near(at, float(settings["Near"])):
			if leak:
				var soon: Array = Config.Alarm.Leak.After
				engine["left"] = randf_range(float(soon[0]), float(soon[1]))
				Game.notify(Text.m("calls.escalation.leak.warn"), "danger")
			else:
				var after: Vector2 = settings["After"]
				engine["left"] = randf_range(after.x, after.y)
				Game.notify(Text.m("calls.crash.battery.warn"), "warning")
		return
	engine["left"] = maxf(engine["left"] - dt, 0.0)
	if leak:
		Escalation.show("leak", ceili(engine["left"]))
	if engine["left"] > 0.0:
		return
	Escalation.show("leak", null)
	engine["state"] = "burning"
	engine["prompt"].enabled = false
	_set_steam(engine["car"], 4)
	Game.notify(Text.m("calls.crash.battery.alight"), "warning")
	if FireService.current == null:
		return
	engine["flame"] = FireService.current.spot(at + Vector3(0, 0.6, 0), func(player: Variant) -> void :
		engine["flame_out"] = true
		_engine_out(of, engine, player)
	)




func _into_cabin(of: Dictionary, engine: Dictionary) -> void :
	var settings: Dictionary = Config.Incidents.Crash.EngineFire
	var car: Dictionary = engine["car"]
	var over_seats: Vector3 = (car["place"] as Transform3D) * Vector3(0, 3.2, 1.0)
	engine["state"] = "cabin"
	engine["cabin_flame"] = FireService.current.spot(over_seats, func(player: Variant) -> void :
		engine["cabin_out"] = true
		_engine_out(of, engine, player)
	)
	Alarm.hurt(float(settings["SafetyCost"]))
	Alarm.check("engine", false)
	Game.notify(Text.m("calls.crash.cabin"), "danger")



func _engine_out(of: Dictionary, engine: Dictionary, player: Variant) -> void :
	var engine_lit: bool = not engine.get("flame_out", false)
	var cabin_lit: bool = engine.get("cabin_flame") != null and not engine.get("cabin_out", false)
	if engine_lit or cabin_lit:
		engine["state"] = "cabin" if cabin_lit else "burning"
		return
	engine["state"] = "out"
	if engine.get("cabin_flame") == null:
		Alarm.check("engine", true)
	if player is Player:
		of["helpers"][player] = true
		Game.notify(Text.f("calls.crash.battery.out", [player.display_name]), "good")







func _net_state() -> Variant:
	var list: Array = []
	for held: Dictionary in _shown.duplicate():
		if not CallKit.there(held["model"]):
			_shown.erase(held)
			continue
		var wrecks: Array = []
		for made: Dictionary in held["wrecks"]:
			var car: Dictionary = made["car"]
			wrecks.append([made["place"], made["shape"], made["paint"], made["sprung"], car["steaming"], car["prep"], car["stable"], car["glass"]])
		var doors: Array = []
		for door: Dictionary in held["doors"]:
			var index: = 0
			for at in held["wrecks"].size():
				if is_same(held["wrecks"][at]["car"], door["car"]):
					index = at
			var victim_id: int = door["victim"].id if door["victim"] is Victim else -1
			doors.append([index, door["side"], door["stage"], snappedf(door["progress"] / float(Config.Incidents.Crash.JobTime), 0.02), victim_id])
		var engine: Variant = held["engine"]
		var engine_car: = -1
		if engine != null:
			for at in held["wrecks"].size():
				if is_same(held["wrecks"][at]["car"], engine["car"]):
					engine_car = at
		list.append({
			"serial": held["serial"], "live": is_same(held, scene), "wrecks": wrecks, "litter": held["litter"], "bicycle": held["bicycle"], 
			"doors": doors, "lit": held["lit"], "closed": held["closed"], "fading": CallKit.fading(held["model"]), 
			"engine": [engine_car, engine["state"], engine.get("leak", false)] if engine_car >= 0 else null, 
		})
	return list



func _net_build(state: Dictionary) -> Dictionary:
	var held: = _blank(CallKit.model("CarCrash"), state["serial"])
	for row: Array in state["wrecks"]:
		wreck(held, row[0], {"shape": row[1], "paint": row[2], "sprung": row[3]})
	for row: Array in state["litter"]:
		_litter(held, row[0], row[1], row[2])
	if state["bicycle"] != null:
		_bicycle(held, state["bicycle"])
	for row: Array in state["doors"]:
		if row[0] < held["wrecks"].size():
			jam(held, held["wrecks"][row[0]]["car"], row[1], null)
	return held




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array or (leaving and _mirrors.is_empty()):
		return
	var told: = {}
	scene = {}
	for state: Dictionary in list:
		var serial: int = state["serial"]
		told[serial] = true
		var held: Dictionary = _mirrors.get(serial, {})
		var fresh: = held.is_empty()
		if fresh:
			held = _net_build(state)
			_mirrors[serial] = held
		for index in mini(state["wrecks"].size(), held["wrecks"].size()):
			var car: Dictionary = held["wrecks"][index]["car"]
			var row: Array = state["wrecks"][index]
			_set_steam(car, row[4])

			if int(row[5]) >= 0:
				car["prep"] = row[5]
				car["stable"] = row[6]
				car["glass"] = row[7]
				_prepare(held, car)
				_show_prep(car, state["closed"])
		for index in mini(state["doors"].size(), held["doors"].size()):
			var door: Dictionary = held["doors"][index]
			_net_door(door, state["doors"][index][2], state["doors"][index][3], fresh)

			if int(door["stage"]) > JOBS.size() and VictimService.current:
				for person: Victim in VictimService.current.victims:
					if person.id == int(state["doors"][index][4]) and is_instance_valid(person.figure):
						_show_board(door, person.figure)
						person.on_board = true
						door["board"].visible = true
		_light(held, state["lit"])

		var engine: Variant = state["engine"]
		if engine != null and engine[0] < held["wrecks"].size():
			if held["engine"] == null:
				held["engine"] = {"prompt": _battery_prompt(held, held["wrecks"][engine[0]]["car"]), "state": ""}
			held["engine"]["state"] = engine[1]
			if engine.size() > 2 and engine[2] and not held["engine"].has("leak"):
				held["engine"]["leak"] = true
				_puddle(held["wrecks"][engine[0]]["car"])
			held["engine"]["prompt"].enabled = engine[1] == "smoking" and not state["closed"]
		if state["closed"] and not held["closed"]:
			close(held)
		if state["fading"]:
			CallKit.fade(held["model"], FADE)
		if state["live"]:
			scene = held
	for serial: int in _mirrors.keys():
		if not told.has(serial):
			if is_instance_valid(_mirrors[serial]["model"]):
				_mirrors[serial]["model"].queue_free()
			_mirrors.erase(serial)



func _net_door(door: Dictionary, stage: int, share: float, fresh: bool) -> void :
	if stage != door["stage"]:
		if not fresh:
			Sounds.once(door["mark"], Config.Tools.Sounds.MetalGive, 1.0, 10.0, 140.0)
		door["stage"] = stage
		door["shown"] = 0.0
		if stage == 2:
			_swing_door(door, DOOR_AJAR)
		elif stage >= 3 and not door.get("dropped", false):
			door["dropped"] = true
			_swing_door(door, DOOR_AJAR)
			_drop_door(door)
		_show_job(door)
	if stage <= HYDRAULIC and not is_equal_approx(share, door.get("shown", 0.0)):

		door["shown"] = share
		CallKit.set_bar(door["bar"], share)
		_swing_door(door, (DOOR_AJAR * DOOR_YIELD * share if stage == 1 else DOOR_AJAR) + randf_range(-1, 1) * DOOR_SHUDDER)







func _guarded(middle: Vector3, along: Vector3) -> bool:
	var ends: = Cordon.road_ends(middle, along, CONE_ROOM, float(Config.Incidents.Crash.Safety.Range))
	return ends[0] and ends[1]



static func road_bodies(of: Dictionary) -> Array:
	var room: float = Config.Incidents.Road.WreckRoom
	var bodies: Array = []
	for made: Dictionary in of.get("wrecks", []):
		var place: Transform3D = made["place"]
		for z: float in [-3.5, 0.0, 3.5]:
			var at: = place * Vector3(0, 0, z)
			bodies.append(Vector3(at.x, at.z, room))
	bodies.append_array(ScenePolice.bodies())
	return bodies







func _find_place(length: float) -> Array:
	for attempt in TRIES:
		var street: Dictionary = _streets[randi() % _streets.size()]
		if street["length"] > length + ROAD_ROOM * 2.0:
			var found: = Roads.at(street["road"], randf_range(ROAD_ROOM + length / 2.0, street["length"] - ROAD_ROOM - length / 2.0))
			var middle: = Vector3(found[0], 0, found[1])
			var along: = Vector3(found[2], 0, found[3])
			if (middle - Vector3(_avoid.x, 0, _avoid.z)).length() > STATION_ROOM and not CallKit.player_near(middle, PLAYER_ROOM):
				var box: = Rbx.look_at(middle + Vector3(0, 3.5, 0), middle + Vector3(0, 3.5, 0) + along)
				if CallKit.box_clear(box, Vector3(float(street["road"]["width"]) - 2.0, 5, length + 6.0)):
					return [CallKit.ground_at(middle), along, street["road"]]
	return []




func _find_tree() -> Array:
	for attempt in (TRIES if not _trees.is_empty() else 0):
		var tree: Dictionary = _trees[randi() % _trees.size()]
		var standing: = CallKit.tree_model(tree["index"])
		if standing != 0 and not CallKit.player_near(tree["position"], PLAYER_ROOM):

			var along: Vector3 = tree["along"] if randf() < 0.5 else - tree["along"]
			var heading: Vector3 = (tree["away"] * 0.7 + along * 0.7).normalized()
			var middle: = CallKit.ground_at(tree["position"] - heading * 8.5)
			var place: = Rbx.look_at(middle, middle + heading)
			if CallKit.box_clear(place * Transform3D(Basis.IDENTITY, Vector3(0, 3.5, 0)), Vector3(7, 5, 16), CallKit.rows_of(standing)):
				return [place, along, tree["road"]]
	return []



func _bicycle(into: Dictionary, place: Transform3D) -> void :
	var model: Node3D = into["model"]
	into["bicycle"] = place
	var tyre: = Color8(28, 28, 30)
	var frame: = Color8(190, 40, 34)
	var holder: = Node3D.new()
	holder.name = "Bicycle"
	model.add_child(holder)
	holder.global_transform = place
	for z: float in [-1.7, 1.7]:
		CallKit.piece(holder, CallKit.CYLINDER, Vector3(0.22, 2.5, 2.5), Transform3D(Basis(Vector3.BACK, PI / 2), Vector3(0, 0.13, z)), tyre)
	CallKit.piece(holder, CallKit.BLOCK, Vector3(0.22, 0.18, 3.4), Transform3D(Basis(Vector3.UP, deg_to_rad(16)), Vector3(0.5, 0.2, 0)), frame)
	CallKit.piece(holder, CallKit.BLOCK, Vector3(1.3, 0.18, 0.22), Transform3D(Basis.IDENTITY, Vector3(0.55, 0.2, 0.3)), frame)
	CallKit.piece(holder, CallKit.BLOCK, Vector3(1.9, 0.16, 0.16), Transform3D(Basis.IDENTITY, Vector3(0.9, 0.24, -1.5)), tyre)
	CallKit.piece(holder, CallKit.BLOCK, Vector3(0.5, 0.2, 0.9), Transform3D(Basis.IDENTITY, Vector3(1.25, 0.24, 0.9)), tyre)



func _draw_layout() -> String:
	var settings: Dictionary = Config.Incidents.Crash
	var wanted: Variant = settings.get("Layout")
	if wanted is String and (LAYOUTS.has(wanted) or wanted == "tree"):
		return wanted
	return CallKit.draw(settings["Layouts"], "headOn")


func available() -> bool:
	return not _streets.is_empty() and VictimService.current != null and not CarKit.shapes().is_empty()


func run() -> bool:
	var settings: Dictionary = Config.Incidents.Crash
	var victims_service: = VictimService.current
	if victims_service == null:
		return false
	var layout_name: = _draw_layout()


	var middle: = Vector3.ZERO
	var along: = Vector3.ZERO
	var road: Dictionary = {}
	var tree_place: Variant = null
	if layout_name == "tree":
		var found: = _find_tree()
		if not found.is_empty():
			tree_place = found[0]
			along = found[1]
			road = found[2]
			middle = found[0].origin
		else:
			layout_name = "headOn"
	var layout: Dictionary = LAYOUTS.get(layout_name, {})
	if tree_place == null:
		var found: = _find_place(layout["length"])
		if found.is_empty():
			return false
		middle = found[0]
		along = found[1]
		road = found[2]

	var model: = CallKit.model("CarCrash")
	var held: = open(model)
	held["along"] = along
	var frame: = Rbx.look_at(middle, middle + along)
	var cars: Array = []
	var people: Array = []
	var thrown: Array = []
	var body_size: = Vector3(14, 6, 20)
	if tree_place != null:
		cars.append(wreck(held, tree_place, {"steaming": true}))
		_litter(held, tree_place * Vector3(0, 0, -6), 6)
		people = [[0, "L"], [0, "R"]]
		frame = tree_place
	else:

		var placed: Array = layout["cars"]
		for index in placed.size():
			var car: Array = placed[index]
			var place: = frame * Transform3D(Basis(Vector3.UP, deg_to_rad(car[2])), Vector3(car[0], 0, car[1]))
			cars.append(wreck(held, place, {"steaming": layout["steaming"] == index, "sprung": not (index in layout["unsprung"])}))
		for impact: float in layout["impacts"]:
			_litter(held, frame * Vector3(0, 0, impact))
		if layout.has("bicycle"):
			var at: Array = layout["bicycle"]
			_bicycle(held, Transform3D(frame.basis * Basis(Vector3.UP, deg_to_rad(at[2])), CallKit.ground_at(frame * Vector3(at[0], 0, at[1]))))
		people = layout["people"]
		thrown = layout.get("thrown", [])
		body_size = Vector3(14, 6, layout["length"])


	var count: = mini(int(CallKit.by_crew(settings["Casualties"])), people.size())
	var seats: Array = []
	for index in count:
		seats.append(seat(cars[people[index][0]], people[index][1]))
	for spot: Array in thrown:
		var feet: = - (frame.basis * Basis(Vector3.UP, deg_to_rad(spot[2]))).z
		seats.append({"lying": Figure.lying(CallKit.ground_at(frame * Vector3(spot[0], 0, spot[1])), feet, 0.05)})
	var title: Variant = Text.m("calls.crash.cyclistTitle" if not thrown.is_empty() else "calls.crash.title")
	var call_name: = Text.join([title, Text.m("calls.separator"), Roads.name_of(road)])
	var victims: = victims_service.begin_at({"lot": frame, "size": body_size, "name": "the accident"}, seats, 100.0 / float(settings["TrappedTime"]))

	var in_car: Dictionary = {}
	for index in mini(count, victims.size()):
		var car_index: int = people[index][0]
		jam(held, cars[car_index], people[index][2] if people[index].size() > 2 else people[index][1], victims[index])
		if not in_car.has(car_index):
			in_car[car_index] = []
		in_car[car_index].append(victims[index])
	var loose: Array = []
	for index in range(count, victims.size()):
		loose.append(victims[index])

	for car_index: int in in_car:
		_prepare(held, cars[car_index])
	for index in cars.size():
		if cars[index]["steaming"] != 0 and in_car.has(index) and randf() < float(settings["EngineFire"]["Chance"]):
			_threaten(held, cars[index], in_car[index])


	if not in_car.is_empty() and Alarm.draw_escalation(["leak"]) == "leak":
		if held["engine"] == null:
			var index: int = in_car.keys()[0]
			for steaming in in_car:
				if cars[steaming]["steaming"] != 0:
					index = steaming
			_threaten(held, cars[index], in_car[index])
		held["engine"]["leak"] = true
		_puddle(held["engine"]["car"])

	position = middle + Vector3(0, 3, 0)
	var doors: int = held["doors"].size()
	var total: = jobs_total(held) + loose.size()
	CallService.current.publish("crash", call_name, position, total)


	var par: Dictionary = Alarm.settings()["Grade"]["Job"]["crash"]
	var platinum: = float(par["Base"]) + float(par["PerJob"]) * doors * JOBS.size() + float(par["PerLoose"]) * loose.size()
	Alarm.par(platinum)
	Game.notify(Text.f("calls.crash.alarm", [call_name]))
	if doors > 0:
		Game.notify(Text.fill(Text.plural(doors, "calls.crash.trapped"), [doors]))
		Game.notify(Text.f("calls.crash.procedure", [Alarm.clock(platinum)]))
	else:
		Game.notify(Text.m("calls.crash.cyclistBrief"))

	var waited: = 0.0
	var safe: = false
	var moved: = false
	var closed: = false
	var freed_at: = -1.0
	var nobody: = func(_at: Vector3) -> float: return 0.0
	while victims_service.waiting() and not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		tend(held)
		victims_service.step(TICK, nobody, false)
		_step_engine(held, TICK)
		blink(held, waited)
		var done: = jobs_done(held)
		for victim: Victim in loose:
			if victim.state == "out":
				done += 1
		Game.incident.merge(victims_service.shown(), true)
		CallService.current.progress(done)


		var shut: = _guarded(middle, along)
		if shut and not closed:
			Game.notify(Text.m("calls.crash.roadClosed"), "good")
		closed = shut
		if Bystanders.current:
			Bystanders.current.set_road(position, along, road_bodies(held), closed)
		if not moved:
			for victim: Victim in victims:
				moved = moved or (victim.state != "trapped" and victim.state != "lying")
			safe = safe or ( not moved and closed)
		var trapped: = false
		for victim: Victim in victims:
			trapped = trapped or victim.state == "trapped"
		if not trapped and freed_at < 0.0:
			freed_at = Game.now()
		_show_platinum(done, total, platinum)
		CallService.current.next_step(next_step(held, closed))

	close(held)
	var engine: Variant = held["engine"]


	if not CallService.current.overdue(waited):
		Alarm.done()
	Alarm.check("cones", safe)
	if engine != null:
		var cut_at: = float(held.get("cut_at", -1.0))
		Alarm.check("battery", engine["state"] == "safe" and (cut_at < 0.0 or float(engine.get("safe_at", INF)) <= cut_at))


	var prepared: = false
	var shaken: = false
	var shards: = false
	for made: Dictionary in held["wrecks"]:
		var car: Dictionary = made["car"]
		if int(car["prep"]) >= 0:
			prepared = true
			shaken = shaken or car.get("shaken", false)
			shards = shards or car.get("shards", false)
	if prepared:
		Alarm.check("stable", not shaken)
		Alarm.check("glass", not shards)
		Alarm.check("platinum", freed_at >= 0.0 and Alarm.arrived_at >= 0.0 and freed_at - Alarm.arrived_at <= platinum)
	if engine != null:
		for flame: String in ["flame", "cabin_flame"]:
			if engine.get(flame) != null and FireService.current:
				FireService.current.end_spot(engine[flame])
		engine["prompt"].enabled = false
	var helpers: Dictionary = held["helpers"]
	var counts: = victims_service.finish()
	for player: Variant in counts["rescuers"]:
		helpers[player] = true

	var good: bool = counts["lost"] == 0 and counts["rescued"] == counts["total"]
	if counts["total"] > 0:
		VictimService.tally(counts)
		if not CallService.current.overdue(waited):
			if good:
				for player in CallKit.pay_helpers(helpers, int(settings["Bonus"]), "", "bonus"):
					Game.notify(Text.f("calls.crash.nobodyLost", [Alarm.pay(int(settings["Bonus"]))]), "good", player)
			if safe:
				for player in CallKit.pay_helpers(helpers, int(settings["Safety"]["Reward"])):
					Game.notify(Text.f("calls.crash.safeScene", [Alarm.pay(int(settings["Safety"]["Reward"]))]), "good", player)
	Game.incident.merge(VictimService.card(counts), true)
	Game.incident.erase("next")

	await CallService.current.settle()
	CallService.current.clear( not good or CallService.current.overdue(waited))


	get_tree().create_timer(float(settings["TowAfter"]), false).timeout.connect( func() -> void : CallKit.fade(model, FADE))
	return true



func _show_platinum(done: int, total: int, platinum: float) -> void :
	if Game.incident.is_empty():
		return
	if Alarm.arrived_at < 0.0:
		Game.incident["progress_text"] = "%d/%d" % [done, total]
	else:
		Game.incident["progress_text"] = Text.f("calls.crash.platinum", [done, total, Alarm.clock(Game.now() - Alarm.arrived_at), Alarm.clock(platinum)])



func start(layout: Dictionary, station: Vector3) -> void :
	_avoid = station
	Net.share("call.crash", _net_state, _net_apply, 8.0)
	Net.stopped.connect( func() -> void : _net_apply([], true))
	for road: Dictionary in layout["roads"]:
		var length: = Roads.length(road)
		if float(road["rank"]) >= 1.0 and length > ROAD_ROOM * 2.0 + 40.0:
			_streets.append({"road": road, "length": length})
	var trees: Array = layout["trees"]
	for index in trees.size():
		var tree: Dictionary = trees[index]
		if tree["kind"] != "bush" and (Vector3(tree["x"], station.y, tree["z"]) - station).length() > STATION_ROOM:
			var found: = Roads.nearest(layout, tree["x"], tree["z"])
			var nearest: Dictionary = found[0]
			var street: Dictionary = found[1]
			if nearest.is_empty():
				continue
			var half: = float(street["width"]) / 2.0
			if nearest["distance"] >= half + TREE_NEAR and nearest["distance"] <= half + TREE_FAR and nearest["along"] >= ROAD_ROOM and nearest["along"] <= nearest["length"] - ROAD_ROOM:
				var way: = Roads.at(street, nearest["along"])
				_trees.append({
					"index": index, 
					"position": Vector3(tree["x"], 0, tree["z"]), 
					"away": Vector3(tree["x"] - nearest["x"], 0, tree["z"] - nearest["z"]).normalized(), 
					"along": Vector3(way[2], 0, way[3]), 
					"road": street, 
				})
	if ToolService.current:
		ToolService.current.hydraulic = work
