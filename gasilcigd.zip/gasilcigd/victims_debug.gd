class_name VictimsDebug
extends Node

















var _args: Dictionary = {}
var _camera: Camera3D
var _mode: = ""
var _began: = -1.0
var _done: Dictionary = {}


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		var bits: = arg.split("=", true, 1)
		if bits[0].begins_with("--victim") or bits[0].begins_with("--carry") or bits[0].begins_with("--casualty") or bits[0].begins_with("--ambulance") or bits[0] == "--putdown":
			_args[bits[0].substr(2)] = bits[1] if bits.size() > 1 else ""
	if _args.is_empty():
		set_process(false)
		return
	if _args.has("victims"):
		VictimService.current.forced = int(_args["victims"])
	if _args.has("victims-sick"):
		VictimService.current.forced_sick = float(_args["victims-sick"])
	if (_args.has("casualty-at") or _args.has("ambulance-at")) and CallService.current:
		CallService.current.hold = true
	if _args.has("casualty-at"):
		var c: PackedFloat64Array = _args["casualty-at"].split_floats(",")
		get_tree().create_timer(1.0).timeout.connect( func() -> void :
			if Net.is_client():
				return
			var ground: = Vector3(c[0], AmbulanceService.current.ground_at(c[0], c[1]), c[1])
			var seat: = Transform3D(Basis.IDENTITY, ground + Vector3(0, 2.2, 0))
			var beside: = {"lying": Figure.lying(ground + Vector3(5, 0, 0), Vector3.BACK, 0.05)}
			var scene: = {"lot": Transform3D(Basis.IDENTITY, ground), "size": Vector3(14, 6, 20), "name": "the accident"}
			var made: = VictimService.current.begin_at(scene, [seat, beside], 1.0)
			get_tree().create_timer(4.0).timeout.connect( func() -> void : VictimService.current.release(made[0]))
		)
	if _args.has("ambulance-from"):
		AmbulanceService.current.drive_from = float(_args["ambulance-from"])
	if _args.has("ambulance-at"):
		var n: PackedFloat64Array = _args["ambulance-at"].split_floats(",")
		get_tree().create_timer(1.0).timeout.connect( func() -> void :
			if Net.is_client():
				return
			var at: = Vector3(n[0], AmbulanceService.current.ground_at(n[0], n[1]), n[1])
			print("ambulance: called to ", at, "; the box is at ", AmbulanceService.current.arrive_at(at))
		)


func _view(from: Vector3, to: Vector3) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 3000.0
		_camera.fov = 60.0
		_camera.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
		add_child(_camera)
	_camera.look_at_from_position(from, to)
	_camera.make_current()


func _once(key: String, after: float) -> bool:
	if _done.has(key) or not _args.has(key):
		return false
	if Game.now() - _began < after:
		return false
	_done[key] = true
	return true


func _process(_delta: float) -> void :
	var service: = VictimService.current
	var ambulance: = AmbulanceService.current
	if _began < 0.0 and ambulance.called():
		_began = Game.now()
		var place: Dictionary = ambulance._scene["place"]
		print("ambulance: parks at ", place["base"].origin, " lane ", place["seg"], "; the box is at ", ambulance.zone_position())
		for victim in service.victims:
			print("victim: ", victim.state, " in ", victim.room, " at ", victim.position())
	if _began < 0.0:
		return
	if _args.has("casualty-at") and Net.is_host():

		service.step(_delta, func(_at: Vector3) -> float: return 0.0, false)
	var player: = Game.local_player
	var first: Victim = service.victims[0] if not service.victims.is_empty() else null

	if _once("victim-cam", 0.2):
		var index: = clampi(int(_args["victim-cam"]) - 1, 0, service.victims.size() - 1)
		var at: = service.victims[index].position()
		_view(at + Vector3(4.5, 6.5, 4.5), at)
	if first and _args.has("carry") and _once("carry", float(_args["carry"])):
		var at: = first.position()
		player.teleport(at + Vector3(2.5, 0.5, 0))
		if Net.is_client():

			var id: = first.prompt.net_id
			get_tree().create_timer(0.6).timeout.connect( func() -> void :
				Net.request("prompt", [id, "tap"])
				print("carry: asked the host to lift at ", at)
			)
		else:
			print("carry: lifted ", service.lift(first, player), " at ", at)
	if _args.has("carry-to"):
		var bits: PackedStringArray = _args["carry-to"].split(",")
		if _once("carry-to", float(bits[1]) if bits.size() > 1 else 6.0):
			var zone: Vector3 = ambulance.zone_position()
			var base: Transform3D = ambulance._scene["place"]["base"]
			var away: = base.basis.z * (0.0 if bits[0] == "zone" else 13.0)
			player.teleport(zone + away + Vector3(0, 0.5, 0))
			player.rig.rotation.y = atan2(base.basis.z.x, base.basis.z.z)
			print("carry: put ", bits[0], " at ", player.global_position)
	if _args.has("putdown") and _once("putdown", float(_args["putdown"])):
		var carried: = service.carried_by(player)
		if carried and Net.is_client():
			Net.request("prompt", [carried.prompt.net_id, "tap"])
			print("carry: asked the host to put down")
		elif carried:
			service.put_down(carried)
			print("carry: put down at ", carried.position())
	if _args.has("ambulance-leave") and _once("ambulance-leave", float(_args["ambulance-leave"])):
		if Net.is_host():
			print("ambulance: sent away")
			ambulance.leave(0.0)

	if _args.has("carry-cam") and (_done.has("carry") or _done.has("carry-to")):
		var at: = player.global_position + Vector3(0, 3.6, 0)
		var front: = player.facing()
		var right: = front.cross(Vector3.UP)
		match _args["carry-cam"]:
			"back":
				_view(at - front * 9.0 + right * 3.0 + Vector3(0, 2.5, 0), at)
			"side":
				_view(at + right * 10.0 + Vector3(0, 1.0, 0), at)
			_:
				_view(at + front * 9.0 + right * 4.0 + Vector3(0, 1.5, 0), at)
	elif _args.has("ambulance-cam") and ambulance.called():
		var base: Transform3D = ambulance._scene["place"]["base"]
		var car: = ambulance.car()
		match _args["ambulance-cam"]:
			"chase":
				if car:
					_view(car.global_transform * Vector3(7, 9, 26), car.global_transform * Vector3(0, 4, -10))
			"zone":
				_view(base * Vector3(-16, 9, 38), base * Vector3(0, 3, 16))
			"back":
				_view(base * Vector3(-9, 6, 34), base * Vector3(0, 4, 12))
			"side":
				_view(base * Vector3(30, 9, 8), base * Vector3(0, 4, 8))
			_:
				_view(base * Vector3(-24, 16, 30), base * Vector3(0, 3, 6))
