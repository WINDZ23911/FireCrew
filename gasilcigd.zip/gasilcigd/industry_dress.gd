class_name IndustryDress
extends RefCounted

















const WHITE: = Color8(240, 240, 236)
const STEEL: = Color8(132, 136, 142)
const DARK: = Color8(52, 54, 60)
const GREY: = Color8(170, 172, 174)
const LINE: = Color8(236, 236, 230)
const GREEN: = Color8(70, 120, 60)
const WOOD: = Color8(176, 136, 90)
const PALLET: = Color8(196, 160, 112)
const BRICK: = Color8(150, 74, 56)
const SHEET: = Color8(146, 146, 140)
const STAINLESS: = Color8(206, 210, 212)
const TUB: = Color8(244, 244, 240)
const TIMBER: = Color8(118, 88, 60)
const CAR_COLORS: Array[Color] = [Color8(200, 200, 204), Color8(40, 40, 46), Color8(160, 30, 34), Color8(30, 70, 140), Color8(230, 230, 228), Color8(90, 96, 104), Color8(40, 90, 60)]
const SLO: = [Color8(250, 250, 250), Color8(0, 80, 160), Color8(220, 30, 40)]
const EU_BLUE: = Color8(0, 51, 153)
const EU_GOLD: = Color8(255, 204, 0)




const COMPANIES: = {


	"Warehouse": {"brand": Color8(118, 38, 58), "second": Color8(176, 156, 90), "logo": "grapes", "roof": "gable", 
		"walls": {"D6D9DC": [Color8(206, 200, 186), "Plaster"], "484C52": [Color8(222, 212, 188), "Plaster"]}, "band": Color8(176, 170, 156)}, 

	"Metalworks": {"brand": Color8(28, 108, 112), "second": Color8(170, 200, 200), "logo": "tub", "roof": "flat", 
		"walls": {"D6D9DC": [Color8(140, 146, 150), "SmoothPlastic"]}, "band": Color8(96, 100, 106)}, 

	"Sawmill": {"brand": Color8(46, 100, 58), "second": Color8(196, 150, 90), "logo": "tree", "roof": "pitched", "walls": {}}, 

	"Textile": {"brand": Color8(44, 60, 118), "second": Color8(196, 120, 70), "logo": "spool", "roof": "sawtooth", 
		"walls": {"D6D9DC": [Color8(224, 216, 196), "Plaster"]}, "band": Color8(206, 198, 178)}, 

	"ColdStore": {"brand": Color8(40, 112, 160), "second": Color8(250, 250, 250), "logo": "flake", "roof": "flat", 
		"walls": {"D6D9DC": [Color8(238, 240, 240), "SmoothPlastic"]}, "band": Color8(214, 218, 220)}, 
}
const SIGNS: = ["WarehouseSign", "WorksSign", "MillSign", "FactorySign", "StoreSign"]



static func dress(kit: PolishKit) -> int:
	var before: = kit.store.count
	for plot: Dictionary in IndustryZone.PLOTS:
		var house: House = IndustryZone.houses.get(plot["name"])
		if house == null or not COMPANIES.has(plot["name"]):
			continue
		var company: Dictionary = COMPANIES[plot["name"]].duplicate()
		var names: = IndustryZone.company(plot["name"])
		company["name"] = names.get("sign", String(plot["name"]).to_upper())
		_reface(kit.store, house, company, names)
		_company(kit, plot, house, company)
	return kit.store.count - before







static func _read(house: House) -> Dictionary:
	var size: Array = house.data["size"]
	var info: = {"width": float(size[0]), "depth": float(size[2]), "front": - float(size[2]) / 2.0, "roof": 0.0, 
		"sign": null, "doors": [], "office": null, "lights": null, "pitched": false, "roofs": [], "coping": 0.0, 
		"left": INF, "right": - INF}
	var roof_low: = INF
	for row: Array in house.data["parts"]:
		var part_name: String = row[1]
		var low_x: float = row[5] - row[2] / 2.0
		var high_x: float = row[5] + row[2] / 2.0
		var top: float = row[6] + row[3] / 2.0
		match part_name:
			"Wall":

				info["left"] = minf(info["left"], low_x)
				info["right"] = maxf(info["right"], high_x)
			"Coping":
				info["coping"] = maxf(info["coping"], top)
			"Roof":
				info["roof"] = maxf(info["roof"], top)
				info["roofs"].append([Rect2(low_x, row[7] - row[4] / 2.0, row[2], row[4]), top])
				roof_low = minf(roof_low, top)
				if String(row[0]) == "w":
					info["pitched"] = true
			"RollerSlats":
				info["doors"].append(Vector2(low_x, high_x))
			"DoorCanopy", "FrontStep":
				var span: = Vector2(low_x, high_x)
				info["office"] = span if info["office"] == null else Vector2(minf(info["office"].x, low_x), maxf(info["office"].y, high_x))
			"RoofLight":
				var span: = Vector2(low_x, high_x)
				info["lights"] = span if info["lights"] == null else Vector2(minf(info["lights"].x, low_x), maxf(info["lights"].y, high_x))
		if part_name in SIGNS:
			info["sign"] = {"x": Vector2(low_x, high_x), "y": Vector2(row[6] - row[3] / 2.0, top)}
	if info["left"] == INF:
		info["left"] = - info["width"] / 2.0
		info["right"] = info["width"] / 2.0
	return info



static func _main_roof(info: Dictionary) -> Array:
	var best: Array = []
	for entry: Array in info["roofs"]:
		if best.is_empty() or entry[1] > best[1]:
			best = entry
	return best





static func _reface(store: PartStore, house: House, company: Dictionary, names: Dictionary) -> void :
	var walls: Dictionary = company.get("walls", {})
	var colors: Array = house.data["colors"]
	var parts: Array = house.data["parts"]
	for index in parts.size():
		var part: Array = parts[index]
		var part_name: String = part[1]
		var row: int = store.row_of[house.part_ids[index]]
		var hex: = Rbx.rgb(colors[int(part[11]) - 1]).to_html(false).to_upper()
		if part_name == "Wall" and walls.has(hex):
			store.set_color(row, walls[hex][0])
			store.set_material(row, walls[hex][1])
		elif part_name == "PanelJoint" and walls.has("D6D9DC") and hex == "B0B4B8":

			var hall: Array = walls["D6D9DC"]
			store.set_color(row, hall[0] if hall[1] == "Plaster" else (hall[0] as Color).darkened(0.12))
			store.set_material(row, hall[1])
		elif part_name.begins_with("Band") and company.has("band"):
			store.set_color(row, company["band"])
		elif part_name == "OfficeSign":
			store.set_color(row, company["brand"])
		elif part_name == "DoorCanopy":
			store.set_color(row, Color8(64, 66, 70))
	var texts: Array = []
	for text: Dictionary in house.data.get("texts", []):
		var words: = text.duplicate()
		var on: String = parts[int(text["part"]) - 1][1]
		if on in SIGNS:
			words["text"] = company["name"]
			words["color"] = [company["brand"].r8, company["brand"].g8, company["brand"].b8]
		elif on == "OfficeSign" and names.has("office"):
			words["text"] = names["office"]
		texts.append(words)

	house.data = house.data.duplicate()
	house.data["texts"] = texts
	if names.has("title"):
		house.name = names["title"]




static func _roof_at(info: Dictionary, x: float, z: float) -> float:
	var best: = - INF
	for entry: Array in info["roofs"]:
		if (entry[0] as Rect2).has_point(Vector2(x, z)):
			best = maxf(best, entry[1])
	return best if best > - INF else float(info["roof"])




static func _free(info: Dictionary, gates: Array, margin: float) -> Array:
	var blocked: Array = []
	for gate: float in gates:
		blocked.append(Vector2(gate - 13.0, gate + 13.0))
	for door: Vector2 in info["doors"]:
		blocked.append(Vector2(door.x - margin, door.y + margin))
	if info["office"] != null:
		blocked.append(Vector2(info["office"].x - 1.5, info["office"].y + 1.5))
	var free: Array = [Vector2( - info["width"] / 2.0 + 2.0, info["width"] / 2.0 - 2.0)]
	for cut: Vector2 in blocked:
		var next: Array = []
		for span: Vector2 in free:
			if cut.y <= span.x or cut.x >= span.y:
				next.append(span)
				continue
			if cut.x > span.x:
				next.append(Vector2(span.x, cut.x))
			if cut.y < span.y:
				next.append(Vector2(cut.y, span.y))
		free = next
	return free





static func _company(kit: PolishKit, plot: Dictionary, house: House, company: Dictionary) -> void :
	var folder: = kit.own_folder("IndustryDress")
	var lot: = house.lot
	var info: = _read(house)
	var brand: Color = company["brand"]
	var gates: Array = []
	for gate: float in plot["gates"]:
		gates.append( - gate)
	var front: float = info["front"]
	var half_w: float = info["width"] / 2.0
	var left: float = info["left"]
	var right: float = info["right"]

	var fence: = IndustryZone.lot_z(plot) - IndustryZone.front_z(plot) + 1.0
	var back: = IndustryZone.lot_z(plot) - IndustryZone.back_z(plot)


	if info["sign"] != null:
		var sign: Dictionary = info["sign"]
		var tall: float = clampf(sign["y"].y - sign["y"].x + 3.0, 5.0, 9.0)
		var x: float = sign["x"].y + tall / 2.0 + 1.5
		if x + tall / 2.0 > right - 1.0:
			x = sign["x"].x - tall / 2.0 - 1.5
		_logo(kit, folder, lot * _out(Vector3(x, (sign["y"].x + sign["y"].y) / 2.0, front - 0.25)), tall, company)


	for side: float in [-1.0, 1.0]:
		var corner_x: float = (right - 0.6) if side > 0.0 else (left + 0.6)
		var corner: = Vector3(corner_x, 0, front - 0.45)
		var top: = _roof_at(info, corner.x - side * 1.0, front + 1.0)
		kit.rod(folder, lot * Vector3(corner.x, 0.4, corner.z), lot * Vector3(corner.x, top, corner.z), 0.5, GREY, "Metal", "Downpipe")
		_camera(kit, folder, lot, Vector3(corner_x - side * 1.4, minf(top - 3.0, 14.0), front), side)
	for span: Vector2 in _free(info, [], 1.5):
		span = Vector2(maxf(span.x, left + 2.0), minf(span.y, right - 2.0))
		var count: = int((span.y - span.x) / 14.0)
		for index in count:
			var x: = span.x + (index + 0.5) * (span.y - span.x) / count
			_wall_lamp(kit, folder, lot, Vector3(x, 11.0, front))



	var yard: = _free(info, gates, 4.0)
	_car_park(kit, lot, yard, plot["name"], fence)
	var office: Variant = info["office"]
	var near_x: float = office.x - 6.0 if office != null else 0.0
	var pylon_x: = _nearest_free(yard, near_x, 5.0)
	if pylon_x != INF:
		_pylon(kit, folder, lot, Vector3(pylon_x, 0.24, fence + 4.5), company)
		var flags_x: = _nearest_free(yard, pylon_x + 9.0, 5.0)
		if flags_x != INF and absf(flags_x - pylon_x) > 6.0:
			_flags(kit, folder, lot, Vector3(flags_x, 0.24, fence + 3.0), brand)
	if office != null:
		_office_front(kit, folder, lot, office, front, info)


	match company["roof"]:
		"flat":
			_roof(kit, folder, lot, info, plot["name"])
		"gable":
			_gable(kit, folder, lot, info, company["walls"].values()[0][0])
		"sawtooth":
			_sawtooth(kit, folder, lot, info)
	match plot["name"]:
		"Metalworks":

			var stack: = Vector3(right - 6.0, 0, - front - 8.0)
			_chimney(kit, folder, lot, stack, _roof_at(info, stack.x, stack.z))
			var tubs_x: = _nearest_free(_free(info, gates, 3.0), 4.0, 10.0)
			if tubs_x != INF:
				_tubs(kit, folder, lot, Vector3(tubs_x, 0.24, front - 6.0))
		"Sawmill":


			var shed_x: = right + 1.0
			var shed_w: = minf(half_w + 5.0 - shed_x, 26.0)
			if shed_w > 12.0 and front - fence > 16.0:
				_open_shed(kit, folder, lot, shed_x, shed_x + shed_w, maxf(fence + 9.0, front - 22.0), front - 3.0)
				_cyclone(kit, folder, lot, Vector3(right + 4.0, 0.6, front + 6.0), _roof_at(info, right - 1.0, front + 6.0), Vector3(right + 0.6, 12.0, front + 6.0))
			var stack: = _nearest_free(_free(info, gates, 3.0), 0.0, 6.0)
			if stack != INF:
				_timber(kit, folder, lot, Vector3(stack, 0.6, front - 5.0))
		"Warehouse":

			var tanks_x: = _nearest_free(_free(info, gates, 3.0), 14.0, 15.0)
			if tanks_x != INF:
				_wine_tanks(kit, folder, lot, Vector3(tanks_x, 0.24, front - 5.5))
		"Textile":

			var door_x: = 0.0
			for info_door: Dictionary in house.data["doors"]:
				if info_door["name"] == "BackDoor":
					door_x = float(info_door["pos"][0])
			var boiler_x: float = right - 9.0 if door_x < right - 18.0 else left + 9.0
			if back + front > 12.0:
				_boiler_house(kit, folder, lot, Vector3(boiler_x, 0, - front + 1.0 + minf(back + front - 2.0, 10.0) / 2.0), minf(back + front - 2.0, 10.0))
			var bales: = _nearest_free(_free(info, gates, 3.0), -14.0, 5.0)
			if bales != INF:
				_bales(kit, folder, lot, Vector3(bales, 0.6, front - 3.5), company)
		"ColdStore":
			var crates: = _nearest_free(_free(info, gates, 3.0), 0.0, 5.0)
			if crates != INF:
				_pallets(kit, folder, lot, Vector3(crates, 0.6, front - 3.5), brand)



static func _out(at: Vector3) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, PI), at)



static func _nearest_free(spans: Array, wanted: float, room: float) -> float:
	var best: = INF
	for span: Vector2 in spans:
		if span.y - span.x < room * 2.0:
			continue
		var x: = clampf(wanted, span.x + room, span.y - room)
		if best == INF or absf(x - wanted) < absf(best - wanted):
			best = x
	return best






static func _logo(kit: PolishKit, folder: int, place: Transform3D, size: float, company: Dictionary) -> void :
	var brand: Color = company["brand"]
	var second: Color = company["second"]
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0, -0.1)), Vector3(size, size, 0.2), WHITE, "SmoothPlastic", "LogoPlate")
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0, -0.14)), Vector3(size + 0.5, size + 0.5, 0.12), brand, "SmoothPlastic", "LogoEdge")
	var s: = size / 6.0
	var z: = 0.06
	match company["logo"]:
		"grapes":

			for tier in 3:
				for index in 3 - tier:
					var at: = Vector3((index - (2 - tier) / 2.0) * 1.15 * s, (0.7 - tier * 1.0) * s, z)
					kit.box(folder, place * Transform3D(Basis(Vector3.BACK, PI / 4.0), at), Vector3(0.8 * s, 0.8 * s, 0.12), brand, "SmoothPlastic", "Logo")
			kit.box(folder, place * Transform3D(Basis(Vector3.BACK, -0.5), Vector3(0.9 * s, 1.9 * s, z)), Vector3(1.6 * s, 0.7 * s, 0.12), second, "SmoothPlastic", "Logo")
		"tub":

			kit.box(folder, place * Transform3D(Basis(), Vector3(0, -0.6 * s, z)), Vector3(4.0 * s, 1.4 * s, 0.12), brand, "SmoothPlastic", "Logo")
			kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0.25 * s, z)), Vector3(4.6 * s, 0.4 * s, 0.12), brand, "SmoothPlastic", "Logo")
			for foot: float in [-1.5, 1.5]:
				kit.box(folder, place * Transform3D(Basis(), Vector3(foot * s, -1.55 * s, z)), Vector3(0.5 * s, 0.6 * s, 0.12), brand, "SmoothPlastic", "Logo")
			for index in 3:
				kit.box(folder, place * Transform3D(Basis(Vector3.BACK, 0.5 if index % 2 == 0 else -0.5), Vector3((index - 1) * 1.1 * s, 1.3 * s, z)), Vector3(1.2 * s, 0.35 * s, 0.12), second, "SmoothPlastic", "Logo")
		"tree":
			for tier in 3:
				kit.box(folder, place * Transform3D(Basis(), Vector3(0, (tier - 0.6) * 1.1 * s, z)), Vector3((3.6 - tier * 1.1) * s, 1.0 * s, 0.12), brand, "SmoothPlastic", "Logo")
			kit.box(folder, place * Transform3D(Basis(), Vector3(0, -2.0 * s, z)), Vector3(0.7 * s, 1.0 * s, 0.12), second, "SmoothPlastic", "Logo")
		"spool":
			kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0, z)), Vector3(2.2 * s, 2.6 * s, 0.12), brand, "SmoothPlastic", "Logo")
			for y: float in [-1.6, 1.6]:
				kit.box(folder, place * Transform3D(Basis(), Vector3(0, y * s, z)), Vector3(3.2 * s, 0.6 * s, 0.14), second, "SmoothPlastic", "Logo")
			kit.box(folder, place * Transform3D(Basis(Vector3.BACK, -0.6), Vector3(1.3 * s, -0.4 * s, z + 0.04)), Vector3(0.25 * s, 3.8 * s, 0.12), DARK, "SmoothPlastic", "Logo")
		"flake":
			for index in 3:
				kit.box(folder, place * Transform3D(Basis(Vector3.BACK, PI / 3.0 * index), Vector3(0, 0, z)), Vector3(0.6 * s, 4.4 * s, 0.12), brand, "SmoothPlastic", "Logo")
			kit.rod(folder, place * Vector3(0, 0, z), place * Vector3(0, 0, z * 3.0), 1.2 * s, brand, "SmoothPlastic", "Logo")



static func _pylon(kit: PolishKit, folder: int, lot: Transform3D, foot: Vector3, company: Dictionary) -> void :
	var brand: Color = company["brand"]
	var place: = lot * _out(foot)
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0.4, 0)), Vector3(5.6, 0.8, 2.2), GREY, "Concrete", "PylonFoot", PolishKit.SOLID)
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 7.4, 0)), Vector3(4.6, 13.6, 1.2), brand, "SmoothPlastic", "Pylon", PolishKit.SOLID)
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 14.3, 0)), Vector3(4.8, 0.3, 1.4), DARK, "Metal", "PylonCap")
	_logo(kit, folder, place * Transform3D(Basis(), Vector3(0, 11.2, 0.75)), 3.6, company)
	for side: float in [1.0, -1.0]:
		var face: = place * Transform3D(Basis(Vector3.UP, 0.0 if side > 0.0 else PI), Vector3(0, 6.2, side * 0.62))
		StreetKit.board(kit, folder, face, Vector2(4.0, 3.8), WHITE, String(company["name"]).replace(" ", "\n"), brand, "PylonName")



static func _flags(kit: PolishKit, folder: int, lot: Transform3D, foot: Vector3, brand: Color) -> void :
	for index in 3:
		var at: = foot + Vector3((index - 1) * 3.2, 0, 0)
		kit.post(folder, lot * at, 16.0, 0.3, WHITE, "Metal", "FlagPole", PolishKit.FIXTURE)
		kit.ball(folder, lot * (at + Vector3(0, 16.1, 0)), Vector3(0.45, 0.45, 0.45), Color8(210, 180, 80), "Metal", "FlagTop")
		var flag: = lot * Transform3D(Basis(), at + Vector3(0, 14.2, 0))
		var width: = 4.2
		match index:
			0:
				for stripe in 3:
					kit.box(folder, flag * Transform3D(Basis(), Vector3(width / 2.0 + 0.15, 1.0 - stripe * 1.0, 0)), Vector3(width, 1.0, 0.06), SLO[stripe], "Fabric", "Flag")
			1:
				kit.box(folder, flag * Transform3D(Basis(), Vector3(width / 2.0 + 0.15, 0, 0)), Vector3(width, 3.0, 0.06), EU_BLUE, "Fabric", "Flag")
				for star in 8:
					var a: = TAU * star / 8.0
					kit.box(folder, flag * Transform3D(Basis(), Vector3(width / 2.0 + 0.15 + cos(a) * 0.9, sin(a) * 0.9, 0)), Vector3(0.22, 0.22, 0.08), EU_GOLD, "Fabric", "Flag")
			2:
				kit.box(folder, flag * Transform3D(Basis(), Vector3(width / 2.0 + 0.15, 0, 0)), Vector3(width, 3.0, 0.06), brand, "Fabric", "Flag")
				kit.box(folder, flag * Transform3D(Basis(), Vector3(width / 2.0 + 0.15, 0, 0)), Vector3(width * 0.6, 0.5, 0.08), WHITE, "Fabric", "Flag")



static func _car_park(kit: PolishKit, lot: Transform3D, yard: Array, plot_name: String, fence: float) -> void :
	var folder: = kit.own_folder("IndustryDress")
	var cars: = kit.own_folder("StreetProps")
	var rng: = kit.rng("industry.cars." + plot_name)
	var z: = fence + 4.6
	for span: Vector2 in yard:
		var bays: = int((span.y - span.x - 2.0) / 16.5)
		if bays < 1:
			continue
		var start: = span.x + 1.0 + ((span.y - span.x - 2.0) - bays * 16.5) / 2.0
		for index in bays + 1:
			var x: = start + index * 16.5
			kit.box(folder, lot * Transform3D(Basis(), Vector3(x, 0.26, z)), Vector3(0.3, 0.04, 7.4), LINE, "SmoothPlastic", "BayLine")
		for index in bays:
			if rng.randf() < 0.3:
				continue
			var middle: = lot * Vector3(start + (index + 0.5) * 16.5, 0.24, z)
			var turn: = Basis(Vector3.UP, PI / 2.0 if rng.randf() < 0.5 else - PI / 2.0)
			var place: = Transform3D(turn, middle)
			var model: = kit.store.add_node(cars, "Model", "Car", {"WorldPivot": place})
			kit.box(model, place * Transform3D(Basis(), Vector3(0, 2.4, 0)), Vector3(6.2, 2.6, 14.6), CAR_COLORS[rng.randi() % CAR_COLORS.size()], "SmoothPlastic", "Body")
			kit._made(kit.store.add(PartStore.Shape.BLOCK, place * Transform3D(Basis(), Vector3(0, 2.05, 0)), Vector3(6.4, 2.2, 15), Color.BLACK, "SmoothPlastic", "CarSolid", model, PolishKit.SOLID, 1.0))
			kit._made(kit.store.add(PartStore.Shape.BLOCK, place * Transform3D(Basis(), Vector3(0, 4.2, 1.2)), Vector3(5.6, 2.2, 7.5), Color.BLACK, "SmoothPlastic", "CarSolid", model, PolishKit.SOLID, 1.0))



static func _office_front(kit: PolishKit, folder: int, lot: Transform3D, office: Vector2, front: float, info: Dictionary) -> void :
	for side: float in [-1.0, 1.0]:
		var x: = office.x - 2.6 if side < 0.0 else office.y + 2.6
		if absf(x) > info["width"] / 2.0 - 2.0:
			continue
		var blocked: = false
		for door: Vector2 in info["doors"]:
			blocked = blocked or (x > door.x - 4.0 and x < door.y + 4.0)
		if blocked:
			continue
		var at: = Vector3(x, 0.6, front - 1.6)
		kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 1.0, 0)), Vector3(2.2, 2.0, 2.2), DARK, "Concrete", "Planter", PolishKit.SOLID)
		kit.ball(folder, lot * (at + Vector3(0, 2.8, 0)), Vector3(2.4, 2.0, 2.4), GREEN, "Grass", "PlanterShrub")
	var bench_x: = office.y + 7.0
	var clear: bool = bench_x < info["width"] / 2.0 - 3.0
	for door: Vector2 in info["doors"]:
		clear = clear and not (bench_x > door.x - 6.0 and bench_x < door.y + 6.0)
	if clear:
		var seat: = lot * Transform3D(Basis(), Vector3(bench_x, 0.6, front - 1.4))
		kit.box(folder, seat * Transform3D(Basis(), Vector3(0, 1.4, 0)), Vector3(5.0, 0.3, 1.4), WOOD, "Wood", "Bench")
		kit.box(folder, seat * Transform3D(Basis(), Vector3(0, 2.3, 0.6)), Vector3(5.0, 1.4, 0.25), WOOD, "Wood", "BenchBack")
		for leg: float in [-2.1, 2.1]:
			kit.box(folder, seat * Transform3D(Basis(), Vector3(leg, 0.65, 0)), Vector3(0.3, 1.3, 1.2), DARK, "Metal", "BenchLeg")

		for index in 4:
			var hoop: = seat * Transform3D(Basis(), Vector3(4.5 + index * 1.6, 0, -0.4))
			kit.rod(folder, hoop * Vector3(0, 0, -0.9), hoop * Vector3(0, 2.4, -0.9), 0.18, STEEL, "Metal", "BikeHoop")
			kit.rod(folder, hoop * Vector3(0, 0, 0.9), hoop * Vector3(0, 2.4, 0.9), 0.18, STEEL, "Metal", "BikeHoop")
			kit.rod(folder, hoop * Vector3(0, 2.4, -0.9), hoop * Vector3(0, 2.4, 0.9), 0.18, STEEL, "Metal", "BikeHoop")
		kit.post(folder, seat * Vector3(-3.4, 0, 0), 2.6, 1.3, DARK, "Metal", "Bin")

	var plate_x: = office.x - 1.2
	kit.box(folder, lot * _out(Vector3(plate_x, 6.0, front - 0.12)), Vector3(1.6, 1.0, 0.1), Color8(200, 200, 200), "Metal", "Nameplate")
	kit.box(folder, lot * _out(Vector3(plate_x, 6.0, front - 0.18)), Vector3(1.2, 0.18, 0.06), DARK, "SmoothPlastic", "Nameplate")



static func _wall_lamp(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3) -> void :
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 0, -0.5)), Vector3(0.3, 0.3, 1.0), DARK, "Metal", "LampBracket")
	kit.box(folder, lot * Transform3D(Basis(Vector3.RIGHT, -0.35), at + Vector3(0, -0.1, -1.1)), Vector3(1.4, 0.4, 1.0), DARK, "Metal", "WallLamp")
	kit.box(folder, lot * Transform3D(Basis(Vector3.RIGHT, -0.35), at + Vector3(0, -0.33, -1.1)), Vector3(1.2, 0.05, 0.8), Color8(250, 246, 220), "Neon", "WallLampLens")



static func _camera(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, side: float) -> void :
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 0, -0.4)), Vector3(0.25, 0.25, 0.8), WHITE, "Metal", "CameraArm")
	var aim: = Basis(Vector3.UP, side * 0.7) * Basis(Vector3.RIGHT, -0.3)
	kit.box(folder, lot * Transform3D(aim, at + Vector3(0, -0.2, -0.9)), Vector3(0.5, 0.5, 1.2), WHITE, "SmoothPlastic", "Camera")
	kit.box(folder, lot * Transform3D(aim, at + Vector3(0, -0.2, -0.9) + aim * Vector3(0, 0, -0.62)), Vector3(0.35, 0.35, 0.05), DARK, "Glass", "CameraLens")





static func _roof(kit: PolishKit, folder: int, lot: Transform3D, info: Dictionary, plot_name: String) -> void :
	var roof: float = info["roof"]
	var half_w: float = info["width"] / 2.0
	var half_d: float = info["depth"] / 2.0
	var lights: Variant = info["lights"]

	var spans: Array = []
	if lights == null:
		spans.append(Vector2( - half_w + 4.0, half_w - 4.0))
	else:
		if lights.x - ( - half_w) > 10.0:
			spans.append(Vector2( - half_w + 4.0, lights.x - 3.0))
		if half_w - lights.y > 10.0:
			spans.append(Vector2(lights.y + 3.0, half_w - 4.0))
	for span: Vector2 in spans:
		var middle: = (span.x + span.y) / 2.0
		var room: = span.y - span.x
		if plot_name == "ColdStore":

			var count: = int(room / 9.0)
			for index in count:
				var x: = span.x + (index + 0.5) * room / count
				_condenser(kit, folder, lot, Vector3(x, _roof_at(info, x, half_d * 0.35), half_d * 0.35))
				_condenser(kit, folder, lot, Vector3(x, _roof_at(info, x, - half_d * 0.35), - half_d * 0.35))
			continue
		if plot_name == "Warehouse" and room > 20.0:

			var rows: = int((half_d * 2.0 - 10.0) / 7.0)
			for row in rows:
				var z: = - half_d + 5.0 + (row + 0.5) * 7.0
				var length: = room - 4.0
				var top: = _roof_at(info, middle, z)
				kit.box(folder, lot * Transform3D(Basis(Vector3.RIGHT, -0.4), Vector3(middle, top + 1.3, z)), Vector3(length, 0.2, 5.0), Color8(30, 46, 80), "Glass", "SolarPanel")
				kit.box(folder, lot * Transform3D(Basis(), Vector3(middle, top + 0.6, z + 1.6)), Vector3(length, 1.2, 0.2), STEEL, "Metal", "SolarFrame")
			continue

		_air_handler(kit, folder, lot, Vector3(middle, _roof_at(info, middle, - half_d * 0.4), - half_d * 0.4), minf(room - 2.0, 10.0))
		if room > 14.0:
			_air_handler(kit, folder, lot, Vector3(middle, _roof_at(info, middle, half_d * 0.4), half_d * 0.4), minf(room - 2.0, 8.0))
		for index in 2:
			var x: = span.x + 2.5 + index * (room - 5.0)
			var top: = _roof_at(info, x, 0.0)
			kit.post(folder, lot * Vector3(x, top, 0), 2.4, 2.0, GREY, "Metal", "ExtractFan")
			kit.post(folder, lot * Vector3(x, top + 2.4, 0), 0.4, 2.6, DARK, "Metal", "ExtractFanCap")

	for x: float in [ - half_w + 1.0, half_w - 1.0]:
		for z: float in [ - half_d + 1.0, half_d - 1.0]:
			var top: = _roof_at(info, x, z)
			kit.rod(folder, lot * Vector3(x, top, z), lot * Vector3(x, top + 4.0, z), 0.15, STEEL, "Metal", "LightningRod")
	var ladder_x: = half_w + 0.6
	var ladder_z: = half_d - 6.0
	roof = _roof_at(info, half_w - 1.0, ladder_z)
	for side: float in [-0.8, 0.8]:
		kit.rod(folder, lot * Vector3(ladder_x, 4.0, ladder_z + side), lot * Vector3(ladder_x, roof + 3.0, ladder_z + side), 0.2, STEEL, "Metal", "LadderRail")
	var rung: = 4.5
	while rung < roof + 2.5:
		kit.rod(folder, lot * Vector3(ladder_x, rung, ladder_z - 0.8), lot * Vector3(ladder_x, rung, ladder_z + 0.8), 0.12, STEEL, "Metal", "LadderRung")
		rung += 1.5
	var hoop: = 8.0
	while hoop < roof + 2.0:
		kit.rod(folder, lot * Vector3(ladder_x, hoop, ladder_z - 1.0), lot * Vector3(ladder_x + 1.8, hoop, ladder_z - 1.0), 0.12, STEEL, "Metal", "LadderCage")
		kit.rod(folder, lot * Vector3(ladder_x, hoop, ladder_z + 1.0), lot * Vector3(ladder_x + 1.8, hoop, ladder_z + 1.0), 0.12, STEEL, "Metal", "LadderCage")
		kit.rod(folder, lot * Vector3(ladder_x + 1.8, hoop, ladder_z - 1.0), lot * Vector3(ladder_x + 1.8, hoop, ladder_z + 1.0), 0.12, STEEL, "Metal", "LadderCage")
		hoop += 4.0



static func _air_handler(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, length: float) -> void :
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 0.3, 0)), Vector3(length + 0.6, 0.6, 4.4), DARK, "Metal", "HvacRail")
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 2.3, 0)), Vector3(length, 3.4, 4.0), Color8(214, 216, 214), "Metal", "Hvac")
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 1.5, -2.02)), Vector3(length - 0.4, 0.3, 0.06), GREY, "SmoothPlastic", "HvacStripe")
	for index in 2:
		var x: = (index - 0.5) * length * 0.5
		kit.rod(folder, lot * (at + Vector3(x, 4.0, 0)), lot * (at + Vector3(x, 4.15, 0)), 2.4, DARK, "Metal", "HvacFan")
		kit.box(folder, lot * Transform3D(Basis(), at + Vector3(x, 4.2, 0)), Vector3(2.4, 0.1, 0.18), GREY, "Metal", "HvacGrille")
	for index in 6:
		kit.box(folder, lot * Transform3D(Basis(), at + Vector3((index - 2.5) * length / 7.0, 2.3, 2.02)), Vector3(0.25, 2.6, 0.06), GREY.darkened(0.3), "Metal", "HvacLouvre")



static func _condenser(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3) -> void :
	for x: float in [-3.0, 3.0]:
		kit.box(folder, lot * Transform3D(Basis(), at + Vector3(x, 0.6, 0)), Vector3(0.4, 1.2, 4.6), DARK, "Metal", "CondenserLeg")
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 2.4, 0)), Vector3(7.4, 2.4, 4.8), Color8(226, 228, 230), "Metal", "Condenser")
	for index in 3:
		var x: = (index - 1) * 2.4
		kit.rod(folder, lot * (at + Vector3(x, 3.6, 0)), lot * (at + Vector3(x, 3.8, 0)), 2.2, DARK, "Metal", "CondenserFan")
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 2.4, -2.42)), Vector3(7.0, 1.8, 0.05), Color8(170, 120, 80), "Metal", "CondenserCoil")






static func _chimney(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, roof: float) -> void :
	var foot: = Vector3(at.x, roof, at.z)
	kit.box(folder, lot * Transform3D(Basis(), foot + Vector3(0, 0.6, 0)), Vector3(4.0, 1.2, 4.0), GREY, "Concrete", "StackBase")
	kit.post(folder, lot * foot, 16.0, 2.2, STEEL, "Metal", "Stack")
	for band in 3:
		kit.post(folder, lot * (foot + Vector3(0, 4.0 + band * 4.5, 0)), 0.6, 2.5, DARK, "Metal", "StackBand")
	kit.post(folder, lot * (foot + Vector3(0, 16.0, 0)), 0.8, 2.9, DARK, "Metal", "StackCap")
	for a in 3:
		var dir: = Vector3(cos(TAU * a / 3.0), 0, sin(TAU * a / 3.0))
		kit.rod(folder, lot * (foot + Vector3(0, 12.0, 0)), lot * (foot + dir * 6.0 + Vector3(0, 0.2, 0)), 0.08, DARK, "Metal", "GuyWire")




static func _cyclone(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, roof: float, wall: Vector3) -> void :
	var green: = Color8(70, 96, 74)
	for x: float in [-1.6, 1.6]:
		for z: float in [-1.6, 1.6]:
			kit.rod(folder, lot * (at + Vector3(x, 0, z)), lot * (at + Vector3(x, 9.0, z)), 0.35, STEEL, "Metal", "CycloneLeg", PolishKit.SOLID)
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 1.4, 0)), Vector3(3.0, 2.8, 3.0), green, "Metal", "SawdustBin", PolishKit.SOLID)
	for step in 4:
		kit.post(folder, lot * (at + Vector3(0, 5.0 + step * 1.0, 0)), 1.0, 1.0 + step * 0.8, WHITE, "Metal", "CycloneCone")
	kit.post(folder, lot * (at + Vector3(0, 9.0, 0)), 5.0, 4.0, WHITE, "Metal", "Cyclone")
	kit.post(folder, lot * (at + Vector3(0, 14.0, 0)), 1.5, 1.2, STEEL, "Metal", "CycloneOutlet")
	kit.rod(folder, lot * (at + Vector3(0, 12.0, 0)), lot * Vector3(wall.x, 12.0, wall.z), 1.2, STEEL, "Metal", "Duct")
	kit.rod(folder, lot * Vector3(wall.x, 12.0, wall.z), lot * Vector3(wall.x, roof + 2.0, wall.z), 1.2, STEEL, "Metal", "Duct")



static func _timber(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3) -> void :
	for stack in 2:
		var base: = at + Vector3((stack - 0.5) * 6.0, 0, 0)
		for layer in 5:
			var y: = 0.4 + layer * 0.8
			kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, y + 0.25, 0)), Vector3(5.0, 0.5, 3.2), WOOD.lightened(0.05 * (layer % 2)), "Wood", "Planks", PolishKit.SOLID if layer == 0 else PolishKit.LOOK)
			for spacer: float in [-1.8, 0.0, 1.8]:
				kit.box(folder, lot * Transform3D(Basis(), base + Vector3(spacer, y + 0.6, 0)), Vector3(0.3, 0.2, 3.4), Color8(120, 90, 60), "Wood", "Spacer")



static func _bales(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, company: Dictionary) -> void :
	for index in 3:
		var base: = at + Vector3((index - 1) * 3.4, 0, 0)
		kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, 0.3, 0)), Vector3(3.0, 0.6, 3.0), PALLET, "Wood", "Pallet", PolishKit.SOLID)
		for layer in 2:
			kit.rod(folder, lot * (base + Vector3(-1.4, 1.4 + layer * 1.6, 0)), lot * (base + Vector3(1.4, 1.4 + layer * 1.6, 0)), 1.5, company["brand"] if (index + layer) % 2 == 0 else company["second"], "Fabric", "FabricRoll")



static func _pallets(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, brand: Color) -> void :
	for index in 3:
		var base: = at + Vector3((index - 1) * 3.4, 0, 0)
		kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, 0.3, 0)), Vector3(3.0, 0.6, 3.0), PALLET, "Wood", "Pallet", PolishKit.SOLID)
		for layer in index + 1:
			kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, 1.2 + layer * 1.2, 0)), Vector3(2.8, 1.1, 2.8), brand if layer % 2 == 0 else WHITE, "SmoothPlastic", "Crates")







static func _gable(kit: PolishKit, folder: int, lot: Transform3D, info: Dictionary, render: Color) -> void :
	var main: = _main_roof(info)
	if main.is_empty():
		return
	var rect: Rect2 = main[0]
	var base: float = maxf(info["coping"], main[1])
	var width: = rect.size.x + 0.4
	var deep: = rect.size.y + 0.4
	var middle: = rect.get_center()
	var rise: = deep * 0.11
	var slope: = atan2(rise, deep / 2.0)
	var length: = sqrt(rise * rise + deep * deep / 4.0) + 1.2
	for side: float in [-1.0, 1.0]:

		var half: = Vector3(middle.x, base + rise / 2.0, middle.y + side * deep / 4.0)
		var turn: = Basis() if side < 0.0 else Basis(Vector3.UP, PI)
		kit.wedge(folder, lot * Transform3D(turn, half), Vector3(width, rise, deep / 2.0), render, "Plaster", "Gable", PolishKit.SOLID)
		var tilt: = Basis(Vector3.RIGHT, slope if side > 0.0 else - slope)
		var down: = Vector3(0, - sin(slope), side * cos(slope))
		kit.box(folder, lot * Transform3D(tilt, half + tilt.y * 0.2 + down * 0.6), Vector3(width + 1.2, 0.35, length), SHEET, "Concrete", "RoofSheet")
	kit.box(folder, lot * Transform3D(Basis(), Vector3(middle.x, base + rise + 0.3, middle.y)), Vector3(width + 1.2, 0.5, 1.4), SHEET.darkened(0.2), "Concrete", "RidgeCap")




static func _sawtooth(kit: PolishKit, folder: int, lot: Transform3D, info: Dictionary) -> void :
	var main: = _main_roof(info)
	if main.is_empty():
		return
	var rect: Rect2 = main[0]
	var base: float = maxf(info["coping"], main[1])
	var count: = maxi(3, roundi(rect.size.y / 9.0))
	var deep: = rect.size.y / count
	var tall: = deep * 0.55
	var middle_x: = rect.get_center().x
	for index in count:

		var z: = rect.position.y + (index + 0.5) * deep
		kit.wedge(folder, lot * Transform3D(Basis(), Vector3(middle_x, base + tall / 2.0, z)), Vector3(rect.size.x, tall, deep), SHEET, "Concrete", "SawTooth", PolishKit.SOLID)
		kit.box(folder, lot * Transform3D(Basis(), Vector3(middle_x, base + tall * 0.5, z + deep / 2.0 + 0.06)), Vector3(rect.size.x - 2.0, tall * 0.6, 0.1), Color8(120, 140, 150), "Glass", "NorthLight")
		kit.box(folder, lot * Transform3D(Basis(), Vector3(middle_x, base + tall - 0.15, z + deep / 2.0 - 0.1)), Vector3(rect.size.x + 0.3, 0.3, 0.5), SHEET.darkened(0.2), "Concrete", "ToothCap")




static func _boiler_house(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3, deep: float) -> void :
	var tall: = 11.0
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, tall / 2.0, 0)), Vector3(14.0, tall, deep), BRICK, "Brick", "BoilerHouse", PolishKit.SOLID)
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, tall + 0.3, 0)), Vector3(14.6, 0.6, deep + 0.6), GREY, "Concrete", "BoilerRoof")
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(-3.0, 3.6, deep / 2.0 + 0.05)), Vector3(4.0, 7.2, 0.15), DARK, "Metal", "BoilerDoor")
	var foot: = at + Vector3(4.0, 0, 0)
	var y: = 0.0
	var steps: = [[4.6, 16.0], [3.9, 14.0], [3.3, 13.0]]
	for step: Array in steps:
		var side: float = step[0]
		var rise: float = step[1]
		kit.box(folder, lot * Transform3D(Basis(), foot + Vector3(0, y + rise / 2.0, 0)), Vector3(side, rise, side), BRICK.darkened(0.06 * (y / 14.0)), "Brick", "Chimney", PolishKit.SOLID)
		y += rise
		kit.box(folder, lot * Transform3D(Basis(), foot + Vector3(0, y + 0.25, 0)), Vector3(side + 0.4, 0.5, side + 0.4), GREY, "Concrete", "ChimneyBand")
	kit.box(folder, lot * Transform3D(Basis(), foot + Vector3(0, y + 0.9, 0)), Vector3(3.0, 0.8, 3.0), DARK, "Concrete", "ChimneyCap")

	kit.rod(folder, lot * (at + Vector3(-1.0, tall + 0.6, 0)), lot * (at + Vector3(-1.0, tall + 3.0, 0)), 1.2, STEEL, "Metal", "Flue")
	kit.rod(folder, lot * (at + Vector3(-1.0, tall + 3.0, 0)), lot * (foot + Vector3(-2.0, tall + 3.0, 0)), 1.2, STEEL, "Metal", "Flue")




static func _tubs(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3) -> void :
	for row in 2:
		for index in 3:
			var base: = at + Vector3((index - 1) * 6.8, 0, - row * 7.0)
			kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, 0.25, 0)), Vector3(6.2, 0.5, 3.4), PALLET, "Wood", "Pallet", PolishKit.SOLID)
			var high: = 3 if (row + index) % 3 == 0 else 4
			for level in high:
				var y: = 0.5 + level * 1.05
				kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, y + 0.55, 0)), Vector3(5.6, 0.95, 2.8), TUB, "SmoothPlastic", "Tub", PolishKit.SOLID if level == 0 else PolishKit.LOOK)
				kit.box(folder, lot * Transform3D(Basis(), base + Vector3(0, y + 0.07, 0)), Vector3(6.0, 0.14, 3.2), TUB.darkened(0.08), "SmoothPlastic", "TubRim")




static func _wine_tanks(kit: PolishKit, folder: int, lot: Transform3D, at: Vector3) -> void :
	var count: = 5
	var spacing: = 6.0
	var tall: = 15.0
	kit.box(folder, lot * Transform3D(Basis(), at + Vector3(0, 0.3, 0.8)), Vector3(count * spacing + 2.0, 0.6, 8.0), GREY, "Concrete", "TankPad", PolishKit.SOLID)
	for index in count:
		var foot: = at + Vector3((index - (count - 1) / 2.0) * spacing, 0.6, 0)
		kit.post(folder, lot * foot, tall, 5.0, STAINLESS, "Metal", "Tank", PolishKit.SOLID)
		kit.post(folder, lot * (foot + Vector3(0, tall * 0.6, 0)), 2.2, 5.2, STAINLESS.darkened(0.15), "Metal", "TankJacket")
		kit.post(folder, lot * (foot + Vector3(0, tall, 0)), 0.8, 3.6, STAINLESS, "Metal", "TankCone")
		kit.post(folder, lot * (foot + Vector3(0, tall + 0.8, 0)), 0.6, 1.6, STAINLESS.darkened(0.1), "Metal", "TankManway")
		kit.rod(folder, lot * (foot + Vector3(0, 1.2, -2.4)), lot * (foot + Vector3(0, 1.2, -3.4)), 0.5, STEEL, "Metal", "TankValve")
	var walk: = at + Vector3(0, 0.6 + tall + 0.2, 3.5)
	var long: = count * spacing
	kit.box(folder, lot * Transform3D(Basis(), walk), Vector3(long, 0.25, 1.6), STEEL, "DiamondPlate", "Catwalk")
	kit.rod(folder, lot * (walk + Vector3( - long / 2.0, 3.2, 0.7)), lot * (walk + Vector3(long / 2.0, 3.2, 0.7)), 0.15, STEEL, "Metal", "CatwalkRail")
	for index in 4:
		var x: = - long / 2.0 + index * long / 3.0
		kit.rod(folder, lot * (walk + Vector3(x, 0, 0.7)), lot * (walk + Vector3(x, 3.2, 0.7)), 0.15, STEEL, "Metal", "CatwalkPost")
	var ladder: = Vector3(at.x + long / 2.0 + 0.8, 0.6, walk.z)
	for side: float in [-0.6, 0.6]:
		kit.rod(folder, lot * (ladder + Vector3(0, 0, side)), lot * (ladder + Vector3(0, tall + 3.4, side)), 0.18, STEEL, "Metal", "LadderRail")
	var rung: = 1.4
	while rung < tall:
		kit.rod(folder, lot * (ladder + Vector3(0, rung, -0.6)), lot * (ladder + Vector3(0, rung, 0.6)), 0.12, STEEL, "Metal", "LadderRung")
		rung += 1.5




static func _open_shed(kit: PolishKit, folder: int, lot: Transform3D, x0: float, x1: float, z_front: float, z_back: float) -> void :
	var high: = 13.0
	var low: = 10.5
	var deep: = z_back - z_front
	var middle: = Vector3((x0 + x1) / 2.0, 0, (z_front + z_back) / 2.0)
	for z: float in [z_front + 0.5, z_back - 0.5]:
		var tall: = low if z < middle.z else high
		for x: float in [x0 + 0.5, middle.x, x1 - 0.5]:
			kit.box(folder, lot * Transform3D(Basis(), Vector3(x, tall / 2.0, z)), Vector3(0.9, tall, 0.9), TIMBER, "Wood", "ShedPost", PolishKit.SOLID)
		kit.box(folder, lot * Transform3D(Basis(), Vector3(middle.x, tall + 0.4, z)), Vector3(x1 - x0 + 0.6, 0.8, 0.9), TIMBER, "Wood", "ShedBeam")
	for x: float in [x0 + 0.5, middle.x, x1 - 0.5]:

		var from: = Vector3(x, low + 0.8, z_front + 0.5)
		var to: = Vector3(x, high + 0.8, z_back - 0.5)
		var rafter: = Basis.looking_at(to - from, Vector3.UP)
		kit.box(folder, lot * Transform3D(rafter, (from + to) / 2.0 + Vector3(0, 0.3, 0)), Vector3(0.5, 0.6, from.distance_to(to) + 1.0), TIMBER.darkened(0.1), "Wood", "ShedRafter")
	var slope: = atan2(high - low, deep)
	var tilt: = Basis(Vector3.RIGHT, - slope)
	var sheet: = Vector3(middle.x, (high + low) / 2.0 + 1.3, middle.z)
	kit.box(folder, lot * Transform3D(tilt, sheet), Vector3(x1 - x0 + 1.4, 0.3, sqrt(deep * deep + (high - low) * (high - low)) + 1.6), Color8(128, 108, 90), "Metal", "ShedRoof")
	_timber(kit, folder, lot, Vector3(middle.x, 0.6, middle.z))
