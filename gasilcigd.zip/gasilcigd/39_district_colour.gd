extends RefCounted


















const OLD_TOWN: = preload("res://scripts/world/polish/passes/32_old_town.gd")
const EDGE: = 110.0
const WALLS: = ["Body", "Gable", "Wing", "Parapet", "StairHead", "Penthouse", "Dormer", "GroundFloor", "Garages"]
const ROOFS: = ["Roof", "WingRoof", "DormerRoof", "GarageRoof", "PenthouseRoof"]


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var table: Dictionary = Edition.data().get("districts", {})
	if table.is_empty():
		return ""
	var church: = Vector2(OLD_TOWN.CHURCH.x, OLD_TOWN.CHURCH.y)
	var near_old: float = float(table["old_town"].get("near", 560))
	var layout: Array = kit.layout()["buildings"]
	var districts: Array = Config.Map.Districts
	var counts: = {"old_town": 0, "estate": 0, "residential": 0, "edge": 0}
	var blocks: Dictionary = {}
	var plans: Array = []
	for model in kit.models_under("Map/Buildings"):
		var rows: = store.rows_in(model)
		var body: = -1
		for row in rows:
			if store.name_at(row) == "Body":
				body = row
				break
		if body < 0:
			continue
		var at: = store.position(body)
		var spot: = Vector2(at.x, at.z)
		var building: Dictionary = _nearest(layout, spot)
		var kind: String = building.get("kind", "house")
		var neighbours: = 0
		for other: Dictionary in layout:
			if other != building and spot.distance_to(Vector2(float(other["x"]), float(other["z"]))) < EDGE:
				neighbours += 1
		var district: = "residential"
		if kind == "apartments":
			district = "estate"
		elif spot.distance_to(church) < near_old and kind in ["house", "terrace", "shop", "public"]:
			district = "old_town"
		elif neighbours <= 1 and kind in ["house", "outbuilding"]:
			district = "edge"
		elif kind == "outbuilding" and neighbours <= 3:
			district = "edge"
		counts[district] += 1
		if district == "estate":
			var key: String = _district_key(districts, spot)
			if not blocks.has(key):
				blocks[key] = []
			blocks[key].append(model)
		plans.append([model, rows, body, district, kind, spot])


	var renovated: Dictionary = {}
	for key: String in blocks:
		var list: Array = blocks[key]
		list.sort()
		if list.size() >= 3:
			renovated[list[_roll([key, "renovated"]) % list.size()]] = _pick_list(table["estate"]["renovated"], [key, "render"])

	for plan: Array in plans:
		var model: int = plan[0]
		var rows: PackedInt32Array = plan[1]
		var body: int = plan[2]
		var district: String = plan[3]
		var spot: Vector2 = plan[5]
		var seed_at: = [int(spot.x), int(spot.y)]
		var wall_from: = store.color(body)
		var roof_from: = Color(-1, -1, -1)
		for row in rows:
			if store.name_at(row) == "Roof":
				roof_from = store.color(row)
				break
		var wall: = Color(-1, -1, -1)
		var roof: = Color(-1, -1, -1)
		var plank: = false
		var shutter: = Color(-1, -1, -1)
		var entry: Dictionary = table.get(district, {})
		match district:
			"old_town":
				wall = _weighted(entry["walls"], seed_at + ["wall"])
				roof = _weighted(entry["roofs"], seed_at + ["roof"])
				shutter = Color("#" + String(entry["shutters"]))
			"estate":
				wall = renovated.get(model, _weighted(entry["walls"], seed_at + ["wall"]))
			"residential":
				roof = _weighted(entry["roofs"], seed_at + ["roof"])
			"edge":
				if plan[4] == "outbuilding":
					wall = _weighted(entry["barns"], seed_at + ["barn"])
					roof = _weighted(entry["barn_roofs"], seed_at + ["roof"])
					plank = true
				else:
					wall = _weighted(entry["walls"], seed_at + ["wall"])
		for row in rows:
			var part: = store.name_at(row)
			var color: = store.color(row)
			if wall.r >= 0.0 and part in WALLS and _same(color, wall_from):
				store.set_color(row, wall)
				if plank and part == "Body":
					store.set_material(row, "WoodPlanks")
			elif roof.r >= 0.0 and part in ROOFS and _same(color, roof_from):
				store.set_color(row, roof)
			elif shutter.r >= 0.0 and part == "Shutter":
				store.set_color(row, shutter)
	var by_model: Dictionary = {}
	for plan: Array in plans:
		by_model[plan[0]] = "renovated" if renovated.has(plan[0]) else plan[3]
	kit.set_meta("districts", by_model)
	return "district colours: %d old town, %d estate (%d renovated), %d residential, %d edge" % [
		counts["old_town"], counts["estate"], renovated.size(), counts["residential"], counts["edge"]]


static func _nearest(layout: Array, spot: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for building: Dictionary in layout:
		var distance: = spot.distance_squared_to(Vector2(float(building["x"]), float(building["z"])))
		if distance < best_distance:
			best_distance = distance
			best = building
	return best


static func _district_key(districts: Array, spot: Vector2) -> String:
	var best: = ""
	var best_distance: = INF
	for district: Dictionary in districts:
		var distance: = spot.distance_squared_to(Vector2(float(district["x"]), float(district["z"])))
		if distance < best_distance:
			best_distance = distance
			best = district["key"]
	return best


static func _same(a: Color, b: Color) -> bool:
	return absf(a.r - b.r) + absf(a.g - b.g) + absf(a.b - b.b) < 0.01



static func _roll(seed_of: Array) -> int:
	return int(rand_from_seed(hash(seed_of))[0])


static func _pick_list(list: Array, seed_of: Array) -> Color:
	return Color("#" + String(list[_roll(seed_of) % list.size()]))



static func _weighted(weights: Dictionary, seed_of: Array) -> Color:
	var total: = 0
	for key: String in weights:
		total += int(weights[key])
	var at: = _roll(seed_of) % maxi(total, 1)
	for key: String in weights:
		at -= int(weights[key])
		if at < 0:
			return Color(-1, -1, -1) if key == "keep" else Color("#" + key)
	return Color(-1, -1, -1)
