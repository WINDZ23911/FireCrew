class_name PlowBody
extends RefCounted









const ORANGE: = Color8(238, 118, 22)
const ORANGE_DEEP: = Color8(204, 94, 16)
const DARK: = Color8(34, 36, 40)
const STEEL: = Color8(132, 136, 140)
const CHROME: = Color8(196, 200, 204)
const TYRE: = Color8(24, 24, 26)
const GLASS: = Color8(30, 40, 52)
const RED: = Color8(196, 30, 26)
const WHITE: = Color8(236, 236, 230)
const LAMP: = Color8(210, 210, 200)
const TAIL: = Color8(96, 20, 18)
const BLINK: = Color8(120, 84, 20)


const CAB_FRONT: = -11.3
const CAB_BACK: = -5.6
const CAB_FLOOR: = 3.4
const CAB_ROOF: = 8.1
const HALF: = 4.1

const HOPPER_FRONT: = -4.9
const HOPPER_BACK: = 12.6
const HOPPER_TOP: = 8.3

const AXLES: = [-8.2, 4.6, 8.6]
const WHEEL: = 1.7
const BLADE_Z: = -14.2
const BLADE_TURN: = 18.0

static var _mesh: ArrayMesh


static func _add(list: Array, piece_name: String, size: Vector3, cframe: Transform3D, tint: Color, material: = "Metal", extra: = {}) -> void :
	var piece: = {"name": piece_name, "size": size, "cframe": cframe, "color": tint, "material": material}
	piece.merge(extra)
	list.append(piece)


static func _at(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))



static func _upright(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis(Vector3.FORWARD, PI / 2.0), Vector3(x, y, z))



static func _along(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(x, y, z))


static func pieces() -> Array:
	var list: Array = []
	_chassis(list)
	_cab(list)
	_hopper(list)
	_wheels(list)
	_blade(list)
	return list


static func _chassis(list: Array) -> void :
	for side: float in [-1.0, 1.0]:
		_add(list, "FrameRail", Vector3(0.5, 1.0, 25.4), _at(side * 2.1, 2.0, 0.4), DARK)

	_add(list, "Subframe", Vector3(7.2, 0.6, 17.6), _at(0, 2.8, 3.85), DARK)
	_add(list, "Belly", Vector3(4.4, 0.8, 16.0), _at(0, 1.9, 3.8), DARK)


	_add(list, "FuelTank", Vector3(1.6, 1.6, 3.4), _at(-3.3, 2.4, -3.2), STEEL)
	for z: float in [-4.3, -2.1]:
		_add(list, "TankStrap", Vector3(1.7, 1.7, 0.18), _at(-3.32, 2.4, z), DARK)
	_add(list, "FuelCap", Vector3(0.12, 0.5, 0.5), _at(-4.15, 3.0, -2.6), DARK, "Rubber", {"shape": "cylinder"})
	for z: float in [-4.0, -2.3]:
		_add(list, "AirTank", Vector3(1.4, 1.0, 1.0), _along(3.2, 2.2, z), STEEL, "Metal", {"shape": "cylinder"})
	_add(list, "Toolbox", Vector3(1.4, 1.1, 1.6), _at(3.3, 2.0, -0.9), DARK)
	_add(list, "Exhaust", Vector3(6.4, 0.55, 0.55), _upright(3.3, 6.3, -5.2), CHROME, "Metal", {"shape": "cylinder"})
	_add(list, "ExhaustGuard", Vector3(0.25, 2.6, 0.7), _at(3.62, 5.2, -5.2), DARK)
	_add(list, "ExhaustTip", Vector3(0.6, 0.62, 0.62), _upright(3.3, 9.6, -5.2), DARK, "Rubber", {"shape": "cylinder"})

	_add(list, "Bumper", Vector3(8.4, 1.1, 0.8), _at(0, 1.95, CAB_FRONT - 0.15), DARK, "Rubber")
	_add(list, "BumperStep", Vector3(2.4, 0.2, 0.6), _at(0, 2.55, CAB_FRONT - 0.2), STEEL)
	_add(list, "Hitch", Vector3(4.6, 2.0, 0.5), _at(0, 1.9, CAB_FRONT - 0.85), STEEL)
	for x: float in [-1.6, 1.6]:
		_add(list, "HitchPin", Vector3(0.7, 0.35, 0.35), _at(x, 2.5, CAB_FRONT - 1.15), CHROME, "Metal", {"shape": "cylinder"})
	_add(list, "Plate", Vector3(2.2, 0.5, 0.06), _at(-2.6, 1.95, CAB_FRONT - 0.58), WHITE, "Plastic")

	_add(list, "RearBar", Vector3(8.2, 1.0, 0.4), _at(0, 1.9, HOPPER_BACK + 0.4), DARK)
	for i in 8:
		_add(list, "RearStripe", Vector3(0.96, 0.8, 0.06), _at(-3.6 + i * 1.03, 1.9, HOPPER_BACK + 0.63), RED if i % 2 == 0 else WHITE, "Plastic")
	for side: float in [-1.0, 1.0]:
		_add(list, "TailLamp", Vector3(1.0, 0.6, 0.16), _at(side * 3.4, 2.75, HOPPER_BACK + 0.45), TAIL, "Plastic", {"lamp": "tail"})
		_add(list, "RearBlink", Vector3(0.6, 0.6, 0.16), _at(side * 2.25, 2.75, HOPPER_BACK + 0.45), BLINK, "Plastic", {"lamp": "blink"})


static func _cab(list: Array) -> void :
	var middle: = (CAB_FRONT + CAB_BACK) / 2.0
	var long: = CAB_BACK - CAB_FRONT

	_add(list, "CabLow", Vector3(HALF * 2.0, 2.4, long), _at(0, CAB_FLOOR + 1.2, middle), ORANGE)
	_add(list, "CabHigh", Vector3(HALF * 2.0 - 0.1, 2.3, long - 0.25), _at(0, CAB_FLOOR + 3.55, middle + 0.12), ORANGE)
	_add(list, "Roof", Vector3(HALF * 2.0 - 0.3, 0.35, long - 0.5), _at(0, CAB_ROOF - 0.1, middle + 0.2), ORANGE)
	_add(list, "RoofCap", Vector3(HALF * 2.0 - 0.8, 0.35, long - 1.6), _at(0, CAB_ROOF + 0.2, middle + 0.5), WHITE)

	_add(list, "UnderCab", Vector3(4.0, 1.2, long - 0.4), _at(0, CAB_FLOOR - 0.5, middle), DARK)
	for side: float in [-1.0, 1.0]:
		_add(list, "FrontArch", Vector3(1.7, 0.4, 4.2), _at(side * 3.55, CAB_FLOOR - 0.1, AXLES[0]), DARK, "Rubber")
		for step: Array in [[1.5, -6.0], [2.5, -6.0]]:
			_add(list, "CabStep", Vector3(0.9, 0.18, 1.3), _at(side * (HALF - 0.4), step[0], step[1]), STEEL, "DiamondPlate")
		_add(list, "StepHanger", Vector3(0.12, 1.4, 1.3), _at(side * (HALF - 0.05), 2.1, -6.0), DARK)

	var lean: = Basis(Vector3.RIGHT, deg_to_rad(-7.0))
	_add(list, "Windscreen", Vector3(7.2, 2.5, 0.12), Transform3D(lean, Vector3(0, 6.15, CAB_FRONT + 0.08)), GLASS, "Glass")
	for side: float in [-1.0, 1.0]:
		_add(list, "Pillar", Vector3(0.4, 2.6, 0.3), Transform3D(lean, Vector3(side * 3.8, 6.15, CAB_FRONT + 0.1)), ORANGE_DEEP)
		_add(list, "Wiper", Vector3(2.9, 0.1, 0.1), _at(side * 1.7, 5.15, CAB_FRONT - 0.04), DARK, "Rubber")
	_add(list, "ScreenFoot", Vector3(7.8, 0.3, 0.3), _at(0, 4.85, CAB_FRONT + 0.05), DARK)
	_add(list, "Visor", Vector3(7.8, 0.3, 0.9), Transform3D(Basis(Vector3.RIGHT, deg_to_rad(8.0)), Vector3(0, 7.65, CAB_FRONT - 0.35)), DARK)
	_add(list, "Grille", Vector3(5.0, 1.5, 0.12), _at(0, 3.9, CAB_FRONT - 0.04), DARK)
	for i in 4:
		_add(list, "GrilleBar", Vector3(4.8, 0.14, 0.1), _at(0, 3.35 + i * 0.37, CAB_FRONT - 0.1), STEEL)
	_add(list, "Badge", Vector3(1.6, 0.35, 0.08), _at(0, 4.4, CAB_FRONT - 0.14), CHROME)
	for side: float in [-1.0, 1.0]:


		_add(list, "Headlamp", Vector3(1.3, 0.75, 0.16), _at(side * 3.15, 3.55, CAB_FRONT - 0.06), LAMP, "Plastic", {"lamp": "head"})
		_add(list, "FrontBlink", Vector3(0.45, 0.75, 0.16), _at(side * 3.82, 3.55, CAB_FRONT - 0.06), BLINK, "Plastic", {"lamp": "blink"})
		_add(list, "PlowLampArm", Vector3(0.18, 0.9, 0.18), _at(side * 3.2, 8.45, CAB_FRONT + 0.35), DARK)
		_add(list, "PlowLamp", Vector3(0.9, 0.55, 0.45), _at(side * 3.2, 8.95, CAB_FRONT + 0.3), LAMP, "Plastic", {"lamp": "head"})

	for side: float in [-1.0, 1.0]:
		var x: = side * (HALF + 0.03)
		_add(list, "Door", Vector3(0.06, 4.6, 3.5), _at(x, CAB_FLOOR + 2.35, -8.15), ORANGE)
		_add(list, "DoorSeamFront", Vector3(0.07, 4.6, 0.08), _at(x, CAB_FLOOR + 2.35, -9.9), ORANGE_DEEP)
		_add(list, "DoorSeamBack", Vector3(0.07, 4.6, 0.08), _at(x, CAB_FLOOR + 2.35, -6.4), ORANGE_DEEP)
		_add(list, "DoorWindow", Vector3(0.08, 2.0, 3.0), _at(x, 6.2, -8.2), GLASS, "Glass")
		_add(list, "QuarterWindow", Vector3(0.08, 1.4, 0.9), _at(x, 6.5, -10.6), GLASS, "Glass")
		_add(list, "Handle", Vector3(0.12, 0.18, 0.7), _at(x + side * 0.05, 4.9, -6.9), DARK)
		_add(list, "Stripe", Vector3(0.07, 0.35, long - 0.3), _at(side * (HALF + 0.05), 3.9, middle), WHITE, "Plastic")
		_add(list, "MirrorArm", Vector3(1.1, 0.14, 0.14), _at(side * (HALF + 0.55), 6.9, -10.7), DARK)
		_add(list, "Mirror", Vector3(0.35, 1.5, 0.8), _at(side * (HALF + 1.15), 6.5, -10.7), DARK)
		_add(list, "MirrorGlass", Vector3(0.06, 1.3, 0.6), _at(side * (HALF + 1.15), 6.5, -10.3), GLASS, "Glass")
		_add(list, "WideMirror", Vector3(0.3, 0.6, 0.6), _at(side * (HALF + 1.1), 5.35, -10.75), DARK)
		_add(list, "SideBlink", Vector3(0.08, 0.3, 0.6), _at(side * (HALF + 0.06), 3.0, -10.4), BLINK, "Plastic")

	_add(list, "CabBack", Vector3(7.4, 4.4, 0.3), _at(0, 5.6, CAB_BACK + 0.15), DARK)
	_add(list, "BarFoot", Vector3(0.3, 0.3, 0.8), _at(-2.6, CAB_ROOF + 0.5, -9.4), DARK)
	_add(list, "BarFoot", Vector3(0.3, 0.3, 0.8), _at(2.6, CAB_ROOF + 0.5, -9.4), DARK)
	_add(list, "LightBar", Vector3(6.4, 0.35, 1.0), _at(0, CAB_ROOF + 0.8, -9.4), DARK)
	_add(list, "BarMiddle", Vector3(2.6, 0.45, 0.9), _at(0, CAB_ROOF + 1.15, -9.4), WHITE, "Plastic")
	for side: float in [-1.0, 1.0]:
		_add(list, "BeaconFoot", Vector3(0.25, 1.05, 1.05), _upright(side * 2.6, CAB_ROOF + 1.05, -9.4), DARK, "Plastic", {"shape": "cylinder"})
		_add(list, "Beacon", Vector3(0.8, 0.85, 0.85), _upright(side * 2.6, CAB_ROOF + 1.5, -9.4), BLINK, "Plastic", {"beacon": true, "shape": "cylinder"})


static func _hopper(list: Array) -> void :
	var long: = HOPPER_BACK - HOPPER_FRONT
	var middle: = (HOPPER_FRONT + HOPPER_BACK) / 2.0

	_add(list, "HopperFoot", Vector3(5.4, 1.4, long - 0.4), _at(0, 3.8, middle), ORANGE_DEEP)
	_add(list, "HopperShoulder", Vector3(HALF * 2.0 - 0.8, 0.9, long - 0.2), _at(0, 4.9, middle), ORANGE)
	_add(list, "Hopper", Vector3(HALF * 2.0, 2.9, long), _at(0, 6.8, middle), ORANGE)
	_add(list, "Rim", Vector3(HALF * 2.0 + 0.2, 0.3, long + 0.2), _at(0, HOPPER_TOP + 0.05, middle), STEEL)

	_add(list, "Tarp", Vector3(HALF * 2.0 - 0.4, 0.2, long - 1.4), _at(0, HOPPER_TOP + 0.25, middle + 0.5), Color8(62, 70, 64), "Fabric")
	for i in 5:
		_add(list, "TarpBow", Vector3(HALF * 2.0 - 0.3, 0.12, 0.25), _at(0, HOPPER_TOP + 0.38, HOPPER_FRONT + 2.0 + i * 3.4), Color8(52, 58, 54), "Fabric")
	_add(list, "TarpRoll", Vector3(HALF * 2.0 - 0.2, 0.7, 0.7), _at(0, HOPPER_TOP + 0.45, HOPPER_FRONT + 0.6), Color8(52, 58, 54), "Fabric", {"shape": "cylinder"})
	for side: float in [-1.0, 1.0]:

		for i in 6:
			_add(list, "Rib", Vector3(0.2, 3.4, 0.35), _at(side * (HALF + 0.08), 6.55, HOPPER_FRONT + 0.6 + i * (long - 1.2) / 5.0), ORANGE_DEEP)
		_add(list, "SideRail", Vector3(0.2, 0.3, long), _at(side * (HALF + 0.12), 7.8, middle), ORANGE_DEEP)
		_add(list, "SideBand", Vector3(0.06, 0.32, long - 0.6), _at(side * (HALF + 0.05), 5.55, middle), WHITE, "Plastic")

		_add(list, "Mudguard", Vector3(2.1, 0.25, 8.0), _at(side * 3.55, 3.75, (AXLES[1] + AXLES[2]) / 2.0), DARK, "Rubber")
		_add(list, "MudguardLip", Vector3(0.12, 0.8, 8.0), _at(side * 4.55, 3.4, (AXLES[1] + AXLES[2]) / 2.0), DARK, "Rubber")
		_add(list, "MudFlap", Vector3(1.8, 1.7, 0.08), _at(side * 3.55, 1.6, AXLES[2] + 2.1), DARK, "Rubber")
		_add(list, "SideMarker", Vector3(0.08, 0.25, 0.45), _at(side * (HALF + 0.08), 3.0, 6.6), BLINK, "Plastic")

	_add(list, "BackWall", Vector3(HALF * 2.0, 4.2, 0.2), _at(0, 6.2, HOPPER_BACK + 0.05), ORANGE_DEEP)
	for i in 3:
		_add(list, "BackRib", Vector3(HALF * 2.0, 0.22, 0.25), _at(0, 4.9 + i * 1.4, HOPPER_BACK + 0.2), ORANGE)
	_add(list, "ControlBox", Vector3(1.6, 1.2, 0.6), _at(2.4, 3.9, HOPPER_BACK + 0.4), DARK)
	for x: float in [-3.95, -2.95]:
		_add(list, "LadderRail", Vector3(0.12, 5.6, 0.12), _at(x, 5.6, HOPPER_BACK + 0.55), STEEL)
	for i in 6:
		_add(list, "LadderRung", Vector3(1.0, 0.1, 0.1), _at(-3.45, 3.3 + i * 0.95, HOPPER_BACK + 0.55), STEEL)
	_add(list, "Chute", Vector3(1.6, 1.4, 1.2), _at(0, 2.1, HOPPER_BACK + 0.9), STEEL)
	_add(list, "SpinnerArm", Vector3(0.4, 0.4, 1.0), _at(0, 1.4, HOPPER_BACK + 1.5), DARK)
	_add(list, "Spinner", Vector3(0.2, 2.4, 2.4), _upright(0, 1.0, HOPPER_BACK + 1.9), DARK, "Metal", {"shape": "cylinder"})
	for i in 4:
		var turn: = Basis(Vector3.UP, i * PI / 4.0)
		_add(list, "Vane", Vector3(2.2, 0.3, 0.12), Transform3D(turn, Vector3(0, 1.22, HOPPER_BACK + 1.9)), ORANGE)


static func _wheels(list: Array) -> void :
	for index in AXLES.size():
		var z: float = AXLES[index]
		var rear: = index > 0
		for side: float in [-1.0, 1.0]:
			var x: = side * (3.45 if rear else 3.55)
			var width: = 1.9 if rear else 1.3
			_add(list, "Tyre", Vector3(width, WHEEL * 2.0, WHEEL * 2.0), _at(x, WHEEL, z), TYRE, "Rubber", {"shape": "cylinder"})
			if rear:

				_add(list, "TwinGap", Vector3(0.14, WHEEL * 1.9, WHEEL * 1.9), _at(x + side * 0.05, WHEEL, z), Color8(14, 14, 16), "Rubber", {"shape": "cylinder"})
			_add(list, "Rim", Vector3(width + 0.04, 1.9, 1.9), _at(x, WHEEL, z), STEEL, "Metal", {"shape": "cylinder"})
			_add(list, "Hub", Vector3(width + 0.14, 0.8, 0.8), _at(x, WHEEL, z), DARK, "Metal", {"shape": "cylinder"})
			_add(list, "HubCap", Vector3(width + 0.22, 0.4, 0.4), _at(x, WHEEL, z), CHROME, "Metal", {"shape": "cylinder"})





static func _blade(list: Array) -> void :
	var frame: = Transform3D(Basis(Vector3.UP, deg_to_rad(BLADE_TURN)), Vector3(0, 0, BLADE_Z))
	var wide: = 12.0

	for i in 7:
		var lean: = deg_to_rad(i * 6.0)
		var height: = 0.75 + 0.45 * i
		var ahead: = -0.035 * i * i
		_add(list, "Moldboard", Vector3(wide, 0.62, 0.3), frame * Transform3D(Basis(Vector3.RIGHT, lean), Vector3(0, height, ahead)), ORANGE)
	_add(list, "CuttingEdge", Vector3(wide + 0.1, 0.45, 0.4), frame * _at(0, 0.32, 0.02), STEEL)
	_add(list, "Flap", Vector3(wide - 0.4, 0.5, 0.1), frame * Transform3D(Basis(Vector3.RIGHT, deg_to_rad(20.0)), Vector3(0, 3.75, -1.55)), DARK, "Rubber")
	for i in 6:
		_add(list, "BladeRib", Vector3(0.25, 2.9, 0.5), frame * _at(-5.2 + i * 2.08, 1.85, 0.45), DARK)
	_add(list, "BladeBeam", Vector3(wide - 1.0, 0.5, 0.5), frame * _at(0, 1.5, 0.75), DARK)
	for side: float in [-1.0, 1.0]:
		var end: = side * (wide / 2.0 - 0.75)
		for row in 2:
			for col in 2:
				var red: = (row + col) % 2 == 0
				_add(list, "EndBoard", Vector3(0.7, 0.7, 0.06), frame * _at(end + (col - 0.5) * 0.72, 1.35 + row * 0.72, -0.2), RED if red else WHITE, "Plastic")
		_add(list, "Skid", Vector3(0.6, 0.35, 1.0), frame * _at(side * (wide / 2.0 - 0.5), 0.2, 0.6), STEEL)

		var pole: = frame * _at(side * (wide / 2.0 - 0.15), 0.0, 0.35)
		for band in 4:
			_add(list, "Marker", Vector3(0.14, 0.75, 0.14), pole * _at(0, 3.9 + band * 0.75, 0), ORANGE if band % 2 == 0 else DARK, "Plastic")
		_add(list, "MarkerTip", Vector3(0.24, 0.3, 0.24), pole * _at(0, 7.05, 0), RED, "Plastic")

		var from: = Vector3(side * 1.6, 2.0, CAB_FRONT - 1.1)
		var to: Vector3 = frame * Vector3(side * 2.6, 1.5, 0.9)
		_add(list, "PushArm", Vector3(0.45, 0.45, from.distance_to(to)), _between(from, to), DARK)
		var ram_from: = Vector3(side * 1.2, 2.7, CAB_FRONT - 1.1)
		var ram_to: Vector3 = frame * Vector3(side * 1.6, 2.6, 0.75)
		_add(list, "Ram", Vector3(ram_from.distance_to(ram_to) * 0.5, 0.32, 0.32), _between(ram_from, ram_to) * Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(0, 0, ram_from.distance_to(ram_to) * 0.2)), DARK, "Metal", {"shape": "cylinder"})
		_add(list, "RamRod", Vector3(ram_from.distance_to(ram_to) * 0.5, 0.18, 0.18), _between(ram_from, ram_to) * Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(0, 0, - ram_from.distance_to(ram_to) * 0.25)), CHROME, "Metal", {"shape": "cylinder"})



static func _between(from: Vector3, to: Vector3) -> Transform3D:
	return Transform3D(Basis.looking_at(to - from, Vector3.UP), (from + to) / 2.0)



static func mesh() -> ArrayMesh:
	if _mesh == null:
		_mesh = BusBody.merged(pieces())
	return _mesh
