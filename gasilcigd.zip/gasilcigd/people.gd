extends ProofDebug
























func _fire_with(count: int, report: String, prefix: = "Family house") -> House:
	var fire: = FireService.current
	var house: = _house(prefix)
	VictimService.current.forced = count
	VictimService.current.forced_report = report
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	fire.run_incident(house)
	await _wait(0.5)
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	return house



func _floor_at(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(at, at - Vector3(0, 30, 0), World.LAYER_SOLID)
	return (hit["position"] if not hit.is_empty() else at) + Vector3(0, 0.3, 0)


func _in_room(house: House, room: Dictionary) -> Vector3:
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	return _floor_at(house.lot * Vector3((low.x + high.x) / 2.0, low.y + 3.0, (low.z + high.z) / 2.0))



func _teammate(name_shown: String, at: Vector3) -> Player:
	var other: = Player.new()
	other.is_local = false
	other.display_name = name_shown
	other.name = "Teammate"
	player.get_parent().add_child(other)
	other.teleport(at)
	return other


func _known_on_card() -> int:
	return int(Game.incident.get("victims", 0))


func _scenario_people() -> void :
	await _wait(1.0)
	var people: = VictimService.current

	var house: = _house("Family house")
	var sky: = Sky3D.current
	var hour_was: float = sky.hour if sky else 12.0
	var shares: = {}
	for at_hour: float in [2.0, 12.0]:
		if sky:
			sky.hour = at_hour
		var kinds: = {}
		for attempt in 300:
			var rooms: Array = people._draw_rooms(house, null)
			var kind: = VictimService.room_kind(rooms[0]["room"]["name"])
			kinds[kind] = int(kinds.get(kind, 0)) + 1
		shares[at_hour] = kinds
	if sky:
		sky.hour = hour_was
	var night_bed: = float(shares[2.0].get("bed", 0)) / 300.0
	var day_rooms: = float(shares[12.0].get("day", 0)) / 300.0
	var day_bed: = float(shares[12.0].get("bed", 0)) / 300.0
	print("people: at night the first room is a bedroom %.0f%% of the time (by day %.0f%%); by day a room of the day %.0f%%: %s" % [night_bed * 100.0, day_bed * 100.0, day_rooms * 100.0, shares])
	_check(night_bed >= 0.55 and night_bed > day_bed + 0.25, "at night people are mostly in the bedrooms")
	var night_day: = float(shares[2.0].get("day", 0)) / 300.0
	_check(day_rooms >= 0.3 and day_rooms > night_day * 3.0 and day_rooms > day_bed, "by day they are mostly in the kitchen and living room")
	var anchors: = 0
	for room_name: String in house.rooms:
		anchors += people._anchors(house, house.rooms[room_name]).size()
	_check(anchors > house.rooms.size(), "the rooms have beds, windows and doors to be found by (%d)" % anchors)


	house = await _fire_with(2, "out")
	var report: Variant = people.report_words()
	print("people: the call says '%s'; %d inside; the card shows %d; next '%s'" % [Text.say(report, "en"), people.victims.size(), _known_on_card(), Text.say(Game.incident.get("next"), "en")])
	_check(people.victims.size() == 2 and people.report == "out", "two inside, though the call says everyone is out")
	_check(_known_on_card() == 0 and not Game.incident.has("victims"), "the card shows nobody before anyone is found")
	var placed: Array = []
	for victim: Victim in people.victims:
		placed.append("%s by the %s" % [victim.room, victim.spot])
	print("people: they lie %s" % [placed])
	_check(people.victims.any( func(v: Victim) -> bool: return v.spot in VictimService.SPOT_KINDS), "at least one lies by a bed, a window, a door or furniture, not in the open floor")

	var first: Victim = people.victims[0]
	var cues_before: = people.cues
	_stand_outside(house, first.position(), 12.0)
	await _wait(12.0)
	print("people: from %.0f studs outside, %d cues heard" % [player.root_position().distance_to(first.position()), people.cues - cues_before])
	_check(people.cues > cues_before, "someone not found yet coughs or calls out")
	_check( not first.found, "and is not found from outside")

	player.teleport(_in_room(house, house.rooms[first.room]))
	await _wait(1.0)
	if not first.found:
		player.teleport(CallKit.ground_at(first.position() + Vector3(2.5, 2, 0)) + Vector3(0, 0.3, 0))
		await _wait(1.0)
	print("people: in the %s: found %s; the card shows %d; next '%s'" % [first.room, first.found, _known_on_card(), Text.say(Game.incident.get("next"), "en")])
	_check(first.found, "going into their room finds them")
	_check(_known_on_card() >= 1 and _known_on_card() <= 2, "the card counts who is known")
	_view(player.head_position() + Vector3(0, 1.5, 0), first.position())
	await _wait(0.3)
	await _snap("found")
	_view_player()



	FireService.current._runs += 1
	FireService.current.incident = {}
	people.finish()
	await _wait(0.5)
	house = await _fire_with(0, "maybe")
	var next: Variant = Game.incident.get("next")
	print("people: 'maybe', nobody inside: the card says '%s'" % Text.say(next, "en"))
	_check(next is Dictionary and str(next.get("k", "")) == "calls.victims.next.search", "the card says to search the house")
	for room_name: String in house.rooms:
		if not house.rooms[room_name].get("open", false):
			player.teleport(_in_room(house, house.rooms[room_name]))
			await _wait(0.6)
	print("people: every room gone into: all searched %s; next '%s'" % [people.searched_all, Text.say(Game.incident.get("next"), "en")])
	_check(people.searched_all, "every room searched: all clear")
	_check( not (Game.incident.get("next") is Dictionary and str(Game.incident["next"].get("k", "")) == "calls.victims.next.search"), "and the card no longer says to search")
	people.forced_report = ""
	await _done()


func _scenario_carry() -> void :
	await _wait(1.0)
	var people: = VictimService.current
	var house: = await _fire_with(1, "maybe")
	var victim: Victim = people.victims[0]
	var room: Dictionary = house.rooms[victim.room]
	var fire: = FireService.current

	fire.incident["rooms"][victim.room]["smoke"] = 1.0
	house.show_smoke(victim.room, 1.0)
	player.teleport(CallKit.ground_at(victim.position() + Vector3(2.0, 2, 0)) + Vector3(0, 0.3, 0))
	await _wait(0.4)
	_check(people.lift(victim, player), "lifted")
	await _wait(0.3)
	var dragged_pace: = player.walk_speed
	print("people: in smoke %.2f: carried as '%s' at %.1f" % [fire.smoke_at(player.root_position()), victim.mode, dragged_pace])
	_check(victim.mode == "drag" and is_equal_approx(dragged_pace, float(Config.Victims.Drag.Speed)), "in smoke they are dragged, at Drag.Speed")


	player.teleport(CallKit.ground_at(house.position + Vector3(40, 5, 40)) + Vector3(0, 0.3, 0))
	await _wait(float(Config.Victims.Drag.Settle) + 0.6)
	var carried_pace: = player.walk_speed
	print("people: in clean air: carried as '%s' at %.1f" % [victim.mode, carried_pace])
	_check(victim.mode == "carry" and is_equal_approx(carried_pace, float(Config.Victims.CarrySpeed)), "in clean air they are carried over the shoulders, faster")

	var mate: = _teammate("Cene", player.global_position + Vector3(2.5, 0, 0))
	await _wait(0.2)
	_check(people.help(victim, mate), "a teammate takes the legs")
	await _wait(0.3)
	print("people: two carrying: %.1f" % player.walk_speed)
	_check(is_equal_approx(player.walk_speed, float(Config.Victims.Drag.TeamCarry)), "two carry faster (Drag.TeamCarry)")
	mate.teleport(player.global_position + Vector3(30, 0, 0))
	await _wait(0.3)
	print("people: the teammate fell behind: helper %s, pace %.1f" % [victim.helper != null, player.walk_speed])
	_check(victim.helper == null and is_equal_approx(player.walk_speed, float(Config.Victims.CarrySpeed)), "a helper who falls behind lets go")
	mate.queue_free()


	people.put_down(victim)
	await _wait(0.2)
	var spot: = _in_room(house, room)
	player.teleport(spot)
	await _wait(0.2)
	if victim.state == "carried":
		people.put_down(victim)
	victim.figure.global_transform = Figure.lying(spot - Vector3(0, 0.3, 0) + Vector3(2.5, 0, 0), Vector3.FORWARD, 0.05)
	fire.incident["rooms"][victim.room]["smoke"] = 1.0
	house.show_smoke(victim.room, 1.0)
	var full: = func(_at: Vector3) -> float: return 1.0
	var before: = victim.condition
	people.step(1.0, full, false)
	var lying_loss: = before - victim.condition
	people.lift(victim, player)
	victim.mode = "carry"
	people._hang_carried(victim)
	await _wait(0.1)
	before = victim.condition
	people.step(1.0, full, false)
	var carried_loss: = before - victim.condition
	print("people: in full smoke, a second: lying %.2f, carried up into it %.2f" % [lying_loss, carried_loss])
	_check(lying_loss < carried_loss * 0.6, "lying under the smoke they breathe much less than carried up into it")

	people.put_down(victim)
	await _wait(0.2)
	victim.figure.global_transform = Figure.lying(spot - Vector3(0, 0.3, 0) + Vector3(2.5, 0, 0), Vector3.FORWARD, 0.05)

	var clear: = func(_at: Vector3) -> float: return 0.0
	before = victim.condition
	people.step(1.0, clear, true)
	var shut_loss: = before - victim.condition
	print("people: in a room without smoke, the fire burning: %.3f a second (InsideDrain %.2f)" % [shut_loss, float(Config.Victims.InsideDrain)])
	_check(shut_loss < float(Config.Victims.InsideDrain) * 0.5, "a room the smoke does not reach spares them")

	var open: = CallKit.ground_at(Vector3(-150, 5, 140)) + Vector3(0, 0.3, 0)
	player.teleport(open)
	player.rig.rotation.y = 0.0
	await _wait(0.2)
	victim.figure.global_transform = Figure.lying(open + Vector3(0, -0.3, -2.5), Vector3.FORWARD, 0.05)
	people.lift(victim, player)
	for way: String in ["drag", "carry"]:
		victim.mode = way
		victim.mode_since = Game.now() + 30.0
		people._hang_carried(victim)
		await _wait(0.2)
		_view(open + Vector3(11, 5, 2), open + Vector3(0, 2, 1.5))
		await _wait(0.2)
		await _snap(way)
	people.put_down(victim)
	_view_player()
	await _done()


func _scenario_handover() -> void :
	await _wait(1.0)
	var people: = VictimService.current
	var house: = await _fire_with(1, "count")
	var ambulance: = AmbulanceService.current
	var waited: = 0.0
	while not ambulance.arrived() and waited < 60.0:
		await _wait(0.5)
		waited += 0.5
	_check(ambulance.arrived(), "the ambulance has come")
	waited = 0.0
	while ambulance.arrived() and ambulance._scene["medics"].size() < int(Config.Victims.Medics) and waited < 20.0:
		await _wait(0.5)
		waited += 0.5
	await _wait(0.5)
	var zone: Vector3 = ambulance.zone_position()

	var box: = BoxShape3D.new()
	var size: Vector3 = Config.Victims.Zone
	box.size = Vector3(size.x, 3.0, size.z)
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = box
	query.transform = Transform3D(ambulance._scene["zone"].basis, zone + Vector3(0, 2.2, 0))
	query.collision_mask = World.LAYER_SOLID | World.LAYER_VEHICLE
	_check(Game.world.get_world_3d().direct_space_state.intersect_shape(query, 1).is_empty(), "the green box is clear of wrecks and walls")
	var medics: Array = ambulance._scene["medics"]
	_check(medics.size() >= 1, "the medics are out (%d)" % medics.size())
	var victim: Victim = people.victims[0]
	player.teleport(CallKit.ground_at(victim.position() + Vector3(2.0, 2, 0)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	people.lift(victim, player)

	var homes: = {}
	for medic: Medic in medics:
		homes[medic] = medic.global_position
	var away: = (zone - house.position)
	away.y = 0.0
	var toward: = away.normalized()
	var stand: = CallKit.ground_at(zone + toward * 26.0 + Vector3(0, 5, 0)) + Vector3(0, 0.3, 0)
	player.teleport(stand)
	await _wait(2.5)
	var walked: = 0.0
	for medic: Medic in medics:
		walked = maxf(walked, medic.global_position.distance_to(homes[medic]))
	print("people: a carrier %.0f studs from the box: a medic walked %.1f studs out to meet them; victim %s" % [Vector2(stand.x - zone.x, stand.z - zone.z).length(), walked, victim.state])
	_check(walked > 4.0, "a medic walks out to meet the carrier")
	_view(stand + Vector3(10, 8, 10), (stand + zone) / 2.0)
	await _wait(0.3)
	await _snap("meet")

	var nearest: Medic = medics[0]
	for medic: Medic in medics:
		if medic.global_position.distance_to(stand) < nearest.global_position.distance_to(stand):
			nearest = medic
	player.teleport(CallKit.ground_at(nearest.global_position + (stand - nearest.global_position).normalized() * 3.0 + Vector3(0, 4, 0)) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	print("people: beside the medic (%.1f studs), %.1f studs from the box: victim %s" % [player.root_position().distance_to(nearest.global_position), Vector2(player.global_position.x - zone.x, player.global_position.z - zone.z).length(), victim.state])
	_check(victim.state == "out", "the medic takes the person from the carrier")
	await _wait(3.0)
	var back: = 0.0
	for medic: Medic in medics:
		back = maxf(back, medic.global_position.distance_to(homes[medic]))
	_check(back < 1.0, "and the medics go back to the stretcher")
	await _done()



func _casualties(count: int) -> Array[Victim]:
	var at: = CallKit.ground_at(Vector3(-140, 5, 120))
	var seats: Array = []
	for index in count:
		seats.append({"lying": Figure.lying(CallKit.ground_at(at + Vector3(index * 4.0, 5, 0)), Vector3.FORWARD, 0.05)})
	return VictimService.current.begin_at({"lot": Transform3D(Basis.IDENTITY, at), "size": Vector3(20, 6, 20), "name": "the scene"}, seats, 0.2)


func _scenario_triage() -> void :
	await _wait(1.0)
	var people: = VictimService.current
	Alarm.active = true
	Alarm.checks = {}
	var victims: = _casualties(4)
	var tags: Array = []
	for victim: Victim in victims:
		tags.append(victim.tag)
	print("people: four casualties, tags %s, shown %s" % [tags, victims.map( func(v: Victim) -> bool: return v.tagged)])
	_check(people.triage and tags.has("red") and victims.all( func(v: Victim) -> bool: return not v.tag.is_empty() and not v.tagged), "each has a hidden START tag, at least one red")
	_check(victims[0].tag_prompt.enabled, "a casualty can be assessed (F)")

	var first: Victim = victims[0]
	_stand_by(first.position(), Vector3(2.2, 0, 0.6))
	_look_at(first.position())
	await _wait(0.3)
	await _hold("item", float(Config.Victims.Triage.Assess) + 0.6)
	_check(first.tagged and is_instance_valid(first.tag_label), "assessing shows the tag")
	for victim: Victim in victims:
		people.assess(victim, player)
	await _wait(0.5)
	_view(first.position() + Vector3(-4, 12, 16), first.position() + Vector3(6, 0, 0))
	await _wait(0.3)
	await _snap("tags")
	_view_player()
	var green: Array = victims.filter( func(v: Victim) -> bool: return v.tag == "green")
	if not green.is_empty():
		_check(green[0].state == "walking", "a green gets up and walks to the ambulance")

	var low: Variant = null
	for victim: Victim in victims:
		if victim.tag != "red" and victim.state == "lying":
			low = victim
	if low == null:
		low = victims.filter( func(v: Victim) -> bool: return v.tag != "red")[0]
		low.state = "lying"
	var zone: Vector3 = AmbulanceService.current.zone_position()
	people.lift(low, player)
	player.teleport(zone + Vector3(0, 0.5, 0))
	await _wait(0.2)
	people.step(0.25, func(_at: Vector3) -> float: return 0.0, false)
	print("people: a %s handed over while a red waits: state %s, triage check %s" % [low.tag, low.state, Alarm.checks.get("triage")])
	_check(low.state == "out" and Alarm.checks.get("triage") == false, "out of order: the triage check fails")
	people.finish()

	Alarm.checks = {}
	victims = _casualties(3)
	for victim: Victim in victims:
		people.assess(victim, player)
	var order: = victims.duplicate()
	order.sort_custom( func(a: Victim, b: Victim) -> bool: return int(a.tag == "red") > int(b.tag == "red"))
	for victim: Victim in order:
		if victim.state != "lying":
			continue
		var stand: = CallKit.ground_at(victim.position() + Vector3(2, 3, 0)) + Vector3(0, 0.3, 0)
		player.teleport(stand)
		await _wait(0.1)
		people.lift(victim, player)
		player.teleport(zone + Vector3(0, 0.5, 0))
		await _wait(0.1)
		people.step(0.25, func(_at: Vector3) -> float: return 0.0, false)
	print("people: reds first: triage check %s, share %.2f" % [Alarm.checks.get("triage"), people.triage_share()])
	_check(Alarm.checks.get("triage") == true, "reds first, everyone assessed: the triage check passes")
	people.finish()
	Alarm.active = false
	await _done()


func _scenario_downed() -> void :
	await _wait(1.0)
	Alarm.active = true
	Alarm.checks = {}
	var down: = DownService.current
	var air: = AirService.current
	var open: = CallKit.ground_at(Vector3(-150, 5, 140)) + Vector3(0, 0.3, 0)
	player.teleport(open)
	air.take_set(player, "rack")
	await _wait(0.5)

	Config.Air["StillWarning"] = 2
	Config.Air["StillAlarm"] = 3
	await _wait(4.0)
	print("people: still for 4 s, set on, mask %s: alarm %s" % [player.get_attr("Mask"), player.get_attr("Distress")])
	_check(player.get_attr("Mask") != true and player.get_attr("Distress") == true, "the motion alarm sounds with a set on, mask off")
	Config.Air["StillWarning"] = 20
	Config.Air["StillAlarm"] = 30
	player.teleport(open + Vector3(3, 0, 0))
	player.velocity = Vector3(6, 0, 0)
	await _wait(0.6)

	down.mayday(player, true)
	await _wait(0.6)
	_check(player.get_attr("Mayday") == true and player.get_attr("Distress") == true, "a Mayday sounds the alarm")
	_check(HudPeople.current != null and not HudPeople.current.own_text().is_empty(), "the Mayday shows on the screen")
	down.mayday(player, false)


	player.take_damage(1000.0)
	await _wait(0.5)
	print("people: at no health: Down %s, health %.0f, frozen %s, alarm %s; the screen says '%s'" % [player.get_attr("Down"), player.health, player.frozen, player.get_attr("Distress"), HudPeople.current.own_text().replace("\n", " / ")])
	_check(player.get_attr("Down") != null and player.health <= 0.0 and player.frozen, "down where they fell, not home at the station")
	_check(player.global_position.distance_to(open) < 12.0, "and still where they fell")
	_check(player.get_attr("Distress") == true, "their alarm sounds")
	_view(player.global_position + Vector3(7, 6, 7), player.global_position)
	await _wait(0.3)
	await _snap("down")

	var mate: = _teammate("Cene", player.global_position + Vector3(2.0, 0, 0))
	await _wait(0.3)
	_check(player._rescue_prompt != null and player._rescue_prompt.shown_to(mate), "a teammate is offered to drag them out")
	down.drag(player, mate)
	await _wait(0.3)
	mate.teleport(mate.global_position + Vector3(0, 0, 8))
	await _wait(0.3)
	var behind: = player.global_position.distance_to(mate.global_position)
	print("people: dragged by %s: %.1f studs behind them" % [DownService.rescuer_of(player).display_name if DownService.rescuer_of(player) else "-", behind])
	_check(DownService.rescuer_of(player) == mate and behind < 8.0, "dragged behind the rescuer")
	_view(player.global_position + Vector3(8, 6, -6), player.global_position)
	await _wait(0.3)
	await _snap("dragged")
	await _wait(float(Config.Down.ReviveTime) + 1.0)
	print("people: in clean air: Down %s, health %.0f, revived %d" % [player.get_attr("Down"), player.health, down.revived])
	_check(player.get_attr("Down") == null and is_equal_approx(player.health, float(Config.Down.ReviveHealth)) and not player.frozen, "out in clean air they come round")
	mate.queue_free()
	_view_player()


	Config.Down["Time"] = 3
	player.teleport(open)
	await _wait(0.3)
	player.take_damage(1000.0)
	await _wait(4.0)
	var truck: = Vehicle.named("Fire Truck")
	print("people: nobody came: Down %s, health %.0f, %.0f studs from the pumper; check %s" % [player.get_attr("Down"), player.health, player.global_position.distance_to(truck.global_position) if truck else -1.0, Alarm.checks.get("nobodyDown")])
	_check(player.get_attr("Down") == null and player.health >= player.max_health - 0.1, "up again after Down.Time")
	_check(truck != null and player.global_position.distance_to(truck.global_position) < 30.0, "by the trucks")
	_check(Alarm.checks.get("nobodyDown") == false, "and the report's 'nobody left down' check fails")
	Config.Down["Time"] = 90
	Alarm.active = false
	await _done()


func _scenario_ceiling() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _fire_with(0, "")

	var room_name: = ""
	var opening: Dictionary = {}
	for each: Dictionary in house.openings:
		if each["door"] is Dictionary and house.rooms.has(each["a"]) and house.rooms.has(each["b"]):
			opening = each
			room_name = each["a"]
			break
	if not _check( not opening.is_empty(), "a room with an inside door"):
		await _done()
		return
	var door: Dictionary = opening["door"]
	if not door["open"]:
		house._swing(door, true, false)
		await _wait(0.8)
	var at: = (door["shut"] as Transform3D).origin
	_check(opening["passes"].call(), "the doorway is open")
	player.teleport(_floor_at(at + Vector3(0, 2, 0) + (house.lot.basis.z * 3.0)))
	await _wait(0.3)
	var health: = player.health
	_check(fire.ceiling_down(house, room_name), "the ceiling comes down")
	await _wait(0.4)
	print("people: the ceiling in the %s: debris %s, the way passes %s; the player %.0f -> %.0f, knocked %s" % [room_name, door.get("debris"), opening["passes"].call(), health, player.health, player.get_attr("Knocked")])
	_check(door.get("debris", false) and not opening["passes"].call(), "the doorway is filled: no way through, for people or smoke")
	_check(player.get_attr("Knocked") != true and player.health > health - 5.0, "whoever stood near is neither hit nor knocked flat")
	var through: = Game.world.raycast(at + Vector3(0, -1.0, 0) + house.lot.basis.z * 3.0, at + Vector3(0, -1.0, 0) - house.lot.basis.z * 3.0, World.LAYER_SOLID)
	_check( not through.is_empty(), "the heap is solid")
	for side: float in [1.0, -1.0]:
		var stand: = _floor_at(at + Vector3(0, 2, 0) + house.lot.basis.z * 8.0 * side)
		if house.room_at(stand + Vector3(0, 2, 0)) != null:
			player.teleport(stand)
			break
	_look_at(at)
	player.camera.pitch = -0.15
	await _wait(0.5)
	await _snap("debris")

	var pile: Node3D = door["debris_node"]
	var clear: Prompt = null
	for child in pile.get_children():
		if child is Prompt:
			clear = child
	_check(clear != null, "the heap can be cleared")
	if clear != null:
		await _hold_prompt(clear, house.lot.basis.z * 3.0, func() -> bool: return not door.get("debris", false))
	print("people: after E held at the heap: debris %s" % door.get("debris"))
	_check( not door.get("debris", false) and opening["passes"].call(), "E held clears it")


	fire.incident["events_forced"] = true
	house.set_read(room_name, "weak", true)
	player.teleport(_in_room(house, house.rooms[room_name]))
	player.health = player.max_health
	health = player.health
	await _wait(float(Config.Fire.Events.Floor.Stand) + 0.6)
	print("people: on the soft floor of the %s: %.0f -> %.0f, knocked %s" % [room_name, health, player.health, player.get_attr("Knocked")])
	_check(player.get_attr("Knocked") != true and player.health > 0.0, "the soft floor never gives way under someone who stays on it")
	await _snap("floor")


	fire.incident["rooms"][room_name]["scorch"] = 1.0
	fire.incident["rooms"][room_name]["shown_scorch"] = -1.0
	await _wait(1.0)
	var rooms: = 0
	for name_of: String in house.rooms:
		rooms += 0 if house.rooms[name_of].get("open", false) else 1
	print("people: the %s burnt black: lost %s, health %.1f (rooms %d: at most %.1f)" % [room_name, fire.incident["rooms"][room_name].get("lost"), fire.incident["health"], rooms, 100.0 * (rooms - 1) / rooms])
	_check(fire.incident["rooms"][room_name].get("lost", false) and house.rooms[room_name].get("lost", false), "a room burnt black is lost, shown on every device")
	_check(float(fire.incident["health"]) <= 100.0 * (rooms - 1) / rooms + 0.01, "the building's health counts the rooms lost")
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _done()
