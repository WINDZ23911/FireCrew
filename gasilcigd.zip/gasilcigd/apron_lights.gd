class_name ApronLights
extends Node3D





const FADE_FROM: = 210.0
const FADE_OVER: = 70.0



const FILL_COLOR: = Color(1.0, 0.82, 0.62)
const FILL_ENERGY: = 3.0
const FILL_GLOW: = 0.22

static var current: ApronLights

var lamps: Array[SpotLight3D] = []
var pool: Decal
var fill: SpotLight3D
var fill_glow: Decal
var _level: = -1
var _filled: = false


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var station: = Game.station
	if station == null:
		return
	var settings: Dictionary = Config.Art.Apron
	var bays: Array = station.record["bays"]
	var front: = float(station.front)
	var low: = INF
	var high: = - INF
	for bay: Dictionary in bays:
		low = minf(low, float(bay["x"]) - float(bay["width"]) / 2.0)
		high = maxf(high, float(bay["x"]) + float(bay["width"]) / 2.0)
	var color: Color = _color(settings["Color"])

	var count: = int(settings["Lamps"])
	for index in count:
		var x: = lerpf(low, high, (index + 0.5) / count)
		var lamp: = SpotLight3D.new()
		lamp.name = "ApronLamp%d" % (index + 1)
		lamp.spot_range = float(settings["Range"])
		lamp.spot_angle = float(settings["Angle"])
		lamp.spot_angle_attenuation = 0.8
		lamp.spot_attenuation = 0.7
		lamp.light_color = color
		lamp.light_energy = float(settings["Energy"])
		lamp.light_specular = 0.2
		lamp.shadow_enabled = false
		lamp.distance_fade_enabled = true
		lamp.distance_fade_begin = FADE_FROM
		lamp.distance_fade_length = FADE_OVER
		add_child(lamp)
		var at: = Vector3(x, float(settings["Height"]), front + float(settings["Out"]))
		var aim: = Vector3(x, 0.0, front + float(settings["Reach"]))
		lamp.global_transform = Transform3D(Basis.looking_at(aim - at, Vector3.UP), at)
		lamps.append(lamp)

	pool = Decal.new()
	pool.name = "ApronPool"
	var reach: = float(settings["Pool"])
	pool.size = Vector3(high - low + 8.0, 8.0, reach)
	pool.texture_emission = _soft_round()
	pool.texture_albedo = _soft_round()
	pool.albedo_mix = 0.0
	pool.emission_energy = float(settings["PoolEnergy"])
	pool.modulate = color
	pool.upper_fade = 0.3
	pool.lower_fade = 0.3
	pool.cull_mask = 1
	add_child(pool)
	pool.global_position = Vector3((low + high) / 2.0, 2.0, front + reach / 2.0 + 1.0)

	var middle: = (low + high) / 2.0
	fill = SpotLight3D.new()
	fill.name = "TitleFill"
	fill.spot_range = 70.0
	fill.spot_angle = 50.0
	fill.spot_angle_attenuation = 0.6
	fill.spot_attenuation = 0.4
	fill.light_color = FILL_COLOR
	fill.light_energy = FILL_ENERGY
	fill.light_specular = 0.0
	fill.shadow_enabled = false
	add_child(fill)
	var from: = Vector3(middle, 3.0, front + 34.0)
	fill.global_transform = Transform3D(Basis.looking_at(Vector3(middle, 10.0, front) - from, Vector3.UP), from)

	fill_glow = Decal.new()
	fill_glow.name = "TitleFillGlow"
	fill_glow.size = Vector3(high - low + 24.0, 10.0, 30.0)
	fill_glow.texture_emission = _soft_round()
	fill_glow.texture_albedo = _soft_round()
	fill_glow.albedo_mix = 0.0
	fill_glow.emission_energy = FILL_GLOW
	fill_glow.modulate = FILL_COLOR
	fill_glow.normal_fade = 0.5
	fill_glow.cull_mask = 1
	add_child(fill_glow)
	fill_glow.global_transform = Transform3D(Basis(Vector3.RIGHT, PI / 2.0), Vector3(middle, 11.0, front + 3.0))
	Game.night_changed.connect( func(_night: bool) -> void : _show())
	set_level(Settings.quality)



func set_level(level: int) -> void :
	_level = level
	_show()



func set_fill(on: bool) -> void :
	_filled = on
	_show()


func _show() -> void :
	var night: = Game.night
	for lamp in lamps:
		lamp.visible = night and _level >= Graphics.MEDIUM
	if pool:
		pool.visible = night and _level < Graphics.MEDIUM
	if fill:
		fill.visible = _filled and not night and _level >= Graphics.MEDIUM
		fill_glow.visible = _filled and not night and _level < Graphics.MEDIUM


static func _color(values: Array) -> Color:
	return Color(float(values[0]), float(values[1]), float(values[2]))



static func _soft_round() -> GradientTexture2D:
	var gradient: = Gradient.new()
	gradient.set_color(0, Color(1, 1, 1, 1))
	gradient.set_color(1, Color(0, 0, 0, 0))
	gradient.add_point(0.55, Color(0.55, 0.55, 0.55, 0.55))
	var texture: = GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = Vector2(0.5, 0.5)
	texture.fill_to = Vector2(1.0, 0.5)
	texture.width = 128
	texture.height = 128
	return texture
