class_name HudRadar
extends Control




const SIZE: = 210.0
const REACH: = 92.0
const INSIDE: = 95.0
const ROAD: = Color(98 / 255.0, 102 / 255.0, 112 / 255.0)
const ROAD_MAIN: = Color(132 / 255.0, 136 / 255.0, 146 / 255.0)
const ROAD_SHARE: = 0.6
const FUEL: = Color(235 / 255.0, 160 / 255.0, 50 / 255.0)

const KIND_ICONS: = {"tree": "saw", "rescue": "ladder", "crash": "car", "medical": "heart", "flood": "drop", "hazmat": "warning", "accident": "spreader", "alarm": "flame"}

static var current: HudRadar

static var route: = PackedVector3Array()
static var route_kind: = "call"
static var _roads: Array = []

static var buildings: Array = []
static var town: = Rect2(-920, -920, 2040, 2040)
static var _hydrants: = PackedVector3Array()
static var _hydrants_found: = false




static func set_route(points: PackedVector3Array, kind: = "call") -> void :
	route = points if points.size() >= 2 else PackedVector3Array()
	route_kind = kind


static func clear_route() -> void :
	route = PackedVector3Array()
	full_route = PackedVector3Array()
	full_length = -1.0



static var full_route: = PackedVector3Array()
static var full_length: = -1.0


static func set_full_route(points: PackedVector3Array, length: float) -> void :
	full_route = points if points.size() >= 2 else PackedVector3Array()
	full_length = length if points.size() >= 2 else -1.0


static func route_color() -> Color:
	return Ui.ROUTES.get(route_kind, Ui.FIRE)



static func roads() -> Array:
	if _roads.is_empty():
		var layout: Dictionary = Rbx.module("TownLayout")
		for road: Dictionary in layout["roads"]:
			var points: = PackedVector2Array()
			var bounds: = Rect2()
			for point: Array in road["points"]:
				var at: = Vector2(point[0], point[1])
				bounds = Rect2(at, Vector2.ZERO) if points.is_empty() else bounds.expand(at)
				points.append(at)
			if points.size() >= 2:
				var width: float = road.get("width", 24.0)
				_roads.append([points, width, bounds.grow(width), int(road.get("rank", 1)) >= 2])
		var edges: Dictionary = layout["bounds"]
		town = Rect2(edges["minX"], edges["minZ"], edges["maxX"] - edges["minX"], edges["maxZ"] - edges["minZ"])
		for building: Dictionary in layout["buildings"]:

			var yaw: = deg_to_rad(float(building.get("yaw", 0.0)))
			var across: = Vector2(cos(yaw), - sin(yaw)) * float(building["width"]) / 2
			var deep: = Vector2(sin(yaw), cos(yaw)) * float(building["depth"]) / 2
			var middle: = Vector2(building["x"], building["z"])
			buildings.append(PackedVector2Array([middle - across - deep, middle + across - deep, middle + across + deep, middle - across + deep]))
	return _roads



static func hydrants() -> PackedVector3Array:
	if not _hydrants_found and Game.store != null:
		_hydrants_found = true
		for entry: Dictionary in Game.records.get("hydrants", []):
			var id: Variant = entry.get("part")
			if id != null and Game.store.row_of.has(int(id)):
				_hydrants.append(Game.store.position(Game.store.row_of[int(id)]))
	return _hydrants




func _draw_hydrants(centre: Vector2, player: Player) -> void :
	var hoses: = HoseService.current
	var driving: bool = player.seat != null
	for hydrant in hydrants():
		var at: = _spot(hydrant)
		if at.length() > REACH:
			continue
		var kind: = hoses.hydrant_kind_at(hydrant) if hoses != null else ""
		draw_hydrant(self, centre + at, 15 if driving else 12, kind)





static func draw_hydrant(canvas: CanvasItem, at: Vector2, size: float, kind: String) -> void :
	var rings: = HoseService.hydrant_rings(kind) if kind != "" else 1
	if rings <= 0:
		canvas.draw_circle(at, size * 0.3, Color(0.06, 0.06, 0.07), true, -1.0, true)
		canvas.draw_arc(at, size * 0.3, 0.0, TAU, 16, Ui.DIM, 1.2, true)
		return
	canvas.draw_circle(at, size * 0.17, Ui.BLUE, true, -1.0, true)
	for ring in rings:
		canvas.draw_arc(at, size * (0.29 + 0.12 * ring), 0.0, TAU, 20, Ui.BLUE, 1.1, true)




static func fleet_number(vehicle: Node) -> String:
	var key: String = VehicleLook.FLEET_KEYS.get(vehicle.name, "")
	return str(Edition.fleet(key).get("number", "")) if not key.is_empty() else ""


static func draw_icon(canvas: CanvasItem, icon: String, at: Vector2, size: float, color: Color, turned: = 0.0) -> void :
	var index: = Ui.ICONS.find(icon)
	if index < 0:
		index = Ui.ICONS.find("dot")
	var region: = Rect2((index % Ui.ICON_COLUMNS) * Ui.ICON_CELL, (index / Ui.ICON_COLUMNS) * Ui.ICON_CELL, Ui.ICON_CELL, Ui.ICON_CELL)
	if turned != 0.0:
		canvas.draw_set_transform(at, turned)
		canvas.draw_texture_rect_region(Ui.image("icons"), Rect2( - size / 2, - size / 2, size, size), region, color)
		canvas.draw_set_transform(Vector2.ZERO)
	else:
		canvas.draw_texture_rect_region(Ui.image("icons"), Rect2(at.x - size / 2, at.y - size / 2, size, size), region, color)



static func clip(a: Vector2, b: Vector2, radius: float) -> Array:
	var along: = b - a
	var length_squared: = along.length_squared()
	if length_squared < 1e-06:
		return []

	var half: = a.dot(along)
	var inside: = half * half - length_squared * (a.length_squared() - radius * radius)
	if inside <= 0.0:
		return []
	var root: = sqrt(inside)
	var from: = maxf(0.0, ( - half - root) / length_squared)
	var to: = minf(1.0, ( - half + root) / length_squared)
	if from >= to:
		return []
	return [a + along * from, a + along * to]


var _look: = Vector3.FORWARD
var _right: = Vector3.RIGHT
var _origin: = Vector3.ZERO


func _ready() -> void :
	current = self
	position = Vector2(Ui.MARGIN, Ui.MARGIN)
	size = Vector2(SIZE, SIZE)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	roads()


func _process(_delta: float) -> void :
	queue_redraw()



func _spot(at: Vector3) -> Vector2:
	var offset: = at - _origin
	var scale_by: = REACH / float(Config.Hud.RadarRange)
	return Vector2(offset.dot(_right), - offset.dot(_look)) * scale_by



func _place(at: Vector3) -> Vector2:
	return _spot(at).limit_length(REACH)


func _draw() -> void :
	var player: = Game.local_player
	draw_texture_rect(Ui.image("radar"), Rect2(Vector2.ZERO, size), false)
	if player == null:
		return
	var view: = player.camera.forward() if player.camera else Vector3.FORWARD
	view.y = 0.0
	_look = view.normalized() if view.length() > 0.01 else Vector3.FORWARD
	_right = Vector3( - _look.z, 0, _look.x)
	_origin = player.global_position
	var centre: = size / 2
	var reach: float = Config.Hud.RadarRange
	var scale_by: = REACH / reach
	var here: = Vector2(_origin.x, _origin.z)


	for road: Array in roads():
		var bounds: Rect2 = road[2]
		if not bounds.grow(reach).has_point(here):
			continue
		var points: PackedVector2Array = road[0]
		var width: = maxf(2.0, road[1] * ROAD_SHARE * scale_by)
		var color: Color = ROAD_MAIN if road[3] else ROAD
		var last: = _spot(Vector3(points[0].x, _origin.y, points[0].y))
		for index in range(1, points.size()):
			var next: = _spot(Vector3(points[index].x, _origin.y, points[index].y))
			var piece: = clip(last, next, INSIDE - width / 2)
			if not piece.is_empty():
				draw_line(centre + piece[0], centre + piece[1], color, width, true)

				if piece[1].is_equal_approx(next):
					draw_circle(centre + next, width / 2, color, true, -1.0, true)
			last = next


	if route.size() >= 2:
		var color: = route_color()
		var last: = _spot(route[0])
		for index in range(1, route.size()):
			var next: = _spot(route[index])
			var piece: = clip(last, next, INSIDE - 2)
			if not piece.is_empty():
				draw_line(centre + piece[0], centre + piece[1], color, 3.5, true)
			last = next

	_draw_hydrants(centre, player)
	for vehicle in Vehicle.all:
		if is_instance_valid(vehicle):
			var spot: = centre + _place(vehicle.global_position)
			draw_icon(self, "truck", spot, 24, Ui.TEXT)
			var number: = fleet_number(vehicle)
			if not number.is_empty():
				draw_string_outline(Ui.display_font(), spot + Vector2(10, -6), number, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, 3, Color(0, 0, 0, 0.8))
				draw_string(Ui.display_font(), spot + Vector2(10, -6), number, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Ui.TEXT)
	for other in Game.players:
		if other != player and is_instance_valid(other):

			var down: bool = other.get_attr("Distress", false) == true
			var color: = Ui.RED if down else Ui.YELLOW
			if down and fmod(Game.now(), 0.6) < 0.3:
				color.a = 0.4
			draw_icon(self, "dot", centre + _place(other.global_position), 18 if down else 14, color)


	if Game.station:
		draw_icon(self, "house", centre + _place(Game.station.door_position), 22, Ui.YELLOW)


	if FuelService.current:
		var seated: Variant = player.get_attr("Vehicle")
		var low: bool = seated is Vehicle and seated.fuel_capacity > 0.0 and seated.fuel / seated.fuel_capacity < float(Config.Truck.Fuel.Low)
		for station: Dictionary in FuelService.current.stations:
			if low or _spot(station["position"]).length() <= REACH:
				draw_icon(self, "pump", centre + _place(station["position"]), 22, FUEL)


	if AmbulanceService.current:
		var box: Variant = AmbulanceService.current.zone_position()
		if box != null:
			draw_icon(self, "heart", centre + _place(box), 22, Ui.GREEN)

	var incident: = Game.incident
	if incident.has("pos"):
		var at: = centre + _place(incident["pos"])

		var beat: = fmod(Game.now(), 1.4) / 1.4
		draw_icon(self, "ring", at, 20 + 40 * beat, Color(Ui.RED, 1.0 - beat))
		draw_icon(self, KIND_ICONS.get(incident.get("kind", "fire"), "flame"), at, 28, Ui.RED)


	var to_north: = Vector3(0, 0, -1)
	var north: = centre + Vector2(to_north.dot(_right), - to_north.dot(_look)) * 104.0
	var letter: = Text.say(Text.m("hud.radar.north"))
	var font: = Ui.display_font()
	var letter_size: = font.get_string_size(letter, HORIZONTAL_ALIGNMENT_LEFT, -1, 16)
	draw_circle(north, 10, Ui.PANEL, true, -1.0, true)
	draw_string(font, north + Vector2( - letter_size.x / 2, 6), letter, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Ui.YELLOW)
	var facing: = player.facing()
	draw_icon(self, "arrow", centre, 26, Ui.YELLOW, atan2(facing.dot(_right), facing.dot(_look)))
