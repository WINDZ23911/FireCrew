extends ProofDebug










func _scenario_art_rescue() -> void :
	proof_name = "art_rescue"
	await _wait(1.0)

	var store: = Game.store
	var blue: = Rbx.rgb(Config.Art.HydrantCollar)
	var bands: = 0
	var blue_bands: = 0
	for entry: Dictionary in Game.records["hydrants"]:
		var row: int = store.row_of.get(int(entry["part"]), -1)
		if row < 0:
			continue
		for other in store.rows_under.get(store.parent(row), PackedInt32Array()):
			if store.name_at(other) == "Band":
				bands += 1
				if store.color(other).is_equal_approx(blue):
					blue_bands += 1
	_check(bands > 50 and blue_bands == bands, "every hydrant's band is blue (%d of %d)" % [blue_bands, bands])
	var first_row: int = store.row_of[int(Game.records["hydrants"][0]["part"])]
	var hydrant_at: = store.position(first_row)
	player.teleport(CallKit.ground_at(hydrant_at + Vector3(6, 3, 0)) + Vector3(0, 0.3, 0))
	_view(hydrant_at + Vector3(5, 3, 4), hydrant_at)
	await _wait(0.6)
	await _snap("hydrant")
	_view_player()


	var head: = player.rig.head as Node3D
	var front: = - player.rig.global_basis.z
	_view(head.global_position + front * 3.2 + Vector3(0, 0.3, 0), head.global_position, 40.0)
	await _wait(0.4)
	await _snap("face_firefighter")
	_view_player()


	var truck: = Vehicle.named("Fire Truck")
	var door_prompt: Prompt = null
	for prompt in Prompt.all:
		if prompt.is_inside_tree() and truck.is_ancestor_of(prompt) and prompt.action is Dictionary and String(prompt.action["k"]) == "gear.truck.doorOpen":
			door_prompt = prompt
			break
	if _check(door_prompt != null, "the truck has a door prompt"):
		var at: = door_prompt.global_position
		var side: = (at - truck.global_position) * Vector3(1, 0, 1)
		player.teleport(CallKit.ground_at(at + side.normalized() * 3.0 + Vector3(0, 3, 0)) + Vector3(0, 0.3, 0))
		_look_at(at)
		await _wait(0.6)
		var focus: = FocusRim.current
		print("focus: prompt %s, code %s, rimmed %d, ring %s" % [Text.say(player.prompt.action, "en") if player.prompt else "none", focus.code, focus.rimmed_count, focus._ring.visible])
		_check(player.prompt != null and focus.code == "use", "what you can use is lit in lime")
		_check(focus.rimmed_count > 0 or focus._ring.visible, "a rim or a ring is drawn on it")
		_view(at + side.normalized() * 7.0 + Vector3(0, 2, 2), at)
		await _wait(0.3)
		await _snap("focus_door")
		_view_player()


	var people: = VictimService.current
	var fire: = FireService.current
	var house: = _house("Family house")
	people.forced = 1
	Config.Fire["Embers"]["Chance"] = 0.0
	fire.run_incident(house)
	await _wait(1.5)
	if not _check( not people.victims.is_empty(), "somebody is inside"):
		_done()
		return
	var victim: Victim = people.victims[0]
	var rings: = CasualtyRings.current
	player.teleport(house.position + Vector3(0, 0, 60))
	await _wait(0.5)
	_check(rings.shown == 0, "no ring seen from outside the house, far off")
	player.teleport(victim.position() + Vector3(1.5, 0.2, 0))
	_look_at(victim.position())
	await _wait(0.6)
	_check(rings.shown == 1, "a green ring under the casualty seen near")
	_check(FocusRim.current.code == "rescue", "the rim on a casualty is rescue green (%s)" % FocusRim.current.code)
	_view(victim.position() + Vector3(4, 6, 3), victim.position())
	await _wait(0.3)
	await _snap("casualty")
	var face: MeshInstance3D = victim.figure.parts["Head"]
	_check(int(face.get_instance_shader_parameter("face_style")) & 32 == 32, "the casualty's eyes are shut")
	_view_player()
	_look_at(victim.position())
	await _hold("interact", float(Config.Victims.LiftTime) + 0.3)
	await _wait(0.5)
	_check(victim.carrier == player, "lifted")
	_check(rings.shown == 0, "no ring under one being carried")

	var ambulance: = AmbulanceService.current
	var waited: = 0.0
	while (ambulance._scene.is_empty() or not is_instance_valid(ambulance._scene.get("zone_model"))) and waited < 10.0:
		await _wait(0.5)
		waited += 0.5
	if _check( not ambulance._scene.is_empty(), "an ambulance is called"):
		var model: Node3D = ambulance._scene["zone_model"]
		var marker: = model.get_node("Marker") as Node3D
		await _wait(0.5)
		_check(marker.visible, "the handover's box and sign stand while you carry someone")
		var zone: Vector3 = model.global_position
		_view(zone + Vector3(12, 9, 12), zone)
		await _wait(0.3)
		await _snap("handover_carrying")
		people.put_down(victim)
		await _wait(0.6)
		_check( not marker.visible, "and only the flat marking otherwise")
		_check((model.get_meta("pad") as MeshInstance3D).visible, "the marking is on the road")
		await _snap("handover_marking")
	_done()



func _burning(prefix: = "Family house") -> House:
	var fire: = FireService.current
	var house: = _house(prefix)
	VictimService.current.forced = 0
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	fire.run_incident(house)
	await _wait(0.5)
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	return house



func _room_with_panes(house: House) -> Array:
	var best: Array = []
	for room_name: String in house.rooms:
		var room: Dictionary = house.rooms[room_name]
		if int(room["floor"]) != 0 or (room["panes"] as Array).is_empty():
			continue
		var nodes: Array = []
		for node: Dictionary in FireService.current.incident["group"]["nodes"]:
			if node["room"] == room_name and not String(node["name"]).ends_with("door"):
				nodes.append(node)
		if nodes.size() >= 2 and (best.is_empty() or (room["panes"] as Array).size() > (best[0]["panes"] as Array).size()):
			best = [room, nodes]
	return best



func _card_at(look: WindowFire, pane: Dictionary) -> MeshInstance3D:
	for child in look.get_children():
		if child is MeshInstance3D and (child as MeshInstance3D).visible and (child as MeshInstance3D).mesh == ToonFire.card():
			if (child as MeshInstance3D).global_position.distance_to(pane["position"]) < 4.0:
				return child
	return null


func _scenario_art_windows() -> void :
	proof_name = "art_windows"
	await _wait(1.0)
	var house: = await _burning()
	var fire: = FireService.current
	var found: = _room_with_panes(house)
	if not _check( not found.is_empty(), "a ground-floor room with panes and things to burn"):
		_done()
		return
	var room: Dictionary = found[0]
	var break_heat: Variant = Config.Fire["BreakHeat"]
	Config.Fire["BreakHeat"] = 1000000000.0
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"] and not found[1].has(node):
			fire._douse(node)
	for node: Dictionary in found[1]:
		if not node["burning"]:
			fire._ignite(node, 1.0)
		node["intensity"] = 1.0
		fire._show(node)
	var pane: Dictionary = room["panes"][0]
	for other: Dictionary in room["panes"]:
		house._restore_pane(other)
	var f: = WindowFire.frame(house, room, pane)
	var out: Vector3 = f[1]
	var eye: Vector3 = (pane["position"] as Vector3) + out * 22.0 + Vector3(0, 4, 0)
	_view(eye, pane["position"])
	await _wait(1.0)
	var look: = WindowFire.current
	_check(look != null, "the window fire looks at the houses")
	print("window fire: ", look.shown)
	_check(int(look.shown["glows"]) > 0, "the glass of the burning room glows (%d)" % int(look.shown["glows"]))
	_check( not (look.shown["flame_panes"] as Array).has(int(pane["id"])), "no flame out of the whole pane")
	_check((look.shown["glow_panes"] as Array).has(int(pane["id"])), "the whole pane glows")
	await _snap("glass")
	Config.Fire["BreakHeat"] = break_heat
	house._shatter(pane, out)
	await _wait(1.0)
	print("window fire: ", look.shown)
	_check((look.shown["flame_panes"] as Array).has(int(pane["id"])), "a flame licks out of the broken pane")
	var card: = _card_at(look, pane)
	if _check(card != null, "the flame card is drawn"):
		var off: Vector3 = card.global_position - (pane["position"] as Vector3)
		_check(off.dot(out) > 0.2, "its foot is outside the wall (%.2f out)" % off.dot(out))
		_check(off.y < 0.0, "its foot is at the sill, below the pane's middle (%.2f)" % off.y)
	house.show_scorch(room["name"], 0.8)
	await _wait(0.8)
	print("window fire: ", look.shown)
	_check(int(look.shown["soots"]) > 0, "soot on the wall over the broken pane")
	await _snap("flames")
	_view(eye + Vector3(0, 0, 0) - out * 4.0 + out.cross(Vector3.UP) * 12.0, pane["position"])
	await _wait(0.5)
	await _snap("flames_side")
	Sky3D.current.set_hour(22.0)
	_view(eye, pane["position"])
	await _wait(1.0)
	await _snap("night")
	Sky3D.current.set_hour(14.0)

	for node: Dictionary in fire.incident["group"]["nodes"]:
		if node["burning"]:
			fire._douse(node)
	await _wait(1.0)
	_check(int(look.shown["flames"]) == 0 and int(look.shown["glows"]) == 0, "no flames or glow once the fire is out")
	_check(int(look.shown["soots"]) > 0, "the soot stays after the fire")
	await _snap("out")
	house.restore()
	await _wait(0.8)
	_check(int(look.shown["soots"]) == 0, "the soot goes when the house is put right")
	_done()


func _scenario_art_smoke() -> void :
	proof_name = "art_smoke"
	await _wait(1.0)
	Settings.quality = Graphics.HIGH
	Graphics.apply(Graphics.HIGH)
	_check(ToonFire.puff_mesh().radial_segments == 16 and ToonFire.puff_mesh().rings == 8, "puffs 16 x 8 on HIGH")
	var house: = await _burning()
	var fire: = FireService.current
	var lit: = 0
	for node: Dictionary in fire.incident["group"]["nodes"]:
		if lit < 10 and not node["burning"]:
			fire._ignite(node, 1.0)
			lit += 1
	await _wait(6.0)
	var flame: Flame = Flame.all[0]
	_check(flame.fuel == "building" and flame._smoke_from.is_equal_approx(ToonFire.fuel_color("building")), "a house's smoke is the building's brown-grey")
	_check(ToonFire.fuel_color("building").r > ToonFire.fuel_color("building").b + 0.03, "brown-grey: warmer than grey")
	var away: = (house.position - Vector3(0, 0, 0)).normalized()
	var day_eye: = house.position + Vector3(0, 0, 0) + Vector3(90, 40, 90)
	_view(day_eye, house.position + Vector3(0, 25, 0))
	await _wait(1.0)
	await _snap("day")
	Sky3D.current.set_hour(22.0)
	await _wait(1.5)
	var far_eye: = house.position + Vector3(200, 60, 200)
	_view(far_eye, house.position + Vector3(0, 30, 0), 50.0)
	await _wait(1.5)
	var plume: = FirePlume.current
	_check(plume != null and plume._sky.visible, "a glow over the roofs at night from afar on HIGH")
	await _snap("night_far_high")
	Settings.quality = Graphics.LOW
	Graphics.apply(Graphics.LOW)
	await _wait(1.0)
	_check(ToonFire.puff_mesh().radial_segments == 10 and ToonFire.puff_mesh().rings == 5, "puffs 10 x 5 on LOW")
	_check( not plume._sky.visible, "no sky glow on LOW")
	await _snap("night_far_low")
	Settings.quality = Graphics.HIGH
	Graphics.apply(Graphics.HIGH)
	Sky3D.current.set_hour(14.0)
	var _unused: = away
	_done()




func _scenario_art_indoor() -> void :
	proof_name = "art_indoor"
	await _wait(1.0)
	var grade: = InteriorGrade.current
	_view(Vector3(-21, 9, -68), Vector3(-21, 10, -99))
	await _wait(1.5)
	var held: = Sky3D.current.world_environment
	_check(grade.inside > 0.99, "the camera in the garage is inside (%.2f)" % grade.inside)
	_check(held.camera_attributes != null and (held.camera_attributes as CameraAttributesPractical).exposure_multiplier < 0.9, "darker inside")
	_check(held.environment.adjustment_color_correction != null, "warmer inside")
	await _snap("garage")
	_view(Vector3(-21, 9, -20), Vector3(-21, 6, -50))
	await _wait(0.5)
	var ramp_end: Color = (held.environment.adjustment_color_correction as GradientTexture1D).gradient.get_color(1) if held.environment.adjustment_color_correction != null else Color.WHITE
	_check(grade.inside > 0.05 and grade.inside < 0.95 and ramp_end.b < 0.995 and ramp_end.b > float(Config.Art.Interior.Warm[2]) + 0.005, "stepping out, the warmth fades rather than switches (%.2f in, blue %.3f)" % [grade.inside, ramp_end.b])
	await _wait(1.5)
	_check(grade.inside == 0.0 and held.camera_attributes == null and held.environment.adjustment_color_correction == null, "the ordinary grade on the apron")
	var posters: = Game.world.get_node_or_null("StationPosters")
	_check(posters != null and posters._labels.size() == 8, "four posters on the station's walls")
	if posters != null:
		var was: = Text.language


		var shown: = func() -> Array:
			var words: Array = []
			for entry: Array in posters._labels:
				words.append((entry[0] as Label3D).text)
			return words
		Text.choose("en")
		await _wait(0.2)
		var contest: = Text.m("world.posters.contest")
		_check(shown.call().has(Text.say(contest, "en")), "the posters in English (%s)" % ", ".join(shown.call()))
		Text.choose("sl")
		await _wait(0.2)
		_check(shown.call().has(Text.say(contest, "sl")) and Text.say(contest, "sl") != Text.say(contest, "en"), "and in Slovenian")
		Text.choose(was)
	_done()
