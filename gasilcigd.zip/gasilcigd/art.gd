extends ProofDebug














func _scenario_art_tree() -> void :
	await _wait(1.0)
	var tree: = _crown_near(Vector3(-20, 0, 40))
	_check(tree.size() > 0, "a broad-leaved crown found near the station")
	if tree.is_empty():
		_done()
		return
	var crown: Vector3 = tree["at"]
	var radius: float = tree["radius"]
	print("art: crown at %s, %.1f studs across" % [crown, radius * 2.0])

	var out: = Vector3(1, 0, 0.35).normalized()
	var stand: = Vector3(crown.x, 0, crown.z) + out * (radius + 3.0)
	player.teleport(Vector3(stand.x, crown.y - radius - 3.0, stand.z))
	await _wait(0.6)
	var ground: = _ground_under(stand)
	player.teleport(Vector3(stand.x, ground + 3.0, stand.z))
	var to_tree: = Vector3(crown.x, 0, crown.z) - Vector3(stand.x, 0, stand.z)
	player.camera.yaw = atan2(to_tree.x, to_tree.z)
	player.camera.pitch = -0.3
	player.camera.wanted_distance = 16.0
	await _wait(1.2)
	await _snap("behind")
	var fade: = FoliageFade.amount
	var focus: = FoliageFade.point
	print("art: fade %s, focus %s, player %s" % [fade, focus, player.global_position])
	_check(fade > 0.5, "leaves between the camera and the player are faded")
	_check(focus.distance_to(player.global_position) < 6.0, "the fade is round the player")


	_view(crown + out * 22.0 + Vector3(0, 2, 0), crown, 60.0)
	await _wait(0.6)
	await _snap("near20")
	_view(crown + out * 60.0 + Vector3(0, 6, 0), crown, 55.0)
	await _wait(0.6)
	await _snap("near40")
	_check(FoliageFade.amount < 0.01, "no fade while another camera is drawn")
	_view(crown + out * 140.0 + Vector3(0, 14, 0), crown, 40.0)
	await _wait(0.6)
	await _snap("far")
	_done()




func _crown_near(near: Vector3) -> Dictionary:
	var store: = Game.store
	var best: = {}
	var best_distance: = INF
	for row in store.count:
		if store.name_at(row) != "Leaves":
			continue
		var size: = store.size(row)
		if minf(size.x, size.z) < 8.0 or maxf(size.x, size.z) > 13.0:
			continue
		var at: = store.position(row)
		if at.y < 9.0:
			continue
		var away: = Vector2(at.x - near.x, at.z - near.z).length()
		if away < best_distance:
			best_distance = away
			best = {"at": at, "radius": maxf(size.x, size.z) / 2.0}
	return best


func _ground_under(at: Vector3) -> float:
	var query: = PhysicsRayQueryParameters3D.create(at + Vector3(0, 80, 0), at + Vector3(0, -80, 0), World.LAYER_SOLID)
	var hit: = player.get_world_3d().direct_space_state.intersect_ray(query)
	return (hit["position"] as Vector3).y if not hit.is_empty() else 0.0






func _scenario_art_start() -> void :
	await _wait(0.5)
	var sky: = Sky3D.current
	var start: = Sky3D.start_hour()
	print("art: started at %.2f, the style's start %.2f, Config.Day.Start %s" % [sky.hour, start, Config.Day.Start])
	_check( not sky.hour_given and absf(sky.hour - start) < 0.1, "a new game starts at the style's golden hour")
	_check( not Style.winter() and is_equal_approx(start, float(Config.Day.Start)), "in summer that is Config.Day.Start")
	sky.running = true
	var before: = sky.hour
	await _wait(3.0)
	var pace: = 24.0 / (float(Config.Day.Length) * 60.0) * float(Config.Art.GoldenPace)
	var went: = sky.hour - before
	print("art: golden hour went %.4f h in 3 s (%.4f expected)" % [went, pace * 3.0])
	_check(absf(went - pace * 3.0) < pace * 1.0, "golden hour goes at Config.Art.GoldenPace")
	_view(Vector3(-20, 12, 10), Vector3(-20, 2, -60), 70.0)
	await _wait(0.5)
	await _snap("station")
	_done()





func _scenario_art_apron() -> void :
	await _wait(0.5)
	Sky3D.current.running = false
	Sky3D.current.set_hour(22.0)
	await _wait(1.5)
	var apron: = ApronLights.current
	_check(apron != null and apron.lamps.size() == int(Config.Art.Apron.Lamps), "the apron has its lamps")
	var lit: = 0
	for lamp in apron.lamps:
		lit += 1 if lamp.visible else 0
	var low: = Settings.quality <= Graphics.LOW
	print("art: graphics %d, %d lamps lit, pool %s" % [Settings.quality, lit, apron.pool.visible])
	if low:
		_check(lit == 0 and apron.pool.visible, "on LOW graphics the apron gets the pool, not the lamps")
	else:
		_check(lit == apron.lamps.size() and not apron.pool.visible, "on MEDIUM and HIGH graphics the lamps light the apron")
	_view(Vector3(-20, 12, 10), Vector3(-20, 2, -60), 70.0)
	await _wait(0.5)
	await _snap("night")
	Sky3D.current.set_hour(13.0)
	await _wait(1.5)
	lit = 0
	for lamp in apron.lamps:
		lit += 1 if lamp.visible else 0
	_check(lit == 0 and not apron.pool.visible, "by day the apron's lights are off")
	_done()





func _scenario_art_light() -> void :
	await _wait(0.5)
	var sky: = Sky3D.current
	sky.running = false
	var truck: = Vehicle.named("Fire Truck")
	truck.global_transform = Transform3D(Basis(Vector3.UP, PI), Vector3(-12.0, 3.0, -30.0))
	truck.linear_velocity = Vector3.ZERO
	truck.headlights_on = true
	sky.set_hour(16.5)
	await _wait(1.0)
	var beam: SpotLight3D = truck._headlamps[0]["beam"]
	print("art: at 16:30 the beam is %s, energy %.1f" % [beam.visible, beam.light_energy])
	_check( not beam.visible or beam.light_energy < 1.0, "no headlight pools in the sun")
	_view(Vector3(-24, 9, 10), Vector3(-12, 1, -22), 60.0)
	await _wait(0.3)
	await _snap("day_headlights")

	var art: Dictionary = Config.Art
	var by_day: float = art["HeadlightsByDay"]
	art["HeadlightsByDay"] = 1.0
	await _wait(0.5)
	await _snap("day_headlights_before")
	art["HeadlightsByDay"] = by_day
	sky.set_hour(22.0)
	await _wait(1.0)
	print("art: at 22:00 the beam is %s, energy %.1f" % [beam.visible, beam.light_energy])
	_check(beam.visible and beam.light_energy > 10.0, "headlights light the road at night")

	player.teleport(Vector3(-12.0, 3.0, -16.0))
	player.rig.rotation.y = 0.0
	await _wait(1.0)
	var banded: = FirefighterRig._banded
	var glow: = banded[0].emission_energy_multiplier if not banded.is_empty() else 0.0
	print("art: %d banded materials, glowing %.1f at night" % [banded.size(), glow])
	_check( not banded.is_empty() and glow > float(Config.Art.Bands.Day) + 1.0, "the suits' reflective bands shine at night")
	_view(Vector3(-12, 6, -2), Vector3(-12, 3, -16), 50.0)
	await _wait(0.3)
	await _snap("night_bands")
	var bands: Dictionary = Config.Art.Bands
	var night_glow: float = bands["Night"]
	bands["Night"] = bands["Day"]
	FirefighterRig.night_bands(1.0)
	await _wait(0.3)
	await _snap("night_bands_before")
	bands["Night"] = night_glow
	FirefighterRig.night_bands(1.0)
	sky.set_hour(13.0)
	await _wait(1.0)
	_check(is_equal_approx(banded[0].emission_energy_multiplier, float(Config.Art.Bands.Day)), "by day the bands are as they were")
	_done()






func _scenario_art_beam() -> void :
	await _wait(1.0)
	var tree: = _crown_near(Vector3(-20, 0, 40))
	_check(tree.size() > 0, "a broad-leaved crown found near the station")
	if tree.is_empty():
		_done()
		return
	var crown: Vector3 = tree["at"]
	var radius: float = tree["radius"]
	var out: = Vector3(1, 0, 0.35).normalized()
	var stand: = Vector3(crown.x, 0, crown.z) + out * (radius + 26.0)
	var ground: = _ground_under(stand)
	var truck: = Vehicle.named("Fire Truck")

	truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(out.x, out.z)), Vector3(stand.x, ground + 4.0, stand.z))
	truck.linear_velocity = Vector3.ZERO
	truck.headlights_on = true
	Sky3D.current.running = false
	Sky3D.current.set_hour(22.0)
	await _wait(2.0)
	var beam: SpotLight3D = truck._headlamps[0]["beam"]
	print("art: beam shadow %s, bias %.3f, normal bias %.2f" % [beam.shadow_enabled, beam.shadow_bias, beam.shadow_normal_bias])
	_check(beam.visible and beam.shadow_enabled, "the lamp that throws the shadow is on")
	_check(beam.shadow_bias >= 0.1, "its shadow biased past the acne")
	var side: = out.cross(Vector3.UP).normalized()
	_view(Vector3(stand.x, ground, stand.z) + side * 14.0 + out * 6.0 + Vector3(0, 12, 0), crown, 60.0)
	await _wait(0.5)
	await _snap("crown")
	_view(Vector3(stand.x, ground, stand.z) - side * 12.0 - out * 8.0 + Vector3(0, 8, 0), crown - Vector3(0, radius * 0.3, 0), 60.0)
	await _wait(0.5)
	await _snap("crown_near")
	_done()






func _scenario_art_title() -> void :
	await _wait(1.5)
	var title: TitleScreen = null
	for node: Node in get_tree().root.find_children("*", "CanvasLayer", true, false):
		if node is TitleScreen:
			title = node
	if title == null:

		title = TitleScreen.new()
		get_tree().current_scene.add_child(title)
		await _wait(1.0)
	var sky: = Sky3D.current
	print("art: title at %.2f, clock running %s; lockup '%s' '%s'" % [sky.hour, sky.running, title._title.text, title._town.text])
	_check( not sky.running and absf(sky.hour - Sky3D.start_hour()) < 0.05, "the title holds the town at golden hour")
	_check(title._town.text == Text.say(Text.m("world.title.lockupTown")) and not title._town.text.is_empty() and not title._title.text.is_empty(), "the splash's lockup is on the title")
	await _snap("summer")

	Style.choose(Style.WINTER)
	title._hold_clock()
	title._say()
	await _wait(5.0)
	print("art: winter title at %.2f" % sky.hour)
	_check(Style.winter() and absf(sky.hour - float(Config.Art.WinterStart)) < 0.05, "the winter button turns the town to a winter's golden hour")
	await _snap("winter")
	Style.choose(Style.SUMMER)
	title._hold_clock()
	await _wait(0.5)
	_check(absf(sky.hour - float(Config.Day.Start)) < 0.05, "and back to a summer evening")


	PlayerData.first_shift_done = true
	sky.hour_given = false
	var hours: = {}
	for session in 40:
		hours[Sky3D.session_hour(session * 7919)] = true
	var span: Vector2 = Sky3D.SESSION_HOURS["summer"]
	var inside: = hours.keys().all( func(h: float) -> bool: return h >= span.x and h <= span.y)
	print("art: 40 sessions start at %d different hours, %s" % [hours.size(), ", ".join(hours.keys().slice(0, 8).map( func(h: float) -> String: return "%.2f" % h))])
	_check(hours.size() >= 12 and inside, "later sessions start at hours of their own, mid-morning to evening")
	title._start()
	await _wait(0.5)
	print("art: the session starts at %.2f" % sky.hour)
	_check(sky.running, "the clock goes on once the game starts")
	_check(sky.hour >= span.x - 0.01 and sky.hour <= span.y + 0.1 and absf(sky.hour - Sky3D.start_hour()) > 0.01, "a later session does not start at golden hour")
	await _wait(2.0)
	await _snap("session_start")
	_done()







func _scenario_art_crew() -> void :
	await _wait(3.0)
	var crew: Array = CrewService.current.members if CrewService.current else []
	_check(crew.size() >= 2, "there is a crew to look at")
	if crew.size() < 2:
		_done()
		return

	var looked: Array = []
	for index in crew.size():
		var man: Crewman = crew[index]
		looked.append([man.display_name(), snappedf(man.body.rig.scale.y, 0.01), man.body.rig.face[0].material_override.get_shader_parameter("style")])
		_check(man.body.rig.face[0].material_override != crew[0].body.rig.face[0].material_override or index == 0, "%s has a face of their own" % man.display_name())
	print("art: crew %s" % str(looked))
	for index in mini(crew.size(), 3):
		var rig: FirefighterRig = (crew[index] as Crewman).body.rig
		var front: = - rig.global_basis.z
		var chest: = rig.global_position + Vector3(0, 4.0, 0)
		_view(chest + front * 9.0 + Vector3(0, 0.6, 0), chest, 40.0)
		await _wait(0.3)
		await _snap("front%d" % index)
	var rig: FirefighterRig = (crew[0] as Crewman).body.rig
	var left: = - rig.global_basis.x
	_view(rig.global_position + Vector3(0, 4.0, 0) + left * 6.0, rig.global_position + Vector3(0, 3.8, 0), 40.0)
	await _wait(0.3)
	await _snap("arm")
	_done()







func _scenario_art_crash() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 0.0)
	if not _check( not held.is_empty(), "a crash came"):
		await _done()
		return
	await _wait(1.0)
	var door: Dictionary = held["doors"][0]
	var where: Vector3 = door["position"]
	var out: Vector3 = door["car"]["place"].basis.x * door["outward"]
	player.teleport(CallKit.ground_at(where + out * 10.0) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	print("art: %d casualty rings shown" % CasualtyRings.current.shown)
	_check(CasualtyRings.current.shown > 0, "a trapped casualty has a ring")
	_view(where + out * 12.0 + out.cross(Vector3.UP) * 6.0 + Vector3(0, 7, 0), where)
	await _wait(0.3)
	await _snap("trapped")
	var officer: = PoliceOfficer.new(2)
	get_tree().current_scene.add_child(officer)
	officer.global_position = CallKit.ground_at(where + out * 7.0 - out.cross(Vector3.UP) * 8.0)
	officer.look_at(officer.global_position + out, Vector3.UP)
	await _wait(0.5)
	_view(officer.global_position + out * 6.0 + out.cross(Vector3.UP) * 4.0 + Vector3(0, 4.5, 0), officer.global_position + Vector3(0, 3.6, 0), 40.0)
	await _wait(0.3)
	await _snap("police")
	officer.queue_free()
	await _done()







func _scenario_art_address() -> void :
	await _wait(1.0)
	var fire: = FireService.current

	var house: House = null
	var plate_rows: = Game.store.rows_named("HouseNumber")
	for candidate: House in House.all:
		for row in plate_rows:
			var spot: = Game.store.position(row)
			if Vector2(spot.x - candidate.position.x, spot.z - candidate.position.z).length() < 30.0 and house == null:
				house = candidate
	if house != null:
		VictimService.current.forced = 0
		Config.Fire["Embers"]["Chance"] = 0.0
		CallService.current.run_call("fire", func() -> bool:
			await fire.run_incident(house)
			return true)
		for wait in 40:
			if not fire.incident.is_empty():
				break
			await _wait(0.25)
	if not _check(house != null, "a house fire came"):
		await _done()
		return
	await _wait(1.5)
	var focus: Vector4 = CallAddress.current.focus
	var plates: Array = Array(Game.store.rows_named("HouseNumber")).map( func(row: int) -> float: return Vector2(Game.store.position(row).x - house.position.x, Game.store.position(row).z - house.position.z).length())
	plates.sort()
	print("art: %s at %s; call focus %s, number lit %d; nearest plates %s" % [house.name, house.position, focus, CallAddress.current._lit, str(plates.slice(0, 3))])
	_check(focus.w > 0.0, "the crowns by the burning house are thinned on this Graphics level")
	_check(CallAddress.current._lit >= 0, "the burning house's number is lit")

	var plate: = -1
	var nearest: = INF
	for row in plate_rows:
		var spot: = Game.store.position(row)
		var away: = Vector2(spot.x - house.position.x, spot.z - house.position.z).length()
		if away < nearest:
			nearest = away
			plate = row
	var at: = Game.store.position(plate)
	var out: = - Game.store.basis(plate).z.normalized()
	_view(at + out * 60.0 + Vector3(0, 6, 0), at, 50.0)
	await _wait(0.5)
	await _snap("street")
	_view(at + out * 9.0 + Vector3(0, -1, 0), at, 50.0)
	await _wait(0.5)
	await _snap("door")
	await _done()



func _scenario_art_beamtrees() -> void :
	await _wait(0.5)
	var sky: = Sky3D.current
	sky.running = false
	sky.set_hour(22.5)

	var best: Dictionary = {}
	for tree: Dictionary in TreeKit.trees:
		var foot: Vector3 = tree["foot"]
		if Vector2(foot.x, foot.z).length() < 700.0 and tree.get("species", "") in ["lime", "walnut", "fruit"]:
			best = tree
			break
	if not _check( not best.is_empty(), "a tree to light"):
		await _done()
		return
	var foot: Vector3 = best["foot"]
	var truck: = Vehicle.named("Fire Truck")
	var from: = foot + Vector3(0, 3, 26)
	var way: = Vector3(foot.x - from.x, 0, foot.z - from.z).normalized()
	truck.global_transform = Transform3D(Basis.looking_at(way, Vector3.UP), from)
	truck.linear_velocity = Vector3.ZERO
	truck.headlights_on = true
	await _wait(1.5)
	print("art: beam trees: %s %s at %s" % [best.get("species"), best.get("model"), foot])
	_view(from - way * 34.0 + Vector3(0, 9, 0), foot + Vector3(0, 8, 0), 60.0)
	await _wait(0.4)
	await _snap("behind")
	_view(from + way * 14.0 + Vector3(12, 4, 0), foot + Vector3(0, 9, 0), 60.0)
	await _wait(0.4)
	await _snap("side")
	truck.headlights_on = false
	await _wait(0.6)
	_view(from - way * 34.0 + Vector3(0, 9, 0), foot + Vector3(0, 8, 0), 60.0)
	await _wait(0.4)
	await _snap("unlit")
	await _done()
