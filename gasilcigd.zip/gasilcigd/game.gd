extends Node



signal notified(text: Variant, kind: String, player: Player)
signal incident_changed

signal incident_ending(last: Dictionary)
signal call_started(kind: String)

signal water_landed(hit: Dictionary, dt: float, direction: Vector3, player: Player)
signal night_changed(night: bool)

signal paused_changed(paused: bool)

var world: World
var store: PartStore
var players: Array[Player] = []
var local_player: Player
var night: = false
var ui_open: = false
var spawns: Array[Vector3] = []
var records: Dictionary = {}
var station: Station



var incident: Dictionary = {}

var _last_told: Dictionary = {}
const TELL_EVERY: = 5.0
var _paused_ms: = 0
var _paused_since: = -1





func now() -> float:
	var ticks: = Time.get_ticks_msec() if _paused_since < 0 else _paused_since
	return (ticks - _paused_ms) / 1000.0



func is_paused() -> bool:
	return _paused_since >= 0





func set_paused(on: bool) -> void :
	on = on and not Net.active()
	if on == is_paused():
		return
	var ticks: = Time.get_ticks_msec()
	if on:
		_paused_since = ticks
	else:
		_paused_ms += ticks - _paused_since
		_paused_since = -1
	get_tree().paused = on
	paused_changed.emit(on)



func notify(text: Variant, kind: = "", player: Player = null) -> void :
	notified.emit(text, kind, player)



func tell(player: Player, text: Variant, kind: = "warning") -> void :
	var key: = [player, Text.say(text, "sl")]
	if now() - _last_told.get(key, -100.0) > TELL_EVERY:
		_last_told[key] = now()
		notify(text, kind, player)


func set_incident(values: Dictionary) -> void :
	if values.is_empty() and not incident.is_empty():
		incident_ending.emit(incident)
	incident = values
	incident_changed.emit()


func set_night(value: bool) -> void :
	if night != value:
		night = value
		night_changed.emit(value)




func humans() -> int:
	var count: = 0
	for player in players:
		if is_instance_valid(player) and player.brain == null:
			count += 1
	return count



func nearest_player(position: Vector3) -> Array:
	var best: Player = null
	var best_distance: = INF
	for player in players:
		var distance: = player.global_position.distance_to(position)
		if distance < best_distance:
			best = player
			best_distance = distance
	return [best, best_distance]


func spawn_point() -> Vector3:
	if spawns.is_empty():
		return Vector3(20, 1, -30)
	return spawns[randi() % spawns.size()] + Vector3(0, 0.5, 0)




func quit() -> void :
	await Telemetry.end()
	Net.leave()
	await Net.finish_router()
	var tree: = get_tree()
	if tree.current_scene:
		tree.current_scene.queue_free()
	await tree.process_frame
	await tree.process_frame
	tree.quit()


func _ready() -> void :
	get_tree().auto_accept_quit = false


func _notification(what: int) -> void :
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		quit()
