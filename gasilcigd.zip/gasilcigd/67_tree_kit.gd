extends RefCounted













const GARDEN: = 70.0
const RAIL: = 70.0
const MAIN: = ["primary", "secondary"]
const CROWNS: = ["Leaves", "Needles"]
const BIRCH_BARK: = Color8(226, 222, 212)
const MARK: = Color8(40, 38, 36)


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	TreeKit.trees.clear()
	var trees: Array = []
	for model in kit.models_under("Map/Trees"):
		trees.append(_model_tree(store, model))
	for model in store.nodes_under.get(kit.folder("Map/Polish/Wild"), PackedInt32Array()):
		if store.nodes[model]["n"] == "WildTree":
			trees.append(_model_tree(store, model))
	trees.append_array(_loose_trees(kit, "Map/Parks"))
	var main_roads: Array = []
	var apartments: Array = []
	for road: Dictionary in kit.layout()["roads"]:
		if road["class"] in MAIN:
			main_roads.append(road)
	for building: Dictionary in kit.layout()["buildings"]:
		if building["kind"] == "apartments":
			apartments.append(Vector2(float(building["x"]), float(building["z"])))
	var counts: = {}
	for tree: Array in trees:
		var trunk: int = tree[0]
		var crowns: Array = tree[1]
		if trunk < 0 or crowns.is_empty():
			continue
		var foot: = store.position(trunk)
		var trunk_size: = store.size(trunk)
		foot.y -= trunk_size.x / 2.0
		var low: = Vector3(INF, INF, INF)
		var high: = - low
		var conifer: = false
		var tint: = Color(0, 0, 0)
		for row: int in crowns:
			var at: = store.position(row)
			var half: = store.size(row) / 2.0
			if store.shape(row) == PartStore.Shape.CYLINDER:
				half = Vector3(half.y, half.x, half.z)
			elif store.shape(row) == PartStore.Shape.BALL:
				half = Vector3.ONE * minf(half.x, minf(half.y, half.z))
			low = low.min(at - half)
			high = high.max(at + half)
			conifer = conifer or store.name_at(row) == "Needles"
			tint += store.color(row)
		tint /= crowns.size()
		var spot: = Vector2(foot.x, foot.z)
		var species: = _species(kit, spot, conifer, tree[2], main_roads, apartments)
		counts[species] = counts.get(species, 0) + 1
		for row: int in crowns:
			store.set_transparency(row, 1.0)
		if species == "birch":
			store.set_color(trunk, BIRCH_BARK)
			_marks(kit, trunk, tree[2], foot, trunk_size)
		TreeKit.trees.append({
			"model": tree[2], "foot": foot, "top": foot.y + trunk_size.x, "low": low, "high": high, 
			"species": species, "tint": tint, "turn": float(rand_from_seed(hash([int(foot.x), int(foot.z)]))[0] %360), 
		})
	var said: Array[String] = []
	for species: String in TreeKit.SPECIES:
		said.append("%d %s" % [counts.get(species, 0), species])
	return "tree kit: " + ", ".join(said)




static func _marks(kit: PolishKit, trunk: int, model: int, foot: Vector3, size: Vector3) -> void :
	var parent: = model if model > 0 else kit.own_folder("TreeKit")
	var radius: = size.y / 2.0
	var rng: = kit.rng("birch:%d" % trunk)
	var height: = 1.2
	while height < size.x - 0.8:
		var turn: = Basis(Vector3.UP, rng.randf_range(0.0, TAU))
		var at: = Transform3D(turn, foot + Vector3(0, height, 0)).translated_local(Vector3(0, 0, - radius * 0.82))
		kit.box(parent, at, Vector3(radius * rng.randf_range(0.9, 1.4), rng.randf_range(0.18, 0.32), 0.25), MARK, "SmoothPlastic", "BirchMark")
		height += rng.randf_range(1.1, 2.2)


static func _model_tree(store: PartStore, model: int) -> Array:
	var trunk: = -1
	var crowns: Array = []
	for row in store.rows_in(model):
		var part: = store.name_at(row)
		if part == "Trunk":
			trunk = row
		elif part in CROWNS:
			crowns.append(row)
	return [trunk, crowns, model]



static func _loose_trees(kit: PolishKit, path: String) -> Array:
	var store: = kit.store
	var trunks: Array = []
	var crowns: Array = []
	for row in kit.rows_under(path):
		var part: = store.name_at(row)
		if part == "Trunk":
			trunks.append(row)
		elif part in CROWNS:
			crowns.append(row)
	var found: Array = []
	for trunk: int in trunks:
		var at: = store.position(trunk)
		var mine: Array = []
		for row: int in crowns:
			var crown: = store.position(row)
			if Vector2(crown.x - at.x, crown.z - at.z).length() < 9.0 and crown.y > at.y:
				mine.append(row)
		found.append([trunk, mine, - store.id_at(trunk)])
	return found


static func _species(kit: PolishKit, spot: Vector2, conifer: bool, model: int, main_roads: Array, apartments: Array) -> String:
	if conifer:
		return "spruce"
	if absf(spot.y - Train.LINE_Z) < RAIL:
		return "poplar"
	var at: = Vector3(spot.x, 0, spot.y)
	var ground: = kit.surface_at(at)
	if ground in ["park", "plaza", "paving", "bus_station"]:
		return "lime"
	for road: Dictionary in main_roads:
		if _near_road(road, spot, float(road["width"]) / 2.0 + 16.0):
			return "lime"
	var wild: bool = model > 0 and kit.store.nodes.has(model) and kit.store.nodes[model]["n"] == "WildTree"
	for block: Vector2 in apartments:
		if spot.distance_to(block) < 70.0:
			return "birch"
	if not wild and kit.building_distance(at, GARDEN) < GARDEN:
		return "walnut" if int(rand_from_seed(hash([int(spot.x), int(spot.y), "walnut"]))[0]) % 3 == 0 else "fruit"
	if wild:
		return "birch"
	return "birch" if int(rand_from_seed(hash([int(spot.x), int(spot.y), "lime"]))[0]) % 4 == 0 else "lime"


static func _near_road(road: Dictionary, spot: Vector2, reach: float) -> bool:
	var points: Array = road["points"]
	for leg in points.size() - 1:
		var a: = Vector2(float(points[leg][0]), float(points[leg][1]))
		var b: = Vector2(float(points[leg + 1][0]), float(points[leg + 1][1]))
		var t: = clampf((spot - a).dot(b - a) / maxf((b - a).length_squared(), 0.01), 0.0, 1.0)
		if spot.distance_to(a + (b - a) * t) < reach:
			return true
	return false
