extends RefCounted



static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--handlook="):
			var look: = HandLook.new()
			look.name = "HandLook"
			main.add_child(look)
			return
