class_name Readiness
extends Node











const ITEMS: Array[String] = ["tank", "fuel", "sets", "hose"]
const TICK: = 0.5

static var current: Readiness



var state: Dictionary = {"due": false, "vehicles": {}}
var _out: Dictionary = {}
var _on_call: = false
var _filling: Dictionary = {}
var _clock: = 0.0
var _prompts: Array = []


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	for vehicle in Vehicle.all:
		_add_prompts(vehicle)
	Net.share("readiness", func() -> Variant: return state, func(shared: Variant) -> void :
		if Net.is_client() and shared is Dictionary:
			state = shared
	, 2.0)
	if Hud.current != null:
		Hud.current.add_widget("readiness", HudReadiness.new())




func _add_prompts(vehicle: Vehicle) -> void :
	var half: = float(vehicle.data.get("halfWidth", 4.0))
	var front: = float(vehicle.data.get("front", -12.0))
	for item: String in ["tank"]:
		if not _applies(vehicle, item):
			continue
		var holder: = Node3D.new()
		vehicle.add_child(holder)

		holder.position = Vector3(half + 0.4, 3.0, front * 0.25)
		var prompt: = Prompt.make(holder, Text.m("world.readiness.%sDo" % item), Text.m("world.readiness.%sWhat" % item), float(Config.Readiness.PromptHold), 9.0)
		prompt.condition = func(_player: Player) -> bool: return at_station(vehicle) and not _done(vehicle, item) and not _is_filling(vehicle, item)
		prompt.triggered.connect( func(player: Player) -> void : _start_fill(vehicle, item, player))
		_prompts.append([vehicle, item, prompt])




func _applies(vehicle: Vehicle, item: String) -> bool:
	match item:
		"tank":
			return vehicle.capacity > 0.0 and not vehicle.spec.get("tankEmpty", false)
		"fuel":
			return vehicle.fuel_capacity > 0.0
		"sets":
			return _set_source(vehicle) != ""
		"hose":
			return _rig(vehicle) != null
	return false



func _done(vehicle: Vehicle, item: String) -> bool:
	var settings: Dictionary = Config.Readiness
	match item:
		"tank":
			return vehicle.water >= vehicle.capacity * float(settings["TankFull"])
		"fuel":
			return vehicle.fuel >= vehicle.fuel_capacity * float(settings["FuelFull"])
		"sets":
			var air: = AirService.current
			var source: = _set_source(vehicle)
			if air == null or source.is_empty():
				return true
			var full: = float(Config.Air.Capacity) * float(settings["SetsFull"])
			var bars: Array = air.bars.get(source, [])
			var count: = {"truck": int(Config.Air.TruckSets), "tanker": int(Config.Air.TankerSets), "command": int(vehicle.spec.get("airSets", 0))}
			if int(air.pool.get(source, 0)) < int(count.get(source, 0)):
				return false
			for bar: Variant in bars:
				if float(bar) < full:
					return false
			return true
		"hose":
			var rig: Variant = _rig(vehicle)
			if rig == null or not rig.has("rolls"):
				return true
			for kind: String in rig["rolls"]:
				if int(rig["rolls"][kind]) < int(rig["roll_full"][kind]):
					return false
			return true
	return true



func _set_source(vehicle: Vehicle) -> String:
	var air: = AirService.current
	if air == null:
		return ""
	if vehicle == air.truck:
		return "truck"
	if vehicle == air.tanker:
		return "tanker"
	if vehicle == air.command and int(vehicle.spec.get("airSets", 0)) > 0:
		return "command"
	return ""


func _rig(vehicle: Vehicle) -> Variant:
	var hoses: = HoseService.current
	if hoses == null:
		return null
	for rig: Dictionary in hoses.rigs:
		if rig["vehicle"] == vehicle:
			return rig
	return null



static func at_station(vehicle: Vehicle) -> bool:
	return Game.station != null and Game.station.inside(vehicle.global_position, float(Config.Readiness.ApronReach))


func _is_filling(vehicle: Vehicle, item: String) -> bool:
	return bool(_filling.get(vehicle, {}).get(item, false)) or bool(state.get("filling", {}).get(String(vehicle.spec["name"]), {}).get(item, false))




func _start_fill(vehicle: Vehicle, item: String, player: Player) -> void :
	if Net.is_client() or not at_station(vehicle) or _done(vehicle, item):
		return
	if not _filling.has(vehicle):
		_filling[vehicle] = {}
	_filling[vehicle][item] = true
	Game.notify(Text.m("world.readiness.%sStarted" % item), "", player)


func _physics_process(delta: float) -> void :
	if Net.is_client():
		return
	_fill(delta)
	_clock += delta
	if _clock < TICK:
		return
	_clock = 0.0
	_look()



func _fill(delta: float) -> void :
	var settings: Dictionary = Config.Readiness
	for vehicle: Vehicle in _filling.keys():
		var filling: Dictionary = _filling[vehicle]
		if not is_instance_valid(vehicle) or not at_station(vehicle):
			_filling.erase(vehicle)
			continue
		if filling.get("tank", false):
			vehicle.fill_water(float(settings["TankRate"]) * delta)
			if vehicle.water >= vehicle.capacity - 0.5:
				filling.erase("tank")
		if filling.get("fuel", false):
			vehicle.fuel = minf(vehicle.fuel_capacity, vehicle.fuel + float(settings["FuelRate"]) * delta)
			if vehicle.fuel >= vehicle.fuel_capacity - 0.05:
				filling.erase("fuel")
		if filling.is_empty():
			_filling.erase(vehicle)




func _look() -> void :
	var incident: = Game.incident
	if incident.has("pos"):
		if not _on_call:
			_on_call = true
			_out = {}
		for vehicle in Vehicle.all:
			if not at_station(vehicle):
				_out[vehicle] = true
	elif _on_call:
		_on_call = false
		if not _out.is_empty():
			state["due"] = true
	var vehicles: = {}
	var all_done: = true
	if state["due"]:
		for vehicle: Vehicle in _out:
			if not is_instance_valid(vehicle):
				continue
			var items: = {}
			for item in ITEMS:
				if _applies(vehicle, item):
					items[item] = _done(vehicle, item)
					all_done = all_done and items[item]
			vehicles[String(vehicle.spec["name"])] = items
	var filling: = {}
	for vehicle: Vehicle in _filling:
		filling[String(vehicle.spec["name"])] = _filling[vehicle].duplicate()
	var fresh: = {"due": state["due"] and not all_done, "vehicles": vehicles, "filling": filling}
	if state["due"] and all_done:
		_out = {}
		Game.notify(Text.m("world.readiness.ready"), "good")
	if fresh != state:
		state = fresh



func ready() -> bool:
	return not state.get("due", false)




func missing() -> Dictionary:
	var parts: Array = []
	var vehicles: Dictionary = state.get("vehicles", {})
	for vehicle_name: String in vehicles:
		var left: Array = []
		for item: String in vehicles[vehicle_name]:
			if not vehicles[vehicle_name][item]:
				if not left.is_empty():
					left.append(", ")
				left.append(Text.m("world.readiness.items.%s" % item))
		if not left.is_empty():
			if not parts.is_empty():
				parts.append("; ")
			parts.append(Text.named("vehicles", vehicle_name))
			parts.append(": ")
			parts.append_array(left)
	return Text.join(parts)



func open_for(vehicles: Array) -> void :
	for vehicle: Vehicle in vehicles:
		_out[vehicle] = true
	state["due"] = true
	_look()
