extends RefCounted




static func start(main: Node) -> void :
	if OS.get_cmdline_user_args().has("--locals-off") or OS.get_cmdline_user_args().has("--life-off"):
		return
	var locals: = TownLocals.new()
	locals.name = "TownLocals"
	main.add_child(locals)
	locals.start()
