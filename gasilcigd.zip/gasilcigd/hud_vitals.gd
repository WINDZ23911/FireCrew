class_name HudVitals
extends Control








const HEIGHT: = 122.0
const BAR_WIDTH: = 258.0

var _badge: TextureRect
var _name: Label
var _cash: Label
var _pending: Label
var _health: Control
var _rank: Label
var _rank_index: = -1
var _rank_player: Player
var _rank_since: = 0.0
var _bar_track: ColorRect
var _bar_fill: ColorRect
var _breath: Control


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var plate: = Ui.plate(Vector2(360, HEIGHT))
	plate.position = Vector2(Ui.MARGIN, - HEIGHT - Ui.MARGIN)
	add_child(plate)
	Ui.stripe(plate, 110)
	_badge = Ui.icon("shield", 70, Ui.YELLOW)
	_badge.position = Vector2(10, 14)
	plate.add_child(_badge)
	var helmet: = Ui.icon("helmet", 38, Ui.DARK)
	helmet.position = Vector2(26, 28)
	plate.add_child(helmet)
	_name = Ui.display("", 24)
	_name.position = Vector2(92, 6)
	_name.size = Vector2(160, 30)
	_name.clip_text = true
	plate.add_child(_name)

	_cash = Ui.display("0", 22, Ui.AMBER)
	_cash.position = Vector2(256, 6)
	_cash.size = Vector2(90, 30)
	_cash.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	plate.add_child(_cash)

	_pending = Ui.display("", 16, Ui.GREEN)
	_pending.size = Vector2(0, 30)
	_pending.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_pending.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	plate.add_child(_pending)
	var heart: = Ui.icon("heart", 20, Ui.RED)
	heart.position = Vector2(92, 42)
	plate.add_child(heart)
	_health = Ui.bar(Vector2(232, 16), Ui.GREEN, 10)
	_health.position = Vector2(118, 44)
	plate.add_child(_health)
	_rank = Ui.caps("", int(Config.Hud.CapsFloor))
	_rank.position = Vector2(92, 66)
	plate.add_child(_rank)

	var bar_height: = float(Config.Onboarding.RankUp["BarHeight"])
	_bar_track = ColorRect.new()
	_bar_track.color = Color(Ui.INSET, 0.9)
	_bar_track.position = Vector2(92, 94)
	_bar_track.size = Vector2(BAR_WIDTH, bar_height)
	_bar_track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	plate.add_child(_bar_track)
	_bar_fill = ColorRect.new()
	_bar_fill.size = Vector2(0, bar_height)
	_bar_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar_track.add_child(_bar_fill)
	_breath = Ui.bar(Vector2(BAR_WIDTH, 10), Ui.TEXT)
	_breath.position = Vector2(92, 103)
	plate.add_child(_breath)






static func rank_progress(player: Player) -> Dictionary:
	var ranks: Array = Config.Gear.Ranks
	var saved: = int(player.get_attr("Saved", 0)) if player else 0
	var index: = Alarm.rank_of(saved)
	var progress: = {"rank": index, "next": -1, "have": 0, "need": 0, "share": 1.0, "saved": saved}
	if index + 1 < ranks.size():
		var from: = int(ranks[index]["saved"])
		var to: = int(ranks[index + 1]["saved"])
		progress["next"] = index + 1
		progress["have"] = saved - from
		progress["need"] = maxi(to - from, 1)
		progress["share"] = clampf(float(saved - from) / maxf(to - from, 1.0), 0.0, 1.0)
	return progress



func _lay_top_row() -> void :
	var right: = 350.0
	var pending_width: = _pending.get_minimum_size().x if _pending.text != "" else 0.0
	_pending.position = Vector2(right - pending_width, 8)
	_pending.size.x = pending_width
	if pending_width > 0.0:
		right -= pending_width + 8.0
	var cash_width: = _cash.get_minimum_size().x
	_cash.position.x = right - cash_width
	_cash.size.x = cash_width
	_name.size.x = maxf(40.0, _cash.position.x - 10.0 - _name.position.x)


func _process(_delta: float) -> void :
	var player: = Game.local_player
	if player == null:
		return
	_name.text = player.display_name.to_upper()

	var pending: = int(player.get_attr("Pending", 0))
	_cash.text = Ui.money(player.get_attr("Cash", 0))
	_pending.text = "+" + Ui.money(pending) if pending > 0 else ""
	_lay_top_row()
	var share: = player.health / player.max_health
	Ui.set_bar(_health, share, Ui.state(Ui.GREEN if share > 0.5 else (Ui.AMBER if share > 0.25 else Ui.RED)))
	Ui.set_bar(_breath, player.stamina, Ui.AMBER if player._winded else (Ui.GREEN if player.sprinting else Ui.TEXT))
	var ranks: Array = Config.Gear.Ranks
	var progress: = rank_progress(player)
	var reached: = int(progress["rank"])
	var rank: Dictionary = ranks[reached]
	var next: Variant = ranks[int(progress["next"])] if int(progress["next"]) >= 0 else null
	var saved: = int(progress["saved"])
	if _rank_player != player:
		_rank_player = player
		_rank_index = -1
		_rank_since = Game.now()

	if _rank_index >= 0 and reached > _rank_index and Game.now() - _rank_since > float(Config.Onboarding.RankUp["Settle"]):
		if HudRankUp.current:
			HudRankUp.current.promote(rank)
		else:
			Sounds.ui("ui_fanfare")
	_rank_index = reached
	_badge.modulate = Ui.RANK_COLORS.get(rank["sheet"], Ui.YELLOW)
	var rank_name: = Text.say(Text.named("ranks", rank["sheet"])).to_upper()
	if next:
		_rank.text = Text.say(Text.f("hud.vitals.savedOf", [rank_name, saved, int(next["saved"])]))
		_bar_fill.color = Ui.RANK_COLORS.get(next["sheet"], Ui.YELLOW)
		_bar_fill.size.x = BAR_WIDTH * float(progress["share"])
	else:
		_rank.text = Text.say(Text.f("hud.vitals.saved", [rank_name, saved]))
		_bar_fill.color = Ui.RANK_COLORS.get(rank["sheet"], Ui.YELLOW)
		_bar_fill.size.x = BAR_WIDTH
