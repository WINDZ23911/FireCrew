class_name GearService
extends Node3D














signal choosing_began(player: Player, stall: Dictionary)

static var current: GearService


const SUIT_SHEETS: Array[String] = ["jacket", "limbs", "visor"]
const STALL_RED: = Color(120 / 255.0, 30 / 255.0, 28 / 255.0)
const STALL_DARK: = Color(60 / 255.0, 60 / 255.0, 64 / 255.0)
const LAMP_COLOR: = Color(1.0, 244 / 255.0, 214 / 255.0)

const SOOT_STEPS: = 20
var worn: Dictionary = {}
var stalls: Array = []
var _looks: Dictionary = {}
var _templates: Array[MeshInstance3D] = []
var _kit: Node
var _dressed_stalls: = 0
var _stall_of: Dictionary = {}
var _choosing: Dictionary = {}
var _busy: Dictionary = {}
var _removed: Array[Callable] = []
var _was_client: = false


func _init() -> void :
	current = self


func _ready() -> void :
	_load_kit()
	for spot: Dictionary in Game.records["station"]["places"]["lockers"]:
		_build_stall(spot)
	_removed.append(_return_to_stall)


	Net.handle("gear.visor", toggle_visor)
	Net.handle("gear.lamp", toggle_lamp)
	Net.handle("gear.suit", func(player: Player, suit_id: Variant) -> void :
		choose_suit(player, null if (suit_id is String and suit_id.is_empty()) else suit_id)
	)
	Net.handle("gear.helmet", func(player: Player, sheet: Variant) -> void :
		choose_helmet(player, null if (sheet is String and sheet.is_empty()) else sheet)
	)
	Net.handle("gear.choose.stop", stop_choosing)
	Net.handle("gear.renew", renew_gear)

	Net.handle("gear.choose", func(index: int) -> void :
		if index >= 0 and index < stalls.size():
			choosing_began.emit(Game.local_player, stalls[index])
	)

	Net.share("gear.stalls", func() -> Variant:
		var taken: Array = []
		for stall: Dictionary in stalls:
			taken.append(stall["user"] != null)
		return taken
	, func(taken: Variant) -> void :
		for index in mini(taken.size(), stalls.size()):
			if stalls[index]["display"] != null:
				stalls[index]["display"].visible = not taken[index]
	, 4.0)
	Net.peer_joined.connect(adopt)
	Net.peer_left.connect(_on_left)
	Net.started.connect(_on_net_started)
	Net.stopped.connect(_on_net_stopped)

	for player in Game.players:
		adopt(player)


func _exit_tree() -> void :
	if _kit:
		_kit.free()
	if current == self:
		current = null


func _load_kit() -> void :
	var scene: PackedScene = load(FirefighterRig.KIT)
	if scene == null:
		push_warning("Gear will work without its look")
		return
	_kit = scene.instantiate()
	for child in _kit.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() == 2 and bits[0] != "Marker":
			_templates.append(mesh)




func adopt(player: Player) -> void :
	Civilian.build(player.rig)
	if Net.is_client():
		return
	StanceService.watch(player)
	player.died.connect(_on_died.bind(player))
	if player.get_attr("Geared", false) and not OS.get_cmdline_user_args().has("--civilian"):
		_gear_up(player, null, true)
	else:
		player.set_attr("Geared", false)
		player.set_attr("Lamp", false)
		player.rig.wear({Civilian.SHEET: true})
		_tell_sheets(player)



func _on_left(player: Player) -> void :
	if worn.has(player):
		_gear_removed(player)
		worn.erase(player)
	_choosing.erase(player)
	_busy.erase(player)
	_drop_look(player)




func _on_net_started() -> void :
	if not Net.is_client():
		return
	_was_client = true
	worn.clear()
	_stall_of.clear()
	_choosing.clear()
	_busy.clear()
	for stall: Dictionary in stalls:
		stall["user"] = null
	var me: = Game.local_player
	for key: String in ["Lamp", "Soot", "Sheets"]:
		me.set_attr(key, null)



func _on_net_stopped() -> void :
	for player: Player in worn.keys():
		if player != Game.local_player:
			if is_instance_valid(player):
				_gear_removed(player)
			worn.erase(player)
	for player: Player in _looks.keys():
		if player != Game.local_player:
			_drop_look(player)
	if not _was_client:
		return
	_was_client = false
	for stall: Dictionary in stalls:
		stall["user"] = null
		if stall["display"] != null:
			stall["display"].visible = true
	var me: = Game.local_player
	if me != null and not worn.has(me):
		if me.get_attr("Geared", false):
			_gear_up(me, null, true)
		else:
			me.rig.wear({Civilian.SHEET: true})
			_tell_sheets(me)


static func _part_of(mesh: MeshInstance3D) -> String:
	return String(mesh.name).get_slice("_", 0)


static func _sheet_of(mesh: MeshInstance3D) -> String:
	return String(mesh.name).get_slice("_", 1)


func has_sheet(sheet: String) -> bool:
	for template in _templates:
		if _sheet_of(template) == sheet:
			return true
	return false






func rank_of(player: Player) -> Dictionary:
	var saved: = int(player.get_attr("Saved", 0))
	var rank: Dictionary = Config.Gear.Ranks[0]
	for candidate: Dictionary in Config.Gear.Ranks:
		if saved >= int(candidate["saved"]):
			rank = candidate
	return rank


func suit_of(suit_id: Variant) -> Variant:
	for suit: Dictionary in Config.Gear.Suits:
		if suit["id"] == suit_id:
			return suit
	return null



func suit_sheets(suit_id: Variant) -> Dictionary:
	var suit: Variant = suit_of(suit_id)
	var sheets: = {"visor": true}
	for sheet in SUIT_SHEETS:
		var other: Variant = suit["sheets"].get(sheet) if suit != null else null
		sheets[other if (other != null and has_sheet(other)) else sheet] = true
	if visor_starts_up():
		sheets.erase("visor")
	return sheets




static func visor_starts_up() -> bool:
	return bool(Edition.data().get("visor_up", false))




static func rank_helmet_of(rank: Dictionary) -> String:
	return String(rank.get("helmet", rank["sheet"]))




func helmet_choice(player: Player, sheet: String) -> Array:
	var saved: = int(player.get_attr("Saved", 0))
	var ranks: Array = Config.Gear.Ranks
	for index in range(1, ranks.size()):
		if rank_helmet_of(ranks[index]) == sheet:
			return [true, saved >= int(ranks[index]["saved"])]
	for helmet: Dictionary in Config.Gear.Helmets:
		if helmet["sheet"] == sheet:
			return [true, false]
	return [false, false]


func may_wear_helmet(player: Player, sheet: String) -> bool:
	var choice: = helmet_choice(player, sheet)
	return choice[0] and (choice[1] or PlayerData.owns(player, sheet))






func _update_visor(player: Player) -> void :
	var state: Dictionary = worn[player]
	player.rig.set_sheet("visor", not (state["visor_up"] or state["mask_on"]))
	_tell_sheets(player)



func _tell_sheets(player: Player) -> void :
	var sheets: = player.rig.shown_sheets()
	sheets.sort()
	player.set_attr("Sheets", sheets)




func _create_lamp(player: Player, state: Dictionary) -> void :
	state["tinted"] = {}
	state["soot"] = 0
	var lens: = MeshInstance3D.new()
	var ball: = SphereMesh.new()
	ball.radius = 0.06
	ball.height = 0.12
	lens.mesh = ball
	var glow: = StandardMaterial3D.new()
	glow.albedo_color = LAMP_COLOR
	glow.emission_enabled = true
	glow.emission = LAMP_COLOR
	glow.emission_energy_multiplier = 8.0
	lens.material_override = glow
	lens.position = Config.Gear.LampOffset
	lens.visible = false
	player.rig.head.add_child(lens)
	var beam: = SpotLight3D.new()

	beam.spot_range = 75.0
	beam.spot_angle = 62.0 / 2.0
	beam.spot_angle_attenuation = 0.45
	beam.spot_attenuation = 0.7
	beam.light_energy = 7.5
	beam.light_color = LAMP_COLOR
	Graphics.lamp_shadow(beam)
	beam.visible = false
	add_child(beam)
	state["lens"] = lens
	state["lamp"] = beam


func _gear_up(player: Player, suit_id: Variant, quiet: = false) -> void :
	if player.health <= 0.0:
		return
	var rank: = rank_of(player)

	var rank_helmet: String = rank_helmet_of(rank)
	var helmet_sheet: String = rank_helmet if has_sheet(rank_helmet) else "helmet"
	var picked: Variant = player.get_attr("Helmet")
	if picked is String and has_sheet(picked) and may_wear_helmet(player, picked):
		helmet_sheet = picked


	if player.brain != null:
		suit_id = null
	var sheets: = suit_sheets(suit_id)
	sheets[helmet_sheet] = true
	player.rig.wear(sheets)

	worn[player] = {"suit": suit_id, "helmet": helmet_sheet, "visor_up": visor_starts_up(), "mask_on": false, "soot": 0.0}
	player.set_attr("Geared", true)
	player.set_attr("Lamp", false)
	player.set_attr("Soot", 0)
	player.set_attr("Rank", rank["name"])
	_tell_sheets(player)
	if not quiet:
		Game.notify(Text.f("gear.suit.on", [Text.named("ranks", rank["sheet"])]), "", player)


func _gear_removed(player: Player) -> void :
	for callback in _removed:
		callback.call(player)


func _change_back(player: Player, quiet: = false) -> void :
	_gear_removed(player)
	worn.erase(player)
	player.set_attr("Geared", false)
	player.set_attr("Lamp", false)
	player.set_attr("Soot", 0)
	player.rig.wear({Civilian.SHEET: true})
	_tell_sheets(player)
	if not quiet:
		Game.notify(Text.m("gear.suit.off"), "", player)




func _may_suit_up(player: Player, suit_id: Variant) -> bool:
	var suit: Variant = suit_of(suit_id)
	if suit == null or PlayerData.owns(player, suit_id):
		return true
	var price: = int(suit["price"])
	if not PlayerData.buy(player, suit_id, price):
		Game.notify(Text.f("gear.suit.suitTooDear", [Text.named("suits", suit_id), price]), "", player)
		return false
	Game.notify(Text.f("gear.suit.suitBought", [Text.named("suits", suit_id), price]), "", player)
	return true





func _on_died(player: Player) -> void :
	if not worn.has(player):
		return
	_gear_removed(player)
	worn[player]["soot"] = 0.0
	player.set_attr("Soot", 0)





func _panel(base: Transform3D, part_name: String, size: Vector3, offset: Vector3, color: = STALL_RED, material: = "Metal", solid: = true, transparency: = 0.0) -> PartNode:
	var flags: = PartStore.QUERY | PartStore.SHADOW | (PartStore.COLLIDE if solid else 0)
	var part: = PartNode.create(PartStore.Shape.BLOCK, base * Transform3D(Basis.IDENTITY, offset), size, color, material, part_name, flags, transparency)
	add_child(part)
	return part




func _build_stall(spot: Dictionary) -> void :
	var base: Transform3D = spot["place"]
	var number: = int(spot["number"])

	var back: = _panel(base, "Back", Vector3(4.5, 9, 0.15), Vector3(0, 4.5, -1.42))
	for side: float in [-1.0, 1.0]:
		_panel(base, "Side", Vector3(0.12, 9, 3), Vector3(side * 2.19, 4.5, 0), STALL_RED, "DiamondPlate", true, 0.3)
		_panel(base, "Post", Vector3(0.2, 9, 0.2), Vector3(side * 2.15, 4.5, 1.4))
	_panel(base, "Top", Vector3(4.5, 0.15, 3), Vector3(0, 8.93, 0))
	_panel(base, "Shelf", Vector3(4.2, 0.15, 2.7), Vector3(0, 6.3, 0), STALL_DARK)
	_panel(base, "BootTray", Vector3(4.2, 0.12, 2.7), Vector3(0, 0.06, 0), STALL_DARK)
	_panel(base, "Rail", Vector3(4.2, 0.12, 0.12), Vector3(0, 6.1, 0.2), STALL_DARK, "Metal", false)
	_panel(base, "Number", Vector3(1.6, 0.9, 0.08), Vector3(0, 8.3, 1.5), Color(240 / 255.0, 240 / 255.0, 236 / 255.0), "SmoothPlastic", false)
	var label: = Label3D.new()
	label.text = str(number)
	label.font = Ui.world_display_font()
	label.font_size = 96
	label.pixel_size = 0.0075
	label.modulate = STALL_RED
	label.outline_size = 0
	label.shaded = true
	add_child(label)
	label.global_transform = base * Transform3D(Basis.IDENTITY, Vector3(0, 8.3, 1.55))


	if Settings.quality > Graphics.VERY_LOW:
		var lamp: = SpotLight3D.new()
		lamp.light_color = Color(1.0, 0.95, 0.86)
		lamp.light_energy = 5.0
		lamp.light_specular = 0.2
		lamp.spot_range = 12.0
		lamp.spot_angle = 55.0
		lamp.shadow_enabled = false
		lamp.distance_fade_enabled = true
		lamp.distance_fade_begin = 60.0
		lamp.distance_fade_length = 20.0
		add_child(lamp)
		lamp.global_transform = base * Transform3D(Basis(Vector3.RIGHT, - PI / 2.0 + 0.35), Vector3(0, 8.7, 1.1))

	var stall: = {"back": back, "position": back.global_position, "number": number, "display": null, "suit": null, "user": null, "prompt": null}
	var index: = stalls.size()
	if spot.get("dressed", false):

		_dressed_stalls += 1
		var suits: Array = Config.Gear.Suits
		if _dressed_stalls % 2 == 0 and not suits.is_empty():
			stall["suit"] = suits[(_dressed_stalls / 2 - 1) % suits.size()]["id"]
		var sheets: = suit_sheets(stall["suit"])
		sheets["helmet"] = true


		var shown: = Node3D.new()
		shown.name = "Gear"
		add_child(shown)
		var hang: = func(head_height: float, wanted: Callable) -> void :
			var wearer: = base * Transform3D(Basis(Vector3.UP, PI), Vector3(0, head_height, 0))
			display(shown, wearer, func(part: String, sheet: String) -> bool: return sheets.has(sheet) and wanted.call(part, sheet))
		hang.call(6.05, func(part: String, _sheet: String) -> bool: return part.contains("Torso") or part.contains("Arm"))
		hang.call(4.97, func(part: String, _sheet: String) -> bool: return part.contains("Foot"))
		hang.call(7.2, func(_part: String, sheet: String) -> bool: return sheet == "helmet" or sheet == "visor")
		stall["display"] = shown
	stalls.append(stall)



	var prompt: = Prompt.make(back, Text.m("gear.suit.stallAction"), Text.f("gear.suit.stall", [str(number)]), float(Config.Gear.DonTime), 7.0)
	prompt.triggered.connect( func(player: Player) -> void :
		if _busy.has(player):
			return
		if worn.has(player):
			_change_back(player)
		else:

			_choosing[player] = stall
			Net.send_to(player, "gear.choose", [index])
	)
	stall["prompt"] = prompt



func _return_to_stall(player: Player) -> void :
	var stall: Variant = _stall_of.get(player)
	if stall != null:
		_stall_of.erase(player)
		stall["user"] = null
		stall["display"].visible = true




func display(parent: Node3D, head: Transform3D, wanted: Callable) -> void :
	for template in _templates:
		if wanted.call(_part_of(template), _sheet_of(template)):
			var piece: = template.duplicate() as MeshInstance3D
			piece.visible = true
			parent.add_child(piece)
			piece.global_transform = head * template.transform






func on_removed(callback: Callable) -> void :
	_removed.append(callback)



func set_mask_worn(player: Player, on: bool) -> void :
	if worn.has(player):
		worn[player]["mask_on"] = on
		_update_visor(player)



func _tint(player: Player, state: Dictionary, suit_tint: Color, suit_wear: float, helmet_tint: Color, helmet_wear: float) -> void :

	var tinted: Dictionary = state["tinted"]
	for sheet: String in player.rig.pieces:
		if sheet == Civilian.SHEET:
			continue
		var helmet: = sheet.begins_with("helmet")
		var tint: = helmet_tint if helmet else suit_tint
		var wear: = helmet_wear if helmet else suit_wear
		for mesh: MeshInstance3D in player.rig.pieces[sheet]:
			if not tinted.has(mesh):
				if tint == Color.WHITE and wear <= 0.0:
					continue

				var copies: Array = []
				for surface in mesh.get_surface_override_material_count():


					var material: = mesh.get_surface_override_material(surface) as BaseMaterial3D
					if material == null and mesh.mesh != null:
						material = mesh.mesh.surface_get_material(surface) as BaseMaterial3D
					if material == null:
						continue
					var copy: = material.duplicate() as BaseMaterial3D
					mesh.set_surface_override_material(surface, copy)
					copies.append([copy, copy.albedo_color, material])
				tinted[mesh] = copies
			for pair: Array in tinted[mesh]:
				var clean: Color = pair[1]
				var copy: BaseMaterial3D = pair[0]
				copy.albedo_color = Color(clean.r * tint.r, clean.g * tint.g, clean.b * tint.b, clean.a)


				if copy is StandardMaterial3D and copy.emission_texture != null and FirefighterRig._is_banded(copy):
					var kept: = 1.0 - float(Config.Gear.WearBands) * wear
					copy.set_meta("wear", kept)
					copy.emission_energy_multiplier = FirefighterRig._bands_glow * kept
				elif helmet:

					copy.next_pass = _scorch(wear) if wear > 0.02 else null
					var original: Variant = pair[2] if pair.size() > 2 else null
					if original is StandardMaterial3D and copy is StandardMaterial3D and FirefighterRig._helmets.has(original):
						(copy as StandardMaterial3D).emission_energy_multiplier = FirefighterRig._helmet_glow(original) * (1.0 - 0.8 * wear)
					copy.albedo_color = copy.albedo_color.darkened(0.45 * wear)




static var _scorches: Dictionary = {}
static var _scorch_noise: NoiseTexture2D


static func _scorch(wear: float) -> StandardMaterial3D:
	var key: = snappedf(wear, 0.05)
	if _scorches.has(key):
		return _scorches[key]
	if _scorch_noise == null:
		var noise: = FastNoiseLite.new()
		noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		noise.frequency = 0.05
		noise.fractal_octaves = 3
		_scorch_noise = NoiseTexture2D.new()
		_scorch_noise.noise = noise
		_scorch_noise.width = 128
		_scorch_noise.height = 128
		_scorch_noise.seamless = true
		var ramp: = Gradient.new()
		ramp.set_color(0, Color(0.06, 0.05, 0.05, 0.0))
		ramp.set_color(1, Color(0.06, 0.05, 0.05, 1.0))
		ramp.set_offset(0, 0.5)
		ramp.set_offset(1, 0.68)
		_scorch_noise.color_ramp = ramp
	var material: = StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_texture = _scorch_noise
	material.albedo_color = Color(1, 1, 1, clampf(key * 1.1, 0.0, 1.0))
	material.uv1_triplanar = true
	material.uv1_scale = Vector3(0.7, 0.7, 0.7)
	material.roughness = 0.95
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	material.cull_mode = BaseMaterial3D.CULL_BACK
	_scorches[key] = material
	return material



func add_soot(player: Player, amount: float) -> void :
	if not worn.has(player):
		return
	var state: Dictionary = worn[player]
	if state["soot"] >= 1.0:
		return
	var before: float = state["soot"]
	state["soot"] = minf(1.0, before + amount)


	player.set_attr("Soot", floori(state["soot"] * SOOT_STEPS))


func soot_of(player: Player) -> float:
	return worn[player]["soot"] if worn.has(player) else 0.0


func is_geared(player: Player) -> bool:
	return worn.has(player)



func heat_protection(player: Player) -> float:
	return float(Config.Gear.HeatProtection) if worn.has(player) else 0.0





func _near_stall(player: Player, stall: Variant) -> bool:
	return stall != null and player.root_position().distance_to(stall["position"]) <= float(Config.Gear.StallReach)



func choosing(player: Player) -> Variant:
	return _choosing.get(player)


func stop_choosing(player: Player) -> void :
	_choosing.erase(player)



func choose_suit(player: Player, suit_id: Variant) -> void :
	var stall: Variant = _choosing.get(player)
	_choosing.erase(player)
	if stall == null or _busy.has(player) or worn.has(player) or not _near_stall(player, stall):
		return
	if suit_id != null and not (suit_id is String and suit_of(suit_id) != null):
		return
	_busy[player] = true
	if _may_suit_up(player, suit_id):
		_gear_up(player, suit_id)


		var from: Dictionary = stall
		if not (from["display"] != null and from["user"] == null and from["suit"] == suit_id):
			for other: Dictionary in stalls:
				if other["display"] != null and other["user"] == null and other["suit"] == suit_id:
					from = other
					break
		if worn.has(player) and not _stall_of.has(player) and from["display"] != null and from["user"] == null:
			from["user"] = player
			_stall_of[player] = from
			from["display"].visible = false
	_busy.erase(player)




func renew_gear(player: Player) -> void :
	var stall: Variant = _choosing.get(player)
	if not _near_stall(player, stall):
		return
	var price: = int(Config.Gear.RenewPrice)
	if maxf(float(player.get_attr("Wear", 0.0)), float(player.get_attr("HelmetWear", 0.0))) < float(Config.Gear.WearShowFrom):
		return
	if not PlayerData.spend(player, price):
		Game.notify(Text.f("gear.suit.renewTooDear", [Ui.money(price), Ui.money(player.get_attr("Cash", 0))]), "", player)
		return
	player.set_attr("Wear", 0.0)
	player.set_attr("HelmetWear", 0.0)
	player.set_attr("Soot", 0)
	if worn.has(player):
		worn[player]["soot"] = 0.0
	PlayerData.save_now(player)
	Game.notify(Text.f("gear.suit.renewed", [Ui.money(price)]), "good", player)




func choose_helmet(player: Player, sheet: Variant) -> void :
	var stall: Variant = _choosing.get(player)
	if not _near_stall(player, stall):
		return
	if sheet == null:
		PlayerData.set_helmet(player, null)
		return
	if not sheet is String or not helmet_choice(player, sheet)[0]:
		return
	if not may_wear_helmet(player, sheet):
		var price: = int(Config.Gear.HelmetPrice)
		if not PlayerData.buy(player, sheet, price):
			Game.notify(Text.f("gear.suit.helmetTooDear", [price]), "", player)
			return
		Game.notify(Text.f("gear.suit.helmetBought", [price]), "", player)
	PlayerData.set_helmet(player, sheet)


func toggle_visor(player: Player) -> void :
	if not worn.has(player):
		return
	var state: Dictionary = worn[player]
	if state["mask_on"]:
		Game.notify(Text.m("gear.suit.visorMask"), "", player)
	else:
		state["visor_up"] = not state["visor_up"]
		_update_visor(player)


func toggle_lamp(player: Player) -> void :
	if not worn.has(player):
		return
	player.set_attr("Lamp", not (player.get_attr("Lamp", false) == true))



func _look_of(player: Player) -> Dictionary:
	var look: Variant = _looks.get(player)
	if look == null:
		look = {}
		_create_lamp(player, look)
		_looks[player] = look
	return look


func _drop_look(player: Player) -> void :
	var look: Variant = _looks.get(player)
	_looks.erase(player)
	if look != null and is_instance_valid(look["lamp"]):
		look["lamp"].queue_free()



func _show(player: Player) -> void :
	var look: = _look_of(player)
	var geared: bool = player.get_attr("Geared", false) == true
	var lit: bool = geared and player.get_attr("Lamp", false) == true
	var beam: SpotLight3D = look["lamp"]
	beam.visible = lit
	look["lens"].visible = lit
	if lit:

		var head: = player.rig.head.global_transform
		var pitch: = player.camera.pitch if (player.is_local and player.camera != null) else player.rig.aim_pitch
		beam.global_transform = Transform3D(head.basis.orthonormalized() * Basis(Vector3.RIGHT, pitch * 0.7), head * (Config.Gear.LampOffset + Vector3(0, 0, - float(Config.Gear.LampLead))))
	var soot: = int(player.get_attr("Soot", 0)) if geared else 0



	var wear: = floori(clampf(float(player.get_attr("Wear", 0.0)), 0.0, 1.0) * SOOT_STEPS) if geared else 0
	var scorch: = floori(clampf(float(player.get_attr("HelmetWear", 0.0)), 0.0, 1.0) * SOOT_STEPS) if geared else 0
	if soot != look["soot"] or wear != look.get("wear", 0) or scorch != look.get("scorch", 0):
		look["soot"] = soot
		look["wear"] = wear
		look["scorch"] = scorch
		var share: = float(wear) / SOOT_STEPS
		var helmet_share: = float(scorch) / SOOT_STEPS
		var sooty: Color = Color.WHITE.lerp(Config.Gear.SootColor, float(soot) / SOOT_STEPS)
		var tint: = sooty.lerp(Config.Gear.WearColor, share * float(Config.Gear.WearTint))
		var helmet_tint: = sooty.lerp(Config.Gear.WearColor, helmet_share * float(Config.Gear.WearTint))
		_tint(player, look, tint, share, helmet_tint, helmet_share)

	if player.is_local and Net.is_client():
		var sheets: Variant = player.get_attr("Sheets")
		if sheets is Array:
			player.rig.wear_sheets(sheets)


func _process(_delta: float) -> void :
	for known: Variant in _looks.keys():
		if not is_instance_valid(known):
			var gone: Dictionary = _looks[known]
			_looks.erase(known)
			if is_instance_valid(gone["lamp"]):
				gone["lamp"].queue_free()
	for player in Game.players:
		_show(player)
	var local: = Game.local_player
	if local == null or Game.ui_open or not (local.get_attr("Geared", false) == true):
		return
	if Input.is_action_just_pressed("visor"):
		Net.request("gear.visor")
	if Input.is_action_just_pressed("lamp") and local.seat == null:
		Net.request("gear.lamp")
