class_name LockedIn
extends Node

















const TICK: = 0.25
const TRIES: = 8
const PUT_RIGHT: = 20.0
const TITLES: = 3

static var current: LockedIn

var kind: = "medical"
var house: House
var scene: Dictionary = {}
var _houses: Array[House] = []
var _serial: = 0
var _shown: Dictionary = {}
var _slowed: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func settings() -> Dictionary:
	return Config.Incidents.Medical


func available() -> bool:
	return not _houses.is_empty() and VictimService.current != null



static func urgency(sick_time: float) -> String:
	var lines: Array = settings()["UrgencyLines"]
	if sick_time < float(lines[0]):
		return "critical"
	return "serious" if sick_time < float(lines[1]) else "stable"



static func _has_upstairs(building: House) -> bool:
	for room_name: String in building.rooms:
		if _upstairs(building, room_name):
			return true
	return false



static func _upstairs(building: House, room_name: String) -> bool:
	var room: Variant = building.rooms.get(room_name)
	return room is Dictionary and int(room.get("floor", 0)) > 0


func run() -> bool:
	var people: = VictimService.current
	if people == null:
		return false
	var times: Array = settings()["SickTimes"]
	var sick_time: = randf_range(float(times[0]), float(times[1]))

	var building: House = null
	var inside: = 0
	var upstairs_wanted: = Alarm.complicated("medical", "upstairs")
	for attempt in TRIES:
		var tried: House = _houses[randi() % _houses.size()]
		if tried.ruined or (upstairs_wanted and attempt < TRIES - 2 and not _has_upstairs(tried)):
			continue
		tried.ruined = true
		tried.lock_up(true)
		inside = people.begin(tried, null, {"count": 1, "sick": 100.0 / sick_time})
		if inside > 0:
			building = tried
			break
		people.finish()
		tried.restore()
		tried.ruined = false
	if building == null:
		return false
	house = building
	var patient: Victim = people.victims[0]

	if Alarm.complicated("medical", "upstairs") and not _upstairs(building, patient.room):
		for room_name: String in building.rooms:
			if _upstairs(building, room_name) and not building.rooms[room_name].get("open", false):
				var spot: Variant = people._floor_spot(building, building.rooms[room_name])
				if spot != null:
					patient.figure.global_transform = spot
					patient.room = room_name
					break
	var heavy: = Alarm.complicated("medical", "heavy")
	var upstairs: = _upstairs(building, patient.room)

	patient.prompt.enabled = false

	_serial += 1
	var level: = urgency(sick_time)
	var front: Dictionary = building.outside_door()
	var key_roll: = float(rand_from_seed(hash([_serial, building.net_index, Time.get_ticks_usec()]))[0] %10000) / 10000.0
	scene = {
		"serial": _serial, "urgency": level, "aid_at": patient.figure.global_transform.origin, 
		"neighbour": _neighbour_place(building, front), "seed": randi_range(1, 1000000), 
		"asked": false, "has_key": key_roll < float(settings()["KeyChance"]), "aided": false, 
	}
	_build(scene)

	var call_name: = Text.join([Text.m("calls.medical.titles.%d" % randi_range(1, TITLES)), Text.m("calls.separator"), CallKit.building_name(building)])

	var marker: = _mark(building.position + Vector3(0, building.height / 2.0 + 10.0, 0))
	CallService.current.publish("medical", call_name, building.position, inside)
	Alarm.par(float(Alarm.settings()["Grade"]["Job"]["medical"]["Base"]))
	Game.incident.merge(people.shown(), true)
	Game.notify(Text.f("calls.medical.alarm", [call_name]))
	Game.notify(Text.m("calls.medical.urgency.told." + level), "danger" if level == "critical" else "warning")
	Game.notify(Text.m("calls.medical.briefAid"))
	if heavy:
		Game.notify(Text.m("calls.medical.heavy"), "warning")
	Escalation.begin_other(["worse"])


	(scene["neighbour_prompt"] as Prompt).triggered.connect( func(player: Player) -> void :
		if scene.is_empty() or scene["asked"]:
			return
		scene["asked"] = true
		scene["neighbour_prompt"].enabled = false
		if scene["has_key"] and front is Dictionary and front["locked"]:
			front["locked"] = false
			building._place_door(front)
			Game.notify(Text.m("calls.medical.neighbour.key"), "good", player)
		else:
			Game.notify(Text.m("calls.medical.neighbour.noKey"), "", player)
	)
	(scene["aid_prompt"] as Prompt).triggered.connect( func(player: Player) -> void :
		if scene.is_empty() or scene["aided"] or patient.state != "lying":
			return
		if not CallGear.has(player, "First aid kit"):
			Game.notify(Text.m("calls.medical.aid.needKit"), "", player)
			return
		scene["aided"] = true
		scene["aided_by"] = player
		if float(scene.get("aided_at", -1.0)) < 0.0:
			scene["aided_at"] = Game.now()
		scene["aid_prompt"].enabled = false
		patient.condition = minf(patient.condition + float(settings()["AidBoost"]), 100.0)
		patient.sick *= float(settings()["AidSlow"])
		patient.prompt.enabled = true
		Game.notify(Text.m("calls.medical.aid.done"), "good", player)
	)

	var waited: = 0.0
	var entered: = false
	var entered_at: = -1.0
	var forced: = false
	var forced_unasked: = false
	var told_stairs: = false
	var locked: Dictionary = {}
	for door_name: String in building.doors:
		locked[door_name] = building.doors[door_name]["locked"]
	var clear_air: = func(_at: Vector3) -> float: return 0.0
	while people.waiting() and not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		people.step(TICK, clear_air, false)

		for door_name: String in building.doors:
			var door: Dictionary = building.doors[door_name]
			if locked[door_name] and not door["locked"] and not (scene["asked"] and scene["has_key"] and is_same(door, front)):
				forced = true
				if not scene["asked"]:
					forced_unasked = true
			locked[door_name] = door["locked"]

		if Escalation.due() == "worse" and patient.waiting():
			var worse: Dictionary = Config.Alarm.Escalations.medical
			patient.sick *= float(worse["Factor"])
			patient.condition = maxf(patient.condition - float(worse["Drop"]), 1.0)
			if patient.state == "lying":
				scene["aided"] = false
				scene["aid_prompt"].enabled = true
				patient.prompt.enabled = false
		for player in Game.players:
			entered = entered or (is_instance_valid(player) and building.room_at(player.root_position()) != null)
		if entered and entered_at < 0.0:
			entered_at = Game.now()
		var carried: = patient.state == "carried"

		var carrier: Player = patient.carrier if carried and is_instance_valid(patient.carrier) else null
		for slowed: Variant in _slowed.keys():
			if slowed != carrier and is_instance_valid(slowed):
				slowed.set_attr("Dragging", null)
				_slowed.erase(slowed)
		if carrier != null:
			var inside_now: = building.room_at(carrier.root_position()) != null
			var alone: = true
			for other in Game.players:
				if is_instance_valid(other) and other != carrier and other.health > 0.0 and other.root_position().distance_to(carrier.root_position()) <= float(settings()["HelperReach"]):
					alone = false
			if inside_now and (upstairs or heavy) and alone:
				carrier.set_attr("Dragging", float(settings()["StairPace"]))
				_slowed[carrier] = true
				if not told_stairs:
					told_stairs = true
					Game.notify(Text.m("calls.medical.stairs"), "", carrier)
			elif _slowed.has(carrier):
				carrier.set_attr("Dragging", null)
				_slowed.erase(carrier)

		var step: Variant
		if carried:
			step = Text.m("calls.medical.next.carryTwo" if upstairs or heavy else "calls.medical.next.carry")
		elif entered and patient.state == "lying" and not scene["aided"]:
			step = Text.m("calls.medical.next.aid")
		elif entered:
			step = Text.m("calls.medical.next.find")
		elif not scene["asked"]:
			step = Text.m("calls.medical.next.ask")
		elif scene["has_key"] and front is Dictionary and not front["locked"]:
			step = Text.m("calls.medical.next.enter")
		else:
			step = Text.m("calls.medical.next.force")
		CallService.current.next_step(Text.join([Text.m("calls.medical.urgency." + level), Text.m("calls.separator"), step]))

	for slowed: Variant in _slowed:
		if is_instance_valid(slowed):
			slowed.set_attr("Dragging", null)
	_slowed = {}
	marker.queue_free()
	var late: = CallService.current.overdue(waited)
	if not late and not people.waiting():
		Alarm.done()


	if Alarm.handed_worst <= 100.0:
		Alarm.check("condition", Alarm.handed_worst >= float(Alarm.settings()["Grade"]["Procedure"]["MedicalCondition"]))
	if entered:
		Alarm.check("entry", not forced_unasked)
		var aided_at: = float(scene.get("aided_at", -1.0))
		Alarm.check("aid", aided_at >= 0.0 and aided_at - entered_at <= float(Alarm.settings()["Grade"]["Procedure"]["MedicalAid"]))
	var counts: = people.finish()
	if counts["lost"] > 0:
		Game.notify(Text.f("calls.medical.lost", [call_name]), "warning")
	elif late:
		Game.notify(Text.f("calls.medical.late", [call_name]), "warning")
	else:
		CallService.current.progress(counts["rescued"])
		var helpers: Dictionary = counts["rescuers"].duplicate()
		if is_instance_valid(scene.get("aided_by")):
			helpers[scene["aided_by"]] = true
		CallKit.pay_helpers(helpers, 0, "", "", false)
		Game.notify(Text.f("calls.medical.done", [call_name]), "good")
	Game.incident.merge(VictimService.card(counts), true)
	Game.incident.erase("next")
	Escalation.reset()
	_unbuild(scene)
	scene = {}

	await CallService.current.settle()
	CallService.current.clear(late or counts["lost"] > 0)
	house = null

	get_tree().create_timer(PUT_RIGHT, false).timeout.connect( func() -> void :
		building.restore()
		building.ruined = false
	)
	return true



static func _neighbour_place(building: House, front: Variant) -> Transform3D:
	var at: = building.position
	var outward: = Vector3.FORWARD
	if front is Dictionary:
		var shut: Transform3D = front["shut"]
		outward = - shut.basis.z
		if outward.dot(shut.origin - building.position) < 0.0:
			outward = - outward
		outward = (outward * Vector3(1, 0, 1)).normalized()
		at = shut.origin + outward * 6.0 + shut.basis.x * 3.0

	var hit: = Game.world.raycast(at + Vector3(0, 1.0, 0), at + Vector3(0, -14.0, 0), World.LAYER_SOLID)
	var ground: Vector3 = hit["position"] if not hit.is_empty() else CallKit.ground_at(at)
	return Figure.standing(ground, - outward)



func _build(held: Dictionary) -> void :
	var serial: int = held["serial"]
	var model: = CallKit.model("MedicalScene")
	held["model"] = model
	var figure: = Figure.build(int(held["seed"]))
	figure.name = "Neighbour"
	model.add_child(figure)
	figure.pose("stand")
	figure.global_transform = held["neighbour"]
	held["neighbour_prompt"] = CallKit.prompt(figure, "medical.%d.neighbour" % serial, Text.m("calls.medical.neighbour.action"), Text.m("calls.medical.neighbour.object"), 0.5, 9.0)
	held["neighbour_prompt"].enabled = not held["asked"]
	var aid: = Node3D.new()
	aid.name = "Aid"
	model.add_child(aid)
	aid.global_position = (held["aid_at"] as Vector3) + Vector3(0, 0.6, 0)
	held["aid_prompt"] = CallKit.prompt(aid, "medical.%d.aid" % serial, Text.m("calls.medical.aid.action"), Text.m("calls.medical.aid.object"), float(settings()["AidHold"]), 8.0)
	held["aid_prompt"].enabled = not held["aided"]


func _unbuild(held: Dictionary) -> void :
	if held.has("model") and is_instance_valid(held["model"]):
		held["model"].queue_free()





static func _mark(at: Vector3) -> CallMarker:
	return CallMarker.make(at, Text.m("calls.markers.medical"), Color8(200, 50, 60))



func start(buildings: Array) -> void :
	for building: Building in buildings:
		if building is House and building.has_rooms():
			_houses.append(building)
	CallGear.ensure(get_parent())
	Net.share("call.medical", _net_state, _net_apply, 4.0)
	Net.stopped.connect( func() -> void : _net_apply({}, true))







func _process(_delta: float) -> void :
	if not Net.is_client() or _shown.is_empty() or VictimService.current == null:
		return
	var aided: bool = _shown["aided"]
	for victim: Victim in VictimService.current._mirror.values():
		if victim.state == "lying" and is_instance_valid(victim.prompt) and victim.prompt.enabled != aided:
			victim.prompt.enabled = aided


func _net_state() -> Variant:
	if scene.is_empty():
		return {}
	return {
		"serial": scene["serial"], "urgency": scene["urgency"], "aid_at": scene["aid_at"], "neighbour": scene["neighbour"], 
		"seed": scene["seed"], "asked": scene["asked"], "has_key": false, "aided": scene["aided"], 
	}



func _net_apply(state: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not state is Dictionary:
		return
	if state.is_empty() or ( not _shown.is_empty() and _shown["serial"] != state["serial"]):
		_unbuild(_shown)
		_shown = {}
	if state.is_empty():
		return
	if _shown.is_empty():
		_shown = (state as Dictionary).duplicate()
		_build(_shown)
	_shown["asked"] = state["asked"]
	_shown["aided"] = state["aided"]
