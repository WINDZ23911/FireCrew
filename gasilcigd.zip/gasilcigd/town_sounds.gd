class_name TownSounds
extends Node








var _birds: AudioStreamPlayer
var _crickets: AudioStreamPlayer
var _hum: AudioStreamPlayer
var _chorus: AudioStreamPlayer
var _wind: AudioStreamPlayer
var _rain_bus: = -1
var _roofed: = false
var _next_roof: = 0.0
var _last_hour: = 0
var _since: = 0.5


func _ready() -> void :
	var settings: Dictionary = Config.Ambience
	_birds = _loop(settings["BirdsSoundId"])
	_crickets = _loop(settings["CricketsSoundId"])
	_hum = _loop(settings["HumSoundId"])
	_set_volume(_hum, float(settings["HumVolume"]))
	_chorus = _loop(settings["BirdsSoundId"])
	_chorus.pitch_scale = 1.13
	_wind = _loop("wind")
	_rain_bus = _make_rain_bus()
	_last_hour = floori(_hour())
	_mix()


func _loop(asset: Variant) -> AudioStreamPlayer:
	var player: = AudioStreamPlayer.new()
	player.stream = Sounds.loop(asset)
	player.volume_db = -80.0
	add_child(player)
	if player.stream:
		player.play()
	return player


func _set_volume(player: AudioStreamPlayer, volume: float) -> void :
	player.volume_db = linear_to_db(maxf(volume, 0.0001))


func _hour() -> float:
	return Sky3D.current.hour if Sky3D.current else float(Config.Day.Start)


func _mix() -> void :
	var hour: = _hour()
	var day: = Sky3D.daylight_at(hour)
	var dawn: = clampf(1.0 - absf(hour - (float(Config.Day.Dawn) + 0.8)) / 1.6, 0.0, 1.0)
	var midday: = clampf(1.0 - absf(hour - 13.5) / 2.5, 0.0, 1.0)
	var rain: = Weather.current.rain if Weather.current else 0.0
	var quiet: = 1.0 - 0.6 * rain
	if Style.winter():
		quiet = 0.0
	_set_volume(_birds, float(Config.Ambience.BirdsVolume) * day * (0.8 + 0.9 * dawn) * (1.0 - 0.4 * midday) * quiet)
	_set_volume(_chorus, float(Config.Ambience.BirdsVolume) * dawn * 0.9 * quiet)
	_set_volume(_crickets, float(Config.Ambience.CricketsVolume) * (1.0 - day) * (1.0 - 0.8 * rain) * (0.0 if Style.winter() else 1.0))



func _blow() -> void :
	var t: = HostClock.now()
	var gust: = 0.5 + 0.3 * sin(t * 0.21) + 0.2 * sin(t * 0.53 + 1.3) + 0.15 * sin(t * 1.27 + 0.4)
	gust = clampf(gust, 0.0, 1.2)
	var open: = 0.0
	var camera: = get_viewport().get_camera_3d()
	if camera:
		var at: = camera.global_position
		open = clampf((Vector2(at.x - 100.0, at.z - 100.0).length() - 550.0) / 500.0, 0.0, 1.0) * 0.6 + clampf(at.y / 80.0, 0.0, 1.0) * 0.4
	var rain: = Weather.current.rain if Weather.current else 0.0
	_set_volume(_wind, (0.05 + 0.1 * open + 0.09 * gust) * (1.0 + 1.6 * rain))
	_wind.pitch_scale = 0.9 + 0.15 * gust




func _make_rain_bus() -> int:
	var index: = AudioServer.get_bus_index("Rain")
	if index < 0:
		index = AudioServer.bus_count
		AudioServer.lock()
		AudioServer.add_bus(index)
		AudioServer.unlock()
		AudioServer.set_bus_name(index, "Rain")

		Settings.effects_bus()
		AudioServer.set_bus_send(index, Settings.EFFECTS_BUS)
		var filter: = AudioEffectLowPassFilter.new()
		filter.cutoff_hz = 700.0
		AudioServer.add_bus_effect(index, filter)
		AudioServer.set_bus_effect_enabled(index, 0, false)
	return index


func _under_roof() -> void :
	if Game.now() < _next_roof or _rain_bus < 0:
		return
	_next_roof = Game.now() + 0.4
	var weather: = Weather.current
	if weather == null:
		return
	for child in weather.get_children():
		if child is AudioStreamPlayer and child.bus != "Rain":
			child.bus = "Rain"
	var camera: = get_viewport().get_camera_3d()
	if camera == null or Game.world == null:
		return
	var at: = camera.global_position
	var roofed: = not Game.world.raycast(at + Vector3(0, 0.5, 0), at + Vector3(0, 80, 0), World.LAYER_SOLID).is_empty()
	if roofed != _roofed:
		_roofed = roofed
		AudioServer.set_bus_effect_enabled(_rain_bus, 0, roofed)
		AudioServer.set_bus_volume_db(_rain_bus, -5.0 if roofed else 0.0)




func _ring() -> void :
	for strike in int(Config.Ambience.BellStrikes):
		if OldTown.bell_at == Vector3.ZERO:
			Sounds.flat(Config.Ambience.BellSoundId, float(Config.Ambience.BellVolume))
		else:
			Sounds.once_at(OldTown.bell_at, Config.Ambience.BellSoundId, float(Config.Ambience.BellVolume), 600.0, 5000.0)
		await get_tree().create_timer(float(Config.Ambience.BellGap), false).timeout


func _process(delta: float) -> void :
	_blow()
	_under_roof()
	_since += delta
	if _since < 0.5:
		return
	_since = 0.0
	_mix()
	var hour: = floori(_hour())
	if hour != _last_hour:
		_last_hour = hour
		for bell_hour: float in Config.Ambience.BellHours:
			if int(bell_hour) == hour:
				_ring()
