extends RefCounted



static func start(main: Node) -> void :
	var flocks: = Flocks.new()
	flocks.name = "Flocks"
	main.add_child(flocks)
