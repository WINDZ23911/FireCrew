class_name OldTown
extends Node3D






static var lit: Array = []
static var bell_at: = Vector3.ZERO

const LAMPS: = Color(1.0, 0.86, 0.66)
const BRIGHT: = 0.82

var _faces: Array[MeshInstance3D] = []


func _ready() -> void :
	for info: Dictionary in lit:
		var box: = BoxMesh.new()
		box.size = info["size"]
		var look: = StandardMaterial3D.new()
		look.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		var wall: Color = info["color"]
		look.albedo_color = Color(wall.r * LAMPS.r, wall.g * LAMPS.g, wall.b * LAMPS.b) * BRIGHT
		var face: = MeshInstance3D.new()
		face.name = "Floodlit"
		face.mesh = box
		face.material_override = look
		face.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(face)
		face.global_transform = Transform3D(info["basis"], info["at"])
		_faces.append(face)
	Game.night_changed.connect( func(_night: bool) -> void : _show())
	_show()


func _show() -> void :
	for face in _faces:
		face.visible = Game.night
