extends RefCounted



static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--firebench"):
			var bench: = FireBench.new()
			bench.name = "FireBench"
			main.add_child(bench)
			return
