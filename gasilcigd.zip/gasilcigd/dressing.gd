class_name Dressing
extends Node3D














const OFF_SURFACE: = 0.03
const FONT_SIZE: = 64
const MAX_TEXT_PIXELS: = 100.0
const LABELS_SEEN_TO: = 420.0
const EMITTERS_RUN_TO: = 260.0
const CHECK_EVERY: = 0.5

static var current: Dressing

var decal_of: Dictionary = {}
var _decal_rows: Dictionary = {}
static var _fonts: Dictionary = {}


var labels: Array[Dictionary] = []
var _by_part: Dictionary = {}
var _emitters: Array[RbxEmitter] = []
var _lit_pictures: Array[StandardMaterial3D] = []
var _since: = 0.0


static func label_on(part_id: int) -> Label3D:
	var found: = labels_on(part_id)
	return found[0] if not found.is_empty() else null


static func labels_on(part_id: int) -> Array[Label3D]:
	var found: Array[Label3D] = []
	if current:
		for entry: Dictionary in current._by_part.get(part_id, []):
			found.append(entry["label"])
	return found



static func set_text(part_id: int, message: Variant, index: = 0) -> void :
	if current == null:
		return
	var entries: Array = current._by_part.get(part_id, [])
	if index < entries.size():
		entries[index]["message"] = message
		current._fit(entries[index])


static func set_text_color(part_id: int, color: Color, index: = 0) -> void :
	if current == null:
		return
	var entries: Array = current._by_part.get(part_id, [])
	if index < entries.size():
		entries[index]["label"].modulate = color


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var store: = Game.store
	var decals: Dictionary = {}
	for id: int in store.nodes:
		var node: Dictionary = store.nodes[id]
		match node["c"]:
			"Decal":
				_add_decal(node, decals)
			"SurfaceGui":
				_add_gui(node)
			"ParticleEmitter":
				_add_emitter(node)
	for texture: Texture2D in decals:
		_draw_decals(texture, decals[texture])
	Text.language_changed.connect(_say_again)
	Game.night_changed.connect(_show_night)
	_show_night(Game.night)
	_check()



func move_decal(row: int, place: Transform3D) -> void :
	var decal: Variant = decal_of.get(row)
	if decal != null:
		(decal[0] as MultiMesh).set_instance_transform(decal[1], place)


func reset_decal(row: int) -> void :
	var decal: Variant = decal_of.get(row)
	if decal != null:
		(decal[0] as MultiMesh).set_instance_transform(decal[1], decal[2])







static func face_frame(row: int, face: String) -> Array:
	var store: = Game.store
	var size: = store.size(row)
	var right: = Vector3.LEFT
	var up: = Vector3.UP
	var extent: = Vector2(size.x, size.y)
	var depth: = size.z
	match face.get_slice(".", 1):
		"Back":
			right = Vector3.RIGHT
		"Right":
			right = Vector3.FORWARD
			extent = Vector2(size.z, size.y)
			depth = size.x
		"Left":
			right = Vector3.BACK
			extent = Vector2(size.z, size.y)
			depth = size.x
		"Top":
			right = Vector3.RIGHT
			up = Vector3.FORWARD
			extent = Vector2(size.x, size.z)
			depth = size.y
		"Bottom":
			right = Vector3.RIGHT
			up = Vector3.BACK
			extent = Vector2(size.x, size.z)
			depth = size.y
	var out: = right.cross(up)
	var local: = Transform3D(Basis(right, up, out), out * (depth / 2.0 + OFF_SURFACE))
	return [local, extent]





func _add_decal(node: Dictionary, into: Dictionary) -> void :
	var store: = Game.store
	var row: int = store.row_of.get(node["p"], -1)
	var texture: = Assets.texture(node["v"].get("Texture", ""))
	if row < 0 or texture == null:
		return
	var frame: = face_frame(row, str(node["v"].get("Face", "NormalId.Front")))
	var local: Transform3D = frame[0]
	var extent: Vector2 = frame[1]
	if not into.has(texture):
		into[texture] = []
		_decal_rows[texture] = []
	into[texture].append(store.transform(row) * local * Transform3D(Basis.from_scale(Vector3(extent.x, extent.y, 1.0)), Vector3.ZERO))
	_decal_rows[texture].append(row)


func _draw_decals(texture: Texture2D, places: Array) -> void :
	var material: = StandardMaterial3D.new()
	material.albedo_texture = texture
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	material.alpha_scissor_threshold = 0.5
	material.alpha_antialiasing_mode = BaseMaterial3D.ALPHA_ANTIALIASING_ALPHA_TO_COVERAGE
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	material.roughness = 0.7
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED

	material.emission_enabled = true
	material.emission_texture = texture
	material.emission_energy_multiplier = 0.05
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE
	quad.material = material
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = quad
	multimesh.instance_count = places.size()
	var rows: Array = _decal_rows.get(texture, [])
	for index in places.size():
		multimesh.set_instance_transform(index, places[index])
		if index < rows.size():
			decal_of[rows[index]] = [multimesh, index, places[index]]
	var instance: = MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)






static func font_for(roblox_font: String) -> Font:
	var key: = roblox_font.get_slice(".", 1)
	if _fonts.has(key):
		return _fonts[key]
	var font: = SystemFont.new()
	match key:
		"Code":
			font.font_names = PackedStringArray(["Menlo", "DejaVu Sans Mono", "Consolas", "Courier New", "monospace"])
			font.font_weight = 500
		"GothamMedium":
			font.font_names = PackedStringArray(["Montserrat", "Avenir Next", "Helvetica Neue", "Arial", "sans-serif"])
			font.font_weight = 500
		_:
			font.font_names = PackedStringArray(["Montserrat", "Avenir Next", "Helvetica Neue", "Arial", "sans-serif"])
			font.font_weight = 700
	font.generate_mipmaps = true
	font.multichannel_signed_distance_field = false
	_fonts[key] = font
	return font


func _add_gui(gui: Dictionary) -> void :
	var store: = Game.store
	var part: int = gui["p"]
	var row: int = store.row_of.get(part, -1)
	if row < 0:
		return
	var values: Dictionary = gui["v"]
	var frame: = face_frame(row, str(values.get("Face", "NormalId.Front")))
	var local: Transform3D = frame[0]
	var extent: Vector2 = frame[1]
	var holder: = Node3D.new()
	holder.name = "Gui%d" % part
	_hang(holder, part, row, local)
	var per_stud: = float(values.get("PixelsPerStud", 50.0))

	var glows: bool = values.has("Brightness")
	var shaded: bool = float(values.get("LightInfluence", 1.0)) > 0.5
	for child in store.nodes_under.get(gui["i"], PackedInt32Array()):
		var node: Dictionary = store.nodes[child]
		var area: = _area(node["v"], extent)
		if node["c"] == "TextLabel":
			_add_text(holder, part, node, area, per_stud, glows, shaded)
		elif node["c"] == "ImageLabel":
			_add_image(holder, node, area, shaded, glows)




func _hang(holder: Node3D, part: int, row: int, local: Transform3D) -> void :
	var store: = Game.store
	var moving: = _moving_part(store.name_at(row))
	if moving:
		moving.add_child(holder)
		holder.transform = local
	else:
		add_child(holder)
		holder.global_transform = store.transform(row) * local


func _moving_part(part_name: String) -> Node3D:
	if not part_name.begins_with("BayDoor") or Game.station == null:
		return null
	var bits: = part_name.substr(7).split("_")
	if bits.size() != 2:
		return null
	var bay: = int(bits[0]) - 1
	if bay < 0 or bay >= Game.station.doors.size():
		return null
	return Game.station.doors[bay]["panels"].get(int(bits[1]))




func _area(values: Dictionary, extent: Vector2) -> Array:
	var size: = Vector2(1, 1)
	var corner: = Vector2.ZERO
	if values.has("Size"):
		size = Vector2(values["Size"]["X"]["Scale"], values["Size"]["Y"]["Scale"])
	if values.has("Position"):
		corner = Vector2(values["Position"]["X"]["Scale"], values["Position"]["Y"]["Scale"])
	var studs: = size * extent
	if str(values.get("SizeConstraint", "")).ends_with("RelativeYY"):
		studs = size * extent.y
	var left_top: = Vector2( - extent.x / 2.0 + corner.x * extent.x, extent.y / 2.0 - corner.y * extent.y)
	return [left_top + Vector2(studs.x, - studs.y) / 2.0, studs]


func _add_text(holder: Node3D, part: int, node: Dictionary, area: Array, per_stud: float, glows: bool, shaded: bool) -> void :
	var values: Dictionary = node["v"]
	var label: = Label3D.new()
	label.font = font_for(str(values.get("Font", "Font.GothamBold")))
	label.font_size = FONT_SIZE
	label.outline_size = 0
	label.modulate = values.get("TextColor3", Color.WHITE)
	label.shaded = shaded
	label.double_sided = false
	label.alpha_cut = Label3D.ALPHA_CUT_DISABLED
	label.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	label.visible = values.get("Visible", true)
	label.visibility_range_end = LABELS_SEEN_TO
	label.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	holder.add_child(label)
	var message: Variant = values.get("Text", "")
	var attributes: Variant = node.get("a")
	if attributes is Dictionary and attributes.has("Text_Text"):
		message = Text.decode(attributes["Text_Text"])

	var row: int = Game.store.row_of[part]
	var model: Dictionary = Game.store.nodes.get(Game.store.parent(row), {})
	message = TownSigns.exported(message, String(model.get("n", "")), Game.store.name_at(row))
	var entry: = {
		"label": label, "part": part, "message": message, "middle": area[0], "size": area[1], 
		"left": str(values.get("TextXAlignment", "")).ends_with("Left"), 
		"top": str(values.get("TextYAlignment", "")).ends_with("Top"), 
		"limit": MAX_TEXT_PIXELS / per_stud / FONT_SIZE, "glow": glows, "shaded": shaded, 
	}
	labels.append(entry)
	if not _by_part.has(part):
		_by_part[part] = []
	_by_part[part].append(entry)
	_fit(entry)




func _fit(entry: Dictionary) -> void :
	var label: Label3D = entry["label"]
	var text: = Text.say(entry["message"])
	var size: Vector2 = entry["size"]
	var best: = text
	var best_scale: = 0.0
	var best_extent: = Vector2.ONE
	for lines in [1, 2, 3, 4]:
		var broken: = _broken(text, lines)
		if broken.is_empty():
			break
		var extent: = label.font.get_multiline_string_size(broken, HORIZONTAL_ALIGNMENT_CENTER, -1, FONT_SIZE)
		if extent.x <= 0.0 or extent.y <= 0.0:
			break
		var scale_here: = minf(minf(size.x / extent.x, size.y / extent.y), entry["limit"])
		if scale_here > best_scale * 1.02:
			best = broken
			best_scale = scale_here
			best_extent = extent
		if text.contains("\n"):
			break
	label.text = best
	label.pixel_size = maxf(best_scale, 0.0001)
	var middle: Vector2 = entry["middle"]
	if entry["left"]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		middle.x += (best_extent.x * best_scale - size.x) / 2.0
	if entry["top"]:
		middle.y -= (best_extent.y * best_scale - size.y) / 2.0
	label.position = Vector3(middle.x, middle.y, 0.0)



func _broken(text: String, lines: int) -> String:
	if lines == 1 or text.contains("\n"):
		return text
	var words: = text.split(" ", false)
	if words.size() < lines:
		return ""
	var target: = float(text.length()) / lines
	var out: = ""
	var line: = ""
	var left: = lines
	for index in words.size():
		var word: = words[index]
		var words_left: = words.size() - index

		if not line.is_empty() and left > 1 and (line.length() + word.length() / 2.0 >= target or words_left < left):
			out += line + "\n"
			line = ""
			left -= 1
		line += ("" if line.is_empty() else " ") + word
	return out + line


func _add_image(holder: Node3D, node: Dictionary, area: Array, shaded: bool, glows: bool) -> void :
	var texture: = Assets.texture(node["v"].get("Image", ""))
	if texture == null:
		return

	var size: Vector2 = area[1]
	var shape: = float(texture.get_width()) / maxf(texture.get_height(), 1.0)
	var fitted: = Vector2(minf(size.x, size.y * shape), minf(size.y, size.x / shape))
	var material: = StandardMaterial3D.new()
	material.albedo_texture = texture
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	material.alpha_antialiasing_mode = BaseMaterial3D.ALPHA_ANTIALIASING_ALPHA_TO_COVERAGE
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL if shaded else BaseMaterial3D.SHADING_MODE_UNSHADED
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	if glows and shaded:
		_lit_pictures.append(material)
	var quad: = QuadMesh.new()
	quad.size = fitted
	quad.material = material
	var picture: = MeshInstance3D.new()
	picture.mesh = quad
	picture.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	picture.visibility_range_end = LABELS_SEEN_TO
	holder.add_child(picture)
	var middle: Vector2 = area[0]
	picture.position = Vector3(middle.x, middle.y, 0.0)


func _say_again(_code: = "") -> void :
	for entry in labels:
		if entry["message"] is Dictionary:
			_fit(entry)



func _show_night(night: bool) -> void :
	for entry in labels:
		if entry["glow"]:
			entry["label"].shaded = entry["shaded"] and not night
	for material in _lit_pictures:
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED if night else BaseMaterial3D.SHADING_MODE_PER_PIXEL





func _add_emitter(node: Dictionary) -> void :
	var store: = Game.store
	var values: Dictionary = node["v"]
	var place: = Transform3D.IDENTITY
	var size: = Vector3.ZERO
	var parent: int = node["p"]
	if store.nodes.has(parent) and store.nodes[parent]["c"] == "Attachment":

		var attachment: Dictionary = store.nodes[parent]
		place = attachment["v"].get("CFrame", Transform3D.IDENTITY)
		parent = attachment["p"]
		if not store.row_of.has(parent):
			return
		place = store.transform(store.row_of[parent]) * place
	elif store.row_of.has(parent):
		place = store.transform(store.row_of[parent])
		size = store.size(store.row_of[parent])
	else:
		return
	var props: = {
		"Texture": values.get("Texture", ""), 
		"Rate": values.get("Rate", 20.0), 
		"Lifetime": values.get("Lifetime", Vector2(5, 10)), 
		"Speed": values.get("Speed", Vector2(5, 5)), 
		"SpreadAngle": values.get("SpreadAngle", Vector2.ZERO), 
		"Acceleration": values.get("Acceleration", Vector3.ZERO), 
		"Drag": values.get("Drag", 0.0), 
		"Rotation": values.get("Rotation", Vector2.ZERO), 
		"RotSpeed": values.get("RotSpeed", Vector2.ZERO), 
		"Size": _sequence(values.get("Size"), 1.0), 
		"Transparency": _sequence(values.get("Transparency"), 0.0), 
		"Color": _colors(values.get("Color")), 
		"LightEmission": values.get("LightEmission", 0.0), 
		"LightInfluence": values.get("LightInfluence", 1.0), 
		"Enabled": values.get("Enabled", true), 
		"Direction": TownLights.face_normal(str(values.get("EmissionDirection", "NormalId.Top"))), 
	}
	if values.has("FlipbookLayout"):
		props["Flipbook"] = true
		props["FlipbookFramerate"] = values.get("FlipbookFramerate", Vector2(16, 16))
	if size != Vector3.ZERO:

		if str(values.get("Shape", "")).ends_with("Sphere"):
			props["Sphere"] = minf(size.x, minf(size.y, size.z)) / 2.0
		else:
			props["Box"] = size
	var holder: = Node3D.new()
	add_child(holder)
	holder.global_transform = place
	var emitter: = RbxEmitter.make(holder, props)
	emitter.visible = false
	_emitters.append(emitter)



func _sequence(value: Variant, default: float) -> Variant:
	if value is Dictionary and value.has("Keypoints"):
		var keys: = []
		for key: Dictionary in value["Keypoints"]:
			keys.append([float(key["Time"]), float(key["Value"])])
		return keys
	if value == null:
		return default
	return value



func _colors(value: Variant) -> Variant:
	if value is Dictionary and value.has("Keypoints"):
		var keys: Array = value["Keypoints"]
		return [keys[0]["Value"], keys[keys.size() - 1]["Value"]]
	if value == null:
		return Color.WHITE
	return value


func _process(delta: float) -> void :
	_since += delta
	if _since >= CHECK_EVERY:
		_since = 0.0
		_check()



func _check() -> void :
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var eye: = camera.global_position
	for emitter in _emitters:
		emitter.visible = emitter.global_position.distance_squared_to(eye) < EMITTERS_RUN_TO * EMITTERS_RUN_TO
