class_name JobCutOpen
extends CrewJob





const PREP_WAIT: = 20.0

var door_only: Variant = null


func _init(door: Variant = null) -> void :
	kind = "cutOpen"
	role = "rescue"
	door_only = door


func place() -> Vector3:
	return CarCrash.current.position


func _next(crash: CarCrash) -> Dictionary:
	if door_only is Dictionary:
		return door_only if door_only["stage"] <= CarCrash.JOBS.size() else {}
	var best: Dictionary = {}
	var best_distance: = INF
	for door: Dictionary in crash.scene.get("doors", []):
		if door["stage"] > CarCrash.JOBS.size():
			continue
		if door.get("crew_taken") != null and door["crew_taken"] != who and is_instance_valid(door["crew_taken"]):
			continue
		var distance: float = door["position"].distance_to(who.body.global_position)
		if distance < best_distance:
			best_distance = distance
			best = door
	return best


func run() -> bool:
	var crash: = CarCrash.current
	if crash == null or crash.scene.is_empty():
		return fail("crew.say.nothingThere")
	var held: = who.token()
	var worked: = 0
	while on(held):
		var door: = _next(crash)
		if door.is_empty():
			return worked > 0 or door_only == null
		door["crew_taken"] = who
		var blocked: Callable = door["blocked"]
		if blocked.is_valid() and blocked.call() != null:
			door["crew_taken"] = null
			return fail("crew.say.blocked")
		var stage: int = door["stage"]

		if stage <= CarCrash.HYDRAULIC and not await _make_ready(door["car"], held):
			door["crew_taken"] = null
			return false if reason.is_empty() else fail(reason, reason_args)
		var job: Dictionary = CarCrash.JOBS[stage - 1]
		var where: Vector3 = door["position"]
		var out: Vector3 = door["car"]["place"].basis.x * door["outward"]
		var finished: = false
		if stage <= CarCrash.HYDRAULIC:
			if await CrewKit.take_tool(who, [job["tool"]], who.service.home_vehicle(who.commander())) == "":
				door["crew_taken"] = null
				return fail("crew.say.noTool", [Text.named("tools", job["tool"])])
			if not await who.go(who.service.ground(where + out * 3.0 + Vector3(0, 2, 0)), 1.2, 40.0):
				door["crew_taken"] = null
				return fail("crew.say.stuck")
			finished = await CrewKit.work_until(who, func() -> bool: return door["stage"] != stage, 25.0, where)
		else:

			if not await _kit(job["tool"]):
				door["crew_taken"] = null
				return fail("crew.say.noTool", [Text.named("tools", job["tool"])])
			if not await who.go(who.service.ground(where + out * 3.0 + Vector3(0, 2, 0)), 1.2, 40.0):
				door["crew_taken"] = null
				return fail("crew.say.stuck")
			finished = await CrewKit.press_skilled(who, door["prompt"]) and door["stage"] != stage
		door["crew_taken"] = null
		if not finished:
			return fail("crew.say.cannot")
		worked += 1
	return false




func _make_ready(car: Dictionary, held: int) -> bool:
	var started: = Game.now()
	while on(held):
		var unready: = CarCrash.unready(car)
		if not unready[0] and not unready[1]:
			return true
		var other: Variant = car.get("crew_prep")
		if other != null and other != who and is_instance_valid(other) and other.alive(other.token()) and other.job != null and other.job.kind == kind:

			if Game.now() - started > PREP_WAIT:
				reason = "crew.say.cannot"
				return false
			await who.wait(0.5, held)
			continue
		car["crew_prep"] = who
		if unready[0] and not await _kit("Step blocks"):
			car["crew_prep"] = null
			reason = "crew.say.noTool"
			reason_args = [Text.named("tools", "Step blocks")]
			return false
		var prompt: Prompt = car["prompt"]
		var behind: Vector3 = (car["place"] as Transform3D).basis.z
		if not await who.go(who.service.ground(prompt.global_position + behind * 2.6 + Vector3(0, 2, 0)), 1.2, 40.0):
			car["crew_prep"] = null
			reason = "crew.say.stuck"
			return false
		var before: Array = unready
		var pressed: = await CrewKit.press_skilled(who, prompt)
		car["crew_prep"] = null
		if not pressed or CarCrash.unready(car) == before:
			reason = "crew.say.cannot"
			return false
	return false



func _kit(kit_name: String) -> bool:
	var cordon: = Cordon.current
	if cordon == null:
		return false
	if cordon.carries(who.body, kit_name):
		return true
	var item: = await CrewKit.take_cordon(who, kit_name, who.service.home_vehicle(who.commander()))
	return not item.is_empty()


func finish(_done: bool) -> void :
	ToolService.current.deactivate(who.body)
	CrewKit.free_hands(who)

	var cordon: = Cordon.current
	if cordon:
		for item: Dictionary in cordon.items:
			if item["holder"] == who.body and item["name"] in ["Step blocks", "First aid kit", "Spinal board"]:
				cordon.put_back(item)
