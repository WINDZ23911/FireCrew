class_name PassingEngine
extends RefCounted





var loop: AudioStreamPlayer3D
var pitch: = 0.58
var loudness: = 1.0
var switch_off: = -1.0
var stood: = 0.0




static func make(parent: Node3D, engine: String, reach: float, how_loud: float, switch_off_after: = -1.0) -> PassingEngine:
	var stream: = Sounds.loop(engine + "_low")
	if stream == null:
		return null
	var note: = PassingEngine.new()
	note.loop = Sounds.emitter(parent, stream, 0.0, 15.0, reach)
	note.loudness = how_loud
	note.switch_off = switch_off_after
	return note


func update(speed: float, dt: float) -> void :
	if not is_instance_valid(loop):
		return
	speed = absf(speed)
	var pace: = speed / 11.0
	var gear: = minf(2.0, floorf(pace))
	var revs: = minf(pace - gear, 1.3)
	var wanted: = 0.58 + 0.6 * revs if gear == 0.0 else 0.78 + 0.4 * revs
	pitch += (wanted - pitch) * minf(1.0, dt * 4.0)
	loop.pitch_scale = pitch
	var volume: float = Config.Truck.EngineVolume * loudness * (0.5 + 0.5 * minf(1.0, speed / 8.0))
	loop.volume_db = linear_to_db(maxf(volume, 0.0001))
	stood = stood + dt if speed < 0.3 else 0.0
	var on: = not (switch_off >= 0.0 and stood > switch_off)
	if on and not loop.playing:
		loop.play()
	elif not on and loop.playing:
		loop.stop()


func stop() -> void :
	if is_instance_valid(loop):
		loop.queue_free()
	loop = null
