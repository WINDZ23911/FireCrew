class_name CrewAiDebug
extends ProofDebug






func _ready() -> void :
	super ()
	await get_tree().process_frame
	if CrewService.current:
		CrewService.current.spoke_line.connect( func(mind: Crewman, line: Variant, kind: String) -> void :
			print("crew: %s (%s): %s" % [mind.display_name(), kind, Text.say(line, "en")])
		)


var _stuck_shots: = 0



func _watch_stuck() -> void :
	if not OS.get_cmdline_user_args().has("--stuck-shots"):
		return
	for mind in _crew():
		var who: = mind
		mind.stuck.connect( func(at: Vector3, to: Vector3) -> void :
			if _stuck_shots >= 4:
				return
			_stuck_shots += 1
			var number: = _stuck_shots
			var way: = (to - at) * Vector3(1, 0, 1)
			way = way.normalized() if way.length() > 0.1 else Vector3(0, 0, 1)
			_view(at - way * 9.0 + way.cross(Vector3.UP) * 5.0 + Vector3(0, 7, 0), at + Vector3(0, 2, 0))
			print("stuck shot %d: %s at %s to %s" % [number, who.display_name(), at, to])
			await _snap("stuck%d" % number)
		)



func _crew_aboard(limit: float) -> void :
	var waited: = 0.0
	while waited < limit and not _crew().all( func(m: Crewman) -> bool: return m.body.seat != null):
		await _wait(0.5)
		waited += 0.5


func _crew() -> Array[Crewman]:
	return CrewService.current.members


func _where() -> String:
	var parts: Array = []
	for mind in _crew():
		var from: = mind.body.global_position.distance_to(player.global_position)
		parts.append("%s %.0f away%s%s at %s wish %s path %d->%s" % [mind.display_name(), from, " seated" if mind.body.seat != null else "", (" job " + mind.job.kind) if mind.job != null else "", mind.body.global_position.snapped(Vector3.ONE * 0.1), mind.wish.snapped(Vector3.ONE * 0.01), mind._path.size(), mind._path[0].snapped(Vector3.ONE) if not mind._path.is_empty() else "-"])
	return ", ".join(parts)



func _walk(yaw: float, seconds: float) -> void :
	player.camera.yaw = yaw
	player.rig.rotation.y = yaw
	var along: = Basis(Vector3.UP, yaw) * Vector3(0, 0, -1)
	var steps: = int(seconds / 0.1)
	for step in steps:
		player.teleport(_ground(player.global_position + along * 1.8 + Vector3(0, 1, 0)) + Vector3(0, 0.1, 0))
		player.rig.rotation.y = yaw
		await _wait(0.1)



func _over() -> void :
	var back: = Basis(Vector3.UP, player.rig.global_rotation.y) * Vector3(0, 0, 1)
	_view(player.global_position + back * 26.0 + Vector3(0, 22, 0), player.global_position + Vector3(0, 2, 0) - back * 4.0)





func _crewai_follow() -> void :
	await _wait(1.5)
	print("follow: start: commander at %s: %s" % [player.global_position, _where()])
	_over()
	await _snap("start")
	await _walk(PI, 4.0)
	await _wait(1.0)
	print("follow: after 4 s walking out of the station: %s" % _where())
	_over()
	await _snap("walked")
	await _walk(PI * 0.5, 5.0)
	await _wait(1.5)
	print("follow: after turning and 5 s more: %s" % _where())
	_over()
	await _snap("turned")

	player.teleport(_ground(player.global_position + Vector3(-120, 0, -40)) + Vector3(0, 0.3, 0))
	await _wait(8.0)
	print("follow: 8 s after the commander jumped 125 studs: %s" % _where())
	_check(_crew().all( func(m: Crewman) -> bool: return m.body.global_position.distance_to(player.global_position) < 30.0), "the crew catches up with the commander")
	_over()
	await _snap("caught_up")
	await _done()





func _crewai_ride() -> void :
	await _wait(1.5)
	var pumper: = Vehicle.named("Fire Truck")
	var door: Dictionary = pumper.doors["DoorCabLeft"]
	player.teleport(_ground(pumper.global_transform * (door["doorway"] + Vector3(-3, 0, 0))) + Vector3(0, 0.3, 0))
	await _wait(2.5)
	print("ride: by the cab: %s" % _where())
	pumper.set_door("DoorCabLeft", true)
	await _wait(0.6)
	pumper._board(player, "DoorCabLeft")
	await _wait(1.0)
	_view(pumper.global_position + Vector3(25, 18, 30), pumper.global_position)
	await _snap("boarding")
	await _wait(5.0)

	await _crew_aboard(25.0)
	print("ride: 6 s after the commander sat at the wheel: %s; riders %s" % [_where(), pumper.riders.map( func(r: Variant) -> String: return r.display_name if r != null else "-")])
	_check(_crew().all( func(m: Crewman) -> bool: return m.body.seat != null), "the crew gets in with the commander")

	await _hold("move_forward", 5.0)
	await _wait(2.0)
	print("ride: after driving: truck at %s, %s" % [pumper.global_position, _where()])
	pumper.driver_key(player, "exit")
	await _wait(3.0)
	print("ride: 3 s after the commander got out: %s" % _where())
	_check(_crew().all( func(m: Crewman) -> bool: return m.body.seat == null), "the crew gets out with the commander")
	_over()
	await _snap("out")
	await _done()





func _crewai_nav() -> void :
	await _wait(3.0)
	var nav: = CrewNav.current
	var map: = nav.get_world_3d().navigation_map
	var a: = player.global_position
	var points: = [a, a + Vector3(0, 0, 20), a + Vector3(-30, 0, 10), a + Vector3(-120, 0, -40), a + Vector3(40, 0, 40)]
	for p: Vector3 in points:
		nav.ensure(p)
	await _wait(3.0)
	print("nav: map regions %d, iteration %d" % [NavigationServer3D.map_get_regions(map).size(), NavigationServer3D.map_get_iteration_id(map)])
	for p: Vector3 in points:
		var c: = NavigationServer3D.map_get_closest_point(map, p)
		var way: = NavigationServer3D.map_get_path(map, a, p, true)
		print("nav: %s ready %s closest %s; raw way %d points ending %s; nav.path %d" % [p.snapped(Vector3.ONE), nav.ready_at(p), c.snapped(Vector3.ONE * 0.1), way.size(), way[way.size() - 1].snapped(Vector3.ONE) if not way.is_empty() else "-", nav.path(a, p).size()])
	_view(a + Vector3(0, 120, 30), a)
	var debug: = MeshInstance3D.new()
	var im: = ImmediateMesh.new()
	debug.mesh = im
	im.surface_begin(Mesh.PRIMITIVE_LINES)
	for region in nav.get_children():
		var mesh: NavigationMesh = region.navigation_mesh
		var verts: = mesh.get_vertices()
		for index in mesh.get_polygon_count():
			var poly: = mesh.get_polygon(index)
			for k in poly.size():
				im.surface_add_vertex(verts[poly[k]] + Vector3(0, 0.3, 0))
				im.surface_add_vertex(verts[poly[(k + 1) % poly.size()]] + Vector3(0, 0.3, 0))
	im.surface_end()
	var material: = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1, 0, 1)
	material.no_depth_test = true
	debug.material_override = material
	add_child(debug)
	await _snap("mesh")
	_view(a + Vector3(10, 40, 40), a)
	await _snap("mesh_near")
	await _done()






func _point_at(point: Vector3) -> void :
	await _aim_view(point)
	await _wait(0.3)


func _orders() -> HudCrewOrders:
	return Hud.current.widgets.get("crew_orders")


func _crewai_orders() -> void :
	await _wait(1.5)
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -30))
	player.teleport(_ground(pumper.global_position + Vector3(20, 0, 10)) + Vector3(0, 0.3, 0))
	await _wait(3.0)

	var spot: = _ground(player.global_position + Vector3(25, 0, 25))
	await _point_at(spot)
	print("orders: looking at ground: %s" % _orders()._target.get("kind"))
	await _tap("crew_order")
	await _wait(0.5)
	print("orders: after tap: %s" % _where())
	await _wait(5.0)
	print("orders: 5 s on: %s" % _where())

	await _point_at(pumper.global_position + Vector3(0, 4, 0))
	print("orders: looking at the truck: %s, first %s" % [_orders()._target.get("kind"), Text.say(_orders()._target["options"][0]["text"], "en") if not _orders()._target.is_empty() else "-"])
	await _snap("hint")
	await get_tree().process_frame
	Input.action_press("crew_order")
	await _wait(0.5)
	print("orders: wheel open %s with %s" % [_orders()._open, _orders()._options.map( func(o: Dictionary) -> String: return Text.say(o["text"], "en"))])

	var wanted: = "Everyone, get in"
	var options: = _orders()._options
	_check(options.any( func(o: Dictionary) -> bool: return Text.say(o["text"], "en") == wanted), "the truck's wheel offers \"%s\"" % wanted)
	for step in options.size():
		if Text.say(_orders()._options[_orders()._chosen]["text"], "en") == wanted:
			break
		var scroll: = InputEventMouseButton.new()
		scroll.button_index = MOUSE_BUTTON_WHEEL_DOWN
		scroll.pressed = true
		Input.parse_input_event(scroll)
		await _wait(0.1)
	print("orders: chosen %s" % Text.say(_orders()._options[_orders()._chosen]["text"], "en"))
	_check(Text.say(_orders()._options[_orders()._chosen]["text"], "en") == wanted, "\"%s\" is under selection" % wanted)
	await _wait(0.2)
	await _snap("wheel")
	Input.action_release("crew_order")
	await _wait(0.3)
	print("orders: given; %s" % _where())

	var waited: = 0.0
	while waited < 25.0 and not _crew().all( func(m: Crewman) -> bool: return m.body.seat != null):
		await _wait(1.0)
		waited += 1.0
	print("orders: %.0f s on: %s; riders %s" % [waited, _where(), pumper.riders.map( func(r: Variant) -> String: return r.display_name if r != null else "-")])
	_check(_crew().all( func(m: Crewman) -> bool: return m.body.seat != null), "\"Everyone, get in\" from the wheel puts the crew in the truck")
	_view(pumper.global_position + Vector3(30, 20, 30), pumper.global_position)
	await _snap("in")

	await _point_at(player.head_position() + Vector3(0, 200, 0))
	await _tap("crew_order")
	await _wait(0.2)
	print("orders: sky wheel open %s with %s" % [_orders()._open, _orders()._options.map( func(o: Dictionary) -> String: return Text.say(o["text"], "en"))])
	_view_player()
	await _snap("sky")
	var click: = InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	click.pressed = true
	Input.parse_input_event(click)
	waited = 0.0
	while waited < 20.0 and not _crew().all( func(m: Crewman) -> bool: return m.body.seat == null and m.body.global_position.distance_to(player.global_position) < 30.0):
		await _wait(1.0)
		waited += 1.0
	print("orders: after follow me: %s" % _where())
	_check(_crew().all( func(m: Crewman) -> bool: return m.body.seat == null and m.body.global_position.distance_to(player.global_position) < 30.0), "\"Everyone, follow me\" brings the crew out to the commander")
	await _done()


func _crewai_list() -> void :
	await _wait(1.0)
	for building in FireService.current.buildings:
		if building is House:
			print("house: %s at %s, %d rooms" % [building.name, building.position, building.rooms.size()])
	for item: Dictionary in ToolService.current.items:
		print("tool: %s on %s (%s)" % [item["name"], item["vehicle"].spec["name"], item["prop"]["locker"]])
	for item: Dictionary in Cordon.current.items:
		print("cordon: %s on %s" % [item["name"], item["truck"].spec["name"]])
	for vehicle in Vehicle.all:
		var lockers: = Lockers.of(vehicle)
		print("vehicle: %s seats %d doors %s handles %d" % [vehicle.spec["name"], vehicle.seats.size(), vehicle.doors.keys(), lockers.handles.size() if lockers else 0])
	await _done()







func _arrive(at: Vector3, back: = 45.0) -> Vehicle:
	var pumper: = Vehicle.named("Fire Truck")
	var place: = _open_ground(at, back)
	_park(pumper, place[0], place[1])
	await _wait(0.2)

	var behind: Vector3 = pumper.global_transform * Vector3(0, 0, 18)
	player.teleport(CrewService.current.ground(behind + Vector3(0, 3, 0)) + Vector3(0, 0.3, 0))
	for mind in _crew():
		mind.body.teleport(CrewService.current.ground(behind + pumper.global_basis.x * (mind.slot * 3.0 - 3.0) + pumper.global_basis.z * 3.0 + Vector3(0, 3, 0)) + Vector3(0, 0.3, 0))
	CrewNav.current.ensure(at, 0.8)
	await _wait(2.0)
	return pumper



func _open_ground(at: Vector3, back: float) -> Array:
	var graph: = NavGraph.current
	var space: = get_viewport().world_3d.direct_space_state
	var box: = BoxShape3D.new()
	box.size = Vector3(11, 6, 32)
	var best: Array = []
	var best_score: = INF
	for segment: Dictionary in graph.segments:
		if segment["kind"] != "lane":
			continue
		var length: float = segment["length"]
		var along: = 0.0
		while along <= length:
			var s: = NavGraph.sample(segment, along)
			along += 8.0
			var spot: = Vector3(s.x, at.y, s.y)
			var distance: = Vector2(spot.x - at.x, spot.z - at.z).length()
			if distance < back * 0.6 or distance > back * 2.0:
				continue
			var ground: = CrewService.current.ground(spot + Vector3(0, 6, 0))
			var yaw: = atan2( - s.z, - s.w)
			var query: = PhysicsShapeQueryParameters3D.new()
			query.shape = box
			query.transform = Transform3D(Basis(Vector3.UP, yaw), ground + Vector3(0, 4.5, 0))
			query.collision_mask = World.LAYER_SOLID
			if not space.intersect_shape(query, 1).is_empty():
				continue
			var score: = absf(distance - back)
			if score < best_score:
				best_score = score
				best = [ground, yaw]
	return best if not best.is_empty() else [at + Vector3(back, 0, 0), 0.0]



func _watch(seconds: float, every: float, stage: String, done: Callable = Callable()) -> void :
	var waited: = 0.0
	while waited < seconds:
		await _wait(every)
		waited += every
		var jobs: = _crew().map( func(m: Crewman) -> String: return "%s:%s" % [m.display_name(), m.job.kind if m.job != null else "-"])
		print("%s: %.0f s, %s, card %s/%s, jobs %s" % [stage, waited, Game.incident.get("kind", "none"), Game.incident.get("done"), Game.incident.get("total"), jobs])
		if done.is_valid() and done.call():
			return


func _crewai_tree() -> void :
	await _wait(1.0)
	Config.Incidents["Tree"]["Variant"] = "plain"
	var tree: = FallenTree.current
	tree.run()
	var waited: = 0.0
	while tree.scene.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	if not _check( not tree.scene.is_empty(), "a tree came down"):
		await _done()
		return
	var at: = tree.position_of_call
	print("tree: %d rings, %d pieces at %s" % [tree.scene["rings"].size(), tree.scene["pieces"].size(), at])
	await _arrive(at)
	var service: = CrewService.current
	print("tree: cut -> %s" % service.order(JobCutTree.new()).display_name())
	print("tree: cones -> %s" % service.order(JobCones.new(at)).display_name())
	_view(at + Vector3(30, 25, 30), at)
	await _watch(20.0, 5.0, "tree")
	await _snap("cutting")
	service.order(JobDrag.new(), service.members[0])
	service.order(JobDrag.new(), service.members[1])
	service.order(JobDrag.new(), service.members[2], true)
	await _watch(80.0, 5.0, "tree", func() -> bool: return Game.incident.is_empty() or Game.incident.get("kind") != "tree")
	_view(at + Vector3(30, 25, 30), at)
	await _snap("cleared")
	print("tree: commander's cash %s" % player.get_attr("Cash"))
	_check(Game.incident.is_empty() or Game.incident.get("kind") != "tree", "the crew clears the tree on orders")
	await _done()


func _crewai_crash() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 1.0)
	if not _check( not held.is_empty(), "a crash came"):
		await _done()
		return
	var crash: = CarCrash.current
	var at: = crash.position
	print("crash: %d doors at %s, engine %s" % [held["doors"].size(), at, held["engine"] != null])
	await _arrive(at)
	var service: = CrewService.current
	var engine: Variant = held["engine"]
	if engine is Dictionary:
		print("crash: battery -> %s" % service.order(JobPress.new("battery", engine["prompt"], "rescue")).display_name())
	print("crash: cut -> %s" % service.order(JobCutOpen.new()).display_name())
	print("crash: cones -> %s" % service.order(JobCones.new(at), null, false).display_name())
	_view(at + Vector3(25, 20, 25), at)
	await _watch(40.0, 5.0, "crash")
	await _snap("working")


	for step in 40:
		for person in JobCarry.free_victims():
			if not person.has_meta("crew_taken"):
				var mind: = service.choose(JobCarry.new(person))
				if mind != null and mind.job == null:
					service.order(JobCarry.new(person), mind)
		await _watch(5.0, 5.0, "crash")
		if Game.incident.is_empty() or Game.incident.get("kind") != "crash":
			break
	_view(at + Vector3(25, 20, 25), at)
	await _snap("end")
	print("crash: guarded %s; commander's cash %s" % [crash._guarded(at, CrewKit.road_at(at)[1]) if not CrewKit.road_at(at).is_empty() else "?", player.get_attr("Cash")])
	_check(Game.incident.is_empty() or Game.incident.get("kind") != "crash", "the crew works the crash to its end on orders")
	var ready: = true
	for made: Dictionary in held["wrecks"]:
		ready = ready and (int(made["car"]["prep"]) < 0 or (made["car"]["stable"] and made["car"]["glass"] and not made["car"].get("shaken", false)))
	var boarded: = true
	for door: Dictionary in held["doors"]:
		boarded = boarded and int(door["stage"]) > CarCrash.JOBS.size()
	print("crash: wrecks made ready first %s; everyone boarded %s; report %s" % [ready, boarded, Alarm.checks])
	_check(ready, "the crew stabilised each wreck and took its glass out before the tools went in")
	_check(boarded, "the crew gave first aid and boarded every casualty")
	await _done()


func _crewai_kit() -> void :
	await _wait(1.0)
	var house: House = null
	for building in FireService.current.buildings:
		if building is House and building.name == "Family":
			house = building
	if house == null:
		for building in FireService.current.buildings:
			if building is House:
				house = building
				break
	house.lock_up(true)
	var door: Dictionary = {}
	for door_name: String in house.doors:
		if house.doors[door_name]["outside"] and house.doors[door_name]["locked"]:
			door = house.doors[door_name]
			break
	var at: Vector3 = door["prompt"].global_position
	print("kit: %s, door %s locked %s at %s" % [house.name, door["name"], door["locked"], at])
	var tanker: = Vehicle.named("Tanker")
	await _arrive(at, 40.0)
	_park(tanker, Vehicle.named("Fire Truck").global_position + Vector3(0, 0, 0) - Vehicle.named("Fire Truck").global_basis.z * -24.0, Vehicle.named("Fire Truck").global_rotation.y)
	var service: = CrewService.current
	print("kit: force -> %s" % service.order(JobForceDoor.new(house, door)).display_name())
	var outward: = (player.global_position - at) * Vector3(1, 0, 1)
	print("kit: light -> %s" % service.order(JobStandTool.new("Floodlight", at + outward.normalized() * 14.0, at)).display_name())
	await _watch(30.0, 5.0, "kit", func() -> bool: return not door["locked"] and service.members.all( func(m: Crewman) -> bool: return m.job == null))
	print("kit: door locked %s open %s" % [door["locked"], door["open"]])
	print("kit: fan -> %s" % service.order(JobStandTool.new("Fan", at + outward.normalized() * 6.0, at)).display_name())
	await _watch(40.0, 5.0, "kit", func() -> bool: return service.members.all( func(m: Crewman) -> bool: return m.job == null))
	var standing: = ToolService.current.items.filter( func(i: Dictionary) -> bool: return i["standing"]).map( func(i: Dictionary) -> String: return "%s at %s" % [i["name"], i["tool"].global_position.snapped(Vector3.ONE)])
	print("kit: standing %s" % [standing])
	_check( not door["locked"], "the crew forces the locked door")
	_check(standing.size() >= 2, "the crew stands the floodlight and the fan")
	_view(at + outward.normalized() * 25.0 + Vector3(0, 15, 0), at)
	await _snap("set")
	await _done()





func _crewai_fire() -> void :
	await _wait(1.0)
	_watch_stuck()
	var fire: = FireService.current
	var wanted: = "Family"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
	var building: Building = null
	for other in fire.buildings:
		if other.name == wanted:
			building = other
	if building == null:
		for other in fire.buildings:
			if other is House:
				building = other
				break
	var kept: Array = building.scenarios
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--trait="):
			Config.Fire["Traits"]["Force"] = arg.substr(8)
		if arg.begins_with("--room="):
			building.scenarios = kept.filter( func(scenario: Dictionary) -> bool: return scenario.get("room") == arg.substr(7))

	CallService.current.run_call("fire", func() -> bool:
		await fire.run_incident(building)
		return true)
	building.scenarios = kept
	await _wait(0.5)
	var pumper: = await _arrive(building.approach if building.approach != null else building.position, 30.0)
	print("fire: %s, %d flames, trait %s; pumper %.0f L, hydrant for it: %s" % [building.name, int(fire.incident["count"]), fire.incident.get("trait"), pumper.water, not CrewWater.hydrant_for(pumper).is_empty()])
	var service: = CrewService.current
	var members: = service.members
	if OS.get_cmdline_user_args().has("--auto"):
		service.all_work()
	else:
		await _fire_orders(service, pumper, fire)
	var middle: = building.position
	_view(middle + Vector3(40, 30, 40), middle)
	var waited: = 0.0
	var on_line: Dictionary = {}
	while waited < 300.0 and not fire.incident.is_empty():
		for tick in 20:
			await _wait(0.5)
			for m in members:
				if HoseService.current.line_of(m.body) != null:
					on_line[m.display_name()] = true
		waited += 10.0
		var jobs: = members.map( func(m: Crewman) -> String: return "%s:%s(%.0fhp%s)" % [m.display_name(), m.job.kind if m.job != null else "-", m.body.health, " air%.0f" % AirService.current.pressure(m.body) if AirService.current.sets.has(m.body) else ""])
		print("fire: %.0f s, %s flames, out %s, health %.0f, tank %.0f, supply %s, jobs %s" % [waited, fire.incident.get("count"), fire.incident.get("out"), float(fire.incident.get("health", 0.0)), pumper.water, HoseService.current.supplied_by(pumper), jobs])
		print("fire:   left %s; crew at %s" % [CrewWater.targets().map( func(t: Dictionary) -> String: return "%s %s" % [t["position"].snapped(Vector3.ONE), t["room"]]), members.map( func(m: Crewman) -> String: return "%s %s cur %s" % [m.display_name(), m.body.global_position.snapped(Vector3.ONE), m.job.current["position"].snapped(Vector3.ONE) if m.job is JobAttack and not m.job.current.is_empty() else "-"])])
		if waited == 30.0:
			await _snap("fighting")
	_view(middle + Vector3(40, 30, 40), middle)
	await _snap("after")
	print("fire: over: incident %s; cash %s" % [fire.incident.is_empty(), player.get_attr("Cash")])
	_check( not on_line.is_empty(), "a member takes a line (held a line: %s)" % on_line.keys())
	if not OS.get_cmdline_user_args().has("--auto"):
		_check(on_line.size() >= mini(2, _ordered_attack), "every member ordered onto a line gets one (%d ordered, %d held one)" % [_ordered_attack, on_line.size()])
	_check(fire.incident.is_empty(), "the fire is put out")
	await _done()


var _ordered_attack: = 0


func _fire_orders(service: CrewService, pumper: Vehicle, fire: FireService) -> void :
	var pump_operator: = service.order(JobSupply.new(pumper))
	print("fire: supply -> %s" % pump_operator.display_name())
	print("fire: attack -> %s" % service.order(JobAttack.new()).display_name())
	_ordered_attack = 1
	var second: = service.choose(JobAttack.new())
	if second != null and second.job == null:
		service.order(JobAttack.new(), second)
		_ordered_attack = 2


	var control: Variant = fire.incident.get("control")
	if is_instance_valid(control):
		var prompt: Prompt = control.get_meta("prompt")
		var job: = JobPress.new("valve" if fire.incident.get("fed") != null else "switch", prompt, "rescue")
		print("fire: %s -> %s, after the supply" % [job.kind, service.order(job, pump_operator, true).display_name()])





func _crewai_drive() -> void :
	await _wait(2.0)
	var tanker: = Vehicle.named("Tanker")
	var service: = CrewService.current

	var graph: = NavGraph.current
	var goal: = Vector3.ZERO
	for segment: Dictionary in graph.segments:
		if segment["kind"] == "lane":
			var s: = NavGraph.sample(segment, 0.0)
			var at: = Vector3(s.x, 0, s.y)
			if at.distance_to(tanker.global_position) > 320.0 and at.distance_to(tanker.global_position) < 380.0:
				goal = _ground(at + Vector3(0, 10, 0))
				break
	print("drive: tanker at %s, to %s (%.0f studs)" % [tanker.global_position, goal, goal.distance_to(tanker.global_position)])
	var mind: = service.members[0]
	service.order(JobDrive.new(tanker, "here", goal), mind)
	var waited: = 0.0
	while waited < 120.0 and mind.job != null:
		await _wait(5.0)
		waited += 5.0
		var job: Variant = mind.job
		print("drive: %.0f s, tanker at %s, speed %.1f, %.0f from goal, driver %s, path %s/%s" % [waited, tanker.global_position.snapped(Vector3.ONE), tanker.forward_speed, tanker.global_position.distance_to(goal), tanker.driver().display_name if tanker.driver() else "-", job._along if job is JobDrive else "-", job._path.size() if job is JobDrive else "-"])
		if waited == 20.0:
			_view(tanker.global_position + Vector3(30, 25, 30), tanker.global_position)
			await _snap("driving")
	_view(tanker.global_position + Vector3(30, 25, 30), tanker.global_position)
	await _snap("arrived")
	print("drive: done, %.0f from goal, driver out %s" % [tanker.global_position.distance_to(goal), tanker.driver() == null])
	_check(tanker.global_position.distance_to(goal) < 40.0, "the crew member drives the tanker across town")
	await _done()




func _crewai_takefollow() -> void :
	await _wait(2.0)
	var tanker: = Vehicle.named("Tanker")
	var pumper: = Vehicle.named("Fire Truck")
	var service: = CrewService.current
	CrewDrive.take_and_follow(service, tanker)
	await _wait(12.0)
	print("takefollow: tanker driver %s, riders %s; crew %s" % [tanker.driver().display_name if tanker.driver() else "-", tanker.riders.map( func(r: Variant) -> String: return r.display_name if r else "-"), service.members.map( func(m: Crewman) -> String: return "%s %s" % [m.display_name(), m.job.kind if m.job else m.mode])])


	var graph: = NavGraph.current
	var goal: = Vector3.ZERO
	for segment: Dictionary in graph.segments:
		if segment["kind"] == "lane":
			var sample: = NavGraph.sample(segment, 0.0)
			var at: = Vector3(sample.x, 0, sample.y)
			if at.distance_to(pumper.global_position) > 300.0 and at.distance_to(pumper.global_position) < 360.0:
				goal = _ground(at + Vector3(0, 10, 0))
				break
	pumper._board(player, "DoorCabRight")
	await _wait(0.5)
	service.order(JobDrive.new(pumper, "here", goal), service.members[2])
	for step in 14:
		await _wait(5.0)
		print("takefollow: %d s, pumper at %s, tanker at %s (%.0f behind), speed %.1f, driver %s" % [(step + 1) * 5, pumper.global_position.snapped(Vector3.ONE), tanker.global_position.snapped(Vector3.ONE), tanker.global_position.distance_to(pumper.global_position), tanker.forward_speed, tanker.driver().display_name if tanker.driver() else "-"])
	_check(tanker.global_position.distance_to(pumper.global_position) < 90.0, "the tanker comes after the pumper")
	_view(pumper.global_position + Vector3(25, 30, 25), (pumper.global_position + tanker.global_position) / 2.0)
	await _snap("convoy")
	await _done()


func _crewai_nozzle() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var wanted: = "Family"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
	var building: Building = null
	for other in fire.buildings:
		if other.name == wanted:
			building = other
	if building == null:
		for other in fire.buildings:
			if other is House and not other.ruined:
				building = other
				break
	if not _check(building != null, "a building to set alight (%s)" % wanted):
		await _done()
		return


	var force: = "none"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--trait="):
			force = arg.substr(8)
	var forced: Variant = Config.Fire["Traits"].get("Force")
	Config.Fire["Traits"]["Force"] = force
	fire.run_incident(building)
	await _wait(0.5)
	Config.Fire["Traits"]["Force"] = forced
	if not _check( not fire.incident.is_empty(), "a fire starts at %s" % building.name):
		await _done()
		return
	var pumper: = await _arrive(building.approach if building.approach != null else building.position, 30.0)
	var service: = CrewService.current
	var hydrant: = CrewWater.hydrant_for(pumper)
	print("nozzle: %s trait %s, flames %s; hydrant %s, intake %s" % [building.name, fire.incident.get("trait"), CrewWater.targets().map( func(t: Dictionary) -> Vector3: return t["position"].snapped(Vector3.ONE)), hydrant.get("position"), pumper.intake["node"].global_position if not pumper.intake.is_empty() else null])
	var supplier: = service.members[0]
	service.order(JobSupply.new(pumper), supplier)
	var mind: = service.members[1]
	service.order(JobAttack.new(), mind)
	var held_line: = false
	for index in 60:
		await _wait(2.0)
		var job: Variant = mind.job
		var line: Variant = HoseService.current.line_of(mind.body)
		held_line = held_line or line != null
		print("nozzle: %d: at %s target %s spot %s trigger %s spraying %s aim %s hose %.0f; flames %s out %s; supplier %s at %s supply %s" % [
			index * 2, mind.body.global_position.snapped(Vector3.ONE * 0.5), 
			job.current["position"].snapped(Vector3.ONE) if job is JobAttack and not job.current.is_empty() else "-", 
			"-", mind.body.get_attr("Trigger"), line["spraying"] if line != null else "-", 
			(mind.body.get_attr("Aim") as Vector3).snapped(Vector3.ONE) if mind.body.get_attr("Aim") is Vector3 else "-", 
			float(mind.body.get_attr("HoseLength", 0.0)), fire.incident.get("count"), fire.incident.get("out"), 
			supplier.job.kind if supplier.job else "-", supplier.body.global_position.snapped(Vector3.ONE), CrewWater.rig_of(pumper)["supply"]["state"]])
		if index % 5 == 2:
			print("nozzle: path %s wish %s on_mesh %s look %s" % [mind._path.map( func(p: Vector3) -> Vector3: return p.snapped(Vector3.ONE)), mind.wish.snapped(Vector3.ONE * 0.01), mind._on_mesh, mind.look])
		if index == 6:
			var at: = mind.body.global_position
			_view(at + Vector3(-12, 9, 6), at)
			await _snap("stuck")
			var probe: = Game.world.raycast(at + Vector3(0, 2.2, 0), at + Vector3(0, 2.2, -4), World.LAYER_SOLID | World.LAYER_VEHICLE, [mind.body.get_rid()])
			print("nozzle: ahead of Jure: %s %s" % [probe.get("collider"), probe.get("position")])
			var probe2: = Game.world.raycast(at + Vector3(0, 0.5, 0), at + Vector3(0, 0.5, -4), World.LAYER_SOLID | World.LAYER_VEHICLE, [mind.body.get_rid()])
			print("nozzle: low ahead of Jure: %s %s %s" % [probe2.get("collider"), probe2.get("position"), Game.world.name_hit(probe2)])
		if fire.incident.is_empty() or int(fire.incident.get("count", 0)) == 0:
			break


		if mind.job == null and mind.queue.is_empty():
			var door: Dictionary = mind.blocked_by
			if not door.is_empty() and door.get("locked", false):
				mind.blocked_by = {}
				for house in fire.buildings:
					if house is House and door in house.doors.values():
						print("nozzle: %s ordered to force the door" % mind.display_name())
						service.order(JobForceDoor.new(house, door), mind)
						break
			print("nozzle: %s ordered onto the line again" % mind.display_name())
			service.order(JobAttack.new(), mind, true)
	_check(held_line, "the member ordered onto the nozzle takes a line")
	_check(fire.incident.is_empty() or int(fire.incident.get("count", 0)) == 0, "the fire is put out (flames %s)" % fire.incident.get("count", 0))
	await _done()


func _crewai_navtruck() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var building: Building = null
	for other in fire.buildings:
		if other.name == "Bungalow":
			building = other
	var pumper: = await _arrive(building.position, 30.0)
	await _wait(3.0)
	var nav: = CrewNav.current
	var centre: = pumper.global_position
	print("navtruck: speed %.3f velocity %s still_since %s regions %d" % [pumper.forward_speed, pumper.linear_velocity, nav._still_since.get(pumper), nav._regions.size()])
	print("navtruck: truck at %s; closest to its middle %s (%.1f off); parked %s" % [centre, nav.closest(centre), Vector3(nav.closest(centre).x - centre.x, 0, nav.closest(centre).z - centre.z).length(), nav._parked.get(pumper)])
	for side: float in [-1.0, 1.0]:
		var at: = centre + pumper.global_basis.x * side * 5.5
		print("navtruck: side %s at %s: closest %s" % [side, at, nav.closest(at)])
	_view(centre + Vector3(0, 60, 10), centre)
	var debug: = MeshInstance3D.new()
	var im: = ImmediateMesh.new()
	debug.mesh = im
	im.surface_begin(Mesh.PRIMITIVE_LINES)
	for region in nav.get_children():
		var mesh: NavigationMesh = region.navigation_mesh
		var verts: = mesh.get_vertices()
		for index in mesh.get_polygon_count():
			var poly: = mesh.get_polygon(index)
			for k in poly.size():
				im.surface_add_vertex(verts[poly[k]] + Vector3(0, 0.3, 0))
				im.surface_add_vertex(verts[poly[(k + 1) % poly.size()]] + Vector3(0, 0.3, 0))
	im.surface_end()
	var material: = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1, 0, 1)
	material.no_depth_test = true
	debug.material_override = material
	add_child(debug)
	await _snap("mesh")
	await _done()





func _crewai_turnout() -> void :
	await _wait(1.5)
	_watch_stuck()
	var fire: = FireService.current
	var wanted: = "Family house"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			wanted = arg.substr(11)
	var building: Building = null
	for other in fire.buildings:
		if other.name == wanted and (building == null or other.position.distance_to(player.global_position) < building.position.distance_to(player.global_position)):
			building = other
	var pumper: = Vehicle.named("Fire Truck")

	player.teleport(_ground(pumper.global_transform * (pumper.doors["DoorCabLeft"]["doorway"] + Vector3(-3, 0, 0))) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	pumper._board(player, "DoorCabLeft")
	await _wait(6.0)
	await _crew_aboard(30.0)
	print("turnout: aboard: %s" % [pumper.riders.map( func(r: Variant) -> String: return r.display_name if r != null else "-")])
	fire.run_incident(building)
	await _wait(0.5)

	var place: = _open_ground(building.position, 35.0)
	_park(pumper, place[0], place[1])
	await _wait(1.5)
	pumper.driver_key(player, "exit")
	print("turnout: arrived at %s; the commander is out" % building.name)
	var waited: = 0.0
	var middle: = building.position
	_view(middle + Vector3(40, 30, 40), middle)
	while waited < 300.0 and not fire.incident.is_empty():
		await _wait(10.0)
		waited += 10.0
		var jobs: = _crew().map( func(m: Crewman) -> String: return "%s:%s/%s" % [m.display_name(), m.mode, m.job.kind if m.job != null else "-"])
		print("turnout: %.0f s, %s flames, out %s, health %.0f, rescued %s, jobs %s" % [waited, fire.incident.get("count"), fire.incident.get("out"), float(fire.incident.get("health", 0.0)), Game.incident.get("victims_out"), jobs])
		if waited == 20.0:
			await _snap("working")
	await _wait(5.0)
	print("turnout: over %s; after the call: %s" % [fire.incident.is_empty(), _crew().map( func(m: Crewman) -> String: return "%s:%s" % [m.display_name(), m.mode])])
	_check(fire.incident.is_empty(), "the crew puts the fire out on Auto")
	_view(middle + Vector3(40, 30, 40), middle)
	await _snap("after")
	await _done()





func _crewai_board() -> void :
	await _wait(2.0)
	var board: = CrewBoard.current
	player.set_attr("Cash", 5000)
	board.open()
	await _wait(0.5)
	await _snap("open")
	var had: = CrewService.current.roster.members.size()
	var level: = int(CrewService.current.roster.members[0]["level"])
	board._hire()
	await _wait(0.5)
	await _snap("candidates")
	board._hire_candidate(0)
	await _wait(0.5)
	board._train(CrewService.current.roster.members[0])
	await _wait(0.5)
	print("board: crew %s; cash %s" % [CrewService.current.roster.members.map( func(m: Dictionary) -> String: return "%s %s L%d" % [m["name"], m["role"], m["level"]]), player.get_attr("Cash")])
	await _snap("after")
	board.close()
	await _wait(0.3)

	var at: Vector3 = board._board.global_position
	var out: Vector3 = board._board.get_meta("out", Vector3.FORWARD)
	_view(at + out * 12.0 + Vector3(0, 1, 0), at)
	await _snap("wall")
	print("board: members now %d, bodies %d" % [CrewService.current.roster.members.size(), CrewService.current.members.size()])
	_check(CrewService.current.roster.members.size() == had + 1 and CrewService.current.members.size() == had + 1, "the board hires a member")
	_check(int(CrewService.current.roster.members[0]["level"]) == level + 1, "the board trains a member")
	await _done()


func _crewai_coop() -> void :
	await _wait(3.0)
	print("coop: net active %s, crew bodies %d, players %d, panel shown %s" % [Net.active(), CrewService.current.members.size(), Game.players.size(), Hud.current.widgets["crew_panel"].visible])
	Net.leave()
	await _wait(2.0)
	print("coop: after leaving: net active %s, crew bodies %d" % [Net.active(), CrewService.current.members.size()])
	await _done()






func _suits() -> String:
	var gear: = GearService.current
	var people: Array = [player]
	for mind in _crew():
		people.append(mind.body)
	return ", ".join(people.map( func(one: Player) -> String:
		var state: Dictionary = gear.worn.get(one, {})
		return "%s: suit %s, helmet %s" % [one.display_name, state.get("suit"), state.get("helmet")]))





func _crewai_suit() -> void :
	await _wait(1.5)
	var gear: = GearService.current
	var suit_id: = "gold"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--suit="):
			suit_id = arg.substr(7)
	player.set_attr("Cash", 5000)

	player.set_attr("Saved", 30)
	print("suit: before: %s" % _suits())
	var stall: Dictionary = gear.stalls[0]

	player.teleport(stall["position"] + Vector3(5, -4.2, 0))
	player.camera.yaw = - PI / 2
	await _wait(0.5)
	gear._change_back(player)
	gear._choosing[player] = stall
	gear.choose_suit(player, suit_id)
	await _wait(4.0)
	print("suit: after choosing %s: %s" % [suit_id, _suits()])
	_check(gear.worn.get(player, {}).get("suit") == suit_id, "the commander wears the bought suit")
	_check(_crew().all( func(m: Crewman) -> bool: return gear.worn.get(m.body, {}).get("suit") == null), "the crew keep the station's suit")
	await _snap_crew("crew", stall)
	if CrewService.current.hire(player):
		await _wait(4.0)
		print("suit: hired: %s" % _suits())
		await _snap_crew("hired", stall)
	await _done()



func _snap_crew(stage: String, stall: Dictionary) -> void :
	var middle: Vector3 = player.global_position
	for mind in _crew():
		middle += mind.body.global_position
	middle /= _crew().size() + 1
	var back: Node3D = stall["back"]
	_view(back.global_transform * Vector3(0, 1.5, 3.6), middle + Vector3(0, 2.0, 0), 75.0)
	await _snap(stage)






func _out_of_trucks() -> String:
	var left: = CrewPack.left_out().map( func(piece: Dictionary) -> String: return "%s at %s" % [piece["kind"], piece["at"].snapped(Vector3.ONE)])
	var carried: Array = []
	for mind in _crew():
		if CrewPack.carries_kit(mind):
			carried.append("%s: tools %s, set %s" % [mind.display_name(), ToolService.current.carried(mind.body).map( func(i: Dictionary) -> String: return i["name"]), AirService.current.sets.has(mind.body)])
	var pumper: = Vehicle.named("Fire Truck")
	var tools_out: = ToolService.current.items.filter( func(i: Dictionary) -> bool: return i["holder"] != null or i["standing"]).map( func(i: Dictionary) -> String: return "%s (%s)" % [i["name"], i["holder"].display_name if i["holder"] != null else "standing"])
	var shutters: = 0
	for vehicle in [pumper, Vehicle.named("Tanker")]:
		shutters += Lockers.of(vehicle).handles.filter( func(h: Dictionary) -> bool: return Lockers.of(vehicle).is_open(h)).size()
	return "left out %s; crew carry %s; tools off the trucks %s; cones on the pumper %d/%d; supply %s; divider %s; open shutters on the pumper and tanker %d" % [
		left, carried, tools_out, Cordon.current._cone_stock.get(pumper, 0), int(Config.Life.Cones), CrewWater.rig_of(pumper)["supply"]["state"], HoseService.current.divider["state"], shutters]






func _crewai_packup() -> void :
	await _wait(1.5)
	var fire: = FireService.current
	var house: Building = null
	for other in fire.buildings:
		if other is House and (house == null or other.name.begins_with("Family")):
			house = other
	var at: Vector3 = house.position
	var auto: = OS.get_cmdline_user_args().has("--packup-auto")
	if auto:


		Game.set_incident({"kind": "tree", "name": "Drill", "pos": at})
	var pumper: = await _arrive(at, 30.0)

	_park(Vehicle.named("Tanker"), pumper.global_position - pumper.global_basis.z * 26.0, pumper.global_rotation.y)
	CrewNav.current.ensure(at, 0.8)
	await _wait(1.0)
	var service: = CrewService.current
	var tools: = ToolService.current
	var hoses: = HoseService.current
	var cordon: = Cordon.current
	print("packup: at %s, crew of %d, hydrant for the pumper %s" % [house.name, service.members.size(), not CrewWater.hydrant_for(pumper).is_empty()])
	print("packup: before anything: %s" % _out_of_trucks())

	var behind: Vector3 = pumper.global_transform * Vector3(0, 0, 18)
	print("packup: supply -> %s" % service.order(JobSupply.new(pumper)).display_name())
	print("packup: cones -> %s" % service.order(JobCones.new(pumper.global_position)).display_name())
	print("packup: light -> %s" % service.order(JobStandTool.new("Floodlight", (behind + at) / 2.0, at)).display_name())

	var fan: = _take_tool("Fan")
	await _wait(0.3)
	_look_at(player.head_position() + (at - player.global_position) * Vector3(1, 0, 1))
	tools.activate(player)
	print("packup: fan standing %s" % fan.get("standing"))
	var side: = pumper.global_basis.x * 12.0
	cordon.stretch_between(pumper, _ground(behind + side), _ground(behind + side + pumper.global_basis.z * 14.0))
	if hoses.divider["vehicle"] != null:
		hoses._carry_divider(player)
		player.teleport(_ground(behind - side) + Vector3(0, 0.3, 0))
		await _wait(0.3)
		hoses._place_divider(player)
	print("packup: divider %s" % hoses.divider["state"])

	var saw: = CrewKit.find_tool("Chainsaw", pumper.global_position)
	if not saw.is_empty():
		tools._on_line(service.members[service.members.size() - 1].body, saw)
	AirService.current.take_set(service.members[0].body, "truck")
	player.teleport(_ground(behind + pumper.global_basis.z * 4.0) + Vector3(0, 0.3, 0))
	await _watch(60.0, 5.0, "packup", func() -> bool: return service.members.all( func(m: Crewman) -> bool: return m.job == null))
	if auto:
		for mind in service.members:
			mind.mode = "auto"
	print("packup: all out: %s" % _out_of_trucks())
	_view(behind + Vector3(0, 45, 0) + pumper.global_basis.z * 25.0, pumper.global_position)
	await _snap("out")
	if auto:
		print("packup: the call is over")
		Game.set_incident({})
	else:

		await _point_at(pumper.global_position + Vector3(0, 4, 0))
		var target: = _orders()._target
		print("packup: looking at %s, a tap would: %s" % [target.get("kind"), Text.say(target["options"][0]["text"], "en") if not target.is_empty() else "-"])
		_view_player()
		await _snap("hint")
		await _tap("crew_order")
	await _wait(1.0)
	print("packup: jobs %s" % [service.members.map( func(m: Crewman) -> String: return "%s:%s" % [m.display_name(), m.job.kind if m.job != null else "-"])])
	_view(behind + Vector3(0, 45, 0) + pumper.global_basis.z * 25.0, pumper.global_position)
	await _wait(2.0)
	await _snap("packing")
	var waited: = 0.0
	while waited < 240.0:
		await _wait(5.0)
		waited += 5.0
		print("packup: %.0f s, jobs %s" % [waited, service.members.map( func(m: Crewman) -> String: return "%s:%s%s" % [m.display_name(), m.job.kind if m.job != null else "-", " (%d)" % m.job.collected if m.job is JobPackUp else ""])])
		if service.members.all( func(m: Crewman) -> bool: return m.job == null):
			break
	print("packup: after: %s" % _out_of_trucks())
	_check(CrewPack.left_out().is_empty(), "the crew packs everything up")
	print("packup: crew %s" % [service.members.map( func(m: Crewman) -> String: return "%s %s %.0f from the pumper" % [m.display_name(), m.mode, m.body.global_position.distance_to(pumper.global_position)])])
	await _snap("after")
	await _done()
