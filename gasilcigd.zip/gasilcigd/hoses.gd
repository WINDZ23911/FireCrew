extends ProofDebug





func _scenario_ladder_settle() -> void :
	await _wait(1.0)
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var at: = _open_spot(Vector3(-12, 0, -30), Vector3(1, 0, 0), truck)
	_park(truck, at, PI / 2)
	player.teleport(_ground(truck.global_position + truck.global_basis.z * 14.0) + Vector3(0, 0.3, 0))
	var still: = 0.0
	while Vector2(truck.linear_velocity.x, truck.linear_velocity.z).length() > 0.3 and still < 8.0:
		await _wait(0.25)
		still += 0.25
	var told: Array = []
	Game.notified.connect( func(text: Variant, _kind: String, _to: Player) -> void : told.append(Text.say(text, "en")))
	var stop_first: = Text.say(Text.m("gear.ladder.stopFirst"), "en")



	await get_tree().physics_frame
	truck.drive.speed = 2.5
	await get_tree().physics_frame
	var speed: = Vector2(truck.linear_velocity.x, truck.linear_velocity.z).length()
	ladder.use_jacks(player)
	var saying: = Text.say(ladder._prompt.action, "en")
	var state_then: = ladder.state
	var trace: Array = []
	for frame in 40:
		await get_tree().physics_frame
		if frame % 4 == 0:
			trace.append("%.1f/%.1f" % [Vector2(truck.linear_velocity.x, truck.linear_velocity.z).length(), truck.linear_velocity.y])
	print("settle: speeds after %s" % [trace])
	print("settle: asked at %.1f studs a second: state %s, prompt '%s'" % [speed, state_then, saying])
	_check(speed > LadderService.STILL and saying == Text.say(Text.m("gear.ladder.settling"), "en") and state_then == "stowed", "a settling truck's prompt says \"Settling…\" (not refused)")
	_view(truck.global_position + Vector3(20, 12, 20), truck.global_position)
	await _snap("settling")
	var waited: = 0.0
	while ladder.state != "ready" and waited < float(Config.Ladder.SettleTime) + LadderService.JACK_TIME + 2.0:
		await _wait(0.25)
		waited += 0.25
	print("settle: after %.1f s: state %s, told %s" % [waited, ladder.state, told])
	_check(ladder.state == "ready" and not told.has(stop_first), "the stabilisers go down once it has settled")
	await _snap("ready")


	ladder.use_jacks(player)
	waited = 0.0
	while ladder.state != "stowed" and waited < LadderService.JACK_TIME + 2.0:
		await _wait(0.25)
		waited += 0.25
	_check(ladder.state == "stowed", "the stabilisers come up again")
	await _wait(0.5)
	told.clear()
	await get_tree().physics_frame
	truck.drive.speed = float(Config.Ladder.SettleSpeed) + 8.0
	await get_tree().physics_frame
	ladder.use_jacks(player)
	print("settle: asked while moving at %.1f: state %s, told %s" % [truck.linear_velocity.length(), ladder.state, told])
	_check(ladder.state == "stowed" and told.has(stop_first), "a truck that is moving is told to stop first")
	await _done()




func _scenario_cellar_plate() -> void :
	await _wait(1.0)
	var flood: = FloodedCellar.current
	var hoses: = HoseService.current
	var truck: = Vehicle.named("Fire Truck")
	flood.run()
	var waited: = 0.0
	while flood.source.is_empty() and waited < 5.0:
		await _wait(0.25)
		waited += 0.25
	if not _check( not flood.source.is_empty(), "a flooded cellar call starts"):
		await _done()
		return
	var source: Dictionary = flood.source
	var inlet: Node3D = source["node"]
	var out: = - inlet.global_basis.z
	var across: = out.cross(Vector3.UP)
	truck.global_transform = Transform3D(Basis.looking_at(across), CallKit.ground_at(inlet.global_position + out * 16.0) + Vector3(0, 3.0, 0))
	truck.linear_velocity = Vector3.ZERO
	await _wait(1.5)
	var rig: Dictionary = {}
	for one: Dictionary in hoses.rigs:
		if one["vehicle"] == truck:
			rig = one
	player.teleport(_ground(truck.intake["node"].global_position + out * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	_check( await _take_roll(truck, "supply"), "the supply roll taken from the pumper")
	hoses._on_intake(rig, player)
	await _wait(0.5)
	player.teleport(_ground(inlet.global_position + out * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	hoses._on_hydrant(source, player)
	await _wait(1.0)
	player.teleport(_ground(truck.global_position + out * 6.0) + Vector3(0, 0.3, 0))
	await _wait(0.5)
	var plate: HudWater = Hud.current.widgets.get("water")
	var shown: String = plate._supply.text
	print("cellar: supply %s, supplied by %s; the plate says '%s'" % [rig["supply"]["state"], hoses.supplied_by(truck), shown])
	_check(hoses.supplied_by(truck) == "cellar", "the pumper's supply is the cellar")
	_check(Text.say(Text.m("gear.truck.sources.cellar")).to_upper() in shown.to_upper() and not Text.say(Text.m("gear.truck.sources.hydrant")).to_upper() in shown.to_upper(), "the water plate says the cellar, not a hydrant")
	_view_player()
	await _snap("plate")
	await _done()





func _scenario_fan_locker() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(1.0)
	var inside: float = float(pumper.data["halfWidth"]) - 0.12
	var into_body: = pumper.body.global_transform.affine_inverse()
	for prop_name: String in ["Fan", "Divider"]:
		var reach: = - INF
		for mesh: Node in pumper.props[prop_name]["node"].find_children("*", "MeshInstance3D", true, false):
			var box: AABB = (into_body * (mesh as MeshInstance3D).global_transform) * (mesh as MeshInstance3D).get_aabb()
			reach = maxf(reach, absf(box.position.x) if box.position.x < 0.0 else box.end.x)
		print("fan_locker: %s reaches %.2f out from the middle; the shutter runs at %.2f" % [prop_name, reach, inside])
		_check(reach < inside, "the %s stays inside the shut shutter" % prop_name)
	_check(pumper.outlets.size() == 2 and pumper.outlets[0]["mesh"].mesh == ToolModels.of("Truck outlet")["body"], "the outlets are the detailed couplings")
	_check(pumper.intake["mesh"].mesh == ToolModels.of("Truck intake")["body"], "and so is the intake")
	var side: = pumper.global_transform * Vector3(15, 4, 12.2)
	_view(side, pumper.global_transform * Vector3(4, 2.5, 12.2), 50.0)
	await _wait(0.5)
	await _snap("shut")
	pumper.set_shutter("R3", true)
	await _wait(1.5)
	await _snap("open")
	_view(pumper.global_transform * Vector3(7.5, 0.5, 9.5), pumper.global_transform * Vector3(5.2, 0, 12.2), 40.0)
	await _wait(0.3)
	await _snap("outlet")
	_view(pumper.global_transform * Vector3(2.5, 0.8, 19.0), pumper.global_transform * Vector3(0, -0.7, 14.2), 40.0)
	await _wait(0.3)
	await _snap("intake")
	await _done()
