class_name CrewDrive
extends RefCounted




static func vehicle_orders(vehicle: Vehicle, lead: Player) -> Array:
	var options: Array = []
	if vehicle.seats.is_empty() or lead.get_attr("Vehicle") == vehicle:
		return options
	if vehicle.driver() != null and vehicle.driver().brain == null:
		return options
	var truck: = vehicle

	options.append(CrewTargets.everyone(Text.m("crew.orders.takeFollow"), "arrow", func(service: CrewService) -> void : take_and_follow(service, truck)))
	if not Game.incident.is_empty():
		options.append(CrewTargets.order(Text.m("crew.orders.driveCall"), "truck", func() -> CrewJob: return JobDrive.new(truck, "call")))
	options.append(CrewTargets.order(Text.m("crew.orders.driveFollow"), "arrow", func() -> CrewJob: return JobDrive.new(truck, "follow")))
	var here: = lead.global_position
	if vehicle.global_position.distance_to(here) > 40.0:
		options.append(CrewTargets.order(Text.m("crew.orders.driveHere"), "pin", func() -> CrewJob: return JobDrive.new(truck, "here", here)))
	return options




static func take_and_follow(service: CrewService, truck: Vehicle) -> void :
	var lead: = service.members[0].commander() if not service.members.is_empty() else null
	var lead_vehicle: Variant = lead.get_attr("Vehicle") if lead else null
	var left: Array = []
	for mind in service.members:
		if mind.body.health > 0.0 and (lead_vehicle == null or mind.body.get_attr("Vehicle") != lead_vehicle):
			left.append(mind)
	if left.is_empty() or (truck.driver() != null and truck.driver().brain == null):
		return
	var driver: Crewman = left[0]
	for mind: Crewman in left:
		if mind.role == "pump":
			driver = mind
	driver.give(JobDrive.new(truck, "follow"))
	driver.say("crew.say.takingTruck", [Text.named("vehicles", truck.spec["name"])], "info", true)
	var seats: = truck.seats.size() - 1
	for mind: Crewman in left:
		if mind != driver and seats > 0:
			mind.give(JobBoard.new(truck))
			seats -= 1




static func overflow(service: CrewService, lead_vehicle: Vehicle, left: Array) -> void :
	if left.is_empty():
		return
	var spare: Vehicle = null
	var best: = 120.0
	for vehicle in Vehicle.all:
		if vehicle == lead_vehicle or vehicle.driver() != null or vehicle.seats.is_empty() or vehicle.locked:
			continue
		var distance: = vehicle.global_position.distance_to(left[0].body.global_position)

		if vehicle.spec.get("hoses", false):
			distance -= 30.0
		if distance < best:
			best = distance
			spare = vehicle
	if spare == null:
		return
	var driver: Crewman = left[0]
	for mind: Crewman in left:
		if mind.role == "pump":
			driver = mind
	driver.give(JobDrive.new(spare, "call" if not Game.incident.is_empty() else "follow"))
	driver.say("crew.say.takingTruck", [Text.named("vehicles", spare.spec["name"])], "info", true)
	var seats: = spare.seats.size() - 1
	for mind: Crewman in left:
		if mind != driver and seats > 0:
			mind.give(JobBoard.new(spare))
			seats -= 1
