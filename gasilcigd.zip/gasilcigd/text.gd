extends Node









signal language_changed(code: String)

const BASE: = "sl"
const LANGUAGES: Array[String] = ["sl", "en", "de"]

const COMMA: Array[String] = ["sl", "de"]

var language: = "en"
var _lines: Dictionary = {}
var _signs: Dictionary = {}
var _pattern: = RegEx.create_from_string("%[-+ 0#]*[0-9]*(?:\\.[0-9]+)?[sdifgq%]")

const _UPPER: = {"č": "Č", "š": "Š", "ž": "Ž", "ć": "Ć", "đ": "Đ", "ä": "Ä", "ö": "Ö", "ü": "Ü"}


func _init() -> void :
	for pair in [["sl", "TextSl"], ["en", "TextEn"], ["de", "TextDe"]]:
		var flat: = {}
		_walk(Rbx.load_json("res://data/modules/%s.json" % pair[1]), "", flat)


		_walk(Rbx.load_json("res://data/godot/%s.json" % pair[1]), "", flat)
		if FileAccess.file_exists("res://data/godot/%sIndustry.json" % pair[1]):
			_walk(Rbx.load_json("res://data/godot/%sIndustry.json" % pair[1]), "", flat)

		var own: = Edition.path("%s.json" % pair[1], "")
		if not own.is_empty():
			_walk(Rbx.load_json(own), "", flat)
		_lines[pair[0]] = flat

	_signs["en"] = Rbx.load_json("res://data/modules/TextSigns.json")
	_signs["de"] = Rbx.load_json("res://data/modules/TextSignsDe.json")


func _walk(node: Variant, path: String, into: Dictionary) -> void :
	if node is Dictionary:
		for key in node:
			_walk(node[key], key if path.is_empty() else path + "." + key, into)
	elif node is Array:
		for index in node.size():
			var key: = str(index + 1)
			_walk(node[index], key if path.is_empty() else path + "." + key, into)
	else:
		into[path] = str(node)



func m(key: String) -> Dictionary:
	return {"k": key}



func f(key: String, args: Array) -> Dictionary:
	return {"k": key, "a": args}



func fill(message: Variant, args: Array) -> Variant:
	if message is Dictionary:
		var copy: Dictionary = message.duplicate()
		copy["a"] = args
		return copy
	return _format(str(message), args)



func join(parts: Array) -> Dictionary:
	return {"p": parts}



func plural(number: float, key: String) -> Dictionary:
	return {"k": key, "n": number}



func count(number: float, key: String) -> Dictionary:
	return {"p": [str(int(number)), " ", plural(number, key)]}



func named(names: String, key: String) -> Variant:
	var full: = names + "." + key
	if _lines[BASE].has(full):
		return {"k": full}
	return key


func has(key: String) -> bool:
	return _lines[BASE].has(key)



func sign(text: String) -> Variant:
	for code in _signs:
		if _signs[code].has(text):
			return {"s": text}
	return text


func upper(text: Variant) -> Variant:
	return {"p": [text], "w": "upper"}


func capital(text: Variant) -> Variant:
	return {"p": [text], "w": "capital"}



func decode(text: Variant) -> Variant:
	if text is String and text.begins_with("{\""):
		var parsed: Variant = JSON.parse_string(text)
		if parsed is Dictionary:
			return parsed
	return text



func say(value: Variant, code: = "") -> String:
	if code.is_empty():
		code = language
	if value == null:
		return ""
	if not value is Dictionary:
		return str(value)
	var text: = ""
	if value.has("s"):
		text = _signs.get(code, {}).get(value["s"], value["s"])
	elif value.has("k"):
		var key: String = value["k"]
		if value.has("n"):
			key += "." + str(_form(code, value["n"]))
		text = _lines[code].get(key, _lines[BASE].get(key, key))
		if code == "de" and not _lines[code].has(key):
			text = _lines["en"].get(key, text)
	else:
		for part in value.get("p", []):
			text += say(part, code)
	if value.has("a"):
		var filled: = []
		for item in value["a"]:
			filled.append(say(item, code) if item is Dictionary else item)
		text = _format(text, filled, code)
	if text.contains("{key:"):
		text = _keys(text)
	match value.get("w", ""):
		"upper":
			text = _upper(text)
		"lower":
			text = text.to_lower()
		"capital":
			text = _upper(text.left(1)) + text.substr(1)
	return text


func choose(code: String) -> void :
	if code in LANGUAGES and code != language:
		language = code
		language_changed.emit(code)



func _form(code: String, number: float) -> int:
	var whole: = int(absf(number))
	if code == "sl":
		var last: = whole % 100
		if last == 1:
			return 1
		if last == 2:
			return 2
		if last == 3 or last == 4:
			return 3
		return 4
	return 1 if whole == 1 else 4


func _upper(text: String) -> String:
	text = text.to_upper()
	for small in _UPPER:
		text = text.replace(small, _UPPER[small])
	return text





func _format(text: String, args: Array, code: = "") -> String:
	if code.is_empty():
		code = language
	var out: = ""
	var at: = 0
	var used: = 0
	for found in _pattern.search_all(text):
		out += text.substr(at, found.get_start() - at)
		at = found.get_end()
		var spec: = found.get_string()
		if spec == "%%":
			out += "%"
		elif used >= args.size():
			out += spec
		else:
			var arg: Variant = args[used]
			used += 1
			if out.ends_with("$") and spec != "%%":
				out = out.left(out.length() - 1) + _money(arg, code)
			elif spec.ends_with("s") or spec.ends_with("q"):
				if arg is float and arg == floorf(arg):
					arg = int(arg)
				out += str(arg)
			elif spec.ends_with("d") or spec.ends_with("i"):
				out += spec.replace("i", "d") % int(float(str(arg)))
			else:
				var number: String = spec.replace("g", "f") % float(str(arg))
				out += number.replace(".", ",") if code in COMMA else number
	return out + text.substr(at)



func _money(arg: Variant, code: String) -> String:
	if arg is int or arg is float:
		return Ui.money(float(arg), false, code)
	var digits: = str(arg).replace(".", "").replace(",", "")
	if digits.is_valid_int():
		return Ui.money(float(digits.to_int()), false, code)
	var sign: = str(Edition.data().get("currency", "€"))
	return str(arg) + " " + sign if code in COMMA else sign + str(arg)



func _keys(text: String) -> String:
	var start: = text.find("{key:")
	while start >= 0:
		var end: = text.find("}", start)
		if end < 0:
			break
		var action: = text.substr(start + 5, end - start - 5)
		var name: String = Controls.key_name(action)
		text = text.left(start) + name + text.substr(end + 1)
		start = text.find("{key:", start + name.length())
	return text
