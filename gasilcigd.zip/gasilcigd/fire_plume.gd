class_name FirePlume
extends Node3D








const LOOK_EVERY: = 0.5
const STARTS_AT: = 0.4

static var current: FirePlume

var _column: RbxEmitter
var _sky: MeshInstance3D
var _since: = 0.0
var _strength: = 0.0
var _scale: = 1.0
var _sizes: Array = []
var _glow_allowed: = true


func _enter_tree() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var look: Dictionary = Config.Art.Smoke
	_sizes = look["PlumeSize"]
	var lit: = float(look["PlumeLit"])


	_column = ToonFire.puffs(self, {
		"Color": ToonFire.fuel_color("building"), "Transparency": [[0.0, 0.0], [lit, 1.0], [1.0, 1.0]], 
		"Speed": [7, 10], "Lifetime": [11.0, 15.0], "SpreadAngle": 9, "Direction": Vector3.UP, 
		"Acceleration": Vector3(0, 0.5, 0) + World.WIND * 2.2, "Drag": 0.12, "Rotation": [0, 360], 
		"Size": _scaled(1.0), "Rate": 0, "MaxRate": float(look["PlumeRate"]), "Sphere": 4.0, 
		"Material": ToonFire.plume_material(), 
	})
	_column.visibility_aabb = AABB(Vector3(-200, -20, -200), Vector3(400, 360, 400))

	var sky: Dictionary = look["SkyGlow"]
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE * float(sky["Size"])
	var material: = ShaderMaterial.new()
	material.shader = load("res://shaders/plume_glow.gdshader")
	var tint: Array = sky["Color"]
	material.set_shader_parameter("tint", Color(tint[0], tint[1], tint[2]))
	_sky = MeshInstance3D.new()
	_sky.mesh = quad
	_sky.material_override = material
	_sky.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_sky.visible = false
	_sky.custom_aabb = AABB(Vector3.ONE * - float(sky["Size"]), Vector3.ONE * float(sky["Size"]) * 2.0)
	add_child(_sky)
	set_level(Settings.quality)



func set_level(level: int) -> void :
	_glow_allowed = level >= int(Config.Art.Smoke.SkyGlow["From"])
	if not _glow_allowed and _sky != null:
		_sky.visible = false


func _scaled(scale: float) -> Array:
	var keys: Array = []
	for key: Array in _sizes:
		keys.append([float(key[0]), float(key[1]) * scale])
	return keys


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var sum: = Vector3.ZERO
	var weight: = 0.0
	var top: = - INF
	for flame in Flame.all:
		if not is_instance_valid(flame) or not flame.is_inside_tree():
			continue
		var size: = 0.25 + 0.75 * flame.intensity
		sum += flame.global_position * size
		weight += size
		top = maxf(top, flame.global_position.y)
	var wanted: = clampf((weight - STARTS_AT) / 3.5, 0.0, 1.0)
	_strength += (wanted - _strength) * 0.3
	if weight > 0.0:
		var middle: = sum / weight
		global_position = Vector3(middle.x, top + 6.0, middle.z)
	_column.set_rate(float(Config.Art.Smoke.PlumeRate) * _strength)
	var camera: = get_viewport().get_camera_3d()
	if camera != null:
		var scale: = snappedf(clampf(camera.global_position.distance_to(global_position) / 260.0, 0.35, 1.0), 0.05)
		if scale != _scale:
			_scale = scale
			_column.set_size(_scaled(scale))
	_show_sky(camera)




func _show_sky(camera: Camera3D) -> void :
	var night: = 1.0 - (Sky3D.current.daylight() if Sky3D.current else 1.0)
	var sky: Dictionary = Config.Art.Smoke.SkyGlow
	var far: = 0.0
	if camera != null:
		far = clampf((camera.global_position.distance_to(global_position) - float(sky["Near"])) / 40.0, 0.0, 1.0)
	var strength: = _strength * night * far
	_sky.visible = _glow_allowed and strength > 0.02
	if _sky.visible:
		_sky.position = Vector3(0, float(sky["Up"]), 0)
		(_sky.material_override as ShaderMaterial).set_shader_parameter("strength", strength * float(sky["Energy"]))
