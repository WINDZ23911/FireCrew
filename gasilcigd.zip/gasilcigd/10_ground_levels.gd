extends RefCounted



const ORDER: = [
	"meadow", "field", "verge", "scrub", "orchard", "park", "forest", "path", "soil", "paving", "playground", 
	"court", "plaza", "driveway", "parking", "bus_station", "forecourt", "lane", "road", "crossover", "tar", 
	"manhole", "drain", "paint", "paint_yellow", 
]
const STEP: = 0.0025


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var lift: Dictionary = {}
	for index in ORDER.size():
		lift[ORDER[index]] = index * STEP
	var moved: = 0
	for row in kit.rows_under("Map/Surfaces"):
		var by: float = lift.get(store.name_at(row), 0.0)
		if by > 0.0:
			var place: = store.transform(row)
			place.origin.y += by
			store.set_transform(row, place)
			moved += 1
	return "%d ground pieces levelled" % moved
