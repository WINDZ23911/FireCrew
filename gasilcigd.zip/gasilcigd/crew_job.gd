class_name CrewJob
extends RefCounted





var kind: = ""
var target: Variant = null
var role: = ""
var who: Crewman
var cancelled: = false
var ordered: = true
var reason: = ""
var reason_args: Array = []
var done_flag: = ""
var quiet: = false



func title() -> Variant:
	return Text.m("crew.jobs." + kind)



func suits(_member: Crewman) -> bool:
	return true



func run() -> bool:
	return true



func finish(_done: bool) -> void :
	pass



func fail(key: String, args: Array = []) -> bool:
	reason = key
	reason_args = args
	return false



func on(held: int) -> bool:
	return not cancelled and who.alive(held)
