class_name Style
extends Node












signal changed(style: int)

enum {SUMMER, WINTER}

const NAMES: = ["summer", "winter"]
const EASE: = 3.0


const WINTER_DAWN: = 7.2
const WINTER_DUSK: = 16.7

static var current: Style
static var kind: = SUMMER
static var _held: = false
static var _summer_day: Array = []

var _amount: = -1.0
var _started: = 0


static func winter() -> bool:
	return kind == WINTER



static func from_command_line() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--style="):
			var at: = NAMES.find(arg.substr(8))
			if at >= 0:
				kind = at
				_held = true
				_set_day()




static func choose(style: int) -> void :
	if _held or style == kind or style < SUMMER or style > WINTER:
		return
	kind = style
	_set_day()
	if current:
		current.changed.emit(kind)



static func _set_day() -> void :
	var day: Dictionary = Config.Day
	if _summer_day.is_empty():
		_summer_day = [day["Dawn"], day["Dusk"]]
	day["Dawn"] = WINTER_DAWN if winter() else _summer_day[0]
	day["Dusk"] = WINTER_DUSK if winter() else _summer_day[1]


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	_amount = 0.0
	_started = Time.get_ticks_msec()
	RenderingServer.global_shader_parameter_set("winter", _amount)


func _process(delta: float) -> void :

	var target: = 1.0 if winter() and SnowCover.current != null and SnowCover.current.done else 0.0
	if _amount != target:

		_amount = target if Time.get_ticks_msec() - _started < 8000 else move_toward(_amount, target, delta / EASE)
		RenderingServer.global_shader_parameter_set("winter", _amount)
