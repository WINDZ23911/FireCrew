class_name HudHints
extends HBoxContainer






var _pairs: Dictionary = {}


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	grow_horizontal = Control.GROW_DIRECTION_BEGIN
	grow_vertical = Control.GROW_DIRECTION_BEGIN
	alignment = BoxContainer.ALIGNMENT_END
	add_theme_constant_override("separation", 10)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint("crouch", "crouch")
	_hint("visor", "visor")
	_hint("lamp", "lamp")
	_hint("moveBack", "pattern")
	_hint("crew", "crew_order")

	_hint("exit", "veh_exit")

	_hint("report", "report_available")



func _hint(hint_name: String, action: String) -> void :
	var pill: = PanelContainer.new()
	var style: = StyleBoxFlat.new()
	style.bg_color = Color(0, 0, 0, float(Config.Hud.HintPill))
	style.set_corner_radius_all(19)
	style.content_margin_left = 5
	style.content_margin_right = 14
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	pill.add_theme_stylebox_override("panel", style)
	pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(pill)
	var pair: = HBoxContainer.new()
	pair.add_theme_constant_override("separation", 8)
	pair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pill.add_child(pair)
	pair.add_child(Ui.action_key(action))
	var label: = Ui.label("", int(Config.Hud.TextFloor))
	label.custom_minimum_size = Vector2(0, 30)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	pair.add_child(label)
	_pairs[hint_name] = {"pair": pill, "label": label, "action": action}



func _unlearned(hint_name: String) -> bool:
	return int(Settings.hints_used.get(hint_name, 0)) < int(Config.Hud.HintLearned)


func _process(_delta: float) -> void :
	var player: = Game.local_player
	visible = player != null and not Game.ui_open
	if player == null:
		return
	var geared: bool = player.get_attr("Geared", false) == true
	var seated: = player.seat != null
	var wanted: = {}
	wanted["visor"] = geared
	wanted["lamp"] = geared


	var crowd: = not Game.incident.is_empty() and Game.incident.has("pos") and player.global_position.distance_to(Game.incident["pos"]) < float(Config.Hud.MoveBackNear)
	wanted["moveBack"] = geared and not seated and player.holding != "nozzle" and crowd

	wanted["crouch"] = not seated
	_pairs["crouch"]["label"].text = Text.say(Text.m("hud.hints.stand" if player.crouching else "hud.hints.crouch"))
	for hint_name: String in ["visor", "lamp", "moveBack"]:
		_pairs[hint_name]["label"].text = Text.say(Text.m("hud.hints." + hint_name))

	var crew: = CrewService.current
	wanted["crew"] = not seated and crew != null and not crew.members.is_empty()
	_pairs["crew"]["label"].text = Text.say(Text.m("crew.hint"))
	wanted["exit"] = seated and HudTruck.driven() == null
	_pairs["exit"]["label"].text = Text.say(Text.m("hud.hints.exit"))
	var duty: Dictionary = Duty.current.state if Duty.current != null else {}
	wanted["report"] = duty.get("status", "") == "available" and not bool(duty.get("reported", false)) and Game.incident.is_empty()
	_pairs["report"]["label"].text = Text.say(Text.m("hud.hints.report"))
	for hint_name: String in _pairs:
		var entry: Dictionary = _pairs[hint_name]
		var pill: Control = entry["pair"]
		var shown: bool = wanted[hint_name]

		if shown and pill.visible and Input.is_action_just_pressed(entry["action"]):
			Settings.hint_used(hint_name)
		if shown and not _unlearned(hint_name):

			var fading: float = entry.get("fading", -1.0)
			if fading < 0.0:
				entry["fading"] = Game.now()
				fading = Game.now()
			var left: = 1.0 - (Game.now() - fading) / float(Config.Hud.HintFade)
			pill.modulate.a = clampf(left, 0.0, 1.0)
			shown = left > 0.0
		pill.visible = shown

	var lift: = 0.0
	var water: Variant = Hud.current.widgets.get("water") if Hud.current else null
	if water is HudWater and water.showing():
		lift = HudWater.HEIGHT + 14
	reset_size()
	position = Vector2(get_parent_area_size().x - 28 - size.x, get_parent_area_size().y - Ui.MARGIN - size.y - lift)
