class_name ProofDebug
extends Node











var proof_name: = ""
var _checks: = 0
var _failed: Array[String] = []
var _verdict_said: = false
var _shots: = ""
var _camera: Camera3D
var player: Player


func _ready() -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shots="):
			_shots = arg.substr(8)
	player = Game.local_player
	Game.notified.connect( func(text: Variant, kind: String, _who: Player) -> void :
		print("told%s: %s" % ["" if kind.is_empty() else " (" + kind + ")", Text.say(text, "en")])
	)
	if CallService.current:
		CallService.current.hold = true


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds, false).timeout


func _snap(stage: String) -> void :
	if _shots.is_empty():
		return
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s_%s.png" % [_shots, stage])
	print("shot: %s_%s.png" % [_shots, stage])



func _check(ok: bool, what: String) -> bool:
	_checks += 1
	if ok:
		print("check ok: %s" % what)
	else:
		print("CHECK FAILED: %s" % what)
		_failed.append(what)
	return ok



func _fail(why: String) -> void :
	print("CHECK FAILED: %s" % why)
	_failed.append(why)


func _verdict() -> void :
	if _verdict_said:
		return
	_verdict_said = true
	if _checks == 0 and _failed.is_empty():
		_failed.append("nothing was checked")
	if _failed.is_empty():
		print("PROOF PASS %s (%d checks)" % [proof_name, _checks])
	else:
		print("PROOF FAIL %s: %s" % [proof_name, "; ".join(_failed)])


func _exit_tree() -> void :
	if not _verdict_said:
		_fail("the run ended before it was done")
		_verdict()


func _done() -> void :
	Input.action_release("fire")
	print("scenario over")
	_verdict()
	if not _shots.is_empty():
		await _wait(0.3)
		Game.quit()



func _view(from: Vector3, to: Vector3, fov: = 60.0) -> void :
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 6000.0
		add_child(_camera)
	_camera.fov = fov
	_camera.look_at_from_position(from, to)
	_camera.make_current()


func _view_player() -> void :
	player.camera.camera.make_current()



func _look_at(point: Vector3) -> void :
	var toward: = point - player.head_position()
	player.camera.yaw = atan2( - toward.x, - toward.z)
	player.camera.pitch = asin(clampf(toward.normalized().y, -1.0, 1.0))
	player.rig.rotation.y = player.camera.yaw




func _aim_view(point: Vector3) -> void :
	for pass_number in 4:
		var toward: = point - player.camera.camera.global_position
		player.camera.yaw = atan2( - toward.x, - toward.z)
		player.camera.pitch = asin(clampf(toward.normalized().y, -1.0, 1.0))
		await get_tree().process_frame
		await get_tree().process_frame



func _tap(action: String) -> void :
	await get_tree().process_frame
	Input.action_press(action)
	await get_tree().process_frame
	await get_tree().process_frame
	Input.action_release(action)
	await get_tree().process_frame



func _hold(action: String, seconds: float) -> void :
	await get_tree().process_frame
	Input.action_press(action)
	await _wait(seconds)
	Input.action_release(action)
	await get_tree().process_frame



func _ground(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(Vector3(at.x, at.y + 40.0, at.z), Vector3(at.x, at.y - 80.0, at.z), World.LAYER_SOLID)
	return hit["position"] if not hit.is_empty() else at



func _park(vehicle: Vehicle, at: Vector3, yaw: = PI) -> void :
	var ground: = _ground(at)
	vehicle.global_transform = Transform3D(Basis(Vector3.UP, yaw), ground + Vector3(0, float(vehicle.spec["spawn"].origin.y), 0))
	vehicle.linear_velocity = Vector3.ZERO
	vehicle.angular_velocity = Vector3.ZERO
	vehicle.reset_physics_interpolation()




func _open_spot(from: Vector3, way: Vector3, vehicle: Vehicle) -> Vector3:
	var half: = Vector2(float(vehicle.data.get("width", 8.0)) / 2.0 + 1.0, 9.0)
	for distance: float in [18.0, 24.0, 14.0, 30.0, 36.0, 40.0]:
		for turn: float in [0.0, 0.35, -0.35, 0.7, -0.7]:
			var along: = way.rotated(Vector3.UP, turn).normalized()
			var at: = _ground(from + along * distance)
			var across: = along.cross(Vector3.UP).normalized()
			var clear: = absf(at.y - from.y) < 3.0
			for x: float in [-1.0, 0.0, 1.0]:
				for z: float in [-1.0, 0.0, 1.0]:
					var probe: = at + across * x * half.x + along * z * half.y
					var hit: = Game.world.raycast(probe + Vector3(0, 14, 0), probe + Vector3(0, 0.6, 0), World.LAYER_SOLID)
					clear = clear and hit.is_empty() and absf(_ground(probe).y - at.y) < 1.5
			if clear:
				return at
	return _ground(from + way * 24.0)


func _locker_line(vehicle: Vehicle, object_name: String) -> LockerLine:
	for line in Lockers.of(vehicle).lines:
		if Text.say(line.object, "en") == object_name:
			return line
	return null



func _take_roll(vehicle: Vehicle, kind: String) -> bool:
	var hoses: = HoseService.current
	for rig: Dictionary in hoses.rigs:
		if rig["vehicle"] == vehicle and rig.get("roll_lines", {}).has(kind):
			rig["roll_lines"][kind].chosen.emit(player)
			await _wait(0.2)
			return player.get_attr("HoseRoll") == kind
	return false


func _slots() -> String:
	var names: Array = []
	var tools: = ToolService.current
	for slot: Dictionary in tools.slots(player):
		names.append("%s%s" % [slot["name"], "*" if tools.slot_in_hand(player, slot) else ""])
	return "[" + ", ".join(names) + "]"





func _scenario_divider() -> void :
	await _wait(1.0)
	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	var tanker: = Vehicle.named("Tanker")
	_park(pumper, Vector3(-12, 0, -22))
	_park(tanker, Vector3(-40, 0, -22))
	await _wait(0.6)
	var divider: Dictionary = hoses.divider
	var line: = _locker_line(pumper, "Divider")
	var lockers: = Lockers.of(pumper)
	print("divider: locker line '%s · %s' in %s, shelf piece shown %s" % [Text.say(line.action, "en"), Text.say(line.object, "en"), line.locker, pumper.props["Divider"]["node"].visible])


	var right: Vector3 = pumper.global_transform * Vector3(9, -2.2, 10)
	player.teleport(_ground(right) + Vector3(0, 0.3, 0))
	pumper.set_lockers(true)
	await _wait(1.2)
	lockers.use(player, lockers.handles[0] if lockers.handles[0]["node"].position.x > 0 else lockers.handles[1], line)
	await _wait(0.3)
	print("divider: %s by %s; line now '%s'; shelf piece shown %s; hotbar %s; hands '%s'" % [divider["state"], divider["player"], Text.say(line.action, "en"), pumper.props["Divider"]["node"].visible, _slots(), player.holding])
	_check(divider["state"] == "carried" and divider["player"] == player, "the divider is carried after its locker line")
	_look_at(player.head_position() + Vector3(1, -0.1, 0.3))
	_view(player.global_position + Vector3(-9, 5, 6), player.global_position + Vector3(0, 3, 0))
	await _snap("carry")


	await _tap("slot_1")
	print("divider: after key 1, hotbar %s, hands '%s'" % [_slots(), player.holding])
	await _tap("slot_1")
	print("divider: after key 1 again, hotbar %s, hands '%s'" % [_slots(), player.holding])
	_check(player.holding == "tool", "key 1 takes the divider back in hand")


	var spot: = _ground(pumper.global_position + Vector3(28, 0, 14))
	player.teleport(spot + Vector3(0, 0.3, 0))
	_look_at(player.head_position() + Vector3(1, 0, 0))
	await _wait(0.3)
	await _tap("fire")
	await _wait(0.3)
	print("divider: %s; prompts: inlet %s, outlets %s, pickup %s; hotbar %s" % [divider["state"], divider["inlet"]["prompt"].enabled if divider["inlet"] != null else "-", divider["lines"].map( func(l: Dictionary) -> bool: return l["prompt"].enabled), divider["pickup"].enabled if divider["pickup"] != null else "-", _slots()])
	_check(divider["state"] == "placed", "a click sets the divider down")
	var at: Vector3 = divider["body"].global_position
	_view(at + Vector3(-7, 6, 9), at)
	await _snap("placed")


	await _hold("coupling", 0.5)
	await _wait(0.2)

	player.teleport(_ground(pumper.global_transform * Vector3(9, 0, 12)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	_look_at(pumper.global_transform * Vector3(5.2, 0, 12.2))
	_check( await _take_roll(pumper, "attack"), "an attack roll taken from the pumper's lockers for the feed")
	await _hold("coupling", 0.5)
	await _wait(1.1)
	print("divider: took '%s' line: %s" % [hoses.line_of(player)["kind"] if hoses.line_of(player) != null else "none", player.get_attr("HoseTruck")])
	_check(hoses.line_of(player) != null and hoses.line_of(player)["kind"] == "outlet", "the roll goes on at the pumper's outlet")
	for step in 6:
		player.teleport(player.global_position.lerp(at + Vector3(-3, -0.4, 0), (step + 1) / 6.0))
		await _wait(0.25)
	_look_at(divider["inlet"]["node"].global_position)
	await _wait(0.2)
	print("divider: offered on T: %s" % (Text.say(player.prompts["coupling"].action, "en") if player.prompts.get("coupling") != null else "nothing"))
	var told: Array = []
	var listen: = func(text: Variant, _kind: String, to: Player) -> void :
		if to == player:
			told.append(Text.say(text, "en"))
	Game.notified.connect(listen)
	await _hold("coupling", 0.5)
	await _wait(0.3)
	Game.notified.disconnect(listen)
	var feed: Variant = divider["feed"]
	_check(feed != null, "the line from the pumper feeds the divider")
	print("divider: told on feeding: %s" % [told])
	_check(told.has(Text.say(Text.m("gear.hose.dividerFed"), "en")) and not told.has(Text.say(Text.m("gear.hose.feedConnected"), "en")), "feeding the divider says the divider's words, not the relay's")
	print("divider: fed %s; feed hose %.0f studs; truck outlet says '%s'; prompts: inlet %s, outlets %s, pickup %s; player's line %s" % [feed != null, feed["hose"].length() if feed != null else 0.0, Text.say(hoses.lines[1]["prompt"].action, "en"), divider["inlet"]["prompt"].enabled, divider["lines"].map( func(l: Dictionary) -> bool: return l["prompt"].enabled), divider["pickup"].enabled, hoses.line_of(player)])


	player.teleport(at + Vector3(3.5, -0.4, 0))
	await _wait(1.1)
	_look_at(divider["lines"][1]["source"].global_position)
	await _wait(0.2)
	_check( await _take_roll(pumper, "attack"), "another attack roll for the divider's own line")
	player.teleport(at + Vector3(3.5, -0.4, 0))
	await _wait(0.6)
	_look_at(divider["lines"][1]["source"].global_position)
	await _hold("coupling", 0.5)
	await _wait(0.3)
	var mine: Variant = hoses.line_of(player)
	_check(mine != null and mine["kind"] == "divider", "a line taken from the divider's outlet")
	print("divider: holding a '%s' line, %s studs most, tank shown %s" % [mine["kind"] if mine != null else "none", player.get_attr("HoseMax"), player.get_attr("HoseTruck")])
	for step in 5:
		player.teleport(player.global_position + Vector3(5, 0, 1))
		await _wait(0.25)
	_look_at(player.head_position() + Vector3(10, 1.5, 2))
	var before: = pumper.water
	Input.action_press("fire")
	await _wait(2.0)
	_view(at + Vector3(-12, 9, 16), at + Vector3(10, 1, 2))
	await _snap("spraying")
	print("divider: spraying %s; pumper tank %.0f -> %.0f in 2 s; hose out %s" % [player.get_attr("Spraying"), before, pumper.water, player.get_attr("HoseLength")])
	_check(pumper.water < before - 1.0, "water through the divider comes out of the pumper's tank")
	Input.action_release("fire")
	await _wait(0.3)



	var pumper_rig: Dictionary = {}
	for rig: Dictionary in hoses.rigs:
		if rig["vehicle"] == pumper:
			pumper_rig = rig
	for index: int in [0, 2]:
		hoses._put_down(hoses.line_of(player), player)
		await _wait(0.3)
		_check( await _take_roll(pumper, "attack"), "a roll from the pumper for the divider's outlet %d" % (index + 1))
		player.teleport(at + Vector3(3.5, -0.4, 0))
		await _wait(1.1)
		_look_at(divider["lines"][index]["source"].global_position)
		divider["lines"][index]["prompt"].triggered.emit(player)
		await _wait(0.3)
		_check(is_same(hoses.line_of(player), divider["lines"][index]), "a line taken from the divider's outlet %d" % (index + 1))
	var in_use: Array = divider["lines"].filter( func(l: Dictionary) -> bool: return l["player"] != null or l.get("down") != null)
	print("divider: %d of its lines out (held %s); pumper rolls %s of %s" % [in_use.size(), divider["lines"].map( func(l: Dictionary) -> bool: return l["player"] != null), pumper_rig["rolls"], pumper_rig["roll_full"]])
	_check(in_use.size() == 3 and in_use.all( func(l: Dictionary) -> bool: return is_same(hoses.rig_of(l)["vehicle"], pumper)), "three lines fed from the one divider, all from the pumper's tank")
	before = pumper.water
	Input.action_press("fire")
	await _wait(1.5 + float(Config.Water.Charge.Time))
	Input.action_release("fire")
	_view(at + Vector3(-12, 9, 16), at)
	await _snap("three")
	_check(pumper.water < before - 1.0, "the third line sprays")


	hoses._on_outlet(hoses.lines[1], player)
	await _wait(0.3)
	print("divider: feed off: fed %s, player's line %s, pickup %s; pumper rolls %s" % [divider["feed"] != null, hoses.line_of(player), divider["pickup"].enabled, pumper_rig["rolls"]])
	_check(divider["feed"] == null and hoses.line_of(player) == null and divider["lines"].all( func(l: Dictionary) -> bool: return l["player"] == null and l.get("down") == null), "the feed off at the truck takes the divider's lines with it")
	_check(int(pumper_rig["rolls"]["attack"]) == int(pumper_rig["roll_full"]["attack"]), "every roll goes back in the pumper")

	player.teleport(at + Vector3(0, -0.4, 4))
	_look_at(at)
	await _wait(1.1)
	print("divider: offered on E: %s" % (Text.say(player.prompts["interact"].action, "en") if player.prompts.get("interact") != null else "nothing"))
	await _hold("interact", 0.8)
	await _wait(0.3)
	var left: = 0
	for other: Dictionary in hoses.lines:
		if other["kind"] == "divider":
			left += 1
	print("divider: %s; line '%s'; shelf piece shown %s; divider lines left %d" % [divider["state"], Text.say(line.action, "en"), pumper.props["Divider"]["node"].visible, left])
	_check(divider["state"] == "stowed" and pumper.props["Divider"]["node"].visible, "picked up, the divider is back on its shelf")
	await _done()


func _scenario_relay() -> void :
	await _wait(1.0)
	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	var tanker: = Vehicle.named("Tanker")
	_park(pumper, Vector3(-12, 0, -22))
	_park(tanker, Vector3(-40, 0, -22))
	await _wait(0.6)
	var pumper_rig: Dictionary = hoses.rigs[0]
	var tanker_rig: Dictionary = hoses.rigs[1]
	var pumper_out: Dictionary = {}
	var tanker_out: Dictionary = {}
	for other: Dictionary in hoses.lines:
		if other["kind"] == "outlet" and other["rig"]["vehicle"] == pumper and pumper_out.is_empty():
			pumper_out = other
		if other["kind"] == "outlet" and other["rig"]["vehicle"] == tanker:
			tanker_out = other
	var behind_tanker: = _ground(tanker.global_transform * Vector3(0, 0, 18)) + Vector3(0, 0.3, 0)
	var by_pumper: = _ground(pumper_out["source"].global_position + Vector3(-3, 0, 0)) + Vector3(0, 0.3, 0)


	tanker.water = 1000.0
	player.teleport(behind_tanker)
	await _wait(0.4)
	_look_at(tanker.intake["node"].global_position)
	_check( await _take_roll(tanker, "supply"), "the tanker's supply roll taken from its lockers")
	await _hold("coupling", 0.5)
	await _wait(0.3)
	print("relay: carrying the supply of %s" % (hoses.supply_of(player)["vehicle"].name if hoses.supply_of(player) != null else "nothing"))

	hoses._on_outlet(tanker_out, player)
	for step in 6:
		player.teleport(behind_tanker.lerp(by_pumper, (step + 1) / 6.0))
		await _wait(0.25)
	_look_at(pumper_out["source"].global_position)
	await _wait(1.0)
	await _hold("coupling", 0.5)
	await _wait(0.3)
	var supply: Dictionary = tanker_rig["supply"]
	print("relay: tanker supply %s, donor %s; pumper outlet says '%s'; tanker fed by %s; pumper feeding %s" % [supply["state"], supply["donor"] != null, Text.say(pumper_out["prompt"].action, "en"), hoses.supplied_by(tanker), hoses.feeding(pumper)])
	_check(supply["state"] == "connected" and supply["donor"] != null, "the tanker's supply hose goes on the pumper's outlet")
	var before: = [pumper.water, tanker.water]
	await _wait(3.0)
	print("relay: in 3 s pumper %.0f -> %.0f, tanker %.0f -> %.0f (RelayFlow %s L/s)" % [before[0], pumper.water, before[1], tanker.water, Config.Hose.RelayFlow])
	_check(tanker.water > before[1] + 1.0 and pumper.water < before[0] - 1.0, "the pumper fills the tanker")
	player.teleport(_ground(pumper.global_transform * Vector3(-12, 0, 16)) + Vector3(0, 0.3, 0))
	_view_player()
	_look_at(pumper.global_transform * Vector3(-8, 2, 10))
	player.camera.wanted_distance = 22.0
	_view(player.global_position + Vector3(-6, 9, -16), (pumper.global_position + tanker.global_position) / 2.0 + Vector3(0, 0, -12))
	await _wait(0.5)
	await _snap("pumper_fills_tanker")


	_check( await _take_roll(pumper, "supply"), "the pumper's supply roll taken")
	hoses._on_intake(pumper_rig, player)
	await _wait(0.2)
	hoses._on_outlet(tanker_out, player)
	await _wait(0.2)
	print("relay: pumper supply still %s" % pumper_rig["supply"]["state"])
	_check(pumper_rig["supply"]["state"] == "carried", "the pumper's supply cannot go on the tanker that it feeds")
	await _wait(1.0)
	hoses._on_intake(pumper_rig, player)
	await _wait(0.2)

	await _wait(1.0)
	hoses._on_outlet(pumper_out, player)
	await _wait(0.2)
	print("relay: after the outlet's prompt: tanker supply %s, outlet says '%s', pumper feeding %s" % [supply["state"], Text.say(pumper_out["prompt"].action, "en"), hoses.feeding(pumper)])
	_check(supply["state"] == "stowed", "the outlet's prompt takes the relay off")


	pumper.water = 500.0
	var by_tanker: = _ground(tanker_out["source"].global_position + Vector3(3, 0, 0)) + Vector3(0, 0.3, 0)
	var behind_pumper: = _ground(pumper.global_transform * Vector3(0, 0, 18)) + Vector3(0, 0.3, 0)
	player.teleport(by_tanker)
	await _wait(1.1)
	_check( await _take_roll(tanker, "attack"), "an attack roll taken from the tanker")
	hoses._on_outlet(tanker_out, player)
	await _wait(0.3)
	for step in 6:
		player.teleport(by_tanker.lerp(behind_pumper, (step + 1) / 6.0))
		await _wait(0.25)
	_look_at(pumper.intake["node"].global_position)
	await _wait(0.3)
	print("relay: offered on T: %s" % (Text.say(player.prompts["coupling"].action, "en") if player.prompts.get("coupling") != null else "nothing"))
	await _hold("coupling", 0.5)
	await _wait(0.3)
	supply = pumper_rig["supply"]
	print("relay: pumper supply %s, limit %s, hose %.0f studs; player's line %s; intake says '%s'; tanker outlet says '%s'" % [supply["state"], supply["limit"], supply["hose"].length() if supply["hose"] != null else 0.0, hoses.line_of(player), Text.say(supply["prompt"].action, "en"), Text.say(tanker_out["prompt"].action, "en")])
	before = [pumper.water, tanker.water]
	await _wait(3.0)
	print("relay: in 3 s pumper %.0f -> %.0f, tanker %.0f -> %.0f" % [before[0], pumper.water, before[1], tanker.water])
	_check(supply["state"] == "connected" and pumper.water > before[0] + 1.0, "an attack hose from the tanker on the pumper's intake fills the pumper")
	_view(player.global_position + Vector3(8, 9, 16), (pumper.global_position + tanker.global_position) / 2.0 + Vector3(0, 0, -12))
	await _snap("tanker_fills_pumper")

	_view_player()
	player.camera.wanted_distance = 16.0
	_look_at(pumper.global_position)
	await _wait(0.6)
	await _snap("water_card")


	_park(tanker, Vector3(-40, 0, 330))
	await _wait(1.0)
	print("relay: tanker gone: pumper supply %s, tanker outlet says '%s'" % [supply["state"], Text.say(tanker_out["prompt"].action, "en")])
	_check(supply["state"] != "connected", "the hose comes off when the tanker drives away")
	_park(tanker, Vector3(-40, 0, -22))


	var hydrant: Dictionary = hoses.hydrants[0]
	var best: = INF
	for other: Dictionary in hoses.hydrants:
		var distance: float = other["position"].distance_to(pumper.global_position)
		if distance < best:
			best = distance
			hydrant = other
	var at: Vector3 = hydrant["position"]
	_park(pumper, at + Vector3(20, 0, 30))
	_park(tanker, at + Vector3(-20, 0, 30))
	await _wait(1.0)
	if pumper_rig["supply"]["state"] != "stowed":
		hoses.stow_supply(pumper_rig)
	_check( await _take_roll(pumper, "supply"), "the pumper's supply roll taken for the hydrant")
	hoses._on_intake(pumper_rig, player)
	player.teleport(_ground(at + Vector3(0, 0, 4)) + Vector3(0, 0.3, 0))
	await _wait(1.1)
	hoses._on_hydrant(hydrant, player)
	await _wait(1.1)
	_check( await _take_roll(tanker, "supply"), "the tanker's supply roll taken for the hydrant")
	hoses._on_intake(tanker_rig, player)
	await _wait(0.2)
	hoses._on_hydrant(hydrant, player)
	await _wait(0.2)
	print("relay: hydrant feeds %s; tanker supply %s" % [hydrant["rig"]["vehicle"].name if hydrant["rig"] != null else "nobody", tanker_rig["supply"]["state"]])
	_check(hydrant["rig"] != null and hydrant["rig"]["vehicle"] == pumper and tanker_rig["supply"]["state"] == "carried", "a hydrant serves one truck at a time")
	_view(at + Vector3(0, 14, -26), at + Vector3(0, 0, 12))
	await _snap("hydrant")
	await _done()





func _scenario_garage() -> void :
	await _wait(1.0)
	var truck: = Vehicle.named("Fire Truck")
	var camera: = player.camera
	Game.station.set_door(int(truck.spec["bay"]), true)
	truck._board(player, "DoorCabLeft")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--pitch="):
			camera.pitch = float(arg.substr(8))
	await _wait(2.5)
	print("garage: parked inside: seated view %s (squeezed %s), camera %.1f studs from the seat's eye, %.1f above the roof" % [camera.seated_view(), camera._squeezed, camera.global_position.distance_to(camera._seat_eye(truck)), camera.global_position.y - (truck.global_position.y + float(truck.data["top"]))])
	await _snap("inside")
	var parked: = truck.global_transform
	Input.action_press("move_forward")
	var said: = {}
	for step in 40:
		await _wait(0.25)
		var view: = "seat" if camera.seated_view() else "behind"
		if OS.get_cmdline_user_args().has("--trace"):
			print("   z=%.0f view %s distance %.1f" % [truck.global_position.z, view, camera.distance])
		if not said.has(view):
			said[view] = true
			print("garage: t=%.1f truck z=%.0f speed %.0f: view from %s, %.1f studs from the truck" % [step * 0.25, truck.global_position.z, truck.forward_speed, view, camera.global_position.distance_to(truck.global_position)])
			if view == "behind":
				await _snap("out")
		if step == 6:
			await _snap("leaving")
	Input.action_release("move_forward")
	await _wait(1.5)
	var close: = camera.global_position.distance_to(truck.global_position)
	await _tap("camera_mode")
	await _wait(1.2)
	var far: = camera.global_position.distance_to(truck.global_position)
	print("garage: after Tab: far %s, %.1f studs from the truck (close was %.1f)" % [camera.chase_far, far, close])
	_check(said.has("behind"), "out of the garage the view goes behind the truck")
	_check(camera.chase_far and not camera.seated_view() and far > close + 6.0, "Tab gives the far view from behind")
	await _snap("tab_far")
	await _tap("camera_mode")
	await _wait(0.3)
	print("garage: after Tab: driver view %s, seated view %s" % [camera.driver_view, camera.seated_view()])
	_check(camera.driver_view and camera.seated_view(), "Tab again gives the driver's view")
	await _snap("tab_seat")
	await _tap("camera_mode")
	await _wait(0.6)
	print("garage: after Tab again: driver view %s, seated view %s, %.1f studs from the truck" % [camera.driver_view, camera.seated_view(), camera.global_position.distance_to(truck.global_position)])
	_check( not camera.driver_view and not camera.chase_far, "Tab a third time gives the close view from behind back")
	await _snap("tab_behind")

	var out_front: = parked.origin - parked.basis.z * 40.0
	_park(truck, out_front, parked.basis.get_euler().y)
	await _wait(1.5)


	var creep: = false
	camera.chase_far = true
	camera.pitch = -0.4
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--back-yaw="):
			camera.yaw = parked.basis.get_euler().y + float(arg.substr(11))
		elif arg.begins_with("--back-pitch="):
			camera.pitch = float(arg.substr(13))
		creep = creep or arg == "--creep"
		if arg == "--close":
			camera.chase_far = false
	Input.action_press("move_back")
	var flips: = 0
	var was: = camera.seated_view()
	for step in 600:
		await _wait(0.1)
		if creep:
			if step % 3 == 0:
				Input.action_press("move_back")
			else:
				Input.action_release("move_back")
		if truck.global_position.distance_to(parked.origin) < 4.0:
			break
		if camera.seated_view() != was:
			was = camera.seated_view()
			flips += 1
			if OS.get_cmdline_user_args().has("--trace"):
				print("   t=%.1f z=%.0f view %s" % [step * 0.1, truck.global_position.z, "seat" if was else "behind"])
	Input.action_release("move_back")
	print("garage: backed in: truck z=%.0f, the view changed %d times, seated now %s" % [truck.global_position.z, flips, camera.seated_view()])
	_check(flips <= 2, "backing in, the view gives way to the seat's (and back, once in) and does not flick")
	await _snap("backed_in")
	await _done()






func _house(prefix: String) -> House:
	var best: House = null
	var best_distance: = INF
	for building in FireService.current.buildings:
		if building is House and building.name.begins_with(prefix) and not building.ruined:
			var distance: = building.position.distance_to(Vector3(120, 0, 40))
			if distance < best_distance:
				best = building
				best_distance = distance
	return best



func _take_tool(tool_name: String) -> Dictionary:
	var tools: = ToolService.current
	for item: Dictionary in tools.items:
		if item["name"] == tool_name and item["holder"] == null and not item["standing"]:
			tools._on_line(player, item)
			return item
	print("NO TOOL ", tool_name)
	return {}




func _take_kit(kit_name: String) -> bool:
	var cordon: = Cordon.current
	for item: Dictionary in cordon.items:
		if item["name"] == kit_name and item["holder"] == null:
			cordon._take(item, player)
			return true
	return cordon.carries(player, kit_name)



func _hold_prompt(prompt: Prompt, off: Vector3, done: Callable) -> bool:
	_stand_by(prompt.global_position, off)
	await _wait(0.3)
	await _hold("interact", prompt.hold + 0.6)
	await _wait(0.3)
	return done.call()



func _stand_outside(house: Building, point: Vector3, off: float, level: = true) -> Vector3:
	var out: = Vector3(point.x - house.position.x, 0, point.z - house.position.z)

	var across: Vector3 = house.place.basis.x if house.place != Transform3D.IDENTITY else Vector3.RIGHT
	var deep: Vector3 = house.place.basis.z if house.place != Transform3D.IDENTITY else Vector3.BACK
	var half: = Vector3(out.dot(across), 0, out.dot(deep))
	out = (across * signf(half.x) if absf(half.x) > absf(half.z) else deep * signf(half.z))
	out = Vector3(out.x, 0, out.z).normalized()
	var at: = _ground(Vector3(point.x, point.y, point.z) + out * off)
	player.teleport(at + Vector3(0, 0.3, 0))
	_look_at(Vector3(point.x, player.head_position().y if level else point.y, point.z))
	return out


func _scenario_entry() -> void :
	await _wait(1.0)
	var house: = _house("Family house")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--building="):
			house = _house(arg.substr(11))
	house.lock_up(true)
	var door: Dictionary = house.outside_door()
	var leaf: PartNode = door["leaf"]
	var lock_at: Vector3 = door["lock"].global_position
	print("entry: %s at %s; %s is %s" % [house.name, house.position, door["name"], "locked" if door["locked"] else "NOT LOCKED"])
	var out: = _stand_outside(house, lock_at, 4.0)
	await _wait(0.5)
	_view(lock_at + out * 14.0 + out.cross(Vector3.UP) * 7.0 + Vector3(0, 4, 0), lock_at)


	print("entry: offered on E with empty hands: '%s', hold %.1f s" % [Text.say(player.prompt.action, "en") if player.prompt != null else "nothing", player.prompt.hold if player.prompt != null else -1.0])
	await _tap("interact")
	await _wait(0.4)
	print("entry: after E with no tool: locked %s, open %s" % [door["locked"], door["open"]])
	_check(door["locked"] and not door["open"], "a locked door only rattles with empty hands")
	await _snap("refused")


	_take_tool("Axe")
	await _wait(0.4)
	print("entry: with the %s in hand (forces %s): '%s', hold %.1f s; hotbar %s" % [player.get_attr("Tool"), player.get_attr("ToolForces"), Text.say(player.prompt.action, "en") if player.prompt != null else "nothing", player.prompt.hold if player.prompt != null else -1.0, _slots()])
	await get_tree().process_frame
	Input.action_press("interact")
	await _wait(1.3)
	print("entry: 1.3 s into the hold: locked %s, held %.1f s" % [door["locked"], player.prompt_held.get("interact", -1.0)])
	await _snap("forcing")
	await _wait(float(Config.Tools.ForceTime) - 1.3 + 0.4)
	Input.action_release("interact")
	await _wait(0.8)
	print("entry: after the hold: locked %s, open %s, swung %.2f" % [door["locked"], door["open"], door["amount"]])
	_check( not door["locked"] and door["open"], "the axe held on the lock forces the door open")
	await _snap("forced")


	var panes: Array = []
	for room_name: String in house.rooms:
		if int(house.rooms[room_name]["floor"]) == 0:
			for pane: Dictionary in house.rooms[room_name]["panes"]:
				panes.append(pane)
	print("entry: %d ground-floor panes" % panes.size())
	var struck: Dictionary = panes[0]
	out = _stand_outside(house, struck["position"], 4.5, false)
	await _wait(0.4)
	_view(struck["position"] + out * 13.0 + out.cross(Vector3.UP) * 6.0 + Vector3(0, 3, 0), struck["position"])
	print("entry: at a pane of the %s, %.1f studs off (reach %s)" % [struck["room"], player.root_position().distance_to(struck["position"]), Config.Tools.GlassReach])
	await _snap("pane_whole")
	await _tap("fire")
	await _wait(0.15)
	print("entry: mid-swing: swings %s, broken %s" % [ToolService.current.held_tool(player).get_attr("Swing"), struck["broken"]])
	await _wait(0.6)
	print("entry: after the swing: broken %s" % struck["broken"])
	_check(struck["broken"], "a swing of the axe breaks a pane")
	await _snap("pane_struck")


	var wet: Dictionary = panes[panes.size() - 1]
	for pane: Dictionary in panes:
		if not pane["broken"] and pane["position"].distance_to(struck["position"]) > 12.0:
			wet = pane
			break
	out = _stand_outside(house, wet["position"], 16.0, false)
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, wet["position"] + out * 45.0, atan2(out.x, out.z) + PI / 2)
	await _wait(0.8)
	var hoses: = HoseService.current
	hoses._connect_line(hoses.lines[0], player)
	(hoses.lines[0]["hose"] as HoseLine).lay_to(player.global_position)
	await _wait(0.3)
	_view_player()
	_look_at(wet["position"])
	await _wait(0.3)
	print("entry: nozzle on a pane of the %s from %.0f studs; tool now '%s', hotbar %s" % [wet["room"], player.root_position().distance_to(wet["position"]), player.get_attr("Tool", ""), _slots()])
	Input.action_press("fire")
	var held: = 0.0
	while not wet["broken"] and held < 6.0:
		await _wait(0.1)
		held += 0.1
	print("entry: pane under the jet: broken %s after %.1f s of trigger (wetted %.2f of %s s)" % [wet["broken"], held, wet["wetted"], Config.Fire.GlassWaterTime])
	_check(wet["broken"], "a jet held on a pane breaks it")
	await _wait(0.3)
	await _snap("pane_jet")
	Input.action_release("fire")
	await _done()





func _scenario_extinguisher() -> void :
	await _wait(1.0)
	var at: = _ground(Vector3(4, 0, -18))
	var out: = [false]
	var made: = FireService.current.spot(at + Vector3(0, 0.5, 0), func(_who: Player) -> void : out[0] = true)
	made["intensity"] = 0.3
	player.teleport(at + Vector3(0, 0.3, 9))
	await _wait(0.5)
	var item: = _take_tool("Extinguisher")
	await _wait(0.3)
	_look_at(at + Vector3(0, 1.5, 0))
	_view(at + Vector3(14, 6, 10), at + Vector3(0, 2, 4))
	await _wait(0.5)
	var cash: = int(player.get_attr("Cash", 0))
	print("extinguisher: a street fire of intensity %.2f at %.0f studs; charge %.1f s, reach %s" % [made["intensity"], player.root_position().distance_to(made["position"]), item["charge"], Config.Tools.Extinguisher.Reach])
	await _snap("before")
	await get_tree().process_frame
	Input.action_press("fire")
	var held: = 0.0
	var snapped: = false
	while not out[0] and held < 13.0:
		await _wait(0.1)
		held += 0.1
		if held > 1.0 and not snapped:
			snapped = true
			print("extinguisher: 1 s in: using %s, damage %.1f, charge %.1f" % [item["using"], made["damage"], item["charge"]])
			await _snap("powder")
	Input.action_release("fire")
	await _wait(0.6)
	print("extinguisher: out %s after %.1f s; charge left %.1f s; spots left %d; cash %d -> %d" % [out[0], held, item["charge"], FireService.current.spots.size(), cash, int(player.get_attr("Cash", 0))])
	_check(out[0], "the extinguisher puts a street fire out")
	await _snap("after")
	await _done()




func _scenario_reticle() -> void :
	await _wait(1.0)
	var hoses: = HoseService.current
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	player.teleport(_ground(pumper.global_transform * Vector3(9, 0, 12)) + Vector3(0, 0.3, 0))
	await _wait(0.3)

	var nearest: Variant = null
	for line: Dictionary in hoses.lines:
		if line["kind"] == "outlet" and line["rig"] != null and line["rig"]["vehicle"] == pumper and (nearest == null or line["source"].global_position.distance_to(player.global_position) < nearest["source"].global_position.distance_to(player.global_position)):
			nearest = line
	if nearest != null:
		hoses._on_outlet(nearest, player)
	await _wait(1.1)
	print("reticle: holding '%s', line %s" % [player.holding, hoses.line_of(player) != null])
	var at: = _ground(player.global_position + Vector3(0, 0, 22))
	var out: = [false]
	var made: = FireService.current.spot(at + Vector3(0, 0.5, 0), func(_who: Player) -> void : out[0] = true)
	made["intensity"] = 0.6
	var sight: HudReticle = Hud.current.crosshair
	await _aim_view(at + Vector3(14, 3, 0))
	await _wait(0.6)
	print("reticle: looking away: shown %s, aimed %.2f" % [sight.visible, sight._aimed])
	await _snap("idle")
	await _aim_view(at + Vector3(0, 1.0, 0))
	await _wait(0.6)
	print("reticle: on the fire: aimed %.2f" % sight._aimed)
	_check(sight._aimed > 0.5, "the sight shows it is on the fire")
	await _snap("aimed")
	Input.action_press("fire")
	var held: = 0.0
	var snapped: = false
	var green: = false
	while held < 20.0 and not green:
		await get_tree().process_frame
		held += get_process_delta_time()
		if held > 1.5 and not snapped:
			snapped = true
			print("reticle: spraying: hitting %s, spraying %.2f, progress %.2f" % [player.get_attr("HittingFire"), sight._spraying, sight._progress])
			await _snap("spraying")
		if fmod(held, 2.0) < get_process_delta_time():
			print("reticle: %.1f s: FlameProgress %s, damage %.1f, shown %.2f" % [held, player.get_attr("FlameProgress"), made["damage"], sight._progress])
		if out[0] and sight._success >= 0.1:
			green = true
	print("reticle: out %s after %.1f s; green %s (FlamesOut %s)" % [out[0], held, green, player.get_attr("FlamesOut")])
	_check(out[0] and green, "the fire goes out and the sight turns green")
	await _snap("out")
	Input.action_release("fire")
	await _wait(1.2)
	print("reticle: after: aimed %.2f, success %.2f" % [sight._aimed, sight._success])
	await _snap("after")
	await _done()


func _scenario_fan() -> void :
	await _wait(1.0)
	var house: = _house("Family house")
	var fire: = FireService.current
	fire.run_incident(house)
	await _wait(1.0)
	var incident: = fire.incident
	var door: Dictionary = house.outside_door()
	door["locked"] = false
	house._place_door(door)
	var lock_at: Vector3 = door["lock"].global_position
	var out: = _stand_outside(house, lock_at, 7.0)
	if not door["open"]:
		house._use_door(door, player)
	await _wait(0.8)

	var inside: Variant = house.room_at(lock_at - out * 5.0 + Vector3(0, 2, 0))
	var first: String = inside["name"] if inside != null else ""
	var other: = ""
	for room_name: String in house.rooms:
		if room_name != first and int(house.rooms[room_name]["floor"]) == 1 and other.is_empty():
			other = room_name
	if other.is_empty():
		for room_name: String in house.rooms:
			if room_name != first:
				other = room_name
	print("fan: fire in %s; the door gives onto the %s; the control room is the %s" % [house.name, first, other])

	var exhaust: = first
	if house.rooms[first]["panes"].is_empty():
		for near: String in fire._open_neighbours(house, first):
			if near != other and not house.rooms[near]["panes"].is_empty():
				exhaust = near
				break
	if not house.rooms[exhaust]["panes"].is_empty():
		house.rooms[exhaust]["panes"][0]["shatter"].call(Vector3.ZERO)
	print("fan: a pane of the %s broken for the exhaust" % exhaust)
	incident["rooms"][first]["smoke"] = 1.0
	incident["rooms"][other]["smoke"] = 1.0
	house.show_smoke(first, 1.0)
	await _wait(1.5)
	_view(lock_at - out * 1.0 + Vector3(0, 3.5, 0) + out.cross(Vector3.UP) * 0.5, lock_at - out * 12.0 + Vector3(0, 3, 0), 85.0)
	await _snap("smoke")
	var before: = [float(incident["rooms"][first]["smoke"]), float(incident["rooms"][other]["smoke"])]
	_take_tool("Fan")
	await _wait(0.3)
	_look_at(lock_at - out * 6.0)
	await _wait(0.2)
	await _tap("fire")
	await _wait(0.4)
	var fan: Dictionary = {}
	for item: Dictionary in ToolService.current.items:
		if item["name"] == "Fan" and item["standing"]:
			fan = item
	print("fan: standing %s, %.1f studs from the door, facing in %s; hands '%s', hotbar %s" % [ not fan.is_empty(), fan["tool"].global_position.distance_to(lock_at) if not fan.is_empty() else -1.0, ( - fan["tool"].global_basis.z).dot( - out) > 0.9 if not fan.is_empty() else false, player.holding, _slots()])
	_check( not fan.is_empty(), "a click stands the fan down")
	_view(lock_at + out * 14.0 + out.cross(Vector3.UP) * 8.0 + Vector3(0, 5, 0), lock_at)
	await _snap("standing")
	await _wait(1.6)
	print("fan: in 2 s the %s went %.2f -> %.2f; the %s (no draught) %.2f -> %.2f (the fan takes %s a second)" % [first, before[0], incident["rooms"][first]["smoke"], other, before[1], incident["rooms"][other]["smoke"], Config.Tools.Fan.Smoke])
	_check(float(incident["rooms"][first]["smoke"]) < before[0] - 0.05 and float(incident["rooms"][first]["smoke"]) - before[0] < float(incident["rooms"][other]["smoke"]) - before[1], "the fan clears the room it blows into faster than one it does not reach")
	_view(lock_at - out * 1.0 + Vector3(0, 3.5, 0) + out.cross(Vector3.UP) * 0.5, lock_at - out * 12.0 + Vector3(0, 3, 0), 85.0)
	await _wait(1.5)
	await _snap("cleared")


	await _wait(9.0)
	var path: Array = incident.get("fan_path", [])
	print("fan: after 12 s the %s is at %.2f and the %s at %.2f (fan path %s; fire %s)" % [first, incident["rooms"][first]["smoke"], other, incident["rooms"][other]["smoke"], path, "burning" if not fire.incident.is_empty() else "out"])
	_check(float(incident["rooms"][first]["smoke"]) < 0.35, "the fan clears the room it blows into while the fire burns")
	_check(float(incident["rooms"][other]["smoke"]) < before[1] - 0.2 or other in path, "and the draught reaches the rooms beyond through the open doors")

	player.teleport(fan["tool"].global_position + out * 3.0 + Vector3(0, 0.3, 0))
	_look_at(fan["tool"].global_position + Vector3(0, 1, 0))
	await _wait(0.3)
	print("fan: offered on E: %s" % (Text.say(player.prompt.action, "en") + " · " + Text.say(player.prompt.object, "en") if player.prompt != null else "nothing"))
	await _hold("interact", 0.5)
	await _wait(0.3)
	print("fan: picked up: standing %s, hotbar %s" % [fan["standing"], _slots()])
	_check( not fan["standing"], "E picks the fan up again")
	await _done()


func _scenario_floodlight() -> void :
	await _wait(1.0)
	var sky: Sky3D = get_tree().current_scene.sky
	sky.set_hour(23.0)
	sky.running = false
	await _wait(1.0)
	var at: = _ground(Vector3(4, 0, -18))

	_park(Vehicle.named("Fire Truck"), at + Vector3(24, 0, 0), 0.0)
	player.teleport(at + Vector3(0, 0.3, 0))
	_look_at(player.head_position() + Vector3(1, 0, 0))
	_view(at + Vector3(-14, 12, 20), at + Vector3(16, 2, 0))
	await _wait(0.5)
	print("floodlight: night %s (hour %.0f)" % [Game.night, sky.hour])
	await _snap("dark")
	_take_tool("Floodlight")
	await _wait(0.4)
	await _tap("fire")
	await _wait(0.6)
	var lamp: Node = null
	for item: Dictionary in ToolService.current.items:
		if item["name"] == "Floodlight" and item["standing"]:
			lamp = item["tool"].points.get("Lamp")
			print("floodlight: standing %.1f studs ahead; lamp %s, range %s, energy %s" % [item["tool"].global_position.distance_to(player.global_position), lamp, lamp.spot_range if lamp else 0, lamp.light_energy if lamp else 0])
	if lamp != null:
		var beam: = lamp as SpotLight3D
		print("floodlight: beam at %s pointing %s (player faces %s), angle %s, attenuation %s" % [beam.global_position, - beam.global_basis.z, player.facing(), beam.spot_angle, beam.spot_attenuation])
		_check(beam.visible and beam.light_energy > 0.0 and ( - beam.global_basis.z).dot(player.facing()) > 0.5, "the floodlight stands lit, shining the way the player faced")
	else:
		_fail("no floodlight standing with a lamp")
	await _snap("lit")
	await _done()





func _scenario_ladder() -> void :
	await _wait(1.0)
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var fire: = FireService.current
	var building: Building = null
	var best: = INF
	for other in fire.buildings:
		if other.name.begins_with("House") and not other.ruined and other.position.distance_to(Vector3(120, 0, 40)) < best:
			best = other.position.distance_to(Vector3(120, 0, 40))
			building = other
	fire.run_incident(building)
	await _wait(0.5)
	var flame_at: = building.position
	for flame in Flame.all:
		flame_at = flame.global_position

	var away: = Vector3(0, 0, 1)
	for angle in 8:
		var direction: = Vector3(sin(angle * PI / 4), 0, cos(angle * PI / 4))
		if Game.world.raycast(flame_at + Vector3(0, 4, 0), flame_at + Vector3(0, 4, 0) + direction * 60, World.LAYER_SOLID).is_empty():
			away = direction
			break


	var stand: = _open_spot(flame_at + away * 36.0, away, truck)
	_park(truck, stand, atan2(away.x, away.z) + PI / 2)
	player.teleport(_ground(truck.global_position + away * 12.0) + Vector3(0, 0.3, 0))
	await _wait(1.0)
	truck.fill_water(truck.capacity)
	print("ladder: fire at %s, %d flames; the truck %.0f studs off, %.0f L in its tank" % [building.name, int(fire.incident["count"]), truck.global_position.distance_to(flame_at), truck.water])


	var settling: = 0.0
	while truck.linear_velocity.length() > 0.5 and settling < 8.0:
		await _wait(0.25)
		settling += 0.25
	if settling > 0.0:
		print("ladder: the truck took %.1f s to come to rest (now %.1f studs a second)" % [settling, truck.linear_velocity.length()])
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME + 0.6)
	print("ladder: after the stabilisers: state %s, truck locked %s, frozen %s" % [ladder.state, truck.locked, truck.freeze])
	if not _check(ladder.state == "ready", "the stabilisers go down"):
		await _done()
		return
	ladder.sit(player, false)
	await _wait(0.4)
	print("ladder: at the stand %s, in control %s" % [ladder.at_stand(player), ladder.controller == player])
	_check(ladder.controller == player, "the player takes the turntable's controls")
	_view(truck.global_position + away * 30.0 + away.cross(Vector3.UP) * 34.0 + Vector3(0, 22, 0), (truck.global_position + flame_at) / 2.0 + Vector3(0, 8, 0))


	Input.action_press("move_forward")
	while ladder.elevation < 30.0:
		await _wait(0.1)
	Input.action_release("move_forward")
	var turning: = 0.0
	while turning < 30.0:
		var along: Vector3 = - ladder.turntable.global_basis.z
		var toward: = Vector3(flame_at.x - ladder.turntable.global_position.x, 0, flame_at.z - ladder.turntable.global_position.z).normalized()
		var off: = along.signed_angle_to(toward, Vector3.UP)
		if absf(off) < deg_to_rad(3.0):
			break

		var key: = "move_right" if off < 0.0 else "move_left"
		Input.action_press(key)
		await _wait(0.1)
		turning += 0.1
		Input.action_release(key)
	await _wait(0.6)
	Input.action_press("ladder_extend")
	await _wait(1.5)
	Input.action_release("ladder_extend")
	await _wait(0.3)
	print("ladder: raised %.0f°, turned %.0f° in %.1f s of key, out %.1f studs; basket %.0f studs up; blocked %s" % [ladder.elevation, ladder.turned, turning, ladder.extension, ladder.height(), Text.say(ladder.blocked, "en") if ladder.blocked != null else "no"])


	await _aim_view(flame_at + Vector3(0, 1, 0))
	await _wait(0.3)
	if OS.get_cmdline_user_args().has("--trace"):
		var eye: = player.camera.camera
		var past: = ladder.passes()
		past.append(player.get_rid())
		var hit: = Game.world.raycast(eye.global_position, eye.global_position - eye.global_basis.z * 600.0, World.LAYER_QUERY | World.LAYER_VEHICLE, past)
		print("   camera %s looks %s; flame %s; the ray lands on %s at %s; nozzle %s, basket faces %s" % [eye.global_position, - eye.global_basis.z, flame_at, Game.world.name_hit(hit) if not hit.is_empty() else "nothing", hit.get("position"), ladder.nozzle.global_position, - ladder.basket.global_basis.z])
	var before: = {"count": int(fire.incident["count"]), "out": int(fire.incident["out"]), "water": truck.water}
	await _tap("monitor_water")
	await _wait(1.5)
	print("ladder: monitor spraying %s, on fire %s, aimed %.1f studs from the flame" % [ladder.monitor["spraying"], ladder.monitor["on_fire"], (ladder.monitor["aim"] as Vector3).distance_to(flame_at)])
	_check(ladder.monitor["spraying"], "the monitor's key opens it")
	await _snap("monitor")
	var sprayed: = 1.5
	var walks: Array[float] = [1.0, -1.0, -3.0, -5.0, -7.0, 3.0]
	var walk: = 0
	while not fire.incident.is_empty() and int(fire.incident["count"]) > 0 and sprayed < 25.0:

		var nearest: = flame_at
		var nearest_distance: = INF
		for flame in Flame.all:
			if is_instance_valid(flame) and flame.global_position.distance_to(building.position) < 80.0 and flame.global_position.distance_to(flame_at) < nearest_distance:
				nearest = flame.global_position
				nearest_distance = flame.global_position.distance_to(flame_at)

		if not ladder.monitor["on_fire"]:
			walk = (walk + 1) % walks.size()
		await _aim_view(nearest + Vector3(0, walks[walk], 0))
		truck.fill_water(float(Config.Hose.HydrantFlow) * 0.25)
		await _wait(0.25)
		sprayed += 0.25
	var after_count: = int(fire.incident["count"]) if not fire.incident.is_empty() else 0
	var after_out: = int(fire.incident["out"]) if not fire.incident.is_empty() else -1
	print("ladder: after %.1f s of monitor: flames %d -> %d, out %d -> %s, tank %.0f -> %.0f; call %s" % [sprayed, before["count"], after_count, before["out"], after_out if after_out >= 0 else "all", before["water"], truck.water, "over" if fire.incident.is_empty() else "open"])
	_check(fire.incident.is_empty() or after_out > before["out"], "the monitor puts flames out")
	await _tap("monitor_water")
	await _wait(0.4)
	print("ladder: monitor shut: spraying %s" % ladder.monitor["spraying"])


	_view_player()
	await _tap("basket_camera")
	await _wait(0.6)
	print("ladder: K: from the basket %s; the view follows %s, %.1f studs from the basket's floor" % [ladder.from_basket, player.camera.subject, player.camera.global_position.distance_to(ladder.floor_node.global_position)])
	await _snap("basket_camera")
	await _tap("basket_camera")
	await _wait(0.4)
	print("ladder: K again: from the basket %s; the view follows %s" % [ladder.from_basket, player.camera.subject])


	await _tap("ladder_stow")
	var stowing: = 0.0
	while not ladder.lies_stowed() and stowing < 40.0:
		await _wait(0.25)
		stowing += 0.25
	print("ladder: R: lies stowed %s after %.1f s (turned %.1f°, raised %.1f°, out %.1f)" % [ladder.lies_stowed(), stowing, ladder.turned, ladder.elevation, ladder.extension])
	_check(ladder.lies_stowed(), "R stows the ladder")
	await _tap("veh_exit")
	await _wait(0.8)
	print("ladder: off the stand: seat %s, on the floor %s, %.1f studs above the ground, %.1f studs from the truck's middle; controller %s" % [player.seat, player.is_on_floor(), player.global_position.y - _ground(player.global_position + Vector3(0, -30, 0)).y, Vector2(player.global_position.x - truck.global_position.x, player.global_position.z - truck.global_position.z).length(), ladder.controller])
	_view(truck.global_position + away * 26.0 + away.cross(Vector3.UP) * 14.0 + Vector3(0, 12, 0), truck.global_position + Vector3(0, 4, 0))
	await _snap("off_stand")


	var reach: = player.root_position().distance_to(ladder._perch_prompt.global_position)
	if reach > LadderService.PERCH_REACH:
		var beside: Vector3 = ladder._perch_prompt.global_position
		player.teleport(_ground(Vector3(beside.x, truck.global_position.y, beside.z) + (beside - truck.global_position).normalized() * 5.0) + Vector3(0, 0.3, 0))
		await _wait(0.4)
	_look_at(ladder._perch_prompt.global_position)
	await _wait(0.3)
	print("ladder: offered on E from the ground: %s" % (Text.say(player.prompt.action, "en") + " · " + Text.say(player.prompt.object, "en") if player.prompt != null else "nothing"))
	await _hold("interact", 0.5)
	await _wait(0.4)
	print("ladder: on the perch %s, in control %s (pace %.1f)" % [player.seat == ladder.perch, ladder.controller == player, ladder.pace])
	_check(player.seat == ladder.perch, "E from the ground puts the player in the basket")
	await _tap("veh_exit")
	await _wait(1.0)
	var floor_at: = ladder.floor_node.global_position
	print("ladder: off the perch: seat %s, on the floor %s, %.1f studs above the basket's floor, %.1f from its middle; controller %s" % [player.seat, player.is_on_floor(), player.global_position.y - floor_at.y, Vector2(player.global_position.x - floor_at.x, player.global_position.z - floor_at.z).length(), ladder.controller])
	_view(floor_at + away * 14.0 + away.cross(Vector3.UP) * 8.0 + Vector3(0, 5, 0), floor_at + Vector3(0, 2, 0))
	await _snap("off_perch")


	player.teleport(_ground(truck.global_position + away * 12.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME + 0.8)
	print("ladder: stabilisers raised: state %s, truck locked %s, frozen %s, prompt '%s'" % [ladder.state, truck.locked, truck.freeze, Text.say(ladder._prompt.action, "en")])
	_check( not truck.locked and not truck.freeze, "the stabilisers come up and free the truck")
	var was: = truck.global_position
	truck._board(player, "DoorCabLeft")
	await _wait(0.5)
	Input.action_press("move_forward")
	await _wait(2.5)
	Input.action_release("move_forward")
	if truck.global_position.distance_to(was) < 5.0:

		print("ladder: forward only %.1f studs: backing out" % truck.global_position.distance_to(was))
		Input.action_press("move_back")
		await _wait(3.0)
		Input.action_release("move_back")
	print("ladder: driven off: %.1f studs, speed %.0f" % [truck.global_position.distance_to(was), truck.forward_speed])
	_check(truck.global_position.distance_to(was) > 5.0, "the ladder truck drives off")
	_view(truck.global_position + away * 30.0 + Vector3(0, 12, 0), truck.global_position)
	await _snap("driven")
	await _done()







func _scenario_lever() -> void :
	await _wait(1.0)
	var ladder: = LadderService.current
	var truck: = ladder.vehicle
	var stand: = _open_spot(Vector3(120, 0, 40), Vector3(0, 0, 1), truck)
	_park(truck, stand, 0.0)
	await _wait(1.5)
	var back: = truck.global_basis.z
	var rear: = truck.global_position + back * float(truck.data["rear"])
	player.teleport(_ground(rear + back * 5.0) + Vector3(0, 0.3, 0))
	_view(rear + back * 9.0 + truck.global_basis.x * 3.0 + Vector3(0, 4.5, 0), rear + Vector3(0, 0.5, 0), 50.0)
	await _wait(0.5)
	await _snap("up")
	ladder.use_jacks(player)
	await _wait(LadderService.JACK_TIME * 0.5)
	await _snap("going")
	await _wait(LadderService.JACK_TIME * 0.5 + 0.6)
	_check(ladder.state == "ready", "the stabilisers go down")
	print("lever: %.0f degrees, lamp lit %s" % [rad_to_deg(ladder._lever.rotation.z), ladder._lever_lamp.visible])
	_check(ladder._lever.rotation.z < 0.0 and ladder._lever_lamp.visible, "the lever is over and the lamp lit")
	await _snap("down")
	_view(rear + back * 30.0 + Vector3(0, 9, 0), truck.global_position)
	await _wait(0.4)
	await _snap("road")

	var road_from: = _ground(Vector3(-322.6, 0, 45.4))
	var road_to: = _ground(Vector3(-385.5, 0, 68.3))
	_view(road_from + Vector3(0, 30, 0) + (road_from - road_to).normalized() * 10.0, (road_from + road_to) / 2.0)
	await _wait(0.6)
	await _snap("street")
	await _done()


func _scenario_course() -> void :
	await _wait(1.0)
	var course: = TrainingCourse.current
	var hoses: = HoseService.current
	var lane: int = course.targets.keys()[0]
	var target: Dictionary = course.targets[lane]
	var at: Vector3 = target["pivot"].global_position + Vector3(0, 3, 0)
	for piece: Variant in target["pieces"]:
		at = (piece as Node3D).global_position
	var pumper: = Vehicle.named("Fire Truck")

	var back: = Vector3(0, 0, 1) if absf(float(course.zone["start"]) - at.z) > 1.0 and float(course.zone["start"]) > at.z else Vector3(0, 0, -1)
	var stand: = _ground(at + back * 9.0) + Vector3(0, 0.3, 0)
	print("course: zone %s" % course.zone)
	_park(pumper, stand + back * 50.0 + Vector3(18, 0, 0))
	await _wait(0.8)
	player.teleport(stand)
	await _wait(0.3)
	hoses._connect_line(hoses.lines[0], player)
	(hoses.lines[0]["hose"] as HoseLine).lay_to(player.global_position)
	_look_at(at)
	await _wait(0.8)
	await _aim_view(at)
	_view(stand + Vector3(11, 5, 0) + back * 4.0, (stand + at) / 2.0 + Vector3(0, 3, 0))
	await _wait(0.5)
	print("course: target in lane %d at %s, %.0f studs off; down %s" % [lane, at, player.root_position().distance_to(at), target["down"]])
	await _snap("standing")
	await get_tree().process_frame
	Input.action_press("fire")
	var held: = 0.0
	while not target["down"] and held < 6.0:
		await _wait(0.05)
		held += 0.05
	print("course: target down %s after %.2f s of water (it takes %s s on it); sprayed %.2f" % [target["down"], held, TrainingCourse.TARGET_HOLD, target["sprayed"]])
	_check(target["down"], "water on the target knocks it down")
	await _wait(0.5)
	await _snap("down")
	Input.action_release("fire")
	await _wait(TrainingCourse.TARGET_DOWN + 1.0)
	print("course: %.0f s later it is %s" % [TrainingCourse.TARGET_DOWN + 1.0, "down still" if target["down"] else "standing again"])
	_check( not target["down"], "the target stands up again")
	await _done()





func _scenario_lost() -> void :
	await _wait(1.0)
	var people: = VictimService.current
	var fire: = FireService.current
	var house: = _house("Family house")
	people.forced = 2
	fire.run_incident(house)
	await _wait(1.0)
	var door: Dictionary = house.outside_door()
	var out: = _stand_outside(house, door["lock"].global_position, 16.0)
	var outside: = player.global_position
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, outside + out * 22.0, atan2(out.x, out.z) + PI / 2)
	await _wait(0.8)
	print("lost: %d inside %s: %s" % [people.total, house.name, people.victims.map( func(v: Victim) -> String: return "%s in the %s" % [v.state, v.room])])
	var first: Victim = people.victims[0]
	var second: Victim = people.victims[1] if people.victims.size() > 1 else null


	player.teleport(first.position() + Vector3(1.5, 0.2, 0))
	_look_at(first.position())
	await _wait(0.4)
	print("lost: offered on E: %s" % (Text.say(player.prompt.action, "en") + " · " + Text.say(player.prompt.object, "en") if player.prompt != null else "nothing"))
	await _hold("interact", float(Config.Victims.LiftTime) + 0.3)
	await _wait(0.3)
	print("lost: the first is %s by %s; hands '%s', walking at %.0f" % [first.state, first.carrier, player.holding, player.walk_speed])
	_check(first.carrier == player, "E held on a casualty lifts them")
	player.teleport(outside)
	_look_at(outside + out * 10.0 + Vector3(0, 3, 0))
	await _wait(0.5)
	_view(outside + out * 16.0 + out.cross(Vector3.UP) * 12.0 + Vector3(0, 7, 0), outside + out * 6.0 + Vector3(0, 2, 0))
	await _snap("carried")


	var stood: = player.global_position
	pumper.set_door("DoorCabLeft", true)
	await _wait(0.7)
	pumper._board(player, "DoorCabLeft")
	await _wait(0.6)
	var lying: = first.position()
	print("lost: the carrier at the wheel: the first is %s, %.1f studs from where the carrier stood, %.1f above the ground, %.1f from the truck's middle; carrying %s" % [first.state, Vector2(lying.x - stood.x, lying.z - stood.z).length(), lying.y - _ground(Vector3(lying.x, lying.y + 1.0 - 40.0, lying.z)).y, lying.distance_to(pumper.global_position), player.get_attr("Carrying", false)])
	_check(first.state == "lying" and Vector2(lying.x - stood.x, lying.z - stood.z).length() < 6.0, "getting into a truck puts the casualty down where the carrier stood")
	await _snap("boarded")
	pumper.leave(player)
	await _wait(0.5)


	if first.state == "lying":
		player.teleport(first.position() + Vector3(1.5, 0.2, 0))
		_look_at(first.position())
		await _wait(0.4)
		await _hold("interact", float(Config.Victims.LiftTime) + 0.3)
		await _wait(0.3)
	player.teleport(outside + out.cross(Vector3.UP) * 8.0)
	await _wait(0.5)
	var fell: = player.global_position
	print("lost: carrying again: %s" % first.state)
	player.take_damage(1000.0)
	await _wait(0.6)
	lying = first.position()
	print("lost: the carrier fell: the first is %s, %.1f studs from where that happened; the carrier is %.0f studs away, health %.0f, carrying %s, hands '%s'" % [first.state, Vector2(lying.x - fell.x, lying.z - fell.z).length(), player.global_position.distance_to(fell), player.health, player.get_attr("Carrying", false), player.holding])
	_check(first.state == "lying" and Vector2(lying.x - fell.x, lying.z - fell.z).length() < 6.0, "a carrier who falls leaves the casualty where it happened")
	_view(fell + out * 14.0 + Vector3(0, 6, 0), lying)
	await _snap("fell")


	player.teleport(outside)
	await _wait(0.5)
	var counts: = [people.total, people.out, people.lost]
	for node: Dictionary in fire.incident["group"]["nodes"]:
		node["fuel"] = 0.0
	var waited: = 0.0
	while not fire.incident.is_empty() and fire.incident["health"] > 0.0 and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(1.0)
	print("lost: the house is lost (charred %s): of %d, out %d -> %d, lost %d -> %d; the first is %s, the second %s; the call's card %s" % [house.ruined or not fire.incident.is_empty(), counts[0], counts[1], people.out, counts[2], people.lost, first.state, second.state if second != null else "-", Game.incident.get("victims_lost", "-")])
	_check(people.lost > counts[2], "the one left inside is lost with the house")
	_view(outside + out * 30.0 + Vector3(0, 16, 0), house.position)
	await _wait(1.0)
	await _snap("lost")

	var ambulance: = AmbulanceService.current
	var zone: Variant = ambulance.zone_position() if ambulance else null
	if first.state == "lying" and zone != null:
		player.teleport(first.position() + Vector3(1.5, 0.2, 0))
		_look_at(first.position())
		await _wait(0.4)
		await _hold("interact", float(Config.Victims.LiftTime) + 0.3)
		await _wait(0.3)
		player.teleport(zone + Vector3(0, 0.5, 0))
		await _wait(1.5)
		print("lost: at the ambulance's box: the first is %s; out %d, lost %d" % [first.state, people.out, people.lost])
		_check(first.state == "out", "the one outside is still handed over at the ambulance")
	else:
		_fail("the first casualty could not be taken to the ambulance (%s, box %s)" % [first.state, zone])
	await _wait(2.0)
	print("lost: the call is %s" % ("closed" if Game.incident.is_empty() else "open still"))
	await _done()






func _stand_by(point: Vector3, off: Vector3) -> void :
	var at: = CallKit.ground_at(point + off)
	player.teleport(at + Vector3(0, 0.3, 0))
	_look_at(Vector3(point.x, player.head_position().y - 1.5, point.z))


func _scenario_saw() -> void :
	await _wait(1.0)
	Config.Incidents["Tree"]["Variant"] = "plain"
	var tree: = FallenTree.current
	tree.run()
	var waited: = 0.0
	while tree.scene.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	if not _check( not tree.scene.is_empty(), "a tree came down"):
		await _done()
		return
	var held: = tree.scene
	var tools: = ToolService.current
	print("saw: %d rings on %d trees; the call's card: %s, %s of %s done" % [held["rings"].size(), held["trees"].size(), Game.incident.get("kind"), Game.incident.get("done"), Game.incident.get("total")])
	var first: Vector3 = held["rings"][0]["position"]
	player.teleport(CallKit.ground_at(first + Vector3(4, 0, 4)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	var item: = _take_tool("Chainsaw")
	await _wait(0.4)
	var tool: = tools.held_tool(player)
	print("saw: in hand '%s', ticking over (idle playing %s); the saw is %s" % [player.get_attr("Tool"), tool.sounds["ChainsawIdle"].playing if tool.sounds.has("ChainsawIdle") else "?", "the tree's" if tools.saw.is_valid() else "NOT SET"])


	for ring: Dictionary in held["rings"]:
		if not ring.has("limb"):
			_stand_by(ring["position"], Vector3(0.5, 0, 2.2))
			await _wait(0.3)
			await _hold("fire", 0.6)
			print("saw: on the trunk with its branches on: progress %.1f, working %s" % [ring["progress"], tool.get_attr("Working")])
			break
	var cash: = int(player.get_attr("Cash", 0))
	var cuts: = 0
	var snapped: = false
	for pass_limbs: bool in [true, false]:
		for ring: Dictionary in held["rings"].duplicate():
			if ring.has("limb") != pass_limbs or ring["done"]:
				continue
			var where: Vector3 = ring["part"].global_position if is_instance_valid(ring["part"]) else ring["position"]
			var side: = FallenTree.cut_side(ring)
			_stand_by(where, side * 2.2 if not side.is_zero_approx() else Vector3(0.5, 0, 2.2))
			await _wait(0.25)
			await get_tree().process_frame
			Input.action_press("fire")
			var sawing: = 0.0
			while not ring["done"] and sawing < 8.0:
				await _wait(0.1)
				sawing += 0.1
				if not pass_limbs and sawing > 1.5 and not snapped:
					snapped = true
					print("saw: in the trunk: trigger held %s, working %s (2 is in the wood), chips flying %s, progress %.1f of %s s" % [tools.trigger_held(player), tool.get_attr("Working"), tool.emitters["Chips"].emitting, ring["progress"], Config.Tools.Chainsaw.CutTime])
					_view(where + Vector3(7, 5, 8), where + Vector3(0, 1.5, 0))
					await _snap("cutting")
			Input.action_release("fire")
			await _wait(0.2)
			cuts += 1 if ring["done"] else 0
			if not ring["done"]:
				print("saw: a %s was NOT cut in %.1f s" % ["branch" if pass_limbs else "trunk ring", sawing])
	print("saw: %d of %d rings cut by the trigger; trigger let go: working %s; cash %d -> %d; the card says %s of %s" % [cuts, held["rings"].size(), tool.get_attr("Working"), cash, int(player.get_attr("Cash", 0)), Game.incident.get("done"), Game.incident.get("total")])
	var loose: = 0
	for piece: Dictionary in held["pieces"]:
		if piece["free"]:
			loose += 1
	print("saw: %d of %d lengths lie loose" % [loose, held["pieces"].size()])
	_check(cuts == held["rings"].size(), "every ring cut by the saw's trigger")
	_check(loose > 0, "the cut lengths lie loose")
	_view(first + Vector3(18, 12, 18), first)
	await _wait(0.5)
	await _snap("cut")
	await _done()


func _start_crash(layout: String, engine_chance: float) -> Dictionary:
	Config.Incidents["Crash"]["Layout"] = layout
	Config.Incidents["Crash"]["EngineFire"]["Chance"] = engine_chance
	var crash: = CarCrash.current
	CallService.current.run_call("crash", crash.run)
	var waited: = 0.0
	while crash.scene.is_empty() and waited < 10.0:
		await _wait(0.25)
		waited += 0.25
	await _wait(0.5)
	return crash.scene


func _scenario_crash() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 0.0)
	if not _check( not held.is_empty(), "a crash came"):
		await _done()
		return
	var crash: = CarCrash.current
	var tools: = ToolService.current
	print("crash: %d doors to work; the card: %s, %s of %s done" % [held["doors"].size(), Game.incident.get("kind"), Game.incident.get("done"), Game.incident.get("total")])
	var door: Dictionary = held["doors"][0]
	var where: Vector3 = door["position"]
	var out: Vector3 = door["car"]["place"].basis.x * door["outward"]
	player.teleport(CallKit.ground_at(where + out * 5.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	_take_tool("Spreader")
	_take_tool("Cutter")
	await _wait(0.4)
	print("crash: hotbar %s; the tools are %s" % [_slots(), "the crash's" if tools.hydraulic.is_valid() else "NOT SET"])
	_stand_by(where, out * 3.0)
	_view(where + out * 11.0 + out.cross(Vector3.UP) * 7.0 + Vector3(0, 5, 0), where + Vector3(0, 1.5, 0))
	await _wait(0.3)


	await _hold("fire", 0.8)
	print("crash: the cutter on a jammed door: stage %d, progress %.1f" % [door["stage"], door["progress"]])

	var car: Dictionary = door["car"]
	var behind: Vector3 = (car["place"] as Transform3D).basis.z
	var prep: Prompt = car["prompt"]
	_check(prep != null and prep.enabled and car["stable"] == false, "a wreck with somebody in it is to be stabilised (a prompt at its back)")
	await _hold_prompt(prep, behind * 3.0, func() -> bool: return car["stable"])
	_check( not car["stable"], "no stabilising without the step blocks")
	_check(_take_kit("Step blocks"), "the step blocks are on the pumper")
	_check( await _hold_prompt(prep, behind * 3.0, func() -> bool: return car["stable"]), "the step blocks stabilise the wreck")
	_check( await _hold_prompt(prep, behind * 3.0, func() -> bool: return car["glass"]), "its glass taken out")
	_view(prep.global_position + behind * 9.0 + Vector3(5, 5, 0), prep.global_position)
	await _wait(0.3)
	await _snap("stabilised")
	_stand_by(where, out * 3.0)
	_view(where + out * 11.0 + out.cross(Vector3.UP) * 7.0 + Vector3(0, 5, 0), where + Vector3(0, 1.5, 0))
	await _wait(0.3)

	await _tap("slot_1")
	await _wait(0.3)
	print("crash: key 1: in hand '%s', hotbar %s" % [player.get_attr("Tool"), _slots()])
	var tool: = tools.held_tool(player)
	await get_tree().process_frame
	Input.action_press("fire")
	var worked: = 0.0
	var snapped: = false
	while door["stage"] == 1 and worked < 9.0:
		await _wait(0.1)
		worked += 0.1
		if worked > 2.0 and not snapped:
			snapped = true
			print("crash: 2 s in: trigger held %s, working %s (2 is at a door), progress %.2f on the tool, sparks %s" % [tools.trigger_held(player), tool.get_attr("Working"), float(tool.get_attr("Progress", 0.0)), tool.emitters["Sparks"].emitting])
			await _snap("spreader")
	Input.action_release("fire")
	await _wait(0.3)
	print("crash: the spreader held %.1f s (a job takes %s): the door is at stage %d; working now %s" % [worked, Config.Incidents.Crash.JobTime, door["stage"], tool.get_attr("Working")])
	_check(door["stage"] == 2, "the spreader forces the jammed door")

	await _tap("slot_2")
	await _wait(0.3)
	tool = tools.held_tool(player)
	print("crash: key 2: in hand '%s'" % player.get_attr("Tool"))
	await get_tree().process_frame
	Input.action_press("fire")
	worked = 0.0
	snapped = false
	while door["stage"] == 2 and worked < 9.0:
		await _wait(0.1)
		worked += 0.1
		if worked > 2.0 and not snapped:
			snapped = true
			await _snap("cutter")
	Input.action_release("fire")
	await _wait(0.5)
	var victim: Victim = door["victim"]
	print("crash: the cutter held %.1f s: the door is at stage %d (3 is off); its casualty is %s; the card says %s of %s; cash %d" % [worked, door["stage"], victim.state if victim != null else "nobody", Game.incident.get("done"), Game.incident.get("total"), int(player.get_attr("Cash", 0))])
	_check(door["stage"] == 3, "the cutter takes the door off")
	await _snap("door_off")

	await _wait(0.6)
	var pace: = 100.0 / float(Config.Incidents.Crash.TrappedTime)
	_check(victim.state == "trapped" and is_equal_approx(victim.drain, pace * float(Config.Incidents.Crash.FreedDrain)), "with the door off the casualty still weakens, at FreedDrain (%.3f a second)" % victim.drain)
	_check( not victim.prompt.enabled, "nobody is lifted out before first aid and the board")
	var aid: Prompt = door["prompt"]
	_check(_take_kit("First aid kit"), "the first aid kit is on the pumper")
	_check( await _hold_prompt(aid, out * 3.0, func() -> bool: return door["stage"] == 4), "first aid at the door")
	await _wait(0.5)
	_check(is_zero_approx(victim.drain), "after first aid the casualty holds steady")
	_check(_take_kit("Spinal board"), "the spinal board is on the pumper")
	_check( await _hold_prompt(aid, out * 3.0, func() -> bool: return door["stage"] == 5), "on the spinal board")
	_check(victim.state == "lying" and door["board"] != null, "boarded, the casualty lies free on the board, to be lifted")
	_view(where + out * 10.0 + Vector3(0, 7, 0), victim.position())
	await _wait(0.4)
	await _snap("boarded")

	player.teleport(_ground(victim.position() + out * 3.0) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	_check(VictimService.current.lift(victim, player), "the casualty on the board is lifted")
	await _wait(0.5)
	var board: Node3D = door["board"]
	var ahead: = (victim.figure.global_position - player.global_position)
	print("crash: carried on the board: mode %s, board visible %s, figure %.1f ahead and %.1f up, pace %.1f" % [victim.mode, board.visible and board.is_visible_in_tree(), Vector2(ahead.x, ahead.z).length(), ahead.y, VictimService.current.pace_of(victim)])
	_check(victim.state == "carried" and victim.mode == "board", "carried on the board, not over the shoulder")
	_check(board.visible and board.is_visible_in_tree(), "the board goes with them")
	_check(Vector2(ahead.x, ahead.z).length() > 2.0 and ahead.y > 0.5 and ahead.y < 4.0, "lying flat ahead of the carrier")
	_check(VictimService.current.pace_of(victim) < float(Config.Victims.CarrySpeed), "slow alone with a board (two carry it faster)")
	_view(player.global_position + player.global_basis.x * 11.0 + Vector3(0, 4, 0), victim.figure.global_position)
	await _wait(0.3)
	await _snap("board_carry")
	VictimService.current.put_down(victim)
	await _wait(0.4)
	_check(victim.state == "lying" and victim.on_board and board.visible, "put down, they still lie on the board")

	var under: = _ground(board.global_position + Vector3(0, 3, 0))
	var low: = (board.global_transform * (board as MeshInstance3D).get_aabb()).position.y
	print("crash: put down: the board's middle %.2f above the ground, its lowest %.2f" % [board.global_position.y - under.y, low - under.y])
	_check(absf(low - under.y) < 0.6, "put down, the board lies on the ground")
	_view(victim.figure.global_position + player.global_basis.x * 9.0 + Vector3(0, 3, 0), victim.figure.global_position)
	await _wait(0.3)
	await _snap("board_down")
	await _done()





func _scenario_engine() -> void :
	await _wait(1.0)
	var held: = await _start_crash("headOn", 1.0)
	var engine: Variant = held.get("engine") if not held.is_empty() else null
	if not _check(engine != null, "a wreck with a smoking engine"):
		await _done()
		return
	var at: Vector3 = engine["car"]["engine"].global_position
	var front: Vector3 = - engine["car"]["place"].basis.z

	var side: Vector3 = engine["car"]["place"].basis.x
	var stand: = _ground(at + side * 7.0 + Vector3(0, -30, 0))
	player.teleport(stand + Vector3(0, 0.3, 0))
	_look_at(at)
	_view(at + side * 16.0 + front * 9.0 + Vector3(0, 6, 0), at)
	await _wait(1.5)
	print("engine: %s; offered on E: %s, hold %.0f s; the clock %s" % [engine["state"], Text.say(player.prompt.action, "en") + " · " + Text.say(player.prompt.object, "en") if player.prompt != null else "nothing", player.prompt.hold if player.prompt != null else 0.0, "running (%.0f s)" % engine["left"] if engine["left"] >= 0.0 else "not started"])
	await _snap("smoking")
	if OS.get_cmdline_user_args().has("--battery"):

		var cash: = int(player.get_attr("Cash", 0))
		await get_tree().process_frame
		Input.action_press("interact")
		await _wait(1.5)
		print("engine: 1.5 s into the hold: %s" % engine["state"])
		await _wait(float(Config.Incidents.Crash.EngineFire.BatteryTime) - 1.5 + 0.4)
		Input.action_release("interact")
		await _wait(0.5)
		print("engine: after the hold: %s; prompt enabled %s; cash %d -> %d" % [engine["state"], engine["prompt"].enabled, cash, int(player.get_attr("Cash", 0))])
		engine["left"] = 0.2
		await _wait(1.5)
		print("engine: with its clock run out anyway: %s, flame %s" % [engine["state"], engine["flame"] != null])
		_check(engine["state"] != "burning" and engine["flame"] == null, "with the battery off the engine does not catch")
		await _snap("safe")
		await _done()
		return

	engine["left"] = 0.5
	await _wait(1.5)
	var trapped: Array = engine["trapped"]
	print("engine: %s; flame %s; battery prompt enabled %s; %d trapped in it, draining %s a second" % [engine["state"], engine["flame"] != null, engine["prompt"].enabled, trapped.size(), trapped[0].drain if not trapped.is_empty() else 0.0])
	_check(engine["state"] == "burning", "left alone, the engine catches")
	await _wait(1.0)
	await _snap("burning")

	_take_tool("Extinguisher")
	await _wait(0.4)
	_look_at(at + Vector3(0, 0.6, 0))
	await get_tree().process_frame
	Input.action_press("fire")
	var sprayed: = 0.0
	while engine["state"] == "burning" and sprayed < 12.5:
		await _wait(0.1)
		sprayed += 0.1
		if is_equal_approx(sprayed, 1.0):
			await _snap("powder")
	Input.action_release("fire")
	await _wait(0.6)
	print("engine: %s after %.1f s of powder; spots left %d; trapped now draining %s" % [engine["state"], sprayed, FireService.current.spots.size(), trapped[0].drain if not trapped.is_empty() else 0.0])
	_check(engine["state"] != "burning", "the extinguisher puts the engine fire out")
	await _snap("out")
	await _done()





func _scenario_crowd() -> void :
	await _wait(1.0)
	var crowd: = Bystanders.current
	var people: = Pedestrians.current
	var fire: = FireService.current
	var building: Building = null
	var best: = INF
	for other in fire.buildings:
		if other.name.begins_with("House") and not other.ruined and other.position.distance_to(Vector3(120, 0, 40)) < best:
			best = other.position.distance_to(Vector3(120, 0, 40))
			building = other
	Config.Life["GatherChance"] = 0.6
	fire.run_incident(building)
	player.teleport(_ground(building.position + Vector3(0, 0, 60)) + Vector3(0, 0.3, 0))
	var watching: Array = []
	var waited: = 0.0
	while waited < 70.0:
		await _wait(1.0)
		waited += 1.0
		watching = []
		if not crowd.scene.is_empty():
			for person: Pedestrians.Person in crowd.scene["crowd"]:
				if person.state == "watch":
					watching.append(person)
		if watching.size() >= 4:
			break
	if not _check( not watching.is_empty(), "onlookers came to watch"):
		await _done()
		return
	var band: Vector2 = crowd.scene["band"]
	print("crowd: %d watching of %d sent after %.0f s; they watch from %.0f to %.0f studs off" % [watching.size(), crowd.scene["crowd"].size(), waited, band.x, band.y])


	var middle: = Vector3.ZERO
	for person: Pedestrians.Person in watching:
		middle += people.where(person)
	middle /= watching.size()
	var nearest: Pedestrians.Person = watching[0]
	for person: Pedestrians.Person in watching:
		if people.where(person).distance_to(middle) < people.where(nearest).distance_to(middle):
			nearest = person
	var hub: = people.where(nearest)
	var toward: = Vector3(building.position.x - hub.x, 0, building.position.z - hub.z).normalized()
	player.teleport(_ground(hub + toward * 7.0) + Vector3(0, 0.3, 0))
	_view_player()
	_look_at(hub + Vector3(0, 3, 0))
	await _wait(0.6)
	var heard: Array = []
	var before: Dictionary = {}
	for person: Pedestrians.Person in crowd.scene["crowd"]:
		var offset: Vector3 = people.where(person) - player.root_position()
		offset.y = 0.0
		if offset.length() < float(Config.Life.MoveBackRange) and (offset.length() < 4.0 or offset.normalized().dot(player.facing()) > -0.2):
			heard.append(person)
			before[person] = [crowd.scene["crowd"][person]["spot"]["far"], people.where(person)]
	_view(player.global_position + toward * 16.0 + toward.cross(Vector3.UP) * 10.0 + Vector3(0, 10, 0), hub)
	await _snap("before")
	print("crowd: %d of the crowd within %s studs in front of the firefighter, standing %s studs off the fire" % [heard.size(), Config.Life.MoveBackRange, heard.map( func(p: Pedestrians.Person) -> int: return int(before[p][0]))])
	await _tap("pattern")
	await _wait(1.0)
	await _snap("order")
	await _wait(9.0)
	var moved: = 0
	var further: = 0
	var now_far: Array = []
	for person: Pedestrians.Person in heard:
		if not crowd.scene["crowd"].has(person):
			continue
		var far: float = crowd.scene["crowd"][person]["spot"]["far"]
		now_far.append(int(far))
		if far > float(before[person][0]) + 1.0:
			further += 1
		if people.where(person).distance_to(before[person][1]) > 3.0:
			moved += 1
	print("crowd: 10 s after the order: %d of %d were given a place further off (now %s studs), %d have walked more than 3 studs; held back until %s" % [further, heard.size(), now_far, moved, "t+%.0f s" % (float(crowd.scene["crowd"][heard[0]]["held_until"]) - Game.now()) if not heard.is_empty() and crowd.scene["crowd"].has(heard[0]) else "-"])
	_check( not heard.is_empty() and further > 0, "the order on foot sends the onlookers in front further off")
	await _snap("after")



	var truck: = Vehicle.named("Command Vehicle")
	var stand_at: = _open_spot(hub, - toward, truck)
	_park(truck, stand_at, atan2( - toward.x, - toward.z))
	await _wait(1.0)
	truck._board(player, "DoorCabLeft")
	await _wait(0.5)
	var ahead: = 0
	var places: Dictionary = {}
	for person: Pedestrians.Person in people.people.values():
		var offset: Vector3 = people.where(person) - truck.global_position
		offset.y = 0.0
		if offset.length() < float(Config.Life.HornRange) and offset.normalized().dot( - truck.global_basis.z) > -0.2:
			ahead += 1
			places[person] = [people.where(person), crowd.scene["crowd"][person]["spot"]["far"] if crowd.scene["crowd"].has(person) else -1.0]
	var sounded: = [0]
	truck.horn.connect( func() -> void : sounded[0] += 1)
	await _tap("veh_horn")
	await _wait(8.0)
	moved = 0
	further = 0
	for person: Pedestrians.Person in places:
		if people.where(person).distance_to(places[person][0]) > 3.0:
			moved += 1
		if crowd.scene["crowd"].has(person) and float(crowd.scene["crowd"][person]["spot"]["far"]) > float(places[person][1]) + 1.0:
			further += 1
	print("crowd: the horn sounded %d time(s): of %d people within %s studs ahead of the truck, %d were sent further off and %d have walked more than 3 studs" % [sounded[0], ahead, Config.Life.HornRange, further, moved])


	var movable: = 0
	for person: Pedestrians.Person in places:
		if float(places[person][1]) < 0.0 or float(places[person][1]) < float(crowd.scene["band"].y) - 4.0:
			movable += 1
	print("crowd: %d of them could still be moved back" % movable)
	_check(sounded[0] > 0 and (movable == 0 or further > 0 or moved > 0), "the horn moves people ahead of the truck that can still go back")
	_view(truck.global_position + toward * 20.0 + Vector3(0, 14, 0) + toward.cross(Vector3.UP) * 12.0, hub)
	await _snap("horn")
	await _done()





func _scenario_cordon() -> void :
	await _wait(1.0)
	var cordon: = Cordon.current
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, Vector3(-12, 0, -22))
	await _wait(0.6)
	player.teleport(_ground(Vector3(6, 0, -14)) + Vector3(0, 0.3, 0))
	_look_at(player.head_position() + Vector3(1, 0, 0.4))
	await _wait(0.3)
	_locker_line(pumper, "Cones").chosen.emit(player)
	await _wait(0.3)
	print("cordon: cones taken: hotbar %s, hands '%s'" % [_slots(), player.holding])
	_locker_line(pumper, "Barrier tape").chosen.emit(player)
	await _wait(0.3)
	print("cordon: tape taken too: hotbar %s (the cones are on the belt, not back in the locker: held by %s)" % [_slots(), _locker_line(pumper, "Cones").holder != null])
	_take_tool("Axe")
	await _wait(0.3)
	print("cordon: an axe taken: hotbar %s, tool '%s'" % [_slots(), player.get_attr("Tool")])

	await _tap("slot_2")
	await _wait(0.2)
	print("cordon: key 2: hotbar %s, tool '%s'" % [_slots(), player.get_attr("Tool")])
	_view(player.global_position + Vector3(8, 5, 9), player.global_position + Vector3(3, 2, 0))
	await _tap("fire")
	await _wait(0.3)
	player.teleport(player.global_position + Vector3(0, 0, 5))
	await _tap("fire")
	await _wait(0.3)
	print("cordon: two clicks with the cones in hand: %d cones standing" % cordon.cordon["cones"].size())
	_check(cordon.cordon["cones"].size() == 2, "two clicks with the cones stand two")
	await _snap("cones")
	await _tap("slot_3")
	await _wait(0.2)
	await _tap("fire")
	player.teleport(player.global_position + Vector3(12, 0, 0))
	await _wait(0.3)
	await _tap("fire")
	await _wait(0.3)
	print("cordon: key 3 and two clicks: hotbar %s, %d tapes stretched" % [_slots(), cordon.cordon["tapes"].size()])
	_check(cordon.cordon["tapes"].size() >= 1, "two clicks with the tape stretch it")
	await _tap("slot_3")
	await _wait(0.2)
	print("cordon: key 3 again puts it on the belt: hotbar %s, hands '%s'" % [_slots(), player.holding])
	await _snap("tape")

	await _tap("slot_2")
	await _wait(0.2)
	var hoses: = HoseService.current
	hoses._connect_line(hoses.lines[0], player)
	(hoses.lines[0]["hose"] as HoseLine).lay_to(player.global_position)
	await _wait(0.3)
	print("cordon: a hose taken with the cones in hand: hotbar %s, hands '%s'" % [_slots(), player.holding])
	player.take_damage(1000.0)
	await _wait(0.5)
	print("cordon: the carrier fell: hotbar %s; cones held by %s, tape by %s; hose line %s" % [_slots(), _locker_line(pumper, "Cones").holder, _locker_line(pumper, "Barrier tape").holder, hoses.line_of(player)])
	_check(_locker_line(pumper, "Cones").holder == null and _locker_line(pumper, "Barrier tape").holder == null and hoses.line_of(player) == null, "a carrier who falls puts the cones, the tape and the hose back")
	await _done()
