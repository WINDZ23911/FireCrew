class_name Escalation
extends RefCounted









static var shown: Dictionary = {}
static var _searched: Dictionary = {}
static var _report_at: = -1.0
static var _hot_for: = 0.0
static var _evacuate_at: = -1.0
static var _fallen: = false
static var _tick: = 0.0
static var _other_after: = -1.0



static func show(key: String, value: Variant) -> void :
	if value == null:
		shown.erase(key)
		Game.incident.erase(key)
	else:
		shown[key] = value
		if not Game.incident.is_empty():
			Game.incident[key] = value


static func reset() -> void :
	for key: String in shown.keys():
		Game.incident.erase(key)
	shown = {}
	_searched = {}
	_report_at = -1.0
	_hot_for = 0.0
	_evacuate_at = -1.0
	_fallen = false
	_other_after = -1.0




static func begin_other(possible: Array) -> void :
	reset()
	if not Alarm.draw_escalation(possible).is_empty():
		var after: Array = Config.Alarm.Escalations.After
		_other_after = randf_range(float(after[0]), float(after[1]))




static func due() -> String:
	if _other_after < 0.0 or Alarm.arrived_at < 0.0 or Game.now() < Alarm.arrived_at + _other_after:
		return ""
	_other_after = -1.0
	if Alarm.escalation.is_empty():
		return ""
	Game.notify(Text.m("calls.escalation." + Alarm.escalation), "danger")
	return Alarm.escalation



static func calm() -> void :
	_report_at = -1.0
	if _evacuate_at > 0.0 and not _fallen:
		_evacuate_at = -1.0
		_hot_for = 0.0
		show("evacuate", null)



static func evacuating() -> bool:
	return _evacuate_at > 0.0 and not _fallen



static func _crew_out(building: Building) -> void :
	var crew: = CrewService.current
	if crew == null:
		return
	var reach: = 30.0
	if building is House:
		var size: Array = (building as House).data["size"]
		reach = Vector2(float(size[0]), float(size[2])).length() / 2.0
	for mind: Crewman in crew.members:
		if building.room_at(mind.body.root_position()) == null:
			continue
		var away: = (mind.body.global_position - building.position) * Vector3(1, 0, 1)
		away = away.normalized() if away.length() > 0.5 else Vector3.BACK
		mind.give(JobGoto.new(crew.ground(building.position + away * (reach + 12.0) + Vector3(0, 6, 0))))



static func can_collapse(building: Building) -> bool:
	if not building.has_rooms():
		return false
	if Alarm.forced_escalation == "collapse":
		return true
	return building is House and (building as House).data.get("collapse", false) == true



static func fire_begin(building: Building) -> void :
	reset()
	var possible: Array = []
	if building.has_rooms():
		possible.append("reported")
	if can_collapse(building):
		possible.append("collapse")
	if Alarm.draw_escalation(possible) == "reported":
		var after: Array = Config.Alarm.Reported.After
		_report_at = Game.now() + randf_range(float(after[0]), float(after[1]))



static func fire_step(fire: FireService, group: Dictionary, dt: float) -> void :
	var building: Building = group["building"]
	_tick += dt
	if _tick >= 0.5:
		_tick = 0.0
		for player in Game.players:
			var room: Variant = building.room_at(player.root_position())
			if room != null:
				_searched[room["name"]] = true

	if _report_at > 0.0 and Game.now() >= _report_at and Alarm.arrived_at >= 0.0:
		_report_at = -1.0
		if VictimService.current and VictimService.current.add_one(_searched):
			Game.notify(Text.m("calls.escalation.reported"), "danger")

	if Alarm.escalation == "collapse":
		_watch_roof(fire, group, dt)


static func _watch_roof(fire: FireService, group: Dictionary, dt: float) -> void :
	var s: Dictionary = Config.Alarm.Collapse
	var building: Building = group["building"]
	if _fallen:

		for node: Dictionary in group["nodes"]:
			if node["burning"]:
				node["fuel"] = maxf(node["fuel"] - (float(s["Loss"]) - 1.0) * (0.3 + 0.7 * node["intensity"]) * dt, 0.01)
		return
	if _evacuate_at < 0.0:
		var heat: = 0.0
		for node: Dictionary in group["nodes"]:
			if node["burning"]:
				heat += node["intensity"]
		_hot_for = _hot_for + dt if heat >= float(s["Heat"]) else maxf(_hot_for - dt * 0.5, 0.0)
		if _hot_for >= float(s["HotFor"]) or float(fire.incident.get("health", 100.0)) < float(s["Health"]):
			_evacuate_at = Game.now() + float(s["Countdown"])
			Game.notify(Text.m("calls.escalation.collapse.order"), "danger")
			sound_evacuation(building.position)
			Net.broadcast("fire.evacuate", [building.position])
			_crew_out(building)
		return
	var left: = _evacuate_at - Game.now()
	if left > 0.0:
		show("evacuate", ceili(left))
		return
	_fallen = true
	show("evacuate", null)
	show("collapsed", true)
	var top: = building.position + Vector3(0, building.height / 2.0, 0)
	Blast.at(top, 24.0, 1.4, 0.7)
	building.show_collapse(true)
	var index: = fire.buildings.find(building)
	if index >= 0:
		Net.broadcast("fire.collapse", [index, true])
	var hurt: = 0
	for player in Game.players:
		var room: Variant = building.room_at(player.root_position())
		if room != null and not room.get("open", false):
			player.take_damage(float(s["Damage"]) * (1.0 - player.heat_protection()))
			hurt += 1
	Game.notify(Text.m("calls.escalation.collapse.fallen" if hurt == 0 else "calls.escalation.collapse.caught"), "danger")




static func sound_evacuation(at: Vector3) -> void :
	for blast in 3:
		Game.get_tree().create_timer(blast * 1.6, false).timeout.connect( func() -> void :
			Sounds.once_at(at, "horn", 2.5, 60.0, 1200.0, 0.92))
