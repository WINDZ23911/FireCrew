extends RefCounted



const STEEL: = Color8(176, 178, 182)
const GLASS: = Color8(46, 56, 66)


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("Doors")
	var doors: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		var place: Transform3D = shell["place"]
		var rng: = kit.rng("doors:%d" % shell["model"])
		for door: int in shell["rows"].get("Door", []):
			var frame: = store.transform(door)
			var size: = store.size(door)
			var thin: = 0
			for axis in [1, 2]:
				if size[axis] < size[thin]:
					thin = axis
			var out: = frame.basis[thin].normalized()
			if out.dot(frame.origin - place.origin) < 0.0:
				out = - out
			out = Vector3(out.x, 0.0, out.z).normalized()
			var side: = Vector3.UP.cross(out).normalized()
			var across: = 0.0
			var tall: = 0.0
			for axis in 3:
				var along: Vector3 = frame.basis[axis].normalized()
				across = maxf(across, absf(along.dot(side)) * size[axis])
				tall = maxf(tall, absf(along.y) * size[axis])
			if across < 2.5 or tall < 6.0:
				continue
			var face: = frame.origin + out * (size[thin] / 2.0)
			var foot: = frame.origin.y - tall / 2.0
			var basis: = Basis( - side, Vector3.UP, - out)
			var lock: = 1.0 if rng.randf() < 0.5 else -1.0

			var at: = face + side * lock * (across / 2.0 - 0.75)
			at.y = foot + 3.5
			kit.box(folder, Transform3D(basis, at + out * 0.03), Vector3(0.28, 0.7, 0.06), STEEL, "Metal", "DoorRose")
			kit.box(folder, Transform3D(basis, at + out * 0.2 - side * lock * 0.3 + Vector3(0, 0.15, 0)), Vector3(0.75, 0.13, 0.13), STEEL, "Metal", "DoorLever")

			var light: = face + Vector3(0, foot + tall - 2.4 - face.y, 0) + out * 0.02
			kit.box(folder, Transform3D(basis, light), Vector3(across * 0.55, 1.5, 0.05), GLASS, "Glass", "DoorLight")
			doors += 1
	return "%d doors furnished" % doors
