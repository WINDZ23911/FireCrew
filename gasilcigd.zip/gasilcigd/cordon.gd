class_name Cordon
extends Node3D
















const WHITE: = Color8(240, 240, 236)
const RED: = Color8(205, 40, 36)
const POST_HEIGHT: = 3.6
const TAPE_HEIGHT: = 3.1
const CHECK_EVERY: = 5.0


const RESCUE_KIT: = {
	"Step blocks": {"spot": Vector3(-2.1, 3.6, 12.4), "turn": Vector3(0, 90, 0), "build": "build_blocks", "icon": "shield"}, 
	"First aid kit": {"spot": Vector3(0.0, 3.5, 12.6), "turn": Vector3(0, 90, 0), "build": "build_kit", "icon": "heart"}, 
	"Spinal board": {"spot": Vector3(-0.2, 3.0, 12.4), "turn": Vector3(0, 90, 0), "build": "build_board", "icon": "stand"}, 
}



const PUMP_BAY: = {
	"Cones": {"spot": Vector3(2.45, 3.0, 12.95)}, 
	"Barrier tape": {"spot": Vector3(-2.45, 3.0, 12.95)}, 
	"Step blocks": {"spot": Vector3(1.45, 3.6, 12.95), "turn": Vector3.ZERO}, 
	"First aid kit": {"spot": Vector3(0.0, 3.5, 13.25)}, 
	"Spinal board": {"spot": Vector3(-3.2, 5.0, 12.4), "turn": Vector3.ZERO}, 
}

static var current: Cordon


var cordon: = {"version": 0, "cones": [], "tapes": []}
var items: Array = []
var _cone_stock: Dictionary = {}
var _in_hand: Dictionary = {}
var _watched: Dictionary = {}
var _elapsed: = 0.0
var _made: = 0
var _mirroring: = false
var _net_cones: Dictionary = {}
var _net_tapes: Dictionary = {}
var _net_firsts: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _changed() -> void :
	cordon["version"] += 1




func made() -> int:
	return _made




func carries(player: Player, item_name: String) -> bool:
	for item: Dictionary in items:
		if item["name"] == item_name and item["holder"] == player:
			return true
	return false









static func road_ends(middle: Vector3, along: Vector3, room: float, reach: float) -> Array:
	var settings: Dictionary = Config.Incidents.Road
	var ends: = [false, false]
	var across: = Vector3(along.z, 0, - along.x)
	var count: = func(at: Vector3, most_run: float, most_aside: float) -> void :
		var offset: = Vector3(at.x - middle.x, 0, at.z - middle.z)
		var run: = offset.dot(along)
		if absf(run) >= room and absf(run) <= most_run and absf(offset.dot(across)) <= most_aside and offset.length() <= most_run:
			ends[0 if run < 0.0 else 1] = true
	var cordon: Dictionary = NavGraph.current.cordon if NavGraph.current else {}
	for cone: Dictionary in cordon.get("cones", []):
		count.call(Vector3(cone["x"], 0, cone["z"]), reach, reach)
	for tape: Dictionary in cordon.get("tapes", []):
		count.call(Vector3((tape["ax"] + tape["bx"]) / 2.0, 0, (tape["az"] + tape["bz"]) / 2.0), reach, reach)
	var truck_reach: float = settings["TruckReach"]
	var aside: float = settings["TruckAside"]
	for vehicle in Vehicle.all:
		if is_instance_valid(vehicle) and vehicle.is_inside_tree() and absf(vehicle.forward_speed) < 2.0:
			count.call(vehicle.global_position, truck_reach, aside)
	if settings["PoliceCloses"] and ScenePolice.current != null:
		var pose: Array = ScenePolice.current.pose_now()
		if pose[1] == "parked":
			count.call((pose[0] as Transform3D).origin, truck_reach, aside)
	return ends






static func build_cone(parent: Node3D, place: Transform3D) -> void :
	_model(parent, "Cone", place)



static func build_post(parent: Node3D, place: Transform3D) -> void :
	_model(parent, "Tape post", place)



static func build_reel(parent: Node3D, place: Transform3D) -> void :
	_model(parent, "Tape reel", place)



static func build_blocks(parent: Node3D, place: Transform3D) -> void :
	var wood: = Color8(214, 168, 72)
	for step in 3:
		var length: = 1.5 - step * 0.45
		CallKit.piece(parent, CallKit.BLOCK, Vector3(0.9, 0.32, length), place * Transform3D(Basis.IDENTITY, Vector3(0, -1.25 + step * 0.32, (1.5 - length) / 2.0)), wood.darkened(step * 0.06))
	CallKit.piece(parent, CallKit.BLOCK, Vector3(0.95, 0.9, 0.1), place * Transform3D(Basis.IDENTITY, Vector3(0, -0.6, 0)), Color8(40, 40, 44))



static func build_kit(parent: Node3D, place: Transform3D) -> void :
	CallKit.piece(parent, CallKit.BLOCK, Vector3(0.55, 0.85, 1.3), place * Transform3D(Basis.IDENTITY, Vector3(0, -0.75, 0)), Color8(200, 34, 34))
	for side: float in [-1.0, 1.0]:
		CallKit.piece(parent, CallKit.BLOCK, Vector3(0.04, 0.5, 0.16), place * Transform3D(Basis.IDENTITY, Vector3(side * 0.29, -0.75, 0)), Color.WHITE, 0.3)
		CallKit.piece(parent, CallKit.BLOCK, Vector3(0.04, 0.16, 0.5), place * Transform3D(Basis.IDENTITY, Vector3(side * 0.29, -0.75, 0)), Color.WHITE, 0.3)
	CallKit.piece(parent, CallKit.BLOCK, Vector3(0.12, 0.25, 0.6), place * Transform3D(Basis.IDENTITY, Vector3(0, -0.22, 0)), Color8(30, 30, 32))



static func build_board(parent: Node3D, place: Transform3D) -> void :
	CallKit.piece(parent, CallKit.BLOCK, Vector3(0.16, 4.6, 1.45), place * Transform3D(Basis.IDENTITY, Vector3(0, 0.1, 0.55)), Color8(236, 112, 30))
	for index in 4:
		CallKit.piece(parent, CallKit.BLOCK, Vector3(0.18, 0.5, 0.22), place * Transform3D(Basis.IDENTITY, Vector3(0, -1.6 + index * 1.15, 1.12)), Color8(30, 30, 32))



static func _model(parent: Node3D, kind: String, place: Transform3D) -> void :
	var mesh: = MeshInstance3D.new()
	mesh.name = kind.replace(" ", "")
	mesh.mesh = ToolModels.of(kind)["body"]
	mesh.transform = place
	parent.add_child(mesh)







func _ground_ahead(player: Player) -> Variant:
	if player.health <= 0.0 or player.seat != null:
		return null
	var look: = player.facing()
	var flat: = Vector3(look.x, 0, look.z).normalized()
	var ahead: = player.root_position() + flat * 4.0
	var ground: = Game.world.raycast(ahead + Vector3(0, 3, 0), ahead + Vector3(0, -9, 0), World.LAYER_SOLID, [player.get_rid()])
	if ground.is_empty():
		Game.notify(Text.m("gear.cordon.nowhere"), "", player)
		return null
	var at: Vector3 = ground["position"]
	return Rbx.look_at(at, at + flat)





func remove_cone(cone: Dictionary) -> void :
	var cones: Array = cordon["cones"]
	for index in cones.size():
		if is_same(cones[index], cone):
			cones.remove_at(index)
			cone["model"].queue_free()
			_cone_stock[cone["truck"]] += 1
			_changed()
			return



func stand_cone_at(truck: Vehicle, place: Transform3D) -> Dictionary:
	_made += 1
	var model: = _cone_model(place, _made)
	var cone: = {"x": place.origin.x, "z": place.origin.z, "model": model, "truck": truck, "id": _made, "place": place}
	var prompt: Prompt = model.get_meta("prompt")
	prompt.triggered.connect( func(_player: Player) -> void : remove_cone(cone))
	_cone_stock[truck] -= 1
	cordon["cones"].append(cone)
	_changed()
	return cone



func _cone_model(place: Transform3D, id: int) -> Node3D:
	var model: = Node3D.new()
	model.name = "Traffic cone"
	add_child(model)
	model.global_transform = place
	build_cone(model, Transform3D.IDENTITY)
	var prompt: = CallKit.prompt(model, "cordon.cone.%d" % id, Text.m("gear.cordon.coneAction"), Text.m("gear.cordon.cone"), 0.3, 9.0)
	prompt.position = Vector3(0, 1.0, 0)
	model.set_meta("prompt", prompt)
	return model


func _stand_cone(item: Dictionary, player: Player) -> void :
	var truck: Vehicle = item["truck"]
	if _cone_stock[truck] <= 0:
		Game.notify(Text.m("gear.cordon.noCones"), "", player)
		return
	var place: Variant = _ground_ahead(player)
	if place == null:
		return
	if player.brain != null:
		player.set_down_ahead()
	stand_cone_at(truck, place)["by"] = player
	if _cone_stock[truck] == 0:
		Game.notify(Text.m("gear.cordon.lastCone"), "", player)





func remove_tape(tape: Dictionary) -> void :
	var tapes: Array = cordon["tapes"]
	for index in tapes.size():
		if is_same(tapes[index], tape):
			tapes.remove_at(index)
			tape["model"].queue_free()
			_changed()
			return



func stretch_between(truck: Vehicle, from: Vector3, to: Vector3, model: Node3D = null) -> Dictionary:
	_made += 1
	model = _tape_model(from, to, _made, model)
	var tape: = {"ax": from.x, "az": from.z, "bx": to.x, "bz": to.z, "model": model, "truck": truck, "id": _made, "from": from, "to": to}
	for prompt: Prompt in model.get_meta("prompts"):
		prompt.triggered.connect( func(_player: Player) -> void : remove_tape(tape))
	cordon["tapes"].append(tape)
	_changed()
	return tape




func _tape_model(from: Vector3, to: Vector3, id: int, model: Node3D = null) -> Node3D:
	if model == null:
		model = _lone_post(from)
	build_post(model, Transform3D(Basis.IDENTITY, to))
	var span: = Vector3(to.x - from.x, 0, to.z - from.z)
	var middle: = (from + to) / 2.0 + Vector3(0, TAPE_HEIGHT, 0)
	var along: = Rbx.look_at(middle, middle + span)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.06, 0.55, span.length()), along, WHITE)
	CallKit.piece(model, CallKit.BLOCK, Vector3(0.08, 0.2, span.length()), along, RED)
	var prompts: Array = []
	for index in 2:
		var prompt: = CallKit.prompt(model, "cordon.tape.%d.%d" % [id, index], Text.m("gear.cordon.tapeAction"), Text.m("gear.cordon.tape"), 0.3, 9.0)
		prompt.position = [from, to][index] + Vector3(0, POST_HEIGHT / 2.0, 0)
		prompts.append(prompt)
	model.set_meta("prompts", prompts)
	return model



func _lone_post(at: Vector3) -> Node3D:
	var model: = Node3D.new()
	model.name = "Barrier tape"
	add_child(model)
	build_post(model, Transform3D(Basis.IDENTITY, at))
	return model




func _stretch_tape(item: Dictionary, player: Player) -> void :
	var settings: Dictionary = Config.Life
	var found: Variant = _ground_ahead(player)
	if found == null:
		return
	if player.brain != null:
		player.set_down_ahead()
	var place: Transform3D = found
	if item["first"] == null:
		var out: = 0
		for tape: Dictionary in cordon["tapes"]:
			if tape["truck"] == item["truck"]:
				out += 1
		if out >= int(settings["Tapes"]):
			Game.notify(Text.m("gear.cordon.reelEmpty"), "", player)
			return
		item["first"] = {"place": place, "model": _lone_post(place.origin)}
		Game.notify(Text.m("gear.cordon.tapeEnd"), "", player)
		return

	var from: Vector3 = item["first"]["place"].origin
	var to: = place.origin
	var span: = Vector3(to.x - from.x, 0, to.z - from.z)
	if span.length() < 4.0:
		Game.notify(Text.m("gear.cordon.tapeTooClose"), "", player)
		return
	elif span.length() > float(settings["TapeLength"]):
		Game.notify(Text.f("gear.cordon.tapeTooFar", [Ui.length(float(settings["TapeLength"]) * float(Config.Hud.MetresPerStud))]), "", player)
		return
	var model: Node3D = item["first"]["model"]
	item["first"] = null
	stretch_between(item["truck"], from, to, model)["by"] = player







func _stock(truck: Vehicle, where: Dictionary, tool_name: String, build: Callable, use: Callable, dropped: = Callable()) -> void :
	var lockers: = Lockers.of(truck)
	if lockers == null or not truck.shutters.has(where["locker"]):
		return
	if truck.data.get("pumpBay", false) and where["locker"] == "Rear" and PUMP_BAY.has(tool_name):
		where = where.merged(PUMP_BAY[tool_name], true)
	var shown: Variant = Text.named("tools", tool_name)
	var line: = lockers.add_line(where["locker"], Text.m("gear.tools.take"), shown, where.get("category", "cordon"), where.get("icon", ToolIcons.of(tool_name)))

	var stowed: = Node3D.new()
	stowed.name = "Stowed " + tool_name.to_lower()
	truck.body.add_child(stowed)
	stowed.position = where["spot"]
	stowed.rotation_degrees = where.get("turn", Vector3.ZERO)
	build.call(stowed, Transform3D.IDENTITY)
	var item: = {"name": tool_name, "truck": truck, "line": line, "stowed": stowed, "holder": null, "tool": null, "first": null, "use": use, "dropped": dropped, "build": build}
	items.append(item)
	line.chosen.connect( func(player: Player) -> void :
		var holder: Player = item["holder"]
		if holder == player:
			put_back(item)
			Game.notify(Text.f("gear.tools.onTruck", [shown]), "", player)
			return
		elif holder != null:
			Game.notify(Text.f("gear.tools.heldBy", [shown, holder.display_name]), "", player)
			return
		if player.health <= 0.0:
			return
		_take(item, player)
	)


func _take(item: Dictionary, player: Player) -> void :

	if ToolService.current:
		ToolService.current.clear_hands(player)
	elif _in_hand.has(player):
		put_back(_in_hand[player])
	_show_taken(item, player)
	_set_in_hand(item, true)

	item["entry"] = {
		"name": item["name"], 
		"in_hand": func() -> bool: return item["holder"] != null and _in_hand.get(item["holder"]) != null and is_same(_in_hand[item["holder"]], item), 
		"set_in_hand": func(on: bool) -> void : _set_in_hand(item, on), 
	}
	if ToolService.current:
		ToolService.current.carry_other(player, item["entry"])
	_tell_carried(player)
	if not _watched.has(player):
		_watched[player] = true
		player.died.connect( func() -> void :
			for other: Dictionary in items:
				if other["holder"] == player:
					put_back(other)
		)
	Game.notify(Text.m("gear.tools.tips." + item["name"]), "", player)




func _show_taken(item: Dictionary, player: Player) -> void :
	var tool: = Node3D.new()
	tool.name = String(item["name"]).replace(" ", "")
	player.rig.hand_right.add_child(tool)

	tool.set_meta("hold", "cone" if item["name"] == "Cones" else "reel")
	item["build"].call(tool, Transform3D.IDENTITY)
	item["holder"] = player
	item["tool"] = tool
	item["line"].holder = player
	item["line"].action = Text.m("gear.tools.back")
	item["stowed"].visible = false



func _show_back(item: Dictionary) -> void :
	if item["tool"] != null and is_instance_valid(item["tool"]):
		item["tool"].queue_free()
	item["holder"] = null
	item["tool"] = null
	item["line"].holder = null
	item["line"].action = Text.m("gear.tools.take")
	item["stowed"].visible = true




func _tell_carried(player: Variant) -> void :
	if not is_instance_valid(player):
		return
	var names: Array = []
	for item: Dictionary in items:
		if item["holder"] == player:
			names.append(item["name"])
	player.set_attr("CordonCarried", names if not names.is_empty() else null)



func _set_in_hand(item: Dictionary, on: bool) -> void :
	var holder: Player = item["holder"]
	if holder == null or not is_instance_valid(holder):
		return
	if is_instance_valid(item["tool"]):
		item["tool"].visible = on
	if on:
		_in_hand[holder] = item
		holder.holding = "tool"
		holder.set_attr("Tool", item["name"])
	elif _in_hand.get(holder) != null and is_same(_in_hand[holder], item):
		_in_hand.erase(holder)
		if holder.get_attr("Tool") == item["name"]:
			holder.set_attr("Tool", null)
			if holder.holding == "tool" and holder.get_attr("Supply") == null:
				holder.holding = ""



func put_back(item: Dictionary) -> void :
	var holder: Variant = item["holder"]
	if holder != null and is_instance_valid(holder):
		_set_in_hand(item, false)
		if ToolService.current and item.get("entry") != null:
			ToolService.current.drop_other(holder, item["entry"])
	_show_back(item)
	_tell_carried(holder)
	var dropped: Callable = item["dropped"]
	if dropped.is_valid():
		dropped.call(item)



func held(player: Player) -> Variant:
	return _in_hand.get(player)



func activate(player: Player) -> void :
	var item: Variant = _in_hand.get(player)
	if item != null:
		if player.is_local and player.camera != null:
			player.camera.face_view(0.6)
		item["use"].call(item, player)


func start() -> void :
	if NavGraph.current:
		NavGraph.current.cordon = cordon
	Net.share("cordon", _net_state, _net_apply, 5.0)
	Net.stopped.connect( func() -> void : _net_apply({}, true))

	Net.handle("cordon.use", func(player: Player) -> void : activate(player))


	Net.peer_left.connect( func(player: Player) -> void :
		if not Net.is_host():
			return
		for item: Dictionary in items:
			if item["holder"] == player:
				put_back(item)
		_in_hand.erase(player)
		_watched.erase(player)
	)

	for vehicle in Vehicle.all:
		var cones: Variant = vehicle.spec.get("cones")
		if cones is Dictionary:
			_cone_stock[vehicle] = int(Config.Life.Cones)
			_stock(vehicle, cones, "Cones", build_cone, _stand_cone)
		var tape: Variant = vehicle.spec.get("tape")
		if tape is Dictionary:
			_stock(vehicle, tape, "Barrier tape", build_reel, _stretch_tape, func(item: Dictionary) -> void :

				if item["first"] != null:
					item["first"]["model"].queue_free()
					item["first"] = null
			)

		if vehicle.spec.get("pumper", false) and cones is Dictionary:
			for kit: String in RESCUE_KIT:
				var where: Dictionary = RESCUE_KIT[kit].duplicate()
				where["locker"] = cones["locker"]
				where["category"] = "rescue"
				var build: Callable = {"build_blocks": build_blocks, "build_kit": build_kit, "build_board": build_board}[where["build"]]
				_stock(vehicle, where, kit, build, _kit_click)

		var own_kit: Dictionary = vehicle.spec.get("rescueKit", {})
		for kit: String in own_kit:
			var where: Dictionary = RESCUE_KIT[kit].duplicate()
			where.merge(own_kit[kit], true)
			where["category"] = "rescue"
			var build: Callable = {"build_blocks": build_blocks, "build_kit": build_kit, "build_board": build_board}[where["build"]]
			_stock(vehicle, where, kit, build, _kit_click)



func _kit_click(item: Dictionary, player: Player) -> void :
	Game.notify(Text.m("gear.tools.tips." + item["name"]), "", player)


func _process(delta: float) -> void :

	var me: = Game.local_player
	var clicked: = me != null and me.camera != null and me.camera.captured and not Game.ui_open and Input.is_action_just_pressed("fire")
	if Net.is_client():
		if clicked and _in_hand.has(me):
			me.camera.face_view(0.6)
			me.set_down_ahead()
			Net.request("cordon.use")
		return

	for player: Variant in _in_hand.keys():
		var item: Dictionary = _in_hand[player]
		if not is_instance_valid(player) or player.health <= 0.0:
			put_back(item)
			continue
		var taken: bool = player.get_attr("Line") != null or player.get_attr("Supply") != null or player.get_attr("Carrying", false) == true or player.seat != null
		if taken or (ToolService.current and not ToolService.current.hands_free(player)):
			_set_in_hand(item, false)
			if ToolService.current:
				ToolService.current.carried_changed.emit(player)
			continue
		if player.holding == "":
			player.holding = "tool"
		if player == me and clicked:
			me.set_down_ahead()
			Net.request("cordon.use")


	_elapsed += delta
	if _elapsed < CHECK_EVERY:
		return
	_elapsed = 0.0
	var leash: float = Config.Life.CordonLeash
	for cone: Dictionary in cordon["cones"].duplicate():
		var at: Vector3 = cone["truck"].global_position
		if (cone["x"] - at.x) ** 2 + (cone["z"] - at.z) ** 2 > leash * leash:
			remove_cone(cone)
	for tape: Dictionary in cordon["tapes"].duplicate():
		var at: Vector3 = tape["truck"].global_position
		if (tape["ax"] - at.x) ** 2 + (tape["az"] - at.z) ** 2 > leash * leash:
			remove_tape(tape)








func _net_state() -> Variant:
	var cones: Array = []
	for cone: Dictionary in cordon["cones"]:
		cones.append([cone["id"], cone["place"]])
	var tapes: Array = []
	for tape: Dictionary in cordon["tapes"]:
		tapes.append([tape["id"], tape["from"], tape["to"]])
	var firsts: Dictionary = {}
	var held_by: Array = []
	for index in items.size():
		var item: Dictionary = items[index]
		if item["first"] != null:
			firsts[index] = item["first"]["place"].origin
		var holder: Variant = item["holder"]
		var there: = is_instance_valid(holder)
		held_by.append([Net.peer_of(holder) if there else 0, there and _in_hand.get(holder) != null and is_same(_in_hand[holder], item)])
	return {"cones": cones, "tapes": tapes, "firsts": firsts, "items": held_by}



func _net_apply(state: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not state is Dictionary or (leaving and not _mirroring):
		return
	_mirroring = not leaving
	var changed: = false
	var told: = {}
	for row: Array in state.get("cones", []):
		told[row[0]] = true
		if not _net_cones.has(row[0]):
			var place: Transform3D = row[1]
			var cone: = {"x": place.origin.x, "z": place.origin.z, "model": _cone_model(place, row[0]), "truck": null, "id": row[0], "place": place}
			_net_cones[row[0]] = cone
			cordon["cones"].append(cone)
			changed = true
	for id: int in _net_cones.keys():
		if not told.has(id):
			_forget(cordon["cones"], _net_cones[id])
			_net_cones.erase(id)
			changed = true
	told = {}
	for row: Array in state.get("tapes", []):
		told[row[0]] = true
		if not _net_tapes.has(row[0]):
			var from: Vector3 = row[1]
			var to: Vector3 = row[2]
			var tape: = {"ax": from.x, "az": from.z, "bx": to.x, "bz": to.z, "model": _tape_model(from, to, row[0]), "truck": null, "id": row[0], "from": from, "to": to}
			_net_tapes[row[0]] = tape
			cordon["tapes"].append(tape)
			changed = true
	for id: int in _net_tapes.keys():
		if not told.has(id):
			_forget(cordon["tapes"], _net_tapes[id])
			_net_tapes.erase(id)
			changed = true
	if changed:
		_changed()

	var firsts: Dictionary = state.get("firsts", {})
	for index: int in _net_firsts.keys():
		if not firsts.has(index) or not is_instance_valid(_net_firsts[index]) or not _net_firsts[index].get_meta("at").is_equal_approx(firsts[index]):
			if is_instance_valid(_net_firsts[index]):
				_net_firsts[index].queue_free()
			_net_firsts.erase(index)
	for index: int in firsts:
		if not _net_firsts.has(index):
			_net_firsts[index] = _lone_post(firsts[index])
			_net_firsts[index].set_meta("at", firsts[index])

	var held_by: Array = state.get("items", [])
	for index in items.size():
		var item: Dictionary = items[index]
		var holder: Player = Net.player_of(held_by[index][0]) if index < held_by.size() and held_by[index][0] != 0 else null
		var was: Variant = item["holder"]
		if was != holder:
			if was != null:
				if _in_hand.get(was) != null and is_same(_in_hand[was], item):
					_in_hand.erase(was)
				_show_back(item)
			if holder != null:
				_show_taken(item, holder)
		if holder != null:
			var in_hand: bool = held_by[index][1]
			if is_instance_valid(item["tool"]):
				item["tool"].visible = in_hand
			if in_hand:
				_in_hand[holder] = item
			elif _in_hand.get(holder) != null and is_same(_in_hand[holder], item):
				_in_hand.erase(holder)


func _forget(list: Array, entry: Dictionary) -> void :
	if is_instance_valid(entry["model"]):
		entry["model"].queue_free()
	for index in list.size():
		if is_same(list[index], entry):
			list.remove_at(index)
			return
