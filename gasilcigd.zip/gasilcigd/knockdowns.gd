class_name Knockdowns
extends Node







const FALL: = 84.0
const ZONE: = 1.4
const NAMES: = {"SignPost": "sign", "SignalPost": "light"}

static var current: Knockdowns

var posts: Array = []
var _by_id: Dictionary = {}
var _since_check: = 0.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	var store: = Game.store
	for part_name: String in NAMES:
		for row in store.rows_named(part_name):
			_make_post(row, NAMES[part_name])
	Net.share("signs.down", _net_state, _net_apply, 2.0)
	print("knockdowns: %d posts a vehicle can run over" % posts.size())


func _make_post(row: int, kind: String) -> void :
	var store: = Game.store
	var id: = store.id_at(row)
	var place: = store.transform(row)
	var size: = store.size(row)
	var axis: = size.max_axis_index()
	var length: = size[axis]
	var along: Vector3 = place.basis[axis].normalized()
	if along.y < 0.0:
		along = - along
	var foot: = place.origin - along * length / 2.0

	var plates: Array[int] = []
	for other: int in store.rows_under.get(store.parent(row), PackedInt32Array()):
		if other == row or NAMES.has(store.name_at(other)):
			continue
		var at: = store.position(other)
		if Vector2(at.x - foot.x, at.z - foot.z).length() <= 1.8:
			plates.append(other)

	Game.world.set_solid(id, false)
	var body: = StaticBody3D.new()
	body.collision_layer = World.LAYER_POST
	body.collision_mask = 0
	var shape: = CollisionShape3D.new()
	var round: = CylinderShape3D.new()
	round.radius = maxf(minf(size.x, minf(size.y, size.z)) / 2.0, 0.15)
	round.height = length
	shape.shape = round
	body.add_child(shape)
	add_child(body)
	body.global_transform = Transform3D(Basis(Quaternion(Vector3.UP, along)), foot + along * length / 2.0)
	var area: = Area3D.new()
	area.collision_layer = 0
	area.collision_mask = World.LAYER_VEHICLE
	area.monitorable = false
	var zone: = CollisionShape3D.new()
	var reach: = CylinderShape3D.new()
	reach.radius = ZONE
	reach.height = 5.0
	zone.shape = reach
	area.add_child(zone)
	add_child(area)
	area.global_position = foot + Vector3(0, 2.5, 0)
	var post: = {
		"id": id, "row": row, "kind": kind, "foot": foot, "along": along, "length": length, "body": body, "shape": shape, 
		"area": area, "plates": plates, "down": false, "since": 0.0, "fall": Vector3.FORWARD, "pivot": null, "parts": [], 
		"lamps": [], "decals": {}, "tween": null, 
	}
	area.body_entered.connect( func(hit: Node3D) -> void : _on_hit(post, hit))
	posts.append(post)
	_by_id[id] = post


func _on_hit(post: Dictionary, hit: Node3D) -> void :
	if Net.is_client() or post["down"] or not hit is Vehicle:
		return
	var vehicle: = hit as Vehicle
	var speed: Vector3 = vehicle.linear_velocity
	speed.y = 0.0
	var kmh: = speed.length() * float(Config.Hud.MetresPerStud) * 3.6
	if kmh < float(Config.Signs.MinKmh):
		return
	var fall: = speed.normalized() if speed.length() > 0.1 else - vehicle.global_basis.z
	knock(post, fall, vehicle.driver())



func knock(post: Dictionary, fall: Vector3, who: Player = null) -> void :
	post["down"] = true
	post["since"] = Game.now()
	post["fall"] = Vector3(fall.x, 0.0, fall.z).normalized() if Vector2(fall.x, fall.z).length() > 0.01 else Vector3.FORWARD
	(post["shape"] as CollisionShape3D).set_deferred("disabled", true)
	_topple(post, true)
	Sounds.once(post["area"], "vehicle_thud", 0.8, 12.0, 120.0, 0.9)
	if who != null and is_instance_valid(who) and who.brain == null and not Net.is_client():
		var fine: = int(Config.Signs.Fine)
		who.add_cash( - fine)
		Game.notify(Text.f("signs." + String(post["kind"]), [Ui.money(fine)]), "warning", who)



func stand(post: Dictionary) -> void :
	post["down"] = false
	_topple(post, false)


func _process(delta: float) -> void :
	_since_check += delta
	if _since_check < 1.0:
		return
	_since_check = 0.0
	if Net.is_client():
		return
	var down_for: = float(Config.Signs.Down)
	for post: Dictionary in posts:
		if post["down"] and Game.now() - float(post["since"]) >= down_for and (post["area"] as Area3D).get_overlapping_bodies().is_empty():
			stand(post)








func _topple(post: Dictionary, down: bool) -> void :
	if post["pivot"] == null:
		var pivot: = Node3D.new()
		pivot.name = "KnockedPost"
		add_child(pivot)
		pivot.global_position = post["foot"]
		post["pivot"] = pivot
		var store: = Game.store
		var parts: Array = []
		for row: int in [post["row"]] + Array(post["plates"]):
			var node: = Game.world.take(store.id_at(row), false)
			if node != null:
				node.reparent(pivot, true)
				parts.append(node)
			var decal: Variant = Dressing.current.decal_of.get(row) if Dressing.current else null
			if decal != null:
				post["decals"][row] = decal[2]
		post["parts"] = parts
		if TrafficLights.current:
			for lamp: Node3D in TrafficLights.current.lamps_near(post["foot"], 2.5):
				lamp.reparent(pivot, true)
				post["lamps"].append(lamp)
	var tween: Variant = post["tween"]
	if tween != null and (tween as Tween).is_valid():
		(tween as Tween).kill()
	var pivot: Node3D = post["pivot"]
	var from: = _tilt_of(pivot)
	var to: = 1.0 if down else 0.0
	var fresh: = create_tween().set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BOUNCE if down else Tween.TRANS_QUAD)
	fresh.tween_method( func(t: float) -> void : _set_tilt(post, t), from, to, 0.7 if down else 0.9)
	if not down:
		fresh.tween_callback( func() -> void : (post["shape"] as CollisionShape3D).set_deferred("disabled", false))
	post["tween"] = fresh



func _tilt_of(pivot: Node3D) -> float:
	return clampf(acos(clampf(pivot.basis.y.dot(Vector3.UP), -1.0, 1.0)) / deg_to_rad(FALL), 0.0, 1.0)


func _set_tilt(post: Dictionary, t: float) -> void :
	var pivot: Node3D = post["pivot"]
	var fall: Vector3 = post["fall"]
	var axis: = Vector3.UP.cross(fall)
	if axis.length() < 0.01:
		axis = Vector3.RIGHT
	pivot.basis = Basis(axis.normalized(), deg_to_rad(FALL) * t)
	if Dressing.current:
		var swing: = Transform3D(pivot.basis, pivot.global_position) * Transform3D(Basis.IDENTITY, - pivot.global_position)
		for row: int in post["decals"]:
			Dressing.current.move_decal(row, swing * (post["decals"][row] as Transform3D))





func _net_state() -> Variant:
	var down: Array = []
	for post: Dictionary in posts:
		if post["down"]:
			down.append([post["id"], post["fall"].x, post["fall"].z])
	return down


func _net_apply(state: Variant) -> void :
	if not Net.is_client() or not state is Array:
		return
	var listed: = {}
	for entry: Array in state:
		listed[int(entry[0])] = true
		var post: Variant = _by_id.get(int(entry[0]))
		if post != null and not post["down"]:
			post["down"] = true
			post["fall"] = Vector3(entry[1], 0.0, entry[2])
			(post["shape"] as CollisionShape3D).set_deferred("disabled", true)
			_topple(post, true)
	for post: Dictionary in posts:
		if post["down"] and not listed.has(post["id"]):
			stand(post)



func nearest(at: Vector3) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: = INF
	for post: Dictionary in posts:
		var distance: float = (post["foot"] as Vector3).distance_to(at)
		if distance < best_distance:
			best_distance = distance
			best = post
	return best
