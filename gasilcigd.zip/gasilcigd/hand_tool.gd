class_name HandTool
extends Node3D














signal attribute_changed(key: String, value: Variant)

const BRACE_TIME: = 0.25
const CHAIN_SPEED: Array[float] = [0.0, 6.0, 4.5]
const CHAIN_PICKUP: = 14.0

const CHAIN: = {
	"Teeth": 14, 
	"Out": 0.047, 
	"Rear": 1.05, 
	"Nose": -0.6, 
	"Radius": 0.215, 
}

const JAWS: = {
	"Spreader": {"L": Vector3(-0.22, -0.48, -0.75), "R": Vector3(0.22, -0.48, -0.75)}, 
	"Cutter": {"L": Vector3(0, -0.48, -0.8), "R": Vector3(0, -0.48, -0.8)}, 
}

const JAW_ANGLES: = {
	"Spreader": [deg_to_rad(25), 0.0], 
	"Cutter": [deg_to_rad(11), deg_to_rad(7)], 
}

var tool_name: = ""
var attributes: Dictionary = {}
var holder: Player
var body: Node3D
var held: = Transform3D.IDENTITY
var standing: = Transform3D.IDENTITY
var sounds: Dictionary = {}
var emitters: Dictionary = {}
var points: Dictionary = {}
var _hinges: Dictionary = {}
var _teeth: Array[Node3D] = []
var _chain_at: = 0.0
var _chain_speed: = 0.0
var _blend: = 0.0
var _load: = 0.0
var _jaw: = 0.0
var _swing_started: = -10.0
var horn: Node3D
var _hose: MeshInstance3D
var _hose_drawn: = Transform3D()
const HORN_CLIPPED: = Transform3D(Basis(Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(0, 1, 0)), Vector3(0.225, 0.62, -0.3))
const HOSE_OUT: = Vector3(0, 1.6, -0.14)



static func make(wanted_name: String, prop: Dictionary) -> HandTool:
	var tool: = HandTool.new()
	tool.name = wanted_name.replace(" ", "")
	tool.tool_name = wanted_name
	var grip: Dictionary = prop["grip"]
	var up: = Rbx.v3(grip["handle"])
	var back: = - Rbx.v3(grip["blade"])
	var axes: = Basis(up.cross(back), up, back)
	tool.held = Transform3D(axes, Rbx.v3(grip["pos"]))
	tool.standing = Transform3D(axes, prop["spot"])
	tool.body = Node3D.new()
	tool.body.name = "Body"
	tool.add_child(tool.body)
	tool.body.transform = tool.standing.affine_inverse()
	if ToolModels.has(wanted_name):
		tool._dress(prop)
		return tool
	var source: Node3D = prop["node"]
	for child in source.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var copy: = mesh.duplicate() as MeshInstance3D
		copy.visible = true
		var side: = ""
		if JAWS.has(wanted_name):
			side = "L" if String(mesh.name).contains("JawL") else ("R" if String(mesh.name).contains("JawR") else "")
		if side.is_empty():
			tool.body.add_child(copy)
			continue
		var joint: = tool._hinge(side)
		joint.add_child(copy)
		copy.transform = joint.transform.affine_inverse() * mesh.transform
	return tool



func _hinge(side: String) -> Node3D:
	if not _hinges.has(side):
		var hinge: = Node3D.new()
		hinge.name = "Jaw" + side
		body.add_child(hinge)
		hinge.transform = held * Transform3D(Basis.IDENTITY, JAWS[tool_name][side])
		_hinges[side] = hinge
	return _hinges[side]



func _dress(_prop: Dictionary) -> void :
	var made: = ToolModels.of(tool_name)
	for part: String in made:
		if part == "Hose":
			continue
		var mesh: = MeshInstance3D.new()
		mesh.name = part
		mesh.mesh = made[part]
		if part in ["JawL", "JawR"]:
			var joint: = _hinge(part.substr(3))
			joint.add_child(mesh)
			mesh.transform = joint.transform.affine_inverse() * standing
		elif part == "Horn":
			horn = Node3D.new()
			horn.name = "Horn"
			add_child(horn)
			horn.add_child(mesh)
			horn.transform = HORN_CLIPPED
			var tip: = Node3D.new()
			tip.name = "Tip"
			horn.add_child(tip)
			tip.position = Vector3(0, 0, -0.26)
			points["HornTip"] = tip
			_hose = MeshInstance3D.new()
			_hose.name = "Hose"
			add_child(_hose)
			_draw_hose()
		else:
			body.add_child(mesh)
			mesh.transform = standing



func _draw_hose() -> void :
	if _hose == null or horn == null:
		return
	var at: = horn.transform
	if at.is_equal_approx(_hose_drawn) and _hose.mesh != null:
		return
	_hose_drawn = at
	var inlet: = at * Vector3(0, 0, 0.14)
	var into: = at.basis.z.normalized()
	var a: = HOSE_OUT
	var b: = HOSE_OUT + Vector3(0.12, -0.25, -0.2)
	var c: = inlet + into * 0.35
	var path: Array = []
	for index in 11:
		var t: = index / 10.0
		var u: = 1.0 - t
		path.append(a * u * u * u + b * 3.0 * u * u * t + c * 3.0 * u * t * t + inlet * t * t * t)
	var kit: = ShapeKit.new()
	kit.tube(ShapeKit.RUBBER, ToolModels.BLACK, path, 0.04, 6, false)
	_hose.mesh = kit.commit()


func get_attr(key: String, default: Variant = null) -> Variant:
	return attributes.get(key, default)


func set_attr(key: String, value: Variant) -> void :
	if attributes.get(key) == value:
		return
	if value == null:
		attributes.erase(key)
	else:
		attributes[key] = value
	if key == "Swing":
		_swing_started = Game.now()
	attribute_changed.emit(key, value)



static func dress_prop(tool_name: String, prop: Dictionary) -> void :
	var node: Node3D = prop["node"]
	var grip: Dictionary = prop["grip"]
	if not ToolModels.has(tool_name) or grip.is_empty() or node.has_node("Model"):
		return
	var up: = Rbx.v3(grip["handle"])
	var back: = - Rbx.v3(grip["blade"])
	var standing: = Transform3D(Basis(up.cross(back), up, back), prop["spot"])
	for child in node.get_children():
		if child is MeshInstance3D:
			child.visible = false
	var model: = ToolModels.instance(tool_name)
	node.add_child(model)
	model.transform = standing
	if model.has_node("Horn"):
		model.get_node("Horn").transform = HORN_CLIPPED




func add_point(point_name: String, offset: Vector3, within: bool) -> Node3D:
	var node: = Node3D.new()
	node.name = point_name
	body.add_child(node)
	node.transform = held * Transform3D(Basis.IDENTITY, offset) if within else Transform3D(Basis.IDENTITY, standing.origin + offset)
	points[point_name] = node
	return node



func add_sound(sound_name: String, looped: = false, volume: = 1.0) -> AudioStreamPlayer3D:
	var asset: Variant = Config.Tools.Sounds.get(sound_name)
	var stream: AudioStream = Sounds.loop(asset) if looped else Assets.sound(asset)
	var sound: = Sounds.emitter(self, stream, volume, 10.0, 140.0)
	sounds[sound_name] = sound
	return sound


func play(sound_name: String, on: = true, pitch: = 1.0) -> void :
	var sound: AudioStreamPlayer3D = sounds.get(sound_name)
	if sound == null or sound.stream == null:
		return
	sound.pitch_scale = pitch
	if on and not sound.playing:
		sound.play()
	elif not on and sound.playing:
		sound.stop()


func emit(emitter_name: String, on: bool) -> void :
	var emitter: RbxEmitter = emitters.get(emitter_name)
	if emitter != null and emitter.emitting != on:
		emitter.emitting = on



func add_chain(bar: Node3D) -> void :
	var steel: = StandardMaterial3D.new()
	steel.albedo_color = Color(196 / 255.0, 200 / 255.0, 206 / 255.0)
	steel.metallic = 0.75
	steel.roughness = 0.38
	for index in int(CHAIN["Teeth"]):
		var tooth: = MeshInstance3D.new()
		var box: = BoxMesh.new()
		box.size = Vector3(0.05, 0.07, 0.11)
		tooth.mesh = box
		tooth.material_override = steel
		bar.add_child(tooth)
		_teeth.append(tooth)
	_place_chain()




static func _tooth_at(distance: float) -> Transform3D:
	var out: float = CHAIN["Out"]
	var rear: float = CHAIN["Rear"]
	var nose: float = CHAIN["Nose"]
	var radius: float = CHAIN["Radius"]
	var straight: = rear - nose
	var around: = PI * radius
	distance = fposmod(distance, straight * 2 + around)
	if distance < straight:
		return Transform3D(Basis.IDENTITY, Vector3(out, radius, rear - distance))
	elif distance < straight + around:
		var angle: = (distance - straight) / radius
		return Transform3D(Basis(Vector3.RIGHT, - angle), Vector3(out, radius * cos(angle), nose - radius * sin(angle)))
	return Transform3D(Basis.IDENTITY, Vector3(out, - radius, nose + distance - straight - around))


func _place_chain() -> void :
	var length: float = (CHAIN["Rear"] - CHAIN["Nose"]) * 2 + PI * CHAIN["Radius"]
	for index in _teeth.size():
		_teeth[index].transform = _tooth_at(_chain_at + (index + 1) * length / _teeth.size())




func _jaw_target(level: int, now: float, done: float) -> Array:
	if tool_name == "Spreader":


		return [0.0 if level == 0 else (1.0 if level == 1 else 0.12 + 0.88 * done), 0.85 if level == 1 else 3.0]


	return [0.0 if level == 0 else (sin(now * 6.5) if level == 1 else 1.0 - 2.0 * done), 7.0]





func hold_kind() -> String:
	return tool_name


func hold_pose(ctx: Dictionary) -> Dictionary:
	return Holds.pose(tool_name, ctx)



func swing_progress() -> float:
	var t: = (Game.now() - _swing_started) / float(Config.Tools.SwingTime)
	return t if t >= 0.0 and t < 1.0 else -1.0



func work_blend() -> float:
	return _blend * _blend * (3.0 - 2.0 * _blend)


func load_blend() -> float:
	return _load * _load * (3.0 - 2.0 * _load)




func after_hold(pose: Dictionary, to_world: Transform3D) -> void :
	if horn == null:
		return
	if pose.has("horn") and float(pose.get("left_weight", 0.0)) > 0.02:
		var wanted: Transform3D = global_transform.affine_inverse() * to_world * (pose["horn"] as Transform3D)
		horn.transform = HORN_CLIPPED.interpolate_with(wanted.orthonormalized(), clampf(float(pose["left_weight"]), 0.0, 1.0))
	else:
		horn.transform = HORN_CLIPPED
	_draw_hose()


func _process(delta: float) -> void :
	var now: = Game.now()
	var in_hand: bool = holder != null and is_instance_valid(holder) and visible and get_parent() == holder.rig.hand_right
	var level: = int(get_attr("Working", 0)) if in_hand else 0
	var running: = level > 0
	_blend = clampf(_blend + (delta if running else - delta) / BRACE_TIME, 0.0, 1.0)
	_load = clampf(_load + (delta if level > 1 else - delta) / BRACE_TIME, 0.0, 1.0)

	if not _hinges.is_empty():
		var target: = _jaw_target(level, now, float(get_attr("Progress", 0.0)))
		var step: float = target[1] * delta
		_jaw += clampf(target[0] - _jaw, - step, step)

		var angles: Array = JAW_ANGLES[tool_name]
		var angle: float = _jaw * (angles[0] if _jaw > 0.0 else angles[1])
		if _hinges.has("L"):
			_hinges["L"].basis = held.basis * Basis(Vector3.UP, angle)
		if _hinges.has("R"):
			_hinges["R"].basis = held.basis * Basis(Vector3.UP, - angle)

	if not _teeth.is_empty():
		var wanted: float = CHAIN_SPEED[level] if in_hand else 0.0
		var gain: = CHAIN_PICKUP * delta
		_chain_speed += clampf(wanted - _chain_speed, - gain, gain)
		if _chain_speed > 0.0:
			_chain_at += _chain_speed * delta
			_place_chain()

	if horn != null and not in_hand and not horn.transform.is_equal_approx(HORN_CLIPPED):
		horn.transform = HORN_CLIPPED
		_draw_hose()
