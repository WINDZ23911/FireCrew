class_name CallKit
extends RefCounted



const BLOCK: = PartStore.Shape.BLOCK
const CYLINDER: = PartStore.Shape.CYLINDER
const BALL: = PartStore.Shape.BALL

const BAR_SHADER: = "\nshader_type spatial;\nrender_mode unshaded, cull_disabled, depth_draw_never, depth_test_disabled, shadows_disabled;\n// How far along a job is: a bar a fixed number of pixels across, over its mark and seen through anything.\nuniform float share = 0.0;\nuniform vec3 fill : source_color = vec3(1.0, 0.82, 0.16);\nuniform vec2 pixels = vec2(90.0, 12.0);\nuniform float lift = 2.0;\n\nvoid vertex() {\n\tvec4 world = MODEL_MATRIX * vec4(0.0, 0.0, 0.0, 1.0);\n\tworld.y += lift;\n\tvec4 centre = VIEW_MATRIX * world;\n\tfloat per_pixel = 2.0 * -centre.z / (abs(PROJECTION_MATRIX[1][1]) * VIEWPORT_SIZE.y);\n\tcentre.xy += VERTEX.xy * pixels * per_pixel;\n\tPOSITION = PROJECTION_MATRIX * centre;\n}\n\nvoid fragment() {\n\tbool full = UV.x <= share;\n\tALBEDO = full ? fill : vec3(0.006, 0.006, 0.006);\n\tALPHA = full ? 1.0 : 0.7;\n}\n"
























static var _bar_shader: Shader
static var _plain: Dictionary = {}




static func model(model_name: String) -> Node3D:
	var node: = Node3D.new()
	node.name = model_name
	Game.world.add_child(node)
	return node




static func part(parent: Node3D, shape: int, size: Vector3, place: Transform3D, color: Color, material: = "SmoothPlastic", solid: = false, transparency: = 0.0, part_name: = "Part") -> PartNode:
	var flags: = PartStore.SHADOW | ((PartStore.COLLIDE | PartStore.QUERY) if solid else 0)
	var node: = PartNode.create(shape, place, size, color, material, part_name, flags, transparency)
	parent.add_child(node)
	node.global_transform = place
	if not solid:
		node.collider.disabled = true
	return node



static func piece(parent: Node3D, shape: int, size: Vector3, place: Transform3D, color: Color, glow: = 0.0) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	mesh.mesh = World.unit_mesh(shape)
	var drawn: = size
	if shape == CYLINDER:
		drawn = Vector3(size.x, minf(size.y, size.z), minf(size.y, size.z))
	elif shape == BALL:
		drawn = Vector3.ONE * minf(size.x, minf(size.y, size.z))
	mesh.transform = place * Transform3D(Basis.from_scale(drawn), Vector3.ZERO)
	mesh.material_override = plain(color, glow)
	parent.add_child(mesh)
	return mesh



static func plain(color: Color, glow: = 0.0) -> StandardMaterial3D:
	var key: = [color, glow]
	if _plain.has(key):
		return _plain[key]
	var made: = StandardMaterial3D.new()
	made.albedo_color = color
	made.roughness = 0.6
	if glow > 0.0:
		made.emission_enabled = true
		made.emission = color
		made.emission_energy_multiplier = glow
	_plain[key] = made
	return made



static func bar(parent: Node3D, lift: float, color: Color, far: = 70.0, pixels: = Vector2(90, 12)) -> MeshInstance3D:
	if _bar_shader == null:
		_bar_shader = Shader.new()
		_bar_shader.code = BAR_SHADER
	var made: = MeshInstance3D.new()
	made.name = "Bar"
	var quad: = QuadMesh.new()
	quad.size = Vector2.ONE
	made.mesh = quad
	var material: = ShaderMaterial.new()
	material.shader = _bar_shader
	material.set_shader_parameter("fill", color)
	material.set_shader_parameter("lift", lift)
	material.set_shader_parameter("pixels", pixels)
	material.render_priority = 5
	made.material_override = material
	made.custom_aabb = AABB(Vector3(-6, -6, -6), Vector3(12, 12, 12))
	made.visibility_range_end = far
	made.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(made)
	return made


static func set_bar(made: MeshInstance3D, share: float, color: Variant = null) -> void :
	if not is_instance_valid(made):
		return
	var material: ShaderMaterial = made.material_override
	material.set_shader_parameter("share", clampf(share, 0.0, 1.0))
	if color != null:
		material.set_shader_parameter("fill", color)



static func words(parent: Node3D, text: Variant, color: Color, lift: float, far: = 80.0) -> Label3D:
	var label: = Label3D.new()
	label.text = Text.say(text)
	label.font = Ui.world_label_font()
	label.font_size = 32
	label.outline_size = 10
	label.modulate = color
	label.outline_modulate = Color(0.05, 0.05, 0.06)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = true
	label.pixel_size = 0.0011
	label.render_priority = 6
	label.visibility_range_end = far
	label.position = Vector3(0, lift, 0)
	parent.add_child(label)
	return label


static func set_marker(marker: CallMarker, text: Variant) -> void :
	if is_instance_valid(marker):
		marker.set_meta("text", text)
		marker.label.text = " %s " % Text.say(text)


static func player_near(position: Vector3, reach: float) -> bool:
	for player in Game.players:
		if player.root_position().distance_to(position) < reach:
			return true
	return false




static func by_crew(table: Array) -> Variant:
	return table[clampi(Alarm.crew(), 1, table.size()) - 1]




static func in_box(place: Transform3D, size: Vector3, but: = {}) -> Array[int]:
	var box: = BoxShape3D.new()
	box.size = size
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = box
	query.transform = place
	query.collision_mask = World.LAYER_SOLID | World.LAYER_VEHICLE
	var found: Array[int] = []
	for hit: Dictionary in Game.world.get_world_3d().direct_space_state.intersect_shape(query, 24):
		var row: = Game.world.row_hit(hit)
		if row < 0 or not but.has(row):
			found.append(row)
	return found


static func box_clear(place: Transform3D, size: Vector3, but: = {}) -> bool:
	return in_box(place, size, but).is_empty()



static func ground_at(position: Vector3) -> Vector3:
	var hit: = Game.world.raycast(position + Vector3(0, 4, 0), position + Vector3(0, -4, 0), World.LAYER_SOLID)
	return hit["position"] if not hit.is_empty() else position





static func floor_at(position: Vector3, below: = 12.0) -> Vector3:
	var passed: Array[RID] = []
	var first: = {}
	for attempt in 8:
		var hit: = Game.world.raycast(position + Vector3(0, 4, 0), position + Vector3(0, - below, 0), World.LAYER_SOLID, passed)
		if hit.is_empty():
			break
		if first.is_empty():
			first = hit
		if Game.world.row_hit(hit) >= 0:
			return hit["position"]
		passed.append(hit["rid"])
	return first["position"] if not first.is_empty() else position



static func draw(weights: Dictionary, otherwise: String) -> String:
	var sum: = 0.0
	for key: String in weights:
		sum += float(weights[key])
	var drawn: = randf() * sum
	for key: String in weights:
		drawn -= float(weights[key])
		if drawn <= 0.0:
			return key
	return otherwise




static func fade(node: Node3D, seconds: float) -> void :
	if not is_instance_valid(node) or not node.is_inside_tree() or node.has_meta("fading"):
		return
	node.set_meta("fading", true)
	for body in node.find_children("*", "CollisionShape3D", true, false):
		body.set_deferred("disabled", true)
	var drawn: Array = []
	for mesh: MeshInstance3D in node.find_children("*", "MeshInstance3D", true, false):
		drawn.append([mesh, mesh.scale])
	var tween: = node.create_tween()
	tween.tween_method( func(left: float) -> void :
		for entry: Array in drawn:
			if is_instance_valid(entry[0]):
				entry[0].scale = entry[1] * left
	, 1.0, 0.02, seconds).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.tween_callback(node.queue_free)



static func there(node: Variant) -> bool:
	return is_instance_valid(node) and not node.is_queued_for_deletion() and node.is_inside_tree()



static func fading(node: Variant) -> bool:
	return not there(node) or node.has_meta("fading")




static func prompt(parent: Node3D, id: String, action: Variant, object: Variant = "", hold: = 0.0, reach: = 10.0) -> Prompt:
	var made: = Prompt.new()
	made.net_id = id
	made.action = action
	made.object = object
	made.hold = hold
	made.reach = reach
	parent.add_child(made)
	return made



static func building_name(building: Building) -> Variant:
	var number: = RegEx.create_from_string("^House (\\d+)$").search(building.name)
	if number:
		return Text.f("calls.houseNumber", [int(number.get_string(1))])
	return building.shown_name if building.shown_name != null else Text.named("calls.buildings", building.name)



static func crew_near(position: Vector3, reach: float) -> Array[Player]:
	var found: Array[Player] = []
	for player in Game.players:
		if is_instance_valid(player) and player.root_position().distance_to(position) <= reach:
			found.append(player)
	return found




static func payee(player: Variant) -> Player:
	if not is_instance_valid(player) or not player is Player:
		return null
	var someone: Player = player
	if someone.brain != null:
		var lead: Player = someone.brain.commander()
		return lead if is_instance_valid(lead) and lead.brain == null else null
	return someone





static func helpers_of(helpers: Variant, stayed: = true) -> Array[Player]:
	var found: Array[Player] = []
	var list: Array = []
	list.append_array(helpers.keys() if helpers is Dictionary else helpers)
	if stayed:
		list.append_array(Alarm.stayed())
	for someone: Variant in list:
		var paid: = payee(someone)
		if paid != null and not found.has(paid):
			found.append(paid)
	return found






static func pay_helpers(helpers: Variant, amount: int, why: = "", item: = "", stayed: = true) -> Array[Player]:
	var paid: = helpers_of(helpers, stayed)
	for player in paid:
		player.add_cash(amount, why, false, item)
	return paid



static func rows_of(model_id: int) -> Dictionary:
	var rows: = {}
	for row in Game.store.rows_in(model_id):
		rows[row] = true
	return rows



static func tree_model(index: int) -> int:
	var store: = Game.store
	var map: Dictionary = store.find_node(0, "Folder", "Map")
	if map.is_empty():
		return 0
	var trees: Dictionary = store.find_node(int(map["i"]), "Folder", "Trees")
	if trees.is_empty():
		return 0
	var tree: Dictionary = store.find_node(int(trees["i"]), "Model", "Tree%d" % (index + 1))
	return int(tree["i"]) if not tree.is_empty() else 0



static func set_standing(model_id: int, standing: bool) -> void :
	for row in Game.store.rows_in(model_id):
		var id: = Game.store.id_at(row)
		Game.world.set_hidden(id, not standing)
		Game.world.set_solid(id, standing)
	if TreeKit.current:
		TreeKit.current.set_standing(model_id, standing)
