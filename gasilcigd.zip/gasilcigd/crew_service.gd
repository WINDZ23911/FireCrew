class_name CrewService
extends Node









signal spoke_line(member: Crewman, line: Variant, kind: String)
signal crew_changed

static var current: CrewService

var roster: CrewRoster
var members: Array[Crewman] = []
var auto: = true
var last_vehicle: Vehicle = null
var _overflow_for: Variant = null
var done_here: Dictionary = {}




var autonomy: = STANDARD

var ask: Dictionary = {}

var arrival: Dictionary = {}
var _voice: Dictionary = {}
var _markers: Array = []

const HANDS_ON: = 0
const STANDARD: = 1
const FULL: = 2
const LEVELS: = ["handsOn", "standard", "full"]

static var _enabled: Variant = null





static func enabled() -> bool:
	if _enabled == null:
		_enabled = bool((Config.Crew as Dictionary).get("Enabled", true))
		for arg in OS.get_cmdline_user_args():
			if arg == "--crew" or arg.begins_with("--crewai=") or arg.begins_with("--scenario=crew")\
			or arg in ["--scenario=art_crew", "--scenario=splash_crew"]:
				_enabled = true
	return _enabled


func _ready() -> void :
	current = self
	roster = CrewRoster.new()
	auto = roster.auto
	autonomy = clampi(int(Config.Crew.Autonomy.Default), HANDS_ON, FULL)
	if roster.autonomy >= 0:
		autonomy = clampi(roster.autonomy, HANDS_ON, FULL)
	if not InputMap.has_action("crew_autonomy"):
		InputMap.add_action("crew_autonomy")
		var key: = InputEventKey.new()
		key.physical_keycode = KEY_Y
		InputMap.action_add_event("crew_autonomy", key)
	for arg in OS.get_cmdline_user_args():

		if arg.begins_with("--crewai="):
			autonomy = FULL
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--autonomy="):
			autonomy = maxi(0, LEVELS.find(arg.substr(11)))
	for arg in OS.get_cmdline_user_args():


		if arg.begins_with("--crewai=") or arg == "--crew":
			Settings.crew = true
			Settings.crew_count = 5
		if arg == "--crew-manual":
			auto = false


		if arg.begins_with("--scenario=crew") or arg in ["--scenario=art_crew", "--scenario=splash_crew"]:
			Settings.crew = true
			Settings.crew_count = 5
		elif (arg.begins_with("--scenario=") or arg.begins_with("--play=")) and not "--crew" in OS.get_cmdline_user_args():
			roster.members.clear()
	var nav: = CrewNav.new()
	nav.name = "Nav"
	add_child(nav)
	var last_call: = [null]
	Game.incident_changed.connect( func() -> void :
		var call_name: Variant = Game.incident.get("name")
		if call_name == null or last_call[0] == null or Text.say(call_name, "sl") != Text.say(last_call[0], "sl"):
			done_here.clear()
			ask = {}
			if call_name == null:
				arrival.clear()
		last_call[0] = call_name
		var at: Variant = Game.incident.get("pos")
		if at is Vector3 and not Net.active():
			nav.ensure(at, 0.6)
	)
	if Hud.current:

		Hud.current.add_widget("crew_panel", HudIncidentBoard.new())
		Hud.current.add_widget("crew_orders", HudCrewOrders.new())
		Hud.current.add_widget("crew_board", CrewBoard.new())
	Net.started.connect(despawn)
	Net.stopped.connect( func() -> void : spawn.call_deferred())
	spawn.call_deferred()


func _exit_tree() -> void :
	if current == self:
		current = null





func spawn() -> void :
	if not enabled() or Net.active() or not members.is_empty() or Game.local_player == null or Settings.crew_size() <= 0:
		return
	var lead: = Game.local_player
	CrewNav.current.ensure(lead.global_position, 0.6)

	for index in mini(roster.members.size(), Settings.crew_size()):
		_make(roster.members[index], index, lead)
	crew_changed.emit()


func _make(entry: Dictionary, index: int, lead: Player) -> Crewman:
	var body: = Player.new()
	body.is_local = false
	body.display_name = entry["name"]
	body.name = "Crew_" + str(entry["name"]).validate_node_name()
	var mind: = Crewman.new()
	mind.name = "Mind"
	mind.body = body
	mind.service = self
	mind.member = entry
	mind.autonomy = int(entry.get("autonomy", -1))
	mind.role = entry["role"]
	mind.slot = index
	body.brain = mind
	body.add_child(mind)
	get_parent().add_child(body)
	var spot: = mind.slot_position() if lead.seat == null else lead.global_position + Vector3(6 + index * 3, 0, 6)
	body.teleport(free_spot(spot, lead.global_position) + Vector3(0, 0.3, 0))
	body.rig.rotation.y = lead.rig.rotation.y
	if GearService.current:
		GearService.current.adopt(body)
	body.died.connect( func() -> void : mind.stand_down())
	members.append(mind)
	return mind


func despawn() -> void :
	for mind in members:
		if is_instance_valid(mind) and is_instance_valid(mind.body):
			mind.stand_down()
			var vehicle: Variant = mind.body.get_attr("Vehicle")
			if vehicle is Vehicle and is_instance_valid(vehicle):
				vehicle.leave(mind.body)
			CrewKit.stow_all(mind)


			Net.peer_left.emit(mind.body)
			mind.body.queue_free()
	members.clear()
	crew_changed.emit()




func hire(lead: Player, candidate: Dictionary = {}) -> bool:
	if not enabled():
		return false
	var price: = roster.hire_price()
	if price >= 0 and candidate.has("price"):
		price = int(candidate["price"])
	if price < 0 or not PlayerData.spend(lead, price):
		return false
	var everyone_came: = Settings.crew and Settings.crew_count >= roster.members.size()
	var entry: = roster.hire(candidate)

	if everyone_came and Settings.crew_count < roster.members.size():
		Settings.crew_count = roster.members.size()
		Settings.save()
	if not Net.active() and members.size() < Settings.crew_size():
		var mind: = _make(entry, members.size(), lead)
		mind.say("crew.say.hired", [], "good", true)
	crew_changed.emit()
	return true


func train(lead: Player, entry: Dictionary) -> bool:
	var price: = roster.train_price(entry)
	if price < 0 or not PlayerData.spend(lead, price):
		return false
	roster.train(entry)
	crew_changed.emit()
	return true


func _process(_delta: float) -> void :
	var lead: = Game.local_player
	if lead != null and lead.get_attr("Vehicle") is Vehicle:
		last_vehicle = lead.get_attr("Vehicle")
	if not ask.is_empty() and (Game.now() > float(ask["until"]) or not is_instance_valid(ask["mind"])):
		ask = {}
	if not members.is_empty():
		if lead != null and not Game.ui_open and lead.seat == null and Input.is_action_just_pressed("crew_autonomy"):
			cycle_autonomy()
		CrewSearch.listen(self)
		CrewReports.tick(self)
		CrewAuto.tick(self)
	for index in range(_markers.size() - 1, -1, -1):
		if Game.now() > float(_markers[index][1]):
			if is_instance_valid(_markers[index][0]):
				_markers[index][0].queue_free()
			_markers.remove_at(index)






func level_of(mind: Crewman) -> int:
	return mind.autonomy if mind != null and mind.autonomy >= 0 else autonomy



static func level_name(level: int) -> Dictionary:
	return Text.m("crew.autonomy." + LEVELS[clampi(level, HANDS_ON, FULL)])



func cycle_autonomy(mind: Crewman = null) -> void :
	set_autonomy((level_of(mind) + 1) % LEVELS.size(), mind)


func set_autonomy(level: int, mind: Crewman = null) -> void :
	level = clampi(level, HANDS_ON, FULL)
	if mind != null:
		mind.autonomy = level
		mind.say("crew.say.autonomy." + LEVELS[level], [], "info", true)
	else:
		autonomy = level
		for each in members:
			each.autonomy = -1
		lead_say("crew.say.autonomy." + LEVELS[level])
	Game.notify(Text.f("crew.autonomy.set", [mind.display_name() if mind != null else Text.m("crew.panel.title"), level_name(level)]), "", Game.local_player)
	ask = {} if level != STANDARD else ask

	roster.autonomy = autonomy
	for each in members:
		each.member["autonomy"] = each.autonomy
	roster.save()
	crew_changed.emit()




func ask_lead(mind: Crewman, kind: String) -> void :
	var now: = Game.now()
	if not ask.is_empty() and now <= float(ask["until"]):
		return
	var asked: = "asked_" + kind
	if now - float(done_here.get(asked, - INF)) < float(Config.Crew.Autonomy.AskAgain):
		return
	done_here[asked] = now
	ask = {"mind": mind, "kind": kind, "until": now + float(Config.Crew.Autonomy.AskOpen)}
	var key: = "crew.say.ask." + kind
	mind.say(key if Text.has(key) else "crew.say.ask.any", [], "info", true)
	Game.notify(Text.join([mind.display_name(), ": ", Text.m(key if Text.has(key) else "crew.say.ask.any"), "  ", Text.f("crew.say.askKey", [Controls.key_name("crew_order")])]), "", Game.local_player)




func confirm_ask() -> void :
	if ask.is_empty():
		return
	var mind: Crewman = ask["mind"] if is_instance_valid(ask["mind"]) else null
	var kind: String = ask["kind"]
	ask = {}
	done_here["granted_" + kind] = true
	var job: CrewJob = null
	match kind:
		"attack":
			job = JobAttack.new()
		"carry":
			job = JobCarry.new()
		"cutTree":
			job = JobCutTree.new()
		"cutOpen":
			job = JobCutOpen.new()
		"leak":
			job = JobValve.new()
	if job == null:
		return
	if mind != null and mind.body.health > 0.0 and job.suits(mind):
		order(job, mind)
	elif order(job) == null:
		Game.notify(Text.m("crew.say.nobody"), "warning", Game.local_player)




func no_room(mind: Crewman, vehicle: Vehicle) -> bool:
	if not auto:
		return false
	if _overflow_for != vehicle:
		_overflow_for = vehicle
		get_tree().create_timer(1.0, false).timeout.connect( func() -> void :
			_overflow_for = null
			var left: Array = []
			for other in members:
				if other.job == null and other.body.seat == null and other.mode != "hold" and other.body.health > 0.0:
					left.append(other)
			CrewDrive.overflow(self, vehicle, left)
		)
	return true



func home_vehicle(_lead: Player) -> Variant:
	if is_instance_valid(last_vehicle):
		return last_vehicle
	return Vehicle.named("Fire Truck")


func mind_of(body: Player) -> Crewman:
	return body.brain if body != null else null







func order(job: CrewJob, to: Crewman = null, after: = false) -> Crewman:
	var chosen: = to if to != null else choose(job)
	if chosen == null:
		return null
	job.ordered = true
	chosen.give(job, after)
	chosen.say("crew.say.yes." + job.kind if Text.has("crew.say.yes." + job.kind) else "crew.say.yes.any", [], "info", true)
	return chosen




func choose(job: CrewJob, leave_out: Array = []) -> Crewman:
	var best: Crewman = null
	var best_score: = - INF
	var roles_here: = members.map( func(mind: Crewman) -> String: return mind.role)
	var at: Variant = job.place() if job.has_method("place") else null
	for mind in members:
		if not is_instance_valid(mind) or mind in leave_out or mind.body.health <= 0.0 or not job.suits(mind):
			continue
		var score: = 0.0
		if job.role.is_empty() or mind.role == job.role:
			score += 3.0
		elif not job.role in roles_here and mind.role in Config.Crew.Covers.get(job.role, []):
			score += 2.0
		if mind.job == null:
			score += 2.0
		elif mind.job.ordered:
			score -= 5.0
		if mind.hands_free():
			score += 1.0
		if at is Vector3:
			score -= mind.body.global_position.distance_to(at) / 60.0
		if score > best_score:
			best_score = score
			best = mind
	return best



func all_follow() -> void :
	for mind in members:
		mind.mode = "follow"
		mind.stand_down()
	lead_say("crew.say.follow")



func all_work() -> void :
	for mind in members:
		mind.mode = "auto"
	lead_say("crew.say.work")
	CrewAuto.start_all(self)



func all_hold(at: = Vector3.INF) -> void :
	for mind in members:
		mind.mode = "hold"
		mind.hold_at = mind.body.global_position if at == Vector3.INF else at + Vector3(mind.slot * 3.0 - 6.0, 0, 0)
		mind.stand_down()
	lead_say("crew.say.hold")




func all_pack_up() -> void :
	if not CrewPack.anything(self):
		lead_say("crew.say.nothingOut")
		return
	for mind in members:
		if mind.body.health > 0.0:
			mind.mode = "follow"
			mind.give(JobPackUp.new())
	lead_say("crew.say.yes.packUp")



func lead_say(key: String) -> void :
	for mind in members:
		mind.say(key, [], "info", true)
		return


func job_done(mind: Crewman, job: CrewJob) -> void :
	var line: = "crew.say.done." + job.kind
	if not job.quiet:
		mind.say(line if Text.has(line) else "crew.say.done.any", [], "good", true)

	if not job.kind in (Config.Crew.LearnSkip as Array):
		if roster.learn(mind.member):
			mind.say("crew.say.better", [], "good", true)
			crew_changed.emit()


func job_failed(mind: Crewman, job: CrewJob) -> void :
	mind.failed[job.kind] = Game.now()
	var key: = job.reason if not job.reason.is_empty() else "crew.say.cannot"
	var where: Vector3 = mind.body.global_position
	if not mind.blocked_by.is_empty() and is_instance_valid(mind.blocked_by.get("prompt")):
		where = (mind.blocked_by["prompt"] as Node3D).global_position


	if not job.ordered:
		mind.failures[job.kind] = int(mind.failures.get(job.kind, 0)) + 1
		if int(mind.failures[job.kind]) == int(Config.Crew.Failures.AskAfter):
			var line: = Text.f("crew.say.failedAsk", [mind.display_name(), job.title(), Text.f(key, job.reason_args) if not job.reason_args.is_empty() else Text.m(key)])
			mark_failure(where, Text.f(key, job.reason_args) if not job.reason_args.is_empty() else Text.m(key))
			Game.notify(line, "warning", Game.local_player)
			return
	if not job.ordered and not key in ["crew.say.lowAir", "crew.say.hurt", "crew.say.lineLost", "crew.say.noHydrant", "crew.say.locked"]:
		return
	if job.ordered:
		mark_failure(where, Text.f(key, job.reason_args) if not job.reason_args.is_empty() else Text.m(key))
	mind.say(key, job.reason_args, "warning", true)



func mark_failure(at: Vector3, why: Variant) -> void :
	var marker: = CallMarker.make(at + Vector3(0, 5, 0), why, Color(0.9, 0.55, 0.1))
	marker.own = true
	_markers.append([marker, Game.now() + float(Config.Crew.Failures.MarkFor)])




func voice_free(key: String, args: Array) -> bool:
	var said: = key + str(args) if not args.is_empty() else key
	var now: = Game.now()
	if now - float(_voice.get(said, -100.0)) < float(Config.Crew.Voice.Gap):
		return false
	_voice[said] = now
	return true



func first_report(key: String, args: Array) -> bool:
	var said: = "report:" + key + str(args)
	if done_here.has(said):
		return false
	done_here[said] = true
	return true



func member_arrived(mind: Crewman) -> void :
	if not Game.incident.is_empty() and not arrival.is_empty():
		CrewAuto.arrival_orders(self, mind)
	if auto and not Game.incident.is_empty():
		CrewAuto.arrived(self, mind)


func spoke(mind: Crewman, line: Variant, kind: String) -> void :
	spoke_line.emit(mind, line, kind)
	if kind == "warning" or kind == "danger":
		Game.notify(Text.join([mind.display_name(), ": ", line]), kind, Game.local_player)







func seen(position: Vector3) -> bool:
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return false
	if camera.global_position.distance_to(position) > 140.0:
		return false
	return camera.is_position_in_frustum(position)


func ground(at: Vector3) -> Vector3:
	var hit: = Game.world.raycast(Vector3(at.x, at.y + 3.0, at.z), Vector3(at.x, at.y - 60.0, at.z), World.LAYER_SOLID)
	return hit["position"] if not hit.is_empty() else at






func free_spot(spot: Vector3, near: Vector3) -> Vector3:
	var tries: Array[Vector3] = [spot]
	for radius: float in [3.0, 5.0, 7.0, 9.0]:
		for step in 8:
			var angle: = TAU * step / 8.0
			tries.append(near + Vector3(cos(angle), 0, sin(angle)) * radius)
	var eyes: = ground(near) + Vector3(0, 2.5, 0)
	for at: Vector3 in tries:
		var foot: = ground(at)
		if _fits(foot) and Game.world.raycast(eyes, foot + Vector3(0, 2.5, 0), World.LAYER_SOLID).is_empty():
			return foot
	return ground(near)



func _fits(foot: Vector3) -> bool:
	var shape: = CapsuleShape3D.new()
	shape.radius = 1.0
	shape.height = 4.6
	var query: = PhysicsShapeQueryParameters3D.new()
	query.shape = shape
	query.transform = Transform3D(Basis.IDENTITY, foot + Vector3(0, 2.6, 0))
	query.collision_mask = World.LAYER_SOLID | World.LAYER_PLAYER
	return Game.world.get_world_3d().direct_space_state.intersect_shape(query, 1).is_empty()


func free_seat(vehicle: Vehicle) -> bool:
	for index in range(1, vehicle.riders.size()):
		if vehicle.riders[index] == null:
			return true
	return false



func door_spot(vehicle: Vehicle, door: String) -> Vector3:
	var doorway: Vector3 = vehicle.doors[door]["doorway"]
	return ground(vehicle.global_transform * Vector3(doorway.x + signf(doorway.x) * 2.5, 0.5, doorway.z) + Vector3(0, 2, 0))



func door_for(vehicle: Vehicle, from: Vector3, driving: = false) -> String:
	if driving:
		return "DoorCabLeft"
	var best: = ""
	var best_distance: = INF
	for door_name: String in vehicle.doors:
		if door_name == "DoorCabLeft" and vehicle.doors.size() > 1:
			continue
		var at: Vector3 = vehicle.global_transform * vehicle.doors[door_name]["doorway"]
		var distance: = at.distance_to(from)
		if distance < best_distance:
			best_distance = distance
			best = door_name
	return best
