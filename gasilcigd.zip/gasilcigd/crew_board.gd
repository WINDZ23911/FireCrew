class_name CrewBoard
extends Control








const WIDTH: = 520.0
const ROW: = 56.0
const HEADER: = 48.0

static var current: CrewBoard

var _plate: Control
var _rows: Control
var _title: Label
var _cash: Label
var _open: = false
var _choices: Array[Callable] = []
var _board: Node3D
var _page: = "main"


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 90)
	_title = Ui.caps("", 18)
	_title.position = Vector2(16, 14)
	_plate.add_child(_title)
	_cash = Ui.display("", 20, Ui.AMBER)
	_cash.position = Vector2(WIDTH - 180, 10)
	_cash.size = Vector2(164, 28)
	_cash.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_plate.add_child(_cash)
	_rows = Control.new()
	_rows.position = Vector2(8, HEADER)
	_rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate.add_child(_rows)
	_build_board.call_deferred()


func _exit_tree() -> void :
	if current == self:
		current = null



func _build_board() -> void :
	if Game.store == null or Game.world == null:
		return
	var row: = -1
	for index in Game.store.count:
		if Game.store.name_at(index) == "DutyBoard":
			row = index
			break
	if row < 0:
		return
	var place: = Game.store.transform(row)
	var size: = Game.store.size(row)

	var axis: = place.basis.x if size.x < size.y and size.x < size.z else (place.basis.y if size.y < size.z else place.basis.z)
	axis = axis.normalized()
	var behind: = Game.world.raycast(place.origin, place.origin - axis * 4.0, World.LAYER_SOLID)
	if behind.is_empty():
		axis = - axis
	_board = Node3D.new()
	_board.name = "CrewBoard"
	get_tree().current_scene.add_child(_board)
	_board.global_position = place.origin + axis * 1.0
	_board.set_meta("out", axis)

	if CrewService.enabled():
		var under: = Label3D.new()
		under.text = Text.say(Text.m("crew.board.under"))
		under.font_size = 36
		under.pixel_size = 0.01
		under.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		under.modulate = Ui.YELLOW
		under.outline_size = 8
		under.position = Vector3(0, - minf(size.y, 4.0) / 2.0 - 0.6, 0)
		_board.add_child(under)
		Text.language_changed.connect( func(_code: String) -> void : under.text = Text.say(Text.m("crew.board.under")))

	var prompt: = Prompt.new()
	prompt.net_id = "crew.board"
	prompt.action = Text.m("crew.board.action")
	prompt.object = Text.m("crew.board.object")
	prompt.reach = 10.0
	prompt.position = Vector3(0, -1.0, 0)
	prompt.condition = func(player: Player) -> bool: return player.brain == null and not Net.is_client()
	_board.add_child(prompt)
	prompt.triggered.connect( func(player: Player) -> void :
		if player.is_local:
			open()
	)


func is_open() -> bool:
	return _open


func open() -> void :
	if CrewService.current == null or Net.is_client():
		return
	_open = true
	_page = "main"
	_draw()
	_plate.visible = true
	MenuKit.take_mouse(Game.local_player, true)


func close() -> void :
	if not _open:
		return
	_open = false
	_plate.visible = false
	MenuKit.take_mouse(Game.local_player, false)


func _draw() -> void :
	for child in _rows.get_children():
		child.queue_free()
	_choices.clear()
	var service: = CrewService.current
	var lead: = Game.local_player
	_title.text = Text.say(Text.m("crew.board.title"))
	_cash.text = Ui.money(int(lead.get_attr("Cash", 0)))
	var index: = 0

	index += 1
	_row(index, Text.say(Text.m("crew.board.report")), Text.say(Text.m("crew.board.reportDetail")), Ui.GREEN, _report)
	index += 1
	_row(index, Text.say(Text.f("crew.board.shift", [Shift.words()])), Text.say(Shift.detail()), Ui.AMBER, _next_shift)
	if Net.active() or not CrewService.enabled():


		index += 1
		_row(index, Text.say(Text.m("crew.board.close")), "", Ui.DIM, close)
		_plate.size = Vector2(WIDTH, HEADER + index * ROW + 8)
		_plate.position = (get_viewport_rect().size - _plate.size) / 2.0
		return
	if _page == "hire":
		index = _draw_candidates(index)
		_finish(index)
		return
	if _page == "roles":
		index = _draw_roles(index)
		_finish(index)
		return
	for entry: Dictionary in service.roster.members:
		index += 1
		var level: int = entry["level"]
		var price: = service.roster.train_price(entry)
		var stars: = "★".repeat(level) + "☆".repeat(service.roster.levels() - 1 - level)
		var text: = "%s  ·  %s  %s" % [entry["name"], Text.say(CrewRoster.position_name(entry["role"])), stars]
		if not str(entry.get("trait", "")).is_empty():
			text += "  ·  " + Text.say(Text.m("crew.traits." + str(entry["trait"])))

		var unlock_key: = "crew.board.unlock.%d" % (level + 1)
		var detail: = Text.say(Text.f("crew.board.trainUnlock", [Ui.money(price), Text.m(unlock_key)])) if price >= 0 and Text.has(unlock_key)\
		else (Text.say(Text.f("crew.board.train", [Ui.money(price)])) if price >= 0 else Text.say(Text.m("crew.board.best")))
		var member: = entry
		_row(index, text, detail, entry.get("colour", Ui.TEXT), func() -> void : _train(member), price >= 0)
	var hire: = service.roster.hire_price()
	index += 1
	if hire >= 0:
		_row(index, Text.say(Text.m("crew.board.hire")), Text.say(Text.f("crew.board.hireChoose", [Ui.money(hire)])), Ui.GREEN, _hire)
	else:
		_row(index, Text.say(Text.m("crew.board.full")), "", Ui.DIM, func() -> void : pass, false)
	index += 1
	_row(index, Text.say(Text.m("crew.board.roles")), Text.say(Text.m("crew.board.rolesDetail")), Ui.TEXT, _page_to.bind("roles"))
	index += 1
	var acting: Variant = Text.f("crew.board.autonomy", [CrewService.level_name(service.autonomy)]) if service.auto else Text.m("crew.board.manual")
	_row(index, Text.say(acting), Text.say(Text.m("crew.board.autonomyDetail." + (CrewService.LEVELS[service.autonomy] if service.auto else "off"))), Ui.BLUE, _toggle_auto)
	index += 1
	_row(index, Text.say(Text.m("crew.board.close")), "", Ui.DIM, close)
	_plate.size = Vector2(WIDTH, HEADER + index * ROW + 8)
	_plate.position = (get_viewport_rect().size - _plate.size) / 2.0



func _draw_candidates(index: int) -> int:
	var service: = CrewService.current
	for candidate: Dictionary in service.roster.draw_candidates():
		index += 1
		var text: = "%s  ·  %s  ·  %s" % [candidate["name"], Text.say(CrewRoster.position_name(candidate["role"])), Text.say(Text.m("crew.traits." + str(candidate["trait"])))]
		var detail: = Text.say(Text.f("crew.board.candidateDetail", [Ui.money(int(candidate["price"])), Text.m("crew.traitsDetail." + str(candidate["trait"]))]))
		var which: = index - 3
		_row(index, text, detail, CrewRoster.role_colour(candidate["role"]), func() -> void : _hire_candidate(which))
	index += 1
	_row(index, Text.say(Text.m("crew.board.back")), "", Ui.DIM, _page_to.bind("main"))
	return index



func _draw_roles(index: int) -> int:
	var service: = CrewService.current
	for entry: Dictionary in service.roster.members:
		index += 1
		var text: = "%s  ·  %s" % [entry["name"], Text.say(CrewRoster.position_name(entry["role"]))]
		var member: = entry
		_row(index, text, Text.say(Text.m("crew.positionsDetail." + str(entry["role"]))), CrewRoster.role_colour(entry["role"]), func() -> void : _swap(member))
	index += 1
	_row(index, Text.say(Text.m("crew.board.rolesDone")), "", Ui.DIM, _page_to.bind("main"))
	return index


func _page_to(page: String) -> void :
	_page = page
	_draw()


func _finish(index: int) -> void :
	_plate.size = Vector2(WIDTH, HEADER + index * ROW + 8)
	_plate.position = (get_viewport_rect().size - _plate.size) / 2.0


func _swap(entry: Dictionary) -> void :
	var service: = CrewService.current
	var role: = service.roster.next_position(entry)
	for mind in service.members:
		if mind.member == entry:
			mind.set_role(role)
	service.crew_changed.emit()
	_draw()


func _row(index: int, text: String, detail: String, color: Color, choose: Callable, enabled: = true) -> void :
	var button: = MenuKit.row(Vector2(WIDTH - 16, ROW - 4), text, detail, color, choose, str(index) if index <= 9 else "", "", 20)
	button.disabled = not enabled
	button.position = Vector2(0, (index - 1) * ROW)
	_rows.add_child(button)
	_choices.append(choose if enabled else Callable())


func _train(entry: Dictionary) -> void :
	var lead: = Game.local_player
	if CrewService.current.train(lead, entry):
		Game.notify(Text.f("crew.board.trained", [entry["name"]]), "good", lead)
	else:
		Game.notify(Text.m("crew.board.noCash"), "warning", lead)
	_draw()



func _hire() -> void :
	_page = "hire"
	_draw()



func _hire_candidate(which: int) -> void :
	var lead: = Game.local_player
	var candidates: = CrewService.current.roster.draw_candidates()
	if which < 0 or which >= candidates.size():
		return
	if not CrewService.current.hire(lead, candidates[which]):
		Game.notify(Text.m("crew.board.noCash"), "warning", lead)
	_page = "main"
	_draw()


func _report() -> void :
	if Duty.current != null:
		Duty.current.report(Game.local_player)
	close()


func _next_shift() -> void :
	Shift.choose(Shift.following())
	_draw()



func _toggle_auto() -> void :
	var service: = CrewService.current
	if not service.auto:
		service.auto = true
		service.set_autonomy(CrewService.HANDS_ON)
	elif service.autonomy < CrewService.FULL:
		service.set_autonomy(service.autonomy + 1)
	else:
		service.auto = false
	service.roster.auto = service.auto
	service.roster.save()
	_draw()


func _unhandled_input(event: InputEvent) -> void :
	if not _open:
		return
	if event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
		return
	var number: = MenuKit.number_key(event)
	if number > 0 and number <= _choices.size():
		var chosen: Callable = _choices[number - 1]
		if chosen.is_valid():
			chosen.call()
		get_viewport().set_input_as_handled()


func _process(_delta: float) -> void :
	if _open and (Game.local_player == null or Game.local_player.health <= 0.0 or (_board != null and Game.local_player.global_position.distance_to(_board.global_position) > 20.0)):
		close()
