class_name JobAlarm
extends CrewJob





func _init() -> void :
	kind = "alarm"
	role = "rescue"


func place() -> Vector3:
	var alarm: = FireAlarm.current
	return (alarm._panel["holder"] as Node3D).global_position if alarm != null and not alarm._panel.is_empty() else who.body.global_position



static func zone(alarm: FireAlarm) -> String:
	if alarm._lcd.size() < 2 or not alarm._lcd[1] is Dictionary or not (alarm._lcd[1] as Dictionary).has("a"):
		return ""
	var house: House = alarm._panel["house"]
	var number: = int(alarm._lcd[1]["a"][0])
	var names: Array = house.rooms.keys()
	return names[number - 1] if number >= 1 and number <= names.size() else ""


func run() -> bool:
	var alarm: = FireAlarm.current
	if alarm == null or alarm._panel.is_empty():
		return fail("crew.say.nothingThere")
	var held: = who.token()
	var prompt: Prompt = alarm._panel["prompt"]
	CrewKit.free_hands(who)
	if not alarm._panel["read"]:
		if not await CrewKit.press_skilled(who, prompt):
			return fail("crew.say.cannot") if on(held) else false
		await who.wait(0.5, held)
	if Game.incident.get("kind") != "alarm":
		return true
	var room: = zone(alarm)
	if room.is_empty():
		return fail("crew.say.cannot")
	var house: House = alarm._panel["house"]
	who.report("crew.say.report.zone", [CrewSearch.room_words(room)], "info")
	var aim: = room
	var reached: = await who.go(CrewSearch.middle(house, room), 3.0, 60.0, func() -> bool:
		var inside: Variant = house.room_at(who.body.root_position())
		return inside != null and inside["name"] == aim)
	if not reached:
		if not who.blocked_by.is_empty() and who.blocked_by["locked"]:
			await CrewSearch.force_way(who, who.blocked_by, held)
		return fail("crew.say.cannotReach", [CrewSearch.room_words(room)]) if on(held) else false
	if not await who.wait(1.5, held):
		return false
	if Game.incident.get("kind") != "alarm" or Game.incident.is_empty():
		return true

	if not await CrewKit.press_skilled(who, prompt):
		return fail("crew.say.cannot") if on(held) else false
	return true
