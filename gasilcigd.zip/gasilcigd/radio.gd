class_name Radio
extends Node













static var current: Radio

const STREET_LETTERS: = {"č": "c", "š": "s", "ž": "z", "ć": "c", "đ": "d", "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss"}

var _last_call: = ""
var _said: Dictionary = {}
var _queue: Array[String] = []
var _playing: AudioStreamPlayer
var _started_at: = 0.0


func _init() -> void :
	current = self


func _ready() -> void :
	_started_at = Game.now()
	Game.incident_changed.connect(_on_incident)
	Game.incident_ending.connect(_on_ending)
	Game.call_started.connect( func(_kind: String) -> void : _said.clear())
	Net.handle("radio.line", func(text: Variant, kind: String, piece: String) -> void : _hear(text, kind, piece))





static func say(text: Variant, kind: = "info", piece: = "") -> void :
	if Net.is_client() or current == null:
		return
	current._hear(text, kind, piece)
	if Net.active():
		Net.broadcast("radio.line", [text, kind, piece])



func _hear(text: Variant, kind: String, piece: String) -> void :
	Game.notified.emit(text, kind, Game.local_player)
	Sounds.ui("ui_squelch", 1.0, float(Config.Dispatch.SquelchVolume))
	if not piece.is_empty():
		_speak([piece])





func _on_incident() -> void :
	var incident: = Game.incident
	if incident.is_empty() or not incident.has("pos") or not incident.has("kind") or incident.get("failed") != null:
		return
	var at: Vector3 = incident["pos"]
	var key: = "%s@%d,%d" % [incident["kind"], roundi(at.x / 10.0), roundi(at.z / 10.0)]
	if key == _last_call:
		return
	_last_call = key
	if Game.now() - _started_at < float(Config.Dispatch.QuietAfterStart):
		return
	_call_out.call_deferred(key)



func _call_out(key: String) -> void :
	await get_tree().create_timer(float(Config.Dispatch.Delay), false).timeout
	if key != _last_call or Game.incident.is_empty():
		return
	var said: = dispatch_line(Game.incident)
	Game.notified.emit(said[0], "info", Game.local_player)
	Sounds.ui("ui_squelch", 1.0, float(Config.Dispatch.SquelchVolume))
	_speak(said[1])



static func dispatch_line(incident: Dictionary) -> Array:
	var kind: String = incident["kind"]
	var address: = address_of(incident["pos"])
	var level: = clampi(int(incident.get("alarm", Alarm.level)), 1, 3)

	var people: bool = int(incident.get("victims", 0)) > 0 and kind == "fire"

	var said: String = incident.get("radio", kind)
	var text: = Text.f("radio.dispatch", [Text.m("radio.kinds." + said), address[0], Text.m("radio.people") if people else "", Alarm.numeral(level)])
	var pieces: Array[String] = ["open", "kind_" + said]
	if address[1] != "":
		pieces.append("street_" + address[1])
	if people:
		pieces.append("people")
	pieces.append("level_%d" % level)
	return [text, pieces]




static func address_of(at: Vector3) -> Array:
	var layout: Dictionary = Rbx.module("TownLayout")
	var best: Variant = null
	var nearest: = float(Config.Dispatch.BuildingReach)
	for building: Dictionary in layout.get("buildings", []):
		if str(building.get("street", "")) == "":
			continue
		var away: = Vector2(float(building["x"]) - at.x, float(building["z"]) - at.z).length()
		if away < nearest:
			nearest = away
			best = building
	if best != null:
		var street: = str(best["street"])
		var number: = str(best.get("number", ""))
		return [(street + " " + number).strip_edges(), street_piece(street)]
	var found: = Roads.nearest(layout, at.x, at.z)
	var road: Dictionary = found[1]
	if not road.is_empty() and str(road.get("name", "")) != "":
		return [str(road["name"]), street_piece(str(road["name"]))]
	return [Text.say(Text.m("calls.town")), ""]



static func street_piece(street: String) -> String:
	var plain: = street.to_lower()
	for letter: String in STREET_LETTERS:
		plain = plain.replace(letter, STREET_LETTERS[letter])
	var out: = ""
	for index in plain.length():
		var c: = plain[index]
		out += c if (c >= "a" and c <= "z") or (c >= "0" and c <= "9") else "_"
	while out.contains("__"):
		out = out.replace("__", "_")
	return out.strip_edges().trim_prefix("_").trim_suffix("_")





func _process(_delta: float) -> void :
	if Net.is_client() or not Alarm.active or Game.incident.is_empty():
		return
	if Alarm.arrived_at >= 0.0 and not _said.has("arrived"):
		_said["arrived"] = true
		say(Text.m("radio.arrived"), "info", "arrived")
	if Alarm.job_done_at >= 0.0 and not _said.has("done") and Game.incident.get("kind") == "fire":
		_said["done"] = true
		say(Text.m("radio.underControl"), "good", "under_control")


func _on_ending(last: Dictionary) -> void :
	if Net.is_client() or not Alarm.active or _said.has("clear") or not _said.has("arrived"):
		return
	_said["clear"] = true
	if last.get("failed", false) != true:
		say(Text.m("radio.allClear"), "good", "all_clear")






func _speak(pieces: Array[String]) -> void :
	if float(Config.Dispatch.VoiceVolume) <= 0.0:
		return
	_queue.append_array(pieces)
	if not is_instance_valid(_playing):
		_next()


func _next() -> void :
	while not _queue.is_empty():
		var piece: String = _queue.pop_front()
		var stream: = _piece(piece)
		if stream == null:
			continue
		_playing = AudioStreamPlayer.new()
		_playing.stream = stream
		_playing.volume_db = linear_to_db(float(Config.Dispatch.VoiceVolume))
		add_child(_playing)
		_playing.finished.connect( func() -> void :
			_playing.queue_free()
			_playing = null
			_next()
		)
		_playing.play()
		Soundtrack.under(_playing)
		return




static func _piece(piece: String) -> AudioStream:
	if piece.begins_with("street_"):
		return Assets.sound("radio_" + piece)
	if Text.language == "sl" or Text.language == "de":
		var own: = Assets.sound("radio_%s_%s" % [Text.language, piece])
		if own:
			return own
	return Assets.sound("radio_en_" + piece)
