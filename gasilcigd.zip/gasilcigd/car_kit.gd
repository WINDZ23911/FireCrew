class_name CarKit
extends RefCounted













const PAINTS: Array[Color] = [
	Color8(118, 42, 40), Color8(40, 58, 96), Color8(200, 200, 205), 
	Color8(40, 42, 46), Color8(190, 176, 140), Color8(78, 104, 84), 
	Color8(226, 226, 222), Color8(84, 94, 108), 
]
const PAINTED: = {"Body": true, "Bonnet": true, "DoorL": true, "DoorR": true}

const LOOKS: = {
	"Glass": [Color8(44, 54, 66), 0.08, 0.2, 0.2], 
	"Trim": [Color8(30, 31, 34), 0.5, 0.0, 0.0], 
	"Tyres": [Color8(28, 28, 30), 0.85, 0.0, 0.0], 
	"Hubs": [Color8(176, 180, 186), 0.38, 0.75, 0.0], 
	"Light": [Color8(236, 234, 220), 0.5, 0.0, 0.0], 
	"Red": [Color8(170, 26, 22), 0.5, 0.0, 0.0], 
}

const WIDTH: = 6.5
const LENGTH: = 15.1


const WEIGHTS: = {"Small": 25, "Hatch": 25, "Estate": 15, "SUV": 15, "Saloon": 10, "Van": 10}

const PLATE_SIZE: = Vector2(1.9, 0.4)


const PLATES: = [Vector3(0, 1.32, -7.69), Vector3(0, 1.7, 7.655)]
const KIT: = "res://assets/models/town_cars.glb"
const KIT_DATA: = "res://data/godot/TownCarData.json"

static var _own: Dictionary = Edition.data().get("town_cars", {})
static var _plates: Dictionary = Edition.data().get("plates", {})
static var _kit_path: String = "res://assets/models/%s.glb" % _own["kit"] if _own.has("kit") else KIT
static var _data_path: String = "res://data/godot/%s.json" % _own["data"] if _own.has("data") else KIT_DATA
static var _weights: Dictionary = _own.get("weights", WEIGHTS)
static var _paints: Array[Color] = _read_paints(_own.get("paints", []))
const OLD_KIT: = "res://assets/models/car_kit.glb"
const OLD_DATA: = "res://data/modules/CarData.json"
const PLATE_ROWS: = 32

static var _pieces: Dictionary = {}
static var _shapes: Array[String] = []
static var _data: Dictionary = {}
static var _materials: Dictionary = {}
static var _plate_mesh: QuadMesh
static var _plate_material: ShaderMaterial
static var _loaded: = false
static var _shaded: = false


static func _load() -> void :
	if _loaded:
		return
	_loaded = true
	var scene: PackedScene = null
	var measures: Variant = null
	if ResourceLoader.exists(_kit_path) and FileAccess.file_exists(_data_path):
		scene = load(_kit_path)
		measures = Rbx.load_json(_data_path)
		_shaded = scene != null and measures is Dictionary
	if not _shaded:
		scene = load(OLD_KIT) if ResourceLoader.exists(OLD_KIT) else null
		measures = Rbx.load_json(OLD_DATA)
	_data = measures if measures is Dictionary else {}
	if scene == null:
		push_warning("CarKit: no car kit; there will be no cars")
		return
	var kit: = scene.instantiate()
	for child in kit.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() != 2 or bits[0] == "Marker" or not _data.has(bits[0]):
			continue
		if not _pieces.has(bits[0]):
			_pieces[bits[0]] = {}
		_pieces[bits[0]][bits[1]] = mesh.mesh
	kit.free()
	for shape: String in _pieces:
		_shapes.append(shape)
	_shapes.sort()



static func shapes() -> Array[String]:
	_load()
	return _shapes




static func pick(car_seed: int, longest: = INF) -> String:
	_load()
	if _shapes.is_empty():
		return ""
	var fitting: Array[String] = []
	var total: = 0
	for shape in _shapes:
		if length_of(shape) <= longest:
			fitting.append(shape)
			total += int(_weights.get(shape, 10))
	if fitting.is_empty():
		var shortest: = _shapes[0]
		for shape in _shapes:
			if length_of(shape) < length_of(shortest):
				shortest = shape
		return shortest
	var roll: int = rand_from_seed(hash([car_seed, "shape"]))[0] %total
	for shape in fitting:
		roll -= int(_weights.get(shape, 10))
		if roll < 0:
			return shape
	return fitting[0]



static func length_of(shape: String) -> float:
	_load()
	return float(_data.get(shape, {}).get("length", LENGTH))




static func data(shape: String) -> Dictionary:
	_load()
	return _data.get(shape, {})



static func meshes(shape: String) -> Dictionary:
	_load()
	return _pieces.get(shape, {})



static func paint_of(paint: int) -> Color:
	return _paints[posmod(paint - 1, _paints.size())]


static func _read_paints(list: Array) -> Array[Color]:
	var out: Array[Color] = []
	for entry: Variant in list:
		if entry is Array and entry.size() >= 3:
			out.append(Color8(int(entry[0]), int(entry[1]), int(entry[2])))
	return out if not out.is_empty() else PAINTS



static func width_of(shape: String) -> float:
	return float(data(shape).get("width", WIDTH))



static func work_shape() -> String:
	return str(_own.get("work", "Van"))





static func street_paint(paint: Color, source: Color, key: int) -> Color:
	if not _own.has("paints"):
		return muted(paint)
	var own: = _paints[rand_from_seed(hash([key, "paint"]))[0] %_paints.size()]
	return own if paint.is_equal_approx(source) else own.lerp(paint, 0.85)



static func plate_size() -> Vector2:
	var size: Variant = _plates.get("size")
	return Vector2(float(size[0]), float(size[1])) if size is Array and size.size() == 2 else PLATE_SIZE



static func plate_ends() -> Array[int]:
	var ends: Array[int] = [1]
	if bool(_plates.get("front", true)):
		ends.push_front(0)
	return ends




static func muted(paint: Color) -> Color:
	if paint.s < 0.35 or paint.v < 0.2:
		return paint
	return Color.from_hsv(paint.h, paint.s * float(Config.Art.CarMute), paint.v * 0.92, paint.a)




static func material(piece: String, paint: = Color.WHITE, instanced: = false) -> Material:
	var painted: = PAINTED.has(piece)
	var key: Variant = [paint, instanced] if painted else piece
	if _materials.has(key):
		return _materials[key]
	if painted:

		var lacquer: = ShaderMaterial.new()
		lacquer.shader = load("res://shaders/car_paint.gdshader")
		lacquer.set_shader_parameter("paint", paint)
		lacquer.set_shader_parameter("instanced", instanced)
		_materials[key] = lacquer
		return lacquer
	var made: = StandardMaterial3D.new()
	if piece == "Glass":

		var tint: Color = LOOKS["Glass"][0]
		_materials[key] = VehicleLook.glass(Color(tint.r, tint.g, tint.b, 0.72), 0.6)
		return _materials[key]
	else:
		var look: Array = LOOKS.get(piece, LOOKS["Trim"])
		made.albedo_color = look[0]
		made.roughness = look[1]
		made.metallic = look[2]
		_load()
		if _shaded:

			made.albedo_color = Color.WHITE
			made.vertex_color_use_as_albedo = true
			if piece == "Hubs":
				made.metallic = 0.35
		if look[3] > 0.0:
			made.albedo_color.a = 1.0 - look[3]
			made.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			made.cull_mode = BaseMaterial3D.CULL_DISABLED
	_materials[key] = made
	return made



static func plate_look() -> Array:
	if _plate_mesh == null:
		_plate_mesh = QuadMesh.new()
		_plate_mesh.size = plate_size()
		_plate_material = ShaderMaterial.new()
		_plate_material.shader = load("res://shaders/plate.gdshader")
		var atlas: = "res://assets/textures/town/%s.png" % str(_plates.get("atlas", "plates"))
		_plate_material.set_shader_parameter("plates", load(atlas if ResourceLoader.exists(atlas) else "res://assets/textures/town/plates.png"))
	return [_plate_mesh, _plate_material]



static func plate_place(end: int, shape: = "") -> Transform3D:
	return Transform3D(Basis(Vector3.UP, PI) if end == 0 else Basis.IDENTITY, plate_at(end, shape))



static func plate_at(end: int, shape: = "") -> Vector3:
	var plates: Variant = data(shape).get("plates") if shape != "" else null
	if plates is Dictionary:
		var at: Variant = plates.get("front" if end == 0 else "back")
		if at is Array and at.size() == 3:
			return Vector3(float(at[0]), float(at[1]), float(at[2]))
	return PLATES[end]





static func build(shape: String, paint: Color, plate: = 0) -> Node3D:
	_load()
	var car: = Node3D.new()
	car.name = "Car"
	var found: Dictionary = _pieces.get(shape, {})
	for piece: String in found:
		var mesh: = MeshInstance3D.new()
		mesh.name = piece
		mesh.mesh = found[piece]
		mesh.material_override = material(piece, paint)
		if LOOKS.has(piece):
			mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		car.add_child(mesh)
	VehicleLook.contact_shadow(car, Vector3.ZERO, width_of(shape), length_of(shape))
	if plate >= 0 and not found.is_empty():
		var look: = plate_look()
		for end in plate_ends():
			var quad: = MeshInstance3D.new()
			quad.name = "Plate"
			quad.mesh = look[0]
			quad.material_override = look[1]
			quad.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			quad.transform = plate_place(end, shape)
			quad.set_instance_shader_parameter("row", float(posmod(plate, PLATE_ROWS)))
			car.add_child(quad)
	return car
