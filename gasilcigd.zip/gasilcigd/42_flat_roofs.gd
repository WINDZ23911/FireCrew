extends RefCounted




const ROOF_TONES: = [Color8(120, 116, 110), Color8(104, 102, 100), Color8(132, 124, 112), Color8(92, 90, 92)]
const COPING: = Color8(206, 204, 198)
const PLANT: = Color8(196, 198, 200)
const DARK: = Color8(58, 60, 64)
const PANEL: = Color8(36, 48, 76)
const MARGIN: = 2.2


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var folder: = kit.own_folder("Roofs")
	var made: = store.count
	var roofs: = 0
	for shell: Dictionary in kit.get_meta("shells"):
		var roof: int = shell["flat_roof"]
		if roof < 0:
			continue
		roofs += 1
		var rng: = kit.rng("flatroof:%d" % shell["model"])
		var place: Transform3D = shell["place"]
		var width: float = shell["width"]
		var depth: float = shell["depth"]
		var top: = store.position(roof).y + store.size(roof).y / 2.0
		var base: = place.origin.y
		var level: = top - base

		var tone: Color = ROOF_TONES[rng.randi_range(0, ROOF_TONES.size() - 1)]

		kit.box(folder, place * Transform3D(Basis(), Vector3(0, level + 0.03, 0)), Vector3(width - 0.7, 0.06, depth - 0.7), tone, "Pebble", "RoofGravel")

		for row: int in shell["rows"].get("Parapet", []):
			var at: = store.transform(row).orthonormalized()
			var size: = store.size(row)
			kit.box(folder, at * Transform3D(Basis(), Vector3(0, size.y / 2.0 + 0.1, 0)), Vector3(size.x + 0.25, 0.2, size.z + 0.25), COPING, "Concrete", "Coping")

		var low: bool = shell["height"] <= 10.5
		if width < 14.0 or depth < 14.0:
			continue

		var taken: Array = []
		for part_name in ["StairHead", "Penthouse", "RoofVent", "Sign"]:
			for row: int in shell["rows"].get(part_name, []):
				var local: = place.affine_inverse() * store.transform(row)
				var size: = store.size(row)
				var half: = Vector2(absf(local.basis.x.x) * size.x + absf(local.basis.z.x) * size.z, absf(local.basis.x.z) * size.x + absf(local.basis.z.z) * size.z) / 2.0
				taken.append(Rect2(Vector2(local.origin.x, local.origin.z) - half - Vector2.ONE, half * 2.0 + Vector2(2, 2)))
		var area: = width * depth
		var blocks: bool = shell["balconies"] or shell["height"] > 30.0


		for i in clampi(int(area / 700.0) + rng.randi_range(0, 1), 1, 4 if not low else 1):
			var spot: = _spot(rng, width, depth, Vector2(3.6, 3.0), taken)
			if spot == Vector2.INF:
				continue
			var unit: = place * Transform3D(Basis(), Vector3(spot.x, level + 1.0, spot.y))
			kit.box(folder, unit, Vector3(3.2, 2.0, 2.6), PLANT, "Metal", "AirUnit")
			kit.post(folder, unit * Vector3(0, 1.0, 0), 0.12, 1.9, DARK, "Metal", "AirFan")
			kit.box(folder, unit * Transform3D(Basis(), Vector3(0, -0.9, 0)), Vector3(3.4, 0.2, 2.8), DARK, "Metal", "AirFeet")


		for i in rng.randi_range(1, 3):
			var spot: = _spot(rng, width, depth, Vector2(1.2, 1.2), taken)
			if spot == Vector2.INF:
				continue
			var foot: = place * Vector3(spot.x, level, spot.y)
			var tall: = rng.randf_range(1.6, 3.2)
			kit.post(folder, foot, tall, 0.55, PLANT.darkened(0.15), "Metal", "VentPipe")
			kit.post(folder, foot + Vector3(0, tall, 0), 0.3, 1.0, DARK, "Metal", "VentCap")

		if low:
			continue


		if blocks or rng.randf() < 0.4:
			for i in rng.randi_range(1, 3 if blocks else 1):
				var spot: = _spot(rng, width, depth, Vector2(2, 2), taken)
				if spot != Vector2.INF:
					_aerial(kit, folder, place * Vector3(spot.x, level, spot.y), place.basis, rng)


		if blocks:
			for i in rng.randi_range(1, 4):
				var spot: = _spot(rng, width, depth, Vector2(2.4, 2.4), taken)
				if spot != Vector2.INF:
					_dish(kit, folder, place * Vector3(spot.x, level, spot.y), rng)


		if area > 900.0 and rng.randf() < (0.3 if blocks else 0.55):
			var tilt: = Basis(Vector3.RIGHT, deg_to_rad(-24.0))
			var laid: = 0
			var x0: = - width / 2.0 + MARGIN + 2.0
			var z0: = - depth / 2.0 + MARGIN + 2.5
			var z: = z0
			while z < depth / 2.0 - MARGIN - 2.5 and laid < 28:
				var x: = x0
				while x < width / 2.0 - MARGIN - 1.8 and laid < 28:
					var rect: = Rect2(Vector2(x - 1.9, z - 2.8), Vector2(3.8, 5.6))
					var free: = true
					for other: Rect2 in taken:
						if other.intersects(rect):
							free = false
							break
					if free:
						var at: = place * Transform3D(tilt, Vector3(x, level + 1.3, z))
						kit.box(folder, at, Vector3(3.4, 0.15, 4.8), PANEL, "SmoothPlastic", "SolarPanel")
						kit.box(folder, place * Transform3D(Basis(), Vector3(x, level + 1.1, z + 1.7)), Vector3(3.0, 2.2, 0.2), DARK, "Metal", "SolarStand")
						laid += 1
					x += 3.8
				z += 7.0
			if laid > 0:
				taken.append(Rect2(Vector2( - width / 2.0, - depth / 2.0), Vector2(width, depth)))
	return "%d flat roofs dressed (%d parts)" % [roofs, store.count - made]



static func _spot(rng: RandomNumberGenerator, width: float, depth: float, size: Vector2, taken: Array) -> Vector2:
	for attempt in 12:
		var x: = rng.randf_range( - width / 2.0 + MARGIN + size.x / 2.0, width / 2.0 - MARGIN - size.x / 2.0)
		var z: = rng.randf_range( - depth / 2.0 + MARGIN + size.y / 2.0, depth / 2.0 - MARGIN - size.y / 2.0)
		var rect: = Rect2(Vector2(x, z) - size / 2.0 - Vector2(0.5, 0.5), size + Vector2(1, 1))
		var free: = true
		for other: Rect2 in taken:
			if other.intersects(rect):
				free = false
				break
		if free:
			taken.append(rect)
			return Vector2(x, z)
	return Vector2.INF



static func _aerial(kit: PolishKit, folder: int, foot: Vector3, turn: Basis, rng: RandomNumberGenerator) -> void :
	var tall: = rng.randf_range(6.0, 10.0)
	kit.post(folder, foot, tall, 0.2, DARK, "Metal", "AerialMast")
	var along: = (turn * Vector3.RIGHT).rotated(Vector3.UP, rng.randf_range(-0.6, 0.6))
	for i in 3:
		var y: = tall - 0.4 - i * 1.3
		var reach: = 2.2 - i * 0.4
		kit.rod(folder, foot + Vector3(0, y, 0) - along * reach, foot + Vector3(0, y, 0) + along * reach, 0.1, DARK, "Metal", "AerialArm")



static func _dish(kit: PolishKit, folder: int, foot: Vector3, rng: RandomNumberGenerator) -> void :
	var look: = Vector3(-0.55, 0.62, 0.55).rotated(Vector3.UP, rng.randf_range(-0.15, 0.15)).normalized()
	kit.post(folder, foot, 1.4, 0.25, DARK, "Metal", "DishStand")
	var middle: = foot + Vector3(0, 2.1, 0)
	kit.rod(folder, middle - look * 0.12, middle + look * 0.12, 2.2, Color8(232, 232, 228), "SmoothPlastic", "Dish")
	kit.rod(folder, middle, middle + look * 1.3, 0.1, DARK, "Metal", "DishArm")
