extends RefCounted







const LINES: = preload("res://scripts/world/polish/passes/60_power_lines.gd")
const SPACING: = 100.0
const ROADS: = ["trunk", "primary", "secondary", "tertiary", "residential", "unclassified", "living_street"]
const KERB_IN: = 1.8
const JUNCTION_CLEAR: = 26.0


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "us":
		return ""
	var parent: = kit.own_folder("UtilityPoles")
	var layout: = kit.layout()
	var junctions: Array[Vector3] = []
	for node: Dictionary in layout["nodes"]:
		if node["kind"] == "junction":
			junctions.append(Vector3(float(node["x"]), 0, float(node["z"])))
	var poles: Array = []
	for road: Dictionary in layout["roads"]:
		if not ROADS.has(road["class"]):
			continue
		var side: = 1.0 if rand_from_seed(hash([str(road.get("name", "")), int(road["from"]), "poles"]))[0] %2 == 0 else -1.0
		var setback: = float(road["width"]) / 2.0 + KERB_IN
		var since: = SPACING * 0.5
		var points: Array = road["points"]
		for leg in points.size() - 1:
			var a: = Vector3(float(points[leg][0]), 0, float(points[leg][1]))
			var b: = Vector3(float(points[leg + 1][0]), 0, float(points[leg + 1][1]))
			var length: = a.distance_to(b)
			if length < 1.0:
				continue
			var along: = (b - a) / length
			var across: = Vector3( - along.z, 0, along.x) * side
			var walked: = SPACING - since
			while walked < length:
				var on_road: = a + along * walked
				walked += SPACING
				var foot: = _spot(kit, on_road, across, setback, junctions)
				if foot == Vector3.INF:
					continue
				poles.append([foot, along, LINES._pole(kit, parent, foot, along, poles.size() % 7 == 4, - across)])
			since = length - (walked - SPACING)


	var spans: = 0
	var strung: = {}
	for i in poles.size():
		var here: Vector3 = poles[i][0]
		var along: Vector3 = poles[i][1]
		for way: float in [1.0, -1.0]:
			var best: = -1
			var best_distance: = SPACING * 2.2
			for j in poles.size():
				if j == i:
					continue
				var there: Vector3 = poles[j][0]
				var gap: = here.distance_to(there)
				if gap < 30.0 or gap >= best_distance:
					continue
				if (there - here).normalized().dot(along * way) < 0.94:
					continue
				best = j
				best_distance = gap
			if best < 0:
				continue
			var key: = Vector2i(mini(i, best), maxi(i, best))
			if strung.has(key):
				continue
			strung[key] = true
			for wire in 3:
				LINES._wire(kit, parent, poles[i][2][wire], poles[best][2][wire])
			spans += 1
	return "USA utility poles: %d poles, %d spans of wire" % [poles.size(), spans]


static func _spot(kit: PolishKit, on_road: Vector3, across: Vector3, setback: float, junctions: Array[Vector3]) -> Vector3:
	for at: Vector3 in junctions:
		if at.distance_to(on_road) < JUNCTION_CLEAR:
			return Vector3.INF
	for slide: float in [0.0, 6.0, -6.0, 12.0]:
		var foot: = on_road + across * setback + Vector3( - across.z, 0, across.x) * slide
		if kit.surface_at(foot) in ["pavement", "verge", "paving", ""] and StreetKit.clear_below(kit, foot, 1.2, 9.0, 0.6):
			return foot
	return Vector3.INF
