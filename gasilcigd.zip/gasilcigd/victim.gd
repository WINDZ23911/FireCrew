class_name Victim
extends RefCounted






var id: = 0
var seed: = 0
var state: = "lying"
var condition: = 100.0
var figure: Figure
var prompt: Prompt
var carrier: Player
var room: = ""
var casualty: = false
var sick: = 0.0
var drain: = 0.0
var bar: MeshInstance3D


var found: = true
var reported: = false
var spot: = ""

var mode: = "carry"
var on_board: = false
var mode_since: = 0.0
var helper: Player


var tag: = ""
var tagged: = false
var tag_prompt: Prompt
var tag_label: Label3D
var next_cue: = 0.0



func waiting() -> bool:
	return state == "lying" or state == "carried" or state == "trapped" or state == "walking"



func position() -> Vector3:
	return figure.global_position if is_instance_valid(figure) and figure.is_inside_tree() else Vector3.ZERO
