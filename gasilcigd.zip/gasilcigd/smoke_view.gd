class_name SmokeView
extends ColorRect







static var current: SmokeView

const SHADER: = "\nshader_type canvas_item;\nuniform float amount = 0.0;\nuniform vec3 smoke : source_color = vec3(0.12, 0.11, 0.105);\nuniform float lamp = 0.2;  // the lamp's pool, as a share of the screen's height\nuniform float lamp_share = 0.45;  // how much of the smoke is left in it\nuniform vec4 flames[8];  // where a fire shows through: x, y (0-1 of the screen), radius (of its height), strength\nuniform int flame_count = 0;\nuniform float aspect = 1.78;\nvoid fragment() {\n\tvec2 p = (SCREEN_UV - vec2(0.5)) * vec2(aspect, 1.0);\n\tfloat a = amount * mix(lamp_share, 1.0, smoothstep(lamp * 0.35, lamp, length(p)));\n\tvec3 col = smoke;\n\tfor (int i = 0; i < 8; i++) {\n\t\tif (i >= flame_count) break;\n\t\tvec2 q = (SCREEN_UV - flames[i].xy) * vec2(aspect, 1.0);\n\t\tfloat near = 1.0 - smoothstep(flames[i].z * 0.25, flames[i].z, length(q));\n\t\tfloat glow = near * flames[i].w;\n\t\ta *= 1.0 - 0.75 * glow;\n\t\tcol = mix(col, vec3(1.0, 0.45, 0.08), glow * 0.8);\n\t}\n\tCOLOR = vec4(col, a);\n}\n"
























var _amount: = 0.0
var _material: ShaderMaterial


func _ready() -> void :
	current = self
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_material = ShaderMaterial.new()
	var shader: = Shader.new()
	shader.code = SHADER
	_material.shader = shader
	material = _material
	color = Color.WHITE
	visible = false



static func lost_at(player: Player) -> float:
	if player == null or player.health <= 0.0 or Settings.reduce_smoke or player.get_attr("Tool") == Thermal.TOOL_NAME:
		return 0.0
	var smoke: Dictionary = Config.Fire.Smoke
	var view: Dictionary = smoke["View"]
	var head: = player.head_position()
	for house in House.all:
		if house.position.distance_to(head) > 90.0:
			continue
		var room: Variant = house.room_at(head)
		if room == null:
			continue
		var level: = float(room.get("level", 0.0))

		var from: = float(smoke["MoreBlindFrom"] if Settings.smoke == Settings.SMOKE_MORE else smoke["BlindFrom"])
		var blind: = smoothstep(from, 1.0, level)
		return blind * (float(view["Crouched"]) if house.below_smoke(room, head) else float(view["Most"]))
	return 0.0


func _process(delta: float) -> void :
	var player: = Game.local_player
	var want: = lost_at(player)
	var view: Dictionary = Config.Fire.Smoke.View
	_amount = move_toward(_amount, want, delta * float(view["Ease"]))
	visible = _amount > 0.01
	if not visible:
		return
	var size: = get_viewport_rect().size
	_material.set_shader_parameter("amount", _amount)
	_material.set_shader_parameter("lamp", float(view["Lamp"]))
	_material.set_shader_parameter("lamp_share", float(view["LampShare"]))
	_material.set_shader_parameter("aspect", size.x / maxf(size.y, 1.0))
	var day: = Sky3D.current.daylight() if Sky3D.current else 1.0
	_material.set_shader_parameter("smoke", Color(0.12, 0.11, 0.105) * lerpf(0.55, 1.0, day))

	var camera: = get_viewport().get_camera_3d()
	var shown: Array[Vector4] = []
	if camera != null:
		var reach: = float(view["FlameReach"])
		for flame in Flame.all:
			if shown.size() >= 8:
				break
			if not is_instance_valid(flame) or flame.intensity <= 0.01:
				continue
			var offset: = flame.global_position - camera.global_position
			var depth: = offset.dot( - camera.global_basis.z)
			if depth < 0.5 or offset.length() > reach:
				continue
			var at: = camera.unproject_position(flame.global_position + Vector3(0, 1.0, 0)) / size
			var radius: = float(view["FlameSize"]) * (0.5 + flame.intensity) / (2.0 * tan(deg_to_rad(camera.fov) / 2.0) * depth)
			shown.append(Vector4(at.x, at.y, clampf(radius, 0.03, 0.6), clampf(1.0 - offset.length() / reach, 0.0, 1.0) * (0.5 + 0.5 * flame.intensity)))
	var padded: Array[Vector4] = shown.duplicate()
	while padded.size() < 8:
		padded.append(Vector4.ZERO)
	_material.set_shader_parameter("flames", padded)
	_material.set_shader_parameter("flame_count", shown.size())
