class_name Ballistics
extends RefCounted






static func launch(origin: Vector3, target: Vector3, speed: float, gravity: float) -> Vector3:
	var offset: = target - origin
	var across: = Vector3(offset.x, 0, offset.z)
	var distance: = across.length()
	var height: = offset.y
	if distance < 0.001:
		return Vector3(0, speed if height >= 0 else - speed, 0)
	var squared: = speed * speed
	var root: = squared * squared - gravity * (gravity * distance * distance + 2.0 * height * squared)
	var slope: float
	if root >= 0.0:
		slope = (squared - sqrt(root)) / (gravity * distance)
	else:

		slope = tan(PI / 4.0 + atan2(height, distance) / 2.0)
	var forward: = speed / sqrt(1.0 + slope * slope)
	return across / distance * forward + Vector3(0, slope * forward, 0)





static func launch_toward(origin: Vector3, target: Vector3, speed: float, gravity: float) -> Vector3:
	return launch(origin, target, speed, gravity)



static func reachable(origin: Vector3, target: Vector3, speed: float, gravity: float) -> bool:
	var offset: = target - origin
	var distance: = Vector2(offset.x, offset.z).length()
	if distance < 0.001:
		return offset.y <= speed * speed / (2.0 * gravity)
	var squared: = speed * speed
	return squared * squared - gravity * (gravity * distance * distance + 2.0 * offset.y * squared) >= 0.0


static func position(origin: Vector3, velocity: Vector3, gravity: float, t: float) -> Vector3:
	return origin + velocity * t - Vector3(0, gravity * t * t / 2.0, 0)


static func velocity_at(velocity: Vector3, gravity: float, t: float) -> Vector3:
	return velocity - Vector3(0, gravity * t, 0)





static func trace(origin: Vector3, velocity: Vector3, gravity: float, duration: float, steps: int, cast: Callable) -> Dictionary:
	var step: = duration / steps
	var from: = origin
	var path: = PackedVector3Array([origin])
	for index in range(1, steps + 1):
		var to: = position(origin, velocity, gravity, index * step)
		var hit: Variant = cast.call(from, to)
		if hit != null:
			path.append(hit)
			var covered: float = (hit - from).length() / maxf((to - from).length(), 1e-06)
			return {"path": path, "hit": true, "time": (index - 1 + covered) * step}
		path.append(to)
		from = to
	return {"path": path, "hit": false, "time": duration}
