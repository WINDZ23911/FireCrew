class_name NextSteps
extends Node










static var current: NextSteps

var _clock: = 0.0
var _streets: Dictionary = {}


func _init() -> void :
	current = self


func _ready() -> void :

	Game.incident_changed.connect(apply)


func _exit_tree() -> void :
	if current == self:
		current = null


func _process(delta: float) -> void :
	_clock += delta
	if _clock >= float(settings()["Every"]):
		_clock = 0.0
		apply()


static func settings() -> Dictionary:
	return Config.Onboarding.NextSteps



func apply() -> void :
	var incident: = Game.incident
	if incident.is_empty() or incident.has("failed") or not incident.has("pos"):
		return
	var own: Variant = incident["scene_next"] if incident.has("scene_next") else incident.get("next")
	var step: Variant = step_for(Game.local_player, incident, own) if bool(settings()["PreArrival"]) else null
	if step == null:
		if incident.has("scene_next"):
			incident.erase("scene_next")
			if own == null:
				incident.erase("next")
			else:
				incident["next"] = own
		return
	incident["scene_next"] = own
	if incident.get("next") != step:
		incident["next"] = step




func step_for(player: Player, incident: Dictionary, own: Variant) -> Variant:
	if player == null or not is_instance_valid(player) or player.health <= 0.0:
		return null
	var at: Vector3 = incident["pos"]
	var there: = player.root_position().distance_to(at) <= float(Config.Fire.ArriveRange)
	var vehicle: Variant = player.get_attr("Vehicle")
	var riding: = vehicle is Vehicle and player.seat != null
	var fire: bool = incident.get("kind", "fire") == "fire"
	if not there:
		if riding:
			var street: = street_of(at)
			var driving: bool = (vehicle as Vehicle).driver() == player
			if street.is_empty():
				return Text.m("onboarding.next.driveCall" if driving else "onboarding.next.rideCall")
			return Text.f("onboarding.next.drive" if driving else "onboarding.next.ride", [street])
		if player.get_attr("Geared", false) != true:
			return Text.f("onboarding.next.gear", [Controls.key_name("interact")])
		return Text.f("onboarding.next.board", [Controls.key_name("item")])
	if riding:
		return Text.f("onboarding.next.parkHydrant" if fire else "onboarding.next.park", [Controls.key_name("veh_exit")])



	var flames_step: = own is Dictionary and String(own.get("k", "")).begins_with("calls.fire.next.flames")
	var has_line: bool = player.get_attr("Line") != null or player.holding == "nozzle"
	if fire and flames_step and not has_line and int(incident.get("flames", 0)) > 0:
		return Text.f("onboarding.next.hose", [Controls.key_name("coupling")])
	return null




func street_of(at: Vector3) -> String:
	var key: = Vector2i(roundi(at.x), roundi(at.z))
	if _streets.has(key):
		return _streets[key]
	var found: = ""
	var graph: = NavGraph.current
	if graph != null and graph.layout.has("roads"):
		var best: = float(settings()["StreetReach"])
		var point: = Vector2(at.x, at.z)
		for road: Dictionary in graph.layout["roads"]:
			var road_name: = String(road.get("name", ""))
			if road_name.is_empty():
				continue
			var points: Array = road.get("points", [])
			for index in range(points.size() - 1):
				var a: = Vector2(float(points[index][0]), float(points[index][1]))
				var b: = Vector2(float(points[index + 1][0]), float(points[index + 1][1]))
				var distance: = point.distance_to(Geometry2D.get_closest_point_to_segment(point, a, b))
				if distance < best:
					best = distance
					found = road_name
	_streets[key] = found
	return found
