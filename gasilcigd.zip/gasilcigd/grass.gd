class_name Grass
extends Node3D







const CELL: = 24.0
const REACH: = 130.0
const STEP: = 2.0
const TUFTS_PER_POINT: = 5
const MEADOW_FLOWERS: = 0.35
const SQUARES_PER_FRAME: = 2
const LIFT: = 1.4
const GRASS_UNDER: = ["Ground", "meadow", "orchard", "scrub", "park", "forest", "verge"]

static var current: Grass

var reach: = REACH
var tufts_per_point: = TUFTS_PER_POINT
var _squares: Dictionary = {}
var _tuft_mesh: ArrayMesh
var _flower_mesh: ArrayMesh
var _material: ShaderMaterial
var _flower_material: ShaderMaterial


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	_tuft_mesh = _make_tuft()
	_flower_mesh = _make_flower()
	var shader: Shader = load("res://shaders/grass.gdshader")
	_material = ShaderMaterial.new()
	_material.shader = shader
	_material.set_shader_parameter("color_map", load(Ground.COLOR_MAP))
	_material.set_shader_parameter("low", Ground.LOW)
	_material.set_shader_parameter("size", Ground.SIZE)
	_material.set_shader_parameter("noise", Ground.noise())

	_material.set_shader_parameter("sage", float(Config.Art.Lawn.Sage))
	_material.set_shader_parameter("night_grey", float(Config.Art.Lawn.NightGrey))
	_flower_material = _material.duplicate()
	_flower_material.set_shader_parameter("flowers", true)
	var growth: = Graphics.grass(Settings.quality)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--grass="):
			var bits: = arg.substr(8).split_floats(",")
			growth = [bits[0], int(bits[1])]
	set_growth(growth[0], growth[1])

	visible = not Style.winter()
	Style.current.changed.connect( func(_style: int) -> void : visible = not Style.winter())



func set_growth(new_reach: float, tufts: int) -> void :
	reach = new_reach
	tufts_per_point = tufts
	for key: Vector2i in _squares:
		_squares[key].queue_free()
	_squares.clear()
	if _material:
		_material.set_shader_parameter("reach", maxf(reach, 1.0))
		_flower_material.set_shader_parameter("reach", maxf(reach, 1.0))


func _process(_delta: float) -> void :
	if not visible:
		return
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var at: = camera.global_position

	var height: = at.y - (Ground.top if Ground.top > - INF else 0.0)
	var growing: = reach if height < 60.0 and tufts_per_point > 0 else 0.0
	var centre: = Vector2i(floori(at.x / CELL), floori(at.z / CELL))
	var span: = ceili(growing / CELL) + 1

	for key: Vector2i in _squares.keys():
		var middle: = Vector2((key.x + 0.5) * CELL, (key.y + 0.5) * CELL)
		if growing == 0.0 or middle.distance_to(Vector2(at.x, at.z)) > growing + CELL * 1.5:
			_squares[key].queue_free()
			_squares.erase(key)
	if growing == 0.0:
		return

	var wanted: Array = []
	for dx in range( - span, span + 1):
		for dz in range( - span, span + 1):
			var key: = centre + Vector2i(dx, dz)
			if _squares.has(key):
				continue
			var middle: = Vector2((key.x + 0.5) * CELL, (key.y + 0.5) * CELL)
			var distance: = middle.distance_to(Vector2(at.x, at.z))
			if distance < growing + CELL * 0.75:
				wanted.append([distance, key])
	wanted.sort_custom( func(a: Array, b: Array) -> bool: return a[0] < b[0])
	for index in mini(wanted.size(), SQUARES_PER_FRAME):
		var key: Vector2i = wanted[index][1]
		_squares[key] = _grow(key)


func _grow(key: Vector2i) -> Node3D:
	var holder: = Node3D.new()
	add_child(holder)
	var world: = Game.world
	var rng: = RandomNumberGenerator.new()
	rng.seed = hash(key)
	var tufts: Array[Transform3D] = []
	var flowers: Array[Transform3D] = []
	var flower_colors: Array[Color] = []
	var low: = Vector2(key.x * CELL, key.y * CELL)
	var steps: = int(CELL / STEP)


	var points: Array = []
	var grassy: Dictionary = {}
	for i in steps:
		for j in steps:
			var x: = low.x + (i + rng.randf()) * STEP
			var z: = low.y + (j + rng.randf()) * STEP
			var kind: = Ground.kind_at(x, z)
			var y: Variant = null
			if kind != 2:
				var hit: = world.raycast(Vector3(x, LIFT, z), Vector3(x, -1.0, z), World.LAYER_SOLID | World.LAYER_QUERY)
				if not hit.is_empty() and world.name_hit(hit) in GRASS_UNDER:
					y = hit["position"].y
					grassy[Vector2i(i, j)] = true
			points.append([x, z, kind, y])
	for index in points.size():
		var point: Array = points[index]
		if point[3] == null:
			continue
		var i: = index / steps
		var j: = index % steps
		var x: float = point[0]
		var z: float = point[1]
		var kind: int = point[2]
		var y: float = point[3]
		var edged: = false
		for near: Vector2i in [Vector2i(i - 1, j), Vector2i(i + 1, j), Vector2i(i, j - 1), Vector2i(i, j + 1)]:
			if near.x >= 0 and near.x < steps and near.y >= 0 and near.y < steps and not grassy.has(near):
				edged = true
		var spread: = 0.35 if edged else 1.0

		var tall: float = {1: 1.0, 4: 1.1, 0: 0.7}.get(kind, 0.5)
		for t in tufts_per_point:
			var spot: = Vector3(x + rng.randf_range( - spread, spread), y, z + rng.randf_range( - spread, spread))
			var scale: = rng.randf_range(0.7, 1.3) * tall
			var basis: = Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(scale, scale * rng.randf_range(0.8, 1.25), scale))
			tufts.append(Transform3D(basis, spot))
		if kind == 1 and rng.randf() < MEADOW_FLOWERS or kind == 4 and rng.randf() < 0.12 or kind == 0 and rng.randf() < 0.04:
			var spot: = Vector3(x + rng.randf_range( - spread, spread), y, z + rng.randf_range( - spread, spread))
			var scale: = rng.randf_range(0.8, 1.2)
			flowers.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * scale), spot))
			var pick: = rng.randf()
			flower_colors.append(Color(0.97, 0.96, 0.9) if pick < 0.4 else (Color(1.0, 0.82, 0.15) if pick < 0.7 else (Color(0.7, 0.45, 0.95) if pick < 0.88 else Color(0.95, 0.35, 0.3))))
	if not tufts.is_empty():
		holder.add_child(_instances(_tuft_mesh, _material, tufts, []))
	if not flowers.is_empty():
		holder.add_child(_instances(_flower_mesh, _flower_material, flowers, flower_colors))
	return holder


func _instances(mesh: Mesh, material: Material, places: Array[Transform3D], colors: Array[Color]) -> MultiMeshInstance3D:
	var multimesh: = MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.use_colors = not colors.is_empty()
	multimesh.mesh = mesh
	multimesh.instance_count = places.size()
	for index in places.size():
		multimesh.set_instance_transform(index, places[index])
		if not colors.is_empty():
			multimesh.set_instance_color(index, colors[index])
	var instance: = MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return instance




static func _make_tuft() -> ArrayMesh:
	var rng: = RandomNumberGenerator.new()
	rng.seed = 5
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var uvs: = PackedVector2Array()
	for blade in 7:
		var turn: = blade * TAU / 7.0 + rng.randf_range(-0.3, 0.3)
		var out: = Vector3(cos(turn), 0, sin(turn))
		var side: = Vector3( - out.z, 0, out.x)
		var root: = out * rng.randf_range(0.0, 0.25)
		var height: = rng.randf_range(0.7, 1.15)
		var lean: = rng.randf_range(0.15, 0.45)
		var width: = rng.randf_range(0.09, 0.14)
		var tip: = root + out * lean + Vector3(0, height, 0)
		var a: = root - side * width
		var b: = root + side * width
		var normal: = (b - a).cross(tip - a).normalized()
		if normal.y < 0.0:
			normal = - normal

		vertices.append_array([a, tip, b, b, tip, a])
		normals.append_array([normal, normal, normal, - normal, - normal, - normal])
		uvs.append_array([Vector2(0, 0), Vector2(0.5, 1), Vector2(1, 0), Vector2(1, 0), Vector2(0.5, 1), Vector2(0, 0)])
	return _mesh(vertices, normals, uvs)



static func _make_flower() -> ArrayMesh:
	var vertices: = PackedVector3Array()
	var normals: = PackedVector3Array()
	var uvs: = PackedVector2Array()
	var h: = 0.95
	var w: = 0.03
	for side: Vector3 in [Vector3.RIGHT, Vector3.BACK]:
		var n: = side.cross(Vector3.UP)
		vertices.append_array([ - side * w, Vector3(0, h, 0), side * w, side * w, Vector3(0, h, 0), - side * w])
		normals.append_array([n, n, n, - n, - n, - n])
		uvs.append_array([Vector2(0, 0), Vector2(0.5, 0.9), Vector2(1, 0), Vector2(1, 0), Vector2(0.5, 0.9), Vector2(0, 0)])

	var top: = Vector3(0, h, 0)
	var r: = 0.18
	for petal in 4:
		var turn: = petal * TAU / 4.0
		var a: = top + Vector3(cos(turn), 0.02, sin(turn)) * r
		var b: = top + Vector3(cos(turn + TAU / 4.0), 0.02, sin(turn + TAU / 4.0)) * r
		vertices.append_array([top, a, b, top, b, a])
		normals.append_array([Vector3.UP, Vector3.UP, Vector3.UP, Vector3.DOWN, Vector3.DOWN, Vector3.DOWN])
		uvs.append_array([Vector2(3, 1), Vector2(3, 1), Vector2(3, 1), Vector2(3, 1), Vector2(3, 1), Vector2(3, 1)])
	return _mesh(vertices, normals, uvs)


static func _mesh(vertices: PackedVector3Array, normals: PackedVector3Array, uvs: PackedVector2Array) -> ArrayMesh:
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh
