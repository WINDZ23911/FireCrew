class_name TrafficLights
extends Node3D









const LAMP_COLORS: = {
	"red": [Color(70 / 255.0, 18 / 255.0, 16 / 255.0), Color(1.0, 50 / 255.0, 40 / 255.0)], 
	"amber": [Color(70 / 255.0, 52 / 255.0, 14 / 255.0), Color(1.0, 190 / 255.0, 40 / 255.0)], 
	"green": [Color(16 / 255.0, 60 / 255.0, 26 / 255.0), Color(60 / 255.0, 235 / 255.0, 110 / 255.0)], 
}
const GLOW: = 3.0

static var current: TrafficLights
static var _showing: Dictionary = {}


var heads: Array[Dictionary] = []
var _lamp_nodes: Array = []
var _middle: = Vector3.ZERO
var _current: = 1
var _since: = 0.0
var _switching: = false
var _tick: = 0.0



static func phase(number: int) -> String:
	return _showing.get(number, "green")


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
		_showing.clear()


func _ready() -> void :
	var store: = Game.store
	var folder: = 0
	for id: int in store.nodes:
		if store.nodes[id]["c"] == "Folder" and store.nodes[id]["n"] == "TrafficLights":
			folder = id
	var rows: PackedInt32Array = store.rows_under.get(folder, PackedInt32Array())
	var layout: Dictionary = Rbx.module("TownLayout")
	for signal_at: Dictionary in layout.get("signals", []):
		var position: = Vector3(signal_at["x"], 0.0, signal_at["z"])
		var head: = {"phase": int(signal_at["phase"]), "lamps": {}, "position": position, "away": Vector3.FORWARD}
		for row in rows:
			var part_name: = store.name_at(row)
			var offset: = store.position(row) - position
			offset.y = 0.0
			if not LAMP_COLORS.has(part_name) or offset.length() > 2.0:
				continue

			if offset.length() > 0.01:
				head["away"] = offset.normalized()
			head["lamps"][part_name] = _lamp(row)
		if not head["lamps"].is_empty():
			heads.append(head)
	if heads.is_empty():
		set_process(false)
		return
	for head in heads:
		_middle += head["position"] / heads.size()
	_show(1, "green")
	_show(2, "red")
	_since = Game.now()

	Net.share("town.signals", func() -> Variant: return [phase(1), phase(2)], _net_apply, 5.0)




func _net_apply(colours: Variant) -> void :
	if not Net.is_client() or heads.is_empty():
		return
	for number in [1, 2]:
		var colour: String = colours[number - 1]
		if phase(number) != colour:
			_show(number, colour)
		if colour == "green":
			_current = number
	_since = Game.now()



func _lamp(row: int) -> StandardMaterial3D:
	var store: = Game.store
	Game.world.set_hidden(store.id_at(row), true)
	var material: = StandardMaterial3D.new()
	material.roughness = 0.4
	material.emission_enabled = true
	var lamp: = MeshInstance3D.new()
	lamp.mesh = World.unit_mesh(PartStore.Shape.CYLINDER)
	lamp.material_override = material
	lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(lamp)
	var size: = store.size(row)
	lamp.global_transform = store.transform(row) * Transform3D(Basis.from_scale(Vector3(size.x, minf(size.y, size.z), minf(size.y, size.z))), Vector3.ZERO)
	_lamp_nodes.append([lamp, store.position(row)])
	return material



func lamps_near(at: Vector3, reach: float) -> Array:
	var found: Array = []
	for entry: Array in _lamp_nodes:
		var where: Vector3 = entry[1]
		if Vector2(where.x - at.x, where.z - at.z).length() <= reach and is_instance_valid(entry[0]):
			found.append(entry[0])
	return found


func _show(number: int, colour: String) -> void :
	_showing[number] = colour
	for head in heads:
		if head["phase"] == number:
			for lamp_name: String in head["lamps"]:
				var lit: = lamp_name == colour
				var material: StandardMaterial3D = head["lamps"][lamp_name]
				var shade: Color = LAMP_COLORS[lamp_name][1 if lit else 0]
				material.albedo_color = shade if not lit else shade * 0.4
				material.emission = shade
				material.emission_energy_multiplier = GLOW if lit else 0.0




func _siren_phase() -> int:


	var siren: = Emergency.nearest(Emergency.sirens(), _middle.x, _middle.z)
	if siren.is_empty():
		return 0
	var level: = Vector3(siren["x"] - _middle.x, 0.0, siren["z"] - _middle.z)

	if level.length() > float(Config.Town.SirenRange) or level.length() < 20.0:
		return 0
	var nearest: = 0
	var best: = - INF
	for head in heads:
		var facing: float = level.normalized().dot(head["away"])
		if facing > best:
			nearest = head["phase"]
			best = facing
	return nearest


func _switch_to(number: int) -> void :
	_switching = true
	_show(_current, "amber")
	await get_tree().create_timer(float(Config.Town.AmberTime), false).timeout
	if Net.is_client():
		_switching = false
		return
	_show(_current, "red")
	await get_tree().create_timer(float(Config.Town.AllRedTime), false).timeout
	if Net.is_client():
		_switching = false
		return
	_current = number
	_show(_current, "green")
	_since = Game.now()
	_switching = false


func _process(delta: float) -> void :
	if Net.is_client():
		return
	_tick += delta
	if _tick < 0.25 or _switching:
		return
	_tick = 0.0
	var wanted: = _siren_phase()
	if wanted != 0:
		if wanted != _current:
			_switch_to(wanted)

		_since = Game.now()
	elif Game.now() - _since >= float(Config.Town.GreenTime):
		_switch_to(3 - _current)
