extends ProofDebug
















func _burning(prefix: = "Family house") -> House:
	var fire: = FireService.current
	var house: = _house(prefix)
	VictimService.current.forced = 0
	Config.Fire["Embers"]["Chance"] = 0.0
	Config.Fire["Traits"]["Force"] = "none"
	fire.run_incident(house)
	await _wait(0.5)
	player.teleport(CallKit.ground_at(house.position + Vector3(30, 5, 30)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	return house



func _nodes() -> Array:
	return FireService.current.incident["group"]["nodes"]



func _quiet_all() -> void :
	var fire: = FireService.current
	for node: Dictionary in _nodes():
		if node["burning"]:
			fire._douse(node)
		node["heat"] = 0.0
		node["wet_until"] = 0.0
	fire.incident["cap_extra"] = 0.0



func _room_with(house: House, least: int) -> String:
	var best: = ""
	var most: = 0
	for room_name: String in house.rooms:
		if house.rooms[room_name].get("open", false):
			continue
		var count: = 0
		for node: Dictionary in _nodes():
			if node["room"] == room_name and node["fuel"] > 0.0:
				count += 1
		if count >= least and count > most:
			most = count
			best = room_name
	return best


func _scenario_heatwater() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	await _burning()
	var burning: Dictionary = {}
	for node: Dictionary in _nodes():
		if node["burning"]:
			burning = node
			break
	if not _check( not burning.is_empty(), "the house is burning"):
		await _done()
		return
	burning["intensity"] = 1.0
	burning["damage"] = 0.0
	var dry: = fire._heat_of(burning)
	burning["damage"] = fire._max_health(burning) * 0.8
	burning["last_sprayed"] = Game.now()
	var wet: = fire._heat_of(burning)
	print("heatwater: a full flame gives off %.2f; knocked down to 80 %% it gives off %.2f" % [dry, wet])
	_check(is_equal_approx(dry, 1.0), "a full flame, dry, gives off its whole heat")
	_check(wet <= 0.2 + 0.01, "a flame knocked 80 % down gives off a fifth of it (KnockdownHeat 1)")

	var other: Dictionary = {}
	for link: Dictionary in burning["links"]:
		if not link["node"]["burning"] and link["node"]["fuel"] > 0.0:
			other = link["node"]
			break
	if _check( not other.is_empty(), "the flame has something unlit beside it"):
		var gained: = []
		for knocked: float in [0.0, 0.8]:
			_quiet_all()
			fire._ignite(burning, 1.0)
			burning["damage"] = fire._max_health(burning) * knocked
			burning["last_sprayed"] = Game.now()
			other["heat"] = 0.0
			fire._burn(0.25)
			gained.append(float(other["heat"]))
		print("heatwater: one step warms its neighbour by %.4f dry, %.4f knocked down" % [gained[0], gained[1]])
		_check(gained[1] < gained[0] * 0.5, "a neighbour of a knocked-down flame warms much slower")

	var reach_dry: float = float(fire.settings()["BurnRadius"]) * (0.5 + 0.5 * dry)
	var reach_wet: float = float(fire.settings()["BurnRadius"]) * (0.5 + 0.5 * fire._heat_of(burning))
	print("heatwater: it burns from %.1f studs dry, %.1f knocked down" % [reach_dry, reach_wet])
	_check(reach_wet < reach_dry, "a knocked-down flame burns from less far off")
	await _done()


func _scenario_flashcool() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var room_name: = _room_with(house, 5)
	if not _check( not room_name.is_empty(), "the house has a shut room with five things to burn"):
		await _done()
		return
	var room: Dictionary = house.rooms[room_name]
	var state: Dictionary = fire.incident["rooms"][room_name]
	var s: Dictionary = fire.settings()
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var middle: Vector3 = (low + high) / 2.0
	var ceiling: Vector3 = house.lot * Vector3(middle.x, high.y - 0.05, middle.z)
	var floor_spot: Vector3 = house.lot * Vector3(middle.x, low.y + 1.0, middle.z)


	var pulse: = func(on: float, off: float, times: int) -> float:
		state["cooled"] = 0.0
		state["fog_last"] = -100.0
		var taken: = 0.0
		for each in times:
			var held: = 0.0
			while held < on:
				await get_tree().physics_frame
				var dt: = get_physics_process_delta_time()
				held += dt
				taken += fire.cool_gas(ceiling, dt)
			await _wait(off)
		return taken
	var pulsed: float = await pulse.call(0.8, 0.6, 2)
	var held_on: float = await pulse.call(1.6, 0.0, 1)
	state["cooled"] = 0.0
	var under: = fire.cool_gas(floor_spot, 1.0)
	print("flashcool: %s: two 0.8 s pulses take %.2f off the room's heat, 1.6 s held on %.2f, fog under the smoke %.2f" % [room_name, pulsed, held_on, under])
	_check(pulsed > 2.0, "short fog pulses into the ceiling take heat out of the room")
	_check(held_on < pulsed * 0.8, "fog held on does less than the same fog in pulses")
	_check(under == 0.0, "fog under the smoke layer takes no heat out of the gas")



	_quiet_all()
	state["cooled"] = 0.0
	var lit: = 0
	for node: Dictionary in _nodes():
		if node["room"] == room_name and node["fuel"] > 0.0 and lit < 5:
			fire._ignite(node, 1.0)
			lit += 1
		elif not node["burning"]:
			node["wet_until"] = Game.now() + 600.0
	var waited: = 0.0
	while state.get("flash_at") == null and waited < float(s["FlashoverTime"]) + 4.0:
		await _wait(0.25)
		waited += 0.25
	_view(house.lot * Vector3(low.x + 0.8, low.y + (high.y - low.y) * 0.45, low.z + 0.8), house.lot * Vector3(high.x, high.y - 1.0, high.z), 75.0)
	await _snap("rollover")
	if not _check(state.get("flash_at") != null, "the room gives its flashover warning (%.1f s)" % waited):
		await _done()
		return
	_check(room.get("rolling", false), "flames roll across the ceiling")

	var cooled_down: = false
	var pulses: = 0
	while pulses < 4 and state.get("flash_at") != null:
		pulses += 1
		var held: = 0.0
		while held < 0.8:
			await get_tree().physics_frame
			held += get_physics_process_delta_time()
			fire.fog(ceiling, get_physics_process_delta_time())
		await _wait(0.4)
	cooled_down = state.get("flash_at") == null
	print("flashcool: after %d pulses: warning %s, flashed %s, cooled %.2f" % [pulses, "gone" if cooled_down else "still on", state.get("flashed", false), float(state.get("cooled", 0.0))])
	_check(cooled_down and not state.get("flashed", false), "fog pulses into the ceiling stop the flashover")
	_check( not room.get("rolling", false), "the rollover is no longer shown")
	await _snap("cooled")


	state["cooled"] = 0.0
	waited = 0.0
	while state.get("flash_at") == null and waited < float(s["FlashoverTime"]) + 4.0:
		for node: Dictionary in _nodes():
			if node["room"] == room_name and node["burning"]:
				node["intensity"] = 1.0
		await _wait(0.25)
		waited += 0.25
	if _check(state.get("flash_at") != null, "the room warns again"):
		for node: Dictionary in _nodes():
			if node["room"] == room_name and node["burning"]:
				node["damage"] = fire._max_health(node) * 0.6
				node["last_sprayed"] = Game.now() + 100.0
		await _wait(0.6)
		print("flashcool: flames knocked 60 %% down: warning %s" % ("gone" if state.get("flash_at") == null else "still on"))
		_check(state.get("flash_at") == null and not state.get("flashed", false), "water on the room's flames stops the flashover")
	await _done()


func _scenario_flamecap() -> void :
	await _wait(1.0)
	var fire: = FireService.current
	var house: = await _burning()
	var s: Dictionary = fire.settings()
	var cap: = fire._base_cap()
	print("flamecap: %s, %d nodes, flame cap %d" % [house.name, _nodes().size(), cap])

	await _wait(6.0)
	var hottest: = 0.0
	for node: Dictionary in _nodes():
		hottest = maxf(hottest, float(node["heat"]))
	print("flamecap: after 6 s the hottest unlit thing is at %.2f" % hottest)
	_check(hottest <= float(s["HeatClamp"]) + 0.001, "stored heat stops at Fire.HeatClamp")


	_quiet_all()
	var source: Dictionary = {}
	var pair: Array = []
	for node: Dictionary in _nodes():
		var free: Array = []
		for link: Dictionary in node["links"]:
			if link["node"]["fuel"] > 0.0 and link["nearness"] > 0.3:
				free.append(link["node"])
		if free.size() >= 2:
			source = node
			pair = [free[0], free[1]]
			break
	if _check( not source.is_empty(), "a flame with two things beside it"):
		fire._ignite(source, 1.0)
		var filler: = 0
		for node: Dictionary in _nodes():
			if fire.incident["count"] >= cap - 1:
				break
			if node["burning"] or is_same(node, pair[0]) or is_same(node, pair[1]) or node["fuel"] <= 0.0:
				continue
			if source["links"].any( func(l: Dictionary) -> bool: return is_same(l["node"], node)):
				continue
			fire._ignite(node, 0.2)
			filler += 1
		for node: Dictionary in _nodes():
			if not node["burning"]:
				node["heat"] = 0.0
		pair[0]["heat"] = 1.0
		pair[1]["heat"] = 1.09
		fire.incident["cap_extra"] = 0.0
		await _wait(0.6)
		print("flamecap: %d of %d burning; the first in the list (heat 1.0) lit %s, the hotter (1.09) lit %s" % [fire.incident["count"], cap, pair[0]["burning"], pair[1]["burning"]])
		_check(pair[1]["burning"] and not pair[0]["burning"], "with one place under the cap, the hotter catches, not the first in the list")


	_quiet_all()
	for node: Dictionary in _nodes():
		if fire.incident["count"] >= cap:
			break
		if node["fuel"] > 0.0:
			fire._ignite(node, 0.5)
	var unlit: Array = []
	for node: Dictionary in _nodes():
		if not node["burning"] and node["fuel"] > 0.0:
			unlit.append(node)
	var before: int = fire.incident["count"]
	fire._light_event(unlit, float(s["FlashoverIntensity"]))
	var after: int = fire.incident["count"]
	print("flamecap: %d burning at the cap; an event over %d more leaves %d burning (cap raised by %.1f)" % [before, unlit.size(), after, float(fire.incident.get("cap_extra", 0.0))])
	_check(after <= cap + int(s["EventOver"]), "a big event lights no more than EventOver past the cap")
	_check(after > before or unlit.is_empty(), "a big event still lights something")
	_check(float(fire.incident.get("cap_extra", 0.0)) >= float(after - cap) - 0.01, "the cap is raised to what burns")
	var left_hot: = unlit.filter( func(node: Dictionary) -> bool: return not node["burning"])
	_check(left_hot.all( func(node: Dictionary) -> bool: return float(node["heat"]) >= 1.0), "what the event could not light is left ready to catch")
	var raised: = float(fire.incident["cap_extra"])
	await _wait(3.0)
	print("flamecap: 3 s later the raise is %.2f (from %.2f)" % [float(fire.incident.get("cap_extra", 0.0)), raised])
	_check(float(fire.incident.get("cap_extra", 0.0)) < raised, "the raised cap falls back")


	_quiet_all()
	for node: Dictionary in _nodes():
		if fire.incident["count"] >= cap:
			break
		if node["fuel"] > 0.0:
			fire._ignite(node, 0.5)
	var bang: Dictionary = {}
	for node: Dictionary in _nodes():
		if node["burning"]:
			bang = node
	player.teleport(CallKit.ground_at(house.position + Vector3(90, 5, 90)) + Vector3(0, 0.3, 0))
	Config.Fire["Bottles"]["Ignite"] = 1000.0
	fire._burst(fire.incident["group"], bang)
	print("flamecap: bottles going off at the cap leave %d burning" % fire.incident["count"])
	_check(int(fire.incident["count"]) <= cap + int(s["EventOver"]), "bottles going off light no more than EventOver past the cap")
	await _done()


func _scenario_airkeep() -> void :
	await _wait(1.0)
	var air: = AirService.current
	var capacity: = float(Config.Air.Capacity)
	var pumper: = Vehicle.named("Fire Truck")
	GearService.current._gear_up(player, null, true)
	player.teleport(_ground(pumper.global_transform * Vector3(9, 0, 4)) + Vector3(0, 0.3, 0))
	await _wait(0.3)
	air.take_set(player, "truck")
	if not _check(air.wearing(player), "a set from the truck"):
		await _done()
		return
	_check(is_equal_approx(air.pressure(player), capacity), "the truck's sets come full")
	air.sets[player]["bar"] = 120.0
	air._return_set(player)
	print("airkeep: handed back at 120 bar; the truck's sets now %s" % str(air.bars["truck"]))
	_check(120.0 in air.bars["truck"], "a set handed back keeps its pressure")

	var low_slot: = (air.bars["truck"] as Array).find(120.0)
	air.take_set(player, "truck", low_slot)
	print("airkeep: taken again: %.0f bar" % air.pressure(player))
	_check(is_equal_approx(air.pressure(player), 120.0), "a set handed back low comes back low")
	air._return_set(player)
	air.take_set(player, "truck")
	_check(is_equal_approx(air.pressure(player), capacity), "taken as anyone would, the fullest comes first")


	air._set_mask(player, true)
	await _wait(0.3)
	var spares: = air.spares
	var swap_time: = float(Config.Air.SwapTime)
	air._on_spare(player)
	await _wait(swap_time * 0.5)
	var half_bar: = air.pressure(player)
	var off_air: = not air.on_air(player)
	print("airkeep: half way through the swap: %.0f bar, on air %s, spares %d -> %d" % [half_bar, not off_air, spares, air.spares])
	_check(half_bar < capacity and off_air, "half way through the swap the cylinder is not in yet, and the wearer is off air")
	await _snap("swapping")
	await _wait(swap_time * 0.5 + 0.4)
	print("airkeep: after %.1f s: %.0f bar, on air %s" % [swap_time, air.pressure(player), air.on_air(player)])
	_check(air.pressure(player) > capacity - 3.0 and air.on_air(player), "after SwapTime the spare is in and the wearer back on air")
	_check(air.spares == spares - 1, "it took one spare")

	air.sets[player]["bar"] = 150.0
	air._on_spare(player)
	await _wait(0.5)
	player.teleport(_ground(player.global_position + Vector3(30, 0, 0)) + Vector3(0, 0.3, 0))
	await _wait(swap_time)
	print("airkeep: walked off mid-swap: %.0f bar, spares %d" % [air.pressure(player), air.spares])
	_check(absf(air.pressure(player) - 150.0) < 3.0 and air.spares == spares - 1, "a swap walked away from leaves the spare in the locker")


	air.sets[player]["bar"] = capacity
	air._set_mask(player, false)
	air._set_mask(player, true)
	air.sets[player]["bar"] = 250.0
	air._publish(player)
	var mark: = AirService.turnaround(player)
	print("airkeep: entered at 300, now 250: the mark at %.0f" % mark)
	_check(is_equal_approx(mark, 200.0), "the turnaround mark is the entry pressure less twice what is used")
	var hud: GearHud = Hud.current.widgets.get("gear")
	await _wait(0.2)
	_check(hud != null and hud._turn_mark.visible, "the gauge shows the turnaround mark")
	await _snap("gauge")
	var told: = [false]
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void :
		if Text.say(text, "en").begins_with("Turn around"):
			told[0] = true)
	air.sets[player]["bar"] = 199.0
	air._publish(player)
	await _wait(0.4)
	print("airkeep: at 199 bar: mark %.0f, turned %s, told %s" % [AirService.turnaround(player), player.get_attr("AirTurned"), told[0]])
	_check(player.get_attr("AirTurned") == true and told[0], "at the turnaround the wearer is told to turn round")
	await _snap("turnaround")
	print("airkeep: air minutes by the reticle would read %.1f" % AirService.minutes_left(player))
	_check(AirService.minutes_left(player) > 0.0, "the minutes of air left can be read for the HUD")


	air.bars["rack"][0] = 40.0
	air._set_mask(player, false)
	air.sets[player]["bar"] = capacity
	air._on_compressor(player)
	await _wait(float(Config.Air.CradleFillTime) + 1.0)
	print("airkeep: the rack's first set after the compressor: %.0f bar" % float(air.bars["rack"][0]))
	_check(is_equal_approx(float(air.bars["rack"][0]), capacity), "the station's compressor fills the sets on the rack")
	await _done()



func _crew_of(roles: Array) -> Array[Crewman]:
	var service: = CrewService.current
	var made: Array[Crewman] = []
	for role: String in roles:
		var entry: = service.roster._member("", role, 2, 0)
		made.append(service._make(entry, service.members.size(), player))
	return made


func _jobs(service: CrewService) -> String:
	return ", ".join(service.members.map( func(m: Crewman) -> String: return "%s:%s" % [m.display_name(), m.job.kind if m.job != null else "-"]))


func _anyone_on(service: CrewService, kind: String) -> bool:
	for mind in service.members:
		if mind.job != null and not mind.job.cancelled and mind.job.kind == kind:
			return true
	return false



func _stand_all_down(service: CrewService) -> void :
	for mind in service.members:
		mind.stand_down()
	var waited: = 0.0
	while waited < 8.0 and service.members.any( func(m: Crewman) -> bool: return m.job != null):
		await _wait(0.25)
		waited += 0.25


func _scenario_autonomy() -> void :
	await _wait(1.0)
	var service: = CrewService.current
	if not _check(service != null, "the crew service is there"):
		await _done()
		return
	_check(service.autonomy == CrewService.STANDARD, "the crew starts on Standard")
	Config.Crew["LeadWait"] = 4.0
	var house: = _house("Family house")
	var crew: = _crew_of(["pump", "nozzle", "rescue"])
	var pumper: = Vehicle.named("Fire Truck")
	_park(pumper, _open_spot(house.position, Vector3(1, 0, 1), pumper))
	service.last_vehicle = pumper
	await _wait(0.5)
	await _burning()
	var at: = house.position
	player.teleport(CallKit.ground_at(at + Vector3(28, 5, 28)) + Vector3(0, 0.3, 0))
	for index in crew.size():
		crew[index].body.teleport(CallKit.ground_at(at + Vector3(32 + index * 3, 5, 26)) + Vector3(0, 0.3, 0))
	service.auto = true
	service.all_work()

	var waited: = 0.0
	while service.ask.is_empty() and waited < 25.0:
		await _wait(0.5)
		waited += 0.5
	print("autonomy: Standard after %.1f s: jobs %s; ask %s" % [waited, _jobs(service), service.ask.get("kind", "none")])
	_check( not service.ask.is_empty() and service.ask["kind"] == "attack", "on Standard a member asks to take the line")
	_check( not _anyone_on(service, "attack"), "on Standard nobody takes the commander's line by themselves")
	await _snap("ask")

	var asker: Crewman = service.ask.get("mind")
	var target: = CrewTargets.look(player)
	_check(target.get("kind", "") == "ask", "a tap of G now answers the ask")
	await _tap("crew_order")
	await _wait(1.0)
	print("autonomy: after G: jobs %s" % _jobs(service))
	_check(asker != null and asker.job != null and asker.job.kind == "attack", "G gives the asking member the line")
	_check(service.ask.is_empty(), "the ask is answered")


	service.set_autonomy(CrewService.HANDS_ON)
	await _stand_all_down(service)
	service.done_here.erase("granted_attack")
	service.set_autonomy(CrewService.FULL)
	waited = 0.0
	while not _anyone_on(service, "attack") and waited < 20.0:
		await _wait(0.5)
		waited += 0.5
	print("autonomy: Full after %.1f s: jobs %s" % [waited, _jobs(service)])
	_check(_anyone_on(service, "attack"), "on Full the crew takes the line up by itself")


	service.set_autonomy(CrewService.HANDS_ON)
	await _stand_all_down(service)
	var taken: Dictionary = {}
	waited = 0.0
	while waited < 12.0:
		await _wait(0.5)
		waited += 0.5
		for mind in service.members:
			if mind.job != null and not mind.job.cancelled:
				taken[mind.job.kind] = true
	print("autonomy: Hands-on for 12 s: kinds taken %s; notes %s" % [taken.keys(), service.members.map( func(m: Crewman) -> String: return Text.say(m.auto_note, "en") if m.auto_note != null else "-")])
	_check( not taken.has("attack") and not taken.has("supply"), "on Hands-on nothing is started that the commander has not")
	_check(taken.keys().all( func(kind: String) -> bool: return kind in (Config.Crew.Autonomy.HandsOn as Array)), "on Hands-on only backing-up work is taken")


	var was: = service.autonomy
	await _tap("crew_autonomy")
	print("autonomy: Y: %d -> %d" % [was, service.autonomy])
	_check(service.autonomy == (was + 1) % 3, "Y steps the crew's level on")
	service.set_autonomy(CrewService.FULL, crew[1])
	_check(service.level_of(crew[1]) == CrewService.FULL and service.level_of(crew[0]) == service.autonomy, "a member has a level of their own")
	var options: Array = CrewTargets.general(player)
	_check(options.any( func(option: Dictionary) -> bool: return Text.say(option["text"], "en").begins_with("Autonomy")), "the crew wheel's general ring sets the level")
	await _snap("panel")
	await _done()
