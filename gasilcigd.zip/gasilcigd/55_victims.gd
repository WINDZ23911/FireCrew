extends RefCounted




static func start(main: Node) -> void :
	var ambulance: = AmbulanceService.new()
	ambulance.name = "AmbulanceService"

	ambulance.graph = NavGraph.current if NavGraph.current else NavGraph.build(Rbx.module("TownLayout"))
	main.add_child(ambulance)

	var victims: = VictimService.new()
	victims.name = "VictimService"
	main.add_child(victims)
	Victims.service = victims

	var debug: = VictimsDebug.new()
	debug.name = "VictimsDebug"
	main.add_child(debug)
