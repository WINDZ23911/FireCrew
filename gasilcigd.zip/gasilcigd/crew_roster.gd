class_name CrewRoster
extends RefCounted










const PATH: = "user://crew.json"

const RENAMED: = {"Marko": "Vid", "Jure": "Žak", "Tina": "Klemen"}
const ROLES: Array[String] = ["pump", "nozzle", "rescue", "safety"]

var members: Array = []
var candidates: Array = []
var auto: = true
var autonomy: = -1
var _saving: = false
var _path: = PATH



func _init(at: = "") -> void :
	_saving = not OS.get_cmdline_user_args().has("--no-save") or not at.is_empty()
	if not at.is_empty():
		_path = at
	var saved: Variant = null
	if _saving:
		saved = PlayerData.read_file(_path)
	if saved is String:

		push_warning("CrewRoster: %s cannot be read: %s; the crew starts afresh and is not saved" % [_path, saved])
		_saving = false
	if saved is Dictionary and saved.get("auto") is bool:
		auto = saved["auto"]
	if saved is Dictionary and saved.has("autonomy"):
		autonomy = int(saved["autonomy"])
	if saved is Dictionary and saved.get("members") is Array and not saved["members"].is_empty():
		for entry: Variant in saved["members"]:
			if entry is Dictionary:

				var name: String = RENAMED.get(entry.get("name", ""), entry.get("name", ""))
				members.append(_member(name, entry.get("role", "nozzle"), int(entry.get("level", 0)), int(entry.get("xp", 0))))
				members[members.size() - 1]["autonomy"] = int(entry.get("autonomy", -1))
				members[members.size() - 1]["trait"] = str(entry.get("trait", ""))
	if members.is_empty():
		var roles: Array = Config.Crew.StartRoles
		for index in roles.size():
			members.append(_member("", roles[index], 0, 0))

	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--crew-size="):
			var wanted: = clampi(int(arg.substr(12)), 0, int(Config.Crew.Most))
			while members.size() > wanted:
				members.pop_back()
			while members.size() < wanted:
				members.append(_member("", _next_role(), 0, 0))


func _member(given: String, role: String, level: int, xp: int) -> Dictionary:
	var names: Array = Config.Crew.Names
	var colours: Array = Config.Crew.Colours
	var taken: Array = members.map( func(entry: Dictionary) -> String: return entry["name"])
	var chosen: = given
	if chosen.is_empty():
		for candidate: String in names:
			if not candidate in taken:
				chosen = candidate
				break
	return {
		"name": chosen, "role": role if role in ROLES else "nozzle", "level": clampi(level, 0, levels() - 1), "xp": xp, 
		"colour": colours[members.size() % colours.size()], "trait": "", 
	}





static func role_colour(_role: String) -> Color:
	return Ui.YELLOW




static func role_pattern(role: String) -> String:
	var patterns: Dictionary = Config.Crew.RolePatterns
	return patterns.get(role, "band")



static func position_name(role: String) -> Variant:
	return Text.m("crew.positions." + role)



func next_position(entry: Dictionary) -> String:
	var at: = ROLES.find(str(entry["role"]))
	entry["role"] = ROLES[(at + 1) % ROLES.size()]
	save()
	return entry["role"]







func draw_candidates() -> Array:
	var price: = hire_price()
	if price < 0:
		candidates = []
		return candidates
	if not candidates.is_empty():
		return candidates
	var hire_rules: Dictionary = Config.Crew.Hire
	var traits: Array = (Config.Crew.Traits as Dictionary).keys()
	var taken: Array = members.map( func(entry: Dictionary) -> String: return entry["name"])
	var names: Array = (Config.Crew.Names as Array).filter( func(n: String) -> bool: return not n in taken)
	var draw: = members.size()
	for index in int(hire_rules["Candidates"]):
		var roll: int = rand_from_seed(hash([draw, index, "crew-hire"]))[0]
		var name: String = names[index % names.size()] if not names.is_empty() else "%s %d" % [str(Config.Crew.Names[0]), members.size() + index + 1]
		var role: String = _next_role() if index == 0 else ROLES[roll % ROLES.size()]
		var quirk: String = traits[(roll / 7) % traits.size()]
		var cost: = int(roundf(price * (1.0 + float(hire_rules["PriceSpread"]) * (float(index) - 1.0))))
		candidates.append({"name": name, "role": role, "trait": quirk, "price": cost})
	return candidates




static func trait_value(entry: Dictionary, what: String) -> float:
	var traits: Dictionary = Config.Crew.Traits
	var quirk: Dictionary = traits.get(str(entry.get("trait", "")), {})
	return float(quirk.get(what, 0.0 if what == "Skill" else 1.0))


func levels() -> int:
	return (Config.Crew.Skill as Array).size()



func _next_role() -> String:
	var order: Array = Config.Crew.HireRoles
	return order[clampi(members.size() - (Config.Crew.StartRoles as Array).size(), 0, order.size() - 1)]



func hire_price() -> int:
	var prices: Array = Config.Crew.HirePrice
	var index: = members.size() - (Config.Crew.StartRoles as Array).size()
	if members.size() >= int(Config.Crew.Most) or index < 0 or index >= prices.size():
		return -1
	return int(prices[index])



func train_price(entry: Dictionary) -> int:
	var prices: Array = Config.Crew.TrainPrice
	var level: int = entry["level"]
	return int(prices[level]) if level < prices.size() and level < levels() - 1 else -1


func hire(candidate: Dictionary = {}) -> Dictionary:
	var entry: = _member(str(candidate.get("name", "")), str(candidate.get("role", _next_role())), 0, 0)
	entry["trait"] = str(candidate.get("trait", ""))
	members.append(entry)
	candidates = []
	save()
	return entry


func train(entry: Dictionary) -> void :
	entry["level"] = mini(int(entry["level"]) + 1, levels() - 1)
	save()



func learn(entry: Dictionary) -> bool:
	entry["xp"] = int(entry["xp"]) + 1
	var needed: Array = Config.Crew.LearnAt
	var level: int = entry["level"]
	if level < needed.size() and level < levels() - 1 and int(entry["xp"]) >= int(needed[level]):
		entry["level"] = level + 1
		save()
		return true
	save()
	return false




static func skill(entry: Dictionary) -> float:
	var table: Array = Config.Crew.Skill
	return (float(table[clampi(int(entry.get("level", 0)), 0, table.size() - 1)]) + trait_value(entry, "Skill")) * float(Config.Crew.get("WorkPace", 1.0))


func save() -> void :
	if not _saving:
		return
	var kept: Array = []
	for entry: Dictionary in members:
		kept.append({"name": entry["name"], "role": entry["role"], "level": entry["level"], "xp": entry["xp"], "autonomy": int(entry.get("autonomy", -1)), "trait": str(entry.get("trait", ""))})
	PlayerData.write_file(_path, {"version": PlayerData.VERSION, "members": kept, "auto": auto, "autonomy": autonomy})
