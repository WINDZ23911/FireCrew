class_name Shift
extends RefCounted








const NAMES: Array[String] = ["quiet", "normal", "busy"]
const PATH: = "user://shift.cfg"

static var chosen: = ""
static var _loaded: = false


static func current() -> String:
	if not _loaded:
		_load()
	return chosen


static func settings() -> Dictionary:
	var shifts: Dictionary = Config.Duty.Shifts
	return shifts.get(current(), shifts["normal"])



static func weights() -> Array:
	return settings().get("Weights", [])



static func gap() -> Array:
	return settings().get("Gap", Config.Fire.IncidentGap)



static func pay() -> float:
	return float(settings().get("Pay", 1.0))



static func words(shift: = "") -> Dictionary:
	return Text.m("hud.duty.shifts." + (shift if not shift.is_empty() else current()))


static func detail(shift: = "") -> Dictionary:
	return Text.m("hud.duty.shiftDetails." + (shift if not shift.is_empty() else current()))



static func choose(shift: String, tell: = true) -> void :
	if not shift in NAMES or Net.is_client():
		return
	var changed: = shift != current()
	chosen = shift
	if not OS.get_cmdline_user_args().has("--no-save"):
		var file: = ConfigFile.new()
		file.set_value("duty", "shift", shift)
		file.save(PATH)
	if changed and tell:
		Game.notify(Text.f("calls.duty.shiftSet", [words(), detail()]), "good")



static func following() -> String:
	return NAMES[(NAMES.find(current()) + 1) % NAMES.size()]



static func apply(shift: String) -> void :
	_loaded = true
	if shift in NAMES:
		chosen = shift


static func _load() -> void :
	_loaded = true
	chosen = String(Config.Duty.Default)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shift="):
			chosen = arg.substr(8)
			return

	if OS.get_cmdline_user_args().has("--no-save"):
		return
	var file: = ConfigFile.new()
	if file.load(PATH) == OK:
		var kept: = String(file.get_value("duty", "shift", chosen))
		if kept in NAMES:
			chosen = kept
