extends ProofDebug







func _speed_on(pumper: Vehicle, at: Vector3, seconds: float) -> float:
	_park(pumper, at, 0.0)
	pumper._drift = 0.0
	await _wait(0.6)
	pumper.drive.speed = 0.0
	var fastest: = 0.0
	var clock: = 0.0
	while clock < seconds:
		pumper.drive.throttle = 1.0
		pumper.drive.speed += 0.0
		await get_tree().physics_frame
		clock += 1.0 / 60.0
		fastest = maxf(fastest, pumper.forward_speed)
	return fastest


func _scenario_winterdrive() -> void :
	await _wait(1.0)
	var pumper: = Vehicle.named("Fire Truck")
	pumper._board(player, "DoorCabLeft")
	await _wait(0.3)
	_check(pumper.driver() == player, "the player drives the pumper")

	var grass: = _stretch("Grass")
	var grass_material: = "Grass" if grass != Vector3.INF else "?"
	print("winterdrive: the grass stretch is %s at %s" % [grass_material, grass])
	var was: = Style.kind
	for season: Array in [["winter", Style.WINTER], ["summer", Style.SUMMER]]:
		Settings.set_style(season[1])
		await _wait(0.6)
		_park(pumper, grass, 0.0)
		await _wait(0.6)
		var from: = pumper.global_position
		pumper.debug_drive = 1.0
		var on_grass: = 0.0
		for tick in 10:
			await _wait(0.5)
			on_grass = maxf(on_grass, absf(pumper.forward_speed))
		var moved: = pumper.global_position.distance_to(from)
		pumper.debug_drive = null
		print("winterdrive: %s: after 5 s of full throttle on the grass %.1f studs a second, %.0f studs covered" % [season[0], on_grass, moved])
		if season[1] == Style.WINTER:
			_check(on_grass < float(Config.Drive.Winter.SnowSpeed) + 2.0 and moved < 40.0 and moved > 4.0, "in winter the snow off the road holds the truck to a crawl (it still creeps)")
			await _snap("snow")
		else:
			_check(on_grass > 14.0 and moved > 25.0, "in summer the grass is driven across")
	Settings.set_style(Style.WINTER)
	await _wait(0.6)

	var road: = _stretch("Asphalt")
	print("winterdrive: the road stretch is %s" % ("Asphalt at %s" % road if road != Vector3.INF else "?"))
	var drifts: = {}
	for season: Array in [["winter", Style.WINTER], ["summer", Style.SUMMER]]:
		Settings.set_style(season[1])
		await _wait(0.6)
		_park(pumper, road, 0.0)
		await _wait(0.6)
		pumper.drive.speed = 40.0
		pumper.debug_drive = 1.0
		Input.action_press("move_left")
		var most: = 0.0
		for frame in 90:
			pumper.drive.speed = maxf(pumper.drive.speed, 36.0)
			await get_tree().physics_frame
			most = maxf(most, absf(pumper._drift))
		Input.action_release("move_left")
		pumper.debug_drive = null
		drifts[season[0]] = most
		print("winterdrive: %s: a turn at speed on the road slides %.2f studs a second at most" % [season[0], most])
	_check(drifts["winter"] > 1.5 and drifts["summer"] < 0.2, "on a winter road the truck slides out of the corner; on a summer one it does not")
	Settings.set_style(was)
	await _done()




func _stretch(material: String) -> Vector3:
	var spots: Array = []
	for z in range(-600, 601, 20):
		for x in range(-600, 601, 20):
			spots.append(Vector3(x, 0, z))
	spots.sort_custom( func(a: Vector3, b: Vector3) -> bool: return a.length_squared() < b.length_squared())
	for at: Vector3 in spots:
		var ok: = true
		for ahead in [0.0, 14.0, 28.0, 42.0, 56.0, 70.0]:
			for aside in [-5.0, 0.0, 5.0]:
				var spot: Vector3 = at + Vector3(aside, 0, - ahead)
				var hit: = Game.world.raycast(spot + Vector3(0, 30, 0), spot + Vector3(0, -12, 0), World.LAYER_SOLID)
				if hit.is_empty() or Game.store.material(Game.world.row_hit(hit)) != material:
					ok = false
					break
			if not ok:
				break
		if ok:
			return at
	return Vector3.INF



func _drift_at(pumper: Vehicle, road: Vector3) -> float:
	_park(pumper, road, 0.0)
	pumper._drift = 0.0
	await _wait(0.6)
	pumper.drive.speed = 40.0
	pumper.debug_drive = 1.0
	Input.action_press("move_left")
	var most: = 0.0
	for frame in 90:
		pumper.drive.speed = maxf(pumper.drive.speed, 36.0)
		await get_tree().physics_frame
		most = maxf(most, absf(pumper._drift))
	Input.action_release("move_left")
	pumper.debug_drive = null
	return most


func _scenario_plow() -> void :
	await _wait(1.0)
	var was: = Style.kind
	Settings.set_style(Style.WINTER)
	await _wait(1.0)
	var snow: = RoadSnow.current
	var traffic: = Traffic.current
	if not _check(snow != null and traffic != null, "the roads have their snow and the town its traffic"):
		await _done()
		return
	snow.clock = 1.5

	traffic._next_plow = 0.0
	var plow: Traffic.Car = null
	var waited: = 0.0
	while plow == null and waited < 20.0:
		await _wait(0.5)
		waited += 0.5
		for car: Traffic.Car in traffic.vehicles:
			if car.kind == "plow" and car.s > 0.0:
				plow = car
				break
	if not _check(plow != null, "a plow is out on a winter's day"):
		await _done()
		return

	var marks: Array[Vector3] = []
	for step in 24:
		await _wait(0.5)
		marks.append(Vector3(plow.x, 0, plow.z))
	var behind: Vector3 = marks[marks.size() - 8]
	var lane: = Vector3(plow.dx, 0, plow.dz)
	print("plow: %s out; %d pixels ploughed; depth where it was 4 s ago %.2f, under the plow now %.2f; the clock %.2f" % [traffic.vehicles.filter( func(car: Traffic.Car) -> bool: return car.kind == "plow").size(), snow.ploughed, snow.depth_at(behind), snow.depth_at(Vector3(plow.x, 0, plow.z)), snow.clock])
	_check(snow.ploughed > 50, "the plow scrapes the road")
	_check(snow.depth_at(behind) < 0.1, "where it has been the road is bare")
	_check(snow.depth_at(behind + Vector3( - lane.z, 0, lane.x) * 30.0) > 0.9, "a street away it lies deep")
	var ahead: = Vector3(plow.x, 0, plow.z)
	var side: = Vector3( - lane.z, 0, lane.x)
	_view(ahead - lane * 40.0 + side * 18.0 + Vector3(0, 16, 0), ahead + Vector3(0, 3, 0))
	await _wait(0.4)
	await _snap("plow")
	_view(Vector3(plow.x, 0, plow.z) + lane * 24.0 + side * 9.0 + Vector3(0, 6, 0), Vector3(plow.x, 4, plow.z))
	await _wait(0.3)
	await _snap("plow_front")

	var fresh: = snow.depth_at(behind)
	snow.clock += 0.5
	await _wait(0.3)
	print("plow: the strip filled in: %.2f -> %.2f" % [fresh, snow.depth_at(behind)])
	_check(snow.depth_at(behind) > fresh + 0.4, "and the snow covers the ploughed strip again as it falls")

	var pumper: = Vehicle.named("Fire Truck")
	pumper._board(player, "DoorCabLeft")
	await _wait(0.3)
	var road: = _stretch("Asphalt")
	snow.clock = 1.5
	var deep: = await _drift_at(pumper, road)
	snow._scrape(Vector2(road.x, road.z + 20.0), Vector2(road.x, road.z - 160.0), 30.0)
	var clear: = await _drift_at(pumper, road)
	print("plow: a hard turn at speed slides %.2f studs a second in deep snow, %.2f on the ploughed road" % [deep, clear])
	_check(clear < deep * 0.5, "a ploughed road holds far better than a snowed-over one")
	Settings.set_style(was)
	await _done()




func _scenario_plowlook() -> void :
	await _wait(1.0)
	var was: = Style.kind
	Settings.set_style(Style.WINTER)
	await _wait(1.5)
	var road: = _stretch("Asphalt")
	var view: = TrafficView.current
	var record: = TrafficView.Drawn.new()
	record.car = Traffic.Car.new()
	record.car.kind = "plow"
	view._build_plow(record)
	view.add_child(record.model)
	var ground: = _ground(road)
	record.model.global_transform = Transform3D(Basis.IDENTITY, ground)
	print("plowlook: %d pieces in one mesh of %d vertices; %d lamps, %d beacons" % [PlowBody.pieces().size(), PlowBody.mesh().surface_get_array_len(0), record.lamps.values().reduce( func(sum: int, lamps: Array) -> int: return sum + lamps.size(), 0), record.beacons.size()])
	_check(record.beacons.size() == 2, "two beacons on the light bar")
	var middle: = ground + Vector3(0, 4, 0)
	for shot: Array in [["front", Vector3(14, 6, -28)], ["side", Vector3(30, 5, 2)], ["back", Vector3(-14, 7, 30)], ["blade", Vector3(-9, 3.5, -22)], ["above", Vector3(18, 22, -18)]]:
		var aim: = middle + (Vector3(0, -1.5, -12) if shot[0] == "blade" else Vector3.ZERO)
		_view(ground + shot[1], aim, 50.0)
		record.lit = -1
		view._flash_beacons(record)
		await _wait(0.4)
		await _snap(shot[0])
	record.model.queue_free()
	Settings.set_style(was)
	await _done()




func _scenario_tracks() -> void :
	await _wait(1.0)
	var was: = Style.kind
	Settings.set_style(Style.WINTER)
	await _wait(1.0)
	var tracks: TyreTracks = get_tree().root.find_child("TyreTracks", true, false)
	if not _check(tracks != null, "the tracks are there to be laid"):
		await _done()
		return
	RoadSnow.current.clock = 1.5
	var pumper: = Vehicle.named("Fire Truck")
	pumper._board(player, "DoorCabLeft")
	await _wait(0.3)
	var counts: = {}
	for ground: String in ["Grass", "Asphalt"]:
		var at: = _stretch(ground)
		_park(pumper, at, 0.0)
		await _wait(0.8)
		var before: = tracks._laid
		pumper.debug_drive = 1.0
		Input.action_press("move_left")
		await _wait(1.2)
		Input.action_release("move_left")
		await _wait(2.5)
		pumper.debug_drive = null
		await _wait(1.0)
		counts[ground] = tracks._laid - before
		var back: = - pumper.global_basis.z
		_view(pumper.global_position + pumper.global_basis.z * 26.0 + pumper.global_basis.x * 8.0 + Vector3(0, 10, 0), pumper.global_position + pumper.global_basis.z * 8.0)
		await _wait(0.4)
		await _snap(ground.to_lower())

	var road: = _stretch("Asphalt")
	RoadSnow.current._scrape(Vector2(road.x, road.z + 30.0), Vector2(road.x, road.z - 160.0), 30.0)
	_park(pumper, road, 0.0)
	await _wait(0.8)
	var before: = tracks._laid
	pumper.debug_drive = 1.0
	await _wait(2.5)
	pumper.debug_drive = null
	counts["ploughed"] = tracks._laid - before
	print("tracks: strips laid on the snow off the road %d, on a snowed-over road %d, on a ploughed road %d" % [counts["Grass"], counts["Asphalt"], counts["ploughed"]])
	_check(counts["Grass"] > 6, "tracks behind the wheels in the snow off the road")
	_check(counts["Asphalt"] > 10, "and on a road the snow lies on")
	_check(counts["ploughed"] == 0, "but none on a ploughed road")
	Settings.set_style(was)
	await _done()
