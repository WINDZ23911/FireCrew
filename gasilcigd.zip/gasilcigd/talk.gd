extends ProofDebug







func _heard_kind(kind: String) -> Array:
	var found: Array = []
	for entry: Array in NetTalk.current.heard:
		if entry[0] == kind:
			found.append(entry)
	return found


func _scenario_talksolo() -> void :
	await _wait(2.0)
	var panel: Control = Hud.current.widgets["crew"]
	_check( not panel.visible, "alone with no AI crew, the crew panel is not shown")

	player.camera.pitch = -0.35
	await _wait(0.4)
	await _tap("crew_order")
	await _wait(0.3)
	var pings: = _heard_kind("ping")
	print("talksolo: pings %s; on show %s" % [pings, NetTalk.current.pings.keys()])
	_check(pings.size() == 1 and NetTalk.current.pings.has(1), "G with no AI crew pings what is looked at")
	await _snap("ping")

	await _tap("shout")
	await _wait(0.5)
	_check(_heard_kind("shout").size() == 1 and player.rig.extras.has("shout"), "H shouts Na pomoč! with a hand up")
	await _snap("shout")
	await _wait(float(Config.Talk.ShoutTime) + 0.3)
	_check( not player.rig.extras.has("shout"), "the hand comes down after the shout")

	var wheel: HudRadioWheel = Hud.current.widgets["radio_wheel"]
	await get_tree().process_frame
	Input.action_press("radio")
	await _wait(0.4)
	_check(wheel.is_open() and Game.ui_open, "Z held brings the radio wheel up")
	await _snap("wheel")
	var key: = InputEventAction.new()
	key.action = "slot_2"
	key.pressed = true
	Input.parse_input_event(key)
	await _wait(0.3)
	Input.action_release("radio")
	await _wait(0.3)
	var radio: = _heard_kind("radio")
	_check(radio.size() == 1 and radio[0][2] == "Need help!" and not wheel.is_open() and not Game.ui_open, "its key 2 says 'Need help!' (%s)" % [radio])

	var chat: HudChat = Hud.current.widgets["chat"]
	var enter: = InputEventAction.new()
	enter.action = "chat"
	enter.pressed = true
	Input.parse_input_event(enter)
	await _wait(0.3)
	_check(chat.is_open() and InputMap.action_get_events("mask").is_empty(), "Enter opens the chat and Q is only a letter in it")
	await _snap("chat")
	var escape: = InputEventKey.new()
	escape.physical_keycode = KEY_ESCAPE
	escape.keycode = KEY_ESCAPE
	escape.pressed = true
	Input.parse_input_event(escape)
	await _wait(0.3)
	_check( not chat.is_open() and not InputMap.action_get_events("mask").is_empty() and _heard_kind("chat").is_empty() and not HudPause.current.open, "Esc shuts it, says nothing, gives the keys back and leaves the pause menu shut")

	player.health = player.max_health * 0.3
	var hurt: = Text.say(NetTalk.status_of(player)[0], "en")
	player.health = player.max_health
	player.set_attr("Scba", true)
	player.set_attr("Mask", true)
	player.set_attr("AirBar", 200)
	var air: = Text.say(NetTalk.status_of(player)[0], "en")
	player.set_attr("Mask", false)
	player.set_attr("Scba", false)
	print("talksolo: status hurt '%s', on air '%s'" % [hurt, air])
	_check(hurt.begins_with("HURT") and air.begins_with("ON AIR ·") and air.ends_with("MIN"), "a teammate's status: '%s', '%s'" % [hurt, air])
	_done()
