extends RefCounted













const QUIET: = ["residential", "service", "living_street", "track"]
const THROUGH: = ["primary", "secondary", "tertiary"]
const CELL: = 100.0


const OPEN_DASH: = 5.0
const OPEN_EVERY: = 15.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var segments: = _segments(kit.layout()["roads"])
	var quiet: = 0
	var country: Array = []
	var dash_length: = 0.0
	var dashes: = 0
	for row in kit.rows_under("Map/Surfaces"):
		if store.name_at(row) != "paint":
			continue
		var at: = store.position(row)
		var found: Array = _nearest(segments, Vector2(at.x, at.z))
		if found.is_empty():
			continue
		var segment: Dictionary = found[0]
		var lateral: float = found[1]
		var size: = store.size(row)
		var basis: = store.basis(row)
		var long_axis: = basis.x if size.x > size.z else basis.z
		var length: = maxf(size.x, size.z)
		var along: = absf(Vector2(long_axis.x, long_axis.z).normalized().dot(segment["way"]))
		if along < 0.8:
			continue
		var half: float = segment["width"] / 2.0
		var centre: = absf(lateral) < 1.0
		var edge: = absf(absf(lateral) - half) < 4.0
		if segment["class"] in QUIET and (centre or edge):
			store.set_transparency(row, 1.0)
			quiet += 1
		elif segment["class"] in THROUGH and centre and length < 12.0:
			var way: = Vector3(segment["way"].x, 0, segment["way"].y)
			if kit.country_road(at, way, half):
				country.append([row, segment])
				dash_length += length
				dashes += 1


	var laid: = 0
	if dashes > 0:
		var metre: = dash_length / dashes / 3.0
		var parent: = kit.own_folder("StreetSections")
		var spots: Dictionary = {}
		for entry: Array in country:
			var row: int = entry[0]
			var segment: Dictionary = entry[1]
			var at: = store.position(row)
			var s: = Vector2(at.x, at.z).distance_to(segment["a"])
			var slot: = floori(s / (OPEN_EVERY * metre))
			var key: = [segment["id"], slot]
			store.set_transparency(row, 1.0)
			if spots.has(key):
				continue
			spots[key] = true
			var middle: Vector2 = segment["a"] + segment["way"] * (slot + 0.5) * OPEN_EVERY * metre
			var place: = PolishKit.facing(Vector3(middle.x, at.y, middle.y), Vector3(segment["way"].x, 0, segment["way"].y))
			var size: = store.size(row)
			var width: = minf(size.x, size.z)
			kit.box(parent, place, Vector3(width, size.y, OPEN_DASH * metre), store.color(row), store.material(row), "paint")
			laid += 1
	return "street sections: %d lines taken off the quiet streets, %d town dashes out of town relaid as %d open-road dashes" % [quiet, dashes, laid]



static func _segments(roads: Array) -> Dictionary:
	var grid: Dictionary = {}
	var id: = 0
	for road: Dictionary in roads:
		var points: Array = road["points"]
		for leg in points.size() - 1:
			var a: = Vector2(float(points[leg][0]), float(points[leg][1]))
			var b: = Vector2(float(points[leg + 1][0]), float(points[leg + 1][1]))
			if a.distance_to(b) < 0.5:
				continue
			id += 1
			var segment: = {"id": id, "a": a, "b": b, "way": (b - a).normalized(), "class": road["class"], "width": float(road["width"])}
			var low: = Vector2i(floori(minf(a.x, b.x) / CELL) - 1, floori(minf(a.y, b.y) / CELL) - 1)
			var high: = Vector2i(floori(maxf(a.x, b.x) / CELL) + 1, floori(maxf(a.y, b.y) / CELL) + 1)
			for cx in range(low.x, high.x + 1):
				for cz in range(low.y, high.y + 1):
					var key: = Vector2i(cx, cz)
					if not grid.has(key):
						grid[key] = []
					grid[key].append(segment)
	return grid



static func _nearest(grid: Dictionary, at: Vector2) -> Array:
	var best: Array = []
	var best_distance: = INF
	for segment: Dictionary in grid.get(Vector2i(floori(at.x / CELL), floori(at.y / CELL)), []):
		var a: Vector2 = segment["a"]
		var b: Vector2 = segment["b"]
		var t: = clampf((at - a).dot(b - a) / (b - a).length_squared(), 0.0, 1.0)
		var distance: = at.distance_to(a + (b - a) * t)
		if distance < best_distance:
			best_distance = distance
			var way: Vector2 = segment["way"]
			best = [segment, (at - a).dot(Vector2( - way.y, way.x))]
	return best
