class_name Prompt
extends Node3D



signal triggered(player: Player)
signal hold_began(player: Player)
signal hold_ended(player: Player)

static var all: Array[Prompt] = []



static var by_id: Dictionary = {}
static var _made: = 0
static var _sealed: = false

var net_id: = ""

@export var action: Variant = ""
@export var object: Variant = ""
@export var hold: = 0.0
@export var reach: = 10.0
@export var enabled: = true
@export var key: = "interact"

var condition: = Callable()

var hands: Node3D = null


var gesture: = ""



func hand_point() -> Vector3:
	return hands.global_position if hands != null and is_instance_valid(hands) and hands.is_inside_tree() else global_position


static func make(parent: Node3D, action_text: Variant, object_text: Variant = "", hold_time: = 0.0, max_distance: = 10.0) -> Prompt:
	var prompt: = Prompt.new()
	prompt.action = action_text
	prompt.object = object_text
	prompt.hold = hold_time
	prompt.reach = max_distance
	parent.add_child(prompt)
	return prompt



static func seal() -> void :
	_sealed = true


func _enter_tree() -> void :
	all.append(self)
	if net_id.is_empty() and not _sealed:
		_made += 1
		net_id = "p%d" % _made
	if not net_id.is_empty():
		by_id[net_id] = self
		Net.prompt_made(self)


func _exit_tree() -> void :
	all.erase(self)
	if by_id.get(net_id) == self:
		by_id.erase(net_id)


func shown_to(player: Player) -> bool:
	if not enabled or not is_visible_in_tree():
		return false
	if condition.is_valid() and not condition.call(player):
		return false
	return true





const RELEASES: Array[String] = ["calls.tree.letGo"]
const HELD_FIRST: = 1000.0



static func nearest(player: Player, from: Vector3, key_action: String, facing: = Vector3.ZERO) -> Prompt:
	var best: Prompt = null
	var best_score: = INF
	var holding: = player != null and player.get_attr("Dragging") != null
	for prompt in all:
		if prompt.key != key_action:
			continue
		var offset: = prompt.global_position - from
		var distance: = offset.length()
		if distance > prompt.reach or not prompt.shown_to(player):
			continue

		var score: = distance
		if facing != Vector3.ZERO and distance > 0.5:
			score -= facing.dot(offset / distance) * 6.0
		if holding and prompt.action is Dictionary and String(prompt.action.get("k", "")) in RELEASES:
			score -= HELD_FIRST
		if score < best_score:
			best = prompt
			best_score = score
	return best






const GROUP: = 2.6
const CHOICES: = 4

const BOARD_FIRST: = 2.5





static func choices(player: Player, from: Vector3, eye: Vector3, along: Vector3, keys: Array[String]) -> Array[Prompt]:
	var scored: Array = []
	var holding: = player != null and player.get_attr("Dragging") != null
	for prompt in all:
		if not prompt.key in keys:
			continue
		var distance: = (prompt.global_position - from).length()
		if distance > prompt.reach or not prompt.shown_to(player):
			continue
		var offset: = prompt.global_position - eye
		var angle: = 0.0 if offset.length() < 0.01 or along == Vector3.ZERO else rad_to_deg(along.angle_to(offset))
		var score: = angle * 0.25 + distance * 0.33
		if prompt.key == "item":
			score -= BOARD_FIRST
		if holding and prompt.action is Dictionary and String(prompt.action.get("k", "")) in RELEASES:
			score -= HELD_FIRST
		scored.append([score, prompt])
	var out: Array[Prompt] = []
	if scored.is_empty():
		return out
	scored.sort_custom( func(a: Array, b: Array) -> bool: return a[0] < b[0])
	var best: Prompt = scored[0][1]
	for pair: Array in scored:
		var prompt: Prompt = pair[1]
		if prompt == best or prompt.global_position.distance_to(best.global_position) <= GROUP:
			out.append(prompt)
			if out.size() >= CHOICES:
				break
	return out
