extends RefCounted


static func start(main: Node) -> void :
	var service: = TruckService.new()
	service.name = "TruckService"
	main.add_child(service)

	var roof: = TruckRoof.new()
	roof.name = "TruckRoof"
	main.add_child(roof)
