class_name HudPing
extends Control






const EDGE: = Vector2(48, 70)
const PIN: = 34.0

var _font: Font
var _pin: Texture2D
var _drawn: = false


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = Ui.label_font()
	_pin = Ui.icon_texture("pin")


func _process(_delta: float) -> void :
	var any: = NetTalk.current != null and not NetTalk.current.pings.is_empty()
	if any or _drawn:
		queue_redraw()
	_drawn = any


func _draw() -> void :
	var talk: = NetTalk.current
	var camera: = get_viewport().get_camera_3d()
	if talk == null or camera == null:
		return
	var now: = Game.now()
	var screen: = get_viewport_rect().size
	var fade: = float(Config.Talk.PingFade)
	for peer: int in talk.pings.keys():
		var ping: Dictionary = talk.pings[peer]
		var left: float = ping["until"] - now
		if left <= 0.0:
			talk.pings.erase(peer)
			continue
		var alpha: = clampf(left / fade, 0.0, 1.0)
		var at: Vector3 = ping["at"]
		var behind: = camera.is_position_behind(at)
		var point: = camera.unproject_position(at)
		if behind:

			point = Vector2(screen.x - point.x, screen.y)
		var shown: = point.clamp(EDGE, screen - EDGE)
		var colour: Color = ping["colour"]
		colour.a = alpha
		var shade: = Color(0, 0, 0, 0.75 * alpha)

		var age: float = now - ping["since"]
		if age < 0.8 and shown == point:
			draw_arc(shown, 8.0 + age * 60.0, 0.0, TAU, 32, Color(colour, (1.0 - age / 0.8) * alpha), 3.0)
		draw_texture_rect(_pin, Rect2(shown - Vector2(PIN / 2.0, PIN), Vector2(PIN, PIN)), false, colour)
		var words: = Text.say(ping["label"])
		var metres: = Ui.metres(camera.global_position.distance_to(at))
		var under: = "%s · %s %s" % [ping["name"], metres[0], metres[1]]
		var top: = shown + Vector2(-160, - PIN - 10)
		draw_string_outline(_font, top, words, HORIZONTAL_ALIGNMENT_CENTER, 320, 20, 6, shade)
		draw_string(_font, top, words, HORIZONTAL_ALIGNMENT_CENTER, 320, 20, colour)
		var low: = shown + Vector2(-160, 20)
		draw_string_outline(_font, low, under, HORIZONTAL_ALIGNMENT_CENTER, 320, 15, 5, shade)
		draw_string(_font, low, under, HORIZONTAL_ALIGNMENT_CENTER, 320, 15, Color(Ui.TEXT, alpha))
