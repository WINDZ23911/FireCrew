class_name Vehicle
extends RigidBody3D







signal driver_changed(driver: Player)
signal water_changed

signal horn

const GLASS: = Color(0.13, 0.17, 0.21, 0.32)
const LAMP_OFF: = Color(200 / 255.0, 200 / 255.0, 190 / 255.0)
const LAMP_ON: = Color(1.0, 0.98, 0.9)
const HEADLIGHT_ENERGY: = 22.0
const TAIL_OFF: = Color(120 / 255.0, 20 / 255.0, 20 / 255.0)
const TAIL_ON: = Color(1.0, 0.12, 0.08)
const BLUE_OFF: = Color(22 / 255.0, 58 / 255.0, 170 / 255.0)
const BLUE_ON: = Color(120 / 255.0, 175 / 255.0, 1.0)
const REVERSE_ON: = Color(1.0, 1.0, 0.96)
const HEAD_GLARE: = Color(1.0, 0.93, 0.8)
const TAIL_GLARE: = Color(1.0, 0.12, 0.06)
const BLUE_GLARE: = Color(0.25, 0.45, 1.0)
const AMBER_OFF: = Color(0.36, 0.2, 0.05)
const AMBER_ON: = Color(1.0, 0.72, 0.25)
const ARROW_STEP: = 0.09
const ARROW_HOLD: = 0.45
const DOOR_ANGLE: = deg_to_rad(72)
const DOOR_TIME: = 0.5
const SHUTTER_TIME: = 0.9
const SHUTTER_ROLLED: = 0.06
const SIREN_HOLD: = 0.4
const BODY_ROLL: = deg_to_rad(2.6) / 40.0
const BODY_PITCH: = deg_to_rad(1.3) / 40.0
const BODY_MOST: = deg_to_rad(3.5)

const LEVEL_RATE: = 5.0
const LEVEL_MOST: = 1.2
const ABOVE: = 1.5
const BELOW: = 8.0

static var all: Array[Vehicle] = []

var spec: Dictionary
var data: Dictionary
var drive: VehicleDrive
var body: Node3D
var objects: Dictionary = {}
var doors: Dictionary = {}
var shutters: Dictionary = {}
var props: Dictionary = {}
var wheels: Array = []
var seats: Array[Node3D] = []
var riders: Array = []
var outlets: Array = []
var intake: Dictionary = {}
var engine: EngineAudio
var wheelbase: = 14.5
var rear_axle: = 7.0
var track: = 4.0
var water: = 0.0
var capacity: = 0.0
var fuel: = 0.0
var fuel_capacity: = 0.0
var headlights_on: = false
var blue_on: = false
var siren: = 0



var arrows: = 0
var locked: = false
var forward_speed: = 0.0

var _headlamps: Array = []
var _tail_lamps: Array = []
var _blue: Array = []
var _siren_player: AudioStreamPlayer3D
var _horn_player: AudioStreamPlayer3D
var _beeper: AudioStreamPlayer3D
var _siren_down: = -1.0
var _exit_down: = -1.0
var _spin: = 0.0
var _roll: = 0.0
var _pitch: = 0.0
var _steering_wheel: Node3D
var _steer_axis: = Vector3.UP
var _kit_glass: ShaderMaterial
var _reverse_lamps: Array = []
var _arrow_blocks: Array = []
var _reversing: = false
var _exhaust: RbxEmitter
var _dash_light: OmniLight3D
var _was_driven: = false
var _impact_at: = -10.0
var _steer_held: = 0.0
var _steer_way: = 0.0


static func make(vehicle_spec: Dictionary) -> Vehicle:
	var vehicle: = Vehicle.new()
	vehicle.spec = vehicle_spec
	vehicle.name = String(vehicle_spec["name"]).replace(" ", "")
	vehicle.transform = vehicle_spec["spawn"]
	return vehicle


static func named(vehicle_name: String) -> Vehicle:
	for vehicle in all:
		if vehicle.spec["name"] == vehicle_name:
			return vehicle
	return null


func _enter_tree() -> void :
	all.append(self)


func _exit_tree() -> void :
	all.erase(self)




static func kit_path(kit: String) -> String:
	var own: = "res://assets/models/%s.glb" % kit.replace("_kit", "2_kit")
	return own if ResourceLoader.exists(own) else "res://assets/models/%s.glb" % kit



static func layout(name: String) -> Dictionary:
	var own: = "res://data/godot/%s.json" % name
	return Rbx.load_json(own if FileAccess.file_exists(own) else "res://data/modules/%s.json" % name)


func _ready() -> void :
	data = layout(spec["data"])
	drive = VehicleDrive.new(spec["name"])
	wheelbase = data["rearAxle"] - data["frontAxle"]
	rear_axle = data["rearAxle"]
	track = absf(data["wheels"][0]["x"])
	capacity = spec.get("tankCapacity", 0.0)
	water = 0.0 if spec.get("tankEmpty", false) else capacity
	fuel_capacity = spec.get("fuelCapacity", 100.0)
	fuel = fuel_capacity

	collision_layer = World.LAYER_VEHICLE
	collision_mask = World.LAYER_SOLID | World.LAYER_VEHICLE
	mass = 13000.0
	gravity_scale = 0.0
	can_sleep = false
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3.ZERO
	continuous_cd = true
	physics_material_override = PhysicsMaterial.new()
	physics_material_override.friction = 0.2

	body = Node3D.new()
	body.name = "Body"
	add_child(body)
	_load_kit()
	_build_colliders()
	_build_doors()
	_build_shutters()
	_build_props()
	_build_borrowed()
	_build_cab()
	_build_lights()
	_build_wheels()
	_build_seats()
	_build_couplings()
	_build_sounds()
	_build_exhaust()
	var cab: = VehicleCab.new()
	cab.name = "Cab"
	add_child(cab)
	var middle: = Vector3(0, float(data["axleY"]) - float(data["wheelRadius"]), (float(data["front"]) + float(data["rear"])) / 2.0)
	VehicleLook.contact_shadow(self, middle, float(data["halfWidth"]) * 2.0, float(data["rear"]) - float(data["front"]))


func v(list: Array) -> Vector3:
	return Vector3(list[0], list[1], list[2])



static func table(value: Variant) -> Dictionary:
	return value if value is Dictionary else {}





func _load_kit() -> void :
	var scene: PackedScene = load(kit_path(spec["kit"]))
	if scene == null:
		push_warning("no kit for " + spec["name"])
		return
	var kit: = scene.instantiate()

	_kit_glass = VehicleLook.glass(GLASS).duplicate()
	for child in kit.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null:
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() != 2 or bits[0] == "Marker":
			continue
		mesh.owner = null
		kit.remove_child(mesh)
		if bits[1] == "glass":
			mesh.material_override = _kit_glass
			mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		else:
			VehicleLook.coat(mesh, spec["name"], table(data.get("tape")))
		if not objects.has(bits[0]):
			objects[bits[0]] = []
		objects[bits[0]].append(mesh)
	kit.free()
	for mesh: MeshInstance3D in objects.get("Body", []):
		body.add_child(mesh)




func hang(object: String, pivot: Transform3D, parent: Node3D = null) -> Node3D:
	var node: = Node3D.new()
	node.name = object
	(parent if parent else body).add_child(node)
	node.transform = pivot
	var inverse: = pivot.affine_inverse()
	for mesh: MeshInstance3D in objects.get(object, []):
		if mesh.get_parent():
			mesh.get_parent().remove_child(mesh)
		node.add_child(mesh)
		mesh.transform = inverse * mesh.transform
	return node



func add_part(part_name: String, size: Vector3, place: Transform3D, color: Color, shape: = PartStore.Shape.BLOCK, material: = "SmoothPlastic", parent: Node3D = null) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	mesh.name = part_name
	mesh.mesh = World.unit_mesh(shape)
	var drawn: = size
	if shape == PartStore.Shape.CYLINDER:
		drawn = Vector3(size.x, minf(size.y, size.z), minf(size.y, size.z))
	var look: Array = WorldMaterials.LOOKS.get(material, WorldMaterials.LOOKS["Plastic"])
	var made: = StandardMaterial3D.new()
	made.albedo_color = color
	made.roughness = look[0]
	made.metallic = look[1]
	mesh.material_override = made
	(parent if parent else body).add_child(mesh)
	mesh.transform = place * Transform3D(Basis.from_scale(drawn), Vector3.ZERO)
	return mesh


func _build_colliders() -> void :
	for corners: Array in data["colliders"]:
		var a: = v(corners[0])
		var b: = v(corners[1])
		var shape: = CollisionShape3D.new()
		var box: = BoxShape3D.new()
		box.size = (b - a).abs()
		shape.shape = box
		shape.position = (a + b) / 2.0
		add_child(shape)


func _build_doors() -> void :
	for door_name: String in data["doors"]:
		var info: Dictionary = data["doors"][door_name]
		var hinge: = hang(door_name, Transform3D(Basis.IDENTITY, v(info["hinge"])))
		var grip: = Node3D.new()
		hinge.add_child(grip)
		grip.position = v(info["handle"]) - v(info["hinge"])
		var vehicle_name: Variant = Text.named("vehicles", spec["name"])
		var door: = {
			"name": door_name, "hinge": hinge, "open": false, "amount": 0.0, "side": float(info["side"]), 
			"doorway": v(info["seat"]), 
		}
		var prompt: = Prompt.make(grip, Text.m("gear.truck.doorOpen"), vehicle_name, 0.0, 9.0)
		prompt.triggered.connect( func(_player: Player) -> void : set_door(door_name, not door["open"]))
		door["prompt"] = prompt


		var doorway: = Node3D.new()
		add_child(doorway)
		doorway.position = door["doorway"]
		var driving: = door_name == "DoorCabLeft"
		var seat_prompt: = Prompt.make(doorway, Text.m("gear.truck.drive" if driving else "gear.truck.ride"), vehicle_name, 0.0, 9.0)
		seat_prompt.key = "item"
		seat_prompt.triggered.connect( func(player: Player) -> void : _board_at(player, door_name))
		door["seat_prompt"] = seat_prompt
		doors[door_name] = door


func set_door(door_name: String, open: bool) -> void :
	var door: Dictionary = doors[door_name]
	if door["open"] == open:
		return
	door["open"] = open
	door["prompt"].action = Text.m("gear.truck.doorClose" if open else "gear.truck.doorOpen")
	var hinge: Node3D = door["hinge"]


	if door.get("tween") != null and door["tween"].is_valid():
		door["tween"].kill()
	var tween: = create_tween()
	door["tween"] = tween
	tween.tween_method( func(amount: float) -> void :
		door["amount"] = amount
		hinge.rotation.y = door["side"] * DOOR_ANGLE * amount
	, door["amount"], 1.0 if open else 0.0, DOOR_TIME * absf((1.0 if open else 0.0) - door["amount"]) + 0.01)
	Sounds.once(hinge, "cab_door_open" if open else "cab_door_shut", 0.6, 8.0, 80.0)


func _build_shutters() -> void :
	for shutter_name: String in table(data.get("shutters")):
		var info: Dictionary = data["shutters"][shutter_name]
		var pieces: Array = objects.get(info.get("object", ""), [])
		var shutter: = {"name": shutter_name, "open": false, "amount": 0.0, "info": info, "node": null, "flap": null}
		if not pieces.is_empty():

			var top: float = info["top"]
			var node: = hang(info["object"], Transform3D(Basis.IDENTITY, Vector3(0, top, 0)))
			shutter["node"] = node
		if info.has("flap"):
			var flap: Dictionary = info["flap"]
			shutter["flap"] = hang(flap["object"], Transform3D(Basis.IDENTITY, v(flap["hinge"])))
		shutters[shutter_name] = shutter


func set_shutter(shutter_name: String, open: bool) -> void :
	var shutter: Dictionary = shutters[shutter_name]
	if shutter["open"] == open:
		return
	shutter["open"] = open
	var info: Dictionary = shutter["info"]
	if shutter.get("tween") != null and shutter["tween"].is_valid():
		shutter["tween"].kill()
	var tween: = create_tween()
	shutter["tween"] = tween
	tween.tween_method( func(amount: float) -> void :
		shutter["amount"] = amount
		if shutter["node"]:
			shutter["node"].scale.y = 1.0 - amount * (1.0 - SHUTTER_ROLLED)
		if shutter["flap"]:
			var flap: Dictionary = info["flap"]
			if flap.get("axis", "z") == "x":
				shutter["flap"].rotation.x = - deg_to_rad(flap.get("angle", 90.0)) * amount
			else:
				shutter["flap"].rotation.z = - float(flap["side"]) * deg_to_rad(flap.get("angle", 90.0)) * amount
	, shutter["amount"], 1.0 if open else 0.0, SHUTTER_TIME)


func set_lockers(open: bool) -> void :
	for shutter_name: String in shutters:
		set_shutter(shutter_name, open)


func lockers_open() -> bool:
	for shutter_name: String in shutters:
		if shutters[shutter_name]["open"]:
			return true
	return false


func _build_props() -> void :
	for prop_name: String in table(data.get("props")):
		var info: = table(data["props"][prop_name])
		var node: = hang(prop_name, Transform3D.IDENTITY)
		for side in ["L", "R"]:
			var jaw: String = prop_name + "Jaw" + side
			if objects.has(jaw):
				for mesh: MeshInstance3D in objects[jaw]:
					node.add_child(mesh)
		props[prop_name] = {
			"node": node, "locker": info.get("locker", ""), "tool": info.get("tool", ""), 
			"spot": v(info["spot"]) if info.has("spot") else Vector3.ZERO, "grip": table(info.get("grip")), 
		}




func _build_borrowed() -> void :
	for info: Dictionary in spec.get("borrowed", []):
		var scene: PackedScene = load(kit_path(info["kit"]))
		var source: Dictionary = layout(info["data"])["props"].get(info["prop"], {})
		if scene == null or source.is_empty():
			continue
		var from: = v(source["spot"])
		var turn: = Basis(Vector3.UP, deg_to_rad(float(info.get("turn", 0.0))))
		var place: = Transform3D(turn, info["at"]) * Transform3D(Basis.IDENTITY, - from)
		var node: = Node3D.new()
		node.name = info["prop"]
		body.add_child(node)
		var kit: = scene.instantiate()
		for child in kit.get_children():
			var mesh: = child as MeshInstance3D
			if mesh != null and String(mesh.name).split("_")[0] == info["prop"]:
				var copy: = mesh.duplicate() as MeshInstance3D
				node.add_child(copy)
				copy.transform = place * mesh.transform
		kit.free()
		var grip: = table(source.get("grip"))
		if not grip.is_empty():
			var at: = place * v(grip["pos"])
			grip = {"pos": [at.x, at.y, at.z], "blade": grip["blade"], "handle": grip["handle"]}
		props[info["prop"]] = {
			"node": node, "locker": info["locker"], "tool": source.get("tool", ""), "spot": place * from, "grip": grip, 
		}


func _build_cab() -> void :
	var steering: = table(data.get("steering"))
	if not steering.is_empty() and objects.has("SteeringWheel"):
		var up: = v(steering["up"])
		var axis: = v(steering["axis"])
		var pivot: = Transform3D(Basis(Vector3.RIGHT, up, axis), v(steering["centre"]))
		_steering_wheel = hang("SteeringWheel", pivot)
		_steer_axis = Vector3.BACK

	for object: String in objects:
		for mesh: MeshInstance3D in objects[object]:
			if mesh.get_parent() == null and not object.begins_with("Wheel"):
				body.add_child(mesh)


func _build_lights() -> void :
	for position_list: Array in data.get("headlights", []):
		var size: = v(data["headlightSize"]) if data.has("headlightSize") else Vector3(1.5, 0.75, 0.12)
		var lamp: = add_part("Headlight", size, Transform3D(Basis.IDENTITY, v(position_list)), LAMP_OFF)
		var beam: = SpotLight3D.new()
		beam.spot_range = 150.0
		beam.spot_angle = 38.0

		beam.spot_attenuation = 0.6
		beam.light_energy = HEADLIGHT_ENERGY
		beam.light_color = Color(1.0, 0.96, 0.86)
		Graphics.lamp_shadow(beam, _headlamps.is_empty())
		beam.visible = false
		body.add_child(beam)
		beam.position = v(position_list) + Vector3(0, 0, - float(Config.Truck.HeadlightLead))
		beam.rotation_degrees.x = -6.0
		var glare: = VehicleLook.flare(body, v(position_list) + Vector3(0, 0, -0.1), HEAD_GLARE, maxf(size.x, size.y) * 2.2, 1.0)
		_headlamps.append({"mesh": lamp, "beam": beam, "flare": glare})
	for position_list: Array in data.get("tailLights", []):
		var at: = v(position_list)
		var lamp: = add_part("TailLight", Vector3(0.9, 1.4, 0.1), Transform3D(Basis.IDENTITY, at), TAIL_OFF)
		var glare: = VehicleLook.flare(body, at + Vector3(0, 0, 0.1), TAIL_GLARE, 2.2, 1.0)
		glare.rotation.y = PI
		lamp.set_meta("flare", glare)
		_tail_lamps.append(lamp)

		var inboard: = at + Vector3( - signf(at.x) * 0.95, -0.25, 0.04)
		var reverse: = add_part("ReverseLight", Vector3(0.7, 0.5, 0.1), Transform3D(Basis.IDENTITY, inboard), REVERSE_ON)
		reverse.visible = false
		var reverse_glare: = VehicleLook.flare(body, inboard + Vector3(0, 0, 0.1), HEAD_GLARE, 1.6, 1.0)
		reverse_glare.rotation.y = PI
		_reverse_lamps.append({"mesh": reverse, "flare": reverse_glare})
	var bar: = table(data.get("arrowBar"))
	if not bar.is_empty():

		var xs: Array = (bar["xs"] as Array).duplicate()
		xs.sort()
		for x: float in xs:
			var at: = Vector3(x, float(bar["y"]), float(bar["z"]) + 0.02)
			var block: = add_part("ArrowBlock", Vector3(float(bar["size"][0]), float(bar["size"][1]), 0.04), Transform3D(Basis.IDENTITY, at), AMBER_OFF)
			var glare: = VehicleLook.flare(body, at + Vector3(0, 0, 0.1), AMBER_ON, 1.4, 1.0)
			glare.rotation.y = PI
			_arrow_blocks.append({"mesh": block, "flare": glare, "lit": false})
	var blue_lamps: Array = data.get("blueLamps", []).duplicate()
	blue_lamps.append_array(spec.get("blueLamps", []))
	for info: Dictionary in blue_lamps:
		var size: = v(info["size"])
		var at: = v(info["pos"])
		var colour: = VehicleLook.lamp_colour(info)
		var beacon: = VehicleLook.beacon(body, at, size, colour)
		var light: = OmniLight3D.new()
		light.light_color = VehicleLook.LAMP_COLOURS[colour]["light"]
		light.omni_range = 46.0 if size.z > 0.15 else 26.0
		light.light_energy = 6.0 if size.z > 0.15 else 3.0
		light.visible = false
		body.add_child(light)
		light.position = at + Vector3(0, 0.6, 0)
		var glare: = VehicleLook.flare(body, at, VehicleLook.LAMP_COLOURS[colour]["glare"], 4.5 if size.z > 0.15 else 2.6)
		_blue.append({"beacon": beacon, "light": light, "phase": int(info["phase"]), "on": false, "flare": glare})


func _build_wheels() -> void :
	for info: Dictionary in data["wheels"]:
		var pieces: Array = objects.get(info["object"], [])

		var drawn_at: = Vector3(info["x"], data["axleY"], 0)
		for side in [-1.0, 1.0]:
			var hub: = Node3D.new()
			hub.name = "Wheel"
			add_child(hub)
			hub.position = Vector3( - side * info["x"], data["axleY"], info["z"])
			var spinner: = Node3D.new()
			hub.add_child(spinner)
			if side > 0:
				hub.rotation.y = PI
			for mesh: MeshInstance3D in pieces:
				var copy: = mesh.duplicate() as MeshInstance3D
				spinner.add_child(copy)
				copy.position = mesh.position - drawn_at
			wheels.append({"hub": hub, "spinner": spinner, "steers": info.get("steers", false), "flipped": side > 0})


func _build_seats() -> void :
	var places: Array = [data["seats"]["driver"]]
	places.append_array(data["seats"]["passengers"])
	for place: Array in places:
		var seat: = Node3D.new()
		seat.name = "Seat"
		body.add_child(seat)

		seat.position = Vector3(place[0], place[1] - 0.5, place[2])
		seat.rotation.y = deg_to_rad(place[3])
		if spec.has("eyeHeight"):

			seat.set_meta("lift", clampf(float(spec["eyeHeight"]) - seat.position.y - FirefighterRig.SEATED_EYE, 0.0, 1.4))
		seats.append(seat)
		riders.append(null)
	if _steering_wheel and not seats.is_empty():
		seats[0].set_meta("wheel", _steering_wheel)




func _build_couplings() -> void :
	if data.has("outlets"):
		for index in data["outlets"].size():
			var at: = v(data["outlets"][index])
			var turn: = Basis.IDENTITY if absf(at.x) < 0.5 else Basis(Vector3.UP, signf(at.x) * PI / 2.0)
			var part: = _coupling_model("Outlet", "Truck outlet", Transform3D(turn, at))
			var holder: = Node3D.new()
			body.add_child(holder)
			holder.position = at
			outlets.append({"node": holder, "mesh": part, "index": index + 1})
	if data.has("intake"):
		var at: = v(data["intake"])
		var part: = _coupling_model("Intake", "Truck intake", Transform3D(Basis.IDENTITY, at))
		var holder: = Node3D.new()
		body.add_child(holder)
		holder.position = at
		intake = {"node": holder, "mesh": part}


func _coupling_model(part_name: String, model: String, place: Transform3D) -> MeshInstance3D:
	var mesh: = MeshInstance3D.new()
	mesh.name = part_name
	mesh.mesh = ToolModels.of(model)["body"]
	body.add_child(mesh)
	mesh.transform = place
	return mesh


func _build_sounds() -> void :
	var bar: = Node3D.new()
	add_child(bar)
	bar.position = Vector3(0, data["top"], data["front"] + 1.5)
	_siren_player = Sounds.emitter(bar, null, float(Config.Siren.Volume), 40.0, 500.0)
	_horn_player = Sounds.emitter(bar, Assets.sound(spec.get("horn", "horn")), 1.0, 40.0, 400.0)
	var step: = Node3D.new()
	add_child(step)
	step.position = Vector3(0, -1.3, data["rear"] + 0.6)

	var beeps: bool = drive.profile.get("reverseBeep", true)
	_beeper = Sounds.emitter(step, Sounds.loop("reverse_beep") if beeps else null, float(Config.Truck.ReverseBeepVolume), 15.0, 250.0)
	engine = EngineAudio.new()
	add_child(engine)
	engine.position = Vector3(0, 2, data["front"])
	engine.setup(drive.profile)





func _build_exhaust() -> void :
	var foot: = float(data["axleY"]) - float(data["wheelRadius"])
	var pipe: = Node3D.new()
	pipe.name = "Exhaust"
	body.add_child(pipe)
	var big: = float(data["wheelRadius"]) > 1.8
	if big:
		pipe.position = Vector3(float(data["halfWidth"]) - 0.9, foot + 1.1, rear_axle - 3.6)
		pipe.basis = Basis.looking_at(Vector3(1, -0.35, 0).normalized())
	else:
		pipe.position = Vector3(1.6, foot + 1.0, float(data["rear"]) - 0.2)
		pipe.basis = Basis.looking_at(Vector3(0, -0.15, 1).normalized())
	_exhaust = RbxEmitter.make(pipe, {
		"Enabled": false, 
		"Texture": Config.Hose.MistTexture, 
		"Color": Color(0.36, 0.36, 0.38), 
		"LightInfluence": 1, 
		"Rate": 4, 
		"MaxRate": 30, 
		"Speed": [3, 6], 
		"Lifetime": [1.0, 1.8], 
		"SpreadAngle": 18, 
		"Acceleration": Vector3(0, 2.2, 0), 
		"Drag": 2.5, 
		"Rotation": [0, 360], 
		"Size": [[0, 0.4], [1, 3.2 if big else 2.2]], 
		"Transparency": [[0, 0.4], [0.3, 0.7], [1, 1]], 
		"Direction": Vector3.FORWARD, 
	})
	var dash: = table(data.get("dash"))
	if not dash.is_empty():
		_dash_light = OmniLight3D.new()
		_dash_light.name = "DashLight"
		_dash_light.light_color = Color(0.55, 0.8, 1.0)
		_dash_light.light_energy = 0.5
		_dash_light.omni_range = 3.2
		_dash_light.shadow_enabled = false
		_dash_light.visible = false
		body.add_child(_dash_light)
		_dash_light.position = v(dash["pos"]) + Vector3(0, 0.5, 1.0)


func _update_exhaust() -> void :
	var driven: = driver() != null and fuel > 0.0
	if driven != _was_driven:
		_was_driven = driven
		_exhaust.emitting = driven
		if driven:

			_exhaust.set_rate(30.0)
	if driven:
		var pulling: = clampf(drive.throttle, 0.0, 1.0) * (1.0 - clampf(absf(forward_speed) / 60.0, 0.0, 0.6))
		var rate: = lerpf(4.0, 30.0, pulling)
		_exhaust.set_rate(lerpf(_exhaust._rate, rate, 0.2))
	if _dash_light:
		_dash_light.visible = headlights_on and driven





func driver() -> Player:

	if riders[0] != null and not is_instance_valid(riders[0]):
		riders[0] = null
	return riders[0]




func _board_at(player: Player, door_name: String) -> void :
	if player.seat != null:
		return


	if player.get_attr("Scba", false) == true and AirService.current:
		if player.brain != null:
			AirService.current.return_worn(player)
		else:
			AirService.current.seated(player)
	if doors[door_name]["open"]:
		_board(player, door_name)
		return
	set_door(door_name, true)
	get_tree().create_timer(float(Config.Boarding.OpenTime), false).timeout.connect( func() -> void :
		if is_instance_valid(player) and player.seat == null:
			_board(player, door_name)
	)


func _board(player: Player, door_name: String) -> void :
	if player.seat != null:
		return
	var index: = -1
	if door_name == "DoorCabLeft":
		index = 0 if riders[0] == null else -1
	if index < 0:

		var doorway: Vector3 = doors[door_name]["doorway"]
		var best: = INF
		for seat_index in range(1, seats.size()):
			var distance: = seats[seat_index].position.distance_to(doorway)
			if riders[seat_index] == null and distance < best:
				best = distance
				index = seat_index
	if index < 0:
		return
	riders[index] = player
	player.sit(seats[index])
	player.set_attr("Vehicle", self)
	player.set_attr("Seat", index)
	set_door(door_name, false)
	if index == 0:

		drive.speed = forward_speed
		drive.reverse = forward_speed < -0.5
		drive.gear = 1
		drive.steer = 0.0
		drive.throttle = 0.0
		drive.brake = 0.0
		driver_changed.emit(player)
	if player.is_local:
		player.camera.subject = self
		player.camera.subject_height = float(data["top"]) * 0.75
		player.camera.subject_distance = 16.0
		player.camera.yaw = global_rotation.y


func leave(player: Player) -> void :
	var index: = riders.find(player)
	if index < 0:
		return
	riders[index] = null

	var seat_at: = seats[index].position
	var best_door: = ""
	var best: = INF
	for door_name: String in doors:
		var distance: float = doors[door_name]["doorway"].distance_to(seat_at)
		if distance < best:
			best = distance
			best_door = door_name
	var out: Vector3 = global_transform * (doors[best_door]["doorway"] + Vector3(signf(doors[best_door]["doorway"].x) * 1.5, 0, 0))
	var ground: = Game.world.raycast(out + Vector3(0, 3, 0), out + Vector3(0, -12, 0), World.LAYER_SOLID)
	if not ground.is_empty():
		out = ground["position"]
	player.leave_seat(out + Vector3(0, 0.1, 0))
	player.set_attr("Vehicle", null)
	player.set_attr("Seat", null)
	if player.is_local:
		player.camera.subject = null
	if index == 0:
		driver_changed.emit(null)







func is_mine() -> bool:
	var who: = driver()
	if who != null and who.brain != null:
		return Net.is_host()
	return who.is_local if who != null else Net.is_host()



func net_motion() -> Array:
	return [global_transform, linear_velocity, angular_velocity, drive.speed, drive.steer, drive.rpm, drive.gear, drive.reverse, drive.throttle, drive.brake]


func net_apply_motion(motion: Array) -> void :
	if is_mine():
		return
	_net_place = motion[0]
	_net_linear = motion[1]
	_net_angular = motion[2]
	drive.speed = motion[3]
	drive.steer = motion[4]
	drive.rpm = motion[5]
	drive.gear = motion[6]
	drive.reverse = motion[7]
	drive.throttle = motion[8]
	drive.brake = motion[9]
	_net_fresh = true



func net_flags() -> Array:
	var open_doors: Array = []
	for door_name: String in doors:
		if doors[door_name]["open"]:
			open_doors.append(door_name)
	var open_shutters: Array = []
	for shutter_name: String in shutters:
		if shutters[shutter_name]["open"]:
			open_shutters.append(shutter_name)
	var seated: Array = []
	for rider: Variant in riders:
		seated.append(Net.peer_of(rider) if rider != null else 0)
	return [headlights_on, blue_on, siren, locked, snappedf(water, 1.0), snappedf(fuel, 0.1), open_doors, open_shutters, seated, freeze, arrows]


func net_apply_flags(flags: Array) -> void :
	headlights_on = flags[0]
	blue_on = flags[1]
	siren = flags[2]
	locked = flags[3]
	water = flags[4]
	fuel = flags[5]
	for door_name: String in doors:
		set_door(door_name, door_name in flags[6])
	for shutter_name: String in shutters:
		set_shutter(shutter_name, shutter_name in flags[7])
	var before: = driver()
	for index in mini(riders.size(), flags[8].size()):
		riders[index] = Net.player_of(flags[8][index]) if flags[8][index] != 0 else null
	if driver() != before:
		driver_changed.emit(driver())
	freeze = flags[9]
	if flags.size() > 10:
		arrows = flags[10]



func driver_key(player: Player, what: String) -> void :
	if what == "exit" or what == "exit_held":

		if what == "exit" and not slow_enough_to_leave():
			Game.notify(Text.f("hud.truck.exitHold", [Controls.key_name("veh_exit")]), "warning", player)
			return
		leave(player)
		return
	if player != driver():
		return
	match what:
		"headlights":
			headlights_on = not headlights_on
		"blue":
			blue_on = not blue_on
		"siren_next":

			var patterns: Array = Config.Siren.Patterns
			siren = siren % patterns.size() + 1
			blue_on = true
		"siren_off":
			siren = 0
		"arrows":

			arrows = (arrows + 1) % 3 if not _arrow_blocks.is_empty() else 0
		"horn":
			sound_horn()
			Net.broadcast("vehicle.horn", [String(get_path())])



func slow_enough_to_leave() -> bool:
	return absf(forward_speed) * float(Config.Hud.MetresPerStud) * 3.6 <= float(Config.Boarding.ExitSpeed)


func sound_horn() -> void :
	if _horn_player.stream:
		_horn_player.play()
	horn.emit()


func _ask(what: String) -> void :
	Net.request("vehicle.key", [String(get_path()), what])




func cab_command(what: String) -> void :
	match what:
		"mast":
			Net.request("truck.mast", [String(get_path())])
		"exit":
			if slow_enough_to_leave():
				_ask("exit")
			else:
				Game.notify(Text.f("hud.truck.exitHold", [Controls.key_name("veh_exit")]), "warning", Game.local_player)
		_:
			_ask(what)


var _drift: = 0.0
var debug_drive: Variant = null
var _net_place: = Transform3D.IDENTITY
var _net_linear: = Vector3.ZERO
var _net_angular: = Vector3.ZERO
var _net_fresh: = false


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void :
	if not is_mine():

		forward_speed = ( - state.transform.basis.z).dot(state.linear_velocity)
		if _net_fresh:
			_net_fresh = false
			var here: = state.transform
			var off: = here.origin.distance_to(_net_place.origin)
			if off > 8.0:
				state.transform = _net_place
			else:
				state.transform = here.interpolate_with(_net_place, 0.35)
			state.linear_velocity = _net_linear
			state.angular_velocity = _net_angular
		return
	var dt: = state.step
	var place: = state.transform
	var forward: = - place.basis.z
	var actual: = forward.dot(state.linear_velocity)
	forward_speed = actual
	var who: = driver()
	var input: = {
		"wheelbase": wheelbase, "actual": actual, "slope": forward.y, 
		"fill": water / capacity if capacity > 0.0 else 1.0, 
		"park": who == null or locked, 
	}
	if fuel <= 0.0:
		input["limit"] = float(Config.Truck.Fuel.CrawlSpeed)
	if who != null:
		_check_impact(actual)
	if who != null and who.is_local and not Game.ui_open and not locked:
		input["drive"] = Input.get_axis("move_back", "move_forward")
		input["steer"] = _steer_input(Input.get_axis("move_left", "move_right"), dt)
		if debug_drive != null:
			input["drive"] = float(debug_drive)

		if HoseService.current and HoseService.current.tethered(self):
			if absf(float(input["drive"])) > 0.1:
				Game.tell(who, Text.m("hud.truck.hosed"))
			input["drive"] = 0.0
			input["park"] = true
	elif who != null and who.brain != null and not locked:
		input["drive"] = who.brain.drive_input
		input["steer"] = who.brain.steer_input



	var space: = state.get_space_state()
	var foot: float = float(data["axleY"]) - float(data["wheelRadius"])
	var front: = rear_axle - wheelbase
	var grounds: Array[Vector3] = []
	var hard: = 0
	for corner: Vector3 in [Vector3( - track, 0, front), Vector3(track, 0, front), Vector3( - track, 0, rear_axle), Vector3(track, 0, rear_axle)]:
		var from: Vector3 = place * (corner + Vector3(0, foot + ABOVE, 0))
		var query: = PhysicsRayQueryParameters3D.create(from, from + Vector3(0, - (ABOVE + BELOW), 0), World.LAYER_SOLID, [get_rid()])
		var hit: = space.intersect_ray(query)
		if hit.is_empty():
			break
		grounds.append(hit["position"])
		var row: = Game.world.row_hit(hit) if Game.world else -1
		if row < 0 or Game.store.material(row) in World.FAR_HARD:
			hard += 1



	var winter: Dictionary = Config.Drive.get("Winter", {})
	var slide: = 1.0
	if Style.winter() and not winter.is_empty():
		if hard >= 2 or grounds.size() < 4:
			var depth: = RoadSnow.current.depth_at(place.origin) if RoadSnow.current else 1.0
			input["grip"] = lerpf(float(winter.get("PlowedGrip", winter["RoadGrip"])), float(winter["RoadGrip"]), depth)
			slide = depth
		else:
			input["limit"] = minf(float(input.get("limit", INF)), float(winter["SnowSpeed"]))
			input["pull"] = float(winter["SnowPull"])
			input["drag"] = float(winter["SnowDrag"])
	drive.step(input, minf(dt, 0.1))
	var motion: = drive.motion(wheelbase, rear_axle)
	if Style.winter() and not winter.is_empty() and input.has("grip"):
		_drift += motion[2] * absf(drive.speed) * float(winter["Drift"]) * lerpf(0.2, 1.0, slide) * dt
		_drift *= exp( - dt * float(winter["DriftDecay"]))
	else:
		_drift = move_toward(_drift, 0.0, dt * 40.0)
	var normal: = Vector3.UP
	var velocity: Vector3 = place.basis * Vector3(motion[1] + _drift, 0, - motion[0])
	if grounds.size() == 4:
		var across: = (grounds[3] - grounds[0]).cross(grounds[2] - grounds[1])
		if across.length() > 0.001:
			normal = across.normalized()
			if normal.y < 0.0:
				normal = - normal

		var ground: = (grounds[0] + grounds[1] + grounds[2] + grounds[3]) / 4.0
		var centre: Vector3 = place * Vector3(0, foot, (front + rear_axle) / 2.0)
		var lift: = (ground - centre).dot(normal)
		velocity += normal * clampf(lift * 14.0, -30.0, 30.0)
	else:

		velocity.y = state.linear_velocity.y - 196.2 * dt
	state.linear_velocity = velocity

	var turn: = place.basis.y.cross(normal) * LEVEL_RATE
	if turn.length() > LEVEL_MOST:
		turn = turn.normalized() * LEVEL_MOST
	state.angular_velocity = turn + place.basis.y * motion[2]


	if who != null:
		var settings: Dictionary = Config.Truck.Fuel
		fuel = maxf(0.0, fuel - (absf(actual) * float(settings["PerStud"]) * float(spec.get("fuelUse", 1.0)) + float(settings["Idle"])) * dt)



func _steer_input(raw: float, dt: float) -> float:
	if raw == 0.0 or signf(raw) != _steer_way:
		_steer_held = 0.0
		_steer_way = signf(raw)
	else:
		_steer_held += dt
	return VehicleDrive.steer_curve(raw, _steer_held, drive.speed, drive.profile)







func _check_impact(actual: float) -> void :
	var settings: Dictionary = Config.Drive
	var lost: = (drive.speed - actual) * signf(drive.speed)
	if absf(drive.speed) < float(settings["ImpactLoss"]) or lost < float(settings["ImpactLoss"]):
		return
	if Game.now() - _impact_at < float(settings["ImpactGap"]):
		return
	_impact_at = Game.now()
	var kmh: = lost * float(Config.Hud.MetresPerStud) * 3.6

	drive.speed = actual - signf(drive.speed) * minf(lost * float(settings["Bounce"]), float(settings["BounceMost"]))
	thud(kmh)
	Net.request("vehicle.impact", [String(get_path()), kmh])


var _squeal: AudioStreamPlayer3D
var _squeal_level: = 0.0



func _update_squeal(delta: float) -> void :
	var settings: Dictionary = Config.Drive
	var from: = float(settings["SquealFrom"])
	var wanted: = 0.0
	if absf(forward_speed) > float(settings["SquealSpeed"]):
		wanted = clampf((drive.grip_use - from) / maxf(1.0 - from, 0.01), 0.0, 1.0)
	_squeal_level += (wanted - _squeal_level) * minf(1.0, delta * 8.0)
	if _squeal == null:
		if _squeal_level < 0.02:
			return
		_squeal = Sounds.emitter(self, Sounds.loop("tyre_squeal"), 1.0, 14.0, 140.0)
	if _squeal_level < 0.02:
		if _squeal.playing:
			_squeal.stop()
		return
	_squeal.volume_db = linear_to_db(_squeal_level * float(settings["SquealVolume"]))
	_squeal.pitch_scale = 0.9 + 0.2 * _squeal_level
	if not _squeal.playing:
		_squeal.play()



func thud(kmh: float) -> void :
	var settings: Dictionary = Config.Drive
	var share: = clampf(kmh / float(settings["ThudFull"]), 0.15, 1.0)
	Sounds.once(self, "vehicle_thud", share * float(settings["ThudVolume"]), 14.0, 160.0, lerpf(1.15, 0.8, share))
	var local: = Game.local_player
	if local != null and local.camera != null and local.get_attr("Vehicle") == self:
		local.camera.jolt(share * float(settings["Shake"]))


func _process(delta: float) -> void :
	var who: = driver()
	var local: = Game.local_player
	var inside: bool = local != null and local.get_attr("Vehicle") == self
	if who == null or ( not who.is_local and who.brain == null):

		if who != null:
			drive.observe(forward_speed, angular_velocity.y, wheelbase, delta)
	engine.update(drive, who != null, inside, delta)


	_spin = fmod(_spin - forward_speed / float(data["wheelRadius"]) * delta, TAU)
	for wheel: Dictionary in wheels:
		wheel["spinner"].rotation.x = - _spin if wheel["flipped"] else _spin
		if wheel["steers"]:
			wheel["hub"].rotation.y = (PI if wheel["flipped"] else 0.0) - drive.steer
	if _steering_wheel:
		_steering_wheel.rotation.z = - drive.steer * 9.0


	var motion: = drive.motion(wheelbase, rear_axle)
	var rock: float = drive.profile["lean"] * drive.profile.get("bodyLean", 1.0)
	var ease: = minf(1.0, delta * 5.0)
	_roll += (clampf( - motion[0] * motion[2] * BODY_ROLL, - BODY_MOST, BODY_MOST) * rock - _roll) * ease
	_pitch += (clampf(drive.accel * BODY_PITCH, - BODY_MOST, BODY_MOST) * rock - _pitch) * ease
	var height: float = data["axleY"]
	body.transform = Transform3D(Basis.IDENTITY, Vector3(0, height, 0)) * Rbx.angles(_pitch, 0, _roll) * Transform3D(Basis.IDENTITY, Vector3(0, - height, 0))

	_update_lights()
	_update_exhaust()
	_update_siren(delta)
	_update_squeal(delta)
	if _beeper.stream:
		var backing: = drive.reverse and absf(forward_speed) > 0.5
		if backing != _beeper.playing:
			if backing:
				_beeper.play()
			else:
				_beeper.stop()
	if who != null and who.is_local and not Game.ui_open:
		_driver_keys()

	if inside and not Game.ui_open:
		_exit_key()
	else:
		_exit_down = -1.0




func _exit_key() -> void :
	if Input.is_action_just_pressed("veh_exit"):
		if slow_enough_to_leave():
			_ask("exit")
			return
		_exit_down = Game.now()
	if _exit_down < 0.0:
		return
	if not Input.is_action_pressed("veh_exit"):
		_exit_down = -1.0
		_ask("exit")
	elif Game.now() - _exit_down >= float(Config.Boarding.ExitHold):
		_exit_down = -1.0
		_ask("exit_held")


func _driver_keys() -> void :
	if Input.is_action_just_pressed("veh_headlights"):
		_ask("headlights")
	if Input.is_action_just_pressed("veh_blue"):
		_ask("blue")
	if Input.is_action_just_pressed("veh_siren"):
		_siren_down = Game.now()
	if _siren_down >= 0.0:
		if Input.is_action_just_released("veh_siren"):
			_ask("siren_next")
			_siren_down = -1.0
		elif Game.now() - _siren_down > SIREN_HOLD:
			_ask("siren_off")
			_siren_down = -1.0
	if Input.is_action_just_pressed("veh_horn"):
		_ask("horn")
	if Input.is_action_just_pressed("veh_arrows") and not _arrow_blocks.is_empty():
		_ask("arrows")


func _update_lights() -> void :
	var glare: = VehicleLook.glare_now()


	var day: = Sky3D.current.daylight() if Sky3D.current else 0.0
	var thrown: = lerpf(1.0, float(Config.Art.HeadlightsByDay), day)
	for lamp: Dictionary in _headlamps:
		var beam: SpotLight3D = lamp["beam"]
		beam.light_energy = HEADLIGHT_ENERGY * thrown
		var beamed: = headlights_on and thrown > 0.01
		if beam.visible != beamed:
			beam.visible = beamed
		var material: StandardMaterial3D = lamp["mesh"].material_override
		if material.emission_enabled != headlights_on:
			material.albedo_color = LAMP_ON if headlights_on else LAMP_OFF
			material.emission_enabled = headlights_on
			material.emission = LAMP_ON
			material.emission_energy_multiplier = 3.0
		VehicleLook.shine(lamp["flare"], glare * 0.8 if headlights_on else 0.0)

	var braking: = drive.brake > 0.1 and driver() != null
	var tail: = braking or headlights_on
	for lamp: MeshInstance3D in _tail_lamps:
		var material: StandardMaterial3D = lamp.material_override
		material.albedo_color = TAIL_ON if tail else TAIL_OFF
		material.emission_enabled = tail
		material.emission = TAIL_ON
		material.emission_energy_multiplier = 2.5 if braking else 0.8
		VehicleLook.shine(lamp.get_meta("flare"), glare * (0.7 if braking else 0.3) if tail else 0.0)
	var reversing: = drive.reverse and driver() != null
	if reversing != _reversing:
		_reversing = reversing
		for lamp: Dictionary in _reverse_lamps:
			var material: StandardMaterial3D = lamp["mesh"].material_override
			lamp["mesh"].visible = reversing
			material.emission_enabled = true
			material.emission = REVERSE_ON
			material.emission_energy_multiplier = 2.0
	for lamp: Dictionary in _reverse_lamps:
		VehicleLook.shine(lamp["flare"], glare * 0.5 if reversing else 0.0)
	var now: = Game.now()
	_update_arrows(now, glare)
	for lamp: Dictionary in _blue:
		var on: = blue_on and blue_lit(lamp["phase"], now)
		if on != lamp["on"]:
			lamp["on"] = on
			lamp["light"].visible = on
			VehicleLook.beacon_lit(lamp["beacon"], on)
		VehicleLook.shine(lamp["flare"], (0.55 + 0.45 * glare) if on else 0.0)




func _update_arrows(now: float, glare: float) -> void :
	if _arrow_blocks.is_empty():
		return
	var count: = _arrow_blocks.size()
	var run: = fmod(now, ARROW_STEP * count + ARROW_HOLD + ARROW_STEP * 2.0)
	var reached: = int(run / ARROW_STEP) + 1
	for index in count:
		var block: Dictionary = _arrow_blocks[index]
		var from_start: = (count - 1 - index) if arrows == 1 else index
		var lit: = arrows != 0 and from_start < reached and run < ARROW_STEP * count + ARROW_HOLD
		if lit != block["lit"]:
			block["lit"] = lit
			var mesh: MeshInstance3D = block["mesh"]
			var material: StandardMaterial3D = mesh.material_override
			material.albedo_color = AMBER_ON if lit else AMBER_OFF
			material.emission_enabled = lit
			material.emission = AMBER_ON
			material.emission_energy_multiplier = 6.0
		VehicleLook.shine(block["flare"], (0.4 + 0.5 * glare) if block["lit"] else 0.0)



func has_arrows() -> bool:
	return not _arrow_blocks.is_empty()



static func blue_lit(phase: int, now: float) -> bool:
	var settings: Dictionary = Config.BlueLights
	var flash: float = settings["Flash"]
	var burst: float = flash * 2.0 * float(settings["Flashes"])
	var turn: float = burst + float(settings["Pause"])
	var within: = fmod(now, turn * 3.0)
	var whose: = int(within / turn)
	within = fmod(within, turn)
	return (whose == 2 or whose == phase) and within < burst and fmod(within, flash * 2.0) < flash


func _update_siren(_delta: float) -> void :
	var patterns: Array = Config.Siren.Patterns
	if siren == 0:
		if _siren_player.playing:
			_siren_player.stop()
		return
	var pattern: Dictionary = patterns[siren - 1]
	var stream: = Sounds.loop(pattern["soundId"])
	if _siren_player.stream != stream:
		_siren_player.stream = stream
		_siren_player.play()
	elif not _siren_player.playing:
		_siren_player.play()


func siren_name() -> Variant:
	if siren == 0:
		return Text.m("hud.truck.sirenOff")
	return Text.named("sirens", Config.Siren.Patterns[siren - 1]["name"])






func draw_water(litres: float) -> float:
	var taken: = minf(water, litres)
	if taken > 0.0:
		water -= taken
		water_changed.emit()
	return taken


func fill_water(litres: float) -> float:
	var added: = minf(capacity - water, litres)
	if added > 0.0:
		water += added
		water_changed.emit()
	return added
