extends RefCounted



static func start(main: Node) -> void :
	var snow: = RoadSnow.new()
	snow.name = "RoadSnow"
	main.add_child(snow)
