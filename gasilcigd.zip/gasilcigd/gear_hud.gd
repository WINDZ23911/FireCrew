class_name GearHud
extends Control




const SIZE: = 200.0
const SWEEP: = 270.0
const GAP: = 8.0
const MASK_HEIGHT: = 44.0
const SEAL_TIME: = 0.35

const SMOKE_SHADER: = "\nshader_type canvas_item;\nuniform sampler2D screen : hint_screen_texture, filter_linear_mipmap;\nuniform float shown = 0.0;\nvoid fragment() {\n\t// A choking blur: soft, dull and grey, thicker the more smoke is being breathed.\n\tvec3 seen = textureLod(screen, SCREEN_UV, shown * 4.0).rgb;\n\tfloat grey = dot(seen, vec3(0.299, 0.587, 0.114));\n\tseen = mix(seen, vec3(grey), 0.6 * shown);\n\tseen = max(seen - vec3(0.2 * shown), vec3(0.0));\n\tCOLOR = vec4(mix(seen, vec3(0.149, 0.149, 0.157), 0.6 * shown), 1.0);\n}\n"













var _panel: Control
var _needle: TextureRect
var _turn_mark: Control
var _reading: Label
var _mask_label: Label
var _mask_icon: TextureRect
var _under: Control
var _fog: ColorRect
var _fog_material: ShaderMaterial
var _mask_frame: Control
var _shown: = 0.0
var _sealed: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


	_under = Control.new()
	_under.name = "SmokeView"
	_under.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_under.mouse_filter = Control.MOUSE_FILTER_IGNORE
	( func() -> void :
		get_parent().add_child(_under)
		get_parent().move_child(_under, 0)
	).call_deferred()
	_fog = ColorRect.new()
	_fog.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fog.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fog_material = ShaderMaterial.new()
	var shader: = Shader.new()
	shader.code = SMOKE_SHADER
	_fog_material.shader = shader
	_fog.material = _fog_material
	_fog.visible = false
	_under.add_child(_fog)


	_mask_frame = Control.new()
	_mask_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mask_frame.visible = false
	_under.add_child(_mask_frame)
	for edge: Array in [
		[Vector2(1, 0.16), Vector2(0, 0), Vector2(0, 0), Vector2(0, 1)], 
		[Vector2(1, 0.22), Vector2(0, 0.78), Vector2(0, 1), Vector2(0, 0)], 
		[Vector2(0.14, 1), Vector2(0, 0), Vector2(0, 0), Vector2(1, 0)], 
		[Vector2(0.14, 1), Vector2(0.86, 0), Vector2(1, 0), Vector2(0, 0)], 
	]:
		var shade: = TextureRect.new()
		var fade: = Gradient.new()
		fade.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
		fade.colors = PackedColorArray([Color(6 / 255.0, 6 / 255.0, 7 / 255.0, 1.0), Color(6 / 255.0, 6 / 255.0, 7 / 255.0, 0.75), Color(6 / 255.0, 6 / 255.0, 7 / 255.0, 0.0)])
		var texture: = GradientTexture2D.new()
		texture.gradient = fade
		texture.width = 64
		texture.height = 64
		texture.fill_from = edge[2]
		texture.fill_to = edge[3]
		shade.texture = texture
		shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		shade.stretch_mode = TextureRect.STRETCH_SCALE
		shade.anchor_left = edge[1].x
		shade.anchor_top = edge[1].y
		shade.anchor_right = edge[1].x + edge[0].x
		shade.anchor_bottom = edge[1].y + edge[0].y
		shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_mask_frame.add_child(shade)


	_panel = Control.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.visible = false
	add_child(_panel)

	_layer("gauge_face")
	_reading = Ui.display("", 22)
	_reading.position = Vector2(SIZE / 2 - 40, SIZE * 0.82 - 13)
	_reading.size = Vector2(80, 26)
	_reading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_panel.add_child(_reading)

	_turn_mark = Control.new()
	_turn_mark.size = Vector2(SIZE, SIZE)
	_turn_mark.pivot_offset = Vector2(SIZE / 2, SIZE / 2)
	_turn_mark.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_turn_mark.visible = false
	_panel.add_child(_turn_mark)
	for part: Array in [[Vector2(8, 27), Color(0, 0, 0, 0.85)], [Vector2(5, 24), Ui.AMBER]]:
		var piece: = ColorRect.new()
		piece.size = part[0]
		piece.position = Vector2(SIZE / 2 - piece.size.x / 2, SIZE * 0.095 + (27 - piece.size.y) / 2)
		piece.color = part[1]
		piece.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_turn_mark.add_child(piece)
	_needle = _layer("gauge_needle")
	_needle.pivot_offset = Vector2(SIZE / 2, SIZE / 2)
	_layer("gauge_glass")

	var plate: = Ui.plate(Vector2(SIZE, MASK_HEIGHT))
	plate.position = Vector2(0, SIZE + GAP)
	_panel.add_child(plate)
	_mask_icon = Ui.icon("mask", 26)
	_mask_icon.position = Vector2(12, 9)
	plate.add_child(_mask_icon)
	_mask_label = Ui.display("", 20)
	_mask_label.position = Vector2(48, 0)
	_mask_label.size = Vector2(SIZE - 96, MASK_HEIGHT)
	_mask_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	plate.add_child(_mask_label)
	var cap: = Ui.action_key("mask")
	cap.position = Vector2(SIZE - 10 - cap.size.x, (MASK_HEIGHT - cap.size.y) / 2)
	plate.add_child(cap)


func _layer(image: String) -> TextureRect:
	var rect: = TextureRect.new()
	rect.texture = Ui.image(image)
	rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	rect.stretch_mode = TextureRect.STRETCH_SCALE
	rect.size = Vector2(SIZE, SIZE)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(rect)
	return rect


func _process(delta: float) -> void :
	var player: = Game.local_player
	if player == null:
		return
	var view: = get_parent_area_size()


	var wearing: bool = player.get_attr("Scba", false) == true and player.seat == null
	_panel.visible = wearing
	if wearing:

		var lift: = 66.0
		var water: Variant = Hud.current.widgets.get("water") if Hud.current else null
		if water is HudWater and water.showing():
			lift += HudWater.HEIGHT + 14
		_panel.position = Vector2(view.x - 28 - SIZE, view.y - lift - (SIZE + GAP + MASK_HEIGHT))
		var capacity: = float(Config.Air.Capacity)
		var bar: = float(player.get_attr("AirBar", 0))
		var mask: bool = player.get_attr("Mask", false) == true
		_needle.rotation_degrees = (bar / capacity - 0.5) * SWEEP
		var turn: = AirService.turnaround(player)
		_turn_mark.visible = turn >= 0.0
		if turn >= 0.0:
			_turn_mark.rotation_degrees = (clampf(turn, 0.0, capacity) / capacity - 0.5) * SWEEP

			var turned: bool = player.get_attr("AirTurned", false) == true
			_turn_mark.modulate.a = (0.45 + 0.55 * absf(sin(Game.now() * 5.0))) if turned else 1.0
		_reading.text = str(int(bar))
		_reading.add_theme_color_override("font_color", Ui.state(Ui.RED if bar <= float(Config.Air.Whistle) else (Ui.AMBER if bar <= capacity / 2 else Ui.TEXT)))
		_mask_label.text = Text.say(Text.m("hud.gear.maskOn" if mask else "hud.gear.maskOff"))
		_mask_icon.modulate = Ui.state(Ui.GREEN if mask else Ui.AMBER)


	var level: = float(player.get_attr("Smoke", 0.0))
	var on_air: bool = player.get_attr("Mask", false) == true and float(player.get_attr("AirBar", 0)) > 0.0 and player.get_attr("AirSwap") != true

	var target: = level * 0.2 if on_air else level
	_shown += (target - _shown) * minf(1.0, delta * 3.0)
	_fog.visible = _shown > 0.01
	_fog_material.set_shader_parameter("shown", _shown)


	var masked: bool = player.get_attr("Mask", false) == true
	_sealed = clampf(_sealed + (delta if masked else - delta) / SEAL_TIME, 0.0, 1.0)
	var open: = (1.0 - _sealed) * (1.0 - _sealed)
	var frame: = Vector2(view.x * (1.0 + 0.5 * open), view.y * (1.0 + 0.6 * open))
	_mask_frame.size = frame
	_mask_frame.position = (view - frame) / 2.0
	_mask_frame.visible = player.camera != null and player.camera.first_person() and _sealed > 0.0
