class_name JobCarry
extends CrewJob








var victim: Victim
var downed: Player


func _init(person: Victim = null) -> void :
	kind = "carry"
	victim = person



static func rescue(player: Player) -> JobCarry:
	var job: = JobCarry.new()
	job.downed = player
	return job


func place() -> Vector3:
	if downed != null:
		return downed.global_position if is_instance_valid(downed) else who.body.global_position
	return victim.position() if victim != null and is_instance_valid(victim.figure) else who.body.global_position


static func free_victims() -> Array[Victim]:
	var found: Array[Victim] = []
	if VictimService.current:
		for person in VictimService.current.victims:

			if person.state == "lying" and person.found and is_instance_valid(person.figure) and is_instance_valid(person.prompt) and person.prompt.enabled:
				found.append(person)
	return found


func _pick() -> Victim:
	if victim != null and victim.state == "lying" and victim.found:
		return victim
	if victim != null and victim.state != "lying":
		return null
	var best: Victim = null
	var best_distance: = INF
	for person in free_victims():
		var taken: Variant = person.get_meta("crew_taken") if person.has_meta("crew_taken") else null
		if taken != null and taken != who:
			continue
		var distance: = person.position().distance_to(who.body.global_position)
		if distance < best_distance:
			best_distance = distance
			best = person
	return best


func run() -> bool:
	if downed != null:
		return await _rescue()
	var people: = VictimService.current
	if people == null:
		return fail("crew.say.nothingThere")
	var person: = _pick()
	if person == null:
		if victim != null and victim.state == "trapped":
			return fail("crew.say.trapped")
		return fail("crew.say.nobodyToCarry")
	victim = person
	person.set_meta("crew_taken", who)
	CrewKit.free_hands(who)
	var held: = who.token()

	if FireService.current != null and FireService.current.smoke_at(person.position() + Vector3(0, 2, 0)) > 0.1:
		if await CrewWater.wear_set(who):
			CrewWater.breathe(who)
		if not on(held):
			return false
	if not await who.go(CrewKit.stand_off(who, person.position(), 2.0), 1.5, 60.0):
		return fail("crew.say.stuck")
	if person.state != "lying":
		return fail("crew.say.nobodyToCarry")
	if not await CrewKit.press_skilled(who, person.prompt):
		return fail("crew.say.cannot") if on(held) else false
	if person.state != "carried" or person.carrier != who.body:
		return fail("crew.say.cannot")
	who.say("crew.say.carrying", [], "info")

	var started: = Game.now()
	while on(held) and person.state == "carried":
		var zone: Variant = AmbulanceService.current.zone_position() if AmbulanceService.current else null
		if zone is Vector3:
			await who.go(zone, 1.0, 60.0)
			if not await who.wait(1.0, held):
				return false
		else:
			var clear: = _clear_spot()
			await who.go(clear, 3.0, 40.0)
			if not await who.wait(2.0, held):
				return false
			if Game.now() - started > 90.0:

				people.put_down(person)
				return fail("crew.say.noAmbulance")
	return person.state == "out"



func _rescue() -> bool:
	if not is_instance_valid(downed) or downed.get_attr("Down") == null:
		return fail("crew.say.nobodyToCarry")
	CrewKit.free_hands(who)
	var held: = who.token()
	if not await who.go(CrewKit.stand_off(who, downed.global_position, 2.0), 1.5, 60.0):
		return fail("crew.say.stuck")
	if downed.get_attr("Down") == null:
		return true
	var offer: = CrewKit.prompt_near(who, downed.global_position + Vector3(0, 1.5, 0), "interact", 6.0)
	if offer == null or not offer.net_id.begins_with("down."):
		return fail("crew.say.cannot")
	if not await CrewKit.press_skilled(who, offer):
		return fail("crew.say.cannot") if on(held) else false
	if DownService.rescuer_of(downed) != who.body:
		return fail("crew.say.cannot")
	who.say("crew.say.carrying", [], "info")
	var started: = Game.now()
	while on(held) and is_instance_valid(downed) and downed.get_attr("Down") != null and DownService.rescuer_of(downed) == who.body:
		await who.go(_clear_spot(), 3.0, 40.0)
		if not await who.wait(1.0, held):
			return false
		if Game.now() - started > 120.0:
			return fail("crew.say.stuck")
	return is_instance_valid(downed) and downed.get_attr("Down") == null



func _clear_spot() -> Vector3:
	var truck: Variant = who.service.home_vehicle(who.commander())
	if truck is Vehicle:
		return who.service.ground(truck.global_transform * Vector3(-8, 0, float(truck.data.get("rearAxle", 7.0)) + 10.0) + Vector3(0, 2, 0))
	return who.body.global_position


func finish(_done: bool) -> void :
	if downed != null:
		if is_instance_valid(downed) and DownService.rescuer_of(downed) == who.body and DownService.current != null:
			DownService.current.drag(downed, who.body)
		return
	if victim != null:
		if victim.has_meta("crew_taken"):
			victim.remove_meta("crew_taken")
		if victim.state == "carried" and victim.carrier == who.body and VictimService.current:
			VictimService.current.put_down(victim)
