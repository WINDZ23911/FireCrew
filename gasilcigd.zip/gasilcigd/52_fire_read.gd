extends RefCounted




static func start(main: Node) -> void :
	var under_hud: = CanvasLayer.new()
	under_hud.name = "SmokeView"
	under_hud.layer = 5
	main.add_child(under_hud)
	under_hud.add_child(SmokeView.new())
	var hud: = Hud.current
	if hud != null:
		hud.add_widget("floor_plan", HudFloorPlan.new())
