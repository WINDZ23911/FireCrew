extends ProofDebug






func _scenario_soul() -> void :
	await _wait(2.0)
	var front: = float(Game.station.front) if Game.station else -50.0
	var spot: = _ground(Vector3(-27.0, 0.0, front + 22.0))
	player.teleport(spot + Vector3(0, 0.2, 6.0))
	await _wait(0.3)
	var rig: = FirefighterRig.new()
	add_child(rig)
	rig.global_position = spot
	rig.rotation.y = PI
	rig.dress_person("Marko", 0.3)
	rig.set_sheet("visor", false)
	await _wait(0.4)
	_check(rig.face.size() == 2 and (rig.face[0].material_override as ShaderMaterial).get_shader_parameter("seed") != null, "the face has its own material and seed")
	var head: = rig.global_position + Vector3(0, FirefighterRig.HEAD_HEIGHT, 0)
	for step in 15:
		if step % 3 == 2:
			_view(rig.global_position + Vector3(-6.0, 3.2, 6.5), rig.global_position + Vector3(0, 2.6, 0), 40.0)
			await _wait(0.9)
			await _snap("body%02d" % step)
		else:
			_view(head + Vector3(-1.2 + 0.5 * sin(step * 0.7), 0.1, 3.0), head + Vector3(0, -0.3, 0), 36.0)
			await _wait(0.9)
			await _snap("face%02d" % step)
	print("soul: fidget '%s', head %s, look %s, mood %d" % [rig._fidget, str(rig._head), str(rig._look), rig.mood])
	_check(rig._head.length() > 0.02 or rig._look.length() > 0.02, "the body looked at the player")
	rig.queue_free()
	var walkers: Array[FirefighterRig] = []
	for index in 3:
		var one: = FirefighterRig.new()
		add_child(one)
		one.global_position = _ground(spot + Vector3((index - 1) * 4.5, 0, 0))
		one.rotation.y = - PI / 2.0
		one.speed = [8.0, 14.0, 22.0][index]
		walkers.append(one)
	await _wait(0.5)
	player.teleport(spot + Vector3(0, 0.2, -12.0))
	for step in 4:
		_view(spot + Vector3(0, 3.0, 15.0), spot + Vector3(0, 2.6, 0), 50.0)
		await _wait(0.12)
		await _snap("walk%d" % step)
	_view(spot + Vector3(14.0, 3.5, 2.0), spot + Vector3(0, 2.6, 0), 45.0)
	await _wait(0.2)
	await _snap("walk_front")
	_done()





func _scenario_soul_town() -> void :
	await _wait(3.0)
	var folk: = Townsfolk.current
	var best: Variant = null
	var nearest: = INF
	if folk != null:
		for id: Variant in folk.bodies:
			var body: Townsfolk.Body = folk.bodies[id]
			if not body.built or body.head_at == Vector3.ZERO or body.alpha < 0.9:
				continue
			var d: float = body.head_at.distance_to(player.global_position)
			if d < nearest:
				nearest = d
				best = body
	_check(best != null, "a townsperson is about")
	if best != null:
		var body: Townsfolk.Body = best


		var head: Vector3 = body.head_at
		var facing: = Vector3( - sin(float(body.yaw)), 0, - cos(float(body.yaw))) if body.yaw != null else Vector3.FORWARD
		var stand: = Vector3(head.x, 0, head.z) + facing * 4.0 + facing.cross(Vector3.UP) * 1.2
		player.teleport(_ground(stand) + Vector3(0, 0.2, 0))
		for step in 4:
			await _wait(0.6)
			head = body.head_at
			_view(head + facing * 2.6 + Vector3(0.4 * sin(step * 1.7), 0.15, 0), head, 32.0)
			await _wait(0.3)
			await _snap("town%d" % step)
		print("soul: townsperson gaze %.2f head_turn %.2f feel %d" % [body.gaze, body.head_turn, body.feel])
	var front: = float(Game.station.front) if Game.station else -50.0
	var spot: = _ground(Vector3(-27.0, 0.0, front + 22.0))
	var rigs: Array[FirefighterRig] = []
	for index in 18:
		var one: = FirefighterRig.new()
		add_child(one)
		one.global_position = _ground(spot + Vector3((index % 6 - 2.5) * 3.0, 0, -3.0 * floorf(index / 6.0)))
		one.dress_person("Oseba %d" % index, 0.2)
		rigs.append(one)
	_view(spot + Vector3(0, 6.0, 22.0), spot + Vector3(0, 2.5, -3.0), 50.0)
	await _wait(1.0)
	for stage in [true, false, true]:
		FirefighterRig.life_on = stage
		await _wait(0.3)
		var process: = 0.0
		for frame in 240:
			await get_tree().process_frame
			process += Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
		print("soul cost: life %s: process %.2f ms a frame with 18 bodies" % ["on" if stage else "off", process / 240.0])
	await _snap("crowd")
	_done()




func _scenario_soul_trees() -> void :
	await _wait(2.0)
	var station: = Vector3(-27.0, 0.0, (float(Game.station.front) if Game.station else -50.0) + 22.0)
	for species: String in TreeKit.SPECIES:
		var best: Variant = null
		var nearest: = INF
		for tree: Dictionary in TreeKit.trees:
			if tree["species"] != species:
				continue
			var d: float = (tree["foot"] as Vector3).distance_to(station)
			if d < nearest:
				nearest = d
				best = tree
		if best == null:
			continue
		var foot: Vector3 = best["foot"]
		var top: float = (best["high"] as Vector3).y
		var middle: = Vector3(foot.x, (foot.y + top) / 2.0, foot.z)
		var toward: = (station - foot) * Vector3(1, 0, 1)
		toward = toward.normalized() if toward.length() > 1.0 else Vector3.FORWARD
		_view(middle + toward * (top - foot.y) * 1.6 + Vector3(0, 2.0, 0), middle, 45.0)
		await _wait(0.4)
		await _snap(species)
	_check(true, "looked")
	_done()




func _scenario_soul_locals() -> void :
	await _wait(3.0)
	var locals: = TownLocals.current
	var station: = Vector3(-27.0, 0.0, (float(Game.station.front) if Game.station else -50.0) + 22.0)
	var picked: Array = []
	if locals != null:
		var spots: Array = locals.spots.filter( func(spot: Variant) -> bool: return not spot.pieces.is_empty())
		spots.sort_custom( func(a: Variant, b: Variant) -> bool: return a.root.origin.distance_to(station) < b.root.origin.distance_to(station))
		picked = spots.slice(0, 3)
	_check( not picked.is_empty(), "locals are about")
	for index in picked.size():
		var spot: Variant = picked[index]
		var root: Transform3D = spot.root
		var head: = root * Vector3(0, 3.2 * float(spot.size), 0)
		player.teleport(_ground(root * Vector3(1.5, 0, -6.0)) + Vector3(0, 0.2, 0))
		for step in 2:
			var side: = -1.5 if step == 0 else 1.5
			_view(root * Vector3(side, 3.4 * float(spot.size), -4.5), head, 32.0)
			await _wait(0.8)
			await _snap("local%d_%d" % [index, step])
	_done()





func _scenario_soul_street() -> void :
	await _wait(3.0)
	var folk: = Townsfolk.current
	_check(folk != null, "townsfolk are about")

	var middle: = Vector3.ZERO
	var count: = 0
	for id: Variant in folk.bodies:
		var body: Townsfolk.Body = folk.bodies[id]
		if body.built and body.head_at != Vector3.ZERO:
			middle += body.head_at
			count += 1
	if count > 0:
		middle /= count
	var nearest: Variant = null
	var gap: = INF
	for id: Variant in folk.bodies:
		var body: Townsfolk.Body = folk.bodies[id]
		if body.built and body.head_at != Vector3.ZERO and body.head_at.distance_to(middle) < gap:
			gap = body.head_at.distance_to(middle)
			nearest = body
	var at: Vector3 = nearest.head_at if nearest != null else middle
	player.teleport(_ground(Vector3(at.x + 2.5, 0, at.z + 2.5)) + Vector3(0, 0.2, 0))
	await _wait(1.0)
	for step in 6:
		var eye: = player.head_position()

		var who: Variant = null
		var near: = INF
		for id: Variant in folk.bodies:
			var body: Townsfolk.Body = folk.bodies[id]
			if body.built and body.head_at != Vector3.ZERO and body.alpha > 0.9:
				var d: = body.head_at.distance_to(eye)
				if d < near:
					near = d
					who = body
		if who == null:
			break

		var facing: = Vector3( - sin(float(who.yaw)), 0, - cos(float(who.yaw))) if who.yaw != null else Vector3.FORWARD
		var stand: = Vector3(who.head_at.x, 0, who.head_at.z) + facing * 4.0 + facing.cross(Vector3.UP) * -1.5
		player.teleport(_ground(stand) + Vector3(0, 0.2, 0))
		await _wait(0.7)
		var head: Vector3 = who.head_at
		_view(head + facing * 6.0 + Vector3(0, 0.6, 0) + facing.cross(Vector3.UP) * 1.0, head - Vector3(0, 0.3, 0), 26.0)
		await _wait(0.2)
		await _snap("street%d" % step)
		print("soul: passer-by %.1f studs off, gaze %.2f head_turn %.2f feel %d" % [near, who.gaze, who.head_turn, who.feel])
		await _wait(0.8)
	_done()
