class_name Breeze
extends Node3D





const FLUTTER_RANGE: = 320.0
const AXES: = {"X": Vector3.RIGHT, "Y": Vector3.UP, "Z": Vector3.BACK}
const FLOCK: = 5
const WING: = Vector3(1.7, 0.08, 0.8)
const WING_COLOR: = Color(40 / 255.0, 40 / 255.0, 44 / 255.0)
const LOOK_EVERY: = 0.5

var _cloths: Array = []
var _near: Array = []
var _flocks: Array = []
var _sky: Node3D
var _since: = LOOK_EVERY


func _ready() -> void :
	var store: = Game.store
	for id: int in store.tagged.get("Flutter", []):
		var row: int = store.row_of.get(id, -1)
		var hinge: Variant = _vector(store.attribute(id, "Hinge"))
		var axis: Variant = AXES.get(store.attribute(id, "Axis", ""))
		if row < 0 or hinge == null or axis == null:
			continue
		var at: = store.position(row)
		_cloths.append({
			"id": id, "base": store.transform(row), "hinge": hinge, "axis": axis, 
			"phase": at.x * 0.13 + at.z * 0.07, 

			"reach": deg_to_rad(24.0) if store.name_at(row) == "Flag" else deg_to_rad(11.0), 
			"node": null, 
			"washing": store.name_at(row) != "Flag", 
		})
	_sky = Node3D.new()
	_sky.name = "Birds"
	add_child(_sky)
	for id: int in store.tagged.get("BirdCircle", []):
		var row: int = store.row_of.get(id, -1)
		if row >= 0:
			_add_flock(store.position(row))
	_sky.visible = not Game.night and not Style.winter()


	Game.night_changed.connect( func(night: bool) -> void : _sky.visible = not night and not Style.winter())

	Style.current.changed.connect( func(_style: int) -> void : _take_in())
	_take_in()


func _take_in() -> void :
	var gone: = Style.winter()
	_sky.visible = not Game.night and not gone
	for cloth: Dictionary in _cloths:
		if not cloth["washing"]:
			continue
		if cloth["node"] != null:
			cloth["node"].visible = not gone
		else:
			Game.world.set_hidden(cloth["id"], gone)
	_since = LOOK_EVERY


static func _vector(value: Variant) -> Variant:
	if value is Vector3:
		return value
	if value is Dictionary and value.has("$v3"):
		return Rbx.v3(value["$v3"])
	return null


func _wing(material: StandardMaterial3D) -> MeshInstance3D:
	var wing: = MeshInstance3D.new()
	wing.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	wing.scale = WING
	wing.material_override = material
	wing.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_sky.add_child(wing)
	return wing


func _add_flock(middle: Vector3) -> void :
	var rng: = RandomNumberGenerator.new()
	rng.seed = int(floorf(middle.x * 7.0 + middle.z * 13.0))
	var material: = StandardMaterial3D.new()
	material.albedo_color = WING_COLOR
	material.roughness = 0.9
	var flock: = {"middle": middle, "birds": []}
	for index in FLOCK:
		flock["birds"].append({
			"left": _wing(material), "right": _wing(material), 
			"radius": rng.randf_range(26.0, 60.0), "height": rng.randf_range(48.0, 80.0), 
			"speed": rng.randf_range(0.22, 0.4) * (1.0 if rng.randf() < 0.5 else -1.0), 
			"phase": rng.randf_range(0.0, TAU), 
		})
	_flocks.append(flock)




func _look(eye: Vector3) -> void :
	_near.clear()
	for cloth: Dictionary in _cloths:
		var base: Transform3D = cloth["base"]
		if base.origin.distance_to(eye) >= FLUTTER_RANGE or (cloth["washing"] and Style.winter()):
			continue
		if cloth["node"] == null:
			cloth["node"] = Game.world.take(cloth["id"], false)
			if cloth["node"] == null:
				continue
		_near.append(cloth)


func _process(delta: float) -> void :
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	_since += delta
	if _since >= LOOK_EVERY:
		_since = 0.0
		_look(camera.global_position)
	var now: = HostClock.now()


	for cloth: Dictionary in _near:
		var phase: float = cloth["phase"]
		var swing: = sin(now * 1.7 + phase) * 0.7 + sin(now * 4.3 + phase * 2.1) * 0.3
		var hinge: Vector3 = cloth["hinge"]
		var base: Transform3D = cloth["base"]
		var node: Node3D = cloth["node"]
		node.global_transform = base * Transform3D(Basis(cloth["axis"], swing * float(cloth["reach"])), hinge) * Transform3D(Basis.IDENTITY, - hinge)

	if Game.night:
		return
	var flap: = sin(now * 9.0)
	for flock: Dictionary in _flocks:
		var middle: Vector3 = flock["middle"]
		for bird: Dictionary in flock["birds"]:
			var speed: float = bird["speed"]
			var angle: float = bird["phase"] + now * speed
			var at: = middle + Vector3(cos(angle) * bird["radius"], bird["height"] + sin(angle * 3.0) * 3.0, sin(angle) * bird["radius"])
			var ahead: = Vector3( - sin(angle), 0, cos(angle)) * (1.0 if speed > 0.0 else -1.0)
			var body: = Rbx.look_at(at, at + ahead)

			var beat: = 0.15 if sin(angle * 2.0) > 0.3 else flap * 0.6
			bird["left"].global_transform = body * Rbx.angles(0, 0, - beat) * Transform3D(Basis.from_scale(WING), Vector3( - WING.x / 2.0, 0, 0))
			bird["right"].global_transform = body * Rbx.angles(0, 0, beat) * Transform3D(Basis.from_scale(WING), Vector3(WING.x / 2.0, 0, 0))
