class_name FirefighterRig
extends Node3D







static var KIT: = "res://assets/models/%s.glb" % str(Edition.data().get("gear_kit", "gear_kit"))
const HEAD_HEIGHT: = 4.86
const CLIMB_CADENCE: = 0.75
const SEATED_DROP: = 1.75
const SEATED_EYE: = HEAD_HEIGHT - SEATED_DROP + 0.2

const JOINTS: = {
	"Hips": Vector3(0, -2.47, 0), 
	"Waist": Vector3(0, -2.25, 0), 
	"Neck": Vector3(0, -0.62, 0), 
	"ShoulderL": Vector3(-1.47, -0.82, 0), "ShoulderR": Vector3(1.47, -0.82, 0), 
	"ElbowL": Vector3(-1.47, -1.56, 0), "ElbowR": Vector3(1.47, -1.56, 0), 
	"WristL": Vector3(-1.47, -2.24, 0), "WristR": Vector3(1.47, -2.24, 0), 
	"HipL": Vector3(-0.5, -2.66, 0), "HipR": Vector3(0.5, -2.66, 0), 
	"KneeL": Vector3(-0.5, -3.58, 0), "KneeR": Vector3(0.5, -3.58, 0), 
	"AnkleL": Vector3(-0.5, -4.5, 0), "AnkleR": Vector3(0.5, -4.5, 0), 
}

const TREE: = {
	"Hips": "", "Waist": "Hips", "Neck": "Waist", 
	"ShoulderL": "Waist", "ElbowL": "ShoulderL", "WristL": "ElbowL", 
	"ShoulderR": "Waist", "ElbowR": "ShoulderR", "WristR": "ElbowR", 
	"HipL": "Hips", "KneeL": "HipL", "AnkleL": "KneeL", 
	"HipR": "Hips", "KneeR": "HipR", "AnkleR": "KneeR", 
}

const CARRIED_BY: = {
	"Head": "Neck", "UpperTorso": "Waist", "LowerTorso": "Hips", 
	"LeftUpperArm": "ShoulderL", "LeftLowerArm": "ElbowL", "LeftHand": "WristL", 
	"RightUpperArm": "ShoulderR", "RightLowerArm": "ElbowR", "RightHand": "WristR", 
	"LeftUpperLeg": "HipL", "LeftLowerLeg": "KneeL", "LeftFoot": "AnkleL", 
	"RightUpperLeg": "HipR", "RightLowerLeg": "KneeR", "RightFoot": "AnkleR", 
}






const FACE_SKIN: = Color8(226, 176, 140)
const FACE_SCALE: = Vector3(1.0, 0.98, 0.88)
const FACE_AT: = Vector3(0, -0.04, 0)
const NOSE_SCALE: = Vector3(0.07, 0.1, 0.06)
const NOSE_AT: = Vector3(0, -0.07, -0.43)


const RANK_STRIPE: = Color8(28, 28, 30)
const RANK_HEIGHT: = 0.22
const RANK_AT: = 0.155
const RANK_GAP: = 0.07
const FACE_SHADER: = "\nshader_type spatial;\n// The face painted on its ball: the game's one cartoon face (shaders/face.gdshaderinc, AR-23), as the\n// townspeople wear it, sized to the hood's opening. `local` is the head's own space (the ball's scale and place\n// undone), so the features are placed in studs from the head's centre, looking down -Z.\nuniform vec4 skin : source_color;\nuniform vec3 scale = vec3(1.0);\nuniform vec3 at = vec3(0.0);\nuniform float size = 0.66;  // the hood's face to a townsperson's head\nuniform int style = 0;\nuniform float seed = 0.0;  // this face's own blinks\nuniform vec2 look = vec2(0.0);  // where the eyes are turned, -1..1 across and up\nuniform int mood = 0;\nvarying vec3 local;\n\n#include \"res://shaders/face.gdshaderinc\"\n\nvoid vertex() {\n\tlocal = VERTEX * scale + at;\n}\n\nvoid fragment() {\n\tvec2 p = local.xy;\n\tvec3 col = cartoon_face_live(vec2(p.x, p.y + 0.02) / size, style, skin.rgb, TIME, seed, look, mood);\n\t// In the shade of the hood's rim toward the edge of the opening.\n\tfloat edge = length((p - vec2(0.0, -0.05)) / vec2(0.37, 0.32));\n\tcol *= mix(1.0, 0.5, smoothstep(0.72, 1.05, edge));\n\tALBEDO = col;\n\tROUGHNESS = 0.62;\n\tSPECULAR = 0.35;\n}\n"
































static var _kit: PackedScene
static var _face_material: ShaderMaterial
static var _nose_material: StandardMaterial3D
static var _ball: SphereMesh
static var _stripe_material: StandardMaterial3D


static var _banded: Array[StandardMaterial3D] = []
static var _bands_glow: = 1.0


static var _helmets: Dictionary = {}
const BANDED: = "FirefighterRigs"

var joints: Dictionary = {}
var pieces: Dictionary = {}
var hand_right: Node3D
var hand_left: Node3D
var head: Node3D
var face: Array[MeshInstance3D] = []
var rank_stripes: Array[MeshInstance3D] = []
var _rank_shown: = -1


var extras: Dictionary = {}



var hands_at: Dictionary = {}

var view_arms: = {"R": false, "L": false}
var _hand_weight: = {"R": 0.0, "L": 0.0}
var _viewing: = false


var speed: = 0.0
var on_floor: = true
var crouch: = 0.0
var hold: = ""
var aim_pitch: = 0.0
var seated: = false
var seat_lift: = 0.0
var seat_stand: = false
var climbing: = false
var lying: = false


var outfit: = {"limbs": true, "jacket": true, "helmet": true, "visor": true}

var pose: = ""

var with_kit: = true
var springs: = true
var every: = 1

var _phase: = 0.0
var _phase_wave: = 0.0


var look_at: Variant = null
var mood: = 0
var mood_until: = 0.0
var _look: = Vector2.ZERO
var _head: = Vector2.ZERO
var _face_seed: = 0.0
var _idle_for: = 0.0
var _fidget: = ""
var _fidget_until: = 0.0
var _next_fidget: = 0.0
var _life_time: = 0.0
var _shown: Dictionary = {}
var _targets: Dictionary = {}
var _base: Dictionary = {}
var _eased: Dictionary = {}


func _ready() -> void :
	if _kit == null:
		_kit = load(KIT)
	var source: = _kit.instantiate()
	for joint_name: String in JOINTS:
		var joint: = Node3D.new()
		joint.name = joint_name
		joints[joint_name] = joint
	for joint_name: String in JOINTS:
		var joint: Node3D = joints[joint_name]
		var parent_name: String = TREE[joint_name]
		if parent_name.is_empty():
			add_child(joint)
			joint.position = JOINTS[joint_name] + Vector3(0, HEAD_HEIGHT, 0)
		else:
			joints[parent_name].add_child(joint)
			joint.position = JOINTS[joint_name] - JOINTS[parent_name]
		_base[joint_name] = joint.position
	for child in source.get_children():
		var mesh: = child as MeshInstance3D
		if mesh == null or mesh.name.begins_with("Marker"):
			continue
		var bits: = String(mesh.name).split("_")
		if bits.size() != 2 or not CARRIED_BY.has(bits[0]):
			continue
		var joint_name: String = CARRIED_BY[bits[0]]
		var at: = mesh.position
		mesh.owner = null
		source.remove_child(mesh)
		joints[joint_name].add_child(mesh)
		mesh.position = at - JOINTS[joint_name]
		mesh.visible = false
		_find_bands(mesh)
		if not pieces.has(bits[1]):
			pieces[bits[1]] = []
		pieces[bits[1]].append(mesh)
	source.free()
	add_to_group(BANDED)
	hand_right = Node3D.new()
	hand_right.name = "HandR"
	hand_right.position = Vector3(0, - ArmReach.FIST, 0)
	joints["WristR"].add_child(hand_right)
	hand_left = Node3D.new()
	hand_left.name = "HandL"
	hand_left.position = Vector3(0, - ArmReach.FIST, 0)
	joints["WristL"].add_child(hand_left)
	head = Node3D.new()
	head.position = - JOINTS["Neck"]
	joints["Neck"].add_child(head)
	_add_face()
	_add_details()
	var player: = _player()
	if player != null:
		player.attribute_changed.connect( func(key: String, _value: Variant) -> void :
			if key == "Saved":
				_show_rank()
		)
	if outfit.has(Civilian.SHEET):
		Civilian.build(self)
	if outfit.has(Civilian.POLICE_SHEET):
		Civilian.build_police(self)
	wear(outfit)




static func _find_bands(mesh: MeshInstance3D) -> void :
	if mesh.mesh == null:
		return
	for surface in mesh.mesh.get_surface_count():
		var material: = mesh.mesh.surface_get_material(surface) as StandardMaterial3D
		if material == null or _banded.has(material) or material.emission_texture == null:
			continue
		if _is_banded(material):
			_banded.append(material)
			material.emission_energy_multiplier = _bands_glow
		elif String(material.resource_name).to_lower().begins_with("helmet") and not _helmets.has(material):
			_helmets[material] = material.emission_energy_multiplier
			material.emission_energy_multiplier = _helmet_glow(material)



static func _is_banded(material: StandardMaterial3D) -> bool:
	var sheet: = String(material.resource_name).to_lower()
	return sheet.begins_with("jacket") or sheet.begins_with("limbs")



static func night_bands(night: float) -> void :
	var settings: Dictionary = Config.Art.Bands
	var glow: = lerpf(float(settings["Day"]), float(settings["Night"]), clampf(night, 0.0, 1.0))
	if is_equal_approx(glow, _bands_glow):
		return
	_bands_glow = glow
	for material in _banded:
		material.emission_energy_multiplier = glow
	for material: StandardMaterial3D in _helmets:
		material.emission_energy_multiplier = _helmet_glow(material)

	var tree: = Engine.get_main_loop() as SceneTree
	if tree == null:
		return
	for rig: Node in tree.get_nodes_in_group(BANDED):
		for sheet: String in (rig as FirefighterRig).pieces:
			for mesh: MeshInstance3D in rig.pieces[sheet]:
				for surface in mesh.get_surface_override_material_count():
					var copy: = mesh.get_surface_override_material(surface) as StandardMaterial3D
					if copy != null and copy.emission_texture != null and _is_banded(copy):
						copy.emission_energy_multiplier = glow * float(copy.get_meta("wear", 1.0))



static func _helmet_glow(material: StandardMaterial3D) -> float:
	var settings: Dictionary = Config.Art.Bands
	var night: = inverse_lerp(float(settings["Day"]), float(settings["Night"]), _bands_glow) if not is_equal_approx(float(settings["Day"]), float(settings["Night"])) else 0.0
	return float(_helmets[material]) * lerpf(0.25, 1.0, clampf(night, 0.0, 1.0))



func wear(sheets: Dictionary) -> void :
	_shown = sheets
	for sheet: String in pieces:
		for mesh: MeshInstance3D in pieces[sheet]:
			mesh.visible = sheets.has(sheet)
	_show_face()
	_show_rank()
	_show_details()


func wearing(sheet: String) -> bool:
	return _shown.has(sheet)



func set_sheet(sheet: String, shown: bool) -> void :
	if shown:
		_shown[sheet] = true
	else:
		_shown.erase(sheet)
	for mesh: MeshInstance3D in pieces.get(sheet, []):
		mesh.visible = shown
	_show_face()
	_show_rank()
	_show_details()



func _add_face() -> void :
	if _ball == null:
		_ball = SphereMesh.new()
		_ball.radius = 0.5
		_ball.height = 1.0
		_ball.radial_segments = 20
		_ball.rings = 10
		var shader: = Shader.new()
		shader.code = FACE_SHADER
		_face_material = ShaderMaterial.new()
		_face_material.shader = shader
		_face_material.set_shader_parameter("skin", FACE_SKIN)
		_face_material.set_shader_parameter("scale", FACE_SCALE)
		_face_material.set_shader_parameter("at", FACE_AT)
		_nose_material = StandardMaterial3D.new()
		_nose_material.albedo_color = FACE_SKIN.darkened(0.03)
		_nose_material.roughness = 0.62
	var own: = _face_material.duplicate() as ShaderMaterial
	_face_seed = randf()
	own.set_shader_parameter("seed", _face_seed)
	own.set_shader_parameter("style", FACE_MAN)
	for part: Array in [["Face", FACE_SCALE, FACE_AT, own], ["Nose", NOSE_SCALE, NOSE_AT, _nose_material]]:
		var mesh: = MeshInstance3D.new()
		mesh.name = part[0]
		mesh.mesh = _ball
		mesh.scale = part[1]
		mesh.position = part[2]
		mesh.material_override = part[3]
		head.add_child(mesh)
		face.append(mesh)




const RADIO: = Color8(34, 36, 40)
const RADIO_LED: = Color8(236, 60, 40)
const CARABINER: = Color8(200, 60, 40)

var _details: Array[MeshInstance3D] = []
static var _radio_material: StandardMaterial3D
static var _led_material: StandardMaterial3D
static var _carabiner_material: StandardMaterial3D




func _add_details() -> void :
	if _radio_material == null:
		_radio_material = StandardMaterial3D.new()
		_radio_material.albedo_color = RADIO
		_radio_material.roughness = 0.55
		_led_material = StandardMaterial3D.new()
		_led_material.albedo_color = RADIO_LED
		_led_material.emission_enabled = true
		_led_material.emission = RADIO_LED
		_led_material.emission_energy_multiplier = 2.0
		_carabiner_material = StandardMaterial3D.new()
		_carabiner_material.albedo_color = CARABINER
		_carabiner_material.roughness = 0.35
		_carabiner_material.metallic = 0.6
	var chest: = _front_of("UpperTorso", "jacket")
	if chest.size.x <= 0.0:
		return
	var waist: Node3D = joints["Waist"]
	var front: = chest.position.z
	var radio: = _box(waist, Vector3(0.2, 0.42, 0.12), RADIO, _radio_material)
	radio.position = Vector3(-0.62, chest.end.y - 0.72, front - 0.06)
	var antenna: = _box(radio, Vector3(0.04, 0.3, 0.04), RADIO, _radio_material)
	antenna.position = Vector3(-0.06, 0.34, 0.0)
	var led: = _box(radio, Vector3(0.05, 0.04, 0.02), RADIO_LED, _led_material)
	led.position = Vector3(0.05, 0.17, -0.065)
	var knob: = _box(radio, Vector3(0.06, 0.03, 0.06), RADIO, _radio_material)
	knob.position = Vector3(0.05, 0.225, 0.0)
	var hips: Node3D = joints["Hips"]
	var belt: = _front_of("LowerTorso", "jacket")
	if belt.size.x > 0.0:
		var ring: = MeshInstance3D.new()
		var torus: = TorusMesh.new()
		torus.inner_radius = 0.07
		torus.outer_radius = 0.11
		torus.rings = 10
		torus.ring_segments = 6
		ring.mesh = torus
		ring.material_override = _carabiner_material
		ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		ring.position = Vector3(0.78, belt.end.y - 0.12, belt.position.z + 0.02)
		ring.rotation = Vector3(0.0, 0.0, 0.3)
		hips.add_child(ring)
		_details.append(ring)
	_show_details()


func _box(parent: Node3D, size: Vector3, color: Color, material: Material) -> MeshInstance3D:
	var box: = BoxMesh.new()
	box.size = size
	var mesh: = MeshInstance3D.new()
	mesh.mesh = box
	mesh.material_override = material
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh)
	_details.append(mesh)
	return mesh



func _show_details() -> void :
	var jacketed: = false
	for sheet: String in _shown:
		jacketed = jacketed or sheet.begins_with("jacket")
	for mesh in _details:
		mesh.visible = jacketed



func _show_face() -> void :
	var hooded: = false
	for sheet: String in _shown:
		hooded = hooded or sheet.begins_with("limbs")
	for mesh in face:
		mesh.visible = hooded





func _show_rank() -> void :
	if head == null:
		return
	var player: = _player()
	var helmeted: = false
	for sheet: String in _shown:
		helmeted = helmeted or sheet.begins_with("helmet")
	var rank: = Alarm.rank_of(int(player.get_attr("Saved", 0))) if player != null and helmeted else 0
	if rank != _rank_shown:
		_rank_shown = rank
		for stripe in rank_stripes:
			stripe.queue_free()
		rank_stripes.clear()
		var widths: Array = Config.Gear.Ranks[rank].get("stripes", [])
		var span: = - RANK_GAP
		for width: float in widths:
			span += width + RANK_GAP
		var x: = - span / 2.0
		for width: float in widths:
			_add_rank_stripe(x + width / 2.0, width)
			x += width + RANK_GAP
	for stripe in rank_stripes:
		stripe.visible = helmeted




func _add_rank_stripe(x: float, width: float) -> void :
	if _stripe_material == null:
		_stripe_material = StandardMaterial3D.new()
		_stripe_material.albedo_color = RANK_STRIPE
		_stripe_material.roughness = 0.5
	var box: = BoxMesh.new()
	box.size = Vector3(width, RANK_HEIGHT, 0.03)
	var stripe: = MeshInstance3D.new()
	stripe.name = "RankStripe"
	stripe.mesh = box
	stripe.material_override = _stripe_material
	stripe.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	stripe.position = Vector3(x, RANK_AT, 0.955 - 0.7 * x * x + 0.02)
	stripe.rotation.y = atan(-1.4 * x)
	head.add_child(stripe)
	rank_stripes.append(stripe)








const NAME_TAPE: = Color8(226, 196, 58)
const NAME_INK: = Color8(24, 24, 26)
const BADGE: = Color8(236, 234, 228)
const BADGE_EDGE: = Color8(176, 40, 36)
const FACE_MAN: = 256
const FACE_MOUSTACHE: = 512
const FACE_BEARD: = 1024
const FACE_SKINS: Array[Color] = [Color8(238, 196, 164), Color8(226, 176, 140), Color8(214, 162, 124), Color8(244, 206, 178), Color8(198, 146, 108)]

var _person: Array[Node3D] = []





func dress_person(called: String, years: float) -> void :
	for made in _person:
		if is_instance_valid(made):
			made.queue_free()
	_person.clear()
	var seed_of: = hash(called.to_lower())
	var roll: = func(what: String, count: int) -> int: return int(rand_from_seed(hash([seed_of, what]))[0]) % count

	var skin: Color = FACE_SKINS[roll.call("skin", FACE_SKINS.size())]
	var own_face: = _face_material.duplicate() as ShaderMaterial
	own_face.set_shader_parameter("skin", skin)

	var style: int = (roll.call("face", 32) & ~ 8) | FACE_MAN | (roll.call("iris", 4) << 6)
	if roll.call("moustache", 3) == 0:
		style |= FACE_MOUSTACHE
	elif roll.call("beard", 4) == 0:
		style |= FACE_BEARD
	own_face.set_shader_parameter("style", style)
	_face_seed = roll.call("blink", 1000) / 1000.0
	own_face.set_shader_parameter("seed", _face_seed)
	var own_nose: = _nose_material.duplicate() as StandardMaterial3D
	own_nose.albedo_color = skin.darkened(0.03)
	face[0].material_override = own_face
	face[1].material_override = own_nose

	scale = Vector3.ONE * (0.96 + 0.08 * roll.call("height", 100) / 99.0)

	var fade: = 1.0 + 0.3 * clampf(years, 0.0, 1.0)
	for sheet: String in ["jacket", "limbs"]:
		for mesh: MeshInstance3D in pieces.get(sheet, []):
			for surface in (mesh.mesh.get_surface_count() if mesh.mesh else 0):
				var material: = mesh.get_surface_override_material(surface) as BaseMaterial3D
				if material == null:
					material = mesh.mesh.surface_get_material(surface) as BaseMaterial3D
				if material == null:
					continue
				var copy: = material.duplicate() as BaseMaterial3D
				copy.albedo_color = Color(copy.albedo_color.r * fade, copy.albedo_color.g * fade, copy.albedo_color.b * fade * 1.03, copy.albedo_color.a)
				mesh.set_surface_override_material(surface, copy)

	var look: = Edition.look("crew_look")

	var chest: = _front_of("UpperTorso", "jacket")
	if chest.size.x > 0.0:
		var tape: = _patch(joints["Waist"], Vector3(0.66, 0.18, 0.025), Edition.color(look, "name_tape", NAME_TAPE).darkened(0.25 * years))
		tape.position = Vector3(-0.42, chest.end.y - 0.42, chest.position.z - 0.015)
		var label: = Label3D.new()
		label.text = called.to_upper()
		label.font_size = 40
		label.pixel_size = 0.0028
		label.modulate = Edition.color(look, "name_ink", NAME_INK)
		label.outline_size = 0
		label.double_sided = false
		label.shaded = true
		label.position = Vector3(0, 0, -0.016)
		label.rotation.y = PI
		tape.add_child(label)

	var arm: = _front_of("LeftUpperArm", "jacket")
	if arm.size.x > 0.0 and look.get("badge") != "kit":
		var badge: = _patch(joints["ShoulderL"], Vector3(0.025, 0.34, 0.3), Edition.color(look, "badge_edge", BADGE_EDGE))
		badge.position = Vector3(arm.position.x - 0.012, -0.12, 0.0)
		var field: = _patch(badge, Vector3(0.012, 0.27, 0.23), Edition.color(look, "badge", BADGE))
		field.position = Vector3(-0.012, 0.01, 0.0)



func _front_of(part: String, sheet: String) -> AABB:
	for mesh: MeshInstance3D in pieces.get(sheet, []):
		if String(mesh.name).begins_with(part + "_") and mesh.mesh != null:
			var box: = mesh.mesh.get_aabb()
			return AABB(box.position * mesh.scale + mesh.position, box.size * mesh.scale)
	return AABB()


func _patch(parent: Node3D, size: Vector3, color: Color) -> MeshInstance3D:
	var box: = BoxMesh.new()
	box.size = size
	var look: = StandardMaterial3D.new()
	look.albedo_color = color
	look.roughness = 0.8
	var patch: = MeshInstance3D.new()
	patch.mesh = box
	patch.material_override = look
	patch.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(patch)
	_person.append(patch)
	return patch


func _turn(joint_name: String, x: float, y: = 0.0, z: = 0.0) -> void :
	_targets[joint_name] = Vector3(x, y, z)


func _add(joint_name: String, x: float, y: = 0.0, z: = 0.0) -> void :
	_targets[joint_name] = _targets.get(joint_name, Vector3.ZERO) + Vector3(x, y, z)



func set_mood(what: int, seconds: float) -> void :
	mood = what
	mood_until = Game.now() + seconds




const LOOK_REACH: = 16.0
const HEAD_YAW: = 1.05
const HEAD_PITCH: = 0.45
const BREATH: = 3.4
const FIDGET_AFTER: = 5.0



static var life_on: = true


func _life(delta: float, stride: float, run: float) -> void :
	if not life_on:
		return
	_life_time += delta
	var now: = Game.now()
	var still: = speed < 0.5 and on_floor and not seated and not lying and not climbing
	var free: = hold.is_empty() and hands_at.is_empty() and pose.is_empty() and not extras.has("mask")
	_idle_for = _idle_for + delta if (still and free) else 0.0

	if mood != 0 and now > mood_until:
		mood = 0
	var shown_mood: = mood
	if lying:
		shown_mood = 5
	elif mood == 0:
		if not on_floor and not seated:
			shown_mood = 1
		elif hold == "carry" or run > 0.5 or crouch > 0.6:
			shown_mood = 2


	var target: Variant = look_at
	if target == null and is_inside_tree():
		var mine: = _player()
		var nearest: = INF
		for other: Player in Game.players:
			if other == mine or not is_instance_valid(other) or not other.is_inside_tree():
				continue
			var at: = other.head_position()
			var d: = at.distance_to(global_position)
			if d < LOOK_REACH and d < nearest:
				nearest = d
				target = at
	var yaw: = 0.0
	var pitch: = 0.0
	if target != null:
		var local: Vector3 = global_transform.affine_inverse() * (target as Vector3)
		local.y -= HEAD_HEIGHT
		var flat: = Vector2(local.x, local.z).length()
		yaw = atan2( - local.x, - local.z)
		pitch = atan2(local.y, maxf(flat, 0.1))
		if absf(yaw) > 1.9:
			yaw = 0.0
			pitch = 0.0
	else:

		yaw = 0.25 * sin(_life_time * 0.37 + _face_seed * 6.0) * (1.0 if still else 0.3)
		pitch = 0.08 * sin(_life_time * 0.23 + _face_seed * 3.0)
	if _fidget == "watch" or _fidget == "look":
		pitch = -0.6
		yaw = 0.3 if _fidget == "watch" else 0.0
	var head_want: = Vector2(clampf(yaw, - HEAD_YAW, HEAD_YAW), clampf(pitch, - HEAD_PITCH, HEAD_PITCH))
	_head = _head.lerp(head_want, 1.0 - exp( - delta * 5.0))

	var look_want: = Vector2(clampf( - (yaw - _head.x * 0.6) * 1.4, -1.0, 1.0), clampf((pitch - _head.y * 0.6) * 1.6, -1.0, 1.0))
	_look = _look.lerp(look_want, 1.0 - exp( - delta * 12.0))
	extras["life"] = {"Neck": Vector3(_head.y, _head.x, 0)}
	if _details.size() > 2:
		_details[2].visible = _details[0].visible and fmod(_life_time + _face_seed * 3.0, 2.4) > 2.25
	if not face.is_empty():
		var material: = face[0].material_override as ShaderMaterial
		if material != null:
			material.set_shader_parameter("look", _look)
			material.set_shader_parameter("mood", shown_mood)

	if lying or (seated and not seat_stand):
		return

	var breath: = sin(_life_time * TAU / BREATH + _face_seed * 7.0)
	_add("Waist", -0.012 * breath)
	_add("ShoulderL", 0, 0, -0.02 * breath)
	_add("ShoulderR", 0, 0, 0.02 * breath)
	if still:
		var sway: = sin(_life_time * 0.45 + _face_seed * 5.0)
		_add("Waist", 0, 0, 0.03 * sway)
		_add("Hips", 0, 0, -0.03 * sway)
		_add("Neck", 0, 0, -0.02 * sway)

	if stride > 0.0 and on_floor and not climbing:
		var swing: = sin(_phase)
		_add("Neck", -0.04 * absf(cos(_phase)) * stride, 0, 0)
		_add("Waist", 0, -0.07 * swing * stride, 0.025 * swing * stride)
		_add("Hips", 0, 0, -0.035 * swing * stride)


	if _idle_for <= 0.0:
		_fidget = ""
		_next_fidget = 0.0
		return
	if _fidget.is_empty():
		if _next_fidget == 0.0:
			_next_fidget = now + FIDGET_AFTER + randf() * 6.0
		elif now >= _next_fidget:
			_fidget = ["hips", "helmet", "watch", "look", "hips"][randi() % 5]
			_fidget_until = now + (4.0 if _fidget == "hips" else 1.8)
	elif now >= _fidget_until:
		_fidget = ""
		_next_fidget = now + 6.0 + randf() * 8.0
	match _fidget:
		"hips":
			_turn("ShoulderL", -0.35, 0, 0.75)
			_turn("ShoulderR", -0.35, 0, -0.75)
			_turn("ElbowL", 1.75)
			_turn("ElbowR", 1.75)
		"helmet":
			_turn("ShoulderR", 2.75, 0, -0.35)
			_turn("ElbowR", 1.5)
		"watch":
			_turn("ShoulderL", 0.55, 0, 0.1)
			_turn("ElbowL", 2.0, 0.4, 0)



func posed(joint_name: String) -> Vector3:
	return _eased.get(joint_name, Vector3.ZERO)



func act(_clip_name: String) -> void :
	pass



func tint(_mesh_name: String, _color: Color) -> void :
	pass


func _process(delta: float) -> void :
	_phase_wave += delta * 6.0

	var run: = clampf((speed - 15.0) / 6.0, 0.0, 1.0) if on_floor and not seated and not lying and not climbing else 0.0

	_phase += speed * delta * (CLIMB_CADENCE if climbing else 0.42 * (1.0 + 0.12 * run))
	var stride: = clampf(speed / 20.0, 0.0, 1.2)
	var swing: = sin(_phase)
	_targets.clear()
	var hips_drop: = 0.0
	var lean: = 0.0

	if lying:
		for joint_name: String in JOINTS:
			_turn(joint_name, 0)
		_turn("ShoulderL", 0.12)
		_turn("ShoulderR", 0.12)
	elif seated and not seat_stand:
		_turn("HipL", 1.45)
		_turn("HipR", 1.45)
		_turn("KneeL", -1.4)
		_turn("KneeR", -1.4)
		_turn("ShoulderL", 1.1, 0, 0.15)
		_turn("ShoulderR", 1.1, 0, -0.15)
		_turn("ElbowL", 0.5)
		_turn("ElbowR", 0.5)
	elif climbing:


		var reach: = sin(_phase)
		var left_up: = maxf(0.0, reach)
		var right_up: = maxf(0.0, - reach)
		_turn("ShoulderL", 2.35 + 0.5 * reach, 0, 0.12)
		_turn("ShoulderR", 2.35 - 0.5 * reach, 0, -0.12)
		_turn("ElbowL", 0.55 + 0.5 * right_up)
		_turn("ElbowR", 0.55 + 0.5 * left_up)
		_turn("HipL", 0.3 + 0.75 * right_up)
		_turn("HipR", 0.3 + 0.75 * left_up)
		_turn("KneeL", -0.45 - 1.1 * right_up)
		_turn("KneeR", -0.45 - 1.1 * left_up)
		_turn("AnkleL", 0.2)
		_turn("AnkleR", 0.2)
		lean = 0.12
	elif not on_floor:
		_turn("HipL", 0.5)
		_turn("HipR", -0.2)
		_turn("KneeL", -0.9)
		_turn("KneeR", -0.3)
		_turn("ShoulderL", -0.4, 0, -0.5)
		_turn("ShoulderR", -0.4, 0, 0.5)
	else:
		var bend: = deg_to_rad(Config.Stance.CrouchAngle) * crouch
		var legs: = 0.65 * stride + 0.2 * run
		var lift: = 0.9 * stride + 0.9 * run
		_turn("HipL", bend + swing * legs + maxf(0.0, swing) * 0.25 * run)
		_turn("HipR", bend - swing * legs + maxf(0.0, - swing) * 0.25 * run)
		_turn("KneeL", - bend * 1.9 - maxf(0.0, - cos(_phase)) * lift - 0.25 * run)
		_turn("KneeR", - bend * 1.9 - maxf(0.0, cos(_phase)) * lift - 0.25 * run)
		_turn("AnkleL", bend * 0.9)
		_turn("AnkleR", bend * 0.9)
		_turn("ShoulderL", - swing * (0.55 * stride + 0.3 * run))
		_turn("ShoulderR", swing * (0.55 * stride + 0.3 * run))
		_turn("ElbowL", 0.15 + 0.35 * stride + 0.9 * run)
		_turn("ElbowR", 0.15 + 0.35 * stride + 0.9 * run)
		lean = deg_to_rad(Config.Stance.CrouchLean) * crouch + 0.06 * stride + 0.16 * run

		hips_drop = (1.0 - cos(bend)) * 0.92 + (1.0 - cos(bend * 0.9)) * 0.92

		hips_drop += absf(sin(_phase)) * (0.08 * stride + 0.1 * run)

	if not lying and not seated and not climbing:
		match hold:
			"nozzle":

				_turn("ShoulderR", 0.75 + aim_pitch * 0.7, 0, -0.25)
				_turn("ElbowR", 0.75)
				_turn("ShoulderL", 1.25 + aim_pitch * 0.7, 0, 0.55)
				_turn("ElbowL", 0.35)
			"tool":
				_turn("ShoulderR", 0.5, 0, -0.1)
				_turn("ElbowR", 0.9)
			"carry":
				if has_meta("board_carry"):

					_turn("ShoulderL", 0.55, 0, 0.12)
					_turn("ShoulderR", 0.55, 0, -0.12)
					_turn("ElbowL", 0.1)
					_turn("ElbowR", 0.1)
					lean += CARRY_LEAN * 0.5
				else:


					_turn("ShoulderL", 1.0, 0, 0.6)
					_turn("ShoulderR", 1.0, 0, -0.3)
					_turn("ElbowL", 0.9)
					_turn("ElbowR", 0.9)
					lean += CARRY_LEAN
			"both":
				_turn("ShoulderR", 0.9, 0, -0.3)
				_turn("ElbowR", 0.7)
				_turn("ShoulderL", 0.9, 0, 0.3)
				_turn("ElbowL", 0.7)

	var low: = _act_low()
	if low > 0.0 and on_floor and not lying and not seated and not climbing:
		var dip: = deg_to_rad(Config.Stance.CrouchAngle) * low
		for side in ["L", "R"]:
			_targets["Hip" + side] = _targets.get("Hip" + side, Vector3.ZERO) + Vector3(dip, 0, 0)
			_targets["Knee" + side] = _targets.get("Knee" + side, Vector3.ZERO) + Vector3( - dip * 1.9, 0, 0)
			_targets["Ankle" + side] = _targets.get("Ankle" + side, Vector3.ZERO) + Vector3(dip * 0.9, 0, 0)
		lean += 0.35 * low
		hips_drop += (1.0 - cos(dip)) * 0.92 + (1.0 - cos(dip * 0.9)) * 0.92
	if pose == "waving" and not lying and not seated and hold.is_empty():
		_turn("ShoulderR", 2.7, 0, -0.35 + sin(_phase_wave) * 0.35)
		_turn("ElbowR", 0.3)
	_turn("Waist", - lean)
	_life(delta, stride, run)

	var ease: = 1.0 - exp( - delta * 14.0)
	for joint_name: String in JOINTS:
		var joint: Node3D = joints[joint_name]
		var target: Vector3 = _targets.get(joint_name, Vector3.ZERO)
		var eased: Vector3 = _eased.get(joint_name, Vector3.ZERO).lerp(target, ease)
		_eased[joint_name] = eased
		for source: Variant in extras:
			eased += extras[source].get(joint_name, Vector3.ZERO)
		joint.rotation = eased
		if joint_name.begins_with("Shoulder") and not _viewing:
			joint.position = _base[joint_name]
	var hips: Node3D = joints["Hips"]
	var base: Vector3 = _base["Hips"]
	if seated and not seat_stand:
		hips_drop = SEATED_DROP - seat_lift
	hips.position = hips.position.lerp(base - Vector3(0, hips_drop, 0), ease)
	if not _viewing:
		_reach(delta)



func shown_sheets() -> Array:
	return _shown.keys()



func wear_sheets(sheets: Array) -> void :
	if sheets.size() == _shown.size():
		var same: = true
		for sheet: String in sheets:
			same = same and _shown.has(sheet)
		if same:
			return
	var wanted: = {}
	for sheet: String in sheets:
		wanted[sheet] = true
	wear(wanted)




const HAND_BLEND: = 0.2
const POLES: = {"R": Vector3(0.7, -1.0, 0.55), "L": Vector3(-0.7, -1.0, 0.55)}



func held() -> Node3D:
	if hand_right == null:
		return null
	for child in hand_right.get_children():
		if child is Node3D and child.visible:
			return child
	return null



static func hold_kind(thing: Node3D) -> String:
	if thing == null:
		return ""
	if thing.has_method("hold_kind"):
		return thing.hold_kind()
	return String(thing.get_meta("hold", ""))



func _player() -> Player:
	return get_parent() as Player



func _act_low() -> float:
	if hands_at.is_empty() or hands_at.get("kind", "") == "force" or not is_inside_tree():
		return 0.0
	var at: Vector3 = hands_at.get("at", Vector3.INF)
	if at == Vector3.INF:
		return 0.0
	var height: = at.y - global_position.y
	var weight: = Holds.act_weight(_act_times(), 0.3, 0.3)
	return clampf((2.2 - height) / 1.6, 0.0, 1.0) * weight



func _act_times() -> Dictionary:
	if hands_at.is_empty():
		return {}
	var now: = Game.now()
	var out: = hands_at.duplicate()
	out["t"] = now - float(hands_at.get("since", now))
	var ended: float = hands_at.get("ended", -1.0)

	if ended < 0.0 and hands_at.get("kind", "") == "place":
		ended = float(hands_at.get("since", now)) + 0.8
	out["done"] = now - ended if ended >= 0.0 and now >= ended else -1.0
	return out



func _context(body: Transform3D, frame_from_world: Transform3D, viewing: bool, thing: Node3D, kind: String) -> Dictionary:
	var ctx: = {
		"body": body, "view": viewing, "now": Game.now(), "stride": clampf(speed / 20.0, 0.0, 1.2), "phase": _phase, 
		"tool": thing as HandTool, "swing": -1.0, 
	}
	var times: = _act_times()
	if not times.is_empty():
		var normal: Vector3 = times.get("normal", Vector3.ZERO)
		times["at"] = frame_from_world * Vector3(times["at"])
		times["normal"] = frame_from_world.basis * normal
		ctx["act"] = times
		if times["done"] >= 0.5 or (times.get("kind") in ["reach", "place"] and times["t"] > 0.8 and times["done"] < 0.0):
			ctx.erase("act")
	if thing is HandTool:
		ctx["swing"] = (thing as HandTool).swing_progress()
	if kind in ["nozzle", "Extinguisher", "Thermal camera"]:
		var player: = _player()
		if player != null:
			var aim: Vector3 = HoseService.current.aim_of(player) if (kind == "nozzle" and HoseService.current) else player.aim_point()
			ctx["aim"] = frame_from_world * aim
	return ctx



func _reach(delta: float) -> void :
	var hips: Node3D = joints["Hips"]
	var waist: Node3D = joints["Waist"]
	var body: = hips.transform * waist.transform * Transform3D(Basis.IDENTITY, Vector3(0, Holds.BODY_HEIGHT, 0))
	var from_world: = global_transform.affine_inverse() if is_inside_tree() else Transform3D.IDENTITY
	_hands(delta, body, from_world, false, 1.0)




func solve_view(eye: Transform3D, scale: float, delta: float) -> void :
	if not _viewing:
		_viewing = true
		for side in ["R", "L"]:
			var shoulder: Node3D = joints["Shoulder" + side]
			shoulder.top_level = true
			shoulder.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	var shift: Vector3 = Holds.VIEW + Holds.VIEWS.get(hold_kind(held()), Vector3.ZERO)
	var body: = eye * Transform3D(Basis.from_scale(Vector3.ONE * scale), shift * scale)
	_hands(delta, body, Transform3D.IDENTITY, true, scale, eye)



func end_view() -> void :
	if not _viewing:
		return
	_viewing = false
	view_arms = {"R": false, "L": false}
	for side in ["R", "L"]:
		var shoulder: Node3D = joints["Shoulder" + side]
		shoulder.top_level = false
		shoulder.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_INHERIT
		shoulder.transform = Transform3D(Basis.from_euler(posed("Shoulder" + side)), _base["Shoulder" + side])
		shoulder.reset_physics_interpolation()




func _hands(delta: float, body: Transform3D, from_world: Transform3D, viewing: bool, scale: float, eye: = Transform3D.IDENTITY) -> void :
	var thing: = held()
	var kind: = hold_kind(thing)
	if kind.is_empty() and thing == null and hold == "tool":
		kind = "hose_end"
	var busy: = lying or seated or hold in ["carry", "wheel"] or extras.has("mask")
	var ctx: = _context(body, from_world, viewing, thing, kind)
	var pose: Dictionary = {}

	var fixed: = {} if (viewing or lying or extras.has("mask")) else _fixed_grips(from_world)
	if not busy and not kind.is_empty():
		pose = thing.hold_pose(ctx) if (thing != null and thing.has_method("hold_pose")) else Holds.pose(kind, ctx)
		var meets: = 1.0 - float(pose.get("view_lift", 1.0))
		if viewing and meets > 0.001:



			var shift: Vector3 = Holds.VIEW + Holds.VIEWS.get(kind, Vector3.ZERO)
			var ahead: = - eye.basis.z
			var upright: = Basis(Vector3.UP, atan2( - ahead.x, - ahead.z))
			var turn: = Basis(eye.basis.get_rotation_quaternion().slerp(upright.get_rotation_quaternion(), meets))
			body = Transform3D(turn, eye.origin) * Transform3D(Basis.from_scale(Vector3.ONE * scale), shift.lerp(Holds.VIEW_AT_WORK, meets) * scale)
			ctx["body"] = body
			pose = thing.hold_pose(ctx) if (thing != null and thing.has_method("hold_pose")) else Holds.pose(kind, ctx)
	var waist: Node3D = joints["Waist"]
	var hips: Node3D = joints["Hips"]

	var weight_r: float = _hand_weight["R"]
	if not viewing and not pose.is_empty():
		waist.rotation += Vector3( - float(pose.get("lean", 0.0)), float(pose.get("twist", 0.0)), 0) * weight_r
	var shoulders: = {}
	for side in ["R", "L"]:
		if viewing:


			var turn: = Basis(Vector3.UP, float(pose.get("twist", 0.0)) * weight_r) * Basis(Vector3.RIGHT, - float(pose.get("lean", 0.0)) * weight_r)
			var pivot: = Vector3(0, - Holds.BODY_HEIGHT, 0)
			shoulders[side] = body * (pivot + turn * (Vector3(Holds.SHOULDER if side == "R" else - Holds.SHOULDER, 0, 0) - pivot))
		else:
			shoulders[side] = hips.transform * waist.transform * _base["Shoulder" + side]

	var targets: = {}
	var place: Transform3D = pose.get("place", Transform3D.IDENTITY)
	var grips: = {}
	if viewing and pose.has("right"):


		var lift: float = float(Holds.LIFTS.get(kind, Holds.LIFT)) * float(pose.get("view_lift", 1.0))
		var anchor: = body.affine_inverse() * (place * (pose["right"] as Transform3D)).origin
		var up: = Basis(Vector3.RIGHT, lift) * anchor - anchor
		place.origin += body.basis * up

		for side: String in shoulders:
			shoulders[side] += body.basis * (up * (Holds.VIEW_SHOULDERS_BY.get(kind, Holds.VIEW_SHOULDERS) as Vector3))
	if pose.has("right"):
		grips["R"] = pose["right"]
		if thing != null:
			thing.transform = (pose["right"] as Transform3D).affine_inverse()
	if pose.get("left") != null and float(pose.get("left_weight", 1.0)) > 0.001:
		grips["L"] = pose["left"]

	var placing: bool = ctx.has("act") and ctx["act"].get("kind") == "place" and not busy
	if placing and grips.has("R"):
		var t: float = ctx["act"]["t"]
		var down: = Holds._ease(t / 0.25) * (1.0 - Holds._ease((t - 0.45) / 0.3))
		var anchor: = (place * (grips["R"] as Transform3D)).origin
		place.origin += ((ctx["act"]["at"] as Vector3) + body.basis.y.normalized() * 0.6 - anchor) * down * 0.85


	var reach_max: = (ArmReach.UPPER + ArmReach.LOWER + ArmReach.STRETCH) * scale * 0.985
	var square: = body.basis.orthonormalized()
	reach_need = {}
	var start: = place.origin
	for _round in 4:
		var moved: = false
		for side: String in grips:
			var hand: Transform3D = place * grips[side]
			var wrist: = hand.origin + hand.basis.orthonormalized().y * ArmReach.FIST * scale
			var to: Vector3 = wrist - shoulders[side]
			if _round == 0:
				reach_need[side] = to.length() / scale
			var over: = to.length() - reach_max
			if over > 0.001:
				var share: = 1.0 if side == "R" else float(pose.get("left_weight", 1.0))
				var shift: = square.inverse() * ( - to.normalized() * over * share)
				shift.z = minf(shift.z, 0.0)
				place.origin += square * shift
				moved = true
		if not moved:
			break
	reach_need["nudge"] = (square.inverse() * (place.origin - start)) / scale
	for side: String in grips:
		targets[side] = place * grips[side]
	for side: String in fixed:
		targets[side] = fixed[side]


	var acting: bool = ctx.has("act") and not busy and not (placing and targets.has("R"))
	var gesture_side: = "L" if targets.has("R") else "R"
	var gesture_weight: = 0.0
	if acting:
		var gesture: = Holds.act_hand(ctx, shoulders[gesture_side], gesture_side == "L")
		if not gesture.is_empty():
			gesture_weight = gesture[1]
			if targets.has(gesture_side) and gesture_side == "L":
				targets["L"] = (targets["L"] as Transform3D).interpolate_with(gesture[0], gesture_weight)
			else:
				targets[gesture_side] = gesture[0]

	for side in ["R", "L"]:
		var wanted: = 0.0
		if targets.has(side):
			wanted = 1.0
			if side == "L" and grips.has("L") and not (acting and gesture_side == "L"):
				wanted = float(pose.get("left_weight", 1.0))
			elif side == gesture_side and not grips.has(side) and not fixed.has(side):
				wanted = gesture_weight
		var gesturing: bool = side == gesture_side and not grips.has(side) and not fixed.has(side)
		_hand_weight[side] = move_toward(_hand_weight[side], wanted, delta / HAND_BLEND) if not gesturing else wanted
	for side in ["R", "L"]:
		var shoulder: Node3D = joints["Shoulder" + side]
		var weight: float = _hand_weight[side]
		var parent: = hips.transform * waist.transform
		if weight <= 0.001 or not targets.has(side):
			view_arms[side] = false
			if viewing:

				shoulder.global_transform = waist.global_transform * Transform3D(Basis.from_euler(posed("Shoulder" + side)), _base["Shoulder" + side])
			continue
		var target: Transform3D = targets[side]

		var from: Transform3D
		if viewing:
			from = target.translated(eye.basis.y * -1.8 * scale + eye.basis.z * 0.4 * scale)
		else:
			from = parent * shoulder.transform * joints["Elbow" + side].transform * joints["Wrist" + side].transform * Transform3D(Basis.IDENTITY, Vector3(0, - ArmReach.FIST, 0))
		if weight < 0.999:
			target = from.interpolate_with(target, Holds._ease(weight))
		var pole: Vector3 = body.basis * (FIXED_POLES[side] if fixed.has(side) else POLES[side])
		var wrist: = target.origin + target.basis.orthonormalized().y * ArmReach.FIST * scale
		var ideal: = wrist + target.basis.orthonormalized().y * ArmReach.LOWER * scale - (shoulders[side] as Vector3)
		pole = pole.normalized() + ideal.normalized() * 0.8
		var solved: = ArmReach.solve(shoulders[side], target, pole, scale)
		var shoulder_basis: Basis = solved[1]
		var bend: float = solved[2]
		var wrist_basis: Basis = solved[3]
		if viewing:
			shoulder.global_transform = Transform3D(shoulder_basis * Basis.from_scale(Vector3.ONE * scale), solved[0])
			view_arms[side] = true
		else:
			var inverse: = parent.affine_inverse()
			shoulder.transform = Transform3D(parent.basis.inverse() * shoulder_basis, inverse * (solved[0] as Vector3))
		joints["Elbow" + side].basis = Basis(Vector3.RIGHT, bend)
		joints["Wrist" + side].basis = (shoulder_basis * Basis(Vector3.RIGHT, bend)).inverse() * wrist_basis
		if side == "R":
			_gap = solved[4]
		else:
			_gap_left = solved[4]
	if not targets.has("R") or _hand_weight["R"] <= 0.001:
		_gap = 0.0
	if not targets.has("L") or _hand_weight["L"] <= 0.001:
		_gap_left = 0.0
	if thing != null and thing.has_method("after_hold"):
		thing.after_hold(pose, from_world.affine_inverse())







const CARRY_GRIPS: = {
	"R": ["outer", Vector3(0.78, 0.1, 0.0), Vector3(0.3, -0.15, 1.0)], 
	"L": ["inner", Vector3(-0.75, -0.1, -0.05), Vector3(-0.7, -0.25, 0.6)], 
}
const CARRY_DOWN: = 0.75
const CARRY_LEAN: = 0.12
const WHEEL_RIM: = 0.9
const WHEEL_AT: = 1.3
const WHEEL_FOLLOW: = 1.15
const WHEEL_HIGHEST: = 0.8
const WHEEL_LOWEST: = 2.3
const FIXED_POLES: = {"R": Vector3(1.0, -1.0, 0.3), "L": Vector3(-1.0, -1.0, 0.3)}



func at_controls() -> bool:
	var player: = _player()
	return seated and player != null and player.seat != null and (player.seat.has_meta("wheel") or player.seat.has_meta("grips"))



func _fixed_grips(from_world: Transform3D) -> Dictionary:
	var player: = _player()
	if hold == "carry" and not seated:
		var waist: Node3D = joints["Waist"]
		var legs: = _carried_legs(waist)
		if legs.is_empty():
			return {}
		var space: = joints["Hips"].transform * waist.transform as Transform3D
		var out: = {}
		for side: String in CARRY_GRIPS:
			var row: Array = CARRY_GRIPS[side]
			var leg: Vector3 = legs[row[0]]
			out[side] = space * ArmReach.grip(leg + (row[1] as Vector3), Vector3.UP, row[2])
		return out
	if seated and player != null and player.seat != null and player.seat.has_meta("grips"):

		var grips: Dictionary = player.seat.get_meta("grips")
		var out: = {}
		for side: String in grips:
			var row: Array = grips[side]
			out[side] = from_world * player.seat.global_transform * ArmReach.grip(row[0], row[1], row[2])
		return out
	if seated and player != null and player.seat != null and player.seat.has_meta("wheel"):
		var wheel: Node3D = player.seat.get_meta("wheel")
		if not is_instance_valid(wheel) or not wheel.is_inside_tree():
			return {}

		var turn: = wheel.rotation.z
		var straight: Transform3D = wheel.get_parent().global_transform * Transform3D(Basis.from_euler(Vector3(wheel.rotation.x, wheel.rotation.y, 0)), wheel.position)
		var follow: = clampf(turn, - WHEEL_FOLLOW, WHEEL_FOLLOW)
		var out: = {}
		for side: String in ["R", "L"]:


			var at: = clampf(WHEEL_AT - follow, WHEEL_HIGHEST, WHEEL_LOWEST) if side == "R" else clampf( - WHEEL_AT - follow, - WHEEL_LOWEST, - WHEEL_HIGHEST)
			var radial: = Vector3(sin(at), cos(at), 0)
			var along: = Vector3(cos(at), - sin(at), 0)
			var thumb: = along * signf(along.y) if absf(along.y) > 0.01 else Vector3.UP
			var wrist: = Vector3(0, -0.45, 1.0) + radial * 0.35
			var hand: = ArmReach.grip(radial * WHEEL_RIM, thumb, wrist)
			out[side] = from_world * straight * hand
		return out
	return {}



func _carried_legs(waist: Node3D) -> Dictionary:
	for child in waist.get_children():
		var figure: = child as Figure
		if figure == null:
			continue
		var found: Array[Vector3] = []
		for joint: Dictionary in figure.joints:
			var pivot: Node3D = joint["node"]
			if joint["role"] == "leg" and pivot.get_child_count() > 0 and String(pivot.get_child(0).name).begins_with("Leg"):
				found.append(figure.transform * pivot.transform * Vector3(0, - CARRY_DOWN, 0))
		if found.size() == 2:
			return {"outer": found[0] if found[0].x > found[1].x else found[1], "inner": found[1] if found[0].x > found[1].x else found[0]}
	return {}


var _gap: = 0.0
var reach_need: Dictionary = {}
var _gap_left: = 0.0



func gaps() -> Array:
	return [_gap, _gap_left]
