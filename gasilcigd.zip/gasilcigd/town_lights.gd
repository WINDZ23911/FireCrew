class_name TownLights
extends Node3D















const LAMP_OFF: = Color(230 / 255.0, 230 / 255.0, 224 / 255.0)
const LAMP_ON: = Color(1.0, 232 / 255.0, 190 / 255.0)
const GLASS: = Color(78 / 255.0, 100 / 255.0, 122 / 255.0)


const LAMPS: = [Color(1.0, 0.66, 0.36), Color(1.0, 0.73, 0.46), Color(1.0, 0.79, 0.57), Color(1.0, 0.85, 0.68), Color(1.0, 0.91, 0.8)]
const SCREEN_LIT: = Color(0.62, 0.72, 1.0)

const SHOP_LIT: = Color(0.96, 0.92, 0.82)
const SHOP_SHUTS: = 21.0
const SHOP_OPENS: = 6.5
const LAMP_MOST: = 0.8
const LAMP_GLOW: = 3.0
const WINDOW_GLOW: = 1.5


const SPOT_ENERGY: = 20.0
const SURFACE_ENERGY: = 14.0
const FADE_FROM: = 210.0
const FADE_OVER: = 70.0
const CHECK_EVERY: = 1.0
const CHECKED_AT_ONCE: = 320
const TV_REACH: = 140.0
const TV_MOST: = 6
const TV_BLUE: = Color(0.55, 0.68, 1.0)



const ROAD_LAMPS: = {
	"main": [Color(1.0, 0.78, 0.5), 1.3, Color(1.0, 0.8, 0.5)], 
	"through": [Color(1.0, 0.85, 0.62), 1.0, Color(1.0, 232 / 255.0, 190 / 255.0)], 
	"estate": [Color(0.96, 0.95, 0.9), 0.7, Color(0.88, 0.92, 1.0)], 
}
const ROAD_CLASS: = {
	"primary": "main", "secondary": "main", "tertiary": "through", 
	"residential": "estate", "living_street": "estate", "service": "estate", "track": "estate", 
}
const ROAD_REACH: = 30.0
const HALO_SIZE: = 4.0
const HALO_FROM: = 150.0

static var current: TownLights

var lights: Array[SpotLight3D] = []
var _night_lights: Array[SpotLight3D] = []
var _heads: PackedInt32Array = []
var _windows: PackedInt32Array = []
static var shops: Dictionary = {}
var _fittings: Dictionary = {}
var _panes: Dictionary = {}
var _floodlights: Dictionary = {}
var _next_window: = 0
var _since: = 0.0
var _tvs: Dictionary = {}
var _tv_since: = 0.0
var _roads: Array = []
var _head_colors: Dictionary = {}
var _halos: MultiMeshInstance3D


func _init() -> void :
	current = self


func _ready() -> void :
	var store: = Game.store
	_find_roads()
	for id: int in store.nodes:
		var node: Dictionary = store.nodes[id]
		if node["c"] == "SpotLight" or node["c"] == "SurfaceLight":
			_add_light(node)
	_heads = store.tagged.get("StreetLamp", PackedInt32Array())
	for id in _heads:
		var row: int = store.row_of.get(id, -1)
		if row >= 0:
			var road: = _road_class(store.position(row))
			if not road.is_empty():
				_head_colors[id] = ROAD_LAMPS[road][2]
	_find_windows()
	_find_station()
	_make_halos()
	Game.night_changed.connect(_show)
	_show(Game.night)





func _find_roads() -> void :
	for road: Dictionary in Rbx.module("TownLayout")["roads"]:
		var kind: String = ROAD_CLASS.get(road["class"], "")
		if kind.is_empty():
			continue
		var points: Array = road["points"]
		for leg in points.size() - 1:
			_roads.append([Vector2(float(points[leg][0]), float(points[leg][1])), Vector2(float(points[leg + 1][0]), float(points[leg + 1][1])), kind])




func _road_class(at: Vector3) -> String:
	var flat: = Vector2(at.x, at.z)
	var best: = ROAD_REACH
	var kind: = ""
	for leg: Array in _roads:
		var near: = Geometry2D.get_closest_point_to_segment(flat, leg[0], leg[1])
		var gap: = near.distance_to(flat)
		if gap < best:
			best = gap
			kind = leg[2]
	return kind




func _make_halos() -> void :
	var spots: Array = []
	for light in _night_lights:
		var road: = _road_class(light.global_position)
		if not road.is_empty():

			var lamp: Color = ROAD_LAMPS[road][2]
			var strength: = float(ROAD_LAMPS[road][1])
			spots.append([light.global_position + Vector3(0, 0.6, 0), Color(lamp.r * strength, lamp.g * strength, lamp.b * strength, strength)])
	if spots.is_empty():
		return
	var quad: = QuadMesh.new()
	quad.size = Vector2(HALO_SIZE, HALO_SIZE)
	var many: = MultiMesh.new()
	many.transform_format = MultiMesh.TRANSFORM_3D
	many.use_colors = true
	many.mesh = quad
	many.instance_count = spots.size()
	for index in spots.size():
		many.set_instance_transform(index, Transform3D(Basis(), spots[index][0]))
		many.set_instance_color(index, spots[index][1])
	var material: = ShaderMaterial.new()
	material.shader = load("res://shaders/lamp_halo.gdshader")
	material.set_shader_parameter("from", HALO_FROM)
	_halos = MultiMeshInstance3D.new()
	_halos.multimesh = many
	_halos.material_override = material
	_halos.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_halos.custom_aabb = AABB(Vector3(-3000, -100, -3000), Vector3(6000, 400, 6000))
	_halos.visible = false
	add_child(_halos)



func _add_light(node: Dictionary) -> void :
	var store: = Game.store
	var row: int = store.row_of.get(node["p"], -1)
	if row < 0:
		return
	var values: Dictionary = node["v"]
	var place: = store.transform(row)
	var out: = face_normal(str(values.get("Face", "NormalId.Front")))
	var toward: = place.basis * out
	var light: = SpotLight3D.new()
	var surface: bool = node["c"] == "SurfaceLight"
	light.spot_range = float(values.get("Range", 16.0))

	light.spot_angle = clampf(float(values.get("Angle", 90.0)) / 2.0, 5.0, 80.0)
	light.spot_angle_attenuation = 0.6
	light.spot_attenuation = 0.6
	light.light_color = values.get("Color", Color.WHITE)
	light.light_energy = float(values.get("Brightness", 1.0)) * (SURFACE_ENERGY if surface else SPOT_ENERGY)
	light.light_specular = 0.3
	light.shadow_enabled = false
	light.distance_fade_enabled = true
	light.distance_fade_begin = FADE_FROM
	light.distance_fade_length = FADE_OVER
	add_child(light)
	var at: = place.origin + toward * ((store.size(row) * out).length() / 2.0 + 0.05)
	light.global_transform = Transform3D(Basis.looking_at(toward, Vector3.FORWARD if absf(toward.y) > 0.9 else Vector3.UP), at)
	lights.append(light)

	if values.get("Enabled", true) == false:
		_night_lights.append(light)


		light.light_color = Sky3D.config_color(Config.Art.SodiumLamps)

		var road: = _road_class(light.global_position)
		if not road.is_empty():
			light.light_color = ROAD_LAMPS[road][0]
			light.light_energy *= float(ROAD_LAMPS[road][1])
	elif store.name_at(row) == "Floodlight":
		_floodlights[light] = light.light_energy



static func face_normal(face: String) -> Vector3:
	match face.get_slice(".", 1):
		"Back":
			return Vector3.BACK
		"Top":
			return Vector3.UP
		"Bottom":
			return Vector3.DOWN
		"Right":
			return Vector3.RIGHT
		"Left":
			return Vector3.LEFT
	return Vector3.FORWARD




func _find_windows() -> void :
	var store: = Game.store
	var share: = minf(float(Config.Day.LitWindows) * 1.6, 0.85)

	var awnings: = {}
	for row in store.count:
		if store.name_at(row) == "Awning":
			awnings[store.parent(row)] = maxf(float(awnings.get(store.parent(row), - INF)), store.position(row).y)
	shops.clear()
	for row in store.count:
		if store.name_at(row) == "Window" and store.color(row).is_equal_approx(GLASS):
			var id: = store.id_at(row)
			var model: = store.parent(row)
			if awnings.has(model) and store.position(row).y < float(awnings[model]) + 0.5:
				shops[id] = true
				_windows.append(id)
			elif _chance(id, 7919) < share:
				_windows.append(id)



static func _chance(id: int, salt: int) -> float:
	return float(posmod(hash(id * salt + salt), 10007)) / 10007.0




static func window_on(id: int, hour: float) -> bool:
	if shops.has(id):

		var dusk_at: = float(Config.Day.Dusk) - 0.5
		return hour >= dusk_at and hour < SHOP_SHUTS or hour >= SHOP_OPENS and hour < float(Config.Day.Dawn) + 0.5
	var dusk: = float(Config.Day.Dusk)
	var dawn: = float(Config.Day.Dawn)

	var since_noon: = fposmod(hour - 12.0, 24.0)
	var on_at: = dusk - 12.0 + _chance(id, 31) * 1.2
	var late: = _chance(id, 53)
	var off_at: = 9.0 + _chance(id, 97) * 4.0
	if late > 0.88:
		off_at = 13.0 + _chance(id, 101) * 2.5
	if _chance(id, 13) < 0.88 and since_noon >= on_at and since_noon < off_at:
		return true

	if _chance(id, 211) < 0.18:
		var up: = 5.0 + _chance(id, 223) * 1.5
		return hour >= up and hour < dawn + 0.4
	return false




func _find_station() -> void :
	var store: = Game.store
	var model: = 0
	for id: int in store.nodes:
		if store.nodes[id]["c"] == "Model" and store.nodes[id]["n"] == "Fire Station":
			model = id
	var plan: Dictionary = Rbx.module("StationData")
	var rows: PackedInt32Array = store.rows_under.get(model, PackedInt32Array())
	for light: Dictionary in plan.get("lights", []):
		var index: = int(light["index"]) - 1
		if light.get("night", false) and index < rows.size():
			_fittings[store.id_at(rows[index])] = store.color(rows[index])
	for number: float in plan.get("nightGlass", []):

		var index: = int(number)
		if index % 3 != 0 and index - 1 < rows.size():
			_panes[store.id_at(rows[index - 1])] = store.color(rows[index - 1])


func _show(night: bool) -> void :
	var world: = Game.world
	for light in _night_lights:
		light.visible = night
	if _halos:
		_halos.visible = night
	for id in _heads:
		if night:
			world.set_glow(id, _head_colors.get(id, LAMP_ON), LAMP_GLOW)
		else:
			world.set_color(id, LAMP_OFF)
	for id: int in _fittings:
		if night:
			world.set_glow(id, LAMP_ON, LAMP_GLOW)
		else:
			world.set_color(id, _fittings[id])
	for id: int in _panes:
		if night:
			world.set_glow(id, lamp_of(id), WINDOW_GLOW)
		else:
			world.set_color(id, _panes[id])
	for id in _windows:
		_show_window(id, night)




func _show_window(id: int, night: bool) -> void :
	if _tvs.has(id):
		return
	var store: = Game.store
	var color: = store.color(store.row_of[id])
	var lit: = night and window_on(id, _hour())
	var lamp: = lamp_of(id)
	if lit:
		if color.is_equal_approx(GLASS) or (color.is_equal_approx(lamp) and Game.world.glow_of(id) <= 0.0):
			Game.world.set_glow(id, lamp, WINDOW_GLOW)
	elif color.is_equal_approx(lamp):
		Game.world.set_color(id, GLASS)




static func lamp_of(id: int) -> Color:
	if shops.has(id):
		return SHOP_LIT
	var roll: int = rand_from_seed(hash([id, 4243]))[0]
	var lamp: Color = SCREEN_LIT if roll % 10 == 0 else LAMPS[(roll / 10) % LAMPS.size()]
	return Color(lamp.r * LAMP_MOST, lamp.g * LAMP_MOST, lamp.b * LAMP_MOST)


func _hour() -> float:
	return Sky3D.current.hour if Sky3D.current else float(Config.Day.Start)







func _pick_tvs() -> void :
	var camera: = get_viewport().get_camera_3d()
	var store: = Game.store
	var keep: Dictionary = {}
	if camera != null and Game.night:
		var at: = camera.global_position
		var slot: = floori(Game.now() / 40.0)
		for id in _windows:
			if keep.size() >= TV_MOST:
				break
			if _chance(id + slot, 389) > 0.08:
				continue
			var row: int = store.row_of[id]
			if store.position(row).distance_to(at) > TV_REACH or not window_on(id, _hour()):
				continue
			var color: = store.color(row)
			if _tvs.has(id) or color.is_equal_approx(lamp_of(id)):
				keep[id] = _tvs.get(id, lamp_of(id))
	for id: int in _tvs.keys():
		if keep.has(id):
			continue
		var ours: bool = store.color(store.row_of[id]).is_equal_approx(_tvs[id])
		_tvs.erase(id)
		if ours:

			Game.world.set_glow(id, lamp_of(id), WINDOW_GLOW)
			_show_window(id, Game.night)
	for id: int in keep:
		if not _tvs.has(id):
			_tvs[id] = keep[id]


func _flicker_tvs() -> void :
	var store: = Game.store
	for id: int in _tvs.keys():
		var row: int = store.row_of[id]
		if not store.color(row).is_equal_approx(_tvs[id]):
			_tvs.erase(id)
			continue

		var t: = Game.now() * 3.1 + id * 0.37
		var level: = 0.55 + 0.3 * sin(t * 2.3) + 0.25 * sin(t * 5.7 + 1.0) + (0.25 if fmod(t, 1.7) < 0.12 else 0.0)
		var color: = lamp_of(id).lerp(TV_BLUE, 0.55 + 0.25 * sin(t * 0.7)) * clampf(level, 0.35, 1.2)
		color.a = 1.0
		Game.world.set_glow(id, color, WINDOW_GLOW * 0.8)
		_tvs[id] = store.color(row)




func _process(delta: float) -> void :
	if not _tvs.is_empty():
		_flicker_tvs()
	_tv_since += delta
	if _tv_since >= 3.0:
		_tv_since = 0.0
		_pick_tvs()
	_since += delta
	if _since < CHECK_EVERY:
		return
	_since = 0.0

	var day: = Sky3D.current.daylight() if Sky3D.current else 1.0
	for light: SpotLight3D in _floodlights:
		light.light_energy = _floodlights[light] * lerpf(1.0, 0.12, day)
	if _windows.is_empty():
		return
	for step in mini(CHECKED_AT_ONCE, _windows.size()):
		_next_window = (_next_window + 1) % _windows.size()
		_show_window(_windows[_next_window], Game.night)
