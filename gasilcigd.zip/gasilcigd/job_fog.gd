class_name JobFog
extends JobAttack





func _init() -> void :
	super ()
	kind = "fog"
	role = "nozzle"


static func leak() -> Dictionary:
	var hazmat: = HazmatLeak.current
	return hazmat._leak if hazmat != null else {}


func place() -> Vector3:
	var at: = leak()
	return at["leak"] if not at.is_empty() else who.body.global_position


func run() -> bool:
	var held: = who.token()
	var hazmat: = HazmatLeak.current
	if leak().is_empty():
		return fail("crew.say.nothingThere")
	if not await CrewWater.wear_set(who):
		who.say("crew.say.noSet", [], "warning")
	CrewKit.free_hands(who)
	if not await take_line(leak()["leak"], held):
		return false
	var hoses: = HoseService.current
	who.body.set_attr("Flow", int(Config.Crew.get("Flow", 2)))
	var started: = Game.now()
	while on(held):
		var at: = leak()
		if at.is_empty() or float(at["cloud"]) <= float(Config.Crew.Hazmat.CloudDone):
			return true
		if hoses.line_of(who.body) == null:
			return fail("crew.say.lineLost")
		if not CrewWater.breathe(who):
			return fail("crew.say.lowAir")
		if who.body.health < who.body.max_health * who.back_out_at():
			return fail("crew.say.hurt")
		var middle: Vector3 = hazmat._cloud_middle()

		var wind: Vector3 = hazmat._wind()
		var side: = wind.rotated(Vector3.UP, PI / 2.0)
		if (who.body.global_position - middle).dot(side) < 0.0:
			side = - side
		var spot: = who.service.ground(middle + side * float(Config.Crew.Hazmat.FogFrom) - wind * 4.0 + Vector3(0, 3, 0))
		var paid: = float(who.body.get_attr("HoseLength", 0.0))
		var length: = float(hoses.kind_of(line["kind"])["length"]) if line != null else 100.0
		if Vector3(spot.x - who.body.global_position.x, 0, spot.z - who.body.global_position.z).length() > 3.0 and length - paid > 10.0:
			who.body.set_attr("Trigger", false)
			await who.go(spot, 2.5, 25.0, func() -> bool: return float(HoseService.current.kind_of(line["kind"])["length"]) - float(who.body.get_attr("HoseLength", 0.0)) < 10.0 if line != null else false)
			if not on(held):
				return false
		who.wish = Vector3.ZERO
		var aim: = middle + Vector3(0, -1.0, 0)
		who.look = aim
		who.pitch = asin(clampf((aim - who.body.head_position()).normalized().y, -1.0, 1.0))
		who.body.set_attr("Aim", aim)
		who.body.set_attr("Pattern", "Fog")
		who.body.set_attr("Trigger", true)
		if not await who.wait(1.0, held):
			return false
		if Game.now() - started > float(Config.Crew.Hazmat.FogGiveUp):
			return fail("crew.say.cannot")
	return false
