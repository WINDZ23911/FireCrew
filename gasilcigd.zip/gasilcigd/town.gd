extends ProofDebug



var _told: Array[String] = []


func _listen() -> void :
	Game.notified.connect( func(text: Variant, _kind: String, _who: Player) -> void : _told.append(Text.say(text, "en")))


func _told_any(start: String) -> bool:
	return _told.any( func(line: String) -> bool: return line.begins_with(start))





func _scenario_readiness() -> void :
	await _wait(1.0)
	_listen()
	var readiness: = Readiness.current
	var truck: = Vehicle.named("Fire Truck")
	var calls: = CallService.current
	_check(readiness != null, "the readiness checklist is there")
	truck.water = truck.capacity * 0.3
	truck.fuel = truck.fuel_capacity * 0.5
	readiness.open_for([truck])
	await _wait(0.6)
	var row: Dictionary = readiness.state["vehicles"].get(String(truck.spec["name"]), {})
	print("readiness: after the call: %s" % [readiness.state])
	_check(readiness.state["due"] and row.get("tank") == false and row.get("fuel") == false, "the pumper's tank and diesel are on its checklist")
	_check(row.has("sets") and row.has("hose"), "its breathing sets and hose rolls are on it too")
	player.teleport(truck.global_position + truck.global_basis.x * 7.0 + Vector3(0, -2.6, 0))
	await _wait(0.6)
	var widget: Variant = Hud.current.widgets.get("readiness")
	var shown: String = widget.shown_text() if widget != null else ""
	print("readiness: the plate says '%s'" % shown)
	_check(shown.contains("BACK TO READINESS") or shown.contains("PRIPRAVLJENOSTI"), "the checklist is on the HUD at the station")
	await _snap("checklist")


	calls.reported = false
	Duty.current.report(player)
	await _wait(0.2)
	_check( not calls.reported and _told_any("Not back to readiness"), "the first report is warned that the unit is not ready")
	Duty.current.report(player)
	await _wait(0.2)
	_check(calls.reported, "pressed again, the unit is reported all the same")
	calls.reported = false


	for entry: Array in readiness._prompts:
		_check(entry[1] != "fuel", "no diesel is offered at the station")
		if entry[0] == truck:
			var prompt: Prompt = entry[2]
			_check(prompt.condition.call(player), "the '%s' prompt is offered at the station" % Text.say(prompt.action, "en"))
			prompt.triggered.emit(player)
	await _wait(0.5)
	await _snap("filling")
	var deadline: = Game.now() + 40.0
	while Game.now() < deadline and truck.water < truck.capacity - 0.5:
		await _wait(0.5)
	_check(truck.fuel < truck.fuel_capacity * 0.6 and readiness.state.get("due", false), "the diesel is not filled at the station")
	truck.fuel = truck.fuel_capacity
	deadline = Game.now() + 5.0
	while Game.now() < deadline and readiness.state.get("due", false):
		await _wait(0.5)
	print("readiness: water %.0f of %.0f, diesel %.0f of %.0f, due %s, told %s" % [truck.water, truck.capacity, truck.fuel, truck.fuel_capacity, readiness.state.get("due"), _told])
	_check(truck.water >= truck.capacity * 0.97 and truck.fuel >= truck.fuel_capacity * 0.95, "the tank is filled from the station, the diesel at a pump")
	_check( not readiness.state.get("due", true) and _told_any("✅ Back to readiness"), "everything done, the unit is back to readiness")
	_check(readiness.ready(), "a report now goes through without a warning")


	truck.water = truck.capacity * 0.5
	readiness.open_for([truck])
	_park(truck, Vector3(420, 0, 330), - PI / 2.0)
	await _wait(0.6)
	var offered: = false
	for entry: Array in readiness._prompts:
		if entry[0] == truck:
			offered = offered or entry[2].condition.call(player)
	_check( not offered, "away from the station the tank is not filled")
	await _done()




func _scenario_turnout() -> void :
	await _wait(1.0)
	var door: = Game.station.door_position

	var police: = Vector3(55.5, 0, -341.3)
	var road: = Guide.road_length(door, police)
	var crow: = door.distance_to(police)
	print("turnout: the police station is %.0f studs from the door as the crow flies, %.0f by road" % [crow, road])
	_check(road > crow * 1.2, "the road is longer than the crow's line (%.0f against %.0f)" % [road, crow])
	Alarm.forced = 1
	Alarm.begin()
	Game.incident = {"pos": police, "kind": "fire"}
	Alarm.station_distance = crow
	await _wait(0.3)
	print("turnout: the call's distance for its par: %.0f" % Alarm.station_distance)
	_check(absf(Alarm.station_distance - road) < 1.0, "the par is worked out from the road's length")
	_check(Duty.water_at < 0.0, "nobody with water there yet")

	_park(Vehicle.named("Command Vehicle"), police + Vector3(20, 0, 0))
	await _wait(0.5)
	_check(Duty.water_at < 0.0, "the command vehicle, with no water, is not the turnout")
	var tanker: = Vehicle.named("Tanker")
	_park(tanker, police + Vector3(-25, 0, 0))
	await _wait(0.5)
	print("turnout: water at the scene %.1f s after the call" % (Duty.water_at - Alarm.started_at))
	_check(Duty.water_at >= 0.0, "the tanker, with water aboard, is the turnout")
	Alarm.end()
	Game.incident = {}
	await _done()




func _scenario_townmap() -> void :
	await _wait(1.0)
	var map: = HudMap.current
	var truck: = Vehicle.named("Fire Truck")
	_park(truck, Vector3(-104, 0, 14), - PI / 2.0)
	await _wait(0.4)
	truck._board(player, "DoorCabLeft")
	await _wait(0.6)
	var far: = Vector3(760, 0, -330)
	Game.incident = {"pos": far, "kind": "fire"}
	Guide.current._clock = 0.0
	await _wait(1.0)
	var guide: = Guide.current
	var full_run: = 0.0
	for index in guide.full.size() - 1:
		full_run += guide.full[index].distance_to(guide.full[index + 1])
	print("townmap: chevrons over %d points; the map's way %d points, %.0f studs (length %.0f)" % [guide.points.size(), guide.full.size(), full_run, guide.full_length])
	_check(guide.full_length > float(Config.Guide.Reach) and full_run > float(Config.Guide.Reach) * 1.2, "the map has the whole way, past the chevrons' %d studs" % int(Config.Guide.Reach))
	_check(HudRadar.full_route.size() == guide.full.size(), "the map is given the whole way")
	map.visible = true
	map._free_mouse(true)
	await _wait(0.3)
	_check(map._hint.text.contains("km") or map._hint.text.contains(" m ") or map._hint.text.contains(" mi ") or map._hint.text.contains(" ft "), "under the sheet the way's length and time: '%s'" % map._hint.text)
	_check(map._streets.size() >= 10 and map._places.size() >= 8, "streets named (%d) and landmarks (%d)" % [map._streets.size(), map._places.size()])
	_check(Input.mouse_mode == Input.MOUSE_MODE_VISIBLE, "the pointer is free while the map is open")
	await _snap("call")


	Game.incident = {}
	var spot: = map._spot(-470.0, -60.0)
	map.set_waypoint_at(spot)
	await _wait(1.0)
	print("townmap: waypoint %s, the guide's way '%s' of %d points" % [Guide.waypoint.round(), guide.kind, guide.points.size()])
	_check(Guide.waypoint != Vector3.INF and guide.kind == "waypoint" and guide.points.size() >= 2, "a click on the map sets a waypoint the guide leads to")
	await _snap("waypoint")
	var event: = InputEventMouseButton.new()
	event.button_index = MOUSE_BUTTON_RIGHT
	event.pressed = true
	map._on_sheet_input(event)
	await _wait(1.0)
	_check(Guide.waypoint == Vector3.INF and guide.kind != "waypoint", "a right click clears it")
	map.visible = false
	await _wait(0.2)
	_check(Input.mouse_mode == Input.MOUSE_MODE_CAPTURED, "the map put away, the view has the mouse again")


	truck.fuel = truck.fuel_capacity * 0.2
	_park(truck, Vector3(420, 0, 330), 0.0)
	await _wait(0.5)
	guide._clock = 0.0
	await _wait(1.0)
	var last: Vector3 = guide.full[guide.full.size() - 1] if guide.full.size() > 0 else Vector3.INF
	print("townmap: low on diesel: the way is '%s', ending %.0f studs from the station door" % [guide.kind, last.distance_to(Game.station.door_position) if last != Vector3.INF else -1.0])
	_check(guide.kind == "home" and last != Vector3.INF and last.distance_to(Game.station.door_position) < 100.0, "low on diesel the guide leads home, not to a petrol station")
	truck.leave(player)
	await _done()




func _scenario_onfoot() -> void :
	await _wait(1.0)
	var settings: Dictionary = Config.Move

	var start: = _ground(Vector3(-60, 0, 30)) + Vector3(0, 0.3, 0)
	player.teleport(start)
	_look_at(start + Vector3(100, 5, 0))
	await _wait(0.5)
	var walked: = await _pace(1.2, false)
	var expected: = player.walk_speed * float(settings["Pace"])
	print("onfoot: walking at %.1f studs/s (walk speed %.0f, expected %.1f), crouching %s %.2f, frozen %s, ui %s" % [walked, player.walk_speed, expected, player.crouching, player._crouch_amount, player.frozen, Game.ui_open])
	_check(absf(walked - expected) < 1.5, "the walk is %.0f %% of the old pace (%.1f studs/s)" % [float(settings["Pace"]) * 100.0, walked])
	player.teleport(start)
	await _wait(0.3)
	var ran: = await _pace(1.2, true)
	print("onfoot: sprinting at %.1f studs/s, breath %.2f" % [ran, player.stamina])
	_check(ran > walked * (float(settings["Sprint"]) - 0.1), "Shift sprints (%.1f studs/s)" % ran)
	_check(player.stamina < 1.0, "a sprint uses breath")

	player.teleport(start)
	player.stamina = 1.0
	Input.action_press("move_forward")
	Input.action_press("sprint")
	await _wait(0.7)
	var side: = player.rig.global_basis.x.normalized()
	for frame in 3:
		_view(player.global_position + side * 14.0 + Vector3(0, 1.0, 0) + player.facing().normalized() * 4.0, player.global_position)
		await _snap("running%d" % frame)
		await _wait(0.12)
	Input.action_release("move_forward")
	Input.action_release("sprint")
	_view_player()
	await _wait(0.3)

	player.teleport(start)
	player.stamina = 0.04
	await _wait(0.1)
	var spent: = await _pace(1.6, true)
	print("onfoot: out of breath: %.1f studs/s, winded %s" % [spent, player._winded])
	_check(player._winded and spent < walked * 1.12, "out of breath, Shift no longer sprints")

	player.stamina = 1.0
	player._winded = false
	player.set_attr("Mask", true)
	player.teleport(start)
	await _pace(1.0, true)
	var masked_left: = player.stamina
	player.set_attr("Mask", null)
	player.stamina = 1.0
	player.teleport(start)
	await _pace(1.0, true)
	print("onfoot: a second of sprint leaves %.2f masked, %.2f without" % [masked_left, player.stamina])
	_check(masked_left < player.stamina - 0.02, "masked, a sprint takes more breath")
	await _snap("sprint")


	player.teleport(start)
	await _wait(0.6)
	var floor_y: = player.global_position.y
	var top: = floor_y
	await _tap("jump")
	for frame in 60:
		await get_tree().physics_frame
		top = maxf(top, player.global_position.y)
	print("onfoot: a jump rises %.2f studs (Config %.1f)" % [top - floor_y, float(settings["JumpHeight"])])
	_check(top - floor_y > float(settings["JumpHeight"]) * 0.7 and top - floor_y < float(settings["JumpHeight"]) + 0.5, "a jump is small (%.2f studs)" % (top - floor_y))


	var wall: = _wall(start + Vector3(4.0, 0, 0), 3.0)
	await _wait(0.3)
	player.teleport(start)
	_look_at(start + Vector3(100, 5, 0))
	await _wait(0.4)
	Input.action_press("move_forward")
	await _wait(0.15)
	await _tap("jump")
	var vaulted: = false
	for frame in 20:
		await get_tree().physics_frame
		vaulted = vaulted or player.vaulting()
		if vaulted and frame == 8:
			await _snap("vault")
	await _wait(0.6)
	Input.action_release("move_forward")
	var beyond: = player.global_position.x - wall.global_position.x
	print("onfoot: at a wall 3 studs high: vaulted %s, now %.1f studs past it" % [vaulted, beyond])
	_check(vaulted and beyond > 1.0, "a low wall is vaulted")
	wall.queue_free()
	var high: = _wall(start + Vector3(4.0, 0, 0), 7.0)
	await _wait(0.3)
	player.teleport(start)
	await _wait(0.4)
	Input.action_press("move_forward")
	await _wait(0.15)
	await _tap("jump")
	var vaulted_high: = false
	for frame in 30:
		await get_tree().physics_frame
		vaulted_high = vaulted_high or player.vaulting()
	Input.action_release("move_forward")
	await _wait(0.5)
	print("onfoot: at a wall 7 studs high: vaulted %s, now at x %.1f (the wall at %.1f)" % [vaulted_high, player.global_position.x, high.global_position.x])
	_check( not vaulted_high and player.global_position.x < high.global_position.x, "a high wall is not")
	high.queue_free()
	await _done()



func _pace(seconds: float, sprint: bool) -> float:
	Input.action_press("move_forward")
	if sprint:
		Input.action_press("sprint")
	await _wait(0.4)
	var from: = player.global_position
	var at: = Game.now()
	await _wait(seconds)
	var went: = Vector2(player.global_position.x - from.x, player.global_position.z - from.z).length() / maxf(Game.now() - at, 0.01)
	Input.action_release("move_forward")
	Input.action_release("sprint")
	await _wait(0.2)
	return went



func _wall(at: Vector3, height: float) -> StaticBody3D:
	var body: = StaticBody3D.new()
	body.collision_layer = World.LAYER_SOLID | World.LAYER_QUERY
	var shape: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = Vector3(0.8, height, 14.0)
	shape.shape = box
	body.add_child(shape)
	var mesh: = MeshInstance3D.new()
	var cube: = BoxMesh.new()
	cube.size = box.size
	mesh.mesh = cube
	body.add_child(mesh)
	Game.world.add_child(body)
	body.global_position = Vector3(at.x, _ground(at).y + height / 2.0, at.z)
	return body




func _scenario_indoorcam() -> void :
	await _wait(1.0)
	var house: = _house("Family house")
	var camera: = player.camera
	var off: Dictionary = Config.IndoorCamera.duplicate()
	var outs: Array[float] = [0.0, PI / 4.0, PI / 2.0, 3.0 * PI / 4.0, PI, -3.0 * PI / 4.0, - PI / 2.0, - PI / 4.0]

	Config.IndoorCamera["HouseReach"] = 0.0
	var best: Dictionary = {}
	var best_yaw: = 0.0
	var worst: = -1.0
	for room_name: String in house.rooms:
		var room: Dictionary = house.rooms[room_name]
		if room.get("panes", []).is_empty():
			continue
		_stand_in(house, room)
		camera.wanted_distance = 16.0
		for yaw: float in outs:
			camera.yaw = yaw
			camera.pitch = -0.15
			await _wait(0.35)
			var out: = _outside(house, room, camera.camera.global_position)
			if out > worst:
				worst = out
				best = room
				best_yaw = yaw
	print("indoorcam: %s; with no room known the view stands %.1f studs outside the %s" % [house.name, worst, best.get("name")])
	_stand_in(house, best)
	camera.yaw = best_yaw
	camera.pitch = -0.15
	await _wait(0.6)
	await _snap("before")
	Config.IndoorCamera["HouseReach"] = off["HouseReach"]
	camera._room_clock = 0.0
	await _wait(0.6)
	await _snap("after")
	var most: = 0.0
	var found: = false
	for yaw: float in outs:
		camera.yaw = yaw
		camera.pitch = -0.15
		await _wait(0.35)
		found = found or camera.indoors()
		most = maxf(most, _outside(house, best, camera.camera.global_position))
	print("indoorcam: the room known %s; the view at most %.2f studs outside it, %.1f behind the head" % [found, most, camera.distance])
	_check(found, "the camera knows the room the firefighter is in")
	_check(most < 0.05, "the view stays inside the room whichever way it is turned")
	_check(camera.distance <= float(Config.IndoorCamera.Reach) + 0.1, "indoors the view comes in closer")
	await _done()


func _stand_in(house: House, room: Dictionary) -> void :
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	player.teleport(house.lot * Vector3((low.x + high.x) / 2.0, low.y + 0.3, (low.z + high.z) / 2.0))
	await get_tree().physics_frame



func _outside(house: House, room: Dictionary, point: Vector3) -> float:
	var p: = house.lot.affine_inverse() * point
	var low: Vector3 = room["low"]
	var high: Vector3 = room["high"]
	var d: = Vector3(maxf(maxf(low.x - p.x, p.x - high.x), 0.0), maxf(maxf(low.y - p.y, p.y - high.y), 0.0), maxf(maxf(low.z - p.z, p.z - high.z), 0.0))
	return d.length()





func _scenario_traffic() -> void :
	await _wait(1.0)
	var traffic: = Traffic.current
	var own: Dictionary = Config.Traffic
	_check(traffic._wanted_cars() == (int(own["Cars"][0]) / 2 if Settings.quality <= Graphics.VERY_LOW else int(own["Cars"][Settings.quality])), "the town keeps %d cars at this Graphics setting" % traffic._wanted_cars())


	var car: = Traffic.Car.new()
	car.x = 0.0
	car.z = 0.0
	car.dx = 0.0
	car.dz = -1.0
	var behind: = [{"x": 0.0, "z": 120.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}]
	var alongside: = [{"x": 90.0, "z": 60.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}]
	var close_behind: = [{"x": 0.0, "z": 14.0, "dx": 0.0, "dz": -1.0, "speed": 20.0}]
	_check( not traffic._hears(car, behind).is_empty(), "a siren coming up the car's own street is heard 120 studs off")
	_check(traffic._hears(car, alongside).is_empty(), "one on the street alongside (90 studs aside) is not")
	car.deaf = true
	_check(traffic._hears(car, behind).is_empty(), "a deaf driver does not hear it up the street")
	_check( not traffic._hears(car, close_behind).is_empty(), "but does with it right behind")


	var truck: = Vehicle.named("Fire Truck")
	_park(truck, Vector3(-104, 0, 14), - PI / 2.0)
	await _wait(0.5)
	var placed: = traffic.put_on_way(truck.global_position, Vector3(700, 0, 300))
	print("traffic: %d cars put on the way east" % placed)
	var deaf_ahead: Traffic.Car = null
	for vehicle in traffic.vehicles:
		if vehicle.deaf:
			vehicle.deaf = false
	var nearest: = INF
	for vehicle in traffic.vehicles:
		var rx: = vehicle.x - truck.global_position.x
		var rz: = vehicle.z - truck.global_position.z
		if rx > 0.0 and rx * rx + rz * rz < nearest:
			nearest = rx * rx + rz * rz
			deaf_ahead = vehicle
	_check(deaf_ahead != null, "a car ahead of the truck")
	if deaf_ahead != null:
		deaf_ahead.deaf = true

		var before: = traffic.horned
		deaf_ahead.x = truck.global_position.x + 30.0
		deaf_ahead.z = truck.global_position.z
		truck.sound_horn()
		print("traffic: the horn at a deaf driver 30 studs ahead: deaf now %s, woken %d" % [deaf_ahead.deaf, traffic.horned - before])
		_check( not deaf_ahead.deaf, "a blast of the horn and the deaf driver hears")


	var made_before: = traffic.set_pieces
	Alarm.forced = 1
	Alarm.begin()
	Game.incident = {"pos": Vector3(760, 0, -330), "kind": "fire"}
	_park(truck, Vector3(-104, 0, 14), - PI / 2.0)
	await _wait(0.4)
	truck._board(player, "DoorCabLeft")
	await _wait(0.6)
	truck.siren = 1
	truck.blue_on = true
	Input.action_press("move_forward")
	await _wait(2.5)
	Input.action_release("move_forward")
	await _wait(1.2)
	var deaf_count: = 0
	for vehicle in traffic.vehicles:
		deaf_count += int(vehicle.deaf)
	print("traffic: on the turnout %d cars were put on the way ahead (%d deaf drivers on the road)" % [traffic.set_pieces - made_before, deaf_count])
	_check(traffic.set_pieces - made_before >= 2, "the turnout meets cars put on its way (%d)" % (traffic.set_pieces - made_before))
	_check(deaf_count >= 1, "one of them does not hear the siren")
	await _snap("turnout")
	truck.siren = 0
	truck.leave(player)
	Alarm.end()
	Game.incident = {}
	await _done()




func _scenario_waveoff() -> void :
	await _wait(1.0)
	var traffic: = Traffic.current
	var placed: = traffic.put_on_way(Vector3(-104, 0, 14), Vector3(700, 0, 300))
	await _wait(0.5)
	var car: Traffic.Car = null
	for vehicle in traffic.vehicles:
		if vehicle.v > 3.0 and traffic._segment_of(vehicle)["kind"] == "lane" and float(traffic._segment_of(vehicle)["length"]) - vehicle.s > 45.0:
			car = vehicle
			break
	if not _check(car != null, "a car driving along a lane (%d put on the road)" % placed):
		await _done()
		return

	var ahead: = Vector3(car.dx, 0, car.dz)
	var stand: = Vector3(car.x, 0, car.z) + ahead * 30.0
	player.teleport(_ground(stand) + Vector3(0, 3, 0))
	player.rig.rotation.y = atan2(ahead.x, ahead.z)
	player.set_attr("Geared", true)
	await _wait(0.1)
	var route_before: = car.route.duplicate()
	Bystanders.current.command(player)
	await _wait(0.2)
	print("waveoff: route changed %s, turning round %s" % [car.route != route_before, car.swing < 1.0])
	_check(car.route != route_before, "told to move away, the car takes another way")
	_view(Vector3(car.x, 0, car.z) + Vector3(0, 30, 0) - ahead * 20.0, Vector3(car.x, 0, car.z))
	await _wait(0.9)
	await _snap("turning")
	await _wait(4.0)
	var at: = player.root_position()
	var away: = Vector2(car.x - at.x, car.z - at.z)
	var going: = Vector2(car.dx, car.dz)
	print("waveoff: %.0f studs from them, heading %s" % [away.length(), "away" if away.dot(going) > 0.0 else "at them"])
	_check(away.dot(going) > 0.0 or away.length() > 45.0, "it is on its way off, not at them")
	_check(car.swing >= 1.0, "a turn round is done in a moment")
	await _snap("gone")
	await _done()
