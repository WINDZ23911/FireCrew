extends RefCounted




const BED: = Color8(128, 122, 114)
const SLEEPER: = Color8(96, 78, 62)
const RAIL: = Color8(150, 150, 154)
const CLEAR: = 34.0
const MOVE: = 80.0
const SLEEPER_EVERY: = 3.0
const RAIL_PIECE: = 40.0


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var moved: = 0
	for row in kit.rows_under("Map/Backdrop"):
		if not store.name_at(row) in ["FarHouse", "FarRoof", "FarTree", "FarTrunk", "Woods", "FarChimney"]:
			continue
		var place: = store.transform(row)
		if absf(place.origin.z - Train.LINE_Z) < CLEAR and place.origin.x > Train.FROM_X - 40.0 and place.origin.x < Train.TO_X + 40.0:
			place.origin.z += MOVE
			store.set_transform(row, place)
			moved += 1
	var parent: = kit.own_folder("Railway")
	var length: = Train.TO_X - Train.FROM_X
	var middle: = (Train.FROM_X + Train.TO_X) / 2.0
	var z: = Train.LINE_Z

	kit.box(parent, Transform3D(Basis(), Vector3(middle, 0.35, z)), Vector3(length, 0.7, 9.0), BED, "Pebble", "RailBed", PolishKit.SOLID)
	for side: float in [-1.0, 1.0]:

		var slope: = Transform3D(Basis(Vector3.UP, PI if side > 0.0 else 0.0), Vector3(middle, 0.35, z + side * 5.25))
		kit.wedge(parent, slope, Vector3(length, 0.7, 1.5), BED, "Pebble", "RailBank", PolishKit.LOOK)
	var x: = Train.FROM_X + 1.0
	var sleepers: = 0
	while x < Train.TO_X:
		kit.box(parent, Transform3D(Basis(), Vector3(x, 0.78, z)), Vector3(0.9, 0.18, 6.4), SLEEPER, "Wood", "Sleeper", PolishKit.LOOK)
		x += SLEEPER_EVERY
		sleepers += 1

	var piece: = Train.FROM_X
	while piece < Train.TO_X:
		var span: = minf(RAIL_PIECE, Train.TO_X - piece)
		for side: float in [-1.0, 1.0]:
			kit.box(parent, Transform3D(Basis(), Vector3(piece + span / 2.0, 0.98, z + side * Train.GAUGE / 2.0)), Vector3(span, 0.26, 0.24), RAIL, "Metal", "Rail", PolishKit.LOOK)
		piece += span
	return "a railway laid (%d sleepers; %d backdrop parts moved off it)" % [sleepers, moved]
