class_name HudDanger
extends Control



const LOW: = 0.25

var _edge: TextureRect
var _warning: Control
var _art: CanvasItem
var _text: Label
var _hurt: = 0.0
var _last_health: = -1.0
var _watched: Player
var _test_smoke: = false
var _warned: = false


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_edge = TextureRect.new()
	_edge.texture = Ui.image("vignette")
	_edge.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_edge.stretch_mode = TextureRect.STRETCH_SCALE
	_edge.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_edge.modulate = Color(200 / 255.0, 30 / 255.0, 20 / 255.0, 0.0)
	add_child(_edge)

	_warning = Ui.plate(Vector2(400, 48), "banner")
	_warning.visible = false
	add_child(_warning)
	_art = _warning.get_node("Plate")
	var picture: = Ui.icon("warning", 26, Color.WHITE)
	picture.position = Vector2(16, 11)
	_warning.add_child(picture)
	_text = Ui.display("", 22, Color.WHITE)
	_text.position = Vector2(52, 0)
	_text.size = Vector2(336, 48)
	_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_warning.add_child(_text)
	_test_smoke = OS.get_cmdline_user_args().has("--hud-open=demo")



func _smoke(player: Player) -> float:
	if _test_smoke:
		return 1.0
	var told: Variant = player.get_attr("Smoke")
	if told != null:
		return float(told)
	if FireService.current:
		return FireService.current.breathed_at(player.head_position())
	return 0.0


func _process(delta: float) -> void :
	var player: = Game.local_player
	if player == null:
		return

	if player != _watched:
		_watched = player
		_last_health = player.health
	if player.health < _last_health:
		_hurt = minf(1.0, _hurt + 0.35 + (_last_health - player.health) / maxf(player.max_health, 1.0) * 4.0)
	_last_health = player.health
	_hurt = maxf(0.0, _hurt - delta * 1.5)
	var share: = player.health / maxf(player.max_health, 1.0)
	var throb: = 0.0
	if share < LOW and player.health > 0.0:
		throb = (0.3 + 0.25 * (1.0 - share / LOW)) * (0.6 + 0.4 * sin(Game.now() * 5.0))
	_edge.modulate.a = maxf(0.7 * _hurt, throb)

	var on_air: bool = player.get_attr("Mask", false) == true and float(player.get_attr("AirBar", 0.0)) > 0.0
	_warning.visible = _smoke(player) > 0.05 and not on_air
	var warned: = _warning.visible or (share < LOW and player.health > 0.0)
	if warned and not _warned:
		Sounds.ui("ui_alert")
	_warned = warned
	if _warning.visible:
		var wearing: bool = player.get_attr("Scba", false) == true
		_text.text = Text.say(Text.m("hud.danger.maskOff" if wearing else "hud.danger.noSet"))
		var width: = maxf(340.0, _text.get_minimum_size().x + 68)
		_warning.size = Vector2(width, 48)
		_text.size.x = width - 64

		_warning.position = Vector2((size.x - width) / 2, size.y - (Ui.MARGIN + 92) - 48)
		_art.self_modulate.a = 1.0 - 0.35 * (0.5 + 0.5 * sin(Game.now() * 8.0))
