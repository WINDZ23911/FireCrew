extends RefCounted





const CABINET_EVERY: = 150.0
const SIGN_SPACING: = 140.0
const SIGNS_AT_MOST: = 44


const CENTRE: = Vector3(40, 0, 470)
const BASKETS_WITHIN: = 260.0
const NODE_CLEAR: = 26.0
const ROADS: = ["primary", "secondary", "tertiary", "residential", "living_street"]

const CABINET: = [Color8(184, 186, 180), Color8(196, 188, 168), Color8(150, 156, 150)]
const PLATE: = Color8(26, 68, 150)
const EDGE: = Color8(242, 242, 238)
const POST: = Color8(120, 124, 128)

const US_PLATE: = Color8(0, 106, 68)
const US_CENTRE: = Vector3(-320, 0, 40)
const DE_PLATE: = Color8(246, 246, 242)
const DE_INK: = Color8(22, 22, 24)
const DE_CENTRE: = Vector3(1850, 0, 450)
const US_WORDS: = {"North": "N", "South": "S", "East": "E", "West": "W", "Street": "ST", "Avenue": "AVE", "Lane": "LN", 
	"Road": "RD", "Drive": "DR", "Alley": "ALY", "Court": "CT", "Place": "PL", "Circle": "CIR", "Way": "WAY"}
const PETUNIAS: = [Color8(222, 60, 120), Color8(200, 40, 50), Color8(150, 70, 190), Color8(246, 244, 240), Color8(240, 120, 170)]


static func apply(kit: PolishKit) -> String:
	var folder: = kit.own_folder("StreetFurniture")
	var made: = kit.store.count
	var layout: = kit.layout()
	var cabinets: = 0
	for road: Dictionary in layout["roads"]:
		if ROADS.has(road["class"]):
			cabinets += _cabinets(kit, folder, road)
	var signs: = _name_signs(kit, folder, layout)
	var baskets: = _baskets(kit, folder)
	return "street furniture: %d cabinets, %d street name plates, %d lamp baskets (%d parts)" % [cabinets, signs, baskets, kit.store.count - made]



static func _pavement_back(kit: PolishKit, on_road: Vector3, across: Vector3, half: float) -> float:
	var found: = -1.0
	var out: = half + 1.0
	while out < half + 16.0:
		var surface: = kit.surface_at(on_road + across * out)
		if surface == "pavement":
			found = out
		elif found > 0.0 and surface != "kerb" and surface != "kerbstone":
			break
		out += 1.0
	return found


static func _near_node(kit: PolishKit, at: Vector3, within: float) -> bool:
	for node: Dictionary in kit.layout()["nodes"]:
		if Vector2(float(node["x"]) - at.x, float(node["z"]) - at.z).length() < within:
			return true
	return false



static func _cabinets(kit: PolishKit, folder: int, road: Dictionary) -> int:
	var half: = float(road["width"]) / 2.0
	var rng: = kit.rng("cabinets:%s:%s" % [road.get("name", ""), str(road["points"][0])])
	var made: = 0
	for spot: Array in PolishKit.along_road(road["points"], CABINET_EVERY, rng.randf_range(30.0, CABINET_EVERY)):
		var on_road: Vector3 = spot[0]
		var way: Vector3 = spot[1]
		var side: = 1.0 if rng.randf() < 0.5 else -1.0
		var across: = Vector3( - way.z, 0, way.x) * side
		var back: = _pavement_back(kit, on_road, across, half)
		if back < 0.0 or _near_node(kit, on_road, NODE_CLEAR):
			continue
		var at: = on_road + across * (back - 1.1)

		if kit.surface_at(at + way * 3.0) != "pavement" or kit.surface_at(at - way * 3.0) != "pavement":
			continue
		var behind: = kit.surface_at(at + across * 2.0)
		if ["driveway", "path", "paving", "lane", "road", "parking", "crossover"].has(behind):
			continue
		if not (StreetKit.clear_below(kit, at, 1.0, 6.0, 0.65) and StreetKit.clear_below(kit, at + way * 1.2, 0.8, 6.0, 0.65) and StreetKit.clear_below(kit, at - way * 1.2, 0.8, 6.0, 0.65)):
			continue
		_cabinet(kit, folder, PolishKit.facing(at, - across), CABINET[rng.randi_range(0, CABINET.size() - 1)])
		made += 1
	return made


static func _cabinet(kit: PolishKit, folder: int, place: Transform3D, color: Color) -> void :
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 0.25, 0)), Vector3(2.9, 0.5, 1.3), Color8(120, 120, 116), "Concrete", "CabinetPlinth")
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 2.3, 0)), Vector3(2.7, 3.6, 1.1), color, "Metal", "Cabinet")
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 4.15, 0)), Vector3(2.9, 0.12, 1.3), color.darkened(0.15), "Metal", "CabinetLid")
	kit.box(folder, place * Transform3D(Basis(), Vector3(0, 2.3, -0.56)), Vector3(0.04, 3.2, 0.02), color.darkened(0.35), "Metal", "CabinetSeam")

	kit.box(folder, place * Transform3D(Basis(Vector3.BACK, PI / 4), Vector3(-0.7, 3.3, -0.57)), Vector3(0.42, 0.42, 0.02), Color8(246, 200, 30), "SmoothPlastic", "CabinetWarning")



static func _name_signs(kit: PolishKit, folder: int, layout: Dictionary) -> int:
	var nodes: Array = layout["nodes"]
	var placed: Array = []
	for road: Dictionary in layout["roads"]:
		var road_name: String = road.get("name", "")
		if road_name.is_empty() or not ROADS.has(road["class"]) or placed.size() >= SIGNS_AT_MOST:
			continue
		var points: Array = road["points"]
		for end in 2:
			var node: Dictionary = nodes[int(road["from"] if end == 0 else road["to"]) - 1]
			if node["kind"] != "junction":
				continue
			var corner: = Vector3(float(node["x"]), 0, float(node["z"]))
			var first: Array = points[0] if end == 0 else points[points.size() - 1]
			var second: Array = points[1] if end == 0 else points[points.size() - 2]
			var way: = (Vector3(float(second[0]), 0, float(second[1])) - Vector3(float(first[0]), 0, float(first[1]))).normalized()
			var near: = false
			for other: Array in placed:
				if other[0] == road_name and (other[1] as Vector3).distance_to(corner) < SIGN_SPACING:
					near = true
			if near or way == Vector3.ZERO:
				continue
			var half: = float(road["width"]) / 2.0
			var across: = Vector3( - way.z, 0, way.x)
			for along: float in [half + 8.0, half + 12.0, half + 16.0]:
				var on_road: = corner + way * along
				if not kit.paved_street(on_road, across, half + 4.0):
					break
				var back: = _pavement_back(kit, on_road, across, half)
				if back < 0.0:
					continue
				var at: = on_road + across * (back - 1.4)
				if StreetKit.clear_below(kit, at, 0.7, 6.0, 0.65):
					_plate(kit, folder, at, across, road_name)
					placed.append([road_name, corner])
					break
	return placed.size()



static func _plate(kit: PolishKit, folder: int, at: Vector3, way: Vector3, words: String) -> void :
	var plate: = PLATE
	var edge: = EDGE
	if Edition.id() == "de":
		plate = DE_PLATE
		edge = DE_INK
	elif Edition.id() == "us":
		plate = US_PLATE
		var short: Array[String] = []
		for word in words.split(" "):
			short.append(US_WORDS.get(word, word.to_upper()))
		words = " ".join(short)
	kit.post(folder, at, 10.2, 0.32, POST, "Metal", "StreetSignPost")
	var width: = clampf(words.length() * 0.36 + 0.9, 4.2, 8.6)
	for facing: float in [1.0, -1.0]:
		var face: = PolishKit.facing(at, way * facing).translated_local(Vector3(0, 9.3, -0.12))
		kit.box(folder, face, Vector3(width + 0.22, 1.42, 0.06), edge, "SmoothPlastic", "StreetSignEdge")
		StreetKit.board(kit, folder, face.translated_local(Vector3(0, 0, -0.06)), Vector2(width, 1.2), plate, words, edge, "StreetSign")



static func _baskets(kit: PolishKit, folder: int) -> int:
	var store: = kit.store
	var arms: = store.rows_named("LampArm")
	var made: = 0
	for post: int in store.rows_named("LampPost"):
		var foot: = store.position(post)
		foot.y = 0.0
		if foot.distance_to(CENTRE if Edition.is_metlika() else (DE_CENTRE if Edition.id() == "de" else US_CENTRE)) > BASKETS_WITHIN or kit.building_distance(foot, 80.0) > 80.0:
			continue
		var reach: = Vector3.ZERO
		for arm: int in arms:
			var at: = store.position(arm)
			if Vector2(at.x - foot.x, at.z - foot.z).length() < 6.0:
				reach = Vector3(at.x - foot.x, 0, at.z - foot.z).normalized()
				break
		if reach == Vector3.ZERO:
			continue
		var out: = - reach
		var hook: = foot + Vector3(0, 12.0, 0) + out * 1.4
		kit.rod(folder, foot + Vector3(0, 12.6, 0), hook + Vector3(0, 0.6, 0), 0.12, POST.darkened(0.3), "Metal", "BasketBracket")
		kit.rod(folder, hook + Vector3(0, 0.6, 0), hook, 0.06, POST.darkened(0.3), "Metal", "BasketChain")

		var bloom: Color = PETUNIAS[(made * 3 + int(absf(foot.x))) % PETUNIAS.size()]
		kit.ball(folder, hook - Vector3(0, 1.3, 0), Vector3(2.8, 2.5, 2.8), bloom, "Fabric", "BasketFlowers")
		kit.ball(folder, hook - Vector3(0, 1.75, 0), Vector3(3.05, 0.9, 3.05), Color8(70, 118, 58), "LeafyGrass", "BasketLeaves")
		made += 1
	return made
