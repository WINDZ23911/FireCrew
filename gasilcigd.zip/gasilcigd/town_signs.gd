class_name TownSigns
extends RefCounted










const EXPORTED: = {
	"Market|MARKET": "KOVAČIČ", 
	"Market|Market": "Trgovina z živili", 
	"Shop|Gostilna": "Gostilna Zupančič", 
	"Naselje Borisa Kidriča 9|Avtodeli  ·  Oblačila": "Avtodeli Hribar  ·  Oblačila Golob", 
	"Naselje Borisa Kidriča 8|Pošta  ·  Kavarna": "Kavarna Mlakar", 
}

const PLANS: = {
	"MARKET": "TRGOVINA ŽAGAR", 
	"KAVARNA": "KAVARNA KOS", 
}




static func exported(words: Variant, model_name: String, part_name: String) -> Variant:
	var said: = Text.say(words, "sl")
	if part_name == "BusBlind":
		return _destination(said)
	return EXPORTED.get(model_name + "|" + said, words)



static func planned(words: String) -> String:
	return PLANS.get(words, words)




static func _destination(said: String) -> String:
	var bits: = said.split(" ", false, 1)
	if bits.size() == 2 and bits[0].is_valid_int():
		return bits[1]
	if said.is_valid_int():
		return "METLIKA"
	return said
