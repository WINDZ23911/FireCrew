extends RefCounted




const SPACING: = 88.0
const HEIGHT: = 31.0
const ARM: = 9.0
const SAG: = 0.035
const WIRE_PIECES: = 4
const TOWN_CLEARANCE: = 85.0
const ROADS: = ["primary", "secondary", "tertiary", "residential", "track"]

const WOOD: = Color(0.36, 0.27, 0.2)
const PORCELAIN: = Color(0.88, 0.88, 0.85)
const WIRE: = Color(0.16, 0.16, 0.17)
const STEEL: = Color(0.52, 0.55, 0.57)


static func apply(kit: PolishKit) -> String:
	var parent: = kit.own_folder("PowerLines")
	var rng: = kit.rng("power lines")
	var poles: = 0
	var roads: Array = kit.layout()["roads"]
	for index in roads.size():
		var road: Dictionary = roads[index]
		if not ROADS.has(road["class"]):
			continue
		var side: = 1.0 if rng.randf() < 0.5 else -1.0
		var setback: = float(road["width"]) / 2.0 + 6.0
		var last: Array = []
		var since: = SPACING
		var points: Array = road["points"]
		for leg in points.size() - 1:
			var a: = Vector3(float(points[leg][0]), 0, float(points[leg][1]))
			var b: = Vector3(float(points[leg + 1][0]), 0, float(points[leg + 1][1]))
			var length: = a.distance_to(b)
			if length < 1.0:
				continue
			var along: = (b - a) / length
			var across: = Vector3( - along.z, 0, along.x) * side
			var walked: = SPACING - since
			while walked < length:
				var on_road: = a + along * walked
				walked += SPACING
				var foot: = _spot(kit, on_road, across, setback)
				if foot == Vector3.INF:
					last = []
					continue
				var ends: = _pole(kit, parent, foot, along, poles % 6 == 3, across)
				poles += 1
				if not last.is_empty() and (last[0] as Vector3).distance_to(ends[0]) < SPACING * 1.6:
					for wire in 3:
						_wire(kit, parent, last[wire], ends[wire])
				last = ends
			since = length - (walked - SPACING)
	return "%d power poles" % poles




static func _spot(kit: PolishKit, on_road: Vector3, across: Vector3, setback: float) -> Vector3:
	if kit.building_distance(on_road, TOWN_CLEARANCE) < TOWN_CLEARANCE or kit.paved_street(on_road, across, setback):
		return Vector3.INF
	for extra: float in [0.0, 4.0, 8.0]:
		var foot: = on_road + across * (setback + extra)
		if kit.open_ground(foot, 3.0) and kit.building_distance(foot, TOWN_CLEARANCE) == INF:
			return foot
	return Vector3.INF



static func _pole(kit: PolishKit, parent: int, foot: Vector3, along: Vector3, transformer: bool, toward_road: Vector3) -> Array:
	var lean: = Basis.looking_at(along, Vector3.UP)
	kit.post(parent, foot + Vector3(0, -1, 0), HEIGHT + 1.0, 1.1, WOOD, "Wood", "PowerPole", PolishKit.SOLID)
	var arm_at: = foot + Vector3(0, HEIGHT - 1.6, 0)
	kit.box(parent, Transform3D(lean, arm_at), Vector3(ARM, 0.55, 0.55), WOOD, "Wood", "PoleArm")

	for x: float in [-1.0, 1.0]:
		var from: = foot + Vector3(0, HEIGHT - 4.2, 0)
		var to: = arm_at + lean.x * (x * 2.6) + Vector3(0, -0.3, 0)
		kit.rod(parent, from, to, 0.18, STEEL, "Metal", "PoleStrut")
	var ends: Array = []
	for x: float in [ - ARM / 2.0 + 0.6, 0.0, ARM / 2.0 - 0.6]:
		var base: Vector3 = arm_at + lean.x * x + Vector3(0, 0.27, 0)
		kit.post(parent, base, 0.9, 0.42, PORCELAIN, "SmoothPlastic", "Insulator")
		ends.append(base + Vector3(0, 0.75, 0))
	if transformer:
		var can: = foot + Vector3(0, HEIGHT - 9.5, 0) + toward_road * -1.7
		kit.post(parent, can, 3.4, 2.3, STEEL, "Metal", "Transformer")
		kit.post(parent, can + Vector3(0, 3.4, 0), 0.25, 2.5, STEEL.darkened(0.2), "Metal", "TransformerLid")
		kit.box(parent, Transform3D(lean, can + Vector3(0, 1.0, 0) + toward_road * 0.9), Vector3(0.6, 0.4, 1.4), STEEL.darkened(0.3), "Metal", "TransformerBracket")
	return ends



static func _wire(kit: PolishKit, parent: int, from: Vector3, to: Vector3) -> void :
	var sag: = from.distance_to(to) * SAG
	var previous: = from
	for piece in range(1, WIRE_PIECES + 1):
		var t: = float(piece) / WIRE_PIECES
		var point: = from.lerp(to, t) + Vector3(0, -4.0 * sag * t * (1.0 - t), 0)
		kit.rod(parent, previous, point, 0.12, WIRE, "Metal", "PowerWire")
		previous = point
