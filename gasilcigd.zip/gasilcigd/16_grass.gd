extends RefCounted



static func start(main: Node) -> void :
	if Ground.current == null:
		return
	var grass: = Grass.new()
	grass.name = "Grass"
	main.add_child(grass)
