class_name ToolModels
extends RefCounted







const RED: = Color8(196, 26, 24)
const DARK_RED: = Color8(140, 18, 16)
const WOOD: = Color8(204, 160, 104)
const WOOD_DARK: = Color8(150, 108, 64)
const BLACK: = Color8(26, 26, 28)
const CHARCOAL: = Color8(52, 54, 58)
const STEEL_DARK: = Color8(78, 81, 86)
const STEEL: = Color8(150, 154, 160)
const BRIGHT: = Color8(222, 226, 230)
const ALU: = Color8(188, 191, 196)
const ORANGE: = Color8(236, 116, 20)
const YELLOW: = Color8(246, 196, 24)
const HAZARD: = Color8(250, 210, 30)
const GREY: = Color8(186, 184, 178)
const WHITE: = Color8(236, 236, 232)
const GREEN: = Color8(40, 170, 70)
const BLUE: = Color8(30, 90, 200)

static var _made: Dictionary = {}


static func of(tool_name: String) -> Dictionary:
	if not _made.has(tool_name):
		_made[tool_name] = _build(tool_name)
	return _made[tool_name]


static func has(tool_name: String) -> bool:
	return tool_name in ["Axe", "Halligan bar", "Crowbar", "Bolt cutters", "Spreader", "Cutter", "Chainsaw", 
		"Extinguisher", "Floodlight", "Fan", "Thermal camera", "Divider", "Cone", "Tape post", "Tape reel", 
		"Attack roll", "Supply roll"]


static func _build(tool_name: String) -> Dictionary:
	var kit: = ShapeKit.new()
	var made: = {}
	match tool_name:
		"Axe":
			_axe(kit)
		"Halligan bar":
			_halligan(kit)
		"Crowbar":
			_crowbar(kit)
		"Bolt cutters":
			_bolt_cutters(kit)
		"Spreader":
			_hydraulic_body(kit)
			var jaws: = [ShapeKit.new(), ShapeKit.new()]
			_spreader_arms(jaws)
			made["JawL"] = jaws[0].commit()
			made["JawR"] = jaws[1].commit()
		"Cutter":
			_hydraulic_body(kit)
			_cutter_head(kit)
			var blades: = [ShapeKit.new(), ShapeKit.new()]
			_cutter_blades(blades)
			made["JawL"] = blades[0].commit()
			made["JawR"] = blades[1].commit()
		"Chainsaw":
			_chainsaw(kit)
		"Extinguisher":
			_extinguisher(kit)
			var horn: = ShapeKit.new()
			_extinguisher_horn(horn)
			made["Horn"] = horn.commit()
			var hose: = ShapeKit.new()
			hose.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, 1.6, -0.14), Vector3(0.1, 1.48, -0.28), Vector3(0.2, 1.25, -0.3), Vector3(0.235, 0.95, -0.3), Vector3(0.225, 0.76, -0.3)], 0.04, 6, false)
			made["Hose"] = hose.commit()
		"Floodlight":
			_floodlight(kit)
		"Fan":
			_fan(kit)
		"Thermal camera":
			_thermal_camera(kit)
		"Divider":
			_divider(kit)
		"Cone":
			_cone(kit)
		"Tape post":
			_tape_post(kit)
		"Tape reel":
			_tape_reel(kit)
		"Attack roll", "Supply roll":
			_hose_roll(kit, tool_name == "Supply roll")
		"Truck outlet":
			_truck_outlet(kit)
		"Truck intake":
			_truck_intake(kit)
	made["body"] = kit.commit()
	return made



static func instance(tool_name: String) -> Node3D:
	var made: = of(tool_name)
	var root: = Node3D.new()
	root.name = "Model"
	for part: String in made:
		var mesh: = MeshInstance3D.new()
		mesh.name = part
		mesh.mesh = made[part]
		root.add_child(mesh)
	return root








static func _axe(k: ShapeKit) -> void :
	k.tube(ShapeKit.PAINT, WOOD, [Vector3(0, -0.94, 0), Vector3(0, -0.86, 0), Vector3(0, -0.7, 0), Vector3(0, 0.4, 0), Vector3(0, 1.4, 0), Vector3(0, 1.98, 0)], 
		[0.08, 0.1, 0.078, 0.072, 0.066, 0.062], 12)
	for y: float in [-0.2, 0.55, 1.15]:
		k.tube(ShapeKit.PAINT, WOOD_DARK, [Vector3(0.0, y, 0), Vector3(0.0, y + 0.32, 0)], 0.0725 - y * 0.005, 12, false)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, -0.84, 0), Vector3(0, -0.18, 0)], 0.088, 12)
	for index in 6:
		k.ring(ShapeKit.RUBBER, BLACK, Vector3(0, -0.76 + index * 0.11, 0), Vector3.UP, 0.088, 0.016, 12)
	k.tube(ShapeKit.PAINT, HAZARD, [Vector3(0, 1.44, 0), Vector3(0, 1.6, 0)], 0.07, 12, false)
	k.tube(ShapeKit.PAINT, BLACK, [Vector3(0, 1.52, 0), Vector3(0, 1.54, 0)], 0.072, 12, false)

	k.box(ShapeKit.PAINT, RED, Vector3(-0.12, 1.72, -0.22), Vector3(0.12, 2.36, 0.22), 0.04)
	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.05, 2.35, -0.07), Vector3(0.05, 2.4, 0.07), 0.01)
	k.slab(ShapeKit.PAINT, RED, Vector3(0, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.16, 1.78], [0.4, 1.73], [0.6, 1.64], [0.6, 2.44], [0.4, 2.36], [0.16, 2.31]], 0.15)
	k.slab(ShapeKit.METAL, BRIGHT, Vector3(0, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.56, 1.66], [0.7, 1.58], [0.8, 1.62], [0.85, 2.03], [0.8, 2.46], [0.7, 2.5], [0.56, 2.42]], 0.07)
	k.slab(ShapeKit.METAL, STEEL, Vector3(0, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.52, 1.67], [0.6, 1.63], [0.6, 2.45], [0.52, 2.41]], 0.11)
	k.tube(ShapeKit.PAINT, RED, [Vector3(0, 2.05, 0.2), Vector3(0, 2.03, 0.45), Vector3(0, 1.98, 0.68), Vector3(0, 1.92, 0.84)], 
		[0.1, 0.075, 0.045, 0.012], 4)
	k.tube(ShapeKit.METAL, BRIGHT, [Vector3(0, 1.95, 0.74), Vector3(0, 1.915, 0.86)], [0.03, 0.006], 4, false)





static func _halligan(k: ShapeKit) -> void :
	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0, -1.16, 0), Vector3(0, 1.48, 0)], 0.066, 6)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, -0.55, 0), Vector3(0, 0.45, 0)], 0.078, 10)
	for y: float in [-0.55, 0.45]:
		k.ring(ShapeKit.RUBBER, BLACK, Vector3(0, y, 0), Vector3.UP, 0.08, 0.018, 10)
	for y: float in [-0.95, 1.12]:
		k.tube(ShapeKit.PAINT, HAZARD, [Vector3(0, y, 0), Vector3(0, y + 0.12, 0)], 0.07, 6, false)
	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.1, 1.4, -0.11), Vector3(0.1, 1.68, 0.11), 0.03)
	k.slab(ShapeKit.METAL, STEEL, Vector3(0, 1.58, 0), Vector3(0, 0, -1), Vector3(1, 0, 0), 
		[[-0.06, -0.11], [0.5, -0.17], [0.76, -0.17], [0.82, 0.0], [0.76, 0.17], [0.5, 0.17], [-0.06, 0.11]], 0.08)
	k.slab(ShapeKit.METAL, BRIGHT, Vector3(0, 1.58, 0), Vector3(0, 0, -1), Vector3(1, 0, 0), 
		[[0.74, -0.17], [0.86, -0.15], [0.88, 0.15], [0.74, 0.17]], 0.04)
	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0.08, 1.55, 0), Vector3(0.4, 1.53, 0), Vector3(0.62, 1.46, 0), Vector3(0.72, 1.42, 0)], [0.075, 0.055, 0.025, 0.006], 6)

	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.13, -1.22, -0.06), Vector3(0.13, -1.08, 0.06), 0.025)
	for side: float in [-1.0, 1.0]:
		var x: = side * 0.075
		k.tube(ShapeKit.METAL, STEEL, [Vector3(x, -1.18, 0), Vector3(x * 1.2, -1.45, -0.05), Vector3(x * 1.3, -1.72, -0.16), Vector3(x * 1.32, -1.9, -0.26)], 
			[0.058, 0.05, 0.035, 0.01], 5)




static func _crowbar(k: ShapeKit) -> void :
	var neck: = [Vector3(0, -1.06, 0), Vector3(0, 0.9, 0), Vector3(0, 1.08, -0.03), Vector3(0, 1.22, -0.12), Vector3(0, 1.32, -0.25), Vector3(0, 1.34, -0.38), Vector3(0, 1.28, -0.48)]
	k.tube(ShapeKit.PAINT, RED, neck, 0.06, 6)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, -0.5, 0), Vector3(0, 0.3, 0)], 0.072, 10)
	for side: float in [-1.0, 1.0]:
		k.tube(ShapeKit.METAL, BRIGHT, [Vector3(side * 0.025, 1.28, -0.47), Vector3(side * 0.05, 1.2, -0.55), Vector3(side * 0.06, 1.12, -0.58)], [0.035, 0.028, 0.008], 4)
	k.slab(ShapeKit.METAL, BRIGHT, Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3.UP, 
		[[-0.055, -1.02], [0.055, -1.02], [0.1, -1.28], [0.08, -1.34], [-0.08, -1.34], [-0.1, -1.28]], 0.05)




static func _bolt_cutters(k: ShapeKit) -> void :
	for side: float in [-1.0, 1.0]:
		k.tube(ShapeKit.PAINT, RED, [Vector3(side * 0.22, -1.2, 0), Vector3(side * 0.12, 0.3, 0), Vector3(side * 0.07, 0.9, 0)], 0.05, 8)
		k.tube(ShapeKit.RUBBER, BLACK, [Vector3(side * 0.225, -1.22, 0), Vector3(side * 0.165, -0.42, 0)], 0.068, 10)
		k.lathe(ShapeKit.RUBBER, BLACK, Vector3(side * 0.226, -1.24, 0), Vector3( - side * 0.07, 1, 0), [[0.0, 0.0], [0.0, 0.07], [0.05, 0.075]], 10)
		k.box(ShapeKit.METAL, BRIGHT, Vector3(side * 0.015, 1.15, -0.03), Vector3(side * 0.16, 1.52, 0.03), 0.02)
	for z: float in [-0.065, 0.065]:
		k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.21, 0.82, z - 0.02), Vector3(0.21, 1.22, z + 0.02), 0.03)
	for at: Vector3 in [Vector3(-0.12, 0.95, 0), Vector3(0.12, 0.95, 0), Vector3(0.0, 1.15, 0)]:
		k.tube(ShapeKit.METAL, BRIGHT, [at - Vector3(0, 0, 0.1), at + Vector3(0, 0, 0.1)], 0.04, 8)








static func _hydraulic_body(k: ShapeKit) -> void :
	k.lathe(ShapeKit.PAINT, ORANGE, Vector3(0, -0.48, 1.0), Vector3(0, 0, -1), 
		[[0.0, 0.0], [0.0, 0.24], [0.06, 0.3], [1.5, 0.3], [1.56, 0.26]], 16)
	for z: float in [0.72, 0.42, 0.1]:
		k.ring(ShapeKit.PAINT, Color8(210, 96, 12), Vector3(0, -0.48, z), Vector3.BACK, 0.3, 0.02, 16)
	k.tube(ShapeKit.PAINT, BLACK, [Vector3(0, -0.48, -0.12), Vector3(0, -0.48, -0.3)], 0.305, 16, false)
	k.tube(ShapeKit.PAINT, WHITE, [Vector3(0, -0.48, -0.17), Vector3(0, -0.48, -0.25)], 0.307, 16, false)
	k.lathe(ShapeKit.METAL, STEEL_DARK, Vector3(0, -0.48, -0.5), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.33], [0.05, 0.36], [0.3, 0.36], [0.32, 0.0]], 16)

	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, -0.24, 0.42), Vector3(0, -0.02, 0.36), Vector3(0, 0.02, 0.2), Vector3(0, 0.02, -0.2), Vector3(0, -0.02, -0.36), Vector3(0, -0.24, -0.42)], 0.05, 8)
	for z: float in [0.42, -0.42]:
		k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.12, -0.27, z - 0.06), Vector3(0.12, -0.17, z + 0.06), 0.02)

	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0, -0.48, 1.0), Vector3(0, -0.48, 1.1)], 0.1, 10)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.36, -0.48, 1.1), Vector3(0.36, -0.48, 1.1)], 0.065, 10)
	for x: float in [-0.36, 0.36]:
		k.lathe(ShapeKit.RUBBER, BLACK, Vector3(x, -0.48, 1.1), Vector3(signf(x), 0, 0), [[0.0, 0.0], [0.0, 0.085], [0.04, 0.085], [0.06, 0.0]], 10)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, -0.3, 1.08), Vector3.UP, [[0.0, 0.0], [0.0, 0.12], [0.08, 0.12], [0.1, 0.06], [0.1, 0.0]], 6)
	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0, -0.42, 1.08), Vector3(0, -0.3, 1.08)], 0.04, 6)

	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0, -0.7, 0.92), Vector3(0, -1, 0.5), [[0.0, 0.0], [0.0, 0.09], [0.16, 0.09], [0.18, 0.06], [0.18, 0.0]], 10)
	k.tube(ShapeKit.RUBBER, Color8(28, 30, 34), [Vector3(0, -0.84, 0.99), Vector3(0, -0.95, 1.2), Vector3(0, -0.98, 1.5), Vector3(0, -1.0, 1.75)], 0.06, 8, true)

	k.box(ShapeKit.PAINT, BLACK, Vector3(0.24, -0.62, 0.3), Vector3(0.31, -0.36, 0.78), 0.01)
	k.box(ShapeKit.PAINT, WHITE, Vector3(0.305, -0.55, 0.38), Vector3(0.315, -0.43, 0.7), 0.0)




static func _spreader_arms(jaws: Array) -> void :
	var arm: = [[0.04, 0.68], [0.3, 0.66], [0.36, 0.82], [0.34, 1.25], [0.2, 1.7], [0.15, 1.86], [0.03, 1.86]]
	for index in 2:
		var side: = -1.0 if index == 0 else 1.0
		var k: ShapeKit = jaws[index]
		var outline: Array = []
		for p: Array in arm:
			outline.append([side * p[0], p[1]])
		k.slab(ShapeKit.PAINT, CHARCOAL, Vector3(0, -0.48, 0), Vector3(1, 0, 0), Vector3(0, 0, -1), outline, 0.24)
		k.slab(ShapeKit.PAINT, BLACK, Vector3(0, -0.48, 0), Vector3(1, 0, 0), Vector3(0, 0, -1), 
			[[side * 0.12, 0.9], [side * 0.26, 0.88], [side * 0.25, 1.25], [side * 0.15, 1.5]], 0.26)
		k.box(ShapeKit.METAL, BRIGHT, Vector3(minf(side * 0.02, side * 0.17), -0.6, -2.0), Vector3(maxf(side * 0.02, side * 0.17), -0.36, -1.82), 0.02)
		for tooth in 4:
			var y: = -0.58 + tooth * 0.06
			k.box(ShapeKit.METAL, STEEL, Vector3(minf(side * 0.0, side * 0.04), y, -1.98), Vector3(maxf(side * 0.0, side * 0.04), y + 0.03, -1.86), 0.0)
		k.tube(ShapeKit.METAL, BRIGHT, [Vector3(side * 0.22, -0.64, -0.75), Vector3(side * 0.22, -0.32, -0.75)], 0.06, 8)



static func _cutter_head(k: ShapeKit) -> void :
	for y: float in [-0.62, -0.34]:
		k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.2, y - 0.025, -1.0), Vector3(0.2, y + 0.025, -0.55), 0.02)
	k.tube(ShapeKit.METAL, BRIGHT, [Vector3(0, -0.68, -0.8), Vector3(0, -0.28, -0.8)], 0.12, 10)
	k.lathe(ShapeKit.METAL, STEEL_DARK, Vector3(0, -0.28, -0.8), Vector3.UP, [[0.0, 0.0], [0.0, 0.14], [0.04, 0.14], [0.04, 0.0]], 6)



static func _cutter_blades(blades: Array) -> void :
	var blade: = [[0.05, 0.7], [0.44, 0.7], [0.54, 1.05], [0.48, 1.4], [0.3, 1.66], [0.1, 1.76], [0.16, 1.4], [0.18, 1.2], [0.07, 1.0]]
	for index in 2:
		var side: = -1.0 if index == 0 else 1.0
		var k: ShapeKit = blades[index]
		var outline: Array = []
		for p: Array in blade:
			outline.append([side * p[0], p[1]])
		k.slab(ShapeKit.METAL, STEEL, Vector3(0, -0.48 + side * 0.04, 0), Vector3(1, 0, 0), Vector3(0, 0, -1), outline, 0.09)
		k.slab(ShapeKit.METAL, BRIGHT, Vector3(0, -0.48 + side * 0.04, 0), Vector3(1, 0, 0), Vector3(0, 0, -1), 
			[[side * 0.07, 1.0], [side * 0.18, 1.2], [side * 0.16, 1.4], [side * 0.1, 1.76], [side * 0.03, 1.5]], 0.095)










static func _chainsaw(k: ShapeKit) -> void :
	k.box(ShapeKit.PAINT, GREY, Vector3(-0.34, 0.0, -1.15), Vector3(0.34, 0.36, 0.0), 0.07)
	for z: float in [-0.3, -0.95]:
		k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.33, 0.16, z), Vector3(-0.41, 0.16, z)], 0.09, 10)
	k.box(ShapeKit.PAINT, ORANGE, Vector3(-0.32, 0.3, -1.1), Vector3(0.32, 0.72, -0.02), 0.12)
	k.box(ShapeKit.PAINT, CHARCOAL, Vector3(-0.23, 0.7, -0.64), Vector3(0.23, 0.79, -0.1), 0.04)
	k.lathe(ShapeKit.PAINT, BLACK, Vector3(0, 0.78, -0.37), Vector3.UP, [[0.0, 0.0], [0.0, 0.06], [0.05, 0.05], [0.06, 0.0]], 8)
	for index in 4:
		var z: = -0.95 + index * 0.12
		k.box(ShapeKit.PAINT, BLACK, Vector3(0.315, 0.42, z), Vector3(0.33, 0.6, z + 0.05), 0.0)
	k.box(ShapeKit.PAINT, WHITE, Vector3(-0.333, 0.5, -0.95), Vector3(-0.32, 0.6, -0.25), 0.0)
	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.3, 0.08, -1.26), Vector3(0.12, 0.42, -1.1), 0.05)
	for index in 3:
		k.box(ShapeKit.METAL, CHARCOAL, Vector3(-0.25 + index * 0.12, 0.12, -1.27), Vector3(-0.19 + index * 0.12, 0.38, -1.25), 0.0)

	k.tube(ShapeKit.PAINT, CHARCOAL, [Vector3(-0.32, 0.42, -0.62), Vector3(-0.42, 0.42, -0.62)], 0.27, 16)
	for index in 6:
		var angle: = TAU * index / 6.0
		k.box(ShapeKit.PAINT, BLACK, Vector3(-0.43, 0.42 + sin(angle) * 0.18 - 0.02, -0.62 + cos(angle) * 0.18 - 0.02), Vector3(-0.42, 0.42 + sin(angle) * 0.18 + 0.02, -0.62 + cos(angle) * 0.18 + 0.02), 0.0)
	k.tube(ShapeKit.PAINT, ORANGE, [Vector3(-0.42, 0.42, -0.62), Vector3(-0.46, 0.42, -0.62)], 0.12, 10)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.4, 0.68, -0.52), Vector3(-0.4, 0.69, -0.24)], 0.048, 8)

	k.box(ShapeKit.PAINT, CHARCOAL, Vector3(0.32, 0.04, -1.2), Vector3(0.47, 0.52, -0.4), 0.06)
	for z: float in [-0.62, -0.9]:
		k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0.47, 0.27, z), Vector3.RIGHT, [[0.0, 0.0], [0.0, 0.055], [0.04, 0.055], [0.04, 0.0]], 6)
	k.slab(ShapeKit.METAL, STEEL, Vector3(0.36, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[1.15, 0.06], [1.32, 0.1], [1.2, 0.18], [1.32, 0.26], [1.2, 0.34], [1.32, 0.42], [1.15, 0.5]], 0.04)

	k.slab(ShapeKit.METAL, BRIGHT, Vector3(0.44, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.75, 0.12], [2.34, 0.14], [2.5, 0.2], [2.56, 0.28], [2.5, 0.36], [2.34, 0.42], [0.75, 0.44]], 0.07)
	k.slab(ShapeKit.METAL, STEEL_DARK, Vector3(0.44, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.75, 0.21], [2.2, 0.225], [2.2, 0.335], [0.75, 0.35]], 0.075)
	k.slab(ShapeKit.METAL, BLACK, Vector3(0.425, 0, 0), Vector3(0, 0, -1), Vector3.UP, 
		[[0.75, 0.07], [2.36, 0.09], [2.56, 0.16], [2.64, 0.28], [2.56, 0.4], [2.36, 0.47], [0.75, 0.49]], 0.04)
	k.tube(ShapeKit.METAL, CHARCOAL, [Vector3(0.43, 0.28, -2.4), Vector3(0.455, 0.28, -2.4)], 0.07, 10)

	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.36, 0.06, -0.72), Vector3(-0.46, 0.5, -0.8), Vector3(-0.4, 0.92, -0.84), Vector3(-0.2, 1.02, -0.85), Vector3(0.24, 1.02, -0.85), 
		Vector3(0.4, 0.9, -0.84), Vector3(0.4, 0.55, -0.8)], 0.055, 8)
	k.slab(ShapeKit.PAINT, BLACK, Vector3(0, 0, -1.02), Vector3(1, 0, 0), Vector3.UP, [[-0.34, 0.7], [0.34, 0.7], [0.3, 1.12], [-0.3, 1.12]], 0.05)

	k.tube(ShapeKit.PAINT, ORANGE, [Vector3(0, 0.6, -0.05), Vector3(0, 0.62, 0.3)], 0.075, 10)
	k.tube(ShapeKit.RUBBER, Color8(40, 40, 42), [Vector3(0, 0.62, 0.3), Vector3(0, 0.37, 0.45), Vector3(0, 0.12, 0.6)], 0.088, 10)
	k.tube(ShapeKit.PAINT, ORANGE, [Vector3(0, 0.12, 0.6), Vector3(0, 0.07, 0.3), Vector3(0, 0.07, 0.0)], 0.065, 10)
	k.box(ShapeKit.PAINT, BLACK, Vector3(-0.035, 0.34, 0.28), Vector3(0.035, 0.5, 0.38), 0.015)
	k.box(ShapeKit.PAINT, CHARCOAL, Vector3(-0.03, 0.66, 0.24), Vector3(0.03, 0.72, 0.4), 0.015)
	k.box(ShapeKit.PAINT, RED, Vector3(0.1, 0.62, -0.06), Vector3(0.2, 0.66, 0.06), 0.015)








static func _extinguisher(k: ShapeKit) -> void :
	k.lathe(ShapeKit.PAINT, RED, Vector3(0, 0, 0), Vector3.UP, 
		[[0.06, 0.0], [0.06, 0.24], [0.1, 0.262], [1.28, 0.262], [1.42, 0.2], [1.52, 0.1], [1.55, 0.05], [1.55, 0.0]], 18)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, 0, 0), Vector3.UP, [[0.0, 0.0], [0.0, 0.25], [0.1, 0.268], [0.14, 0.24], [0.14, 0.0]], 18)
	k.tube(ShapeKit.PAINT, WHITE, [Vector3(0, 0.48, 0), Vector3(0, 1.02, 0)], 0.266, 18, false)
	for index in 3:
		var x: = -0.13 + index * 0.13
		k.box(ShapeKit.PAINT, RED if index == 1 else BLACK, Vector3(x - 0.045, 0.62, -0.275), Vector3(x + 0.045, 0.72, -0.262), 0.0)
	for y: float in [0.82, 0.88, 0.94]:
		k.box(ShapeKit.PAINT, CHARCOAL, Vector3(-0.15, y, -0.272), Vector3(0.15, y + 0.02, -0.262), 0.0)

	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0, 1.5, 0), Vector3.UP, [[0.0, 0.0], [0.0, 0.1], [0.08, 0.1], [0.08, 0.0]], 10)
	k.box(ShapeKit.PAINT, BLACK, Vector3(-0.1, 1.56, -0.13), Vector3(0.1, 1.72, 0.13), 0.035)
	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(-0.1, 1.64, 0.02), Vector3.LEFT, [[0.0, 0.0], [0.0, 0.085], [0.05, 0.09], [0.06, 0.0]], 12)
	k.lathe(ShapeKit.GLOW, WHITE, Vector3(-0.16, 1.64, 0.02), Vector3.LEFT, [[0.0, 0.0], [0.0, 0.075], [0.003, 0.0]], 12)
	k.box(ShapeKit.GLOW, GREEN, Vector3(-0.166, 1.66, 0.0), Vector3(-0.163, 1.69, 0.06), 0.0)
	k.box(ShapeKit.GLOW, RED, Vector3(-0.166, 1.6, -0.03), Vector3(-0.163, 1.63, 0.0), 0.0)

	k.tube(ShapeKit.PAINT, BLACK, [Vector3(0, 1.66, -0.1), Vector3(0, 1.74, 0.05), Vector3(0, 1.76, 0.36)], [0.045, 0.045, 0.04], 8)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(0, 1.72, -0.11), Vector3(0, 1.86, 0.0), Vector3(0, 1.86, 0.34)], 0.03, 6)

	k.tube(ShapeKit.METAL, BRIGHT, [Vector3(-0.12, 1.79, 0.08), Vector3(0.12, 1.79, 0.08)], 0.015, 5)
	k.ring(ShapeKit.PAINT, HAZARD, Vector3(0.18, 1.79, 0.08), Vector3.FORWARD, 0.06, 0.014, 10)

	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(0.17, 0.3, -0.34), Vector3(0.28, 0.4, -0.24), 0.01)



static func _extinguisher_horn(k: ShapeKit) -> void :
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, 0, 0.12), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.045], [0.18, 0.05], [0.3, 0.07], [0.36, 0.1], [0.38, 0.0]], 10)
	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0, 0, 0.16), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.048], [0.06, 0.048], [0.06, 0.0]], 8)





static func _floodlight(k: ShapeKit) -> void :
	k.box(ShapeKit.PAINT, YELLOW, Vector3(-0.5, 0.25, -0.18), Vector3(0.5, 0.95, 0.18), 0.07)
	k.box(ShapeKit.PAINT, BLACK, Vector3(-0.53, 0.22, -0.25), Vector3(0.53, 0.98, -0.16), 0.03)
	k.box(ShapeKit.METAL, Color8(196, 202, 208), Vector3(-0.45, 0.3, -0.262), Vector3(0.45, 0.9, -0.25), 0.0)
	for row in 3:
		for column in 6:
			var at: = Vector3(-0.35 + column * 0.14, 0.42 + row * 0.18, -0.265)
			k.box(ShapeKit.PAINT, Color8(250, 244, 214), at - Vector3(0.035, 0.035, 0.005), at + Vector3(0.035, 0.035, 0.0), 0.0)
	for index in 8:
		var x: = -0.42 + index * 0.12
		k.box(ShapeKit.PAINT, CHARCOAL, Vector3(x - 0.02, 0.3, 0.18), Vector3(x + 0.02, 0.9, 0.3), 0.005)
	k.tube(ShapeKit.PAINT, BLACK, [Vector3(-0.6, 0.6, 0), Vector3(-0.6, 0.08, 0), Vector3(0.6, 0.08, 0), Vector3(0.6, 0.6, 0)], 0.04, 8)
	for side: float in [-1.0, 1.0]:
		k.lathe(ShapeKit.RUBBER, BLACK, Vector3(side * 0.6, 0.6, 0), Vector3(side, 0, 0), [[0.0, 0.0], [0.0, 0.1], [0.08, 0.1], [0.1, 0.06], [0.1, 0.0]], 8)
	k.box(ShapeKit.PAINT, CHARCOAL, Vector3(-0.3, 0.0, -0.2), Vector3(0.3, 0.09, 0.2), 0.03)
	for x: float in [-0.25, 0.25]:
		for z: float in [-0.15, 0.15]:
			k.box(ShapeKit.RUBBER, BLACK, Vector3(x - 0.04, -0.02, z - 0.04), Vector3(x + 0.04, 0.01, z + 0.04), 0.0)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.25, 0.95, 0.1), Vector3(-0.25, 1.08, 0.1), Vector3(0.25, 1.08, 0.1), Vector3(0.25, 0.95, 0.1)], 0.045, 8)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0.3, 0.4, 0.18), Vector3.BACK, [[0.0, 0.0], [0.0, 0.06], [0.08, 0.05], [0.1, 0.0]], 8)
	k.tube(ShapeKit.RUBBER, ORANGE, [Vector3(0.3, 0.4, 0.26), Vector3(0.3, 0.36, 0.42), Vector3(0.36, 0.2, 0.5)], 0.03, 6)




static func _fan(k: ShapeKit) -> void :
	var at: = Vector3(0, 0.95, 0.0)
	k.lathe(ShapeKit.PAINT, RED, at + Vector3(0, 0, 0.32), Vector3(0, 0, -1), [[0.0, 0.82], [0.04, 0.86], [0.56, 0.84], [0.62, 0.8], [0.6, 0.74], [0.04, 0.76], [0.0, 0.0]], 24)
	for radius: float in [0.26, 0.5, 0.74]:
		k.ring(ShapeKit.METAL, STEEL, at + Vector3(0, 0, -0.3), Vector3.FORWARD, radius, 0.014, 24)
		k.ring(ShapeKit.METAL, STEEL, at + Vector3(0, 0, 0.32), Vector3.FORWARD, radius, 0.014, 24)
	for index in 8:
		var angle: = TAU * index / 8.0
		var out: = Vector3(cos(angle), sin(angle), 0)
		k.tube(ShapeKit.METAL, STEEL, [at + Vector3(0, 0, -0.3) + out * 0.08, at + Vector3(0, 0, -0.3) + out * 0.8], 0.012, 4, false)
		k.tube(ShapeKit.METAL, STEEL, [at + Vector3(0, 0, 0.32) + out * 0.08, at + Vector3(0, 0, 0.32) + out * 0.8], 0.012, 4, false)
	k.lathe(ShapeKit.PAINT, CHARCOAL, at + Vector3(0, 0, 0.42), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.2], [0.08, 0.24], [0.36, 0.24], [0.42, 0.14], [0.46, 0.0]], 14)
	for index in 6:
		var angle: = TAU * index / 6.0
		k.box(ShapeKit.PAINT, BLACK, at + Vector3(cos(angle) * 0.24 - 0.02, sin(angle) * 0.24 - 0.02, 0.1), at + Vector3(cos(angle) * 0.24 + 0.02, sin(angle) * 0.24 + 0.02, 0.38), 0.0)
	for index in 7:
		var angle: = TAU * index / 7.0
		var out: = Vector3(cos(angle), sin(angle), 0)
		var across: = Vector3( - sin(angle), cos(angle), 0)
		k.slab(ShapeKit.PAINT, BLACK, at + Vector3(0, 0, 0.0), out, (across + Vector3(0, 0, 0.6)).normalized(), 
			[[0.1, -0.08], [0.7, -0.14], [0.72, 0.1], [0.1, 0.06]], 0.025)
	k.lathe(ShapeKit.METAL, STEEL_DARK, at + Vector3(0, 0, -0.06), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.12], [0.06, 0.1], [0.1, 0.0]], 10)
	for x: float in [-0.9, 0.9]:
		k.tube(ShapeKit.METAL, STEEL, [Vector3(x, 0.08, 0.5), Vector3(x, 1.9, 0.4), Vector3(x, 1.9, -0.1), Vector3(x, 0.08, -0.5)], 0.045, 8)
		k.tube(ShapeKit.RUBBER, BLACK, [Vector3(x - 0.06, 0.2, 0.5), Vector3(x + 0.06, 0.2, 0.5)], 0.2, 14)
		k.tube(ShapeKit.METAL, STEEL, [Vector3(x - 0.07, 0.2, 0.5), Vector3(x + 0.07, 0.2, 0.5)], 0.08, 8)
		k.box(ShapeKit.RUBBER, BLACK, Vector3(x - 0.06, 0.0, -0.56), Vector3(x + 0.06, 0.08, -0.44), 0.02)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(-0.9, 1.9, 0.4), Vector3(0.9, 1.9, 0.4)], 0.045, 8)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(-0.3, 1.9, 0.4), Vector3(0.3, 1.9, 0.4)], 0.06, 10)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(-0.9, 0.08, -0.5), Vector3(0.9, 0.08, -0.5)], 0.045, 8)
	for x: float in [-0.9, 0.9]:
		k.tube(ShapeKit.METAL, STEEL, [Vector3(x, 0.95, 0.4), Vector3(signf(x) * 0.84, 0.95, 0.32)], 0.04, 6, false)
	k.box(ShapeKit.PAINT, BLACK, Vector3(0.55, 0.12, 0.25), Vector3(0.85, 0.42, 0.45), 0.03)
	k.box(ShapeKit.PAINT, RED, Vector3(0.62, 0.3, 0.45), Vector3(0.72, 0.38, 0.48), 0.01)
	k.tube(ShapeKit.RUBBER, ORANGE, [Vector3(0.7, 0.12, 0.45), Vector3(0.7, 0.04, 0.6), Vector3(0.6, 0.02, 0.8)], 0.03, 6)




static func _thermal_camera(k: ShapeKit) -> void :
	k.box(ShapeKit.PAINT, YELLOW, Vector3(-0.21, 0.3, -0.35), Vector3(0.21, 0.72, 0.35), 0.07)
	for z: float in [-0.33, 0.33]:
		k.box(ShapeKit.RUBBER, BLACK, Vector3(-0.225, 0.285, z - 0.035), Vector3(0.225, 0.33, z + 0.035), 0.015)
		k.box(ShapeKit.RUBBER, BLACK, Vector3(-0.225, 0.69, z - 0.035), Vector3(0.225, 0.735, z + 0.035), 0.015)
		for x: float in [-0.2, 0.2]:
			k.box(ShapeKit.RUBBER, BLACK, Vector3(x - 0.025, 0.3, z - 0.035), Vector3(x + 0.025, 0.72, z + 0.035), 0.01)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, 0.52, -0.35), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.15], [0.12, 0.15], [0.14, 0.12], [0.14, 0.0]], 14)
	k.lathe(ShapeKit.METAL, Color8(30, 20, 40), Vector3(0, 0.52, -0.48), Vector3(0, 0, -1), [[0.0, 0.0], [0.0, 0.1], [0.012, 0.0]], 14)
	k.box(ShapeKit.PAINT, BLACK, Vector3(-0.17, 0.36, 0.34), Vector3(0.17, 0.68, 0.37), 0.02)
	k.box(ShapeKit.GLOW, Color8(40, 20, 90), Vector3(-0.15, 0.39, 0.366), Vector3(0.15, 0.65, 0.372), 0.0)
	for blob: Array in [[Vector3(-0.05, 0.5, 0), Color8(250, 130, 30)], [Vector3(0.05, 0.56, 0), Color8(255, 220, 90)], [Vector3(-0.09, 0.44, 0), Color8(200, 40, 120)], [Vector3(0.09, 0.45, 0), Color8(140, 30, 150)]]:
		var c: Vector3 = blob[0]
		k.box(ShapeKit.GLOW, blob[1], Vector3(c.x - 0.04, c.y - 0.035, 0.372), Vector3(c.x + 0.04, c.y + 0.035, 0.375), 0.0)
	for index in 3:
		k.box(ShapeKit.RUBBER, CHARCOAL, Vector3(-0.1 + index * 0.1 - 0.03, 0.72, 0.1), Vector3(-0.1 + index * 0.1 + 0.03, 0.75, 0.18), 0.01)
	k.slab(ShapeKit.RUBBER, BLACK, Vector3(0, 0, 0), Vector3(0, 0, -1), Vector3.UP, [[-0.18, -0.06], [0.02, -0.08], [0.12, 0.32], [-0.12, 0.32]], 0.17)
	for index in 3:
		k.box(ShapeKit.RUBBER, CHARCOAL, Vector3(-0.09, -0.02 + index * 0.1, -0.04 + index * 0.025), Vector3(0.09, 0.02 + index * 0.1, 0.0 + index * 0.025), 0.01)
	k.ring(ShapeKit.RUBBER, CHARCOAL, Vector3(0, -0.1, 0.18), Vector3.RIGHT, 0.12, 0.018, 12)




static func _divider(k: ShapeKit) -> void :
	var y: = -0.52
	k.box(ShapeKit.METAL, ALU, Vector3(-0.42, y - 0.22, -0.3), Vector3(0.42, y + 0.22, 0.3), 0.08)
	_storz(k, Vector3(0, y, 0.3), Vector3.BACK, 0.2)
	_storz(k, Vector3(0, y, -0.3), Vector3.FORWARD, 0.2)
	for side: float in [-1.0, 1.0]:
		_storz(k, Vector3(side * 0.42, y, -0.05), Vector3(side, 0, 0), 0.15)
	for at: Vector3 in [Vector3(-0.26, y + 0.22, 0.05), Vector3(0, y + 0.22, -0.17), Vector3(0.26, y + 0.22, 0.05)]:
		k.tube(ShapeKit.METAL, STEEL, [at, at + Vector3(0, 0.08, 0)], 0.03, 6)
		k.ring(ShapeKit.PAINT, RED, at + Vector3(0, 0.1, 0), Vector3.UP, 0.09, 0.02, 12)
		for index in 3:
			var angle: = TAU * index / 3.0
			k.tube(ShapeKit.PAINT, RED, [at + Vector3(0, 0.1, 0), at + Vector3(cos(angle) * 0.09, 0.1, sin(angle) * 0.09)], 0.012, 4, false)

	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, y + 0.2, 0.27), Vector3(0, 0.0, 0.2), Vector3(0, 0.0, -0.2), Vector3(0, y + 0.2, -0.27)], 0.045, 8)



static func _storz(k: ShapeKit, at: Vector3, axis: Vector3, size: float) -> void :
	k.lathe(ShapeKit.METAL, ALU, at, axis, [[0.0, 0.0], [0.0, size], [0.03, size * 1.16], [0.09, size * 1.16], [0.1, size], [0.14, size], [0.14, size * 0.6], [0.14, 0.0]], 12)
	var side: = axis.cross(Vector3.UP if absf(axis.y) < 0.9 else Vector3.RIGHT).normalized()
	for s: float in [-1.0, 1.0]:
		var lug: = at + axis * 0.07 + side * s * size * 1.2
		k.box(ShapeKit.METAL, ALU, lug - Vector3.ONE * 0.04, lug + Vector3.ONE * 0.04, 0.01)









static func _truck_outlet(k: ShapeKit) -> void :
	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0, 0, -0.6), Vector3(0, 0, -0.2)], 0.2, 12)
	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0, 0, -0.21), Vector3.BACK, [[0.0, 0.0], [0.0, 0.44], [0.02, 0.46], [0.05, 0.46], [0.07, 0.42], [0.07, 0.0]], 20)
	for index in 6:
		var angle: = TAU * index / 6.0 + PI / 6.0
		var bolt: = Vector3(cos(angle) * 0.35, sin(angle) * 0.35, -0.14)
		k.tube(ShapeKit.METAL, STEEL, [bolt, bolt + Vector3(0, 0, 0.035)], 0.035, 6)

	k.lathe(ShapeKit.METAL, ALU, Vector3(0, 0, -0.14), Vector3.BACK, [[0.0, 0.18], [0.04, 0.23], [0.08, 0.27], [0.17, 0.27], [0.21, 0.22], [0.26, 0.2]], 16)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(0, 0.25, -0.01), Vector3(0, 0.37, -0.01)], 0.04, 8)
	k.box(ShapeKit.PAINT, RED, Vector3(-0.07, 0.35, -0.05), Vector3(0.48, 0.41, 0.03), 0.02)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0.4, 0.38, -0.01), Vector3(0.6, 0.38, -0.01)], 0.05, 8)
	_storz_big(k, 0.12, 0.27)





static func _truck_intake(k: ShapeKit) -> void :
	k.tube(ShapeKit.METAL, STEEL_DARK, [Vector3(0, 0, -0.6), Vector3(0, 0, -0.2)], 0.3, 12)
	k.box(ShapeKit.METAL, STEEL_DARK, Vector3(-0.56, -0.56, -0.26), Vector3(0.56, 0.56, -0.17), 0.04)
	for x: float in [-0.44, 0.44]:
		for y: float in [-0.44, 0.44]:
			k.tube(ShapeKit.METAL, STEEL, [Vector3(x, y, -0.17), Vector3(x, y, -0.13)], 0.045, 6)
	k.lathe(ShapeKit.METAL, BRIGHT, Vector3(0, 0, -0.17), Vector3.BACK, [[0.0, 0.3], [0.05, 0.36], [0.17, 0.37], [0.22, 0.32], [0.25, 0.3]], 18)

	var wheel: = Vector3(0, 0.6, -0.06)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(0, 0.34, -0.06), wheel], 0.045, 8)
	k.ring(ShapeKit.PAINT, RED, wheel, Vector3.UP, 0.24, 0.03, 18)
	for index in 3:
		var angle: = TAU * index / 3.0
		k.tube(ShapeKit.PAINT, RED, [wheel, wheel + Vector3(cos(angle) * 0.24, 0, sin(angle) * 0.24)], 0.02, 5, false)
	k.ball(ShapeKit.PAINT, RED, wheel + Vector3(0, 0.02, 0), Vector3(0.06, 0.04, 0.06), 8, 4)

	k.tube(ShapeKit.METAL, ALU, [Vector3(0, -0.34, -0.06), Vector3(0, -0.5, -0.06)], 0.05, 8)
	k.box(ShapeKit.RUBBER, BLACK, Vector3(-0.12, -0.56, -0.09), Vector3(0.12, -0.5, -0.03), 0.015)
	_storz_big(k, 0.08, 0.4)





static func _storz_big(k: ShapeKit, from: float, size: float) -> void :
	var ring: = size * 1.18
	var deep: = size * 0.75
	k.lathe(ShapeKit.METAL, ALU, Vector3(0, 0, from), Vector3.BACK, [[0.0, size * 0.75], [0.0, ring - 0.03], [0.03, ring], [deep - 0.04, ring], [deep - 0.01, ring - 0.03], [deep, ring - 0.04], [deep, size * 0.78]], 20)
	for index in 14:
		var angle: = TAU * index / 14.0
		var at: = Vector3(cos(angle) * ring, sin(angle) * ring, from)
		k.tube(ShapeKit.METAL, ALU, [at + Vector3(0, 0, 0.05), at + Vector3(0, 0, deep - 0.06)], 0.018, 4)
	for s: float in [-1.0, 1.0]:
		var lug: = Vector3(0, s * (ring + 0.03), from + deep * 0.45)
		k.box(ShapeKit.METAL, ALU, lug - Vector3(0.05, 0.04, 0.06), lug + Vector3(0.05, 0.04, 0.06), 0.012)

		var x0: = s * size * 0.82
		var x1: = s * ring
		k.box(ShapeKit.METAL, ALU, Vector3(minf(x0, x1), - size * 0.24, from + deep - 0.01), Vector3(maxf(x0, x1), size * 0.24, from + deep + size * 0.3), 0.012)
		var x2: = s * size * 0.62
		k.box(ShapeKit.METAL, ALU, Vector3(minf(x2, x0), - size * 0.24, from + deep + size * 0.2), Vector3(maxf(x2, x0), size * 0.24, from + deep + size * 0.3), 0.01)
	k.ring(ShapeKit.RUBBER, BLACK, Vector3(0, 0, from + deep + 0.005), Vector3.BACK, size * 0.66, size * 0.08, 18)
	k.lathe(ShapeKit.METAL, CHARCOAL, Vector3(0, 0, from + deep - 0.04), Vector3.BACK, [[0.0, size * 0.78], [0.0, 0.0]], 16)







static func _cone(k: ShapeKit) -> void :
	k.box(ShapeKit.RUBBER, BLACK, Vector3(-0.75, 0.0, -0.75), Vector3(0.75, 0.16, 0.75), 0.07)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, 0.16, 0), Vector3.UP, [[0.0, 0.66], [0.06, 0.62], [0.08, 0.0]], 16)
	k.lathe(ShapeKit.PAINT, ORANGE, Vector3.ZERO, Vector3.UP, [[0.16, 0.57], [0.24, 0.55], [2.02, 0.19], [2.1, 0.185], [2.14, 0.15]], 16)
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3(0, 2.12, 0), Vector3.UP, [[0.0, 0.15], [0.01, 0.0]], 12)
	for band: Array in [[0.95, 1.3], [1.5, 1.68]]:
		var low: float = band[0]
		var high: float = band[1]
		k.lathe(ShapeKit.PAINT, WHITE, Vector3.ZERO, Vector3.UP, [[low, _cone_r(low) + 0.006], [high, _cone_r(high) + 0.006]], 16)


static func _cone_r(y: float) -> float:
	return 0.55 - (y - 0.24) * (0.36 / 1.78)




static func _tape_post(k: ShapeKit) -> void :
	k.lathe(ShapeKit.RUBBER, BLACK, Vector3.ZERO, Vector3.UP, [[0.0, 0.66], [0.06, 0.66], [0.12, 0.55], [0.2, 0.28], [0.3, 0.2], [0.3, 0.0]], 16)
	var top: = Cordon.POST_HEIGHT
	var stripes: = 6
	for index in stripes:
		var y0: = 0.3 + (top - 0.45) * index / stripes
		var y1: = 0.3 + (top - 0.45) * (index + 1) / stripes
		k.tube(ShapeKit.PAINT, RED if index % 2 == 0 else WHITE, [Vector3(0, y0, 0), Vector3(0, y1, 0)], 0.13, 10, false)
	k.lathe(ShapeKit.PAINT, RED, Vector3(0, top - 0.15, 0), Vector3.UP, [[0.0, 0.17], [0.1, 0.17], [0.15, 0.12], [0.18, 0.0]], 10)
	k.box(ShapeKit.METAL, BRIGHT, Vector3(-0.17, Cordon.TAPE_HEIGHT - 0.16, -0.17), Vector3(0.17, Cordon.TAPE_HEIGHT + 0.16, 0.17), 0.03)




static func _tape_reel(k: ShapeKit) -> void :
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0, 0.0, 0), Vector3(0, 0.72, 0)], 0.13, 10)
	for index in 4:
		k.ring(ShapeKit.RUBBER, BLACK, Vector3(0, 0.12 + index * 0.16, 0), Vector3.UP, 0.13, 0.02, 10)
	k.box(ShapeKit.PAINT, CHARCOAL, Vector3(-0.36, 0.72, -0.1), Vector3(0.36, 0.84, 0.1), 0.03)
	for side: float in [-1.0, 1.0]:
		k.box(ShapeKit.PAINT, CHARCOAL, Vector3(side * 0.36 - 0.05, 0.72, -0.08), Vector3(side * 0.36 + 0.05, 1.36, 0.08), 0.02)
		k.lathe(ShapeKit.RUBBER, BLACK, Vector3(side * 0.27, 1.3, 0), Vector3(side, 0, 0), [[0.0, 0.0], [0.0, 0.62], [0.04, 0.62], [0.04, 0.0]], 18)
	k.lathe(ShapeKit.PAINT, WHITE, Vector3(-0.25, 1.3, 0), Vector3.RIGHT, [[0.0, 0.0], [0.0, 0.54], [0.5, 0.54], [0.5, 0.0]], 18)
	for x: float in [-0.17, -0.02, 0.13]:
		k.lathe(ShapeKit.PAINT, RED, Vector3(x, 1.3, 0), Vector3.RIGHT, [[0.0, 0.545], [0.08, 0.545]], 18)
	k.tube(ShapeKit.METAL, BRIGHT, [Vector3(-0.44, 1.3, 0), Vector3(0.44, 1.3, 0)], 0.05, 8)
	k.tube(ShapeKit.METAL, STEEL, [Vector3(0.44, 1.3, 0), Vector3(0.44, 1.12, -0.22)], 0.03, 6)
	k.tube(ShapeKit.RUBBER, BLACK, [Vector3(0.44, 1.12, -0.22), Vector3(0.58, 1.12, -0.22)], 0.05, 8)
	k.slab(ShapeKit.PAINT, WHITE, Vector3(0.0, 0, 0), Vector3(0, 0, -1), Vector3.UP, [[0.5, 1.3], [0.56, 1.3], [0.58, 0.85], [0.52, 0.86]], 0.36)
	k.slab(ShapeKit.PAINT, RED, Vector3(0.0, 0, 0), Vector3(0, 0, -1), Vector3.UP, [[0.505, 1.1], [0.565, 1.1], [0.575, 0.95], [0.515, 0.95]], 0.37)





static func _hose_roll(k: ShapeKit, supply: bool) -> void :
	var cloth: Color = HoseService.SUPPLY_COLOR if supply else HoseService.ATTACK_COLOR
	var outer: = 0.85 if supply else 0.75
	var half: = (0.5 if supply else 0.4) / 2.0
	var middle: = Vector3(0, - outer, 0)
	k.lathe(ShapeKit.PAINT, cloth, middle, Vector3.RIGHT, 
		[[ - half, 0.22], [ - half, outer - 0.05], [ - half + 0.05, outer], [half - 0.05, outer], [half, outer - 0.05], [half, 0.22]], 22)
	k.lathe(ShapeKit.RUBBER, BLACK, middle, Vector3.RIGHT, [[half, 0.22], [ - half, 0.22]], 14)
	var layers: = 5
	for layer in layers:
		var r: = 0.3 + layer * (outer - 0.34) / (layers - 1)
		for side: float in [-1.0, 1.0]:
			k.ring(ShapeKit.PAINT, cloth.darkened(0.35), middle + Vector3(side * half, 0, 0), Vector3.RIGHT, r, 0.012, 22)

	k.lathe(ShapeKit.METAL, ALU, middle, Vector3.RIGHT, [[ - half - 0.03, 0.0], [ - half - 0.03, 0.15], [half + 0.03, 0.15], [half + 0.03, 0.0]], 12)
	k.lathe(ShapeKit.METAL, ALU, Vector3(0, -2.0 * outer + 0.1, 0.05), Vector3.FORWARD, [[0.0, 0.0], [0.0, 0.14], [0.3, 0.14], [0.34, 0.1], [0.34, 0.0]], 12)
	for side: float in [-1.0, 1.0]:
		k.box(ShapeKit.METAL, ALU, Vector3(side * 0.2 - 0.04, -2.0 * outer + 0.06, -0.25), Vector3(side * 0.2 + 0.04, -2.0 * outer + 0.14, -0.17), 0.01)
	k.ring(ShapeKit.RUBBER, BLACK, middle, Vector3.RIGHT, outer + 0.015, 0.03, 26)
