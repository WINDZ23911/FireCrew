extends RefCounted



static func start(main: Node) -> void :
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--crewai="):
			var debug: = CrewAiDebug.new()
			debug.name = "CrewAiDebug"
			debug.proof_name = "crewai-" + arg.substr(9)
			main.add_child(debug)
			debug.call_deferred("_crewai_" + arg.substr(9))
