class_name PlayerData
extends RefCounted




const PATH: = "user://firefighter.json"
const VERSION: = 1


static var path: = PATH
static var _loaded: = false
static var _player: Player
static var _dirty: = false


static var first_shift_done: = true



static func start(player: Player) -> void :
	_player = player
	var saved: Variant = read_file(path)
	if saved is String:

		push_warning("PlayerData: %s cannot be read: %s; a copy is kept at %s, and nothing will be saved" % [path, saved, path + ".broken"])
		Game.notify(Text.m("world.save.unreadable"), "warning", player)
		return
	first_shift_done = saved is Dictionary and (bool(saved.get("first_shift", false)) or int(saved.get("saved", 0)) > 0)
	if saved is Dictionary:

		player.set_attr("Cash", int(player.get_attr("Cash", 0)) + int(saved.get("cash", 0)))

		player.set_attr("Pending", int(player.get_attr("Pending", 0)) + int(saved.get("pending", 0)))

		player.set_attr("Wear", clampf(float(saved.get("wear", 0.0)), 0.0, 1.0))

		player.set_attr("HelmetWear", clampf(float(saved.get("helmet_wear", 0.0)), 0.0, 1.0))
		player.set_attr("Saved", int(player.get_attr("Saved", 0)) + rank_points(saved))

		player.set_attr("Lives", int(player.get_attr("Lives", 0)) + int(saved.get("lives", 0)))
		for id: String in saved.get("suits", []):
			player.set_attr("Owns_" + id, true)

		if saved.get("best") is Dictionary:
			for kind: String in saved["best"]:
				player.set_attr("Best_" + kind, String(saved["best"][kind]))
		if saved.get("helmet") is String:
			player.set_attr("Helmet", saved["helmet"])

		if saved.get("training") is Dictionary:
			for id: String in saved["training"]:
				player.set_attr("Train_" + id, clampi(int(saved["training"][id]), 0, Training.MOST))
		if saved.get("name") is String and not String(saved["name"]).is_empty():
			player.display_name = saved["name"]

	if not (saved is Dictionary and saved.get("name") is String and not String(saved["name"]).is_empty()):
		player.display_name = default_name()
	_loaded = true
	player.attribute_changed.connect( func(key: String, _value: Variant) -> void :
		if key in ["Cash", "Pending", "Wear", "HelmetWear", "Saved", "Helmet", "Lives"] or key.begins_with("Owns_") or key.begins_with("Best_") or key.begins_with("Train_"):
			_dirty = true
	)
	var timer: = Timer.new()
	timer.wait_time = 5.0
	timer.autostart = true
	timer.timeout.connect( func() -> void :
		if _dirty:
			save()
	)
	player.add_child(timer)
	player.tree_exiting.connect(save)







static func rank_points(saved: Dictionary) -> int:
	if saved.has("points"):
		return int(saved["points"])
	return int(saved.get("saved", 0)) * int(Config.Alarm.Grade.Points.PerOldCall)



static func default_name() -> String:
	return Text.say(Text.m("world.defaultName"))


static func save() -> void :

	if not _loaded or not is_instance_valid(_player):
		return
	_dirty = false
	var bought: Array = []
	var best: = {}
	var training: = {}
	for key: String in _player.attributes:
		if key.begins_with("Owns_") and _player.attributes[key] == true:
			bought.append(key.substr(5))
		elif key.begins_with("Best_") and _player.attributes[key] is String:
			best[key.substr(5)] = _player.attributes[key]
		elif key.begins_with("Train_") and int(_player.attributes[key]) > 0:
			training[key.substr(6)] = int(_player.attributes[key])
	write_file(path, {
		"version": VERSION, 
		"cash": int(_player.get_attr("Cash", 0)), 
		"pending": int(_player.get_attr("Pending", 0)), 
		"wear": snappedf(float(_player.get_attr("Wear", 0.0)), 0.001), 
		"helmet_wear": snappedf(float(_player.get_attr("HelmetWear", 0.0)), 0.001), 
		"saved": int(_player.get_attr("Saved", 0)), 
		"points": int(_player.get_attr("Saved", 0)), 
		"lives": int(_player.get_attr("Lives", 0)), 
		"suits": bought, 
		"best": best, 
		"training": training, 
		"helmet": _player.get_attr("Helmet"), 
		"name": _player.display_name, 
		"first_shift": first_shift_done, 
	})









static func read_file(at: String) -> Variant:
	at = ProjectSettings.globalize_path(at)
	var found: Variant = _parse(at)
	if found is Dictionary:
		return found
	var backup: Variant = _parse(at + ".bak")
	if found == null:

		return backup if backup is Dictionary else null
	if not FileAccess.file_exists(at + ".broken"):
		DirAccess.copy_absolute(at, at + ".broken")
	if backup is Dictionary:
		push_warning("PlayerData: %s cannot be read (%s); the backup is read instead, the spoilt one kept at %s" % [at, found, at + ".broken"])
		return backup
	return found



static func _parse(at: String) -> Variant:
	if not FileAccess.file_exists(at):
		return null
	var text: = FileAccess.get_file_as_string(at)
	var json: = JSON.new()
	if json.parse(text) == OK and json.data is Dictionary:
		return json.data
	return "%d bytes that are not a saved game" % text.length()




static func write_file(at: String, data: Dictionary) -> bool:
	at = ProjectSettings.globalize_path(at)
	var temporary: = at + ".tmp"
	var file: = FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(data))
	file.flush()
	file.close()
	if FileAccess.file_exists(at) and _parse(at) is Dictionary:
		DirAccess.remove_absolute(at + ".bak")
		DirAccess.rename_absolute(at, at + ".bak")
	return DirAccess.rename_absolute(temporary, at) == OK



static func finish_first_shift() -> void :
	first_shift_done = true
	save()


static func owns(player: Player, id: String) -> bool:
	return player.get_attr("Owns_" + id, false) == true



static func set_helmet(player: Player, sheet: Variant) -> void :
	player.set_attr("Helmet", sheet)




static func buy(player: Player, id: String, price: int) -> bool:
	if owns(player, id) or int(player.get_attr("Cash", 0)) < price:
		return false
	player.set_attr("Cash", int(player.get_attr("Cash", 0)) - price)
	player.set_attr("Owns_" + id, true)

	save_now(player)
	return true



static func save_now(player: Player) -> void :
	if player == _player:
		save()



static func spend(player: Player, amount: int) -> bool:
	if int(player.get_attr("Cash", 0)) < amount:
		return false
	player.set_attr("Cash", int(player.get_attr("Cash", 0)) - amount)
	return true
