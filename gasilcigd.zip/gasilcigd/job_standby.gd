class_name JobStandby
extends CrewJob



func _init(vehicle: Vehicle) -> void :
	kind = "standby"
	target = vehicle


func place() -> Vector3:
	return target.global_position


func run() -> bool:
	var vehicle: Vehicle = target
	var spot: Vector3 = vehicle.global_transform * Vector3((who.slot % 3 - 1) * 4.0, 0, float(vehicle.data.get("rearAxle", 7.0)) + 6.0)
	if not await who.go(who.service.ground(spot), 3.0, 90.0):
		return fail("crew.say.stuck")
	if ordered:
		who.mode = "hold"
	who.hold_at = who.body.global_position
	who.look = vehicle.global_position
	return true
