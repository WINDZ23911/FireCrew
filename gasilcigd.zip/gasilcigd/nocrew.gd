extends ProofDebug







func _scenario_noaicrew() -> void :
	await _wait(3.0)
	var service: = CrewService.current
	if not _check(service != null, "the crew service is there (its logic kept)"):
		await _done()
		return
	_check( not CrewService.enabled(), "the AI crew is out of the game (Config.Crew.Enabled)")
	_check(service.members.is_empty(), "the firefighter starts alone")
	await _snap("start")


	Settings.crew = true
	Settings.crew_count = 5
	while service.roster.members.size() < 3:
		service.roster.members.append(service.roster._member("", "nozzle", 0, 0))
	service.spawn()
	await _wait(1.0)
	_check(Settings.crew_size() == 0, "a saved crew-along setting counts for nobody (%d)" % Settings.crew_size())
	_check(service.members.is_empty(), "a saved roster brings nobody (%d made)" % service.members.size())
	player.set_attr("Cash", 100000)
	_check( not service.hire(player) and service.members.is_empty(), "nobody can be hired")


	process_mode = Node.PROCESS_MODE_ALWAYS
	var menu: = HudPause.current
	menu.show_menu()
	menu.show_tab("game")
	await get_tree().create_timer(0.5, true).timeout
	_check(menu._crew_buttons.is_empty(), "the Game tab has no buttons for the AI crew")
	await _snap("pause_game")
	menu.show_tab("controls")
	await get_tree().create_timer(0.5, true).timeout
	_check( not menu._key_rows.has("crew_order") and menu._key_rows.has("ping"), "the keys' list has no crew orders (the ping is there)")
	await _snap("pause_controls")
	menu.close()
	await _wait(0.5)


	var board: = CrewBoard.current
	if _check(board != null and board._board != null, "the station's board is there"):
		var out: Vector3 = board._board.get_meta("out")
		player.teleport(board._board.global_position + out * 4.0 + Vector3(0, -1.0, 0))
		await _wait(0.5)
		board.open()
		await _wait(0.5)
		var rows: = board._rows.get_children().filter( func(row: Node) -> bool: return not row.is_queued_for_deletion())
		_check(rows.size() == 3, "the board is the duty board alone (%d rows)" % rows.size())
		await _snap("board")
		board.close()
	_check(service.members.is_empty(), "still alone")


	var title: = TitleScreen.new()
	get_tree().current_scene.add_child(title)
	await _wait(2.5)
	await _snap("title")
	for page: String in ["play", "crew", "setup"]:
		title._open(page)
		await _wait(0.6)
		await _snap("title_" + page)
	title._open("")
	await _done()
