class_name IconChip
extends Node3D




static var _disc: ImageTexture

var words: Label3D
var _icon: Sprite3D
var _back: Sprite3D
var _since: = 0.0



static func attach(parent: Node3D, label: Label3D, lift: float) -> IconChip:
	var chip: = IconChip.new()
	chip.name = "IconChip"
	chip.words = label
	chip.position = Vector3(0, lift + 0.9, 0)
	parent.add_child(chip)
	return chip



static func show_icon(chip: Variant, icon: String, ring: Color) -> void :
	if not is_instance_valid(chip):
		return
	var made: = chip as IconChip
	made.visible = not icon.is_empty()
	if icon.is_empty():
		return
	made._icon.texture = Ui.icon_texture(icon)
	made._back.modulate = ring


func _init() -> void :
	var look: Dictionary = Config.Art.Chips
	_back = _sprite(_disc_texture(), float(look["Pixel"]), 6)
	_icon = _sprite(null, float(look["Pixel"]) * 0.33, 7)
	_icon.modulate = Color(0.94, 0.95, 0.92)


func _sprite(texture: Texture2D, pixel: float, priority: int) -> Sprite3D:
	var sprite: = Sprite3D.new()
	sprite.texture = texture
	sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sprite.no_depth_test = true
	sprite.fixed_size = true
	sprite.pixel_size = pixel
	sprite.render_priority = priority
	sprite.shaded = false
	sprite.alpha_cut = SpriteBase3D.ALPHA_CUT_DISABLED
	sprite.visibility_range_end = float(Config.Art.Chips.Far)
	add_child(sprite)
	return sprite


func _process(delta: float) -> void :
	_since += delta
	if _since < 0.2 or not is_instance_valid(words):
		return
	_since = 0.0
	var player: = Game.local_player
	var near: = player != null and player.root_position().distance_to(global_position) <= float(Config.Art.Chips.WordsNear)
	words.visible = visible and near



static func _disc_texture() -> ImageTexture:
	if _disc == null:
		var image: = Image.create(64, 64, false, Image.FORMAT_RGBA8)
		for y in 64:
			for x in 64:
				var r: = Vector2(x + 0.5 - 32.0, y + 0.5 - 32.0).length() / 32.0
				var color: = Color(0, 0, 0, 0)
				if r < 0.84:
					color = Color(0.07, 0.075, 0.085, 0.92)
				elif r < 0.98:
					color = Color(1, 1, 1, 1)
				image.set_pixel(x, y, color)
		_disc = ImageTexture.create_from_image(image)
	return _disc
