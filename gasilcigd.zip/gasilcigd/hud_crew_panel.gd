class_name HudCrewPanel
extends Control





func _ready() -> void :
	visible = false
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(false)
