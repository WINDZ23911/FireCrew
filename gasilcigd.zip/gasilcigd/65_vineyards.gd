extends RefCounted



















const SOFT_ROW: = ["VinePost", "VineWire", "Vines", "VineStems", "Grapes"]



const HILLS: = [Vector2(-38, -1267), Vector2(433, -1290), Vector2(-408, -1274)]
const ROW_GAP: = 7.5
const ROW_STEP: = 22.0
const LEAF: = Color8(80, 114, 54)
const STAKE: = Color8(116, 100, 82)
const LIMEWASH: = Color8(238, 235, 226)
const TILES: = Color8(156, 78, 56)
const BOARDS: = Color8(112, 80, 56)
const CELLAR_STONE: = Color8(178, 172, 160)
const DOOR: = Color8(88, 62, 44)
const BACKDROP_GREEN: = ["FarTree", "FarTrunk", "Woods"]


const BRAJDA_LENGTH: = 22.0
const BRAJDA_WIDTH: = 11.0
const BRAJDA_HEIGHT: = 8.2
const POST_WOOD: = Color8(122, 98, 74)
const VINE_WOOD: = Color8(84, 64, 48)


const BIRCH_BARK: = Color8(214, 210, 200)
const BIRCH_LEAF: = Color8(118, 156, 82)
const BRACKEN: = [Color8(86, 116, 46), Color8(96, 122, 48), Color8(122, 104, 50)]
const STELJA: = Color8(150, 112, 66)
const NORTH_EDGE: = -921.0
const CLEARINGS: = 2
const CLEARING_APART: = 450.0
const WAYS: = ["road", "lane", "path", "driveway", "parking", "crossover", "pavement", "paving"]


static func apply(kit: PolishKit) -> String:
	var gone: = _grub(kit)
	var brajde: = _brajde(kit, gone[1])
	var hills: = _gorice(kit)
	var clearings: = _steljniki(kit)
	return "vineyards: %d flat rows grubbed (%d parts), %d brajde, %d hill vineyards (%d rows, %d zidanice, %d parts), %d steljniki (%d birches)" % [
		gone[0], gone[2], brajde, hills[0], hills[1], hills[2], hills[3], clearings[0], clearings[1]]







static func _grub(kit: PolishKit) -> Array:
	var store: = kit.store
	var posts: Array = []
	var hidden: = 0
	var rows: = 0
	for row in kit.rows_under("Map/Parks"):
		var part_name: = store.name_at(row)
		if not part_name in SOFT_ROW:
			continue
		if part_name == "VinePost":
			posts.append(store.position(row))
		elif part_name == "Vines":
			rows += 1
		store.set_transparency(row, 1.0)
		store.set_flags(row, 0)
		hidden += 1
	var plots: Array = []
	for row in kit.rows_under("Map/Surfaces"):
		if store.name_at(row) != "soil":
			continue
		var place: = store.transform(row)
		var half: = store.size(row) / 2.0
		for at: Vector3 in posts:
			var local: = place.affine_inverse() * at
			if absf(local.x) < half.x and absf(local.z) < half.z:
				plots.append(row)

				store.set_transparency(row, 1.0)
				hidden += 1
				break
	return [rows, plots, hidden]






static func _brajde(kit: PolishKit, plots: Array) -> int:
	var store: = kit.store
	var parent: = kit.own_folder("Vineyards")
	var made: = 0
	for row: int in plots:
		var place: = store.transform(row).orthonormalized()
		var half: = store.size(row) / 2.0
		var middle: = place.origin
		var house: = Vector2.INF
		for building: Dictionary in kit.layout()["buildings"]:
			var spot: = Vector2(float(building["x"]), float(building["z"]))
			if spot.distance_to(Vector2(middle.x, middle.z)) < house.distance_to(Vector2(middle.x, middle.z)):
				house = spot
		var local: = place.affine_inverse() * Vector3(house.x, middle.y, house.y)

		var reach: = Vector2(half.x - BRAJDA_LENGTH / 2.0 - 3.0, half.z - BRAJDA_WIDTH / 2.0 - 3.0)
		var at: = place * Vector3(clampf(local.x, - reach.x, reach.x), 0, clampf(local.z, - reach.y, reach.y))
		at.y = 0.0
		var model: = store.add_node(parent, "Model", "Brajda")
		_brajda(kit, model, Transform3D(place.basis, at), kit.rng("brajda:%d" % row))
		made += 1
	return made





static func _brajda(kit: PolishKit, model: int, frame: Transform3D, rng: RandomNumberGenerator) -> void :
	var top: = BRAJDA_HEIGHT
	for side: float in [-1.0, 1.0]:
		var z: = side * BRAJDA_WIDTH / 2.0
		for index in 3:
			var x: = (index - 1) * (BRAJDA_LENGTH / 2.0 - 1.0) + rng.randf_range(-0.4, 0.4)
			kit.box(model, Transform3D(frame.basis, frame * Vector3(x, top / 2.0 - 0.15, z)), Vector3(0.6, top + 0.3, 0.6), POST_WOOD.darkened(rng.randf() * 0.12), "Wood", "BrajdaPost", PolishKit.SOLID)

			var foot: = frame * Vector3(x + 0.5, 0.0, z - side * 0.45)
			var bend: = frame * Vector3(x + rng.randf_range(0.0, 0.3), top * 0.5, z - side * 0.42)
			kit.rod(model, foot, bend, 0.34, VINE_WOOD, "Wood", "BrajdaVine")
			kit.rod(model, bend, frame * Vector3(x + rng.randf_range(0.4, 0.8), top + 0.1, z - side * 0.4), 0.3, VINE_WOOD, "Wood", "BrajdaVine")
		kit.box(model, Transform3D(frame.basis, frame * Vector3(0, top + 0.25, z)), Vector3(BRAJDA_LENGTH + 1.2, 0.5, 0.5), POST_WOOD, "Wood", "BrajdaBeam", PolishKit.FIXTURE)
	for index in 5:
		var x: = (index - 2) * (BRAJDA_LENGTH / 4.0 - 0.3)
		kit.box(model, Transform3D(frame.basis, frame * Vector3(x, top + 0.65, 0)), Vector3(0.35, 0.3, BRAJDA_WIDTH + 1.6), POST_WOOD, "Wood", "BrajdaBar")


	kit.box(model, Transform3D(frame.basis * Basis(Vector3.UP, rng.randf_range(-0.03, 0.03)), frame * Vector3(rng.randf_range(-0.8, 0.8), top + 1.15, 0)), Vector3(BRAJDA_LENGTH - 1.5, 0.6, BRAJDA_WIDTH - 1.0), LEAF.lightened(0.04), "LeafyGrass", "Leaves")
	for clump in 11:
		var x: = rng.randf_range( - BRAJDA_LENGTH / 2.0, BRAJDA_LENGTH / 2.0)
		var side: = -1.0 if clump % 2 == 0 else 1.0
		var z: = side * (BRAJDA_WIDTH / 2.0 + rng.randf_range(-1.6, 0.5)) if clump % 4 != 3 else rng.randf_range(-2.5, 2.5)
		var at: = Vector3(x, top + rng.randf_range(0.6, 1.4), z)
		if absf(z) > BRAJDA_WIDTH / 2.0 - 0.5 and rng.randf() < 0.35:
			at.y -= 1.0
		kit.ball(model, frame * at, Vector3.ONE * rng.randf_range(1.9, 3.5), LEAF.lightened(0.02 + rng.randf() * 0.12), "LeafyGrass", "Leaves")






static func _gorice(kit: PolishKit) -> Array:
	var store: = kit.store
	var before: = store.count
	var parent: = kit.own_folder("Vineyards")
	var hills: Array = []
	for row in kit.rows_under("Map/Backdrop"):
		if store.name_at(row) == "Hill":
			hills.append([store.position(row), store.size(row) / 2.0])
	var houses: Array = []
	for row in kit.rows_under("Map/Backdrop"):
		if store.name_at(row) == "FarHouse":
			houses.append([store.position(row), store.size(row) / 2.0])
	var made: = 0
	var rows: = 0
	var zidanice: = 0
	for near: Vector2 in HILLS:
		var hill: Array = []
		for each: Array in hills:
			var middle: Vector3 = each[0]
			if hill.is_empty() or Vector2(middle.x, middle.z).distance_to(near) < Vector2(hill[0].x, hill[0].z).distance_to(near):
				hill = each
		if hill.is_empty():
			continue
		var middle: Vector3 = hill[0]
		var half: Vector3 = hill[1]
		var rng: = kit.rng("gorice:%d" % made)
		var model: = store.add_node(parent, "Model", "Vineyard")


		var top_z: float = middle.z + half.z * 0.12
		var foot_z: float = middle.z + half.z * 0.8
		var left: float = middle.x + half.x * rng.randf_range(-0.12, 0.12) - half.x * 0.5
		var parcels: = rng.randi_range(2, 3)
		var track: = 9.0
		var width: float = (half.x - track * (parcels - 1)) / parcels
		var parcel_bounds: Array = []
		for parcel in parcels:
			var bounds: = Rect2(left + parcel * (width + track), top_z + rng.randf_range(0.0, 14.0), width, foot_z - top_z - rng.randf_range(0.0, 14.0))
			parcel_bounds.append(bounds)
			_clear_backdrop(kit, bounds.grow(8.0))
			rows += _rows(kit, model, hills, houses, bounds, rng)


		for attempt in 16:
			var outer: = rng.randf() < 0.5
			var bounds: Rect2 = parcel_bounds[0 if outer else parcels - 1]
			var spot: = Vector2(bounds.position.x - 12.0 if outer else bounds.end.x + 12.0, lerpf(bounds.position.y, bounds.end.y, rng.randf_range(0.05, 0.5)))
			var fall: = _height(hills, spot.x, spot.y - 10.0) - _height(hills, spot.x, spot.y + 10.0)
			if _by_house(houses, spot, 20.0) or fall > 10.0:
				continue
			_clear_backdrop(kit, Rect2(spot - Vector2(18, 18), Vector2(36, 36)))
			_zidanica(kit, model, hills, spot, rng)
			zidanice += 1
			break
		made += 1
	return [made, rows, zidanice, store.count - before]



static func _height(hills: Array, x: float, z: float) -> float:
	var best: = 0.0
	for hill: Array in hills:
		var middle: Vector3 = hill[0]
		var half: Vector3 = hill[1]
		var u: = (x - middle.x) / half.x
		var v: = (z - middle.z) / half.z
		var inside: = 1.0 - u * u - v * v
		if inside > 0.0:
			best = maxf(best, middle.y + half.y * sqrt(inside))
	return best





static func _rows(kit: PolishKit, model: int, hills: Array, houses: Array, bounds: Rect2, rng: RandomNumberGenerator) -> int:
	var count: = int(bounds.size.x / ROW_GAP)
	var first: = bounds.position.x + (bounds.size.x - (count - 1) * ROW_GAP) / 2.0
	var top_wander: = rng.randf_range(0.0, TAU)
	var shade: = LEAF.darkened(rng.randf() * 0.08)
	for index in count:
		var x: = first + index * ROW_GAP
		var top: = bounds.position.y + 5.0 * sin(index * 0.35 + top_wander) + rng.randf_range(-1.5, 1.5)
		var foot: = bounds.end.y - rng.randf_range(0.0, 6.0)
		var steps: = maxi(2, roundi((foot - top) / ROW_STEP))
		var last: = Vector3.INF
		for step in steps + 1:
			var z: = lerpf(top, foot, float(step) / steps)
			var at: = Vector3(x, _height(hills, x, z), z)
			if _by_house(houses, Vector2(at.x, at.z), 8.0):
				last = Vector3.INF
				continue
			kit.post(model, at + Vector3(0, -0.6, 0), 5.4, 0.4, STAKE.darkened(rng.randf() * 0.15), "Wood", "VineStake")
			if last != Vector3.INF:
				var from: = last + Vector3(0, 2.0, 0)
				var to: = at + Vector3(0, 2.0, 0)
				var ahead: = (to - from).normalized()
				var right: = Vector3.UP.cross(ahead).normalized()
				var up: = ahead.cross(right)
				var place: = Transform3D(Basis(right, up, ahead), (from + to) / 2.0 + Vector3(0, -0.3, 0))
				kit.box(model, place, Vector3(2.4, 3.4, from.distance_to(to) + 0.6), shade.darkened(rng.randf() * 0.04), "LeafyGrass", "Leaves")
			last = at
	return count



static func _by_house(houses: Array, at: Vector2, margin: float) -> bool:
	for house: Array in houses:
		var middle: Vector3 = house[0]
		var half: Vector3 = house[1]
		var reach: = maxf(half.x, half.z) + margin
		if absf(at.x - middle.x) < reach and absf(at.y - middle.z) < reach:
			return true
	return false




static func _zidanica(kit: PolishKit, model: int, hills: Array, spot: Vector2, rng: RandomNumberGenerator) -> void :
	var width: = 17.0 + rng.randf_range(-1.0, 1.5)
	var depth: = 20.0 + rng.randf_range(-1.0, 2.0)
	var low: = _height(hills, spot.x, spot.y + depth / 2.0)
	var high: = _height(hills, spot.x, spot.y - depth / 2.0)
	var eaves: = maxf(low + 13.5, high + 6.5)
	var turn: = Basis(Vector3.UP, rng.randf_range(-0.06, 0.06))
	var foot: = Vector3(spot.x, low - 4.0, spot.y)
	var frame: = Transform3D(turn, foot)
	var walls: = eaves - foot.y
	kit.box(model, Transform3D(turn, frame * Vector3(0, walls / 2.0, 0)), Vector3(width, walls, depth), LIMEWASH, "Plaster", "Zidanica")


	var front: = depth / 2.0 + 0.12
	kit.box(model, Transform3D(turn, frame * Vector3(0, 5.75, front - 0.05)), Vector3(width + 0.3, 11.5, 0.3), CELLAR_STONE, "Plaster", "CellarFront")
	front += 0.15
	kit.box(model, Transform3D(turn, frame * Vector3(rng.randf_range(-2.5, 2.5), 4.0 + 3.0, front)), Vector3(4.6, 6.0, 0.3), DOOR, "Wood", "CellarDoor")
	kit.box(model, Transform3D(turn, frame * Vector3(rng.randf_range(-3.0, 3.0), walls - 3.4, front)), Vector3(2.6, 2.8, 0.3), DOOR.darkened(0.3), "Wood", "ZidanicaWindow")

	var side: = 1.0 if rng.randf() < 0.5 else -1.0
	var step_in: = _height(hills, spot.x + side * width / 2.0, spot.y - depth * 0.2)
	var sill: = minf(step_in, eaves - 6.5) - foot.y
	kit.box(model, Transform3D(turn, frame * Vector3(side * (width / 2.0 + 0.12), sill + 3.0, - depth * 0.2)), Vector3(0.3, 6.0, 3.8), DOOR, "Wood", "ZidanicaDoor")

	var rise: = width * 0.5
	var top: = frame * Vector3(0, walls, 0)
	for flip: float in [0.0, PI]:
		var roof: = turn * Basis(Vector3.UP, PI / 2.0 + flip)
		kit.wedge(model, Transform3D(roof, top + roof * Vector3(0, rise / 2.0, - width / 4.0 - 0.6)), Vector3(depth + 2.4, rise, width / 2.0 + 1.2), TILES, "ClayRoofTiles", "ZidanicaRoof")

		var gable: = top + turn * Vector3(0, 0.05, front + 1.25) + roof * Vector3(0, (rise - 0.7) / 2.0, - (width / 2.0 + 0.2) / 2.0)
		kit.wedge(model, Transform3D(roof, gable), Vector3(0.2, rise - 0.7, width / 2.0 + 0.2), BOARDS, "Wood", "ZidanicaGable")



static func _clear_backdrop(kit: PolishKit, area: Rect2) -> void :
	var store: = kit.store
	for row in kit.rows_under("Map/Backdrop"):
		if store.name_at(row) in BACKDROP_GREEN:
			var at: = store.position(row)
			var reach: = store.size(row).x / 2.0 if store.name_at(row) == "Woods" else 0.0
			if area.grow(reach * 0.6).has_point(Vector2(at.x, at.z)):
				store.set_transparency(row, 1.0)






static func _steljniki(kit: PolishKit) -> Array:
	var wild: = kit.own_folder("Wild")
	var parent: = kit.own_folder("Steljniki")
	var found: Array = []
	var x: = -880.0
	while x <= 1080.0:
		var z: = NORTH_EDGE + 50.0
		while z <= NORTH_EDGE + 200.0:
			var spot: = Vector3(x, 0, z)
			var score: = _openness(kit, spot)
			if score > 0:
				found.append([score - absf(x) * 0.001, spot])
			z += 25.0
		x += 25.0
	found.sort_custom( func(one: Array, two: Array) -> bool: return one[0] > two[0])
	var chosen: Array = []
	for each: Array in found:
		var spot: Vector3 = each[1]
		var apart: = true
		for other: Vector3 in chosen:
			if other.distance_to(spot) < CLEARING_APART:
				apart = false
		if apart:
			chosen.append(spot)
		if chosen.size() == CLEARINGS:
			break
	var birches: = 0
	for spot: Vector3 in chosen:
		birches += _clearing(kit, wild, parent, spot, kit.rng("steljnik:%d:%d" % [int(spot.x), int(spot.z)]))
	return [chosen.size(), birches]




static func _openness(kit: PolishKit, at: Vector3) -> int:
	if kit.building_distance(at, 90.0) < 90.0 or not kit.open_ground(at, 18.0) or kit.surface_at(at) == "field":
		return 0
	var score: = 0
	for ring: float in [26.0, 42.0, 50.0]:
		for turn in 10:
			var point: = at + Vector3(sin(turn * TAU / 10.0), 0, cos(turn * TAU / 10.0)) * ring
			var ground: = kit.surface_at(point)
			if ground in WAYS:
				return 0
			if ring < 45.0 and kit.open_ground(point, 4.0) and ground != "field":
				score += 1
	return score if score >= 16 else 0




static func _clearing(kit: PolishKit, wild: int, parent: int, middle: Vector3, rng: RandomNumberGenerator) -> int:
	var birches: = 0
	var start: = rng.randf_range(0.0, TAU)
	var count: = rng.randi_range(9, 11)
	for index in count:

		var turn: = start + (index + rng.randf_range(-0.3, 0.3)) * TAU / (count + 1.5)
		var out: = Vector3(sin(turn), 0, cos(turn))
		var at: = middle + out * rng.randf_range(24.0, 40.0)
		if not kit.open_ground(at, 3.0):
			continue
		_birch(kit, wild, at, rng)
		birches += 1

		for clump in rng.randi_range(3, 5):
			var by: = at + out * rng.randf_range(2.5, 12.0) + Vector3(rng.randf_range(-6, 6), 0, rng.randf_range(-6, 6))
			if by.distance_to(middle) < 20.0 or not kit.open_ground(by, 0.8):
				continue
			var color: Color = BRACKEN[rng.randi_range(0, BRACKEN.size() - 1)]
			for frond in rng.randi_range(2, 3):
				var size: = Vector3(rng.randf_range(5.0, 8.0), rng.randf_range(1.6, 2.4), rng.randf_range(4.0, 6.5))
				var spot: = by + Vector3(rng.randf_range(-3.0, 3.0), 0, rng.randf_range(-3.0, 3.0))
				var place: = Transform3D(Basis(Vector3.UP, rng.randf_range(0.0, TAU)), spot + Vector3(0, size.y * 0.3, 0))
				kit._made(kit.store.add(PartStore.Shape.ELLIPSOID, place, size, color.darkened(rng.randf() * 0.08), "LeafyGrass", "Leaves", parent, PolishKit.LOOK))

	for stack in rng.randi_range(2, 3):
		var at: = middle + Vector3(rng.randf_range(-9, 9), 0, rng.randf_range(-9, 9))
		if not kit.open_ground(at, 3.0):
			continue
		var height: = rng.randf_range(6.0, 7.5)
		kit.post(parent, at, height + 1.4, 0.3, STAKE, "Wood", "SteljaPole")

		var shade: = STELJA.darkened(rng.randf() * 0.1)
		var drum: = height * 0.4
		kit.post(parent, at + Vector3(0, -0.2, 0), drum + 0.2, 6.2, shade, "Grass", "Stelja", PolishKit.FIXTURE)
		kit._made(kit.store.add(PartStore.Shape.ELLIPSOID, Transform3D(Basis(), at + Vector3(0, drum, 0)), Vector3(6.2, height * 1.1, 6.2), shade, "Grass", "Stelja", parent, PolishKit.FIXTURE))
	return birches




static func _birch(kit: PolishKit, folder: int, at: Vector3, rng: RandomNumberGenerator) -> void :
	var model: = kit.store.add_node(folder, "Model", "WildTree")
	var size: = rng.randf_range(0.85, 1.2)
	var trunk: = 21.0 * size
	kit.post(model, at + Vector3(0, -0.5, 0), trunk + 0.5, 1.5 * size, BIRCH_BARK, "Wood", "Trunk", PolishKit.SOLID)
	var turn: = rng.randf_range(0.0, TAU)
	for ball: Array in [[0.0, -2.0, 0.0, 11.0], [1.2, 3.5, 0.8, 9.0], [-1.0, 7.5, -0.6, 7.0]]:
		var offset: = Vector3(float(ball[0]), 0, float(ball[2])).rotated(Vector3.UP, turn) * size
		kit.ball(model, at + offset + Vector3(0, trunk + float(ball[1]) * size, 0), Vector3.ONE * float(ball[3]) * size, BIRCH_LEAF, "LeafyGrass", "Leaves")
