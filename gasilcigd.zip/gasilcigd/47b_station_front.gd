extends RefCounted







const DOOR_FOOT: = Color8(170, 50, 34)


static func apply(kit: PolishKit) -> String:
	var store: = kit.store
	var station: = -1
	for id: int in store.nodes:
		if store.nodes[id]["c"] == "Model" and store.nodes[id]["n"] == "Fire Station":
			station = id
	if station < 0:
		return ""
	var doors: = 0
	var boards: = 0
	var pattern: = RegEx.create_from_string("^BayDoor\\d_1$")
	for row in store.rows_in(station):
		var part: = store.name_at(row)
		if pattern.search(part) != null:
			store.set_color(row, DOOR_FOOT)
			doors += 1
		elif part == "ApronWords":


			store.set_transparency(row, 1.0)
			store.set_flags(row, 0)
			boards += 1
	return "station front: %d door feet dulled, %d painted board hidden" % [doors, boards]
