class_name OldTownDe
extends RefCounted












const STONE: = Color8(178, 166, 142)
const STONE_DARK: = Color8(150, 138, 116)
const RENDER: = Color8(226, 214, 190)
const TILE: = Color8(164, 74, 50)
const TILE_DARK: = Color8(132, 58, 42)
const TIMBER: = Color8(92, 64, 44)
const WINDOW: = Color8(46, 50, 56)
const CHURCH_STONE: = Color8(190, 172, 140)
const WALL_HIGH: = 24.0
const WALL_THICK: = 4.0
const PASSAGE_HIGH: = 24.0

static var places: Array = []


static func apply(kit: PolishKit) -> String:
	if Edition.id() != "de":
		return ""
	var data: Variant = Rbx.load_json(Edition.path("OldTown.json", ""))
	if not data is Dictionary:
		return ""
	var folder: = kit.own_folder("OldTown")
	var middle: = Vector3.ZERO
	var walls: Array = data.get("walls", [])
	for piece: Array in walls:
		middle += Vector3(float(piece[0]), 0, float(piece[1]))
	if walls.size():
		middle /= walls.size()
	for piece: Array in walls:
		_wall(kit, folder, Vector3(float(piece[0]), 0, float(piece[1])), Vector3(float(piece[2]), 0, float(piece[3])), middle)
	var gates: = 0
	var towers: = 0
	places.clear()
	for tower: Dictionary in data.get("towers", []):
		var spot: Vector3 = _footprint(tower)[0]
		if not String(tower["name"]).is_empty():
			places.append([String(tower["name"]), Vector2(spot.x, spot.z)])
		if tower["kind"] == "gate":
			_gate(kit, folder, tower)
			gates += 1
		else:
			_tower(kit, folder, tower)
			towers += 1
	var church: Variant = data.get("church")
	if church is Dictionary:
		_church(kit, folder, church)
		var middle_of: = Vector2.ZERO
		for corner: Array in church["corners"]:
			middle_of += Vector2(float(corner[0]), float(corner[1])) / 4.0
		places.append([String(church.get("name", "Münster")), middle_of])
	return "old town: %d pieces of wall, %d towers, %d gates%s" % [walls.size(), towers, gates, ", the Münster" if church is Dictionary else ""]



static func _ground(kit: PolishKit, at: Vector3) -> float:
	var top: = 0.0
	for row in kit.parts_at(Vector3(at.x, 0, at.z)):
		var height: = kit._top(row)
		if height < 80.0 and kit.store.name_at(row) in ["Hill", "Ground", "Backdrop", "Field", "Meadow", "Edge", "Floor", "land", "ground", "Grass", "Park"]:
			top = maxf(top, height)
	return top



static func _frame(foot: Vector3, along: Vector3) -> Transform3D:
	var x: = Vector3(along.x, 0, along.z).normalized()
	return Transform3D(Basis(x, Vector3.UP, x.cross(Vector3.UP)), foot)



static func _wall(kit: PolishKit, folder: int, a: Vector3, b: Vector3, middle: Vector3) -> void :
	var length: = a.distance_to(b)
	if length < 1.0:
		return
	var centre: = (a + b) / 2.0
	centre.y = _ground(kit, centre)
	var frame: = _frame(centre, b - a)
	kit.box(folder, frame.translated_local(Vector3(0, WALL_HIGH / 2.0, 0)), Vector3(length + 0.6, WALL_HIGH, WALL_THICK), STONE, "Cobblestone", "TownWall", PolishKit.SOLID)

	var inward: = 1.0 if (middle - centre).dot(frame.basis.z) > 0.0 else -1.0
	kit.box(folder, frame.translated_local(Vector3(0, WALL_HIGH + 2.2, inward * 1.2)), Vector3(length + 0.6, 4.4, 2.0), STONE_DARK, "Cobblestone", "WallParapet")
	var roof: = frame * Transform3D(Basis(Vector3.UP, - PI / 2.0 if inward > 0.0 else PI / 2.0), Vector3(0, WALL_HIGH + 6.4, inward * 3.2))
	kit.wedge(folder, roof, Vector3(length + 0.8, 4.0, 6.0), TILE, "ClayRoofTiles", "WallWalkRoof")
	kit.box(folder, frame.translated_local(Vector3(0, WALL_HIGH + 2.2, inward * 5.6)), Vector3(length, 4.4, 0.4), TIMBER, "Wood", "WallWalkPosts")



static func _footprint(tower: Dictionary) -> Array:
	var c: Array = tower["corners"]
	var p: Array[Vector3] = []
	for corner: Array in c:
		p.append(Vector3(float(corner[0]), 0, float(corner[1])))
	var centre: = (p[0] + p[1] + p[2] + p[3]) / 4.0
	return [centre, p[1] - p[0], p[0].distance_to(p[1]), p[0].distance_to(p[3])]



static func _spire(kit: PolishKit, folder: int, frame: Transform3D, y: float, w: float, d: float, high: float, color: Color) -> void :
	var steps: = 11
	for step in steps:
		var t: = float(step) / steps
		var shrink: = 1.0 - t
		kit.box(folder, frame.translated_local(Vector3(0, y + high / steps * (step + 0.5), 0)), Vector3(w * shrink + 0.6, high / steps + 0.05, d * shrink + 0.6), color, "ClayRoofTiles", "TowerRoof")
	kit.box(folder, frame.translated_local(Vector3(0, y + high + 2.0, 0)), Vector3(0.3, 4.0, 0.3), Color8(60, 60, 62), "Metal", "TowerFinial")



static func _slits(kit: PolishKit, folder: int, frame: Transform3D, w: float, d: float, from: float, to: float) -> void :
	var y: = from
	while y < to - 6.0:
		for face in 4:
			var half: = (d if face % 2 == 0 else w) / 2.0 + 0.06
			var turn: = frame * Transform3D(Basis(Vector3.UP, face * PI / 2.0), Vector3.ZERO)
			kit.box(folder, turn.translated_local(Vector3(0, y, half)), Vector3(1.6, 3.4, 0.2), WINDOW, "Glass", "TowerWindow")
		y += 14.0


static func _tower(kit: PolishKit, folder: int, tower: Dictionary) -> void :
	var fp: = _footprint(tower)
	var centre: Vector3 = fp[0]
	centre.y = _ground(kit, centre)
	var frame: = _frame(centre, fp[1])
	var w: = clampf(fp[2], 14.0, 40.0)
	var d: = clampf(fp[3], 14.0, 40.0)
	var bastion: bool = tower["kind"] == "bastion"
	var high: = 34.0 if bastion else 52.0 + float(abs(hash(tower["name"])) % 14)
	kit.box(folder, frame.translated_local(Vector3(0, high / 2.0, 0)), Vector3(w, high, d), STONE, "Cobblestone", "Tower", PolishKit.SOLID)
	kit.box(folder, frame.translated_local(Vector3(0, high - 5.0, 0)), Vector3(w + 0.3, 10.0, d + 0.3), RENDER, "Plaster", "TowerTop")
	_slits(kit, folder, frame, w, d, 14.0, high)
	_spire(kit, folder, frame, high, w + 1.6, d + 1.6, maxf(w, d) * (0.7 if bastion else 1.3), TILE)



static func _gate(kit: PolishKit, folder: int, tower: Dictionary) -> void :
	var fp: = _footprint(tower)
	var centre: Vector3 = fp[0]
	centre.y = _ground(kit, centre)
	var way: = Vector3(float(tower["way"][0]), 0, float(tower["way"][1]))
	var frame: = _frame(centre, way)
	var passage: = float(tower.get("passage", 26.0))
	var across: = maxf(maxf(fp[2], fp[3]), passage + 12.0)
	var along: = clampf(minf(fp[2], fp[3]), 20.0, 34.0)
	var pier: = (across - passage) / 2.0
	var high: = 70.0
	for side: float in [-1.0, 1.0]:
		kit.box(folder, frame.translated_local(Vector3(0, PASSAGE_HIGH / 2.0, side * (passage + pier) / 2.0)), Vector3(along, PASSAGE_HIGH, pier), STONE, "Cobblestone", "GatePier", PolishKit.SOLID)
	var upper: = high - PASSAGE_HIGH
	kit.box(folder, frame.translated_local(Vector3(0, PASSAGE_HIGH + upper / 2.0, 0)), Vector3(along, upper, across), RENDER, "Plaster", "GateTower", PolishKit.SOLID)
	kit.box(folder, frame.translated_local(Vector3(0, PASSAGE_HIGH + 1.5, 0)), Vector3(along + 0.4, 3.0, across + 0.4), STONE_DARK, "Cobblestone", "GateArch")

	for end: float in [-1.0, 1.0]:
		var face: = frame * Transform3D(Basis(Vector3.UP, 0.0 if end > 0.0 else PI), Vector3.ZERO)
		kit.box(folder, face.translated_local(Vector3(along / 2.0 + 0.1, PASSAGE_HIGH + 12.0, 0)), Vector3(0.2, 7.0, 7.0), Color8(236, 232, 220), "SmoothPlastic", "GateClock")
		kit.box(folder, face.translated_local(Vector3(along / 2.0 + 0.2, PASSAGE_HIGH + 12.0, 0)), Vector3(0.2, 1.0, 5.0), Color8(40, 36, 30), "Metal", "GateClockHand")
		for row in 2:
			for column: float in [-1.0, 1.0]:
				kit.box(folder, face.translated_local(Vector3(along / 2.0 + 0.1, PASSAGE_HIGH + 24.0 + row * 12.0, column * across * 0.25)), Vector3(0.2, 5.0, 3.2), WINDOW, "Glass", "GateWindow")
	_spire(kit, folder, frame, high, along + 2.0, across + 2.0, across * 1.0, TILE_DARK)




static func _church(kit: PolishKit, folder: int, church: Dictionary) -> void :
	var c: Array = church["corners"]
	var p: Array[Vector3] = []
	for corner: Array in c:
		p.append(Vector3(float(corner[0]), 0, float(corner[1])))

	var west: = (p[0] + p[3]) / 2.0
	var east: = (p[1] + p[2]) / 2.0
	var length: = west.distance_to(east)
	var width: = p[0].distance_to(p[3])
	var centre: = (west + east) / 2.0
	centre.y = _ground(kit, centre)
	var frame: = _frame(centre, east - west)
	var walls: = 64.0
	kit.box(folder, frame.translated_local(Vector3(0, walls / 2.0, 0)), Vector3(length, walls, width), CHURCH_STONE, "Cobblestone", "ChurchNave", PolishKit.SOLID)

	var pitch: = width * 0.9
	for side: float in [-1.0, 1.0]:
		var half: = Transform3D(Basis(Vector3.UP, - PI / 2.0 if side > 0.0 else PI / 2.0), Vector3.ZERO)
		var roof: = frame * Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3.ZERO)
		kit.wedge(folder, roof * Transform3D(Basis(), Vector3(side * width / 4.0, walls + pitch / 2.0, 0)) * half, Vector3(length + 2.0, pitch, width / 2.0 + 1.5), TILE_DARK, "ClayRoofTiles", "ChurchRoof")

	var bays: = maxi(4, int(length / 26.0))
	for index in bays + 1:
		var x: = - length / 2.0 + length * index / bays
		for side: float in [-1.0, 1.0]:
			kit.box(folder, frame.translated_local(Vector3(x, walls * 0.42, side * (width / 2.0 + 2.0))), Vector3(4.0, walls * 0.84, 4.0), STONE_DARK, "Cobblestone", "Buttress")
			if index < bays:
				var mid: = x + length / bays / 2.0
				kit.box(folder, frame.translated_local(Vector3(mid, walls * 0.5, side * (width / 2.0 + 0.1))), Vector3(7.0, walls * 0.62, 0.3), WINDOW, "Glass", "ChurchWindow")

	var t: = minf(width * 0.42, 34.0)
	var tower_high: = 150.0
	var foot: = frame.translated_local(Vector3( - length / 2.0 - t / 2.0 + 4.0, 0, 0))
	kit.box(folder, foot.translated_local(Vector3(0, tower_high / 2.0, 0)), Vector3(t, tower_high, t), CHURCH_STONE, "Cobblestone", "ChurchTower", PolishKit.SOLID)
	for level in 4:
		kit.box(folder, foot.translated_local(Vector3(0, 30.0 + level * 30.0, 0)), Vector3(t + 1.0, 1.4, t + 1.0), STONE_DARK, "Cobblestone", "TowerCornice")
	_slits(kit, folder, foot, t, t, 40.0, tower_high)
	for face in 4:
		var turn: = foot * Transform3D(Basis(Vector3.UP, face * PI / 2.0), Vector3.ZERO)
		kit.box(folder, turn.translated_local(Vector3(0, tower_high - 16.0, t / 2.0 + 0.1)), Vector3(8.0, 9.0, 0.2), Color8(232, 226, 210), "SmoothPlastic", "TowerClock")
	_spire(kit, folder, foot, tower_high, t + 2.0, t + 2.0, t * 1.1, TILE_DARK)
