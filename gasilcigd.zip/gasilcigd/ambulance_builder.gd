class_name AmbulanceBuilder
extends RefCounted






const WHITE: = Color8(244, 244, 240)
const DARK: = Color8(34, 36, 40)
const GREEN: = Color8(70, 230, 110)
const STEEL: = Color8(196, 198, 202)




static func part(parent: Node3D, part_name: String, size: Vector3, place: Transform3D, color: Color, look: = {}) -> MeshInstance3D:
	var shape: int = look.get("shape", PartStore.Shape.BLOCK)
	var mesh: = MeshInstance3D.new()
	mesh.name = part_name
	mesh.mesh = World.unit_mesh(shape)
	var drawn: = size
	if shape == PartStore.Shape.CYLINDER:
		drawn = Vector3(size.x, minf(size.y, size.z), minf(size.y, size.z))
	var made: = StandardMaterial3D.new()
	made.albedo_color = color
	made.roughness = 0.35 if look.get("metal", false) else 0.7
	made.metallic = 0.7 if look.get("metal", false) else 0.0
	if look.get("neon", false):
		made.emission_enabled = true
		made.emission = color
		made.emission_energy_multiplier = look.get("glow", 1.6)
	var alpha: float = look.get("alpha", 1.0)
	if alpha < 0.999:
		made.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		made.albedo_color.a = alpha
		made.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		made.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.material_override = made
	if not look.get("shadow", false):
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mesh)
	mesh.transform = place * Transform3D(Basis.from_scale(drawn), Vector3.ZERO)
	return mesh


static func _at(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))




static func stretcher() -> Node3D:
	var model: = Node3D.new()
	model.name = "Stretcher"
	var top: = 2.9
	model.set_meta("top", top)
	part(model, "Frame", Vector3(2.5, 0.16, 6.6), _at(0, top - 0.3, 0), STEEL, {"metal": true, "shadow": true})
	part(model, "Mattress", Vector3(2.3, 0.3, 6.3), _at(0, top - 0.15, 0), Color8(226, 106, 36), {"shadow": true})
	part(model, "Pillow", Vector3(1.7, 0.25, 1.1), _at(0, top + 0.05, -2.5), WHITE)
	for z: float in [-2.4, 2.4]:
		for x: float in [-1.05, 1.05]:
			part(model, "Leg", Vector3(0.14, top - 0.75, 0.14), _at(x, (top - 0.3) / 2.0 + 0.2, z), STEEL, {"metal": true})
			part(model, "Castor", Vector3(0.2, 0.6, 0.6), _at(x, 0.3, z), DARK, {"shape": PartStore.Shape.CYLINDER})
		part(model, "Rail", Vector3(2.5, 0.12, 0.12), _at(0, 0.9, z), STEEL, {"metal": true})
	for x: float in [-1.25, 1.25]:
		part(model, "SideRail", Vector3(0.1, 0.1, 3.4), _at(x, top + 0.45, 0.6), STEEL, {"metal": true})
	return model






static func zone() -> Node3D:
	var size: Vector3 = Config.Victims.Zone
	var model: = Node3D.new()
	model.name = "DropZone"
	var pad: = _handover_marking(model, size)
	model.set_meta("pad", pad)
	var marker: = Node3D.new()
	marker.name = "Marker"
	marker.visible = false
	model.add_child(marker)
	part(marker, "Glow", size, _at(0, size.y / 2.0, 0), GREEN, {"alpha": 0.05})
	var rim: = 0.3
	for side: float in [-1.0, 1.0]:
		for end: float in [-1.0, 1.0]:
			part(marker, "Post", Vector3(rim, size.y, rim), _at(side * (size.x - rim) / 2.0, size.y / 2.0, end * (size.z - rim) / 2.0), GREEN, {"neon": true, "alpha": 0.5})


	var sign: = Label3D.new()
	sign.name = "Sign"
	sign.font = Ui.label_font()
	sign.font_size = 36
	sign.outline_size = 14
	sign.outline_modulate = Color8(30, 130, 60)
	sign.modulate = Color.WHITE
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.no_depth_test = true
	sign.fixed_size = true
	sign.pixel_size = 0.0011
	sign.render_priority = 5
	sign.visibility_range_end = 400.0
	sign.position = Vector3(0, size.y + 1.5, 0)
	marker.add_child(sign)

	var painted: = Label3D.new()
	painted.name = "Painted"
	painted.font = Ui.label_font()
	painted.font_size = 96
	painted.pixel_size = 0.007
	painted.outline_size = 0
	painted.modulate = Color(0.92, 1.0, 0.94)
	painted.double_sided = false
	painted.shaded = false

	painted.transform = Transform3D(Basis(Vector3.UP, PI) * Basis(Vector3.RIGHT, - PI / 2.0), Vector3(0, 0.07, - size.z * 0.36))
	model.add_child(painted)
	var words: = func(_code: = "") -> void :
		var said: = Text.say(Text.m("gear.ambulance.dropOff"))
		sign.text = " %s " % said
		painted.text = said
	words.call()
	Text.language_changed.connect(words)
	sign.tree_exiting.connect( func() -> void : Text.language_changed.disconnect(words))

	var watch: = Timer.new()
	watch.wait_time = 0.25
	watch.autostart = true
	watch.timeout.connect( func() -> void :
		var victims: = VictimService.current
		marker.visible = victims != null and Game.local_player != null and victims.carried_by(Game.local_player) != null
	)
	model.add_child(watch)
	return model


static var _marking: ImageTexture



static func _handover_marking(model: Node3D, size: Vector3) -> MeshInstance3D:
	if _marking == null:
		var picture: = Image.create(128, 128, false, Image.FORMAT_RGBA8)
		for y in 128:
			for x in 128:
				var u: = (x + 0.5) / 128.0 - 0.5
				var v: = (y + 0.5) / 128.0 - 0.5
				var edge: = 0.5 - maxf(absf(u), absf(v))
				var cross: = (absf(u) < 0.07 and absf(v) < 0.22) or (absf(v) < 0.07 and absf(u) < 0.22)
				var color: = Color(0, 0, 0, 0)
				if edge < 0.045:
					color = Color(1, 1, 1, 1.0)
				elif cross:
					color = Color(1, 1, 1, 0.95)
				elif edge < 0.06:
					color = Color(1, 1, 1, 0.0)
				else:
					color = Color(1, 1, 1, 0.22)
				picture.set_pixel(x, y, color)
		picture.generate_mipmaps()
		_marking = ImageTexture.create_from_image(picture)
	var mesh: = MeshInstance3D.new()
	mesh.name = "Pad"
	var quad: = QuadMesh.new()
	quad.size = Vector2(size.x, size.z)
	mesh.mesh = quad
	var made: = StandardMaterial3D.new()
	made.albedo_color = Color(GREEN, 0.6)
	made.albedo_texture = _marking
	made.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	made.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	made.emission_enabled = false
	mesh.material_override = made
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mesh.transform = Transform3D(Basis(Vector3.RIGHT, - PI / 2.0), Vector3(0, 0.06, 0))
	model.add_child(mesh)
	return mesh
