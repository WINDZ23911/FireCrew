class_name RoadSnow
extends Node














const PIXELS: = 1024
const UPLOAD_EVERY: = 0.5
const STAMP_EVERY: = 0.1
const BLADE_AHEAD: = 0.45

static var current: RoadSnow

var clock: = 0.0
var _image: Image
var _texture: ImageTexture
var _area: = Rect2()
var _settings: Dictionary = {}
var _dirty: = false
var _upload_in: = 0.0
var _stamp_in: = 0.0
var _last: Dictionary = {}
var _trace: = OS.get_cmdline_user_args().has("--road-snow-trace")
var _trace_in: = 0.0
var ploughed: = 0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	_settings = Config.Drive.Winter.get("RoadSnow", {})
	clock = float(_settings.get("Start", 0.7))
	_area = SnowCover.area()
	_image = Image.create_empty(PIXELS, PIXELS, false, Image.FORMAT_RH)
	_image.fill(Color(0, 0, 0))
	_texture = ImageTexture.create_from_image(_image)
	RenderingServer.global_shader_parameter_set("road_snow", _texture)
	RenderingServer.global_shader_parameter_set("road_snow_clock", clock)



func depth_at(at: Vector3) -> float:
	if not Style.winter():
		return 0.0
	var pixel: = _pixel(at)
	if pixel.x < 0:
		return clampf(clock, 0.0, 1.0)
	return clampf(clock - _image.get_pixelv(pixel).r, 0.0, 1.0)


func _pixel(at: Vector3) -> Vector2i:
	var uv: = (Vector2(at.x, at.z) - _area.position) / _area.size
	if uv.x < 0.0 or uv.y < 0.0 or uv.x >= 1.0 or uv.y >= 1.0:
		return Vector2i(-1, -1)
	return Vector2i(uv * PIXELS)


func _process(delta: float) -> void :
	if not Style.winter() or _settings.is_empty():
		return

	var falling: = Weather.FLURRIES
	if Weather.current:
		falling = maxf(Weather.current.rain, Weather.FLURRIES)
	clock += delta * falling / Weather.FLURRIES / float(_settings["FillTime"])
	RenderingServer.global_shader_parameter_set("road_snow_clock", clock)
	_stamp_in -= delta
	if _stamp_in <= 0.0:
		_stamp_in = STAMP_EVERY
		_plough()
	_upload_in -= delta
	if _dirty and _upload_in <= 0.0:
		_upload_in = UPLOAD_EVERY
		_dirty = false
		_texture.update(_image)
	if _trace:
		_trace_in -= delta
		if _trace_in <= 0.0:
			_trace_in = 5.0
			var plows: = Traffic.current.vehicles.filter( func(car: Traffic.Car) -> bool: return car.kind == "plow") if Traffic.current else []
			print("road snow: clock %.2f, %d plow(s) out at %s, %d pixels ploughed" % [clock, plows.size(), plows.map( func(car: Traffic.Car) -> String: return "%.0f,%.0f" % [car.x, car.z]), ploughed])



func _plough() -> void :
	var traffic: = Traffic.current
	if traffic == null:
		return
	var seen: = {}
	for car: Traffic.Car in traffic.vehicles:
		if car.kind != "plow":
			continue
		seen[car.id] = true
		var blade: = Vector2(car.x, car.z) + Vector2(car.dx, car.dz) * car.half * BLADE_AHEAD * 2.0
		var from: Vector2 = _last.get(car.id, blade)
		_last[car.id] = blade
		if from.distance_to(blade) > 30.0:
			from = blade
		_scrape(from, blade, float(_settings["Blade"]))
	for id: int in _last.keys():
		if not seen.has(id):
			_last.erase(id)



func _scrape(a: Vector2, b: Vector2, half: float) -> void :
	var studs: = _area.size.x / PIXELS
	var low: = (a.min(b) - Vector2(half, half) - _area.position) / studs
	var high: = (a.max(b) + Vector2(half, half) - _area.position) / studs
	var x0: = clampi(floori(low.x), 0, PIXELS - 1)
	var y0: = clampi(floori(low.y), 0, PIXELS - 1)
	var x1: = clampi(ceili(high.x), 0, PIXELS - 1)
	var y1: = clampi(ceili(high.y), 0, PIXELS - 1)
	var line: = b - a
	var long: = line.length_squared()
	var now: = Color(clock, 0, 0)
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			var at: = _area.position + (Vector2(x, y) + Vector2(0.5, 0.5)) * studs
			var t: = clampf((at - a).dot(line) / long, 0.0, 1.0) if long > 0.0 else 0.0
			if at.distance_to(a + line * t) <= half:
				_image.set_pixel(x, y, now)
				ploughed += 1
	_dirty = true
