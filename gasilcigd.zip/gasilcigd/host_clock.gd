class_name HostClock
extends Node









static var offset: = 0.0
static var synced: = false


static func now() -> float:
	return Game.now() + offset


func _ready() -> void :
	Net.share("life.clock", func() -> Variant: return Game.now(), _apply, 2.0, true)
	Net.stopped.connect(_reset)
	Net.join_failed.connect(_reset)


func _exit_tree() -> void :
	_reset()


func _reset() -> void :
	offset = 0.0
	synced = false




func _apply(host_now: Variant) -> void :
	var raw: float = float(host_now) - Game.now()
	if not synced or raw > offset or absf(raw - offset) > 0.25:
		offset = raw
		synced = true
