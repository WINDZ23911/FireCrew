class_name HudIncidentBoard
extends Control






const WIDTH: = 270.0
const LINE: = 22.0
const HEADER: = 26.0
const FULL_WIDTH: = 520.0
const ROW: = 52.0

var _plate: Control
var _title: Label
var _lines: Array[Label] = []
var _full: Control
var _full_title: Label
var _full_rows: Control
var _open: = false
var _tasks: Array = []
var _next: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if not InputMap.has_action("incident_board"):
		InputMap.add_action("incident_board")
		var key: = InputEventKey.new()
		key.physical_keycode = KEY_PERIOD
		InputMap.action_add_event("incident_board", key)
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.visible = false
	add_child(_plate)
	Ui.stripe(_plate, 40)
	_title = Ui.caps("", int(Config.Hud.CapsFloor))
	_title.position = Vector2(10, 5)
	_title.size = Vector2(WIDTH - 20, 18)
	_title.clip_text = true
	_plate.add_child(_title)
	for index in int(Config.Crew.Board.Rows):
		var line: = Ui.label("", int(Config.Hud.TextFloor) - 2)
		line.position = Vector2(10, HEADER + index * LINE)
		line.size = Vector2(WIDTH - 20, LINE)
		line.clip_text = true
		line.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		_plate.add_child(line)
		_lines.append(line)
	_full = Ui.plate(Vector2(FULL_WIDTH, 60))
	_full.visible = false
	add_child(_full)
	Ui.stripe(_full, 90)
	_full_title = Ui.caps("", 18)
	_full_title.position = Vector2(16, 12)
	_full_title.size = Vector2(FULL_WIDTH - 32, 24)
	_full.add_child(_full_title)
	_full_rows = Control.new()
	_full_rows.position = Vector2(8, 44)
	_full_rows.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_full.add_child(_full_rows)
	Text.language_changed.connect( func(_code: String) -> void : _next = 0.0)



func _below() -> float:
	for sibling in get_parent().get_children():
		if sibling is HudCrew and (sibling as HudCrew).visible:
			var plate: Control = (sibling as HudCrew)._plate
			return plate.position.y + plate.size.y + 18.0
	return Ui.MARGIN


static func owners(task: Dictionary) -> Variant:
	var names: Array = (task["who"] as Array).duplicate()
	var parts: Array = []
	if task["lead"]:
		parts.append(Text.m("crew.board.incident.you"))
	for name: String in names:
		if not parts.is_empty():
			parts.append(", ")
		parts.append(name)
	if parts.is_empty():
		return Text.m("crew.board.incident.nobody")
	return Text.join(parts)


func _process(_delta: float) -> void :
	var service: = CrewService.current
	var usable: = service != null and not service.members.is_empty() and not Game.incident.is_empty() and not Net.active()
	if not usable:
		_plate.visible = false
		if _open:
			close()
		return
	if Game.now() >= _next:
		_next = Game.now() + 0.4
		_tasks = CrewTasks.open_tasks(service)
		_show_short()
		if _open:
			_draw_full()
	_plate.position = Vector2(get_parent_area_size().x - WIDTH - Ui.MARGIN, _below())
	if Input.is_action_just_pressed("incident_board") and Game.local_player != null and ( not Game.ui_open or _open):
		if _open:
			close()
		else:
			open()


func _show_short() -> void :
	var shown: = mini(_tasks.size(), _lines.size())
	_plate.visible = true
	_title.text = Text.say(Text.f("crew.board.incident.short", [_tasks.size(), Controls.key_name("incident_board")]))
	for index in _lines.size():
		var line: = _lines[index]
		line.visible = index < shown
		if index >= shown:
			continue
		var task: Dictionary = _tasks[index]
		var nobody: bool = (task["who"] as Array).is_empty() and not task["lead"]
		line.text = Text.say(Text.join(["• ", task["text"], " — ", owners(task)]))
		line.add_theme_color_override("font_color", Ui.state(Ui.AMBER) if nobody else Ui.TEXT)
	if _tasks.is_empty():
		_lines[0].visible = true
		_lines[0].text = Text.say(Text.m("crew.board.incident.none"))
		_lines[0].add_theme_color_override("font_color", Ui.DIM)
		shown = 1
	_plate.size = Vector2(WIDTH, HEADER + shown * LINE + 6)


func is_open() -> bool:
	return _open


func open() -> void :
	_open = true
	_draw_full()
	_full.visible = true
	MenuKit.take_mouse(Game.local_player, true)


func close() -> void :
	if not _open:
		return
	_open = false
	_full.visible = false
	MenuKit.take_mouse(Game.local_player, false)


func _draw_full() -> void :
	for child in _full_rows.get_children():
		child.queue_free()
	_full_title.text = Text.say(Text.m("crew.board.incident.title"))
	var index: = 0
	for task: Dictionary in _tasks:
		index += 1
		var make: Variant = task["make"]
		var nobody: bool = (task["who"] as Array).is_empty() and not task["lead"]
		var detail: = Text.say(Text.join([owners(task), "  ·  ", Text.m("crew.board.incident.assign" if make is Callable else "crew.board.incident.yours")]))
		var choose: = func() -> void : _assign(task)
		var button: = MenuKit.row(Vector2(FULL_WIDTH - 16, ROW - 4), Text.say(task["text"]), detail, Ui.state(Ui.AMBER) if nobody else Ui.TEXT, choose, str(index) if index <= 9 else "", "", 20)
		button.disabled = not make is Callable
		button.position = Vector2(0, (index - 1) * ROW)
		_full_rows.add_child(button)
	if _tasks.is_empty():
		var none: = Ui.label(Text.say(Text.m("crew.board.incident.none")), 18, Ui.DIM)
		none.position = Vector2(8, 4)
		_full_rows.add_child(none)
		index = 1
	_full.size = Vector2(FULL_WIDTH, 44 + index * ROW + 8)
	_full.position = (get_parent_area_size() - _full.size) / 2.0



func _assign(task: Dictionary) -> void :
	var make: Variant = task["make"]
	var service: = CrewService.current
	if not make is Callable or service == null:
		return
	var job: CrewJob = (make as Callable).call()
	if job == null:
		return
	Sounds.ui("ui_squelch")
	if service.order(job) == null:
		Game.notify(Text.m("crew.say.nobody"), "warning", Game.local_player)
	_next = 0.0


func _unhandled_input(event: InputEvent) -> void :
	if not _open:
		return
	if event.is_action_pressed("pause"):
		close()
		get_viewport().set_input_as_handled()
		return
	var number: = MenuKit.number_key(event)
	if number > 0 and number <= _tasks.size():
		_assign(_tasks[number - 1])
		get_viewport().set_input_as_handled()
