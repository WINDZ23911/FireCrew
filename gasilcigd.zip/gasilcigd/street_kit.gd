class_name StreetKit
extends RefCounted





const STEEL: = Color8(120, 124, 128)
const TYRE: = Color8(28, 28, 30)
const BIKE_PAINTS: = [Color8(40, 90, 170), Color8(190, 40, 40), Color8(30, 30, 34), Color8(230, 230, 226), Color8(40, 120, 80), Color8(220, 150, 40), Color8(120, 60, 140)]
const CAT_COATS: = [Color8(214, 130, 60), Color8(36, 34, 34), Color8(120, 116, 112), Color8(238, 236, 230), Color8(150, 104, 70)]
const WOOD_STACK: = Color8(150, 112, 74)
const LOG_ENDS: = Color8(196, 160, 112)
const ROOF_TIN: = Color8(70, 72, 76)
const BIN_LIDS: = [Color8(40, 42, 46), Color8(60, 110, 70), Color8(226, 190, 40), Color8(120, 78, 50), Color8(40, 80, 150)]




static func bicycle(kit: PolishKit, parent: int, place: Transform3D, paint: Color, lean: = 0.0) -> void :
	var frame: = place * Transform3D(Basis(Vector3.BACK, lean), Vector3.ZERO)
	var rear: = Vector3(0, 1.2, 1.9)
	var front: = Vector3(0, 1.2, -1.9)
	var crank: = Vector3(0, 1.1, 0.35)
	var seat: = Vector3(0, 2.75, 0.85)
	var head: = Vector3(0, 2.65, -1.3)
	for at: Vector3 in [rear, front]:
		_wheel(kit, parent, frame, at)
	for pair: Array in [[rear, crank], [rear, seat], [crank, seat], [seat, head], [crank, head], [head, front]]:
		kit.rod(parent, frame * pair[0], frame * pair[1], 0.17, paint, "Metal", "BikeFrame")
	kit.box(parent, frame * Transform3D(Basis(), seat + Vector3(0, 0.22, 0.05)), Vector3(0.45, 0.18, 0.95), TYRE, "SmoothPlastic", "BikeSaddle")
	var bars: = head + Vector3(0, 0.55, 0.25)
	kit.rod(parent, frame * head, frame * bars, 0.15, STEEL, "Metal", "BikeStem")
	kit.rod(parent, frame * (bars + Vector3(-0.9, 0, 0)), frame * (bars + Vector3(0.9, 0, 0)), 0.13, STEEL, "Metal", "BikeBars")



static func cat(kit: PolishKit, parent: int, place: Transform3D, coat: Color) -> void :
	var at: = place.scaled_local(Vector3.ONE * 1.3)
	var belly: = coat.lerp(Color.WHITE, 0.3)
	kit.ball(parent, at * Vector3(0, 0.42, 0.12), Vector3(0.62, 0.8, 0.8) * 1.3, coat, "Fabric", "CatBody")
	kit.ball(parent, at * Vector3(0, 0.6, -0.17), Vector3(0.4, 0.46, 0.3) * 1.3, belly, "Fabric", "CatChest")
	kit.ball(parent, at * Vector3(0, 1.0, -0.2), Vector3(0.52, 0.4, 0.44) * 1.3, coat, "Fabric", "CatHead")

	for side: float in [-1.0, 1.0]:
		var ear: = Transform3D(place.basis * Basis(Vector3.UP, - side * PI / 2), at * Vector3(side * 0.15, 1.27, -0.2))
		kit.wedge(parent, ear, Vector3(0.05, 0.24, 0.16) * 1.3, coat, "Fabric", "CatEar")
	var root: = at * Vector3(0.1, 0.1, 0.5)
	var mid: = at * Vector3(0.45, 0.06, 0.2)
	var tip: = at * Vector3(0.5, 0.08, -0.25)
	kit.rod(parent, root, mid, 0.16, coat, "Fabric", "CatTail")
	kit.rod(parent, mid, tip, 0.15, coat, "Fabric", "CatTail")



static func woodpile(kit: PolishKit, parent: int, place: Transform3D, length: float, height: float) -> void :
	kit.box(parent, place * Transform3D(Basis(), Vector3(0, height / 2.0, 0.2)), Vector3(length, height, 1.4), WOOD_STACK.darkened(0.2), "Wood", "Woodpile")

	var courses: = maxi(int(height / 0.65), 3)
	var thick: = height / courses
	for index in courses:
		var tint: = LOG_ENDS.lerp(WOOD_STACK, 0.25 + 0.5 * float((index * 7 + int(length * 10.0)) % 5) / 4.0)
		kit.rod(parent, place * Vector3( - length / 2.0 + 0.1, thick * (index + 0.5), -0.55), place * Vector3(length / 2.0 - 0.1, thick * (index + 0.5), -0.55), thick * 1.05, tint, "Wood", "Logs")
	kit.box(parent, place * Transform3D(Basis(Vector3.RIGHT, deg_to_rad(-10)), Vector3(0, height + 0.35, -0.1)), Vector3(length + 0.8, 0.15, 2.6), ROOF_TIN, "Metal", "WoodpileRoof")

	var block: = place * Vector3(length / 2.0 - 0.6, 0, -2.0)
	kit.post(parent, block, 1.1, 1.2, WOOD_STACK.darkened(0.1), "Wood", "ChoppingBlock")
	kit.rod(parent, block + Vector3(0, 1.1, 0), block + place.basis * Vector3(0.6, 2.2, -0.4), 0.14, Color8(150, 110, 70), "Wood", "AxeHandle")



static func wheelie_bins(kit: PolishKit, parent: int, place: Transform3D, lids: Array) -> void :
	for index in lids.size():
		var x: = (index - (lids.size() - 1) / 2.0) * 2.2
		var lid: Color = lids[index]
		var body: = Color8(52, 54, 58) if index > 0 else lid
		kit.box(parent, place * Transform3D(Basis(), Vector3(x, 1.75, 0)), Vector3(1.8, 3.1, 2.0), body, "SmoothPlastic", "WheelieBin")
		kit.box(parent, place * Transform3D(Basis(), Vector3(x, 3.42, -0.05)), Vector3(2.0, 0.24, 2.2), lid, "SmoothPlastic", "WheelieLid")



static func cafe_table(kit: PolishKit, parent: int, place: Transform3D, chairs: Color, parasol: Color) -> void :
	kit.post(parent, place.origin, 2.7, 0.3, Color8(44, 46, 50), "Metal", "TableLeg")
	kit.post(parent, place.origin + Vector3(0, 2.7, 0), 0.15, 3.0, Color8(236, 234, 228), "SmoothPlastic", "TableTop")
	for side: float in [-1.0, 1.0]:
		var at: = place * Transform3D(Basis(Vector3.UP, PI / 2 if side > 0 else - PI / 2), Vector3(side * 2.4, 0, 0))
		kit.box(parent, at * Transform3D(Basis(), Vector3(0, 1.7, 0)), Vector3(1.5, 0.2, 1.5), chairs, "Metal", "ChairSeat")
		kit.box(parent, at * Transform3D(Basis(), Vector3(0, 2.6, 0.7)), Vector3(1.5, 1.8, 0.15), chairs, "Metal", "ChairBack")
		for x: float in [-0.6, 0.6]:
			kit.box(parent, at * Transform3D(Basis(), Vector3(x, 0.8, 0)), Vector3(0.12, 1.6, 1.3), chairs.darkened(0.2), "Metal", "ChairLegs")
	if parasol.a > 0.0:
		kit.post(parent, place.origin + Vector3(0, 2.85, 0), 4.5, 0.2, Color8(230, 230, 226), "Metal", "ParasolPole")
		var canopy: = Transform3D(Basis(Vector3.BACK, PI / 2), place.origin + Vector3(0, 7.6, 0))
		kit._made(kit.store.add(PartStore.Shape.CYLINDER, canopy, Vector3(0.35, 8.5, 8.5), parasol, "Fabric", "Parasol", parent, PolishKit.LOOK))
		kit.post(parent, place.origin + Vector3(0, 7.2, 0), 0.45, 8.9, parasol.darkened(0.15), "Fabric", "ParasolValance")




static func board(kit: PolishKit, parent: int, place: Transform3D, size: Vector2, color: Color, words: String, ink: Color, part_name: String, font: = "Font.GothamBold") -> int:
	var plate: = kit.box(parent, place, Vector3(size.x, size.y, 0.1), color, "SmoothPlastic", part_name)
	var gui: = kit.store.add_node(plate, "SurfaceGui", part_name + "Text", {"Face": "NormalId.Front", "PixelsPerStud": 50.0})
	kit.store.add_node(gui, "TextLabel", "Words", {
		"Text": words, "TextColor3": ink, "Font": font, "TextScaled": true, 
		"Size": {"X": {"Scale": 0.86, "Offset": 0}, "Y": {"Scale": 0.74, "Offset": 0}}, 
		"Position": {"X": {"Scale": 0.07, "Offset": 0}, "Y": {"Scale": 0.13, "Offset": 0}}, 
	})
	return plate



static func a_board(kit: PolishKit, parent: int, place: Transform3D, words: String) -> void :
	var frame: = Color8(120, 84, 54)
	for side: float in [-1.0, 1.0]:
		var leaf: = place * Transform3D(Basis(Vector3.RIGHT, side * 0.2), Vector3(0, 1.75, side * 0.36))
		kit.box(parent, leaf, Vector3(2.1, 3.5, 0.12), frame, "Wood", "ABoard")
	var face: = place * Transform3D(Basis(Vector3.RIGHT, -0.2), Vector3(0, 1.85, -0.43))
	board(kit, parent, face, Vector2(1.8, 2.6), Color8(34, 38, 36), words, Color8(240, 238, 226), "ABoardFace", "Font.Gotham")




static func _wheel(kit: PolishKit, parent: int, frame: Transform3D, at: Vector3) -> void :
	var radius: = 1.1
	for index in 8:
		var a: = TAU * index / 8.0
		var b: = TAU * (index + 1) / 8.0
		kit.rod(parent, frame * (at + Vector3(0, sin(a), cos(a)) * radius), frame * (at + Vector3(0, sin(b), cos(b)) * radius), 0.16, TYRE, "Rubber", "BikeTyre")
	kit.box(parent, frame * Transform3D(Basis(), at), Vector3(0.24, 0.26, 0.26), STEEL, "Metal", "BikeHub")
	for a: float in [0.4, 0.4 + PI / 2]:
		var spoke: = Vector3(0, sin(a), cos(a)) * radius
		kit.rod(parent, frame * (at - spoke), frame * (at + spoke), 0.05, STEEL, "Metal", "BikeSpoke")



static func facing(at: Vector3, toward: Vector3) -> Transform3D:
	return PolishKit.facing(Vector3(at.x, 0, at.z), toward)




static func clear_below(kit: PolishKit, at: Vector3, radius: float, under: = 7.0, above: = 0.3, ignoring: Array = []) -> bool:
	kit._build_grid()
	var low: = Vector2i(floori((at.x - radius) / PolishKit.CELL), floori((at.z - radius) / PolishKit.CELL))
	var high: = Vector2i(floori((at.x + radius) / PolishKit.CELL), floori((at.z + radius) / PolishKit.CELL))
	for cx in range(low.x, high.x + 1):
		for cz in range(low.y, high.y + 1):
			for row: int in kit._grid.get(Vector2i(cx, cz), PackedInt32Array()):
				if kit._top(row) > above and _bottom(kit.store, row) < under and kit._near(row, at, radius):
					if ignoring.is_empty() or not ignoring.has(kit.store.name_at(row)):
						return false
	return true


static func _bottom(store: PartStore, row: int) -> float:
	var d: = store.data
	var i: = row * PartStore.COLUMNS
	return d[i + 3] - (absf(d[i + 8]) * (d[i + 14] / 2.0) + absf(d[i + 9]) * (d[i + 15] / 2.0) + absf(d[i + 10]) * (d[i + 16] / 2.0))
