class_name Bystanders
extends Node3D


















const TICK: = 1.0
const KEPT_CLEAR: = ["crash", "tree", "hazmat"]
const SPOT_STEP: = 5.0

const STAND: = {
	"pavement": {"aside": 3.5, "height": 0.5}, 
	"corner": {"aside": 2.0, "height": 0.5}, 
	"parkpath": {"aside": 3.0, "height": 0.1}, 
	"path": {"aside": 1.0, "height": 0.1}, 
	"roadside": {"aside": 1.5, "height": 0.2}, 
	"crossing": {"aside": 2.0, "height": 0.2}, 
}
const HAZARD_MARGIN: = 20.0
const REPLIES: = 6
const SHOUT_TIME: = 2.0
const ARM_TIME: = 1.2

static var current: Bystanders

var graph: NavGraph
var walk: Array = []
var people: Pedestrians
var scene: Dictionary = {}
var _lots: Array = []
var _leaving: Dictionary = {}
var _last_health: = 0.0
var _last_order: Dictionary = {}
var _elapsed: = 0.0
var _shout: Label3D
var _shout_until: = 0.0
var _shouter: Player
var _last_failed: = false

var road: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


static func _between(span: Vector2) -> float:
	return randf_range(span.x, span.y)



static func _outside(lot: Dictionary, x: float, z: float) -> float:
	var dx: float = x - lot["x"]
	var dz: float = z - lot["z"]
	var across: float = absf(dx * lot["cos"] - dz * lot["sin"]) - lot["halfWidth"]
	var along: float = absf(dx * lot["sin"] + dz * lot["cos"]) - lot["halfDepth"]
	return sqrt(maxf(across, 0.0) ** 2 + maxf(along, 0.0) ** 2)


func _in_any_building(x: float, z: float) -> bool:
	for lot: Dictionary in _lots:
		if _outside(lot, x, z) < 2.0:
			return true
	return false


static func _smoke_at(x: float, z: float) -> float:
	return FireService.current.smoke_at(Vector3(x, 3, z)) if FireService.current else 0.0





func _new_scene(position: Vector3) -> void :
	var settings: Dictionary = Config.Life
	var is_fire: bool = Game.incident.get("kind", "fire") == "fire"

	var burning: Dictionary = {}
	for lot: Dictionary in _lots:
		if _outside(lot, position.x, position.z) == 0.0 and (burning.is_empty() or lot["halfWidth"] * lot["halfDepth"] < burning["halfWidth"] * burning["halfDepth"]):
			burning = lot

	if not is_fire:
		burning = {}
	var away: = func(x: float, z: float) -> float:
		if not burning.is_empty():
			return _outside(burning, x, z)
		return sqrt((x - position.x) ** 2 + (z - position.z) ** 2)
	var band: Vector2 = settings["WatchBand"] if not burning.is_empty() else settings["SmallWatchBand"]
	var extent: float = maxf(burning["halfWidth"], burning["halfDepth"]) if not burning.is_empty() else 0.0
	var creep: Vector2 = settings["CreepBand"]


	var spots: Array = []
	var reach: = band.y + 40.0
	for a in walk.size():
		var node: Dictionary = walk[a]
		for link: Dictionary in node["links"]:
			var stand: Variant = STAND.get(link["kind"])
			var to: int = link["to"]
			var length: float = link["length"]
			if a >= to or stand == null or length < 0.01 or away.call(node["x"], node["z"]) >= reach + length:
				continue
			var other: Dictionary = walk[to]
			var steps: = maxi(1, int(length / SPOT_STEP))
			var nx: float = - (other["z"] - node["z"]) / length
			var nz: float = (other["x"] - node["x"]) / length
			for i in range(1, steps + 1):
				var t: = (i - 0.5) / steps
				var aside: = randf_range( - stand["aside"], stand["aside"])
				var x: float = node["x"] + (other["x"] - node["x"]) * t + nx * aside
				var z: float = node["z"] + (other["z"] - node["z"]) * t + nz * aside
				var far: float = away.call(x, z)
				if far >= creep.x and far <= reach and not _in_any_building(x, z):
					spots.append({"x": x, "z": z, "height": stand["height"], "far": far, "node": a if t < 0.5 else to, "taken": false})

	scene = {
		"kind": Game.incident.get("kind", "fire"), 
		"radius": extent + float(settings["RoadClosed"] if not burning.is_empty() else settings["SmallRoadClosed"]), 
		"position": position, 
		"face": Vector3(position.x, 3, position.z), 
		"band": band, 
		"spots": spots, 
		"crowd": {}, 
		"drew": false, 
		"fire": is_fire, 
		"crowded": 0.0, 
	}
	if people:
		people.set_hazard({"x": position.x, "z": position.z, "radius": extent + HAZARD_MARGIN})
	_close_streets()




func _close_streets() -> void :
	var position: Vector3 = scene["position"]
	var full: = {"x": position.x, "z": position.z, "radius": scene["radius"]}
	var at: Variant = road.get("at")
	var own: bool = at is Vector3 and (at as Vector3).distance_to(position) < 1.0
	if scene["kind"] in CarCrash.ROAD_KINDS and not (own and road.get("closed", false)):
		full = {"x": position.x, "z": position.z, "radius": float(Config.Incidents.Road.SlowRadius), "open": true, "bodies": road.get("bodies", []) if own else []}
	if graph.closure != full:
		graph.closure = full




func set_road(at: Vector3, along: Vector3, bodies: Array, closed: bool) -> void :
	road = {"at": at, "along": along, "bodies": bodies, "closed": closed}
	if not scene.is_empty() and scene["position"].distance_to(at) < 1.0:
		_close_streets()


func _end_scene() -> void :
	var settings: Dictionary = Config.Life
	var now: = Game.now()

	var saved: bool = (scene["fire"] and _last_health > 0.0) or (scene["kind"] in KEPT_CLEAR and not _last_failed)
	for person: Pedestrians.Person in scene["crowd"]:
		_leaving[person] = now + _between(settings["LeaveAfter"])
		if saved and person.state == "watch":
			people.set_mood(person, "cheer")

	if saved and scene["drew"] and scene["crowded"] <= float(settings["ClearSlack"]):
		var geared: Array[Player] = []
		for player in CallKit.crew_near(scene["position"], float(settings["ClearRange"])):
			if player.get_attr("Geared", false):
				geared.append(player)
		for player in CallKit.pay_helpers(geared, int(settings["ClearBonus"]), "", "", false):
			Game.notify(Text.f("calls.bystanders.keptClear", [Alarm.pay(int(settings["ClearBonus"]))]), "", player)
	scene = {}
	if people:
		people.set_hazard({})
	graph.closure = {}







func _barred(spot: Dictionary) -> bool:
	var cordon: = graph.cordon
	if cordon.is_empty():
		return false
	var settings: Dictionary = Config.Life
	var fx: float = scene["position"].x
	var fz: float = scene["position"].z
	for tape: Dictionary in cordon.get("tapes", []):
		var dx: float = tape["bx"] - tape["ax"]
		var dz: float = tape["bz"] - tape["az"]
		var spot_side: float = dx * (spot["z"] - tape["az"]) - dz * (spot["x"] - tape["ax"])
		var fire_side: float = dx * (fz - tape["az"]) - dz * (fx - tape["ax"])
		if spot_side * fire_side > 0.0:

			var t: = clampf(((spot["x"] - tape["ax"]) * dx + (spot["z"] - tape["az"]) * dz) / (dx * dx + dz * dz), 0.0, 1.0)
			var gap: float = (spot["x"] - tape["ax"] - dx * t) ** 2 + (spot["z"] - tape["az"] - dz * t) ** 2
			if gap < float(settings["TapeReach"]) ** 2:
				return true
	for cone: Dictionary in cordon.get("cones", []):
		if (spot["x"] - cone["x"]) ** 2 + (spot["z"] - cone["z"]) ** 2 < float(settings["ConeRoom"]) ** 2:
			return true
	return false




func _pick_spot(from: Vector3, least: float, most: float) -> Dictionary:
	var settings: Dictionary = Config.Life
	var spacing: = float(settings["SpotSpacing"]) ** 2
	for attempt in 3:
		var best: Dictionary = {}
		var best_score: = INF
		for spot: Dictionary in scene["spots"]:
			if spot["taken"] or spot["far"] < least or spot["far"] > most or _barred(spot):
				continue
			var score: float = sqrt((spot["x"] - from.x) ** 2 + (spot["z"] - from.z) ** 2) + randf_range(0, 25)
			if score >= best_score:
				continue
			var free: bool = _smoke_at(spot["x"], spot["z"]) < float(settings["SmokeLimit"])
			if free:
				for member: Dictionary in scene["crowd"].values():
					var other: Dictionary = member["spot"]
					if (other["x"] - spot["x"]) ** 2 + (other["z"] - spot["z"]) ** 2 < spacing:
						free = false
						break
			if free:
				best = spot
				best_score = score
		if not best.is_empty():
			return best
		most += 20.0
	return {}



func _send(person: Pedestrians.Person, spot: Dictionary, close: bool) -> bool:
	if not people.send_to(person, spot["node"], Vector3(spot["x"], spot["height"], spot["z"]), scene["face"]):
		return false
	var member: Dictionary
	if scene["crowd"].has(person):
		member = scene["crowd"][person]
		member["spot"]["taken"] = false
	else:
		member = {"held_until": 0.0}
		scene["crowd"][person] = member
	member["spot"] = spot
	member["close"] = close
	spot["taken"] = true
	scene["drew"] = true
	return true





static func _flat(vector: Vector3) -> Vector3:
	return Vector3(vector.x, 0, vector.z)




func order(origin: Vector3, look: Vector3, reach: float) -> void :
	if people == null or Net.is_client():
		return
	var settings: Dictionary = Config.Life
	var now: = Game.now()
	var hears: = func(person: Pedestrians.Person) -> bool:
		var offset: = _flat(people.where(person) - origin)
		return offset.length() < reach and (offset.length() < 4.0 or offset.normalized().dot(look) > -0.2)

	var moved: Array = []
	for person: Pedestrians.Person in people.people.values():
		var member: Variant = scene["crowd"].get(person) if not scene.is_empty() else null
		if member != null and hears.call(person):
			member["held_until"] = now + float(settings["MoveBackHold"])
			var spot: Dictionary = member["spot"]
			var band: Vector2 = scene["band"]
			if spot["far"] < band.y - 4.0:
				var back: = _pick_spot(Vector3(spot["x"], 0, spot["z"]), band.y - 4.0, band.y + float(settings["MoveBackOut"]))
				if not back.is_empty() and _send(person, back, false):
					moved.append(person)
		elif member == null and not _leaving.has(person) and hears.call(person) and people.shoo(person, origin):
			moved.append(person)


	for index in mini(moved.size(), randi_range(1, 2)):
		var person: Pedestrians.Person = moved.pop_at(randi() % moved.size())
		people.say(person, Text.m("calls.bystanders.replies.%d" % randi_range(1, REPLIES)))



func command(player: Player) -> void :
	var settings: Dictionary = Config.Life
	var now: = Game.now()
	if now - _last_order.get(player, -100.0) < float(settings["MoveBackEvery"]):
		return
	_last_order[player] = now
	if not player.get_attr("Geared", false):
		Game.notify(Text.m("calls.bystanders.needUniform"), "", player)
		return
	_show_shout(player)
	Net.broadcast("bystanders.shout", [Net.peer_of(player)])
	var look: = _flat(player.facing()).normalized()
	order(player.root_position(), look, float(settings["MoveBackRange"]))

	if Traffic.current != null and not Net.is_client():
		Traffic.current.wave_off(player.root_position(), look, float(settings["MoveBackRange"]) * 2.0)



func _show_shout(player: Player) -> void :
	if _shout == null:
		_shout = Label3D.new()
		_shout.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		_shout.pixel_size = 0.012
		_shout.font = Ui.world_label_font()
		_shout.font_size = 64
		_shout.outline_size = 16
		_shout.outline_modulate = Color(0.08, 0.09, 0.11)
		_shout.physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
		add_child(_shout)
	_shout.text = Text.say(Text.m("hud.command.moveBack"))
	_shout.visible = true
	if is_instance_valid(_shouter) and _shouter != player:
		_shouter.rig.extras.erase("command")
	_shouter = player
	_shout_until = Game.now() + SHOUT_TIME





func _tick() -> void :
	var settings: Dictionary = Config.Life
	var now: = Game.now()
	var incident: = Game.incident
	var position: Variant = incident.get("pos")
	if incident.has("health"):
		_last_health = incident["health"]
	if not scene.is_empty() and (position == null or position.distance_to(scene["position"]) > 1.0):
		_end_scene()
	if position != null and scene.is_empty():
		_new_scene(position)
	if people == null:
		return

	for person: Pedestrians.Person in _leaving.keys():
		if person.gone or ( not scene.is_empty() and scene["crowd"].has(person)):
			_leaving.erase(person)
		elif now >= _leaving[person]:
			_leaving.erase(person)
			people.release(person)
	if scene.is_empty():
		return
	var band: Vector2 = scene["band"]
	var creep: Vector2 = settings["CreepBand"]
	var crowd: Dictionary = scene["crowd"]


	for person: Pedestrians.Person in crowd.keys():
		var member: Dictionary = crowd[person]
		var spot: Dictionary = member["spot"]
		if person.gone:
			spot["taken"] = false
			crowd.erase(person)
		elif person.state == "watch":
			if spot["far"] < band.x - 4.0:
				scene["crowded"] += TICK
			var from: = Vector3(spot["x"], 0, spot["z"])
			if _barred(spot):

				var back: = _pick_spot(from, creep.x, band.y + float(settings["MoveBackOut"]))
				if not back.is_empty():
					_send(person, back, false)
			elif _smoke_at(spot["x"], spot["z"]) >= float(settings["SmokeLimit"]):
				var back: = _pick_spot(from, spot["far"] + 8.0, spot["far"] + 30.0)
				if not back.is_empty():
					_send(person, back, false)
			elif not member["close"] and now >= member["held_until"] and randf() < float(settings["CreepChance"]) * TICK:
				var nearer: = _pick_spot(from, creep.x, creep.y)
				if not nearer.is_empty() and nearer["far"] < spot["far"]:
					_send(person, nearer, true)


	var wanted: = clampi(2 + int(incident.get("flames", 1)), 2, int(settings["CrowdMax"]))
	var at_fire: Vector3 = scene["position"]
	for person: Pedestrians.Person in people.people.values():
		if crowd.size() >= wanted:
			return
		var free: = not crowd.has(person) and not _leaving.has(person) and person.on < 0
		var about: = person.state in ["walk", "idle", "talk", "sit"]
		if free and about and randf() < float(settings["GatherChance"]) * TICK:
			var at: = people.where(person)
			if Vector3(at.x, at_fire.y, at.z).distance_to(at_fire) < float(settings["GatherRange"]):
				var spot: = _pick_spot(at, band.x, band.y)
				if not spot.is_empty():
					_send(person, spot, false)


	if crowd.size() < wanted and randf() < float(settings["NeighbourChance"]) * TICK:
		var neighbour: = people.come_out(at_fire.x, at_fire.z, float(settings["NeighbourRange"]))
		if neighbour != null:
			var spot: = _pick_spot(people.where(neighbour), band.x, band.y)
			if not spot.is_empty():
				_send(neighbour, spot, false)


func start(nav_graph: NavGraph, layout: Dictionary) -> void :
	graph = nav_graph
	walk = nav_graph.walk

	Net.handle("bystanders.command", func(player: Player) -> void : command(player))


	Game.incident_ending.connect( func(last: Dictionary) -> void :
		if not scene.is_empty() and not Net.is_client():
			if last.has("health"):
				_last_health = last["health"]
			_last_failed = last.get("failed", false)
			_end_scene()
	)
	Net.handle("bystanders.shout", func(peer: int) -> void :
		var player: = Net.player_of(peer)
		if player != null:
			_show_shout(player)
	)
	people = Pedestrians.current

	for vehicle in Vehicle.all:
		vehicle.horn.connect( func() -> void :
			order(vehicle.global_position, _flat( - vehicle.global_basis.z).normalized(), float(Config.Life.HornRange))
		)
	for building: Dictionary in layout["buildings"]:
		var yaw: = deg_to_rad(building["yaw"])
		_lots.append({
			"x": building["x"], 
			"z": building["z"], 
			"halfWidth": float(building["width"]) / 2.0, 
			"halfDepth": float(building["depth"]) / 2.0, 
			"cos": cos(yaw), 
			"sin": sin(yaw), 
		})


func _process(delta: float) -> void :
	if graph == null:
		return
	var player: = Game.local_player
	if player != null and not Game.ui_open and player.health > 0.0:

		if Input.is_action_just_pressed("pattern") and player.get_attr("Line") == null and player.seat == null:
			Net.request("bystanders.command")

	if _shout != null and _shout.visible:
		var now: = Game.now()
		if now > _shout_until or not is_instance_valid(_shouter):
			_shout.visible = false
			if is_instance_valid(_shouter):
				_shouter.rig.extras.erase("command")
		else:
			_shout.global_position = _shouter.head_position() + Vector3(0, 2.2, 0)
			_shout.modulate.a = clampf((_shout_until - now) * 3.0, 0.0, 1.0)
			_shout.outline_modulate.a = _shout.modulate.a

			var out: = clampf((_shout_until - (SHOUT_TIME - ARM_TIME) - now) * 5.0, 0.0, 1.0) * clampf((now - (_shout_until - SHOUT_TIME)) * 10.0, 0.0, 1.0)
			_shouter.rig.extras["command"] = {"ShoulderR": Vector3(deg_to_rad(88) * out, 0, 0)}

	if Net.is_client():
		return
	_elapsed += delta
	if _elapsed >= TICK:
		_elapsed = 0.0
		_tick()
