class_name HudPrompts
extends Control






static var current: HudPrompts

var _rows: Dictionary = {}
var _held: Dictionary = {}
var _more: Control
var _more_lines: Array[Label] = []
var _more_hint: Label
const MORE_ROW: = 24.0




static func top() -> float:
	if current == null:
		return INF
	var highest: = INF
	for key: String in current._rows:
		var plate: Control = current._rows[key]["plate"]
		if plate.visible:
			highest = minf(highest, plate.get_global_rect().position.y)
	return highest



static func middle_x() -> float:
	if current == null:
		return INF
	var highest: = INF
	var middle: = INF
	for key: String in current._rows:
		var plate: Control = current._rows[key]["plate"]
		if plate.visible and plate.get_global_rect().position.y < highest:
			highest = plate.get_global_rect().position.y
			middle = plate.get_global_rect().get_center().x
	return middle


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_more = Ui.plate(Vector2(220, 40))
	_more.custom_minimum_size = Vector2.ZERO
	_more.visible = false
	add_child(_more)
	for index in Prompt.CHOICES - 1:
		var line: = Ui.label("", 16, Ui.DIM)
		line.position = Vector2(14, 6 + index * MORE_ROW)
		line.size = Vector2(200, MORE_ROW)
		line.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		_more.add_child(line)
		_more_lines.append(line)
	_more_hint = Ui.caps("", 11)
	_more_hint.modulate = Ui.DIM
	_more.add_child(_more_hint)


func _row(key: String) -> Dictionary:
	if _rows.has(key):
		return _rows[key]
	var plate: = Ui.plate(Vector2(320, 58))
	plate.custom_minimum_size = Vector2.ZERO
	add_child(plate)
	var cap: = Ui.action_key(key)
	cap.position = Vector2(14, 14)
	plate.add_child(cap)
	var action: = Ui.display("", 22)
	action.position = Vector2(26 + cap.size.x, 4)
	plate.add_child(action)
	var object: = Ui.caps("", 14)
	object.position = Vector2(26 + cap.size.x, 32)
	plate.add_child(object)
	var bar: = Ui.bar(Vector2(300, 8), Ui.YELLOW)
	bar.position = Vector2(10, 52)
	plate.add_child(bar)
	_rows[key] = {"plate": plate, "cap": cap, "action": action, "object": object, "bar": bar}
	return _rows[key]


func _process(_delta: float) -> void :
	var player: = Game.local_player

	for key: String in _held.keys():
		if player == null or not player.prompt_held.has(key):
			if float(_held[key]) >= 0.92:
				Sounds.ui("ui_prompt_done")
			_held.erase(key)
	var y: = -230.0
	var simple: = Settings.simple()
	_more.visible = false
	for key: String in Player.PROMPT_KEYS:
		var offered: Variant = player.prompts.get(key) if player else null
		var prompt: Prompt = offered if is_instance_valid(offered) else null
		if simple and key != "interact":
			prompt = null
		if prompt == null:
			if _rows.has(key):
				_rows[key]["plate"].visible = false
			continue
		var row: = _row(key)
		var plate: Control = row["plate"]
		plate.visible = true
		row["action"].text = Text.say(prompt.action)
		row["object"].text = Text.say(prompt.object).to_upper()


		var inset: float = 26.0 + (row["cap"] as Control).size.x
		row["action"].position.x = inset
		row["object"].position.x = inset
		var width: = maxf(220.0, maxf(row["action"].get_minimum_size().x, row["object"].get_minimum_size().x) + inset + 24.0)
		plate.size.x = width
		plate.position = Vector2( - width / 2, y)
		y -= 70.0
		var bar: Control = row["bar"]
		bar.visible = prompt.hold > 0.0
		if prompt.hold > 0.0:
			bar.size.x = width - 20
			var held_key: = key
			if simple:

				for other: String in Player.PROMPT_KEYS:
					if player.prompt_held.has(other) and player.prompts.get(other) == prompt:
						held_key = other
			Ui.set_bar(bar, player.prompt_held.get(held_key, 0.0) / prompt.hold)
			if player.prompt_held.has(held_key):
				_held[held_key] = float(player.prompt_held[held_key]) / prompt.hold
		if simple and key == "interact":
			_show_more(player, plate)



func _show_more(player: Player, plate: Control) -> void :
	var others: Array[Prompt] = []
	for index in player.choices.size():
		if index != player.choice and is_instance_valid(player.choices[index]):
			others.append(player.choices[index])
	if others.is_empty():
		return
	var width: = plate.size.x
	for index in _more_lines.size():
		var line: = _more_lines[index]
		line.visible = index < others.size()
		if line.visible:
			line.text = Text.say(others[index].action)
			width = maxf(width, line.get_minimum_size().x + 28.0)
	_more_hint.text = Text.say(Text.m("hud.prompts.wheel")).to_upper()
	width = maxf(width, _more_hint.get_minimum_size().x + 28.0)
	var lines_height: = others.size() * MORE_ROW
	_more_hint.position = Vector2(14, 8 + lines_height)
	_more.size = Vector2(width, lines_height + 32.0)
	_more.position = Vector2( - width / 2.0, plate.position.y + plate.size.y + 6.0)
	for line in _more_lines:
		line.size.x = width - 28.0
	_more.visible = true
