class_name CallLog
extends RefCounted










static var _reports: Array = []
static var _listeners: Array[Callable] = []



static func add(report: Dictionary) -> void :
	_reports.push_front(report)
	_reports.resize(mini(_reports.size(), int(Config.Alarm.EndScreen.Kept)))
	for listener: Callable in _listeners.duplicate():
		if listener.is_valid():
			listener.call(report)
		else:
			_listeners.erase(listener)



static func listen(listener: Callable) -> void :
	_listeners.append(listener)



static func recent(count: = -1) -> Array:
	return _reports.duplicate() if count < 0 else _reports.slice(0, count)


static func last() -> Dictionary:
	return _reports[0] if not _reports.is_empty() else {}



static func mine(report: Dictionary) -> Dictionary:
	for line: Dictionary in report.get("crew", []):
		if int(line.get("peer", 0)) == Net.my_id():
			return line
	return {}



static func clear() -> void :
	_reports.clear()
