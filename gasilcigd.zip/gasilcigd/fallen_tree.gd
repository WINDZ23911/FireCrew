class_name FallenTree
extends Node3D





















const TICK: = 0.25
const BUTT_START: = 2.0
const KERB_ROOM: = 1.5
const ROAD_ROOM: = 30.0
const PLAYER_ROOM: = 80.0
const TRIES: = 25
const STRAP: = 4.0
const GRIP_REACH: = 7.0
const GRIP_IN: = 0.4
const LET_GO: = 25.0
const CROWN_ROOM: = 5.0
const LINGER: = 60.0
const FADE: = 2.5
const REGROW: = 120.0
const CAR_HALF: = 3.7
const OFF_CAR: = 11.0

const BARK: = Color8(98, 72, 52)
const HEARTWOOD: = Color8(216, 184, 134)
const RING: = Color8(255, 208, 40)
const STRAP_COLOR: = Color8(218, 133, 65)

static var current: FallenTree

var kind: = "tree"
var position_of_call: = Vector3.ZERO
var scene: Dictionary = {}
var _candidates: = {"broadleaf": [], "conifer": []}
var _dragging: Dictionary = {}
var _last_hint: Dictionary = {}
var _serial: = 0
var _shown: Array = []
var _mirrors: Dictionary = {}


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null






func _find_candidates(layout: Dictionary, avoid: Vector3) -> void :
	var trees: Array = layout["trees"]
	for index in trees.size():
		var tree: Dictionary = trees[index]
		if not _candidates.has(tree["kind"]) or (Vector3(tree["x"], avoid.y, tree["z"]) - avoid).length() < 150.0:
			continue
		var found: = Roads.nearest(layout, tree["x"], tree["z"])
		var nearest: Dictionary = found[0]
		var street: Dictionary = found[1]
		if nearest.is_empty():
			continue
		var half: = float(street["width"]) / 2.0
		if nearest["distance"] >= half + 5.0 and nearest["distance"] <= half + 26.0 and nearest["along"] >= ROAD_ROOM and nearest["along"] <= nearest["length"] - ROAD_ROOM:
			_candidates[tree["kind"]].append({
				"index": index, 
				"kind": tree["kind"], 
				"position": Vector3(tree["x"], 0, tree["z"]), 
				"toward": Vector3(nearest["x"] - tree["x"], 0, nearest["z"] - tree["z"]).normalized(), 
				"distance": nearest["distance"], 
				"half": half, 
				"road": street, 
				"along": nearest["along"], 
			})







func _cut_mark(model: Node3D, place: Transform3D, across: float, lift: float) -> Dictionary:
	var ring: = CallKit.part(model, CallKit.CYLINDER, Vector3(0.45, across, across), place, RING, "Neon", false, 0.0, "CutMark")
	ring.mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var bar: = CallKit.bar(ring, lift, RING, 70.0)
	return {"part": ring, "bar": bar, "position": place.origin, "progress": 0.0, "done": false}






func _build(candidate: Dictionary, standing: int, options: Dictionary) -> Dictionary:
	var store: = Game.store
	var conifer: bool = candidate["kind"] == "conifer"
	var trunk: = store.find_row(standing, "Trunk")
	var leaves: = store.find_row(standing, "Needles" if conifer else "Leaves")
	if trunk < 0 or leaves < 0:
		return {}
	var trunk_size: = store.size(trunk)
	var leaf_color: = store.color(leaves)
	var thick: = clampf(trunk_size.y * 0.85, 1.9, 2.8) if conifer else clampf(trunk_size.y, 2.2, 3.4)
	var tree_scale: = trunk_size.x / (5.0 if conifer else 9.0)
	var half: float = candidate["half"]
	var distance: float = candidate["distance"]
	var length: float = options.get("length", minf(distance + half * 0.6, 48.0))
	var first_cut: = distance - half - KERB_ROOM

	var rng: = RandomNumberGenerator.new()
	rng.seed = int(options.get("seed", 0))

	var toward: Vector3 = candidate["toward"]
	var foot: Vector3 = candidate["position"]
	var base: = Transform3D(Basis(toward, Vector3.UP, toward.cross(Vector3.UP)), foot + Vector3(0, thick / 2.0 + 0.35, 0))
	var lie: = func(s: float) -> Transform3D:
		return base * Transform3D(Basis.IDENTITY, Vector3(s, 0, 0))


	var across: Transform3D = lie.call((first_cut + length) / 2.0) * Transform3D(Basis.IDENTITY, Vector3(0, 2, 0))
	if not options.get("sure", false) and not CallKit.box_clear(across, Vector3(length - first_cut, 3, thick + 2.0), CallKit.rows_of(standing)):
		return {}

	var model: = CallKit.model("FallenTree")
	var tree: = {"model": model, "candidate": candidate, "standing": standing, "pieces": [], "rings": [], "limbs_left": 0, "options": options, "back": false}

	var stump_place: = Transform3D(Basis(Vector3.BACK, PI / 2), foot + Vector3(0, 1.1, 0))
	CallKit.part(model, CallKit.CYLINDER, Vector3(2.2, thick + 0.3, thick + 0.3), stump_place, BARK, "Wood", true, 0.0, "Stump")
	CallKit.part(model, CallKit.CYLINDER, Vector3(0.3, thick * 0.9, thick * 0.9), stump_place * Transform3D(Basis.IDENTITY, Vector3(1.1, 0, 0)), HEARTWOOD, "Wood", false, 0.0, "Break")

	for splinter in 5:
		var round: = rng.randf() * TAU
		var reach: = rng.randf_range(0.1, 0.38) * thick
		var lean: = Basis(toward.cross(Vector3.UP).normalized(), deg_to_rad(rng.randf_range(10, 28))) * Basis(Vector3.UP, rng.randf() * PI)
		var tall: = rng.randf_range(0.6, 1.5)
		CallKit.piece(model, CallKit.BLOCK, Vector3(rng.randf_range(0.25, 0.5), tall, rng.randf_range(0.2, 0.4)), Transform3D(lean, foot + Vector3(cos(round) * reach, 2.2 + tall / 2.0 - 0.2, sin(round) * reach)), HEARTWOOD.darkened(rng.randf_range(0.0, 0.2)))


	var cuts: = int(options["cuts"])
	var marks: Array[float] = [BUTT_START]
	for index in cuts:
		marks.append(first_cut + (length - first_cut) * index / cuts)
	marks.append(length)

	var pieces: Array = tree["pieces"]
	for index in marks.size() - 1:
		var from: = marks[index]
		var to: = marks[index + 1]
		var span: = to - from
		var place: Transform3D = lie.call((from + to) / 2.0)

		var log_part: = CallKit.part(model, CallKit.BLOCK, Vector3(span - 0.06, thick * 0.82, thick * 0.82), place, BARK, "Wood", true, 0.0, "Log")
		log_part.mesh.visible = false
		CallKit.part(log_part, CallKit.CYLINDER, Vector3(span - 0.06, thick, thick), place, BARK, "Wood", false, 0.0, "Bark")
		for side: float in [-1.0, 1.0]:
			CallKit.part(log_part, CallKit.CYLINDER, Vector3(0.08, thick * 0.92, thick * 0.92), place * Transform3D(Basis.IDENTITY, Vector3(side * (span / 2.0 - 0.05), 0, 0)), HEARTWOOD, "Wood", false, 0.0, "End")
		pieces.append({
			"log": log_part, 
			"from": from, 
			"to": to, 
			"length": span, 
			"thick": thick, 
			"butt": index == 0, 
			"crown": index == marks.size() - 2, 

			"heavy": options.get("heavy", false) and index == 1 and marks.size() > 4, 
			"road": candidate["road"], 
			"half": half, 
			"free": false, 
			"cleared": false, 
			"paid": false, 
			"rings": [], 
			"prompts": [], 
			"grips": [], 
			"holders": {}, 
			"dragged": {}, 
		})

	var top: PartNode = pieces[pieces.size() - 1]["log"]
	if conifer:


		var needles: = CallKit.plain(leaf_color)
		for tier in 4:
			var width: = (11.0 - tier * 2.6) * tree_scale * 0.55
			var tier_length: = 5.2 * tree_scale
			var cone: = MeshInstance3D.new()
			cone.name = "NeedleCone%d" % tier
			var shape: = CylinderMesh.new()
			shape.bottom_radius = width / 2.0
			shape.top_radius = width * 0.08
			shape.height = tier_length
			shape.radial_segments = 10
			shape.rings = 1
			cone.mesh = shape
			cone.material_override = needles
			top.add_child(cone)

			var at: Transform3D = lie.call(length - 7.0 + tier * 3.5 * tree_scale + tier_length / 2.0 - 1.0)
			cone.global_transform = Transform3D(Basis( - at.basis.y, at.basis.x, at.basis.z) * Basis.from_scale(Vector3(0.72, 1.0, 1.0)), at.origin + Vector3(0, width * 0.12, 0))
	else:

		for ball: Array in [[2.0, 0.0, 13.0], [7.0, 4.5, 9.0], [6.0, -4.5, 8.5]]:
			var size: float = ball[2] * tree_scale * 0.6
			var place: Transform3D = lie.call(length + ball[0] * tree_scale * 0.5) * Transform3D(Basis.IDENTITY, Vector3(0, size * 0.3 - thick / 2.0, ball[1] * tree_scale * 0.5))
			CallKit.part(top, CallKit.BALL, Vector3.ONE * size, place, leaf_color, "LeafyGrass", false, 0.0, "Leaves")
		for bough: Array in [[28.0, 0.0], [-32.0, 14.0], [12.0, 30.0], [-16.0, -24.0]]:
			var reach: = 7.0 * tree_scale * 0.6
			var place: Transform3D = lie.call(length - 1.5) * Rbx.angles(0, deg_to_rad(bough[0]), deg_to_rad(bough[1])) * Transform3D(Basis.IDENTITY, Vector3(reach / 2.0, 0, 0))
			CallKit.part(top, CallKit.CYLINDER, Vector3(reach, thick * 0.35, thick * 0.35), place, BARK, "Wood", false, 0.0, "Bough")


	for index in range(1, marks.size() - 1):
		var ring: = _cut_mark(model, lie.call(marks[index]), thick + 0.3, thick + 1.0)
		ring["tree"] = tree
		ring["pieces"] = [pieces[index - 1], pieces[index]]
		for piece: Dictionary in ring["pieces"]:
			piece["rings"].append(ring)
		tree["rings"].append(ring)



	var limb_from: = first_cut + 1.5
	var limb_to: = length - 9.0
	var limbs: = int(options.get("limbs", 0)) if limb_to - limb_from >= 3.0 else 0
	var broad: = maxf(tree_scale, 0.8)
	for index in range(1, limbs + 1):
		var s: = limb_from + (limb_to - limb_from) * (index - 0.5) / limbs
		var side: = 1.0 if index % 2 == 0 else -1.0
		var reach: = rng.randf_range(5, 7) * broad
		var carrier: PartNode = top
		for piece: Dictionary in pieces:
			if s >= piece["from"] and s < piece["to"]:
				carrier = piece["log"]

		var out: Transform3D = lie.call(s) * Rbx.angles(0, - side * deg_to_rad(rng.randf_range(55, 72)), 0) * Rbx.angles(0, 0, deg_to_rad(rng.randf_range(12, 24))) * Transform3D(Basis.IDENTITY, Vector3(thick * 0.4, 0, 0))
		var parts: Array = []
		parts.append(CallKit.part(carrier, CallKit.CYLINDER, Vector3(reach, 0.5, 0.5), out * Transform3D(Basis.IDENTITY, Vector3(reach / 2.0, 0, 0)), BARK, "Wood", false, 0.0, "Limb"))
		for tuft: Array in [[0.5, 2.8], [0.9, 2.1]]:
			parts.append(CallKit.part(carrier, CallKit.BALL, Vector3.ONE * tuft[1] * broad, out * Transform3D(Basis.IDENTITY, Vector3(reach * tuft[0], 0, 0)), leaf_color, "LeafyGrass", false, 0.0, "Needles"))
		var ring: = _cut_mark(carrier, out * Transform3D(Basis.IDENTITY, Vector3(0.9, 0, 0)), 1.2, 2.2)
		ring["tree"] = tree
		ring["limb"] = parts
		tree["rings"].append(ring)
		tree["limbs_left"] += 1



	var trunk_rings: Array = []
	for ring: Dictionary in tree["rings"]:
		if not ring.has("limb"):
			trunk_rings.append(ring)
	var tension: Dictionary = Config.Incidents.Tree.Tension
	if not trunk_rings.is_empty() and rng.randf() < float(tension["Chance"]):
		var ring: Dictionary = trunk_rings[rng.randi() % trunk_rings.size()]
		ring["tension"] = (toward.cross(Vector3.UP).normalized()) * (1.0 if rng.randf() < 0.5 else -1.0)


	var debris: Dictionary = Config.Incidents.Tree.Debris
	for index in int(debris["Leaves"]):
		var s: = rng.randf_range(first_cut, length + 4.0)
		var aside: = rng.randf_range(-6.0, 6.0) * tree_scale
		var at: Vector3 = lie.call(s).origin + toward.cross(Vector3.UP) * aside
		var leaf: = CallKit.piece(model, CallKit.BLOCK, Vector3(rng.randf_range(0.8, 1.8), 0.06, rng.randf_range(0.6, 1.4)), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Vector3(at.x, foot.y + 0.4, at.z)), leaf_color.darkened(0.1))
		leaf.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for index in int(debris["Twigs"]):
		var s: = rng.randf_range(first_cut, length)
		var at: Vector3 = lie.call(s).origin + toward.cross(Vector3.UP) * rng.randf_range(-5.0, 5.0)
		var twig: = CallKit.piece(model, CallKit.CYLINDER, Vector3(rng.randf_range(1.5, 3.0), 0.22, 0.22), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Vector3(at.x, foot.y + 0.5, at.z)), BARK)
		twig.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF



	if options.get("line", false):
		var pole_at: = CallKit.ground_at(foot + toward.cross(Vector3.UP) * 9.0 - toward * 2.0 + Vector3(0, 3, 0))
		CallKit.piece(model, CallKit.CYLINDER, Vector3(14.0, 0.7, 0.7), Transform3D(Basis(Vector3.BACK, PI / 2), pole_at + Vector3(0, 7.0, 0)), Color8(92, 76, 60))
		CallKit.piece(model, CallKit.BLOCK, Vector3(3.2, 0.3, 0.3), Transform3D(Basis(Vector3.UP, atan2(toward.x, toward.z)), pole_at + Vector3(0, 13.4, 0)), Color8(70, 70, 74))
		var points: Array = [pole_at + Vector3(0, 13.2, 0)]
		var down: Vector3 = lie.call(length * 0.7).origin + Vector3(0, thick * 0.5, 0)
		points.append((points[0] + down) / 2.0 + Vector3(0, 1.0, 0))
		points.append(down)
		points.append(CallKit.ground_at(lie.call(length + 6.0).origin + Vector3(0, 3, 0)) + Vector3(0, 0.15, 0))
		var wire: = Node3D.new()
		wire.name = "PowerLine"
		model.add_child(wire)
		for index in points.size() - 1:
			var a: Vector3 = points[index]
			var b: Vector3 = points[index + 1]
			var span: = b - a
			var x: = span.normalized()
			var up: = Vector3.UP if absf(x.y) < 0.95 else Vector3.RIGHT
			var z: = x.cross(up).normalized()
			var piece: = CallKit.piece(wire, CallKit.CYLINDER, Vector3.ONE, Transform3D(Basis(x * span.length(), z.cross(x) * 0.14, z * 0.14), (a + b) / 2.0), Color8(28, 28, 30))
			piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		tree["line"] = points
		var end: Vector3 = points[points.size() - 1]
		var sparks: = Node3D.new()
		model.add_child(sparks)
		sparks.global_position = end + Vector3(0, 0.3, 0)
		tree["sparks"] = RbxEmitter.make(sparks, {
			"Texture": Config.Hose.DropletTexture, 
			"Color": [Color(1.0, 0.95, 0.7), Color(0.5, 0.7, 1.0)], 
			"LightEmission": 1, "Brightness": 4, "LightInfluence": 0, 
			"Rate": 30, "Speed": [4, 10], "Lifetime": [0.15, 0.4], "SpreadAngle": 80, 
			"Acceleration": Vector3(0, -40, 0), "Size": [0.18, 0.04], "Direction": Vector3.UP, 
		})

	tree["middle"] = lie.call((first_cut + length) / 2.0).origin
	tree["tip"] = lie.call(length).origin
	return tree






func _drag_speed(piece: Dictionary) -> float:
	var speeds: Dictionary = Config.Incidents.Tree
	if piece["crown"]:
		return speeds["CrownSpeed"]
	return speeds["HeavySpeed"] if piece["heavy"] and piece["holders"].size() < 2 else speeds["LogSpeed"]



func _refresh(piece: Dictionary) -> void :
	var count: int = piece["holders"].size()
	if Net.is_host():
		for player: Player in piece["holders"]:
			player.set_attr("Dragging", _drag_speed(piece))
			StanceService.refresh_speed(player)
	for prompt: Prompt in piece["prompts"]:
		prompt.action = Text.m("calls.tree.drag" if count == 0 else ("calls.tree.help" if piece["heavy"] and count < 2 else "calls.tree.letGo"))


func release(piece: Dictionary, player: Player) -> void :
	var made: Variant = piece["holders"].get(player)
	if made == null:
		return
	if is_instance_valid(made["strap"]):
		made["strap"].queue_free()
	piece["holders"].erase(player)
	_dragging.erase(player)
	if is_instance_valid(player):
		player.set_attr("Dragging", null)
		StanceService.refresh_speed(player)
	_refresh(piece)


func _release_all(piece: Dictionary) -> void :
	for player: Variant in piece["holders"].keys():
		release(piece, player)



func take(piece: Dictionary, player: Player, side: float) -> void :
	if player.health <= 0.0 or player.seat != null:
		return
	var first: bool = piece["holders"].is_empty()
	piece["holders"][player] = {"side": side, "strap": _strap()}
	piece["dragged"][player] = true
	_dragging[player] = piece
	_refresh(piece)
	if first and piece["heavy"]:
		Game.notify(Text.m("calls.tree.heavyHint"), "", player)


func _strap() -> MeshInstance3D:
	var strap: = CallKit.piece(self, CallKit.CYLINDER, Vector3(1, 0.12, 0.12), Transform3D.IDENTITY, STRAP_COLOR)
	strap.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return strap



func _free(piece: Dictionary) -> void :
	piece["free"] = true
	if piece["butt"]:
		return
	var log_part: PartNode = piece["log"]
	for side: float in [-1.0, 1.0]:
		var grip: = Node3D.new()
		grip.name = "Grip"
		log_part.add_child(grip)
		grip.position = Vector3(side * (piece["length"] / 2.0 - GRIP_IN), 0, 0)
		var what: = "calls.tree.top" if piece["crown"] else ("calls.tree.heavyLog" if piece["heavy"] else "calls.tree.log")
		var prompt: = CallKit.prompt(grip, "%s.%d" % [piece["id"], 0 if side < 0.0 else 1], Text.m("calls.tree.drag"), Text.m(what), 0.3, GRIP_REACH)
		piece["prompts"].append(prompt)
		piece["grips"].append(grip)
		prompt.triggered.connect( func(player: Player) -> void :
			if piece["holders"].has(player):
				release(piece, player)
			elif piece["holders"].size() >= (2 if piece["heavy"] else 1):
				var other: Player = piece["holders"].keys()[0]
				Game.notify(Text.f("calls.tree.held", [other.display_name]), "", player)
			else:
				if _dragging.has(player):
					release(_dragging[player], player)
				take(piece, player, side)
		)



func _physics_process(delta: float) -> void :
	if scene.is_empty():
		return
	var deciding: = Net.is_host()
	var ease: = 1.0 - exp( - delta * 14.0)
	for piece: Dictionary in scene["pieces"]:
		var log_part: PartNode = piece["log"]
		if not is_instance_valid(log_part):
			continue
		if not deciding and piece.has("net_to"):

			var to: Transform3D = piece["net_to"]
			if not log_part.global_transform.is_equal_approx(to):
				log_part.global_transform = to if log_part.global_position.distance_to(to.origin) > 12.0 else log_part.global_transform.interpolate_with(to, ease)
		if piece["holders"].is_empty():
			continue
		var reach: float = piece["length"] / 2.0 - GRIP_IN
		for player: Player in piece["holders"]:
			if not is_instance_valid(player):
				continue
			var held: Dictionary = piece["holders"][player]
			var side: float = held["side"]
			var place: = log_part.global_transform
			var grip: = place * Vector3(side * reach, 0, 0)
			var waist: = player.root_position() + Vector3(0, -0.8, 0)
			var offset: = Vector3(grip.x - waist.x, 0, grip.z - waist.z)
			if deciding and offset.length() > STRAP:

				var pulled: = Vector3(waist.x, 0, waist.z) + offset.normalized() * STRAP
				var far: = place * Vector3( - side * reach, 0, 0)
				var way: = Vector3(pulled.x - far.x, 0, pulled.z - far.z)
				if way.length() > 0.01:
					way = way.normalized()
					var middle: = pulled - way * reach
					var ground: = Game.world.raycast(Vector3(middle.x, place.origin.y + 3.0, middle.z), Vector3(middle.x, place.origin.y - 8.0, middle.z), World.LAYER_SOLID, [log_part.get_rid()])
					var height: float = ground["position"].y + piece["thick"] / 2.0 if not ground.is_empty() else place.origin.y
					var along: = way * side
					log_part.global_transform = Transform3D(Basis(along, Vector3.UP, along.cross(Vector3.UP)), Vector3(middle.x, height, middle.z))
					grip = log_part.global_transform * Vector3(side * reach, 0, 0)
			var strap: MeshInstance3D = held["strap"]
			var span: = grip - waist
			if span.length() > 0.05 and is_instance_valid(strap):
				var x: = span.normalized()
				var up: = Vector3.UP if absf(x.y) < 0.95 else Vector3.RIGHT
				var z: = x.cross(up).normalized()
				strap.global_transform = Transform3D(Basis(x * span.length(), z.cross(x) * 0.12, z * 0.12), (grip + waist) / 2.0)






func _cuts_left() -> int:
	var left: = 0
	for ring: Dictionary in scene["rings"]:
		if not ring["done"] and not ring.has("limb"):
			left += 1
	return left



func _drop_limb(ring: Dictionary) -> void :
	for made: PartNode in ring["limb"]:
		if not is_instance_valid(made):
			continue
		var tween: = made.create_tween()
		tween.set_parallel(true)
		tween.tween_property(made, "global_position", made.global_position - Vector3(0, 1.2, 0), 1.2)
		tween.tween_property(made.mesh, "scale", made.mesh.scale * 0.05, 1.2).set_ease(Tween.EASE_IN)
		tween.chain().tween_callback(made.queue_free)




func saw(player: Player, at: Vector3, look: Vector3, dt: float) -> bool:
	if scene.is_empty() or Net.is_client():
		return false
	if line_live() and line_distance(at) < float(Config.Incidents.Tree.Line.KeepClear):
		var now: = Game.now()
		if now - _last_hint.get(player, -100.0) > 4.0:
			_last_hint[player] = now
			Game.notify(Text.m("calls.tree.line.live"), "danger", player)
		return false
	var settings: Dictionary = Config.Tools.Chainsaw
	var nearest: Dictionary = {}
	var nearest_distance: = INF
	var branches_first: = false
	for ring: Dictionary in scene["rings"]:
		if ring["done"]:
			continue

		var where: Vector3 = ring["part"].global_position if is_instance_valid(ring["part"]) else ring["position"]
		var offset: = Vector3(where.x - at.x, 0, where.z - at.z)
		var distance: = offset.length()
		var ahead: = distance < 2.5 or offset.normalized().dot(look) > 0.2
		if distance <= float(settings["Reach"]) and ahead:
			if not ring.has("limb") and ring["tree"]["limbs_left"] > 0:
				branches_first = true
			elif distance < nearest_distance:
				nearest = ring
				nearest_distance = distance
	if nearest.is_empty():
		var now: = Game.now()
		if branches_first and now - _last_hint.get(player, -100.0) > 4.0:
			_last_hint[player] = now
			Game.notify(Text.m("calls.tree.limbsFirst"), "", player)
		return false

	var time: float = settings["LimbTime"] if nearest.has("limb") else settings["CutTime"]


	if nearest.has("tension"):
		var side: Vector3 = nearest["tension"]
		var from: Vector3 = nearest["part"].global_position if is_instance_valid(nearest["part"]) else nearest["position"]
		var wrong: = Vector3(at.x - from.x, 0, at.z - from.z).dot(side) < 0.0
		if wrong and nearest["progress"] >= time * float(Config.Incidents.Tree.Tension.BindAt):
			if not nearest.get("bound", false):
				nearest["bound"] = true
				Alarm.check("tension", false)
				_show_tension(nearest)
			var now: = Game.now()
			if now - _last_hint.get(player, -100.0) > 4.0:
				_last_hint[player] = now
				Game.notify(Text.m("calls.tree.tension.bind"), "warning", player)
			return true
	nearest["progress"] += dt
	CallKit.set_bar(nearest["bar"], nearest["progress"] / time)
	if nearest["progress"] >= time:
		nearest["done"] = true
		nearest["part"].queue_free()
		scene["helpers"][player] = true
		_check_cut(player)
		var rewards: Dictionary = Config.Incidents.Tree
		if nearest.has("limb"):
			_drop_limb(nearest)
			nearest["tree"]["limbs_left"] -= 1
			player.add_cash(int(rewards["LimbReward"]))
			if nearest["tree"]["limbs_left"] == 0:
				Game.notify(Text.m("calls.tree.limbsOff"), "", player)
			return true
		player.add_cash(int(rewards["CutReward"]))
		if nearest.has("tension"):
			if not nearest.get("bound", false):
				Alarm.check("tension", true)
				player.add_cash(int(Config.Incidents.Tree.Tension.Reward))
			Game.notify(Text.m("calls.tree.tension.done"), "", player)
			if is_instance_valid(nearest.get("hint")):
				nearest["hint"].queue_free()

		for piece: Dictionary in nearest["pieces"]:
			var loose: bool = not piece["free"]
			for ring: Dictionary in piece["rings"]:
				loose = loose and ring["done"]
			if loose:
				_free(piece)
		var left: = _cuts_left()
		Game.notify(Text.fill(Text.plural(left, "calls.tree.cutsLeft"), [left]) if left > 0 else Text.m("calls.tree.lastCut"), "", player)
	return true




static func cut_side(ring: Dictionary) -> Vector3:
	return ring.get("tension", Vector3.ZERO)



func _show_tension(ring: Dictionary) -> void :
	if is_instance_valid(ring.get("hint")) or ring["done"]:
		return
	var at: Vector3 = ring["part"].global_position if is_instance_valid(ring["part"]) else ring["position"]
	var spot: = Node3D.new()
	spot.name = "TensionHint"
	ring["tree"]["model"].add_child(spot)
	spot.global_position = at + (ring["tension"] as Vector3) * 2.6
	CallKit.words(spot, Text.m("calls.tree.tension.hint"), Color8(255, 236, 120), 3.2)
	var arrow: = CallKit.piece(spot, CallKit.BLOCK, Vector3(0.3, 1.4, 0.3), Transform3D(Basis.IDENTITY, Vector3(0, 1.7, 0)), Color8(255, 236, 120), 0.6)
	arrow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ring["hint"] = spot






func line_live() -> bool:
	return not scene.is_empty() and scene.get("line", {}).get("live", false)



func line_distance(at: Vector3) -> float:
	var nearest: = INF
	for tree: Dictionary in scene.get("trees", []):
		var points: Array = tree.get("line", [])
		for index in points.size() - 1:
			var a: = Vector2(points[index].x, points[index].z)
			var b: = Vector2(points[index + 1].x, points[index + 1].z)
			var p: = Vector2(at.x, at.z)
			var t: = clampf((p - a).dot(b - a) / maxf((b - a).length_squared(), 0.001), 0.0, 1.0)
			nearest = minf(nearest, p.distance_to(a + (b - a) * t))
	return nearest





func _line_boards(held: Dictionary) -> void :
	var settings: Dictionary = Config.Incidents.Tree.Line
	held["line"]["prompts"] = []
	held["line"]["boards"] = []
	var model: Node3D = held["trees"][0]["model"]
	var candidate: Dictionary = held["trees"][0]["candidate"]
	var road: Dictionary = candidate["road"]
	var out: = float(settings["KeepClear"]) + 10.0
	for index in 2:
		var side: = -1.0 if index == 0 else 1.0
		var way: = Roads.at(road, clampf(float(candidate["along"]) + side * out, 0.0, Roads.length(road)))
		var run: = Vector3(way[2], 0, way[3]).normalized()
		var verge: = run.cross(Vector3.UP) * - side * (float(road.get("width", 20.0)) / 2.0 + 1.5)
		var board: = Node3D.new()
		board.name = "LineBoard"
		model.add_child(board)
		board.global_position = _ground_below(Vector3(way[0], held["trees"][0].get("middle", Vector3.ZERO).y, way[1]) + verge)
		CallKit.piece(board, CallKit.BLOCK, Vector3(0.25, 3.0, 0.25), Transform3D(Basis.IDENTITY, Vector3(0, 1.5, 0)), Color8(60, 60, 64))
		var panel: = CallKit.piece(board, CallKit.BLOCK, Vector3(2.4, 2.0, 0.15), Transform3D(Basis(Vector3.UP, atan2(run.x, run.z)), Vector3(0, 3.6, 0)), Color8(250, 210, 30))
		var label: = CallKit.words(board, Text.m("calls.tree.line.sign"), Color8(250, 210, 30), 5.2, 60.0)
		held["line"]["boards"].append([panel, label])
		var prompt: = CallKit.prompt(board, "tree.%d.line.%d" % [held["serial"], index], Text.m("calls.tree.line.action"), Text.m("calls.tree.line.object"), float(settings["CallTime"]), 9.0)
		prompt.position = Vector3(0, 2.5, 0)
		prompt.triggered.connect( func(player: Player) -> void : _call_utility(held, player))
		held["line"]["prompts"].append(prompt)




func _ground_below(at: Vector3) -> Vector3:
	var hits: Array = []
	var top: = at + Vector3(0, 40, 0)
	for step in 8:
		var hit: = Game.world.raycast(top, at - Vector3(0, 40, 0), World.LAYER_SOLID)
		if hit.is_empty():
			break
		hits.append(hit["position"])
		top = hit["position"] - Vector3(0, 0.05, 0)
	for index in hits.size():
		if index == hits.size() - 1 or hits[index].y - hits[index + 1].y < 2.5:
			return hits[index]
	return at




func _show_line(held: Dictionary, live: bool, left: float) -> void :
	for pair: Array in held.get("line", {}).get("boards", []):
		if not is_instance_valid(pair[1]):
			continue
		var label: Label3D = pair[1]
		if live and left < 0.0:
			label.text = Text.say(Text.m("calls.tree.line.sign"))
		elif live:
			label.text = Text.say(Text.f("calls.tree.line.signCalled", [Alarm.clock(ceilf(left))]))
		else:
			label.text = Text.say(Text.m("calls.tree.line.signDead"))
			label.modulate = Color8(90, 220, 110)
			if is_instance_valid(pair[0]):
				pair[0].material_override = CallKit.plain(Color8(70, 190, 90))



func _call_utility(held: Dictionary, player: Player) -> void :
	if Net.is_client() or not held.get("line", {}).get("live", false):
		return
	var line: Dictionary = held["line"]
	if line["isolate_at"] >= 0.0:
		Game.notify(Text.m("calls.tree.line.already"), "", player)
		return
	var wait: Array = Config.Incidents.Tree.Line.UtilityWait
	var after: = randf_range(float(wait[0]), float(wait[1]))
	line["isolate_at"] = Game.now() + after
	held["helpers"][player] = true
	player.add_cash(int(Config.Incidents.Tree.Line.Reward))
	Game.notify(Text.f("calls.tree.line.called", [player.display_name, int(after)]), "good")




func _step_line(held: Dictionary, dt: float) -> void :
	var line: Dictionary = held.get("line", {})
	if not line.get("live", false):
		return
	var settings: Dictionary = Config.Incidents.Tree.Line
	for player: Player in Game.players:
		if player.health <= 0.0 or player.seat != null:
			continue
		var far: = line_distance(player.root_position())
		if far < float(settings["KeepClear"]):
			Alarm.check("line", false)
			var now: = Game.now()
			if now - float(line["told"].get(player, -100.0)) > 6.0:
				line["told"][player] = now
				Game.notify(Text.m("calls.tree.line.live"), "danger", player)
		if far < float(settings["ShockRange"]):
			player.take_damage(float(settings["Shock"]) * dt)
	if line["isolate_at"] >= 0.0 and Game.now() < line["isolate_at"]:
		_show_line(held, true, float(line["isolate_at"]) - Game.now())
	if line["isolate_at"] >= 0.0 and Game.now() >= line["isolate_at"]:
		line["live"] = false
		_show_line(held, false, -1.0)
		if not Alarm.checks.has("line"):
			Alarm.check("line", true)
		for tree: Dictionary in held["trees"]:
			if tree.get("sparks") != null and is_instance_valid(tree["sparks"]):
				tree["sparks"].emitting = false
		for prompt: Prompt in line["prompts"]:
			prompt.enabled = false
		Game.notify(Text.m("calls.tree.line.dead"), "good")




func _check_cut(player: Player) -> void :
	var rules: Dictionary = Alarm.settings()["Grade"]["Procedure"]
	if not Alarm.checks.has("cones") and scene.has("middle"):
		Alarm.check("cones", Alarm.cones_near(scene["middle"], float(rules["ConeReach"])) >= int(rules["TreeCones"]))
	if not Alarm.checks.has("gear") or Alarm.checks["gear"]:
		Alarm.check("gear", player.get_attr("Geared", false) == true)






func _tally() -> Array:
	var done: = 0
	var finished: = true
	for ring: Dictionary in scene["rings"]:
		if ring["done"]:
			done += 1
		else:
			finished = false
	for piece: Dictionary in scene["pieces"]:
		if piece["butt"]:
			continue
		var at: Vector3 = piece["log"].global_position
		var off: float = Roads.on_road(piece["road"], at.x, at.z)["distance"]
		piece["cleared"] = piece["free"] and off > piece["half"] + 0.5 + piece["length"] * 0.25 + (CROWN_ROOM if piece["crown"] else 0.0)
		if piece["cleared"]:
			done += 1
			if not piece["paid"] and not piece["dragged"].is_empty():
				piece["paid"] = true
				for player: Variant in piece["dragged"]:
					if is_instance_valid(player):
						scene["helpers"][player] = true

				CallKit.pay_helpers(piece["dragged"], int(Config.Incidents.Tree.PieceReward), "", "", false)
		else:
			finished = false
	return [done, finished]




func _next_step(crash: Variant) -> Variant:
	var line: Dictionary = scene.get("line", {})
	if line.get("live", false):
		if float(line["isolate_at"]) < 0.0:
			return Text.m("calls.tree.next.utility")
		return Text.f("calls.tree.next.wait", [Alarm.clock(ceilf(float(line["isolate_at"]) - Game.now()))])
	var limbs: = 0
	var cuts: = 0
	var cut_any: = false
	for ring: Dictionary in scene["rings"]:
		if not ring["done"]:
			if ring.has("limb"):
				limbs += 1
			else:
				cuts += 1
		else:
			cut_any = true

	if not cut_any and not scene.get("road_closed", false):
		return Text.m("calls.tree.next.cones")
	if limbs > 0:
		return Text.f("calls.tree.next.limbs", [limbs])
	if cuts > 0:
		return Text.f("calls.tree.next.cut", [cuts])
	var left: = 0
	for piece: Dictionary in scene["pieces"]:
		if not piece["butt"] and not piece["cleared"]:
			left += 1
	if crash != null:
		var on_car: Variant = CarCrash.current.next_step(crash, true)
		if left > 0 and on_car != null:
			return Text.m("calls.tree.next.crown")
		if on_car != null:
			return on_car
	if left > 0:
		return Text.f("calls.tree.next.drag", [left])
	return null




func _road_bodies(crash: Variant) -> Array:
	var bodies: Array = []
	for piece: Dictionary in scene["pieces"]:
		if not piece["butt"] and not piece["cleared"] and is_instance_valid(piece["log"]):
			var at: Vector3 = piece["log"].global_position
			bodies.append(Vector3(at.x, at.z, minf(float(piece["length"]) / 2.0 + 1.0, 7.0)))
	if crash != null:
		bodies.append_array(CarCrash.road_bodies(crash))
	else:
		bodies.append_array(ScenePolice.bodies())
	return bodies



func _check_straps() -> void :
	for piece: Dictionary in scene["pieces"]:
		for player: Variant in piece["holders"].keys():
			var held: bool = is_instance_valid(player) and player.health > 0.0 and player.seat == null
			if not held or player.root_position().distance_to(piece["log"].global_position) > LET_GO + piece["length"] / 2.0:
				release(piece, player)



func _draw_variant() -> String:
	var settings: Dictionary = Config.Incidents.Tree
	var wanted: Variant = settings.get("Variant")
	if wanted is String and settings["Variants"].has(wanted):
		return wanted
	return CallKit.draw(settings["Variants"], "plain")





func _car_under(candidate: Dictionary) -> Array:
	var toward: Vector3 = candidate["toward"]
	var out: float = candidate["distance"] + candidate["half"] / 2.0
	var at: Vector3 = CallKit.ground_at(candidate["position"] + toward * out)
	var heading: = toward.cross(Vector3.UP)
	if heading.cross(Vector3.UP).dot(toward) > 0.0:
		heading = - heading
	var place: = Rbx.look_at(at, at + heading)
	if not CallKit.box_clear(place * Transform3D(Basis.IDENTITY, Vector3(0, 3.5, 0)), Vector3(7, 5, 16)):
		return []
	return [place, out - CAR_HALF]




func _fell(tree_kind: String, variant: String) -> Array:
	var list: Array = _candidates[tree_kind]
	var settings: Dictionary = Config.Incidents.Tree
	var cuts: = int(CallKit.by_crew(settings["Cuts"]))
	for attempt in (TRIES if not list.is_empty() else 0):
		var candidate: Dictionary = list[randi() % list.size()]
		var standing: = CallKit.tree_model(candidate["index"])
		if standing == 0 or CallKit.player_near(candidate["position"], PLAYER_ROOM):
			continue
		var options: = {"cuts": cuts, "heavy": randf() < float(settings["HeavyChance"]), "seed": randi()}
		var car_place: Variant = null
		if variant == "car":
			var under: = _car_under(candidate)
			if under.is_empty():
				continue
			car_place = under[0]
			options["length"] = under[1]
			options["cuts"] = maxi(cuts - 1, 2)
			options["heavy"] = false
		elif variant == "conifer":
			options["cuts"] = maxi(cuts - 1, 2)
			options["heavy"] = false
			options["limbs"] = int(CallKit.by_crew(settings["Limbs"]))
		elif variant == "double":
			options["cuts"] = maxi(cuts - 1, 2)
		elif variant == "line":
			options["line"] = true
		var tree: = _build(candidate, standing, options)
		if not tree.is_empty():
			return [tree, car_place]
	return []



func _fell_beside(first: Dictionary) -> Dictionary:
	var settings: Dictionary = Config.Incidents.Tree
	var apart: Vector2 = settings["PairApart"]
	var cuts: = maxi(int(CallKit.by_crew(settings["Cuts"])) - 1, 2)
	for candidate: Dictionary in _candidates["broadleaf"]:
		var gap: = absf(candidate["along"] - first["candidate"]["along"])
		if is_same(candidate["road"], first["candidate"]["road"]) and gap >= apart.x and gap <= apart.y:
			var standing: = CallKit.tree_model(candidate["index"])
			if standing != 0:
				var tree: = _build(candidate, standing, {"cuts": cuts, "seed": randi()})
				if not tree.is_empty():
					return tree
	return {}


func available() -> bool:
	return not _candidates["broadleaf"].is_empty()


func run() -> bool:
	var variant: = _draw_variant()
	if variant == "car" and (CarCrash.current == null or VictimService.current == null or CarKit.shapes().is_empty()):
		variant = "plain"
	var felled: = _fell("conifer" if variant == "conifer" else "broadleaf", variant)
	if felled.is_empty() and variant != "plain":
		variant = "plain"
		felled = _fell("broadleaf", variant)
	if felled.is_empty():
		return false
	var first: Dictionary = felled[0]
	var car_place: Variant = felled[1]
	var trees: Array = [first]
	if variant == "double":
		var second: = _fell_beside(first)
		if not second.is_empty():
			trees.append(second)

	_serial += 1
	scene = _gather(_serial, trees)
	_shown.append(scene)
	var middle: = Vector3.ZERO
	for tree: Dictionary in trees:
		middle += tree["middle"] / trees.size()

	var title: = "calls.tree.carTitle" if car_place != null else ("calls.tree.doubleTitle" if trees.size() > 1 else ("calls.tree.lineTitle" if first.has("line") else "calls.tree.title"))
	var call_name: = Text.join([Text.m(title), Text.m("calls.separator"), Roads.name_of(first["candidate"]["road"])])


	var crash: Variant = null
	var wrecks: = CarCrash.current
	var people: = VictimService.current
	if car_place != null:
		crash = wrecks.open(first["model"])
		var car: = wrecks.wreck(crash, car_place, {"sprung": false})
		var place: Transform3D = car_place
		var victims: = people.begin_at({"lot": place, "size": Vector3(14, 6, 20), "name": "the car"}, [wrecks.seat(car, "L")], 100.0 / float(Config.Incidents.Crash.TrappedTime))
		var crown: Dictionary = first["pieces"][first["pieces"].size() - 1]
		if not victims.is_empty():
			wrecks.jam(crash, car, "L", victims[0], func() -> Variant:
				var clear: bool = crown["free"] and crown["log"].global_position.distance_to(place.origin) > OFF_CAR
				return null if clear else Text.m("calls.tree.crownOnCar")
			)
		scene["crash"] = crash

	var total: int = scene["rings"].size() + scene["pieces"].size() - trees.size() + (crash["doors"].size() * CarCrash.JOBS.size() if crash != null else 0)
	position_of_call = middle
	scene["middle"] = middle
	var way: = Roads.at(first["candidate"]["road"], first["candidate"]["along"])
	var along: = Vector3(way[2], 0, way[3]).normalized()
	if first.has("line"):
		scene["line"] = {"live": true, "isolate_at": -1.0, "told": {}, "prompts": []}
		_line_boards(scene)
	CallService.current.publish("tree", call_name, middle, total)


	var par: Dictionary = Alarm.settings()["Grade"]["Job"]
	var lengths: int = scene["pieces"].size() - trees.size()
	var door_jobs: int = crash["doors"].size() * CarCrash.JOBS.size() if crash != null else 0
	Alarm.par(float(par["tree"]["Base"]) + float(par["tree"]["PerCut"]) * scene["rings"].size() + float(par["tree"]["PerPiece"]) * lengths + float(par["crash"]["PerJob"]) * door_jobs)
	Game.notify(Text.f("calls.tree.alarm", [call_name]))
	Game.notify(Text.m("calls.tree.briefCar" if car_place != null else ("calls.tree.briefLine" if first.has("line") else ("calls.tree.briefConifer" if first["limbs_left"] > 0 else "calls.tree.brief"))))

	var waited: = 0.0
	var finished: = false
	var closed: = false
	var nobody: = func(_at: Vector3) -> float: return 0.0
	while not finished and not CallService.current.overdue(waited):
		await get_tree().create_timer(TICK, false).timeout
		waited += TICK
		_check_straps()
		_step_line(scene, TICK)
		var tally: = _tally()
		var done: int = tally[0]
		finished = tally[1]

		var ends: = Cordon.road_ends(middle, along, CarCrash.CONE_ROOM, float(Config.Incidents.Crash.Safety.Range))
		if ends[0] and ends[1] and not closed:
			Game.notify(Text.m("calls.crash.roadClosed"), "good")
		closed = ends[0] and ends[1]
		scene["road_closed"] = closed
		if Bystanders.current:
			Bystanders.current.set_road(middle, along, _road_bodies(crash), closed)
		if crash != null:
			wrecks.tend(crash)
			people.step(TICK, nobody, false)
			wrecks.blink(crash, waited)
			done += wrecks.jobs_done(crash)
			finished = finished and not people.waiting()
			Game.incident.merge(people.shown(), true)
		CallService.current.progress(done)
		CallService.current.next_step(_next_step(crash))

	for piece: Dictionary in scene["pieces"]:
		_release_all(piece)
		for prompt: Prompt in piece["prompts"]:
			prompt.enabled = false
	for prompt: Prompt in scene.get("line", {}).get("prompts", []):
		prompt.enabled = false
	var helpers: Dictionary = scene["helpers"]
	if crash != null:
		wrecks.close(crash)
		var counts: = people.finish()
		for player: Variant in crash["helpers"]:
			helpers[player] = true
		for player: Variant in counts["rescuers"]:
			helpers[player] = true
		VictimService.tally(counts)
		Game.incident.merge(VictimService.card(counts), true)

		finished = finished and int(counts["lost"]) == 0
	Game.incident.erase("next")
	if finished:
		Alarm.done()
		var bonus: = int(Config.Incidents.Tree.Bonus)
		CallKit.pay_helpers(helpers, bonus, "", "bonus")
		Game.notify(Text.f("calls.tree.clear", [call_name, Alarm.pay(bonus)]), "good")
	else:
		Game.notify(Text.f("calls.tree.closed", [call_name]), "warning")



	scene = {}

	await CallService.current.settle()
	CallService.current.clear( not finished)
	var linger: = 0.0 if not finished else (float(Config.Incidents.Crash.TowAfter) if crash != null else LINGER)
	for tree: Dictionary in trees:
		_clear_away(tree, linger)
	return true


func _clear_away(tree: Dictionary, linger: float) -> void :
	if linger > 0.0:
		await get_tree().create_timer(linger, false).timeout
	CallKit.fade(tree["model"], FADE)
	await get_tree().create_timer(FADE + REGROW, false).timeout
	CallKit.set_standing(tree["standing"], true)
	tree["back"] = true

	for held: Dictionary in _shown.duplicate():
		var over: = true
		for one: Dictionary in held["trees"]:
			over = over and one["back"]
		if over:
			_shown.erase(held)




func _gather(serial: int, trees: Array) -> Dictionary:
	var held: = {"serial": serial, "trees": trees, "rings": [], "pieces": [], "helpers": {}, "crash": null}
	for tree: Dictionary in trees:
		if tree["standing"] != 0:
			CallKit.set_standing(tree["standing"], false)
		held["rings"].append_array(tree["rings"])
		held["pieces"].append_array(tree["pieces"])
	for index in held["pieces"].size():
		held["pieces"][index]["id"] = "tree.%d.%d" % [serial, index]
	return held








func _net_state() -> Variant:
	var list: Array = []
	for held: Dictionary in _shown:
		var trees: Array = []
		for tree: Dictionary in held["trees"]:
			trees.append({
				"index": tree["candidate"]["index"], "kind": tree["candidate"]["kind"], "options": tree["options"], 
				"fading": CallKit.fading(tree["model"]), "gone": not CallKit.there(tree["model"]), "back": tree["back"], 
			})
		var rings: Array = []
		for ring: Dictionary in held["rings"]:
			var time: float = Config.Tools.Chainsaw.LimbTime if ring.has("limb") else Config.Tools.Chainsaw.CutTime
			rings.append([snappedf(ring["progress"] / time, 0.01), ring["done"], ring.get("bound", false)])
		var pieces: Array = []
		for piece: Dictionary in held["pieces"]:
			var holders: Array = []
			for player: Variant in piece["holders"]:
				if is_instance_valid(player):
					holders.append([Net.peer_of(player), piece["holders"][player]["side"]])
			pieces.append([piece["free"], piece["log"].global_transform if CallKit.there(piece["log"]) else Transform3D.IDENTITY, holders])
		var line: Dictionary = held.get("line", {})
		list.append({"serial": held["serial"], "live": is_same(held, scene), "trees": trees, "rings": rings, "pieces": pieces, "line_live": line.get("live", false), 
			"line_left": snappedf(float(line["isolate_at"]) - Game.now(), 1.0) if float(line.get("isolate_at", -1.0)) >= 0.0 else -1.0})
	return list


func _candidate(tree_kind: String, index: int) -> Dictionary:
	for candidate: Dictionary in _candidates.get(tree_kind, []):
		if candidate["index"] == index:
			return candidate
	return {}



func _net_build(state: Dictionary) -> Dictionary:
	var trees: Array = []
	for told: Dictionary in state["trees"]:
		var candidate: = _candidate(told["kind"], told["index"])
		var standing: = CallKit.tree_model(told["index"])
		var options: Dictionary = told["options"].duplicate()
		options["sure"] = true
		var tree: Dictionary = _build(candidate, standing, options) if not candidate.is_empty() and standing != 0 else {}
		if tree.is_empty():
			tree = {"model": null, "candidate": candidate, "standing": standing, "pieces": [], "rings": [], "limbs_left": 0, "options": options, "back": false}
		elif told["gone"]:
			tree["model"].queue_free()
		trees.append(tree)
	var held: = _gather(state["serial"], trees)

	if not trees.is_empty() and trees[0].has("line"):
		held["line"] = {"live": true, "isolate_at": -1.0, "told": {}, "prompts": []}
		_line_boards(held)
	return held




func _net_apply(list: Variant, leaving: = false) -> void :
	if not (Net.is_client() or leaving) or not list is Array or (leaving and _mirrors.is_empty()):
		return
	var told: = {}
	scene = {}
	for state: Dictionary in list:
		var serial: int = state["serial"]
		told[serial] = true
		var held: Dictionary = _mirrors.get(serial, {})
		var fresh: = held.is_empty()
		if fresh:
			held = _net_build(state)
			_mirrors[serial] = held
		var rings: Array = state["rings"]
		for index in mini(rings.size(), held["rings"].size()):
			var ring: Dictionary = held["rings"][index]
			if rings[index][1] and not ring["done"]:
				ring["done"] = true
				if is_instance_valid(ring["part"]):
					ring["part"].queue_free()
				if ring.has("limb"):
					_drop_limb(ring)
			elif not ring["done"]:
				CallKit.set_bar(ring["bar"], rings[index][0])
				if rings[index].size() > 2 and rings[index][2] and ring.has("tension"):
					_show_tension(ring)

		if held.has("line") and held["line"]["live"]:
			_show_line(held, state.get("line_live", false), float(state.get("line_left", -1.0)))
		if held.has("line") and held["line"]["live"] and not state.get("line_live", false):
			held["line"]["live"] = false
			for tree: Dictionary in held["trees"]:
				if tree.get("sparks") != null and is_instance_valid(tree["sparks"]):
					tree["sparks"].emitting = false
		var pieces: Array = state["pieces"]
		for index in mini(pieces.size(), held["pieces"].size()):
			var piece: Dictionary = held["pieces"][index]
			var row: Array = pieces[index]
			if not is_instance_valid(piece["log"]):
				continue
			if row[0] and not piece["free"]:
				_free(piece)
			if row[0]:
				if fresh:
					piece["log"].global_transform = row[1]
				piece["net_to"] = row[1]

			var holding: = {}
			for pair: Array in row[2]:
				var player: = Net.player_of(pair[0])
				if player == null:
					continue
				holding[player] = true
				if not piece["holders"].has(player):
					piece["holders"][player] = {"side": pair[1], "strap": _strap()}
			for player: Variant in piece["holders"].keys():
				if not holding.has(player):
					if is_instance_valid(piece["holders"][player]["strap"]):
						piece["holders"][player]["strap"].queue_free()
					piece["holders"].erase(player)
			_refresh(piece)
			if not state["live"]:
				for prompt: Prompt in piece["prompts"]:
					prompt.enabled = false
		for index in mini(state["trees"].size(), held["trees"].size()):
			var tree: Dictionary = held["trees"][index]
			var how: Dictionary = state["trees"][index]
			if how["fading"] and is_instance_valid(tree["model"]):
				CallKit.fade(tree["model"], FADE)
			if how["back"] and not tree["back"]:
				tree["back"] = true
				CallKit.set_standing(tree["standing"], true)
		if state["live"]:
			scene = held
	for serial: int in _mirrors.keys():
		if not told.has(serial):
			var gone: Dictionary = _mirrors[serial]
			_mirrors.erase(serial)
			for piece: Dictionary in gone["pieces"]:
				for player: Variant in piece["holders"]:
					if is_instance_valid(piece["holders"][player]["strap"]):
						piece["holders"][player]["strap"].queue_free()
			for tree: Dictionary in gone["trees"]:
				if is_instance_valid(tree["model"]):
					tree["model"].queue_free()
				if tree["standing"] != 0:
					CallKit.set_standing(tree["standing"], true)



func start(layout: Dictionary, avoid: Vector3) -> void :
	_find_candidates(layout, avoid)
	Net.share("call.tree", _net_state, _net_apply, 10.0)
	Net.stopped.connect( func() -> void : _net_apply([], true))
	if ToolService.current:
		ToolService.current.saw = saw
