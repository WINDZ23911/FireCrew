class_name HudSettingsLive
extends Node








static var current: HudSettingsLive

var _latched: Dictionary = {}


func _ready() -> void :
	current = self
	process_mode = Node.PROCESS_MODE_ALWAYS
	Controls.bindings_changed.connect( func() -> void : Ui.say_action_keys(get_tree()))
	Text.language_changed.connect( func(_code: String) -> void : Ui.say_action_keys(get_tree()))


func _process(_delta: float) -> void :
	var player: = Game.local_player
	if player == null or not is_instance_valid(player):
		_let_go_all()
		return
	if player.camera and not is_equal_approx(player.camera.base_fov, Settings.fov):
		player.camera.base_fov = Settings.fov
	for action: String in Player.PROMPT_KEYS:
		var held: = player.prompt_held.has(action)
		if Settings.tap_holds and held and not _latched.has(action):
			_latch(action)
		elif _latched.has(action) and ( not held or not Settings.tap_holds):
			_let_go(action)
	if _latched.has("fire") and (player.holding != "nozzle" or not Settings.spray_toggle):
		_let_go("fire")


func _input(event: InputEvent) -> void :
	if event is InputEventKey and event.pressed and not event.echo:
		for action: String in Player.PROMPT_KEYS:
			if _latched.has(action) and _was_on(action, event):
				_let_go(action)
	elif event is InputEventMouseButton and event.pressed and event.button_index == Controls.BUTTONS["fire"]:
		if _latched.has("fire"):
			_let_go("fire")
			return
		var player: = Game.local_player
		if not Settings.spray_toggle or player == null or player.holding != "nozzle" or Game.ui_open:
			return
		if player.camera == null or not player.camera.captured:
			return
		_latch.call_deferred("fire")



func _was_on(action: String, event: InputEventKey) -> bool:
	for kept: InputEvent in _latched[action]:
		if kept is InputEventKey and (kept as InputEventKey).physical_keycode == event.physical_keycode:
			return true
	return false


func latched(action: String) -> bool:
	return _latched.has(action)


func _latch(action: String) -> void :
	if _latched.has(action):
		return

	if action == "fire" and Settings.click_use and Controls._click_to != "fire":
		return
	_latched[action] = InputMap.action_get_events(action)
	InputMap.action_erase_events(action)
	Input.action_press(action)


func _let_go(action: String) -> void :
	if not _latched.has(action):
		return
	var events: Array = _latched[action]
	_latched.erase(action)
	for event: InputEvent in events:
		InputMap.action_add_event(action, event)
	Input.action_release(action)


func _let_go_all() -> void :
	for action: String in _latched.keys():
		_let_go(action)
