extends SceneTree






const SOURCE: = "../tools/character/out/clips.json"
const TARGET: = "res://assets/animations/body.res"


func _init() -> void :
	var path: = ProjectSettings.globalize_path("res://").path_join(SOURCE)
	var clips: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	var library: = AnimationLibrary.new()
	for clip_name: String in clips:
		var clip: Dictionary = clips[clip_name]
		var fps: float = clip["fps"]
		var hips: Array = clip["hips"]
		var animation: = Animation.new()
		animation.length = maxf((hips.size() - 1) / fps, 1.0 / fps)
		animation.loop_mode = Animation.LOOP_LINEAR if clip["loop"] else Animation.LOOP_NONE
		var rotations: Dictionary = clip["rotations"]
		for bone: String in rotations:
			var track: = animation.add_track(Animation.TYPE_ROTATION_3D)
			animation.track_set_path(track, NodePath("Skeleton3D:" + bone))
			var keys: Array = rotations[bone]
			for i in keys.size():
				var q: Array = keys[i]
				animation.rotation_track_insert_key(track, i / fps, Quaternion(q[0], q[1], q[2], q[3]).normalized())
		var track: = animation.add_track(Animation.TYPE_POSITION_3D)
		animation.track_set_path(track, NodePath("Skeleton3D:Hips"))
		for i in hips.size():
			var p: Array = hips[i]
			animation.position_track_insert_key(track, i / fps, Vector3(p[0], p[1], p[2]))
		animation.optimize()
		library.add_animation(clip_name, animation)
	var error: = ResourceSaver.save(library, TARGET, ResourceSaver.FLAG_COMPRESS)
	print("saved %d clips to %s: %s" % [clips.size(), TARGET, error_string(error)])
	quit()
