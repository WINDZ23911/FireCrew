class_name CallAddress
extends Node






const LOOK_EVERY: = 0.5
const REACH: = 25.0
const NUMBER_REACH: = 45.0
const CALL_REACH: = 30.0
const PLATE_REACH: = 14.0
const GLOW: = 0.6
const OUTDOORS: = ["tree", "crash", "hazmat", "accident"]

static var current: CallAddress
static var _doors: Array[Vector3] = []

var _numbers: Array[int] = []
var focus: = Vector4.ZERO
var _lit: = -1
var _since: = 0.0


func _init() -> void :
	current = self


func _exit_tree() -> void :
	if current == self:
		current = null
	RenderingServer.global_shader_parameter_set("call_focus", Vector4.ZERO)


func _ready() -> void :
	var store: = Game.store
	for row in store.rows_named("HouseNumber"):
		_numbers.append(store.id_at(row))


func _process(delta: float) -> void :
	_since += delta
	if _since < LOOK_EVERY:
		return
	_since = 0.0
	var at: Variant = Game.incident.get("pos") if not Game.incident.is_empty() else null
	if not at is Vector3 or str(Game.incident.get("kind", "fire")) in OUTDOORS:
		_show(Vector3.INF)
		return
	var door: = door_near(at)
	_show(door, at)



static func door_near(at: Vector3) -> Vector3:
	if _doors.is_empty():
		for row in Game.store.rows_named("Door"):
			_doors.append(Game.store.position(row))
	var best: = at
	var nearest: = NUMBER_REACH
	for spot: Vector3 in _doors:
		var away: = Vector2(spot.x - at.x, spot.z - at.z).length()
		if away < nearest:
			nearest = away
			best = spot
	return best


func _show(door: Vector3, call: = Vector3.INF) -> void :
	var thin: = door != Vector3.INF and Settings.quality >= Graphics.MEDIUM
	focus = Vector4(door.x, door.y, door.z, REACH) if thin else Vector4.ZERO
	RenderingServer.global_shader_parameter_set("call_focus", focus)
	var wanted: = -1
	if door != Vector3.INF and Game.world != null:
		var nearest: = PLATE_REACH
		for id in _numbers:
			var row: int = Game.store.row_of.get(id, -1)
			if row < 0:
				continue
			var spot: = Game.store.position(row)

			var away: = minf(Vector2(spot.x - door.x, spot.z - door.z).length(), Vector2(spot.x - call.x, spot.z - call.z).length() * PLATE_REACH / CALL_REACH)
			if away < nearest:
				nearest = away
				wanted = id
	if wanted == _lit:
		return
	if _lit >= 0 and Game.world != null:
		var row: int = Game.store.row_of.get(_lit, -1)
		if row >= 0:
			Game.world.set_color(_lit, Game.store.color(row))
	_lit = wanted
	if _lit >= 0:
		var row: int = Game.store.row_of[_lit]
		Game.world.set_glow(_lit, Game.store.color(row), GLOW)
