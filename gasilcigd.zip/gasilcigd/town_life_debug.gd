class_name TownLifeDebug
extends Node3D


















var _stats: = false
var _follow: = false
var _person: = false
var _which: = 0
var _mate: = 0
var _since: = 0.0
var _camera: Camera3D
var _ghost: Ghost
var _sync: = false
var _sync_at: = -1
var _shots: Array = []



class Ghost:
	extends Node3D
	var siren: = 1
	var linear_velocity: = Vector3(0, 0, -30)


func _ready() -> void :
	var args: = OS.get_cmdline_user_args()
	_stats = args.has("--life-stats")
	for arg in args:
		if arg.begins_with("--life-follow"):
			_follow = true
			_which = -1 if arg.ends_with("=bus") else int(arg.get_slice("=", 1))
		elif arg.begins_with("--life-person"):
			_person = true
			_which = int(arg.get_slice("=", 1))
		elif arg.begins_with("--life-mate="):
			_person = true
			_mate = int(arg.get_slice("=", 1))
		elif arg.begins_with("--life-closure="):
			var n: = arg.get_slice("=", 1).split_floats(",")
			NavGraph.current.closure = {"x": n[0], "z": n[1], "radius": n[2]}
			if Pedestrians.current:
				Pedestrians.current.set_hazard({"x": n[0], "z": n[1], "radius": n[2] * 0.5})
		elif arg.begins_with("--life-cone="):
			var n: = arg.get_slice("=", 1).split_floats(",")
			var cordon: = NavGraph.current.cordon
			if cordon.is_empty():
				cordon = {"version": 0, "cones": [], "tapes": []}
				NavGraph.current.cordon = cordon
			cordon["cones"].append({"x": n[0], "z": n[1]})
			cordon["version"] += 1
		elif arg.begins_with("--life-shot="):
			_shots.append([float(arg.get_slice("=", 1).get_slice(",", 0)), arg.get_slice(",", 1)])
		elif arg.begins_with("--life-figures="):
			var n: = arg.get_slice("=", 1).split_floats(",")
			_figures(Vector3(n[0], 0.3, n[1]))
	if args.has("--life-graph"):
		_draw_graph()
	if args.has("--life-night"):
		Game.set_night(true)
	if args.has("--life-ghost"):
		_ghost = Ghost.new()
		add_child(_ghost)
		_ghost.global_position = Vector3(0, 2, 5000)
		Emergency.watch(_ghost, true)
	if args.has("--life-siren"):
		get_tree().create_timer(1.0).timeout.connect( func() -> void : Vehicle.named("Fire Truck").siren = 1)
	if _follow or _person:
		_camera = Camera3D.new()
		_camera.far = 4000.0
		_camera.fov = 70.0
		add_child(_camera)
		_camera.make_current()
	_sync = args.has("--life-sync")
	set_process(_stats or _follow or _person or _ghost != null or _sync or not _shots.is_empty())


func _print_sync(at: int) -> void :
	var line: = "sync %d s:" % at
	if Pedestrians.current:
		var ids: Array = Pedestrians.current.people.keys()
		ids.sort()
		line += " %d people" % ids.size()
		for id: int in ids.slice(0, 6):
			var person: Pedestrians.Person = Pedestrians.current.people[id]
			var where: = Pedestrians.current.where(person)
			line += " #%d %s %.0f,%.0f" % [id, person.shown_state, where.x, where.z]
	if Traffic.current:
		var cars: Array = Traffic.current.vehicles.duplicate()
		cars.sort_custom( func(a: Traffic.Car, b: Traffic.Car) -> bool: return a.id < b.id)
		var boxes: = 0
		for car: Traffic.Car in cars:
			boxes += 1 if car.body != null and car.body.is_inside_tree() else 0
		line += " | %d vehicles, %d solid" % [cars.size(), boxes]
		for car: Traffic.Car in cars.slice(0, 6):
			line += " #%d %s%d %.0f,%.0f%s" % [car.id, "bus" if car.bus else "car", car.shape, car.x, car.z, " hazards" if car.standing else ""]
	print(line + " | lights %s %s | night %s" % [TrafficLights.phase(1), TrafficLights.phase(2), Game.night])


func _process(delta: float) -> void :
	if _sync and (Net.is_host() or HostClock.synced) and floori(HostClock.now() / 5.0) != _sync_at:
		_sync_at = floori(HostClock.now() / 5.0)
		_print_sync(_sync_at * 5)
	if not _shots.is_empty() and (Net.is_host() or HostClock.synced) and HostClock.now() >= _shots[0][0]:
		var shot: Array = _shots.pop_front()
		get_viewport().get_texture().get_image().save_png(shot[1])
		print("life shot at %.2f s: %s" % [HostClock.now(), shot[1]])
	if _ghost and Traffic.current and not Traffic.current.vehicles.is_empty() and Game.now() > 6.0:
		var chased: = Traffic.current.vehicles[maxi(_which, 0) % Traffic.current.vehicles.size()]
		var way: = Vector3(chased.dx, 0, chased.dz)
		_ghost.global_position = chased.place.origin - way * 60.0
		_ghost.linear_velocity = way * 20.0
	if _person and Pedestrians.current and not Pedestrians.current.people.is_empty():
		var people: = Pedestrians.current.people.values()
		if _mate > 0:
			people = people.filter( func(one: Pedestrians.Person) -> bool: return Townsfolk.mate_of(one.seed) == _mate)
		if not people.is_empty():
			var person: Pedestrians.Person = people[_which % people.size()]
			var at: = Pedestrians.current.where(person)
			var ahead: = (person.shown_to - person.shown_from) * Vector3(1, 0, 1)
			if _mate > 0 and ahead.length() > 0.5:

				ahead = ahead.normalized()
				var left: = Vector3(ahead.z, 0, - ahead.x)
				_camera.look_at_from_position(at + ahead * 11.0 + left * 7.0 + Vector3(0, 4.5, 0), at + left * 1.5 + Vector3(0, 2.5, 0))
			elif _mate == 0 or ahead.length() > 0.5:
				_camera.look_at_from_position(at + Vector3(4, 5.5, 8), at + Vector3(0, 3, 0))
	if _follow and Traffic.current and not Traffic.current.vehicles.is_empty():
		var car: = Traffic.current.vehicles[maxi(_which, 0) % Traffic.current.vehicles.size()]
		if _which < 0:
			for each in Traffic.current.vehicles:
				if each.bus:
					car = each
		var at: = car.place.origin
		var back: = Vector3(car.dx, 0, car.dz)
		var aside: = Vector3( - car.dz, 0, car.dx)

		var behind: = maxf(26.0, car.half + 22.0)
		_camera.look_at_from_position(at - back * behind + aside * 9.0 + Vector3(0, behind * 0.42, 0), at + back * 6.0)
	if not _stats:
		return
	_since += delta
	if _since < 5.0:
		return
	_since = 0.0
	if _ghost and Traffic.current and not Traffic.current.vehicles.is_empty():
		var chased: = Traffic.current.vehicles[maxi(_which, 0) % Traffic.current.vehicles.size()]
		var lane: Dictionary = Traffic.current.segments[chased.route[chased.index]]
		print("chased: %s, v %.1f, pulled over %.1f of %.1f, alarmed %s, hazards %s, held back by '%s'" % [
			lane["kind"], chased.v, chased.side, lane.get("pull_over", 0.0), chased.alarmed, chased.standing, chased.waiting_for])
	if Traffic.current and not (Traffic.current._closed.is_empty() and Traffic.current._barriers.is_empty()):
		var inside: = 0
		for car in Traffic.current.vehicles:
			inside += 1 if Traffic.current._closed.has(car.route[car.index]) else 0
		print("closed to traffic: %d lanes and turns, %d with a cone or tape; %d vehicles on them" % [Traffic.current._closed.size(), Traffic.current._barriers.size(), inside])
	var people: = {}
	if Pedestrians.current:
		for person: Pedestrians.Person in Pedestrians.current.people.values():
			people[person.state] = people.get(person.state, 0) + 1
	var waits: = {}
	var slowest: = 0.0
	var moving: = 0
	var alarmed: = 0
	if Traffic.current:
		for car in Traffic.current.vehicles:
			var why: = car.waiting_for if car.v < 1.0 else "going"
			waits[why] = waits.get(why, 0) + 1
			slowest = maxf(slowest, car.still)
			moving += 1 if car.v > 1.0 else 0
			alarmed += 1 if car.alarmed else 0
	print("life %5.1f s: %d fps | people %s drawn %d | vehicles %s, %d hear a siren, longest still %.0f s | lights %s %s" % [
		Game.now(), Engine.get_frames_per_second(), people, Townsfolk.current.drawn if Townsfolk.current else 0, waits, alarmed, slowest, 
		TrafficLights.phase(1), TrafficLights.phase(2), 
	])


func _figures(at: Vector3) -> void :
	var poses: Array = Figure.POSES.keys()
	for index in poses.size():
		var look: = {} if index % 2 == 0 else {"top": Color8(214, 60, 40), "legs": Color8(40, 44, 60), "bands": Color8(230, 230, 200), "cap": Color8(214, 60, 40)}
		var figure: = Figure.build(index * 37 + 5, look)
		add_child(figure)
		var ground: = at + Vector3(index * 5.0, 0, 0)
		if poses[index] == "lying" or poses[index] == "stretcher":
			figure.global_transform = Figure.lying(ground, Vector3(0, 0, 1))
		else:
			figure.global_transform = Figure.standing(ground, Vector3(0, 0, 1))
		figure.pose(poses[index])
	var camera: = Camera3D.new()
	add_child(camera)
	var middle: = at + Vector3((poses.size() - 1) * 2.5, 3, 0)
	camera.look_at_from_position(middle + Vector3(0, 4, 20), middle)
	camera.make_current()


func _draw_graph() -> void :
	var graph: = NavGraph.current
	if graph == null:
		return
	var mesh: = ImmediateMesh.new()
	var material: = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	mesh.surface_begin(Mesh.PRIMITIVE_LINES, material)
	for segment: Dictionary in graph.segments:
		var color: = Color(0.2, 0.6, 1.0) if segment["kind"] == "lane" else Color(1.0, 0.9, 0.2)
		var points: PackedVector2Array = segment["points"]
		for i in points.size() - 1:
			mesh.surface_set_color(color)
			mesh.surface_add_vertex(Vector3(points[i].x, 0.7, points[i].y))
			mesh.surface_set_color(color)
			mesh.surface_add_vertex(Vector3(points[i + 1].x, 0.7, points[i + 1].y))
	for a in graph.walk.size():
		var node: Dictionary = graph.walk[a]
		for link: Dictionary in node["links"]:
			if a < link["to"]:
				var other: Dictionary = graph.walk[link["to"]]
				var color: = Color(1.0, 0.2, 0.2) if link["kind"] == "crossing" else Color(0.2, 1.0, 0.3)
				mesh.surface_set_color(color)
				mesh.surface_add_vertex(Vector3(node["x"], 0.9, node["z"]))
				mesh.surface_set_color(color)
				mesh.surface_add_vertex(Vector3(other["x"], 0.9, other["z"]))
	mesh.surface_end()
	var instance: = MeshInstance3D.new()
	instance.mesh = mesh
	add_child(instance)
