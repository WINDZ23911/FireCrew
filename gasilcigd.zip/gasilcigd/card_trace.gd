class_name CardTrace
extends Node




var _said: = ""


func _process(_delta: float) -> void :
	var incident: = Game.incident
	var line: = ""
	if not incident.is_empty():
		line = "card: %s %s | next: %s" % [incident.get("kind", ""), Text.say(incident.get("progress_text", "")), Text.say(incident.get("next", "-"), "en")]
	if line != _said:
		_said = line
		if not line.is_empty():
			print(line)
