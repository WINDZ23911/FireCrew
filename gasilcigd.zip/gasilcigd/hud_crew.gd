class_name HudCrew
extends Control















const WIDTH: = 270.0
const ROW: = 46.0
const HEADER: = 30.0

var _plate: Control
var _heading: Label
var _mode: Label
var _rows: Array = []
var _next: = 0.0


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_plate = Ui.plate(Vector2(WIDTH, HEADER))
	_plate.position = Vector2( - WIDTH - Ui.MARGIN, Ui.MARGIN)
	add_child(_plate)
	Ui.stripe(_plate, 60)
	_heading = Ui.caps("", int(Config.Hud.CapsFloor))
	_heading.position = Vector2(10, 7)
	_plate.add_child(_heading)
	_mode = Ui.caps("", int(Config.Hud.CapsFloor))
	_mode.position = Vector2(WIDTH - 160, 7)
	_mode.size = Vector2(150, 18)
	_mode.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_mode.clip_text = true
	_plate.add_child(_mode)
	var caps: = int(Config.Hud.CapsFloor)
	for place in int(Config.Lobby.MaxCrew) + int(Config.Crew.Most):
		var row: = Control.new()
		row.position = Vector2(8, HEADER + place * ROW)
		row.size = Vector2(WIDTH - 16, ROW)
		row.visible = false
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_plate.add_child(row)
		var swatch: = ColorRect.new()
		swatch.position = Vector2(0, 5)
		swatch.size = Vector2(4, ROW - 10)
		row.add_child(swatch)
		var key: = Ui.caps("", caps)
		key.position = Vector2(9, 3)
		key.modulate = Ui.DIM
		row.add_child(key)
		var member: = Ui.label("", int(Config.Hud.TextFloor))
		member.position = Vector2(24, 1)
		member.size = Vector2(row.size.x - 24, 21)
		member.clip_text = true
		member.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		row.add_child(member)
		var doing: = Ui.caps("", caps)
		doing.position = Vector2(24, 22)
		doing.size = Vector2(row.size.x - 76, 19)
		doing.clip_text = true
		doing.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		row.add_child(doing)
		var bar: = Ui.bar(Vector2(44, 6), Ui.BLUE)
		bar.position = Vector2(row.size.x - 46, 29)
		row.add_child(bar)

		var air: = Ui.caps("", caps - 2)
		air.position = Vector2(row.size.x - 70, 4)
		air.size = Vector2(70, 18)
		air.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(air)
		_rows.append({"row": row, "swatch": swatch, "key": key, "name": member, "doing": doing, "bar": bar, "air": air})
	Text.language_changed.connect( func(_code: String) -> void : _next = 0.0)



func _humans() -> Array[Player]:
	var found: Array[Player] = []
	if not Net.active():
		return found
	var peers: Array = Net.players.keys()
	peers.sort()
	for peer: int in peers:
		var player: Variant = Net.players[peer]
		if player != null and is_instance_valid(player) and player.brain == null:
			found.append(player)
	return found


func _process(_delta: float) -> void :
	var service: = CrewService.current
	var members: Array[Crewman] = service.members if service != null else [] as Array[Crewman]
	var humans: = _humans()
	visible = not members.is_empty() or not humans.is_empty()
	if not visible:
		return
	_heading.text = Text.say(Text.m("talk.panel.title")).to_upper()
	if not members.is_empty():

		_mode.text = Text.say(Text.join([CrewService.level_name(service.autonomy), " · ", Controls.key_name("crew_autonomy")]) if service.auto else Text.m("crew.panel.manual"))
	else:
		_mode.text = Text.say(Text.f("talk.panel.count", [humans.size(), Net.MAX_CREW]))
	var place: = 0
	for player in humans:
		if place < _rows.size():
			_show_player(_rows[place], player)
			place += 1
	var calling: = not Game.incident.is_empty()
	for index in members.size():
		var mind: Crewman = members[index]
		if place < _rows.size() and is_instance_valid(mind):
			_show_member(_rows[place], mind, index, service, calling)
			place += 1
	for rest in range(place, _rows.size()):
		_rows[rest]["row"].visible = false
	_plate.size = Vector2(WIDTH, HEADER + place * ROW + 4)


func _show_player(entry: Dictionary, player: Player) -> void :
	entry["row"].visible = true
	entry["row"].modulate.a = 1.0
	entry["air"].text = ""
	entry["key"].remove_theme_color_override("font_color")
	entry["swatch"].color = NetTalk.colour_of(player)
	entry["key"].text = ""
	var mine: = player == Game.local_player
	entry["name"].text = player.display_name + ("  (%s)" % Text.say(Text.m("talk.panel.you")) if mine else "")
	entry["name"].add_theme_color_override("font_color", Ui.YELLOW if mine else Ui.TEXT)
	var status: = NetTalk.status_of(player)
	entry["doing"].text = Text.say(status[0])
	entry["doing"].modulate = Color.WHITE
	entry["doing"].add_theme_color_override("font_color", (status[1] as Color).lightened(0.1))
	_show_bar(entry["bar"], player, float(player.get_attr("AirBar", -1.0)) if player.get_attr("Scba", false) == true else -1.0)


func _show_member(entry: Dictionary, mind: Crewman, index: int, service: CrewService, calling: bool) -> void :
	entry["row"].visible = true
	entry["swatch"].color = mind.member.get("colour", Ui.YELLOW)
	entry["key"].text = str(index + 1)
	entry["key"].add_theme_color_override("font_color", CrewRoster.role_colour(mind.role))
	entry["name"].add_theme_color_override("font_color", Ui.TEXT)
	var stars: = "★".repeat(int(mind.member.get("level", 0)))
	entry["name"].text = "%s  %s  %s" % [mind.display_name(), Text.say(CrewRoster.position_name(mind.role)), stars]
	var doing: Variant
	if mind.body.health <= 0.0:
		doing = Text.m("crew.panel.down")
	elif Game.now() - mind.last_line_at < 4.0 and mind.last_line != null:
		doing = Text.join(["“", mind.last_line, "”"])
	elif mind.job != null:
		doing = mind.job.title()
	elif not mind.queue.is_empty():
		doing = mind.queue[0].title()
	elif mind.body.seat != null:
		doing = Text.m("crew.jobs.ride")
	elif HoseService.current and HoseService.current.line_of(mind.body) != null:
		doing = Text.m("crew.jobs.attack")
	elif calling and mind.mode == "auto" and mind.auto_note != null:
		doing = mind.auto_note
	else:
		doing = Text.m("crew.jobs." + ("hold" if mind.mode == "hold" else ("idle" if calling else "follow")))

	if mind.autonomy >= 0 and mind.autonomy != service.autonomy:
		doing = Text.join([CrewService.level_name(mind.autonomy), " · ", doing])

	if mind.job != null and not mind.queue.is_empty():
		doing = Text.join([doing, "  ▸ ", Text.f("crew.jobs.then", [mind.queue[0].title()])])
	var room: Variant = _room_of(mind.body)
	if room != null and not mind.job is JobSearch:
		doing = Text.join([doing, " · ", room])
	entry["doing"].text = Text.say(doing)
	entry["doing"].add_theme_color_override("font_color", Ui.DIM)

	var idle: = calling and mind.job == null and mind.queue.is_empty() and mind.body.seat == null and not (mind.mode == "auto" and mind.auto_note != null)
	entry["row"].modulate.a = (0.55 + 0.45 * absf(sin(Game.now() * 4.0))) if idle else 1.0
	entry["doing"].modulate = Ui.AMBER if idle else Ui.DIM
	_show_bar(entry["bar"], mind.body, AirService.current.pressure(mind.body) if AirService.current else -1.0)
	var minutes: = AirService.minutes_left(mind.body)
	entry["air"].text = Text.say(Text.f("crew.panel.air", [maxi(0, floori(minutes))])) if minutes >= 0.0 else ""
	entry["air"].modulate = Ui.state(Ui.RED) if minutes >= 0.0 and minutes < 3.0 else Ui.DIM



func _room_of(body: Player) -> Variant:
	var house: = CrewSearch.house()
	if house == null:
		return null
	var room: Variant = house.room_at(body.root_position())
	return CrewSearch.room_words(room["name"]) if room != null else null



func _show_bar(bar: Control, body: Player, pressure: float) -> void :
	var share: = 1.0
	var tint: = Ui.BLUE
	if pressure >= 0.0:
		share = pressure / float(Config.Air.Capacity)
	if body.health < body.max_health:
		share = minf(share, body.health / body.max_health)
		tint = Ui.state(Ui.RED if body.health < 40.0 else Ui.AMBER)
	bar.visible = share < 0.999
	Ui.set_bar(bar, share, tint)
