class_name JobBackup
extends CrewJob





var partner: Player


func _init(with: Player = null) -> void :
	kind = "backup"
	role = "nozzle"
	partner = with


func place() -> Vector3:
	return partner.global_position if is_instance_valid(partner) else who.body.global_position


func title() -> Variant:
	if is_instance_valid(partner):
		return Text.f("crew.jobs.backupOf", [partner.display_name if partner != who.commander() else Text.m("crew.jobs.you")])
	return Text.m("crew.jobs.backup")


func suits(member: Crewman) -> bool:
	return is_instance_valid(partner) and member.body != partner and member.body.get_attr("Supply") == null



func _spot() -> Vector3:
	var back: = Vector3.ZERO
	var line: Variant = HoseService.current.line_of(partner) if HoseService.current else null
	if line != null and is_instance_valid(line["source"]):
		back = (line["source"] as Node3D).global_position - partner.global_position
	if back.length() < 1.0:
		back = - partner.facing()
	back.y = 0.0
	return partner.global_position + back.normalized() * float(Config.Crew.Pair.Behind)


func run() -> bool:
	if not is_instance_valid(partner):
		return fail("crew.say.nothingThere")
	var held: = who.token()
	CrewKit.free_hands(who)
	var mate: = who.service.mind_of(partner)
	var alone_since: = -1.0
	var set_tried: = false
	while on(held):
		if not is_instance_valid(partner) or partner.health <= 0.0:
			return true
		var fire: = FireService.current
		var smoky: = fire != null and fire.smoke_at(partner.root_position() + Vector3(0, 2, 0)) > 0.1
		if smoky and not set_tried:
			set_tried = true
			if not await CrewWater.wear_set(who):
				who.say("crew.say.noSet", [], "warning")
		if not CrewWater.breathe(who):
			return fail("crew.say.lowAir")
		if who.body.health < who.body.max_health * who.back_out_at():
			return fail("crew.say.hurt")

		if mate != null and not mate.job is JobAttack:
			if alone_since < 0.0:
				alone_since = Game.now()
			if Game.now() - alone_since > float(Config.Crew.Pair.TakeOver):
				if not CrewWater.targets().is_empty():
					who.report("crew.say.takeOver", [], "info")
					var attack: = JobAttack.new()
					attack.ordered = ordered
					who.give(attack)
				return true
		else:
			alone_since = -1.0
		var spot: = _spot()
		var gap: = Vector3(spot.x - who.body.global_position.x, 0, spot.z - who.body.global_position.z).length()
		if gap > 2.0:
			who._steer(spot, 1.2)
		else:
			who.wish = Vector3.ZERO
			who.look = partner.global_position + partner.facing() * 10.0
		who.crouch = partner._crouch_amount > 0.5 or (smoky and fire.smoke_at(who.body.head_position()) > float(Config.Crew.Search.CrouchSmoke))
		await who.tick()
	return false


func finish(_done: bool) -> void :
	who.crouch = false
	who.wish = Vector3.ZERO
