extends RefCounted



static func start(main: Node) -> void :
	var swifts: = Swifts.new()
	swifts.name = "Swifts"
	main.add_child(swifts)
