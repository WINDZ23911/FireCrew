extends Node





















var _shots: Array = []
var _says: Array = []
var _camera: Camera3D
var _building: Building
var _door: Dictionary = {}
var _hydrant: Dictionary = {}
var _together: = -1.0
var _end_at: = -1.0
var _lose_at: = -1.0


func _ready() -> void :
	var what: = ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--crew="):
			what = arg.substr(7)
		elif arg.begins_with("--crew-shot="):
			var bits: = arg.substr(12).split(",")
			_shots.append([float(bits[0]), bits[1], bits[2]])
		elif arg.begins_with("--crew-end="):
			_end_at = float(arg.substr(11))
		elif arg.begins_with("--crew-lose="):
			_lose_at = float(arg.substr(12))
		elif arg.begins_with("--crew-say="):
			_says.append(float(arg.substr(11)))
	_shots.sort_custom( func(a: Array, b: Array) -> bool: return a[0] < b[0])
	_says.sort()
	Net.share("crew.debug", func() -> Variant: return _together, func(at: Variant) -> void : _together = at, 2.0)
	Net.peer_joined.connect( func(player: Player) -> void :
		if Net.is_host() and _together < 0.0:
			_together = Game.now()
		if Net.is_host() and what in ["gear", "host_house", "host_hydrant", "give_divider"]:
			player.set_attr("Geared", true)
			print("crew [host]: %s joined, geared" % player.display_name)
		if Net.is_host() and what == "give_divider":
			await _wait(3.0)
			_hoses()._carry_divider(player)
			print("crew [host]: the divider is %s by %s" % [_hoses().divider["state"], player.display_name])
	)
	if CallService.current:
		CallService.current.hold = true
	if has_method("_play_" + what):
		call_deferred("_play_" + what)


func _side() -> String:
	return "host" if Net.is_host() else "client"


func _now() -> float:
	if _together < 0.0 or not (Net.is_host() or HostClock.synced):
		return -1.0
	return HostClock.now() - _together


func _wait(seconds: float) -> void :
	await get_tree().create_timer(seconds).timeout


func _wait_until(test: Callable, limit: = 20.0) -> bool:
	var waited: = 0.0
	while not test.call():
		await get_tree().create_timer(0.1).timeout
		waited += 0.1
		if waited > limit:
			return false
	return true


func _fires() -> FireService:
	return FireService.current


func _hoses() -> HoseService:
	return HoseService.current



func _burning() -> Building:
	var fires: = _fires()
	if Net.is_host():
		if not fires.incident.is_empty():
			_building = fires.incident["group"]["building"]
	elif fires._net_building >= 0:
		_building = fires.buildings[fires._net_building]
	return _building


func _truck() -> Vehicle:
	return Vehicle.named("Fire Truck")





func _view(view: String) -> void :
	if view == "me":
		if _camera != null:
			_camera.current = false
			Game.local_player.camera.camera.make_current()
		return
	var building: = _burning()
	var fire: = building.position if building != null else Vector3.ZERO
	var truck: = _truck().global_position
	var toward: = Vector3(truck.x - fire.x, 0, truck.z - fire.z).normalized()
	var across: = toward.cross(Vector3.UP)
	var from: = Vector3.ZERO
	var to: = Vector3.ZERO
	match view:
		"side":
			var middle: = (fire + truck) / 2.0
			from = Vector3(middle.x, 20, middle.z) + across * 48
			to = Vector3(middle.x, 3, middle.z)
		"fire":
			from = Vector3(fire.x, 13, fire.z) + toward * 36 + across * 12
			to = fire
		"far":
			from = Vector3(fire.x, 34, fire.z) + toward * 70 + across * 30
			to = fire
		"flames":

			var middle: = Vector3.ZERO
			for flame in Flame.all:
				middle += flame.global_position / Flame.all.size()
			if Flame.all.is_empty():
				middle = fire
			var out: = Vector3(middle.x - fire.x, 0, middle.z - fire.z).normalized()
			from = middle + out * 30 + Vector3(0, 9, 0) + out.cross(Vector3.UP) * 8
			to = middle + Vector3(0, 2, 0)
		"crew":
			var middle: = Vector3.ZERO
			for player in Game.players:
				middle += player.global_position / Game.players.size()
			from = middle + toward * 16 + across * 7 + Vector3(0, 7, 0)
			to = middle + Vector3(0, 2, 0) - toward * 6
		"door":
			var door: = _front_door()
			if door.is_empty():
				return
			var shut: Transform3D = door["shut"]
			var outward: = - shut.basis.z
			if outward.dot(shut.origin - building.position) < 0.0:
				outward = - outward
			from = shut.origin + outward * 15 + shut.basis.x * 5 + Vector3(0, 4, 0)
			to = shut.origin + Vector3(0, 0.5, 0) + shut.basis.x * 2
		"hydrant":
			var hydrant: = _near_hydrant()
			var at: Vector3 = hydrant["position"]
			var along: = Vector3(truck.x - at.x, 0, truck.z - at.z).normalized()
			from = (at + truck) / 2.0 + along.cross(Vector3.UP) * 30 + Vector3(0, 14, 0)
			to = (at + truck) / 2.0
		"divider":
			var place: Transform3D = _hoses().divider.get("place", Transform3D(Basis.IDENTITY, truck))
			from = place.origin + toward * 12 + across * 9 + Vector3(0, 8, 0)
			to = place.origin
	if _camera == null:
		_camera = Camera3D.new()
		_camera.far = 6000.0
		_camera.near = 0.5
		_camera.fov = 70.0
		add_child(_camera)
	_camera.look_at_from_position(from, to)
	_camera.make_current()


func _process(_delta: float) -> void :
	var now: = _now()
	if now < 0.0:
		return
	if not _shots.is_empty():
		var shot: Array = _shots[0]
		if now >= shot[0] - 1.2 and shot.size() == 3:
			_view(shot[1])
			shot.append(true)
		if now >= shot[0]:
			_shots.pop_front()
			get_viewport().get_texture().get_image().save_png(shot[2])
			print("crew [%s]: picture '%s' at %.2f s: %s" % [_side(), shot[1], now, shot[2]])
	if not _says.is_empty() and now >= _says[0]:
		_says.pop_front()
		_say(now)
	var fires: = _fires()
	if Net.is_host() and _end_at >= 0.0 and now >= _end_at and not fires.incident.is_empty():
		_end_at = -1.0
		_burning()
		fires.incident["fed"] = null
		for node: Dictionary in fires.incident["group"]["nodes"]:
			if node["burning"]:
				fires._extinguish(node, Game.players[Game.players.size() - 1])
		for ember: Dictionary in fires.incident.get("embers", []).duplicate():
			fires.spray(Game.local_player, PackedVector3Array([ember["position"] + Vector3(0, 1, 0), ember["position"]]), 10.0)
		print("crew [host]: every flame put out at %.1f s" % now)
	if Net.is_host() and _lose_at >= 0.0 and now >= _lose_at and not fires.incident.is_empty():
		_lose_at = -1.0
		_burning()
		for node: Dictionary in fires.incident["group"]["nodes"]:
			if not node["burning"] and node["fuel"] > 0.0 and node["burnt"] is Callable:
				fires._ignite(node, 1.0)
			node["fuel"] = 0.001
		print("crew [host]: everything alight and burning away at %.1f s" % now)



func _say(now: float) -> void :
	var fires: = _fires()
	var hoses: = _hoses()
	var flames: Array = []
	for flame in Flame.all:
		flames.append("%.0f,%.0f,%.0f i%.1f p%.1f" % [flame.global_position.x, flame.global_position.y, flame.global_position.z, flame.intensity, flame.progress])
	flames.sort()
	var held: Array = []
	for index in hoses.lines.size():
		var line: Dictionary = hoses.lines[index]
		if line["player"] != null:
			held.append("%d:%s%s" % [index, line["player"].display_name, " spraying" if hoses._shown_spraying(line, line["player"]) else ""])
		elif line["feeding"]:
			held.append("%d:feeds" % index)
	var supplies: Array = []
	for rig: Dictionary in hoses.rigs:
		supplies.append("%s/%s %.0f L" % [rig["supply"]["state"], str(hoses.supplied_by(rig["vehicle"])), rig["vehicle"].water])
	var hose_points: Array = []
	if Net.is_host():
		for index in hoses.lines.size():
			if is_instance_valid(hoses.lines[index]["hose"]):
				hose_points.append("L%d:%d" % [index, hoses.lines[index]["hose"].points.size()])
		for index in hoses.rigs.size():
			if is_instance_valid(hoses.rigs[index]["supply"]["hose"]):
				hose_points.append("S%d:%d" % [index, hoses.rigs[index]["supply"]["hose"].points.size()])
	else:
		for key: String in hoses._net_hoses:
			hose_points.append("%s:%d" % [key, hoses._net_hoses[key].points.size()])
	hose_points.sort()
	var cannons: Array = []
	for monitor: Dictionary in hoses.monitors:
		cannons.append("%s to %.0f,%.0f,%.0f" % ["water" if monitor["jet"].spraying else "shut", monitor["aim"].x, monitor["aim"].y, monitor["aim"].z])
	var house: = _burning()
	var of_house: = " | monitors %s" % [cannons]
	if house is House:
		var doors: Array = []
		for door_name: String in house.doors:
			var door: Dictionary = house.doors[door_name]
			if door["open"] or door["locked"] or door["burnt"]:
				doors.append("%s%s%s%s" % [door_name, " open" if door["open"] else "", " locked" if door["locked"] else "", " burnt" if door["burnt"] else ""])
		var broken: = 0
		var cracked: = 0
		for pane: Dictionary in house._pane_list:
			broken += 1 if pane["broken"] else 0
			cracked += 1 if pane["cracked"] else 0
		var smoke: Array = []
		for room_name: String in house.rooms:
			var room: Dictionary = house.rooms[room_name]
			if float(room.get("level", 0.0)) > 0.0 or room.get("dark", false):
				smoke.append("%s %.2f%s%s" % [room_name, room.get("level", 0.0), " dark" if room.get("dark", false) else "", " rolling" if room.get("rolling", false) else ""])
		var control: Variant = house._control.get("part")
		of_house += " | doors %s | panes %d broken %d cracked | rooms %s | control %s | charred %s" % [doors, broken, cracked, smoke, ("used" if house._control["used"] else "fitted") if is_instance_valid(control) else "none", house.charred]
	var shaded: = 0
	if house != null:
		for id: int in house._original:
			var row: int = Game.store.row_of.get(id, -1)
			if row >= 0 and not Game.store.color(row).is_equal_approx(house._original[id]):
				shaded += 1
	var crew: Array = []
	for player in Game.players:
		crew.append("%s cash %d holding '%s' flames out %d hose %s" % [player.display_name, int(player.get_attr("Cash", 0)), player.holding, int(player.get_attr("FlamesOut", 0)), str(player.get_attr("HoseLength"))])
	crew.sort()
	print("crew [%s] %.0f s: %d flames %s | embers %d | markers %d | lines %s | supply %s | hoses %s | divider %s | parts blackened %d%s | smoke here %.2f | %s" % [
		_side(), now, flames.size(), flames, Ember.all.size(), CallMarker.all.size(), held, supplies, hose_points, hoses.divider["state"], shaded, of_house, 
		fires.smoke_at(Game.local_player.head_position()), crew, 
	])





func _front_door() -> Dictionary:
	if _door.is_empty():
		var house: = _burning() as House
		if house != null and house.doors.has("FrontDoor"):
			_door = house.doors["FrontDoor"]
	return _door


func _outside(door: Dictionary, out: float, along: = 0.0) -> Vector3:
	var shut: Transform3D = door["shut"]
	var outward: = - shut.basis.z
	if outward.dot(shut.origin - _burning().position) < 0.0:
		outward = - outward
	var at: = shut.origin + outward * out + shut.basis.x * along
	return Vector3(at.x, shut.origin.y - float(door["info"]["height"]) / 2.0 + 3.0, at.z)


func _near_hydrant() -> Dictionary:
	if _hydrant.is_empty():
		var best: = INF
		for hydrant: Dictionary in _hoses().hydrants:
			var distance: float = hydrant["position"].distance_to(_truck().global_position)
			if distance < best:
				best = distance
				_hydrant = hydrant
	return _hydrant



func _walk(to: Vector3, hop: = 5.0) -> void :
	var me: = Game.local_player
	var from: = me.global_position
	var hops: = maxi(1, int(ceil(from.distance_to(to) / hop)))
	for index in range(1, hops + 1):
		me.teleport(from.lerp(to, float(index) / hops))
		await _wait(0.12)


func _look_at(point: Vector3) -> void :
	var me: = Game.local_player
	var toward: = point - me.head_position()
	me.camera.yaw = atan2( - toward.x, - toward.z)
	me.camera.pitch = asin(clampf(toward.normalized().y, -1, 1)) + 0.1


func _use(prompt: Prompt) -> void :
	Game.local_player._fire_prompt(prompt, "tap")





func _play_host_house() -> void :
	await _wait(0.5)
	var fires: = _fires()
	var house: House = null
	for building in fires.buildings:
		if building is House and building.name.begins_with("Family house") and (house == null or building.position.distance_to(Vector3(120, 0, 40)) < house.position.distance_to(Vector3(120, 0, 40))):
			house = building

	var gas: Array = []
	for scenario: Dictionary in house.scenarios:
		if scenario.get("origin") in FireService.GAS_ORIGINS:
			gas.append(scenario)
	if not gas.is_empty():
		house.scenarios = gas
		Config.Fire.Traits["Force"] = "gas"
	CallService.current.forced = "none"
	fires.run_incident(house)
	await _wait(0.3)
	var front: Dictionary = house.doors["FrontDoor"]
	front["locked"] = false
	house._place_door(front)
	_building = house
	print("crew [host]: fire at %s %s, trait '%s', %d flames" % [house.name, house.position, fires.incident.get("trait", ""), Flame.all.size()])
	var truck: = _truck()
	var at: = _outside(front, 48.0)
	truck.global_transform = Transform3D(Basis(Vector3.UP, atan2(at.x - house.position.x, at.z - house.position.z) + PI / 2), Vector3(at.x, 3.0, at.z))
	truck.linear_velocity = Vector3.ZERO
	await _wait(0.6)
	var me: = Game.local_player
	me.set_attr("Geared", true)
	me.teleport(_outside(front, 30.0, -8.0))
	await _wait(0.3)
	var hoses: = _hoses()
	hoses._connect_line(hoses.lines[0], me)
	await _walk(_outside(front, 16.0, -8.0))
	_look_at(front["shut"].origin + Vector3(0, 6, 0))
	await _wait_until( func() -> bool: return Net.players.size() > 1, 60.0)
	await _wait(6.0)

	var scenario_room: String = ""
	for node: Dictionary in fires.incident["group"]["nodes"]:
		if node["burning"] and node["room"] != null:
			scenario_room = node["room"]
	var panes: Array = house.rooms[scenario_room]["panes"] if house.rooms.has(scenario_room) else []
	for index in panes.size():
		if index == 0:
			panes[index]["shatter"].call(Vector3.ZERO)
		else:
			panes[index]["crack"].call()
	print("crew [host]: glass of %s: %d panes, the first broken" % [scenario_room, panes.size()])

	await _wait(3.0)
	hoses.disconnect_line(hoses.lines[0])
	me.teleport(_outside(front, 26.0, 6.0))
	await _wait(0.3)
	hoses._carry_divider(me)
	await _wait(1.5)
	_look_at(front["shut"].origin)
	me.rig.rotation.y = me.camera.yaw
	await _wait(0.3)
	hoses._place_divider(me)
	await _wait(0.5)
	me.teleport(_outside(front, 36.0, -4.0))
	await _wait(0.3)
	hoses._connect_line(hoses.lines[0], me)
	await _walk(hoses.divider["place"].origin + Vector3(0, 2, 0) + (me.global_position - hoses.divider["place"].origin).normalized() * 3.0)
	await _wait(0.3)
	hoses._feed_divider(me)
	print("crew [host]: divider %s, fed %s" % [hoses.divider["state"], hoses.divider["feed"] != null])


func _play_host_hydrant() -> void :
	await _wait(0.5)
	CallService.current.forced = "none"
	var hoses: = _hoses()
	var truck: = _truck()

	var best: = INF
	for hydrant: Dictionary in hoses.hydrants:
		var distance: float = hydrant["position"].distance_to(Vector3(120, 0, 40))
		if distance < best:
			best = distance
			_hydrant = hydrant
	var at: Vector3 = _hydrant["position"]
	var spot: = at
	for angle in 8:
		var direction: = Vector3(sin(angle * PI / 4), 0, cos(angle * PI / 4))
		var hit: = Game.world.raycast(at + Vector3(0, 4, 0), at + Vector3(0, 4, 0) + direction * 45, World.LAYER_SOLID)
		if hit.is_empty():
			spot = at + direction * 30
			break
	truck.global_transform = Transform3D(Basis.IDENTITY, Vector3(spot.x, 3.0, spot.z))
	truck.linear_velocity = Vector3.ZERO
	truck.water = 800.0
	Game.local_player.set_attr("Geared", true)
	Game.local_player.teleport(Vector3(spot.x, 2.0, spot.z) + Vector3(12, 0, 0))
	print("crew [host]: pumper at %s, hydrant at %s" % [spot, at])





func _play_client_fire() -> void :
	var hoses: = _hoses()
	var me: = Game.local_player
	await _wait_until( func() -> bool: return Net.players.size() > 1, 60.0)
	var host: Player = Net.players[1]
	var ready: = await _wait_until( func() -> bool: return not Flame.all.is_empty() and hoses.line_of(host) != null and me.get_attr("Geared", false), 40.0)
	print("crew [client]: the host has a line %s; flames here %d; geared %s" % [ready, Flame.all.size(), me.get_attr("Geared", false)])
	var line: Dictionary = hoses.lines[1]
	var coupling: Node3D = line["source"]
	var truck: = _truck()
	var out: = coupling.global_position - truck.global_position
	out = Vector3(out.x, 0, out.z).normalized()
	me.teleport(coupling.global_position + out * 4.0 + Vector3(0, 1, 0))
	await _wait(0.6)
	var cash: = int(me.get_attr("Cash", 0))
	_use(line["prompt"])
	var took: = await _wait_until( func() -> bool: return hoses.line_of(me) != null, 6.0)
	print("crew [client]: took the second outlet's line by its prompt: %s (holding '%s', nozzle %s)" % [took, me.holding, is_instance_valid(line.get("nozzle"))])

	var building: = _burning()
	var stand: = host.global_position + (host.global_position - building.position).cross(Vector3.UP).normalized() * 9.0
	await _walk(Vector3(stand.x, me.global_position.y, stand.z))
	await _wait(0.5)
	var target: Flame = null
	for flame in Flame.all:
		if target == null or flame.progress < target.progress:
			target = flame
	var count: = Flame.all.size()
	_look_at(target.global_position + Vector3(0, 1, 0))
	await _wait(0.3)
	Input.action_press("fire")
	print("crew [client]: spraying at %s from %s with %d flames burning" % [target.global_position, me.global_position, count])
	var aimed: = target.get_instance_id()
	var out_first: = await _wait_until( func() -> bool: return not is_instance_id_valid(aimed), 30.0)
	await _wait(0.5)
	print("crew [client]: that flame is out: %s; flames now %d; cash %d -> %d; FlamesOut %s; hose paid out %s" % [out_first, Flame.all.size(), cash, int(me.get_attr("Cash", 0)), str(me.get_attr("FlamesOut")), str(me.get_attr("HoseLength"))])

	while not Flame.all.is_empty():
		target = Flame.all[0]
		_look_at(target.global_position + Vector3(0, 1, 0))
		aimed = target.get_instance_id()
		await _wait_until( func() -> bool: return not is_instance_id_valid(aimed), 12.0)
		await _wait(0.3)
	Input.action_release("fire")


func _play_client_house() -> void :
	var hoses: = _hoses()
	var me: = Game.local_player
	await _wait_until( func() -> bool: return Net.players.size() > 1, 60.0)
	await _wait_until( func() -> bool: return _burning() is House and not _front_door().is_empty() and me.get_attr("Geared", false), 40.0)
	var house: = _burning() as House
	var front: = _front_door()

	var found: = await _wait_until( func() -> bool: return is_instance_valid(house._control.get("part")), 10.0)
	print("crew [client]: the valve is on the wall here: %s; its prompt is known as %s" % [found, house._control["part"].get_meta("prompt").net_id if found else "-"])
	if found:
		var part: Node3D = house._control["part"]
		me.teleport(Vector3(part.global_position.x, me.global_position.y, part.global_position.z) + (_outside(front, 4.0) - _outside(front, 0.0)))
		await _wait(1.0)
		var prompt: Prompt = part.get_meta("prompt")
		print("crew [client]: offered '%s' (hold %.1f, shown %s)" % [Text.say(prompt.action), prompt.hold, prompt.shown_to(me)])
		_use(prompt)
		var used: = await _wait_until( func() -> bool: return house._control.get("used", false), 5.0)
		print("crew [client]: valve shut: %s (its prompt enabled %s)" % [used, prompt.enabled])

	me.teleport(_outside(front, 5.0, 2.0))
	await _wait(0.8)
	_use(front["prompt"])
	var opened: = await _wait_until( func() -> bool: return front["open"], 5.0)
	print("crew [client]: front door open here: %s" % opened)

	for door_name: String in house.doors:
		var door: Dictionary = house.doors[door_name]
		if door["locked"]:
			me.teleport(_outside(door, 4.0, 2.0))
			await _wait(0.8)
			_use(door["prompt"])
			await _wait(0.8)
			print("crew [client]: %s is locked and stays shut: %s; offered '%s'" % [door_name, not door["open"], Text.say(door["prompt"].action)])
			break

	var fed: = await _wait_until( func() -> bool: return hoses.divider["state"] == "placed" and hoses.divider["feed"] != null, 40.0)
	print("crew [client]: the divider is %s here, fed %s, %d lines in all" % [hoses.divider["state"], fed, hoses.lines.size()])
	if fed:
		var branch: Dictionary = hoses.divider["lines"][1]
		var place: Transform3D = hoses.divider["place"]
		me.teleport(place.origin + Vector3(0, 2, 0) - place.basis.z * 4.0)
		await _wait(1.0)
		print("crew [client]: the divider's outlet prompt %s enabled %s shown %s" % [branch["prompt"].net_id, branch["prompt"].enabled, branch["prompt"].shown_to(me)])
		_use(branch["prompt"])
		var took: = await _wait_until( func() -> bool: return hoses.line_of(me) != null, 6.0)
		print("crew [client]: took a line from the divider: %s; water plate truck %s" % [took, str(me.get_attr("HoseTruck"))])
		await _walk(_outside(front, 9.0, 2.0))
		_look_at(front["shut"].origin + Vector3(0, 7, 0))
		await _wait(0.3)
		Input.action_press("fire")
		await _wait(6.0)
		Input.action_release("fire")


func _play_client_hydrant() -> void :
	var hoses: = _hoses()
	var me: = Game.local_player
	await _wait_until( func() -> bool: return Net.players.size() > 1, 60.0)
	await _wait_until( func() -> bool: return me.get_attr("Geared", false), 20.0)
	await _wait(2.0)
	var truck: = _truck()
	var rig: Dictionary = hoses.rigs[0]
	for other: Dictionary in hoses.rigs:
		if other["vehicle"] == truck:
			rig = other
	var intake: Node3D = truck.intake["node"]
	var out: = intake.global_position - truck.global_position
	out = Vector3(out.x, 0, out.z).normalized()
	me.teleport(intake.global_position + out * 4.0 + Vector3(0, 1, 0))
	await _wait(0.8)
	var water: = truck.water
	_use(rig["supply"]["prompt"])
	var carried: = await _wait_until( func() -> bool: return hoses.supply_of(me) != null, 6.0)
	print("crew [client]: carrying the supply hose: %s (holding '%s', tank %.0f L)" % [carried, me.holding, water])
	var hydrant: = _near_hydrant()
	var node: Node3D = hydrant["node"]
	await _walk(Vector3(node.global_position.x, me.global_position.y, node.global_position.z) + Vector3(3, 0, 0))
	await _wait(0.8)
	print("crew [client]: at the hydrant its prompt is offered: %s" % hydrant["prompt"].shown_to(me))
	_use(hydrant["prompt"])
	var connected: = await _wait_until( func() -> bool: return hoses.supplied_by(truck) != null, 6.0)
	await _wait(4.0)
	print("crew [client]: connected: %s; the plate would say supply '%s'; tank %.0f -> %.0f L" % [connected, str(hoses.supplied_by(truck)), water, truck.water])
	me.teleport(me.global_position + Vector3(8, 0, 6))


func _play_client_divider() -> void :
	var hoses: = _hoses()
	var me: = Game.local_player
	await _wait_until( func() -> bool: return Net.players.size() > 1, 60.0)
	var mine: = await _wait_until( func() -> bool: return hoses.divider["state"] == "carried" and hoses.divider["player"] == me, 20.0)
	await _wait(0.5)
	print("crew [client]: carrying the divider: %s (holding '%s', Tool %s, in hand %s, its plate %s)" % [mine, me.holding, str(me.get_attr("Tool")), is_instance_valid(hoses.divider["tool"]) and hoses.divider["tool"].visible, hoses.divider["entry"] != null])

	hoses.divider["entry"]["set_in_hand"].call(false)
	await _wait(0.8)
	print("crew [client]: put on the belt: in hand %s, holding '%s'" % [hoses.divider["tool"].visible, me.holding])
	hoses.divider["entry"]["set_in_hand"].call(true)
	await _wait(0.8)
	print("crew [client]: back in hand: in hand %s, holding '%s'" % [hoses.divider["tool"].visible, me.holding])
	for pressed: bool in [true, false]:
		var click: = InputEventAction.new()
		click.action = "fire"
		click.pressed = pressed
		Input.parse_input_event(click)
		await _wait(0.15)
	var placed: = await _wait_until( func() -> bool: return hoses.divider["state"] == "placed", 5.0)
	print("crew [client]: set down with a click: %s, %d lines, holding '%s'; pickup prompt %s" % [placed, hoses.lines.size(), me.holding, is_instance_valid(hoses.divider["pickup"])])

	var line: Dictionary = hoses.lines[1]
	me.teleport(line["source"].global_position + Vector3(0, 1, 0) + (line["source"].global_position - _truck().global_position).normalized() * 4.0)
	await _wait(0.8)
	_use(line["prompt"])
	var took: = await _wait_until( func() -> bool: return hoses.line_of(me) != null, 6.0)
	print("crew [client]: took a line: %s; leaving with it" % took)
	await _wait(1.5)
	Game.quit()
