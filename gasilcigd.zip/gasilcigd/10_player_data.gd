extends RefCounted


static func start(_main: Node) -> void :

	Training.listen()
	if Game.local_player and not OS.get_cmdline_user_args().has("--no-save"):
		PlayerData.start(Game.local_player)
