class_name HudNameTags
extends Control







var _font: Font
var _hidden: Dictionary = {}
var _next_look: = 0.0
var _drawn: = false


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = Ui.label_font()


func _others() -> Array[Player]:
	var found: Array[Player] = []
	for player in Game.players:
		if is_instance_valid(player) and player != Game.local_player and player.brain == null:
			found.append(player)
	return found


func _process(_delta: float) -> void :
	var any: = not _others().is_empty()
	if any or _drawn:
		queue_redraw()
	_drawn = any


func _draw() -> void :
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var settings: Dictionary = Config.Talk
	var reach: = float(settings["TagRange"])
	var fade_from: = float(settings["TagFadeFrom"])
	var now: = Game.now()
	var looking: = now >= _next_look
	if looking:
		_next_look = now + float(settings["TagLook"])
		_hidden.clear()
	for player in _others():
		var head: = player.head_position() + Vector3(0, 1.8, 0)
		if camera.is_position_behind(head):
			continue
		var distance: = camera.global_position.distance_to(head)
		if distance > reach or distance < float(settings["TagNear"]):
			continue
		if looking:
			var exclude: Array[RID] = []
			if Game.local_player != null:
				exclude.append(Game.local_player.get_rid())
			_hidden[player] = not Game.world.raycast(camera.global_position, head, World.LAYER_SOLID, exclude).is_empty()
		var alpha: = 1.0 - clampf((distance - fade_from) / maxf(reach - fade_from, 1.0), 0.0, 1.0)
		if _hidden.get(player, false):
			alpha *= float(settings["TagHidden"])
		if alpha <= 0.01:
			continue
		var point: = camera.unproject_position(head)
		var colour: = NetTalk.colour_of(player)
		colour.a = alpha
		var shade: = Color(0, 0, 0, 0.75 * alpha)
		var status: = NetTalk.status_of(player)
		var tint: Color = status[1]
		tint.a = alpha
		var top: = point + Vector2(-150, -14)
		draw_string_outline(_font, top, player.display_name, HORIZONTAL_ALIGNMENT_CENTER, 300, 18, 6, shade)
		draw_string(_font, top, player.display_name, HORIZONTAL_ALIGNMENT_CENTER, 300, 18, colour)
		var words: = Text.say(status[0])
		var low: = point + Vector2(-150, 4)
		draw_string_outline(_font, low, words, HORIZONTAL_ALIGNMENT_CENTER, 300, 14, 5, shade)
		draw_string(_font, low, words, HORIZONTAL_ALIGNMENT_CENTER, 300, 14, tint.lightened(0.15))
