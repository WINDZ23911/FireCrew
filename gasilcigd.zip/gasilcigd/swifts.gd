class_name Swifts
extends Node3D









const HOURS: Array = [[6.2, 8.6, 0.4], [16.8, 21.0, 0.85]]
const SLOT: = 70.0
const REACH: = 420.0
const LIVE: = 3
const MOST: = 11
const BODY: = Vector3(0.48, 0.4, 1.5)
const WING: = Vector3(2.4, 0.07, 0.52)
const SWEEP: = 0.65
const COLOR: = Color(0.1, 0.09, 0.09)
const LAG: = 0.2
const CALL_GAP: = Vector2(3.5, 9.0)
const HEARD: = 170.0

var centres: Array[Vector3] = []
var _mesh: MultiMesh
var _voices: Array = []
var _next_call: Array = []
var _scream: AudioStream
var _look: Camera3D


func _ready() -> void :
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_find_centres()
	if OS.get_cmdline_user_args().has("--swifts-trace"):
		print("swifts: ", centres.size(), " places they wheel over: ", centres)
	_mesh = MultiMesh.new()
	_mesh.transform_format = MultiMesh.TRANSFORM_3D
	_mesh.mesh = World.unit_mesh(PartStore.Shape.BLOCK)
	_mesh.instance_count = MOST * LIVE * 3
	_mesh.visible_instance_count = 0
	var material: = StandardMaterial3D.new()
	material.albedo_color = COLOR
	material.roughness = 0.9
	var drawn: = MultiMeshInstance3D.new()
	drawn.name = "Birds"
	drawn.multimesh = _mesh
	drawn.material_override = material
	drawn.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	drawn.custom_aabb = AABB(Vector3(-1500, -50, -1500), Vector3(3000, 400, 3000))
	add_child(drawn)
	if OS.get_cmdline_user_args().has("--swifts-look"):
		_look = Camera3D.new()
		_look.far = 4000.0
		add_child(_look)
		_look.make_current()
	_scream = Assets.sound("swift_scream")
	for index in LIVE:
		var voice: = AudioStreamPlayer3D.new()
		voice.stream = _scream
		voice.unit_size = 22.0
		voice.max_distance = HEARD
		voice.volume_db = -6.0
		voice.bus = "Master"
		add_child(voice)
		_voices.append(voice)
		_next_call.append(0.0)




func _find_centres() -> void :
	var layout: Dictionary = Rbx.module("TownLayout")
	var cells: = {}
	for building: Dictionary in layout.get("buildings", []):
		var floors: = int(building.get("floors", 1))
		if floors < 3 and not (floors >= 2 and building.get("kind", "") in ["shop", "public", "apartments"]):
			continue
		var cell: = Vector2i(floori(float(building["x"]) / 170.0), floori(float(building["z"]) / 170.0))
		if not cells.has(cell):
			cells[cell] = [Vector3.ZERO, 0]
		cells[cell][0] += Vector3(building["x"], 0, building["z"])
		cells[cell][1] += 1
	var keys: = cells.keys()
	keys.sort()
	for cell: Vector2i in keys:
		if cells[cell][1] >= 2:
			var middle: Vector3 = cells[cell][0] / float(cells[cell][1])
			middle.y = _roofs(middle)
			centres.append(middle)




func _roofs(middle: Vector3) -> float:
	var tops: Array[float] = []
	for x in range(-100, 101, 20):
		for z in range(-100, 101, 20):
			var hit: = Game.world.raycast(middle + Vector3(x, 300, z), middle + Vector3(x, -10, z), World.LAYER_SOLID | World.LAYER_QUERY)
			tops.append(hit["position"].y if not hit.is_empty() else 0.0)
	tops.sort()
	return maxf(tops[int(tops.size() * 0.8)], tops[int(tops.size() * 0.95)] - 6.0)


static func _roll(a: int, b: int) -> float:
	return float(rand_from_seed(hash([a, b]))[0] %100000) / 100000.0



static func share_at(hour: float) -> float:
	if Style.winter():
		return 0.0
	for window: Array in HOURS:
		if hour >= window[0] and hour < window[1]:

			var into: float = minf(hour - window[0], window[1] - hour)
			return window[2] * clampf(into / 0.6, 0.2, 1.0)
	return 0.0



static func _on_loop(centre: Vector3, seed_number: int, t: float) -> Vector3:
	var turn: = _roll(seed_number, 1) * TAU
	var wide: = 55.0 + _roll(seed_number, 2) * 40.0
	var deep: = 35.0 + _roll(seed_number, 3) * 35.0
	var pace: = 0.55 + _roll(seed_number, 4) * 0.25
	var local: = Vector3(sin(t * pace) * wide, 0, sin(t * pace * 1.37 + 1.3) * deep)
	local.y = 18.0 + _roll(seed_number, 5) * 12.0 + sin(t * pace * 0.83 + 0.4) * 7.0
	return centre + local.rotated(Vector3.UP, turn)


func _process(_delta: float) -> void :
	var hour: = Sky3D.current.hour if Sky3D.current else 12.0
	var share: = share_at(hour)
	if share <= 0.0 or centres.is_empty():
		_mesh.visible_instance_count = 0
		for voice: AudioStreamPlayer3D in _voices:
			voice.stop()
		return
	var camera: = get_viewport().get_camera_3d()
	if camera == null:
		return
	var eye: = camera.global_position
	var now: = HostClock.now()
	var slot: = floori(now / SLOT)
	var used: = 0
	var live: = 0
	for index in centres.size():
		if live >= LIVE:
			break
		var centre: = centres[index]
		if Vector2(centre.x - eye.x, centre.z - eye.z).length() > REACH and _look == null:
			continue
		if _roll(index, slot) >= share:
			continue
		var seed_number: = hash([index, slot])
		var birds: = 6 + int(_roll(seed_number, 6) * (MOST - 6 + 1))
		var lead: = Vector3.ZERO
		for bird in birds:
			var t: = now - bird * LAG + _roll(seed_number, 10 + bird) * 0.08
			var at: = _on_loop(centre, seed_number, t)
			var ahead: = _on_loop(centre, seed_number, t + 0.05) - at
			var further: = _on_loop(centre, seed_number, t + 0.1) - (at + ahead)
			at += Vector3(_roll(seed_number, 30 + bird) - 0.5, _roll(seed_number, 50 + bird) - 0.5, 0) * 3.0
			if bird == 0:
				lead = at
			if ahead.length() < 0.001:
				continue

			var bank: = clampf(ahead.normalized().cross(further.normalized()).y * 18.0, -1.1, 1.1)
			var facing: = Basis.looking_at(ahead.normalized(), Vector3.UP) * Basis(Vector3.BACK, bank)
			var body: = Transform3D(facing, at)

			var gliding: = sin(now * 0.8 + bird * 1.7) > 0.3
			var beat: = 0.05 if gliding else sin(now * 19.0 + bird * 2.3) * 0.55
			_mesh.set_instance_transform(used, body * Transform3D(Basis.from_scale(BODY), Vector3.ZERO))
			var left: = Basis(Vector3.UP, - SWEEP) * Basis(Vector3.BACK, - beat)
			var right: = Basis(Vector3.UP, SWEEP) * Basis(Vector3.BACK, beat)
			_mesh.set_instance_transform(used + 1, body * Transform3D(left * Basis.from_scale(WING), left * Vector3( - WING.x / 2.0, 0, 0)))
			_mesh.set_instance_transform(used + 2, body * Transform3D(right * Basis.from_scale(WING), right * Vector3(WING.x / 2.0, 0, 0)))
			used += 3
		if _look and live == 0:
			var out: = (lead - centre) * Vector3(1, 0, 1)
			_look.look_at_from_position(lead + out.normalized() * 26.0 + Vector3(0, 10, 0), lead)

		var voice: AudioStreamPlayer3D = _voices[live]
		voice.global_position = lead
		if _scream and lead.distance_to(eye) < HEARD and now >= _next_call[live]:
			_next_call[live] = now + randf_range(CALL_GAP.x, CALL_GAP.y)
			voice.pitch_scale = randf_range(0.92, 1.08)
			voice.play()
		live += 1
	_mesh.visible_instance_count = used
