extends RefCounted





static func start(main: Node) -> void :
	var calls: = CallService.current
	if calls == null or FireService.current == null or IndustryZone.houses.is_empty() and IndustryZone.places.is_empty():
		return

	if AirService.current != null and ChemSuit.current == null:
		var suits: = ChemSuit.new()
		suits.name = "ChemSuit"
		main.add_child(suits)
	var leak: = HazmatLeak.new()
	leak.name = "HazmatLeak"
	main.add_child(leak)
	leak.start()
	var accident: = WorkAccident.new()
	accident.name = "WorkAccident"
	main.add_child(accident)
	accident.start()
	var alarm: = FireAlarm.new()
	alarm.name = "FireAlarm"
	main.add_child(alarm)
	alarm.start()
	for call_kind: Node in [leak, accident, alarm]:
		calls.kinds.append(call_kind)
