class_name JobBoard
extends CrewJob



var driving: = false


func _init(vehicle: Vehicle, at_wheel: = false) -> void :
	kind = "mount"
	target = vehicle
	driving = at_wheel


func place() -> Vector3:
	return target.global_position


func suits(member: Crewman) -> bool:
	return member.body.seat == null or member.body.get_attr("Vehicle") != target


func run() -> bool:
	var vehicle: Vehicle = target
	if driving and vehicle.driver() != null:
		return fail("crew.say.taken")
	if not driving and not who.service.free_seat(vehicle):
		return fail("crew.say.noRoom")
	var door: = who.service.door_for(vehicle, who.body.global_position, driving)
	var held: = who.token()
	while true:
		var at: Vector3 = who.service.door_spot(vehicle, door)
		if await who.go(at, 2.5, 40.0):
			break
		if not on(held):
			return false
		return fail("crew.say.stuck")
	if driving and vehicle.driver() != null:
		return fail("crew.say.taken")
	CrewKit.stow_all(who)
	vehicle._board(who.body, door)
	if who.body.seat == null:
		return fail("crew.say.noRoom")
	who.mode = "hold"
	return true
