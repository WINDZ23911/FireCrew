extends ProofDebug





func _scenario_stairs() -> void :
	await _wait(1.0)
	var base: = Vector3(300, 0, 300)
	var hit: = Game.world.raycast(base + Vector3(0, 200, 0), base - Vector3(0, 200, 0), World.LAYER_SOLID)
	if not hit.is_empty():
		base = hit["position"]
	var rise: = 0.8
	var run: = 1.4
	var steps: = StaticBody3D.new()
	steps.collision_layer = World.LAYER_SOLID
	Game.world.add_child(steps)
	for index in 10:
		var shape: = CollisionShape3D.new()
		var box: = BoxShape3D.new()
		box.size = Vector3(8, rise * (index + 1), run)
		shape.shape = box
		steps.add_child(shape)
		shape.position = base + Vector3(0, rise * (index + 1) / 2.0, -20.0 - run * index)
		var drawn: = MeshInstance3D.new()
		var mesh: = BoxMesh.new()
		mesh.size = box.size
		drawn.mesh = mesh
		shape.add_child(drawn)
	var top: = base + Vector3(0, rise * 10, -20.0 - run * 10)
	player.teleport(base + Vector3(0, 0.3, 0))
	player.camera.yaw = 0.0
	await _wait(0.8)
	Input.action_press("move_forward")
	await _wait(0.6)
	var from: = player.global_position
	await _wait(0.5)
	var flat: = (player.global_position - from) * Vector3(1, 0, 1)
	var flat_speed: = flat.length() / 0.5

	var walking: = Game.now()
	while player.global_position.z > base.z - 20.0 + 0.5 and Game.now() - walking < 6.0:
		await _wait(0.05)
	print("stairs: at the foot of the steps: %s (flat %.1f studs/s)" % [player.global_position - base, flat_speed])
	from = player.global_position
	var started: = Game.now()
	var off: = [0, 0]
	var count: = func() -> void :
		off[1] += 1
		if not player.rig.on_floor:
			off[0] += 1
	get_tree().physics_frame.connect(count)
	while player.global_position.y < top.y - 0.5 and Game.now() - started < 8.0:
		await _wait(0.05)
	get_tree().physics_frame.disconnect(count)
	print("stairs: up, off the floor %d of %d frames" % off)
	var took: = Game.now() - started
	var along: = ((player.global_position - from) * Vector3(1, 0, 1)).length()
	var stair_speed: = along / maxf(took, 0.01)
	Input.action_release("move_forward")
	print("stairs: flat %.1f studs/s, up the steps %.1f studs/s along the ground (%.1f s for %.1f studs up), now at %.1f of %.1f" % [flat_speed, stair_speed, took, player.global_position.y - from.y, player.global_position.y, top.y])
	await _snap("stairs")
	_check(player.global_position.y >= top.y - 0.6, "the body gets to the top of the steps")
	_check(stair_speed <= flat_speed * 0.85 and stair_speed > flat_speed * 0.4, "up the steps it goes slower than on the flat, but on")
	_check(off[0] == 0, "up the steps the body keeps its feet (no jump or crouched pose)")

	await _wait(0.4)
	player.camera.yaw = PI
	var down: = [0, 0]
	var count_down: = func() -> void :
		down[1] += 1
		if not player.rig.on_floor:
			down[0] += 1
	get_tree().physics_frame.connect(count_down)
	Input.action_press("move_forward")
	started = Game.now()
	while player.global_position.y > base.y + 0.3 and Game.now() - started < 8.0:
		await _wait(0.05)
	Input.action_release("move_forward")
	get_tree().physics_frame.disconnect(count_down)
	print("stairs: down, off the floor %d of %d frames, now at %.1f" % [down[0], down[1], player.global_position.y - base.y])
	_check(player.global_position.y <= base.y + 0.5, "the body gets back down the steps")
	_check(down[0] <= 2, "down the steps the body keeps its feet")
	steps.queue_free()
	await _done()




func _scenario_cabdoor() -> void :
	await _wait(1.0)
	var truck: = Vehicle.named("Fire Truck")
	var door: Dictionary = truck.doors["DoorCabLeft"]
	player.teleport(truck.global_transform * door["doorway"] + truck.global_basis.x * -3.0)
	await _wait(0.3)
	truck.set_door("DoorCabLeft", true)
	await _wait(0.05)
	truck._board_at(player, "DoorCabLeft")
	await _wait(1.2)
	var hinge: Node3D = door["hinge"]
	print("cabdoor: seated %s, door open %s, drawn at %.2f rad (amount %.2f)" % [player.seat != null, door["open"], hinge.rotation.y, door["amount"]])
	await _snap("cabdoor")
	_check(player.seat != null, "the driver is in")
	_check( not door["open"] and absf(hinge.rotation.y) < 0.01, "the door is shut, and drawn shut")
	await _done()




func _scenario_climbing() -> void :
	await _wait(1.0)
	var roof: = TruckRoof.current
	var ladder: Dictionary = {}
	for each: Dictionary in roof.ladders:
		if (each["vehicle"] as Vehicle).spec["name"] == "Tanker":
			ladder = each
	_check( not ladder.is_empty(), "the tanker has a ladder up its back")
	if ladder.is_empty():
		await _done()
		return
	var vehicle: Vehicle = ladder["vehicle"]
	player.teleport(vehicle.global_transform * Vector3(float(ladder["x"]), float(ladder["bottom"]) - 2.0, float(ladder["z"]) + 2.0))
	player.camera.yaw = vehicle.global_rotation.y
	await _wait(0.6)
	var poses: = [0, 0]
	var count: = func() -> void :
		if roof.climbing(player):
			poses[1] += 1
			if player.rig.climbing and player.rig.on_floor:
				poses[0] += 1
	get_tree().physics_frame.connect(count)
	Input.action_press("move_forward")
	var started: = Game.now()
	var shot: = false
	var top: = false
	while Game.now() - started < 6.0:
		await _wait(0.05)
		if not shot and roof.climbing(player) and Game.now() - started > 0.6:
			shot = true
			await _snap("climbing_up")
		var local: = vehicle.global_transform.affine_inverse() * player.global_position
		if not roof.climbing(player) and local.y > float(ladder["top"]) and not player.vaulting():
			top = true
			break
	Input.action_release("move_forward")
	await _wait(0.5)
	var on_roof: = vehicle.global_transform.affine_inverse() * player.global_position
	print("climbing: up in %.1f s, on the roof at %.1f (top %.1f), on the floor %s; drawn climbing %d of %d frames on the rungs" % [Game.now() - started, on_roof.y, float(ladder["top"]), player.is_on_floor(), poses[0], poses[1]])
	_check(top and on_roof.y > float(ladder["top"]) - 0.3 and player.is_on_floor(), "the climber gets over the top and stands on the roof")
	_check(poses[1] > 10 and poses[0] >= poses[1] - 1, "on the rungs the body is drawn climbing")

	player.camera.yaw = vehicle.global_rotation.y + PI
	Input.action_press("move_forward")
	started = Game.now()
	var down_shot: = false
	while Game.now() - started < 8.0:
		await _wait(0.05)
		if not down_shot and roof.climbing(player) and Game.now() - started > 0.8:
			down_shot = true
			await _snap("climbing_down")
		if Game.now() - started > 1.0 and not roof.climbing(player) and player.is_on_floor() and (vehicle.global_transform.affine_inverse() * player.global_position).y < float(ladder["bottom"]):
			break
	Input.action_release("move_forward")
	get_tree().physics_frame.disconnect(count)
	var below: = vehicle.global_transform.affine_inverse() * player.global_position
	print("climbing: down at %.1f (bottom %.1f), climbing pose ends %s" % [below.y, float(ladder["bottom"]), not player.rig.climbing])
	_check(below.y < float(ladder["bottom"]) and not roof.climbing(player), "the climber gets back down to the road")
	_check( not player.rig.climbing, "off the rungs the body walks again")
	await _done()
