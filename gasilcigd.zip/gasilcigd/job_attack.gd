class_name JobAttack
extends CrewJob





const KINDS: Array[String] = ["outlet", "reel", "divider"]

var first: Dictionary
var line: Variant = null
var current: Dictionary = {}
var _trace_at: = 0.0
var tried_lines: Array = []


func _init(target: Dictionary = {}) -> void :
	kind = "attack"
	role = "nozzle"
	first = target


func place() -> Vector3:
	if not first.is_empty():
		return first["position"]
	return Game.incident.get("pos", who.body.global_position if who != null else Vector3.ZERO)


func suits(member: Crewman) -> bool:
	return member.body.get_attr("Supply") == null



func _pick_line(toward: Vector3) -> Variant:
	var best: Variant = null
	var best_score: = INF
	var home: Variant = who.service.home_vehicle(who.commander())
	for each: Dictionary in HoseService.current.lines:
		if each["player"] != null or each.get("feeding", false) or each.get("relay") != null or not each["kind"] in KINDS:
			continue
		if each.get("divert") is Callable and each["divert"].is_valid():
			continue
		if each.get("down") != null or each in tried_lines or _picked_by_another(each):
			continue
		var rig: Variant = HoseService.current.rig_of(each)
		if rig == null or rig["vehicle"].water <= 0.0 and HoseService.current.supplied_by(rig["vehicle"]) == null:
			continue
		var source: Node3D = each["source"]
		var score: = source.global_position.distance_to(toward) + source.global_position.distance_to(who.body.global_position) * 0.5
		if each["kind"] == "reel":
			score += 25.0
		if rig["vehicle"] != home:
			score += 40.0
		if score < best_score:
			best_score = score
			best = each
	return best


func run() -> bool:
	var hoses: = HoseService.current
	var held: = who.token()
	if who.body.health < who.body.max_health * 0.6:
		return fail("crew.say.hurt")
	var target: = first if not first.is_empty() and CrewWater.still_on(first) else CrewWater.nearest_target(who.body.global_position, _taken())
	if target.is_empty():
		return fail("crew.say.noFire")
	current = target

	if target["room"] != null or (FireService.current and FireService.current.smoke_at(target["position"]) > 0.25):
		if not await CrewWater.wear_set(who):
			who.say("crew.say.noSet", [], "warning")
	CrewKit.free_hands(who)
	if not await take_line(target["position"], held):
		return false
	var kind: = hoses.kind_of(line["kind"])
	var skill: = CrewRoster.skill(who.member)
	who.body.set_attr("Flow", int(Config.Crew.get("Flow", 2)))
	var spot: = Vector3.INF
	var spot_for: Dictionary = {}
	var started: = Game.now()
	var last_knock: = Game.now()
	var last_damage: = 0.0
	var tried: Array = []
	var moving_on: = false
	while on(held):
		if hoses.line_of(who.body) == null:
			return fail("crew.say.lineLost")
		if not CrewWater.breathe(who):
			return fail("crew.say.lowAir")
		if who.body.health < who.body.max_health * who.back_out_at():


			await _back_out(held)
			return fail("crew.say.hurt")
		if current.is_empty() or not CrewWater.still_on(current):
			who.body.set_attr("Trigger", false)
			current = CrewWater.nearest_target(who.body.global_position, _taken())
			if current.is_empty():
				return true
			spot = Vector3.INF
			last_knock = Game.now()
			last_damage = 0.0
			tried.clear()

		if spot == Vector3.INF or not is_same(spot_for, current["node"]):
			spot_for = current["node"]
			spot = CrewWater.spot_for(who, current["position"], who.body.global_position)
			if spot == Vector3.INF:
				spot = who.stand_by(current["position"], 10.0)
		var paid: float = float(who.body.get_attr("HoseLength", 0.0))
		var room: = float(kind["length"]) - paid
		var to_spot: = Vector3(spot.x - who.body.global_position.x, 0, spot.z - who.body.global_position.z).length()
		var shot: = CrewWater._clear_shot(who.body.root_position() + Vector3(0, 1, 0), current["position"])
		var near: = who.body.global_position.distance_to(current["position"]) < 30.0
		if OS.get_cmdline_user_args().has("--crew-trace") and Game.now() >= _trace_at:
			_trace_at = Game.now() + 3.0
			print("crew trace: %s attack at %s target %s spot %s to_spot %.1f room %.0f shot %s near %s trigger %s" % [who.display_name(), who.body.global_position.snapped(Vector3.ONE), current["position"].snapped(Vector3.ONE), spot.snapped(Vector3.ONE) if spot != Vector3.INF else "-", to_spot, room, shot, near, who.body.get_attr("Trigger")])
		if to_spot > 2.5 and room > 12.0 and (moving_on or not (shot and near and to_spot < 8.0)):


			who.body.set_attr("Trigger", false)
			var aiming_at: Dictionary = current
			var line_kind: = kind
			await who.go(spot, 2.0, 25.0, func() -> bool:
				if not CrewWater.still_on(aiming_at):
					return true
				if float(line_kind["length"]) - float(who.body.get_attr("HoseLength", 0.0)) < 10.0:
					return true
				return who.body.global_position.distance_to(aiming_at["position"]) < 26.0 and CrewWater._clear_shot(who.body.root_position() + Vector3(0, 1, 0), aiming_at["position"])
			)
			if not on(held):
				return false
			if not who.blocked_by.is_empty() and who.blocked_by["locked"]:

				var door: = who.blocked_by
				if not await CrewSearch.force_way(who, door, held):
					return fail("crew.say.locked") if on(held) else false
				spot = Vector3.INF
				continue
			spot = who.body.global_position if CrewWater._clear_shot(who.body.root_position() + Vector3(0, 1, 0), current["position"]) else spot
			moving_on = false
			continue

		who.wish = Vector3.ZERO
		var wander: = (1.0 - skill) * 4.0

		if current["room"] != null and FireService.current != null and not FireService.current.incident.is_empty():
			var inside: Variant = (FireService.current.incident["group"]["building"] as Building).room_at(who.body.root_position())
			if inside == null or inside["name"] != current["room"]:
				wander *= float(Config.Crew.WindowAim)
		var aim: Vector3 = current["position"] + Vector3(sin(Game.now() * 1.7) * wander, cos(Game.now() * 1.1) * wander * 0.4, cos(Game.now() * 1.3) * wander)
		who.look = aim
		who.pitch = asin(clampf((aim - who.body.head_position()).normalized().y, -1.0, 1.0))
		who.body.set_attr("Aim", aim)
		var grease: bool = Game.incident.get("trait") == "grease" or (FireService.current != null and FireService.current.has_trait("grease"))
		who.body.set_attr("Pattern", "Fog" if grease or current["ember"] else "Jet")
		await who.wait(0.35, held)
		who.body.set_attr("Trigger", true)
		await who.wait(0.4, held)

		var damage: float = float(current["node"].get("damage", current["node"].get("wet", 0.0)))
		if damage > last_damage + 0.5:
			last_damage = damage
			last_knock = Game.now()
		elif Game.now() - last_knock > 5.0:
			last_knock = Game.now()
			tried.append(spot)
			tried.append(who.body.global_position)
			spot = CrewWater.spot_for(who, current["position"], who.body.global_position, tried)

			var house: = CrewSearch.house()
			if tried.size() >= 4 and current["room"] != null and house != null and house.rooms.has(current["room"]):
				spot = CrewSearch.middle(house, current["room"]).lerp(current["position"], 0.4)
			if spot == Vector3.INF:
				spot = who.stand_by(current["position"], 7.0 + randf() * 6.0)
			moving_on = true
		if Game.now() - started > 600.0:
			return false
	return false




func take_line(toward: Vector3, held: int) -> bool:
	var hoses: = HoseService.current
	line = hoses.line_of(who.body)
	if line != null:
		return true


	tried_lines.clear()
	while hoses.line_of(who.body) == null:
		line = _pick_line(toward)
		if line == null:
			if tried_lines.is_empty():
				return fail("crew.say.noLine")
			var why: Variant = hoses.refusal_for(who.body)
			return fail("crew.say.cannotBecause", [why]) if why != null else fail("crew.say.noLine")
		if not await who.press(line["prompt"]):
			return fail("crew.say.stuck") if on(held) else false
		await who.wait(0.4, held)
		if not on(held):
			return false
		if hoses.line_of(who.body) == null:
			tried_lines.append(line)
			line = null
	line = hoses.line_of(who.body)
	return true



func _back_out(held: int) -> void :
	who.body.set_attr("Trigger", false)
	who.report("crew.say.backOut", [], "warning")
	var truck: Variant = who.service.home_vehicle(who.commander())
	if truck is Vehicle:
		var away: Vector3 = (truck as Vehicle).global_position - who.body.global_position
		away.y = 0.0
		var step: = minf(away.length(), float(Config.Crew.BackOut))
		if step > 2.0:
			await who.go(who.body.global_position + away.normalized() * step, 2.0, 8.0)
	if not on(held):
		return



func _picked_by_another(each: Dictionary) -> bool:
	for mind in who.service.members:
		if mind != who and mind.job is JobAttack and mind.job.line != null and is_same(mind.job.line, each):
			return true
	return false



func _taken() -> Array:
	var taken: Array = []
	for mind in who.service.members:
		if mind != who and mind.job is JobAttack and not mind.job.current.is_empty():
			taken.append(mind.job.current["node"])
	return taken



func _step_toward(to: Vector3, held: int) -> void :
	var until: = Game.now() + 1.5
	while who.alive(held) and Game.now() < until:
		var gap: = Vector3(to.x - who.body.global_position.x, 0, to.z - who.body.global_position.z).length()
		if gap < 2.0:
			break
		who._steer(to, 1.5)
		await who.tick()
	who.wish = Vector3.ZERO


func finish(_done: bool) -> void :
	who.body.set_attr("Trigger", false)
	var hoses: = HoseService.current
	var held_line: Variant = hoses.line_of(who.body)
	if held_line != null:
		hoses.disconnect_line(held_line)
		hoses._refresh_divider()
	var air: = AirService.current
	if air != null and air.sets.has(who.body) and air.sets[who.body]["mask"] and FireService.current and FireService.current.smoke_at(who.body.root_position()) <= 0.0:
		air.move_mask(who.body)
